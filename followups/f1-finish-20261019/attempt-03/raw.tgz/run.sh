#!/bin/bash
set -euo pipefail
cd /workspace/d1probe
mkdir -p source results
cleanup() {
 if test -s /workspace/d1probe/clock_uuid; then nvidia-smi -i "$(cat /workspace/d1probe/clock_uuid)" -rgc > /workspace/d1probe/results/clock-reset.txt 2>&1 || true; fi
 touch /workspace/d1probe/done
}
trap cleanup EXIT
python -m venv --without-pip --system-site-packages /workspace/d1probe/.venv
export PATH=/workspace/d1probe/.venv/bin:$PATH
tar -xf source.tar -C source
nvidia-smi --query-gpu=name,uuid,driver_version,memory.total --format=csv,noheader > results/gpu.txt
python -m pip install --disable-pip-version-check --timeout 20 --retries 1 --no-deps bitsandbytes==0.50.2
python -m pip install --disable-pip-version-check --timeout 20 --retries 1 rich==14.0.0 transformers==5.17.0 peft==0.20.0 accelerate==1.14.0 'pydantic>=2,<3' pytest pytest-cov psutil nvidia-ml-py
export CUBLAS_WORKSPACE_CONFIG=:4096:8
export CUDA_AUTO_BOOST=0
printf "CUDA_AUTO_BOOST=0\n" > results/clock-request.txt
export D1_SOURCE_SHA=e274b7e2905574c0864b91a02dd8b390ba1bad6b
export PYTHONPATH=/workspace/d1probe/source/benchmarks/harness:/workspace/d1probe/source:/workspace/d1probe/source/src:/workspace/d1probe/source/tests
nvidia-smi --query-gpu=uuid --format=csv,noheader | head -n 1 > clock_uuid
nvidia-smi -i "$(cat clock_uuid)" -lgc 1200,1200 > results/clock-lock.txt 2>&1 || true
python -m pip freeze > results/packages-before.txt
sha256sum source/benchmarks/d1-final-f1-rule-20261016.md source/benchmarks/d1-final-f1-a100-20261016.md > results/rule-sha256.txt
python source/benchmarks/harness/d1_native_acceptance.py --output results/native-gates > results/native-gates.log 2>&1
cd source
python -m pytest tests/test_issue842_checkpoint_visible_nf4.py tests/test_issue968_bnb_nf4_path_divergence.py -m gpu --no-cov -q > ../results/gpu-regressions.log 2>&1
cd ..
python source/benchmarks/harness/d1_final_f1.py prepare --data fixture --output results/prepare
cp fixture/correctness.json fixture/native.pt fixture/candidate.pt results/prepare/
cp -r fixture/resident-gate results/prepare/
python source/benchmarks/harness/d1_final_f1.py dispatch --data fixture --output results/dispatch --route candidate
python source/benchmarks/harness/d1_final_f1.py run --data fixture --output results/f1
python -m pip freeze > results/packages-final.txt
