"""The smaller lease keeps numerical qualification and explicitly omits large traces."""

import copy
import json
import math
from pathlib import Path

import pytest

import cloud
from launch_safety import validate_protocol


def protocol():
    return json.loads((Path(__file__).parent / "protocol.json").read_text())


def test_standalone_plan_is_explicit_and_original_accuracy_timing_recipe_unchanged():
    value = protocol()
    validate_protocol(value, source_commit=value["source_commit"], stage_id=cloud.STAGE)
    assert value["execution_plan"]["large_profiles_in_this_lease"] is False
    assert value["execution_plan"]["dispatch_qualification"] is True
    assert value["performance"]["dispatch_qualification"]["accuracy_updates"] == 2
    assert value["performance"]["dispatch_qualification"]["timing_workers"] == 8
    assert value["financial"]["maximum_stage_usd"] == 3.0
    assert value["financial"]["maximum_seconds"] == 14400
    assert cloud.RESERVE_USD == .75
    context = json.loads((Path(__file__).parent / "prior-budget-context.json").read_text())
    assert math.isclose(context["prior_remaining_usd"] + context["new_authorized_usd"] - context["failed_f10_cost_usd"] - context["failed_f11_cost_usd"] - context["failed_f12_cost_usd"] - context["failed_f13_cost_usd"],
                        context["aggregate_remaining_before_f14_usd"], abs_tol=1e-12)
    assert 3.0 < context["aggregate_remaining_before_f14_usd"]
    assert value["performance"]["dispatch_qualification"]["timing_variants"] == [
        "ordinary_legacy", "grouped"]



@pytest.mark.parametrize("key", ["native_accuracy_phase_in_this_lease",
                                 "large_profiles_in_this_lease", "dispatch_qualification"])
def test_changed_execution_plan_is_refused(key):
    value = copy.deepcopy(protocol())
    value["execution_plan"][key] = not value["execution_plan"][key]
    with pytest.raises(ValueError, match="execution plan"):
        validate_protocol(value, source_commit=value["source_commit"], stage_id=cloud.STAGE)


def test_git_deployment_fetches_full_objects_before_any_dependency_or_gpu_work():
    text = (Path(__file__).parent / "setup.sh").read_text()
    assert "--filter=blob:none" not in text
    assert "git config --local core.autocrlf true" in text
    assert "git config --local gc.auto 0" in text
    assert text.index("git fetch") < text.index("python3 -m pip install uv")
