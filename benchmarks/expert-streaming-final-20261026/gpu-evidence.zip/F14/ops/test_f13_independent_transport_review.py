"""Independent refusal and cleanup-priority controls; all networking is mocked."""

import ast
import hashlib
import io
import json
import urllib.error
import urllib.request
from pathlib import Path
from types import SimpleNamespace

import api_rate_limit as rate
import api_transport as transport
import pytest


@pytest.mark.parametrize("floor", [0., 1.99, float("nan"), float("inf"), -float("inf")])
def test_shared_cadence_never_accepts_invalid_floor(tmp_path, floor):
    with pytest.raises(ValueError):
        rate.SharedAdmission(tmp_path, floor_seconds=floor)


@pytest.mark.parametrize("last", [float("nan"), float("inf"), -float("inf"), "invalid"])
def test_corrupt_shared_state_cannot_silently_bypass_rate_floor(tmp_path, last):
    (tmp_path / "admission.json").write_text(json.dumps({"last_start_monotonic": last}))
    admission = rate.SharedAdmission(tmp_path)
    with pytest.raises((ValueError, RuntimeError)):
        admission.wait(deadline=rate.time.monotonic() + 1.)


def test_cleanup_requested_during_normal_wait_gets_the_next_slot(tmp_path, monkeypatch):
    current = [100.]
    cleanup_request = tmp_path / "cleanup-priority-review.json"
    (tmp_path / "admission.json").write_text(json.dumps({"last_start_monotonic": 99.}))

    def sleep(seconds):
        current[0] += seconds
        if not cleanup_request.exists():
            cleanup_request.write_text(json.dumps({"monotonic": current[0]}))

    monkeypatch.setattr(rate.time, "monotonic", lambda: current[0])
    monkeypatch.setattr(rate.time, "sleep", sleep)
    admission = rate.SharedAdmission(tmp_path)
    with pytest.raises(TimeoutError):
        admission.wait(deadline=102.)
    assert json.loads((tmp_path / "admission.json").read_text())["last_start_monotonic"] == 99.


def test_expired_wait_never_starts_a_network_admission(tmp_path):
    admission = rate.SharedAdmission(tmp_path)
    with pytest.raises(TimeoutError):
        admission.wait(deadline=rate.time.monotonic() - 1.)
    assert not (tmp_path / "admission.json").exists()


@pytest.fixture
def mocked_transport(monkeypatch):
    clock, calls, admissions, sleeps = [100.], [], [], []

    def sleep(seconds):
        sleeps.append(seconds)
        clock[0] += seconds

    def admission(**kwargs):
        admissions.append(kwargs)
        return clock[0]

    monkeypatch.setattr(transport.time, "monotonic", lambda: clock[0])
    monkeypatch.setattr(transport.time, "sleep", sleep)
    monkeypatch.setattr(transport, "ADMISSION", SimpleNamespace(wait=admission))
    return SimpleNamespace(clock=clock, calls=calls, admissions=admissions, sleeps=sleeps)


def http_error(code=429, headers=None, body=b'{"error":"secret-value"}'):
    return urllib.error.HTTPError(
        "https://invalid.local", code, "test", headers or {}, io.BytesIO(body))


def request(readonly=True):
    return urllib.request.Request("https://invalid.local", method="GET" if readonly else "PUT")


@pytest.mark.parametrize("error_kind", ["http429", "http500", "timeout", "url", "bad_json"])
def test_create_mutation_is_never_automatically_retried(mocked_transport, monkeypatch, error_kind):
    state = mocked_transport

    def urlopen(*args, **kwargs):
        state.calls.append((args, kwargs))
        if error_kind.startswith("http"):
            raise http_error(int(error_kind[4:]))
        if error_kind == "timeout":
            raise TimeoutError("network")
        if error_kind == "url":
            raise urllib.error.URLError("network")
        return io.BytesIO(b"invalid-json")

    monkeypatch.setattr(transport.urllib.request, "urlopen", urlopen)
    with pytest.raises(Exception):
        transport.request_json(
            request(False), readonly=False, secret="secret-value", deadline=1000.)
    assert len(state.calls) == 1 and len(state.admissions) == 1 and state.sleeps == []


def test_readonly_retries_exactly_eight_before_typed_exhaustion(mocked_transport, monkeypatch):
    state = mocked_transport

    def urlopen(*args, **kwargs):
        state.calls.append((args, kwargs))
        raise http_error()

    monkeypatch.setattr(transport.urllib.request, "urlopen", urlopen)
    with pytest.raises(transport.ReadOnlyTransientError) as caught:
        transport.request_json(request(), readonly=True, secret="secret-value", deadline=1000.)
    assert "secret-value" not in str(caught.value)
    assert len(state.calls) == 8 and state.sleeps == [1., 2., 4., 8., 16., 30., 30.]


def test_new_bounded_read_operation_recovers_after_prior_eight_429s(mocked_transport, monkeypatch):
    state = mocked_transport

    def urlopen(*args, **kwargs):
        state.calls.append((args, kwargs))
        if len(state.calls) <= 9:
            raise http_error()
        return io.BytesIO(b'{"success":true}')

    monkeypatch.setattr(transport.urllib.request, "urlopen", urlopen)
    with pytest.raises(transport.ReadOnlyTransientError):
        transport.request_json(request(), readonly=True, secret="", deadline=1000.)
    result = transport.request_json(request(), readonly=True, secret="", deadline=1000.)
    assert result == {"success": True} and len(state.calls) == 10
    assert state.clock[0] < 1000.


def test_readonly_respects_larger_header_or_body_retry_after(mocked_transport, monkeypatch):
    state = mocked_transport

    def urlopen(*args, **kwargs):
        state.calls.append((args, kwargs))
        if len(state.calls) == 1:
            raise http_error(headers={"Retry-After": "3"}, body=b'{"retry_after":7}')
        return io.BytesIO(b'{"ok":true}')

    monkeypatch.setattr(transport.urllib.request, "urlopen", urlopen)
    result = transport.request_json(request(), readonly=True, secret="", deadline=1000.)
    assert result == {"ok": True}
    assert state.sleeps == [7.]


def test_deadline_bounds_retry_after_and_network_timeout(mocked_transport, monkeypatch):
    state = mocked_transport

    def urlopen(*args, **kwargs):
        state.calls.append((args, kwargs))
        raise http_error(headers={"Retry-After": "100"})

    monkeypatch.setattr(transport.urllib.request, "urlopen", urlopen)
    with pytest.raises(transport.ReadOnlyTransientError):
        transport.request_json(request(), readonly=True, secret="", deadline=102.)
    assert len(state.calls) == 1 and state.sleeps == []
    assert state.calls[0][1]["timeout"] <= 2.


@pytest.mark.parametrize("readonly", [False, True])
def test_admission_timeout_keeps_readonly_type_and_mutation_single_attempt(
    mocked_transport, monkeypatch, readonly,
):
    def failed_admission(**_kwargs):
        raise TimeoutError("shared admission busy")

    monkeypatch.setattr(transport, "ADMISSION", SimpleNamespace(wait=failed_admission))
    expected = transport.ReadOnlyTransientError if readonly else TimeoutError
    with pytest.raises(expected):
        transport.request_json(request(readonly), readonly=readonly, secret="", deadline=1000.)
    assert mocked_transport.calls == []


def test_nontransient_readonly_error_does_not_retry(mocked_transport, monkeypatch):
    state = mocked_transport

    def urlopen(*args, **kwargs):
        state.calls.append((args, kwargs))
        raise http_error(400)

    monkeypatch.setattr(transport.urllib.request, "urlopen", urlopen)
    with pytest.raises(RuntimeError) as caught:
        transport.request_json(request(), readonly=True, secret="", deadline=1000.)
    assert not isinstance(caught.value, transport.ReadOnlyTransientError)
    assert len(state.calls) == 1 and state.sleeps == []


def test_cleanup_context_sets_priority_only_inside_scope(mocked_transport, monkeypatch):
    monkeypatch.setattr(transport.urllib.request, "urlopen", lambda *_a, **_k: io.BytesIO(b"{}"))
    with transport.cleanup_priority():
        transport.request_json(request(False), readonly=False, secret="", deadline=1000.)
    transport.request_json(request(), readonly=True, secret="", deadline=1000.)
    assert mocked_transport.admissions[0]["cleanup"] is True
    assert mocked_transport.admissions[1]["cleanup"] is False


STAGE = Path(r"C:\Users\esenb\Documents\SoupResearch\kanana-30b-final-gpu-20261026-f14")


def boot_function(status, probe, lease_seconds=7200.):
    source = ast.parse((STAGE / "controller.py").read_text(encoding="utf-8"))
    function = next(node for node in source.body
                    if isinstance(node, ast.FunctionDef) and node.name == "wait_for_boot")
    current, receipts = [0.], []

    def sleep(seconds):
        current[0] += seconds

    namespace = {"time": SimpleNamespace(monotonic=lambda: current[0], time=lambda: current[0],
                                        sleep=sleep),
                 "_remaining": lambda _p: lease_seconds-current[0],
                 "cloud": SimpleNamespace(status=status, save=lambda *args: receipts.append(args)),
                 "probe_ssh_routes": probe}
    exec(compile(ast.Module(body=[function], type_ignores=[]), str(STAGE / "controller.py"),
                 "exec"), namespace)
    return namespace["wait_for_boot"], current, receipts


def test_paid_boot_survives_more_than_eight_transient_status_cycles():
    calls = [0]

    def status():
        calls[0] += 1
        if calls[0] <= 9:
            raise transport.ReadOnlyTransientError("429 read-only attempts exhausted")

    wait, current, receipts = boot_function(status, lambda _p: calls[0] >= 10)
    assert wait({}) is True and calls[0] == 10
    assert 0 < current[0] < 1800
    assert len(receipts) == 9 and all(row[1]["lease_kept_alive"] for row in receipts)


def test_paid_boot_has_a_real_deadline_and_preserves_recovery_reserve():
    def status():
        raise transport.ReadOnlyTransientError("429")

    wait, current, _ = boot_function(status, lambda _p: False, lease_seconds=650.)
    assert wait({}) is False and current[0] <= 50.
    wait, current, receipts = boot_function(status, lambda _p: False, lease_seconds=600.)
    assert wait({}) is False and current[0] == 0 and receipts == []


def test_nontransient_identity_or_numerical_errors_are_not_softened():
    def status():
        raise ValueError("wrong exact lease identity")

    wait, _, _ = boot_function(status, lambda _p: True)
    with pytest.raises(ValueError, match="wrong exact lease identity"):
        wait({})


def test_cached_exact_identity_route_can_recover_while_api_status_is_throttled():
    def status():
        raise transport.ReadOnlyTransientError("429")

    probes = []
    wait, current, _ = boot_function(status, lambda p: probes.append(p) or True)
    assert wait({"instance_id": 12}) is True
    assert probes == [{"instance_id": 12}] and current[0] == 0


def cloud_api_function(tmp_path, cleanup_scope=False, remaining=50.):
    source = ast.parse((STAGE / "cloud.py").read_text(encoding="utf-8"))
    function = next(node for node in source.body
                    if isinstance(node, ast.FunctionDef) and node.name == "api")
    key = tmp_path / "dummy-key"
    key.write_text("dummy-local-test-key")
    policy = {"created_unix": 0., "maximum_seconds": remaining}
    (tmp_path / "vast-rental.json").write_text(json.dumps(policy))
    calls = []

    def request_json(*args, **kwargs):
        calls.append((args, kwargs))
        return {"ok": True}

    namespace = {"ROOT": tmp_path, "KEY_FILE": key, "json": json, "urllib": urllib,
                 "time": SimpleNamespace(time=lambda: 0., monotonic=lambda: 100.),
                 "CLEANUP_SCOPE": SimpleNamespace(get=lambda: cleanup_scope),
                 "request_json": request_json}
    exec(compile(ast.Module(body=[function], type_ignores=[]), str(STAGE / "cloud.py"),
                 "exec"), namespace)
    return namespace["api"], calls


def test_live_cloud_create_never_uses_readonly_retry_classifier(tmp_path):
    api, calls = cloud_api_function(tmp_path)
    assert api("/api/v0/asks/123/", "PUT", {"label": "ours"}) == {"ok": True}
    assert len(calls) == 1 and calls[0][1]["readonly"] is False
    assert calls[0][1]["deadline"] == 150.


def test_readonly_inventory_is_bounded_by_actual_receipt_deadline(tmp_path):
    api, calls = cloud_api_function(tmp_path)
    api("/api/v1/instances/?limit=100")
    assert calls[0][1]["readonly"] is True and calls[0][1]["deadline"] == 150.


def test_exact_cleanup_still_allowed_after_financial_deadline(tmp_path):
    api, calls = cloud_api_function(tmp_path, cleanup_scope=True, remaining=-1.)
    api("/api/v0/instances/123/", "DELETE")
    assert calls[0][1]["cleanup"] is True
    assert calls[0][1]["deadline"] == 160. and calls[0][1]["readonly"] is False


def test_production_source_private_wrapper_and_numerical_protocol_unchanged():
    old = STAGE.with_name("kanana-30b-final-gpu-20261026-f11")
    for name in ("source.tar.gz", "source-manifest.json", "final_comparison.py", "constraints.txt"):
        assert hashlib.sha256((STAGE / name).read_bytes()).digest() == hashlib.sha256(
            (old / name).read_bytes()).digest()
    protocol = json.loads((STAGE / "protocol.json").read_text())
    previous = json.loads((old / "protocol.json").read_text())
    changed = {key for key in protocol if protocol[key] != previous.get(key)}
    assert changed == {"stage_id", "financial", "checkpoint_input_integrity"}
    assert protocol["checkpoint_input_integrity"]["official_sha256_required"] is True
    assert protocol["checkpoint_input_integrity"]["fresh_bad_shard_redownload_global_limit"] == 2
    assert protocol["checkpoint_input_integrity"]["full_final_recheck_required"] is True
    assert protocol["source_commit"] == "43cf0b34afe0d8850d76bf86d60663ab5c85cdb2"
    assert protocol["financial"]["maximum_stage_usd"] == 3.
    assert protocol["financial"]["maximum_seconds"] == 14400
    context = json.loads((STAGE / "prior-budget-context.json").read_text())
    expected = (context["prior_remaining_usd"] + context["new_authorized_usd"]
                - context["failed_f10_cost_usd"] - context["failed_f11_cost_usd"]
                - context["failed_f12_cost_usd"] - context["failed_f13_cost_usd"])
    assert context["aggregate_remaining_before_f14_usd"] == pytest.approx(expected)
    assert context["new_stage_cap_usd"] <= expected
    assert context["active_sibling_reservation_usd"] == 0


def attachment_function(tmp_path, actions, lease_seconds=7200.):
    source = ast.parse((STAGE / "controller.py").read_text(encoding="utf-8"))
    function = next(node for node in source.body
                    if isinstance(node, ast.FunctionDef) and node.name == "attach_frozen_ssh_key")
    current, calls, receipts = [0.], [], []
    policy = {"instance_id": 12, "label": "soup-test", "stage_id": "soup-test",
              "maximum_usd": 3., "source_sha256": "a" * 64}
    receipt = dict(policy)
    key = tmp_path / "ssh-key"
    public_path = key.with_suffix(".pub")
    public = b"ssh-ed25519 AAAA-original-public-fixture\n"
    public_path.write_bytes(public)
    manifest = {"files": {"ssh-key.pub": {
        "bytes": len(public), "sha256": hashlib.sha256(public).hexdigest()}}}

    def api(*args):
        calls.append(args)
        action = actions[min(len(calls)-1, len(actions)-1)]
        if callable(action):
            return action(receipt, public_path)
        if isinstance(action, Exception):
            raise action
        return action

    def sleep(seconds):
        current[0] += seconds

    namespace = {"hashlib": hashlib,
                 "time": SimpleNamespace(monotonic=lambda: current[0], sleep=sleep),
                 "_remaining": lambda _p: lease_seconds-current[0],
                 "cloud": SimpleNamespace(LABEL="soup-test", STAGE="soup-test", MAXIMUM_USD=3.,
                    SSH_KEY=key, receipt=lambda: dict(receipt), api=api,
                    save=lambda *args: receipts.append(args))}
    exec(compile(ast.Module(body=[function], type_ignores=[]), str(STAGE / "controller.py"),
                 "exec"), namespace)
    return SimpleNamespace(run=namespace["attach_frozen_ssh_key"], policy=policy,
        manifest=manifest, public_path=public_path, calls=calls, receipts=receipts, clock=current)


def test_exact_frozen_public_key_attachment_recovers_only_explicit_429(tmp_path):
    fixture = attachment_function(tmp_path, [transport.MutationRateLimitRefusalError("429", 3.),
                                             {"success": True}])
    result = fixture.run(fixture.policy, fixture.manifest)
    assert result["success"] is True and result["attempts"] == 2
    assert fixture.clock[0] == 3.
    assert fixture.calls[0] == fixture.calls[1]
    assert fixture.calls[0][0] == "/api/v0/instances/12/ssh/"
    assert fixture.calls[0][1] == "POST"
    assert fixture.calls[0][2] == {"ssh_key": "ssh-ed25519 AAAA-original-public-fixture"}


@pytest.mark.parametrize("change", ["key", "receipt"])
def test_attachment_refuses_any_replacement_key_or_lease_after_429(tmp_path, change):
    def mutate(receipt, public_path):
        if change == "key":
            public_path.write_bytes(b"ssh-ed25519 replacement-public-key-extra-bytes\n")
        else:
            receipt["instance_id"] = 34
        raise transport.MutationRateLimitRefusalError("429", 1.)

    fixture = attachment_function(tmp_path, [mutate, {"success": True}])
    with pytest.raises(ValueError):
        fixture.run(fixture.policy, fixture.manifest)
    assert len(fixture.calls) == 1


@pytest.mark.parametrize("field,value", [("instance_id", 0), ("instance_id", True),
    ("label", "colleague"), ("stage_id", "other-stage"), ("maximum_usd", 4.)])
def test_attachment_refuses_non_owned_or_changed_policy_before_any_mutation(tmp_path, field, value):
    fixture = attachment_function(tmp_path, [{"success": True}])
    fixture.policy[field] = value
    with pytest.raises(ValueError):
        fixture.run(fixture.policy, fixture.manifest)
    assert fixture.calls == []


def test_attachment_refuses_unfrozen_public_key_before_any_mutation(tmp_path):
    fixture = attachment_function(tmp_path, [{"success": True}])
    fixture.manifest["files"]["ssh-key.pub"]["sha256"] = "b" * 64
    with pytest.raises(ValueError):
        fixture.run(fixture.policy, fixture.manifest)
    assert fixture.calls == []


@pytest.mark.parametrize("action", [RuntimeError("HTTP500"), TimeoutError("unknown outcome"),
                                   {"success": False}])
def test_attachment_never_retries_ambiguous_or_non_429_errors(tmp_path, action):
    fixture = attachment_function(tmp_path, [action, {"success": True}])
    with pytest.raises((RuntimeError, TimeoutError)):
        fixture.run(fixture.policy, fixture.manifest)
    assert len(fixture.calls) == 1 and fixture.clock[0] == 0


def test_attachment_has_eight_attempt_and_300_second_deadline_limits(tmp_path):
    fixture = attachment_function(tmp_path, [transport.MutationRateLimitRefusalError("429", 0.)])
    with pytest.raises(transport.MutationRateLimitRefusalError):
        fixture.run(fixture.policy, fixture.manifest)
    assert len(fixture.calls) == 8 and fixture.clock[0] < 300.
    fixture = attachment_function(tmp_path, [transport.MutationRateLimitRefusalError("429", 301.)])
    with pytest.raises(TimeoutError):
        fixture.run(fixture.policy, fixture.manifest)
    assert len(fixture.calls) == 1 and fixture.clock[0] == 0


def test_attachment_preserves_600_second_result_recovery_reserve(tmp_path):
    fixture = attachment_function(tmp_path, [{"success": True}], lease_seconds=600.)
    with pytest.raises(TimeoutError):
        fixture.run(fixture.policy, fixture.manifest)
    assert fixture.calls == []
