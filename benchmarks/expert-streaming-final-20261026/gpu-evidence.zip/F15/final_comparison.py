"""Private ordinary-vs-complete Kanana30B qualifier; never rents resources.

Imports the frozen public qualifier unchanged, retaining its three complete
accuracy trajectories and original tolerances. Only the timing contrast changes.
The delegated child command points back to this hash-bound private wrapper.
"""

from __future__ import annotations

import argparse
import math
import random
import statistics
import sys
from pathlib import Path
from typing import Any

SOURCE_COMMIT = "43cf0b34afe0d8850d76bf86d60663ab5c85cdb2"
VARIANTS = ("ordinary_legacy", "grouped")
ORDERS = (VARIANTS, tuple(reversed(VARIANTS))) * 2
QUALIFIER: Any = None


def configure(source_root: Path) -> Any:
    """Keep native source immutable, bind all child workers to this wrapper."""
    global QUALIFIER
    sys.path[:0] = [str(source_root / "src"), str(source_root)]
    from benchmarks.harness import expert_cache_dispatch_qualification as public

    if QUALIFIER is None:
        original_save = public.save

        def save(path: Path, value: Any) -> None:
            if path.name == "run.json" and isinstance(value, dict):
                value["hypothesis"] = "ordinary streaming versus grouped two-read RAM/GPU caches"
                value["timing_contrast"] = list(VARIANTS)
                value["private_wrapper_sha256"] = public.digest(Path(__file__))
            original_save(path, value)

        public.save = save
    public.__file__ = __file__
    public.VARIANTS = VARIANTS
    public.ORDERS = ORDERS
    public.timing_summary = timing_summary
    QUALIFIER = public
    return public


def timing_summary(blocks: list[dict[str, Any]], common: Any) -> dict[str, Any]:
    q = QUALIFIER
    require = q.require
    require(common.RTOL == .01 and common.ATOL == 1e-5, "Original tolerances changed")
    require(len(blocks) == 8, "Exactly eight complete timing blocks are required")
    seen, pids, identities, by_round = set(), set(), set(), {}
    loss_checks, counter_checks = [], []
    for block in blocks:
        number, position, variant = block["round"], block["position"], block["variant"]
        require(type(number) is int and 0 <= number < 4 and type(position) is int
                and 0 <= position < 2 and ORDERS[number][position] == variant
                and (number, variant) not in seen, "Unbalanced/duplicate timing schedule")
        seen.add((number, variant))
        result = block["result"]
        raw, envelope = result["worker"], result["envelope"]
        require(raw["arm"] == result["native_arm"] == envelope["native_arm"]
                == q.NATIVE_ARMS[variant]
                and result["variant"] == envelope["variant"] == variant
                and raw["phase"] == envelope["phase"] == "timing"
                and raw["status"] == envelope["status"] == "passed"
                and type(raw["pid"]) is int and raw["pid"] > 0
                and raw["pid"] == envelope["pid"] and raw["pid"] not in pids,
                "Native arm/envelope/fresh-process identity changed")
        q.validate_dispatch_evidence(envelope["dispatch"], variant)
        q.validate_native_routes(raw, variant)
        require(raw["spec_sha256"] == envelope["spec_sha256"], "Native/envelope spec differs")
        identities.add(tuple(envelope[key] for key in (
            "spec_sha256", "source_commit", "expert_module_sha256", "constructor_source_sha256",
            "runtime_module_sha256", "wrapper_sha256")))
        require(envelope["source_commit"] == SOURCE_COMMIT, "Unexpected production source")
        pids.add(raw["pid"])
        for stage, count in (("warmup", 2), ("timing", 6)):
            data = raw[stage]
            require(data.get("complete") is True and data.get("updates_complete") == count
                    and data.get("finite_state_checks_per_update") is True
                    and len(data.get("update_seconds", [])) == len(data.get("losses", [])) == count
                    and all(type(value) in (int, float) and math.isfinite(value) and value > 0
                            for value in data["update_seconds"]), "Incomplete finite timing block")
            q.cache_delta(raw, stage, cached=variant == "grouped")
        by_round.setdefault(number, {})[variant] = block
    require(len(identities) == 1, "Timing workers did not use one frozen source/spec")
    logs = []
    for number in range(4):
        base, candidate = (by_round[number][variant]["result"]["worker"]
                           for variant in VARIANTS)
        logs.append(math.log(statistics.median(candidate["timing"]["update_seconds"])
                             / statistics.median(base["timing"]["update_seconds"])))
        for stage in ("warmup", "timing"):
            gate = q.loss_gate(base[stage]["losses"], candidate[stage]["losses"], common)
            require(gate["passed"], "Recorded warmup/timed numerical loss gate failed")
            loss_checks.append({"round": number, "stage": stage, **gate})
            left = q.cache_delta(base, stage, cached=False)
            right = q.cache_delta(candidate, stage, cached=True)
            require(left["logical_fetches"] * 2 == right["logical_fetches"] * 3,
                    "Ordinary three-read versus complete two-read schedule changed")
            counter_checks.append({"round": number, "stage": stage,
                                   "three_to_two_logical_reads": True,
                                   "reference": left, "candidate": right})
    rng = random.Random(29)
    draws = sorted(100 * (1 - math.exp(statistics.mean(rng.choices(logs, k=4))))
                   for _ in range(5000))
    lower, upper = draws[124], draws[4874]
    absolute = {}
    for variant in VARIANTS:
        rows = [block["result"] for block in blocks if block["variant"] == variant]
        absolute[variant] = {
            "median_step_seconds": statistics.median(
                value for row in rows for value in row["worker"]["timing"]["update_seconds"]),
            "median_setup_seconds": statistics.median(row["worker"]["setup"]["seconds"]
                                                       for row in rows),
            "median_whole_entry_seconds": statistics.median(
                row["fresh_process_wall_seconds"] for row in rows),
            "max_step_allocated_bytes": max(row["worker"]["timing"]["cuda"][
                "peak_allocated_bytes"] for row in rows),
            "max_step_reserved_bytes": max(row["worker"]["timing"]["cuda"][
                "peak_reserved_bytes"] for row in rows),
            "max_sampled_timing_rss_bytes": max(row["worker"]["timing"]["resources"][
                "sampled_peak_rss_bytes"] for row in rows),
        }
    return {
        "reference_variant": VARIANTS[0], "candidate_variant": VARIANTS[1],
        "native_arms": {name: q.NATIVE_ARMS[name] for name in VARIANTS}, "paired_rounds": 4,
        "step_time_reduction_percent": 100 * (1 - math.exp(statistics.mean(logs))),
        "throughput_increase_percent": 100 * (math.exp(-statistics.mean(logs)) - 1),
        "paired_bootstrap_95_percent": [lower, upper],
        "passes_practical_2_percent_gate": lower >= 2., "bootstrap_samples": 5000,
        "bootstrap_seed": 29, "absolute": absolute,
        "recorded_loss_gates": loss_checks, "read_schedule_checks": counter_checks,
        "recording_limits": ["NO VERDICT for unrecorded first timed microbatch loss.",
                             "Full gradients/AdamW states cover the separate accuracy phase.",
                             "Frozen random tokens; downstream quality/convergence unmeasured.",
                             "Shared download and NF4 preparation excluded from whole entry."]}


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--source-commit", required=True)
    args, _ = parser.parse_known_args(argv)
    if args.source_commit != SOURCE_COMMIT:
        raise ValueError("Frozen production source differs")
    return configure(args.source_root).main(argv)


if __name__ == "__main__":
    raise SystemExit(main())
