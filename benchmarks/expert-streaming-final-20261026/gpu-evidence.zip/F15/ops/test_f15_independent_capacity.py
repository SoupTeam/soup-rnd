"""Independent disk-plan refusal controls; no GPU/provider/network access."""

import ast
import copy
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

import audit_final_infrastructure as infra
import pytest

STAGE = Path(r"C:\Users\esenb\Documents\SoupResearch\kanana-30b-final-gpu-20261026-f15")


def fixture():
    plan = json.loads((STAGE / "protocol.json").read_text())["storage_capacity_plan"]
    before = {"passed": True, "root_free_bytes": 16 * infra.GIB,
              "data_free_bytes": 100 * infra.GIB, "minimum_root_bytes": 16 * infra.GIB,
              "minimum_data_bytes": 100 * infra.GIB, "unix": 1.}
    after = {**before, "minimum_data_bytes": plan["minimum_pre_prepare_data_free_bytes"],
             "data_free_bytes": plan["minimum_pre_prepare_data_free_bytes"], "unix": 2.,
             "capacity_plan_sha256": hashlib.sha256(json.dumps(plan, sort_keys=True,
                 separators=(",", ":")).encode()).hexdigest()}
    return plan, before, after


def test_exact_per_filesystem_budget_is_consistent_and_outputs_retain_twelve_gib():
    plan, before, after = fixture()
    summary = infra.storage_capacity(plan, before, after)
    assert summary["root_worst_case_bytes"] == 16632385536 < 16 * infra.GIB
    assert summary["data_worst_case_bytes"] == 90731222941 < 100 * infra.GIB
    assert summary["minimum_remaining_before_nf4_bytes"] == 29387287853
    assert plan["root_components_bytes"]["raw_outputs_reserve"] == 12 * infra.GIB
    assert "raw_outputs_reserve" not in plan["data_components_bytes"]
    assert plan["root_provider_gb"] + plan["volume_provider_gb"] == 144 <= 146


@pytest.mark.parametrize("change", ["root_layout", "volume_layout", "root_floor", "data_floor",
    "raw_reserve", "wrong_filesystem", "pre_root_short", "pre_data_short", "nf4_root_short",
    "nf4_data_short", "wrong_plan_hash", "provider_unit_assumption"])
def test_layout_or_actual_capacity_changes_are_refused(change):
    plan, before, after = fixture()
    if change == "root_layout":
        plan["root_provider_gb"] = 24
    elif change == "volume_layout":
        plan["volume_provider_gb"] = 120
    elif change == "root_floor":
        plan["minimum_pre_download_root_free_bytes"] = 8 * infra.GIB
    elif change == "data_floor":
        plan["minimum_pre_download_data_free_bytes"] -= 1
    elif change == "raw_reserve":
        plan["root_components_bytes"]["raw_outputs_reserve"] -= 1
    elif change == "wrong_filesystem":
        plan["output_filesystem"] = "data"
    elif change == "pre_root_short":
        before["root_free_bytes"] -= 1
    elif change == "pre_data_short":
        before["data_free_bytes"] -= 1
    elif change == "nf4_root_short":
        after["root_free_bytes"] -= 1
    elif change == "nf4_data_short":
        after["data_free_bytes"] -= 1
    elif change == "wrong_plan_hash":
        after["capacity_plan_sha256"] = "a" * 64
    else:
        plan["provider_gb_to_gib_conversion_assumed"] = True
    with pytest.raises(ValueError):
        infra.storage_capacity(plan, before, after)


def gate(name, root_free, data_free):
    source = ast.parse((STAGE / "remote_run.py").read_text())
    node = next(item for item in source.body
                if isinstance(item, ast.FunctionDef) and item.name == name)
    receipts = []
    namespace = {"ROOT": Path("/root/liger"), "OUT": Path("/root/liger/results"),
        "SOURCE_BYTES": 61343935088, "json": json, "hashlib": hashlib,
        "time": SimpleNamespace(time=lambda: 1.), "save": lambda *args: receipts.append(args),
        "shutil": SimpleNamespace(disk_usage=lambda path: SimpleNamespace(
            free=data_free if str(path) == "/data" else root_free))}
    exec(compile(ast.Module(body=[node], type_ignores=[]), str(STAGE / "remote_run.py"), "exec"),
         namespace)
    return namespace[name], receipts


def test_actual_remote_gates_enforce_both_filesystems_before_download_and_before_nf4():
    plan, _, _ = fixture()
    pre, _ = gate("pre_download_disk_gate", 16 * infra.GIB, 100 * infra.GIB)
    assert pre()["passed"] is True
    for root, data in ((16 * infra.GIB-1, 100 * infra.GIB),
                       (16 * infra.GIB, 100 * infra.GIB-1)):
        pre, receipts = gate("pre_download_disk_gate", root, data)
        with pytest.raises(RuntimeError):
            pre()
        assert receipts[-1][1]["passed"] is False
    after, _ = gate("pre_prepare_disk_gate", 16 * infra.GIB,
                    plan["minimum_pre_prepare_data_free_bytes"])
    assert after({"storage_capacity_plan": plan})["passed"] is True
    after, receipts = gate("pre_prepare_disk_gate", 16 * infra.GIB-1,
                           plan["minimum_pre_prepare_data_free_bytes"])
    with pytest.raises(RuntimeError):
        after({"storage_capacity_plan": plan})
    assert receipts[-1][1]["passed"] is False


def test_actual_full_host_pool_check_accepts_146_but_refuses_less_than_144():
    source = ast.parse((STAGE / "cloud.py").read_text())
    node = next(item for item in source.body
                if isinstance(item, ast.FunctionDef) and item.name == "validate_full_host")
    namespace = {"DISK_GB": 32, "VOLUME_GB": 112}
    exec(compile(ast.Module(body=[node], type_ignores=[]), str(STAGE / "cloud.py"), "exec"),
         namespace)
    offer = {"num_gpus": 1, "gpu_frac": 1., "gpu_ram": 8188, "cpu_ram": 30470,
             "compute_cap": 890, "disk_space": 146.}
    assert namespace["validate_full_host"](offer) is True
    offer["disk_space"] = 143.99
    with pytest.raises(ValueError):
        namespace["validate_full_host"](offer)


def test_failed_f14_swap_boundary_is_still_rejected_by_new_v5_auditor():
    root = STAGE.with_name("kanana-30b-final-gpu-20261026-f14") / "retained/results"
    path = root / "dispatch-qualification/accuracy/ordinary_legacy/result.json"
    raw = json.loads(path.read_text())
    proof = json.loads((root / "capacity-preflight.json").read_text())
    spec = json.loads((root / "prepared/spec.json").read_text())
    assert raw["accuracy"]["resources"]["sampled_peak_cgroup_swap_bytes"] > 0
    with pytest.raises(ValueError):
        infra.worker_boundary(raw, proof, spec)


def test_storage_change_preserves_all_original_memory_and_numerical_inputs():
    old = STAGE.with_name("kanana-30b-final-gpu-20261026-f14")
    for name in ("source.tar.gz", "source-manifest.json", "final_comparison.py",
                 "checkpoint_integrity.py", "constraints.txt"):
        assert hashlib.sha256((STAGE / name).read_bytes()).digest() == hashlib.sha256(
            (old / name).read_bytes()).digest()
    before = json.loads((old / "protocol.json").read_text())
    after = json.loads((STAGE / "protocol.json").read_text())
    assert before["performance"] == after["performance"]
    assert before["checkpoint_input_integrity"] == after["checkpoint_input_integrity"]
    boundary = copy.deepcopy(after["native_boundary"])
    boundary["minimum_root_free_bytes"] = before["native_boundary"]["minimum_root_free_bytes"]
    boundary["minimum_data_free_bytes"] = before["native_boundary"]["minimum_data_free_bytes"]
    assert boundary == before["native_boundary"]
