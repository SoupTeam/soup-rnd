"""Independent retained-artifact audit for the final ordinary/grouped contrast.

Does not rent resources or accept reported speed/accuracy flags as evidence.
Numerical trajectory comparison uses the unchanged native comparator. Timing
and read-schedule calculations are independently implemented here.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import random
import statistics
import sys
from pathlib import Path
from typing import Any

SOURCE = "43cf0b34afe0d8850d76bf86d60663ab5c85cdb2"
ARMS = {"ordinary_legacy": "ordinary", "legacy": "two_read_cache",
        "grouped": "two_read_cache"}
VARIANTS = ("ordinary_legacy", "grouped")
ORDERS = (VARIANTS, tuple(reversed(VARIANTS))) * 2


def check(condition: Any, message: str) -> None:
    if not condition:
        raise ValueError(message)


def sha(path: Path) -> str:
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 2**20), b""):
            result.update(chunk)
    return result.hexdigest()


def read(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def loss_gate(left: list[float], right: list[float]) -> None:
    check(left and len(left) == len(right), "Incomplete scalar loss sequence")
    check(all(type(a) in (int, float) and type(b) in (int, float)
              and math.isfinite(a) and math.isfinite(b)
              and abs(a-b) <= 1e-5 + .01 * abs(a) and f"{a:.3f}" == f"{b:.3f}"
              for a, b in zip(left, right)), "Original scalar loss gate failed")


def counters(raw: dict[str, Any], phase: str, cached: bool) -> dict[str, int]:
    stage = raw[phase]
    before, after = [stage[key]["expert_cache"] for key in ("runtime_before", "runtime_after")]
    delta = {key: after[key] - before[key] for key in (
        "logical_fetches", "storage_reads", "storage_bytes_read", "materializations")}
    for tier, cap in (("host", 8 * 2**30), ("device", 2 * 2**30)):
        for snapshot in (before, after):
            check(snapshot[tier]["budget_bytes"] == (cap if cached else 0)
                  and 0 <= snapshot[tier]["payload_bytes"] <= (cap if cached else 0),
                  "Per-arm cache payload/ceiling changed")
        delta[tier + "_hits"] = after[tier]["hits"] - before[tier]["hits"]
    check(all(type(value) is int and value >= 0 for value in delta.values())
          and min(delta[key] for key in ("logical_fetches", "storage_reads",
                                        "storage_bytes_read")) > 0,
          "Invalid expert counters")
    check(delta["logical_fetches"] == sum(delta[key] for key in (
        "storage_reads", "host_hits", "device_hits"))
        and delta["materializations"] == delta["logical_fetches"] - delta["device_hits"],
        "Expert counter accounting failed")
    if cached:
        check(before["host_cache_policy"] == after["host_cache_policy"] == "static"
              and min(delta["host_hits"], delta["device_hits"]) > 0,
              "Both candidate cache tiers must be exercised")
        plan = raw["setup"]["cache_plan"]
        check(plan["host_cache_bytes"] == 8 * 2**30
              and plan["device_cache_bytes"] == 2 * 2**30
              and plan["host_cache_policy"] == "static", "Candidate cache plan changed")
    else:
        check(delta["host_hits"] == delta["device_hits"] == 0, "Baseline used caches")
    return delta


def validate_worker(result: dict[str, Any], variant: str, phase: str) -> None:
    raw, env = result["worker"], result["envelope"]
    check(raw["arm"] == env["native_arm"] == result["native_arm"] == ARMS[variant]
          and result["variant"] == env["variant"] == variant
          and raw["phase"] == env["phase"] == phase
          and raw["status"] == env["status"] == "passed"
          and type(raw["pid"]) is int and raw["pid"] > 0 and raw["pid"] == env["pid"]
          and raw["spec_sha256"] == env["spec_sha256"]
          and env["source_commit"] == SOURCE, "Worker identity/arm changed")
    enabled = variant == "grouped"
    flags = {str(index): enabled for index in range(1, 48)}
    proof = env["dispatch"]
    check(proof["mode"] == ("grouped_constructor" if enabled else "legacy_constructor")
          and proof["grouped_expert_routes"] is enabled and proof["factory_calls"] == 1
          and proof["factory_restored"] is True and len(proof["build_proofs"]) == 1,
          "Constructor dispatch evidence changed")
    evidence = proof["build_proofs"][0]
    check(evidence["checked_before_cache_admission"] is True and evidence["expert_modules"] == 47
          and evidence["actual_expert_grouped_routes"] == flags
          and evidence["runtime_expert_grouped_routes"] == flags,
          "Constructed expert flags changed")
    for stage in ("setup", "accuracy", "warmup", "timing"):
        for point in ("runtime_before", "runtime_after"):
            if point in raw.get(stage, {}):
                actual = raw[stage][point]["expert_grouped_routes"]
                check(actual == flags and all(type(v) is bool for v in actual.values()),
                      "Native route flags changed")


def recompute_timing(blocks: list[dict[str, Any]]) -> dict[str, Any]:
    check(len(blocks) == 8, "Eight fresh balanced timing workers are required")
    pids, seen, identities, pairs = set(), set(), set(), {}
    for block in blocks:
        number, position, variant = block["round"], block["position"], block["variant"]
        check(type(number) is int and 0 <= number < 4 and type(position) is int
              and 0 <= position < 2 and ORDERS[number][position] == variant
              and (number, variant) not in seen, "Timing order is not balanced AB/BA")
        seen.add((number, variant))
        result = block["result"]
        validate_worker(result, variant, "timing")
        raw, env = result["worker"], result["envelope"]
        check(raw["pid"] not in pids, "Timing worker reused a process")
        pids.add(raw["pid"])
        identities.add(tuple(env[key] for key in (
            "source_commit", "spec_sha256", "wrapper_sha256", "expert_module_sha256",
            "runtime_module_sha256", "constructor_source_sha256")))
        for phase, expected in (("warmup", 2), ("timing", 6)):
            stage = raw[phase]
            check(stage["complete"] is True and stage["updates_complete"] == expected
                  and stage["finite_state_checks_per_update"] is True
                  and len(stage["update_seconds"]) == len(stage["losses"]) == expected
                  and all(type(value) in (int, float) and math.isfinite(value) and value > 0
                          for value in stage["update_seconds"]), "Incomplete finite timing phase")
            counters(raw, phase, variant == "grouped")
        pairs.setdefault(number, {})[variant] = raw
    check(len(identities) == 1, "Timing source/spec differs between workers")
    logs = []
    for pair in pairs.values():
        base, candidate = pair[VARIANTS[0]], pair[VARIANTS[1]]
        for phase in ("warmup", "timing"):
            loss_gate(base[phase]["losses"], candidate[phase]["losses"])
            left, right = counters(base, phase, False), counters(candidate, phase, True)
            check(left["logical_fetches"] * 2 == right["logical_fetches"] * 3,
                  "Logical expert reads do not follow three-read versus two-read")
        logs.append(math.log(statistics.median(candidate["timing"]["update_seconds"])
                             / statistics.median(base["timing"]["update_seconds"])))
    generator = random.Random(29)
    distribution = sorted(100 * (1 - math.exp(statistics.mean(generator.choices(logs, k=4))))
                          for _ in range(5000))
    return {"step_time_reduction_percent": 100 * (1-math.exp(statistics.mean(logs))),
            "throughput_increase_percent": 100 * (math.exp(-statistics.mean(logs))-1),
            "paired_bootstrap_95_percent": [distribution[124], distribution[4874]],
            "passes_practical_2_percent_gate": distribution[124] >= 2.}


def audit(stage: Path, source_root: Path) -> dict[str, Any]:
    import torch

    sys.path[:0] = [str(source_root / "src"), str(source_root)]
    from benchmarks.harness import expert_cache_dispatch_qualification as q
    from benchmarks.harness import two_read_cache_common as common

    check(common.RTOL == .01 and common.ATOL == 1e-5, "Original tolerances changed")
    manifest = read(stage / "archive-manifest.json")
    root = stage / "retained"
    verified = 0

    def file(name: str) -> Path:
        nonlocal verified
        row = manifest["files"][name]
        path = root / name
        check(path.stat().st_size == row["bytes"] and sha(path) == row["sha256"],
              "Manifested artifact changed: " + name)
        verified += 1
        return path

    check(manifest["source_commit"] == SOURCE, "Retained production source changed")
    spec_path = file("results/prepared/spec.json")
    spec = read(spec_path)
    q.validate_protocol(spec)
    inputs_path = file("results/prepared/inputs.pt")
    check(sha(inputs_path) == spec["training_data_sha256"], "Frozen input SHA changed")
    inputs = torch.load(inputs_path, map_location="cpu", weights_only=True)
    check(inputs.dtype == torch.long and tuple(inputs.shape) == (4, 1, 512), "Input recipe changed")
    prefix = "results/dispatch-qualification"
    run = read(file(prefix + "/run.json"))
    check(run["status"] == "completed" and run["accuracy_passed"] is True
          and run["source_commit"] == SOURCE and run["spec_sha256"] == sha(spec_path)
          and run["timing_contrast"] == list(VARIANTS)
          and run["original_gates"] == {"reference_relative_rtol": .01, "atol": 1e-5,
                                         "loss_three_decimal": True, "finite": True},
          "Completed run does not describe the final contrast/original gates")
    wrapper = Path(__file__).with_name("final_comparison.py")
    check(run["private_wrapper_sha256"] == sha(wrapper), "Private executed wrapper changed")
    pids, identity, captures, losses, accuracy_counters, gates = set(), None, {}, {}, {}, {}

    def worker(directory: str, variant: str, phase: str) -> dict[str, Any]:
        nonlocal identity
        result = read(file(directory + "/controller-result.json"))
        raw_path = file(directory + "/result.json")
        env_path = file(directory + "/dispatch-envelope.json")
        raw, env = read(raw_path), read(env_path)
        check(raw == result["worker"] and env == result["envelope"]
              and result["envelope_sha256"] == sha(env_path)
              and env["native_result_sha256"] == sha(raw_path)
              and env["wrapper_sha256"] == sha(wrapper)
              and env["spec_sha256"] == sha(spec_path), "Worker raw/envelope bytes differ")
        validate_worker(result, variant, phase)
        check(raw["pid"] not in pids, "Accuracy/timing process reused")
        pids.add(raw["pid"])
        current = tuple(env[key] for key in (
            "source_commit", "spec_sha256", "wrapper_sha256", "expert_module_sha256",
            "runtime_module_sha256", "constructor_source_sha256"))
        if identity is None:
            identity = current
        check(current == identity, "Source/spec differ across accuracy/timing")
        return result

    for variant in ("ordinary_legacy", "legacy", "grouped"):
        directory = prefix + "/accuracy/" + variant
        result = worker(directory, variant, "accuracy")
        check(result == run["accuracy"][variant]["result"], "Recorded accuracy cell differs")
        capture_path = file(directory + "/capture.pt")
        check(sha(capture_path) == result["worker"]["accuracy"]["capture_sha256"],
              "Complete accuracy capture SHA changed")
        capture = torch.load(capture_path, map_location="cpu", weights_only=True)
        controls = q.full_capture_controls(capture, inputs, common)
        check(controls == run["accuracy"][variant]["capture_controls"], "Capture controls differ")
        losses[variant] = controls["full_microbatch_losses"]
        accuracy_counters[variant] = counters(
            result["worker"], "accuracy", variant != "ordinary_legacy")
        captures[variant] = capture
    check(accuracy_counters["legacy"] == accuracy_counters["grouped"]
          and accuracy_counters["ordinary_legacy"]["logical_fetches"] * 2
          == accuracy_counters["grouped"]["logical_fetches"] * 3,
          "Accuracy read schedule/cache accounting changed")
    for left, right in (("ordinary_legacy", "legacy"), ("ordinary_legacy", "grouped"),
                        ("legacy", "grouped")):
        gate = common.compare_captures(captures[left], captures[right])
        check(gate["passed"], "Original full numerical trajectory gate failed")
        gates[left + "_vs_" + right] = gate
    del captures
    for block in run["timing_blocks"]:
        variant = block["variant"]
        directory = prefix + f"/timing/round-{block['round']:02d}/" + variant
        result = worker(directory, variant, "timing")
        check(result == block["result"], "Recorded timing cell differs")
        loss_gate(losses[variant][1::2], result["worker"]["warmup"]["losses"])
    recomputed = recompute_timing(run["timing_blocks"])
    check(all(run["timing_summary"][key] == value for key, value in recomputed.items()),
          "Reported timing summary differs from independent recomputation")
    check(len(pids) == 11, "Exactly eleven fresh accuracy/timing workers are required")
    return {"status": "passed_independent_final_numerical_timing_audit",
            "verified_artifact_reads": verified, "workers": len(pids),
            "accuracy_gates": gates, "timing_recomputed": recomputed,
            "scope": ("retained numerical/timing artifacts; "
                      "infrastructure/billing separately audited"),
            "recording_limits": run["timing_summary"]["recording_limits"]}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", type=Path, required=True)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    report = audit(args.stage, args.source_root)
    args.out.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    from rich.console import Console

    Console().print({"status": report["status"], "out": str(args.out)})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
