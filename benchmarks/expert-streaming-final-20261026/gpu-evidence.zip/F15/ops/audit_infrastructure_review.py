"""CPU refusal controls for native-boundary, retention and cleanup claims."""

import copy
import json
import xml.etree.ElementTree as ET
from pathlib import Path

import audit_final_infrastructure as infra
import pytest


def capacity_fixture():
    return {"passed": True, "container_id": "12", "gpu_memory_mib": 8192,
            "gpu_name": "NVIDIA GeForce RTX 3070", "gpu_uuid": "GPU-test",
            "native_ram_limit_bytes": 30 * infra.GIB,
            "memory_constraints": [{"memory.max": 30 * infra.GIB,
                                    "memory.swap.max": 0, "memory.swap.current": 0}],
            "host_meminfo": {"MemTotal": 32 * infra.GIB, "SwapTotal": infra.GIB},
            "data_free_bytes": 150 * infra.GIB, "root_free_bytes": 64 * infra.GIB}


def test_native_capacity_requires_actual_gpu_and_ram_bound():
    infra.capacity(capacity_fixture(), {"instance_id": 12})


@pytest.mark.parametrize("change", ["gpu", "ram", "swap_used", "swap_enabled", "identity",
                                   "false_pass", "fake_bound", "disk", "root"])
def test_native_capacity_refuses_changed_boundaries(change):
    proof = capacity_fixture()
    if change == "gpu":
        proof["gpu_memory_mib"] = 24576
    elif change == "ram":
        proof["native_ram_limit_bytes"] = 64 * infra.GIB
    elif change == "swap_used":
        proof["memory_constraints"][0]["memory.swap.current"] = 1
    elif change == "swap_enabled":
        proof["memory_constraints"][0]["memory.swap.max"] = infra.GIB
    elif change == "identity":
        proof["container_id"] = "34"
    elif change == "false_pass":
        proof["passed"] = False
    elif change == "fake_bound":
        proof["memory_constraints"][0]["memory.max"] = 31 * infra.GIB
    elif change == "disk":
        proof["data_free_bytes"] = 1
    else:
        proof["root_free_bytes"] = 1
    with pytest.raises(ValueError):
        infra.capacity(proof, {"instance_id": 12})


@pytest.mark.parametrize("change", [None, "skip", "fail", "error", "missing", "rename", "zero"])
def test_all_four_numerical_cuda_cases_must_execute_without_skips(tmp_path, change):
    root = ET.Element("testsuites")
    suite = ET.SubElement(root, "testsuite")
    cases = [ET.SubElement(suite, "testcase", name=name, time="1")
             for name in sorted(infra.CUDA_NAMES)]
    if change in ("skip", "fail", "error"):
        ET.SubElement(cases[0], {"skip": "skipped", "fail": "failure", "error": "error"}[change])
    elif change == "missing":
        suite.remove(cases[0])
    elif change == "rename":
        cases[0].set("name", "fake_cuda_control")
    elif change == "zero":
        cases[0].set("time", "0")
    path = tmp_path / "cuda.xml"
    ET.ElementTree(root).write(path)
    if change is None:
        infra.cuda_xml(path)
    else:
        with pytest.raises(ValueError):
            infra.cuda_xml(path)


def cleanup_fixture():
    rental = {"instance_id": 12, "volume_id": 34, "label": "ours",
              "creation_state": "reconciled", "preexisting_instance_ids": [56],
              "preexisting_volume_ids": [78]}
    deletion = {"instance_id": 12, "volume_id": 34, "verified_absent": True,
                "volume_verified_absent": True, "unix": 20}
    volume = {"volume_id": 34, "verified_absent": True}
    absence = {**deletion, "label": "ours", "instance_verified_absent": True,
               "label_verified_absent": True, "unix": 21}
    return [rental, deletion, volume, absence, {"unix": 19}]


def test_exact_cleanup_follows_complete_local_retention():
    infra.cleanup(*cleanup_fixture())


@pytest.mark.parametrize("change", ["peer", "volume_peer", "null", "wrong_disk", "still_present",
                                   "wrong_label", "before_retention", "stale_absence"])
def test_cleanup_cannot_claim_peer_deletion_or_missing_disk(change):
    args = cleanup_fixture()
    if change == "peer":
        args[0]["preexisting_instance_ids"].append(12)
    elif change == "volume_peer":
        args[0]["preexisting_volume_ids"].append(34)
    elif change == "null":
        args[0]["instance_id"] = None
    elif change == "wrong_disk":
        args[2]["volume_id"] = 99
    elif change == "still_present":
        args[3]["volume_verified_absent"] = False
    elif change == "wrong_label":
        args[3]["label"] = "colleague"
    elif change == "before_retention":
        args[4]["unix"] = 22
    else:
        args[3]["unix"] = 18
    with pytest.raises(ValueError):
        infra.cleanup(*args)


def phase_fixture():
    return {"source_commit": infra.SOURCE, "spec_sha256": "a" * 64, "records": [
        {"phase": "dispatch_qualification", "status": "started", "monotonic": 1, "unix": 1,
         "command": ["python", "/root/liger/final_comparison.py", "run",
                     "--source-commit", infra.SOURCE]},
        {"phase": "dispatch_qualification", "status": "completed", "monotonic": 2, "unix": 2}]}


def test_frozen_runner_has_only_started_completed_standalone_qualification():
    infra.phase_order(phase_fixture(), "a" * 64)


@pytest.mark.parametrize("change", ["source", "spec", "profile", "time", "runner"])
def test_phase_receipts_cannot_relabel_profiles_or_another_runner(change):
    value = phase_fixture()
    if change == "source":
        value["source_commit"] = "b" * 40
    elif change == "spec":
        value["spec_sha256"] = "c" * 64
    elif change == "profile":
        value["records"][0]["phase"] = "baseline_profile"
    elif change == "time":
        value["records"][1]["monotonic"] = 0
    else:
        value["records"][0]["command"][1] = "old_qualifier.py"
    with pytest.raises(ValueError):
        infra.phase_order(value, "a" * 64)


def test_manifest_cannot_escape_retained_root(tmp_path):
    assert infra.contained(tmp_path, "results/ok.json") == tmp_path / "results/ok.json"
    for name in ("../outside.json", str(tmp_path.parent / "absolute.json"), ""):
        with pytest.raises(ValueError):
            infra.contained(tmp_path, name)


def worker_fixture():
    snapshot = {"process_swap_bytes": 0,
                "cgroup": {"constraints": [{"memory.max": 30 * infra.GIB,
                    "memory.swap.max": 0, "memory.swap.current": 0}]}}
    resources = {"before": copy.deepcopy(snapshot), "after": copy.deepcopy(snapshot),
                 "sampled_peak_cgroup_swap_bytes": 0, "sampled_peak_process_swap_bytes": 0}
    raw = {"environment": {"gpu_name": "NVIDIA GeForce RTX 3070", "gpu_total_bytes": 8 * infra.GIB,
                           "deterministic_algorithms": True, "allow_tf32": False},
           "resources_before": copy.deepcopy(snapshot), "resources_after": copy.deepcopy(snapshot),
           "warmup": {"resources": copy.deepcopy(resources)},
           "timing": {"resources": copy.deepcopy(resources)}}
    return raw, capacity_fixture(), {"hardware": {"physical_vram_bytes": 8 * infra.GIB}}


def test_all_workers_keep_native_gpu_and_disabled_swap():
    infra.worker_boundary(*worker_fixture())


@pytest.mark.parametrize("change", ["gpu", "tf32", "scope", "process_swap", "timed_swap"])
def test_worker_boundary_refuses_changed_device_or_swap(change):
    raw, proof, spec = worker_fixture()
    if change == "gpu":
        raw["environment"]["gpu_name"] = "RTX 4090"
    elif change == "tf32":
        raw["environment"]["allow_tf32"] = True
    elif change == "scope":
        raw["resources_after"]["cgroup"]["constraints"][0]["memory.max"] = 64 * infra.GIB
    elif change == "process_swap":
        raw["resources_before"]["process_swap_bytes"] = 1
    else:
        raw["timing"]["resources"]["sampled_peak_cgroup_swap_bytes"] = 1
    with pytest.raises(ValueError):
        infra.worker_boundary(raw, proof, spec)


def model_fixture():
    sizes = [5_000_000_000] * 12 + [1_343_935_088]
    pinned = {"repo_id": infra.MODEL, "revision": infra.REVISION,
              "weights_bytes": 61_343_935_088,
              "files": {f"model-{index+1:05d}-of-00013.safetensors": {
                  "bytes": size, "lfs": {"size": size, "sha256": "a" * 64}}
                  for index, size in enumerate(sizes)}}
    return pinned, {"revision": infra.REVISION, "source_bytes": 61_343_935_088, "seconds": 1}


def test_official_model_pin_contains_thirteen_complete_shards():
    infra.model_pin(*model_fixture())


@pytest.mark.parametrize("change", ["model", "revision", "missing", "size", "sha", "download"])
def test_model_identity_cannot_silently_change(change):
    pinned, downloaded = model_fixture()
    first = next(iter(pinned["files"]))
    if change == "model":
        pinned["repo_id"] = "another/model"
    elif change == "revision":
        pinned["revision"] = "main"
    elif change == "missing":
        pinned["files"].pop(first)
    elif change == "size":
        pinned["files"][first]["lfs"]["size"] -= 1
    elif change == "sha":
        pinned["files"][first]["lfs"]["sha256"] = "unknown"
    else:
        downloaded["revision"] = "main"
    with pytest.raises(ValueError):
        infra.model_pin(pinned, downloaded)


def test_no_data_or_missing_retention_never_gets_a_success_verdict(tmp_path):
    with pytest.raises(FileNotFoundError):
        infra.audit(tmp_path)


def test_unprofiled_readiness_passes_without_unrelated_cupti_control(tmp_path):
    root = ET.Element("testsuites")
    suite = ET.SubElement(root, "testsuite")
    for name in sorted(infra.CUDA_NAMES):
        ET.SubElement(suite, "testcase", name=name, time="1")
    path = tmp_path / "numerical-only.xml"
    ET.ElementTree(root).write(path)
    infra.cuda_xml(path)
    assert infra.PROFILER_DIAGNOSTIC not in infra.CUDA_NAMES


@pytest.mark.parametrize("replacement", [False, True])
def test_profiler_cannot_replace_missing_numerical_control(tmp_path, replacement):
    root = ET.Element("testsuites")
    suite = ET.SubElement(root, "testsuite")
    for name in sorted(infra.CUDA_NAMES)[1:]:
        ET.SubElement(suite, "testcase", name=name, time="1")
    if replacement:
        ET.SubElement(suite, "testcase", name=infra.PROFILER_DIAGNOSTIC, time="1")
    path = tmp_path / "missing-numerical.xml"
    ET.ElementTree(root).write(path)
    with pytest.raises(ValueError):
        infra.cuda_xml(path)


def test_old_failed_five_case_preflight_cannot_be_relabelled_as_new_pass(tmp_path):
    root = ET.Element("testsuites")
    suite = ET.SubElement(root, "testsuite")
    for name in sorted(infra.CUDA_NAMES):
        ET.SubElement(suite, "testcase", name=name, time="1")
    profiler = ET.SubElement(suite, "testcase", name=infra.PROFILER_DIAGNOSTIC, time="1")
    ET.SubElement(profiler, "failure", message="CUPTI unavailable")
    path = tmp_path / "old-failed-five-case.xml"
    ET.ElementTree(root).write(path)
    with pytest.raises(ValueError):
        infra.cuda_xml(path)


def input_receipt_fixture(repaired=False):
    old = Path(r"C:\Users\esenb\Documents\SoupResearch\kanana-30b-dispatch-gpu-20261026-f8")
    pinned = json.loads((old / "retained/results/model-pinned.json").read_text())
    spec = json.loads((old / "retained/results/prepared/spec.json").read_text())
    expected = {name: {"bytes": row["bytes"], "sha256": row["lfs"]["sha256"]}
                for name, row in pinned["files"].items()}
    events, count = [], 0
    bad = "model-00012-of-00013.safetensors"

    def event(kind, name, phase, passed=True):
        row = {"event": kind, "filename": name, "phase": phase,
               "expected_bytes": expected[name]["bytes"],
               "expected_sha256": expected[name]["sha256"],
               "attempt": int(count > 0), "timestamp": float(len(events) + 1),
               "global_forced_redownloads_used": count,
               "observed_bytes": expected[name]["bytes"],
               "observed_sha256": expected[name]["sha256"] if passed else "c" * 64,
               "error_category": None if passed else "sha256_mismatch", "passed": passed}
        events.append(row)

    for name in expected:
        event("hash_started", name, "initial")
        event("hash_completed", name, "initial", not (repaired and name == bad))
    if repaired:
        count = 1
        event("forced_download_started", bad, "repair")
        event("forced_download_completed", bad, "repair")
        event("hash_started", bad, "post_redownload")
        event("hash_completed", bad, "post_redownload")
    for name in expected:
        event("hash_started", name, "final_recheck")
        event("hash_completed", name, "final_recheck")
    receipt = {"schema_version": 1, "status": "passed", "all_shards_verified": True,
               "repo_id": infra.MODEL, "revision": infra.REVISION,
               "helper_path": "/root/liger/checkpoint_integrity.py", "helper_sha256": "a" * 64,
               "expected_files": 13, "expected_total_bytes": 61_343_935_088,
               "expected_pins": expected, "expected_pins_sha256": infra.OFFICIAL_PIN_MAP_SHA256,
               "final_verified_files": copy.deepcopy(expected), "max_forced_redownloads": 2,
               "forced_redownloads_used": count, "events": events, "passed_unix": 500.}
    control = {"passed": True, "hub_version": "1.33.0", "cached_destination_replaced": True,
               "fresh_stream_position": 0, "resume_size": 0, "real_network_invoked": False,
               "http_function_restored": True, "source_sha256": "b" * 64}
    binding = {"passed": True, "files": 13, "unix": 1000.,
               "model_fingerprint": {name: row["sha256"] for name, row in expected.items()}}
    return receipt, pinned, spec, control, binding, "a" * 64


@pytest.mark.parametrize("repaired", [False, True])
def test_v4_input_audit_uses_actual_f8_official_pins_and_native_prepared_schema(repaired):
    result = infra.checkpoint_input_integrity(*input_receipt_fixture(repaired))
    assert result["verified_files"] == 13
    assert result["forced_redownloads_used"] == int(repaired)
    assert len(result["initial_failed_files"]) == int(repaired)


@pytest.mark.parametrize("corruption", ["max_budget", "used_budget", "wrong_expected", "helper",
    "helper_path", "accepted_bad_sha", "missing_initial", "missing_final", "forced_healthy",
    "counter_reset", "prepared_sha", "resume", "not_passed", "bad_sha_not_retained"])
def test_v4_input_audit_never_accepts_replaced_inputs_or_unverified_repairs(corruption):
    args = list(input_receipt_fixture(True))
    receipt, pinned, spec, control, binding, _helper_sha = args
    bad = "model-00012-of-00013.safetensors"
    initial_bad = next(row for row in receipt["events"]
                       if row["event"] == "hash_completed" and row["phase"] == "initial"
                       and row["filename"] == bad)
    if corruption == "max_budget":
        receipt["max_forced_redownloads"] = 3
    elif corruption == "used_budget":
        receipt["forced_redownloads_used"] = 3
    elif corruption == "wrong_expected":
        pinned["files"][bad]["lfs"]["sha256"] = "d" * 64
    elif corruption == "helper":
        receipt["helper_sha256"] = "d" * 64
    elif corruption == "helper_path":
        receipt["helper_path"] = "/some/other/checkpoint_integrity.py"
    elif corruption == "accepted_bad_sha":
        initial_bad["passed"] = True
    elif corruption == "missing_initial":
        receipt["events"] = [row for row in receipt["events"]
            if not (row["filename"] == bad and row["phase"] == "initial")]
    elif corruption == "missing_final":
        receipt["events"] = receipt["events"][:-2]
    elif corruption == "forced_healthy":
        initial_bad.update(passed=True, error_category=None,
                           observed_sha256=initial_bad["expected_sha256"])
    elif corruption == "counter_reset":
        receipt["events"][-1]["global_forced_redownloads_used"] = 0
    elif corruption == "prepared_sha":
        spec["model_fingerprint"][bad] = "d" * 64
    elif corruption == "resume":
        control["resume_size"] = 123
    elif corruption == "not_passed":
        receipt["status"] = "failed"
    else:
        initial_bad["observed_sha256"] = None
    with pytest.raises((ValueError, TypeError)):
        infra.checkpoint_input_integrity(*args)
