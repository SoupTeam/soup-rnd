"""Offline F15 combined controls; no real provider or GPU operation."""

import gzip
import hashlib
import json
import math
import sys
from pathlib import Path
from types import SimpleNamespace

import cloud
import launch
import controller
import diagnostics
import pytest
import remote_run
from launch_safety import validate_protocol


@pytest.fixture(autouse=True)
def offline_only(tmp_path, monkeypatch):
    monkeypatch.setattr(remote_run, 'ROOT', tmp_path)
    monkeypatch.setattr(cloud, 'ROOT', tmp_path)
    monkeypatch.setattr(controller, 'ROOT', tmp_path)
    monkeypatch.setattr(diagnostics, 'ROOT', tmp_path)
    (tmp_path / 'source-manifest.json').write_text(json.dumps({'source_commit': 'a' * 40}))
    (tmp_path / 'spec.json').write_text('{}')
    monkeypatch.setattr(cloud, 'api', lambda *_a, **_k: pytest.fail('Live provider reached'))
    monkeypatch.setattr(cloud, 'ssh', lambda *_a, **_k: pytest.fail('Live SSH reached'))


def protocol():
    value = json.loads((Path(__file__).parent / 'protocol.json').read_text())
    value['source_commit'] = 'a' * 40
    return value


def validate(value):
    return validate_protocol(value, source_commit='a' * 40, stage_id=cloud.STAGE)


def test_combined_stage_pins_four_numerical_cuda_cells_accuracy_arms_and_scope():
    result = validate(protocol())
    assert result['cuda_cells'] == 4
    assert result['accuracy_arms'] == ['ordinary', 'two_read', 'two_read_cache']
    assert result['profile_arms'] == ['two_read', 'two_read_cache']
    assert 'dispatch paired timing separate' in result['performance_verdict']


@pytest.mark.parametrize('section,field,value', [
    ('performance', 'accuracy_arms', ['two_read_cache']),
    ('performance', 'profile_arms', ['two_read_cache']),
    ('performance', 'host_cache_bytes', 2 * 2**30),
    ('performance', 'max_trace_bytes', 2**30),
    ('performance', 'profiled_times_are_diagnostic_only', False),
    ('financial', 'maximum_stage_usd', 4.338940737783173),
    ('financial', 'maximum_seconds', 10800),
    ('financial', 'maximum_seconds', 6600),
    ('financial', 'download_allowance_decimal_gb', 100),
    ('financial', 'upload_allowance_decimal_gb', 20),
])
def test_frozen_diagnostic_or_financial_boundary_cannot_silently_change(section, field, value):
    candidate = protocol()
    candidate[section][field] = value
    with pytest.raises(ValueError):
        validate(candidate)


def test_actual_cuda_numerical_controls_are_required_and_cannot_be_skipped(tmp_path):
    candidate = protocol()
    candidate['cuda_test_selectors'] = candidate['cuda_test_selectors'][:-1]
    with pytest.raises(ValueError, match='four actual CUDA'):
        validate(candidate)
    from xml.etree import ElementTree as ET
    target = tmp_path / 'cuda.xml'
    suite = ET.Element('testsuite')
    for index, name in enumerate(protocol()['cuda_expected_case_names']):
        item = ET.SubElement(suite, 'testcase', name=name)
        if index == 3:
            ET.SubElement(item, 'skipped')
    ET.ElementTree(suite).write(target)
    with pytest.raises(RuntimeError, match='four required'):
        remote_run.validate_cuda_xml(target, protocol()['cuda_expected_case_names'])


def test_f_budget_counts_both_disks_and_all_reserves_without_historical_double_charge():
    offer = {'machine_id': 122165, 'dph_base': .14666666666666667,
             'storage_cost': .5333333333333332, 'dph_total': .14666666666666667 + 32 * .5333333333333332 / 720,
             'inet_down_cost': .0026041666666666665, 'inet_up_cost': .00390625}
    volume = {'id': 56801565, 'machine_id': 122165, 'disk_space': 294,
              'storage_cost': .1333333333333333}
    quote = cloud.quote(offer, volume_offer=volume)
    expected_hourly = offer['dph_total'] + 112 * volume['storage_cost'] / 720
    expected_total = expected_hourly * (14400 + 180) / 3600 + 90 * offer['inet_down_cost'] + 2 * offer['inet_up_cost'] + .75 + .25
    assert math.isclose(quote['total_stage_admission_usd'], expected_total)
    assert quote['maximum_stage_usd'] == 3.0 and quote['prior_stage_usd'] == 0
    assert quote['allocated_disk_gb'] == 32 and quote['local_volume_gb'] == 112
    assert quote['maximum_seconds'] == 14400
    assert quote['download_allowance_decimal_gb'] == 90
    assert quote['upload_allowance_decimal_gb'] == 2
    context = json.loads((Path(__file__).parent / 'prior-budget-context.json').read_text())
    assert math.isclose(context['prior_remaining_usd'] + context['new_authorized_usd'] - context['failed_f10_cost_usd'] - context['failed_f11_cost_usd'] - context['failed_f12_cost_usd'] - context['failed_f13_cost_usd'] - context['failed_f14_cost_usd'],
                        context['aggregate_remaining_before_f15_usd'], abs_tol=1e-12)
    assert context['new_stage_cap_usd'] < context['aggregate_remaining_before_f15_usd']
    assert cloud.QUERY['num_gpus'] == {'eq': 1} and cloud.QUERY['gpu_frac'] == {'eq': 1.0}


def test_mismatched_cli_deadline_refuses_before_allocation(tmp_path, monkeypatch):
    (tmp_path / 'protocol.json').write_text(json.dumps(protocol()))
    monkeypatch.setattr(launch, 'ROOT', tmp_path)
    monkeypatch.setattr(launch.controller, 'freeze_check', lambda: None)
    monkeypatch.setattr(launch.cloud, 'allocate', lambda *_: pytest.fail('allocation reached'))
    with pytest.raises(ValueError, match='4-hour'):
        launch.main(['--offer-id', '1', '--volume-ask-id', '2', '--seconds', '3600'])


def profile_report():
    adapters = {'lora_' + str(index): {'sha256': 'a' * 64} for index in range(288)}
    return {'status': 'passed', 'arm': 'two_read', 'spec_sha256': 'a' * 64,
            'inputs': {'canonical_index_sha256': 'b' * 64},
            'initial_adapters': {'tensors': adapters}, 'scope': {'activities': ['CPU', 'CUDA']},
            'warmup': {'updates_complete': 2}, 'unprofiled_context': {'updates_complete': 1},
            'profile_update': {'losses': [2.123456, 2.345678], 'optimizer_updates': 1,
                               'accumulation': 2, 'profiled_microbatches': [0],
                               'unprofiled_microbatches': [1], 'finite_training_state': True},
            'state_before_profile': {'canonical_index_sha256': 'c' * 64},
            'state_after_profile': {'canonical_index_sha256': 'd' * 64}}


def test_cross_profile_original_loss_and_exact_inputs_gate_without_false_hash_tolerance_verdict():
    base, both = profile_report(), profile_report()
    both['arm'] = 'two_read_cache'
    passed = remote_run.compare_profiles(base, both)
    assert passed['passed'] and all(row['passed'] for row in passed['loss_gates'])
    both['state_after_profile']['canonical_index_sha256'] = 'e' * 64
    still_numerically_passes = remote_run.compare_profiles(base, both)
    assert still_numerically_passes['passed']
    assert 'NO VERDICT' in still_numerically_passes['training_state_hash_comparison']['state_after_profile']['verdict']
    assert still_numerically_passes['speed_verdict'] == 'NO VERDICT'


@pytest.mark.parametrize('mutation', ['input', 'adapter', 'loss', 'nonfinite_loss', 'missing_micro'])
def test_wrong_profile_input_adapter_or_original_loss_gate_refuses(mutation):
    base, both = profile_report(), profile_report()
    if mutation == 'input':
        both['inputs']['canonical_index_sha256'] = 'f' * 64
    elif mutation == 'adapter':
        both['initial_adapters']['tensors']['lora_0']['sha256'] = 'f' * 64
    elif mutation == 'loss':
        both['profile_update']['losses'][0] += .001
    elif mutation == 'nonfinite_loss':
        both['profile_update']['losses'][0] = float('nan')
    else:
        both['profile_update']['losses'].pop()
    assert not remote_run.compare_profiles(base, both)['passed']


@pytest.mark.parametrize('failure', ['raise', 'missing_pass'])
def test_failed_accuracy_cannot_start_profile(tmp_path, monkeypatch, failure):
    monkeypatch.setattr(remote_run, 'OUT', tmp_path)
    def qualify(*_):
        if failure == 'raise':
            raise ValueError('actual numerical gate failed')
        return {'status': 'failed', 'accuracy_passed': False}
    monkeypatch.setattr(remote_run, 'qualify_accuracy', qualify)
    monkeypatch.setattr(remote_run, 'command', lambda *_a, **_k: pytest.fail('profile reached'))
    with pytest.raises(ValueError):
        remote_run.accuracy_then_profiles(tmp_path / 'spec.json', protocol())


def test_profile_sequence_starts_only_after_accuracy_then_records_comparison(tmp_path, monkeypatch):
    events = []
    (tmp_path / 'profiles').mkdir()
    monkeypatch.setattr(remote_run, 'OUT', tmp_path)
    def qualify(*_):
        events.append('accuracy')
        return {'status': 'accuracy_passed', 'accuracy_passed': True}
    monkeypatch.setattr(remote_run, 'qualify_accuracy', qualify)
    def command(name, args, **_kwargs):
        events.append(name)
        assert args[1].endswith('expert_cache_profile.py')
        assert '--phase' not in args
    monkeypatch.setattr(remote_run, 'command', command)
    monkeypatch.setattr(remote_run, 'validate_profile_outputs', lambda *_: profile_report())
    remote_run.accuracy_then_profiles(tmp_path / 'spec.json', protocol())
    assert events == ['accuracy', 'profile-two_read', 'profile-two_read_cache']
    assert json.loads((tmp_path / 'profiles/comparison.json').read_text())['passed']


def test_profile_trace_is_byte_verified_and_cpu_cuda_h2d_are_required(tmp_path):
    spec = tmp_path / 'spec.json'
    spec.write_bytes(b'{}')
    raw = b'{"traceEvents":[{"name":"complete-original-event"}]}'
    encoded = gzip.compress(raw)
    path = tmp_path / 'trace.json.gz'
    path.write_bytes(encoded)
    trace = {'path': path.name, 'bytes': len(encoded), 'sha256': hashlib.sha256(encoded).hexdigest(),
             'decoded_bytes': len(raw), 'decoded_sha256': hashlib.sha256(raw).hexdigest(),
             'decoded_verified': True, 'within_bound': True, 'maximum_encoded_bytes': 134217728}
    report = {'status': 'passed', 'phase': 'diagnostic_profile', 'arm': 'two_read',
              'spec_sha256': remote_run.digest(spec), 'unprofiled_speed_verdict': 'NO VERDICT',
              'profile_event_counts': {'event_count': 8, 'cuda_event_count': 3,
                                      'cuda_kernel_event_count': 1, 'cuda_copy_event_count': 2,
                                      'cuda_h2d_event_count': 2}, 'trace': trace}
    (tmp_path / 'profile-result.json').write_text(json.dumps(report))
    (tmp_path / 'trace-retention.json').write_text(json.dumps(trace))
    (tmp_path / 'key-averages.json').write_text(json.dumps({'key_averages': [{'name': 'CPU and CUDA'}], **report['profile_event_counts']}))
    assert remote_run.validate_profile_outputs(tmp_path, 'two_read', spec, 134217728)['status'] == 'passed'
    report['profile_event_counts']['cuda_h2d_event_count'] = 0
    (tmp_path / 'profile-result.json').write_text(json.dumps(report))
    with pytest.raises(ValueError, match='H2D'):
        remote_run.validate_profile_outputs(tmp_path, 'two_read', spec, 134217728)
    report['profile_event_counts']['cuda_h2d_event_count'] = 2
    (tmp_path / 'profile-result.json').write_text(json.dumps(report))
    path.write_bytes(encoded[:-1] + b'X')
    with pytest.raises(ValueError, match='encoded trace'):
        remote_run.validate_profile_outputs(tmp_path, 'two_read', spec, 134217728)


def test_failed_cuda_preflight_exports_failure_and_never_downloads_weights(tmp_path, monkeypatch):
    repo, out = tmp_path / 'repo', tmp_path / 'results'
    repo.mkdir()
    archive = tmp_path / 'source.tar.gz'
    archive.write_bytes(b'frozen source')
    (tmp_path / 'source-manifest.json').write_text(json.dumps({
        'archive_sha256': remote_run.digest(archive), 'source_commit': 'a' * 40, 'files': {}}))
    (tmp_path / 'protocol.json').write_text(json.dumps(protocol()))
    monkeypatch.setattr(remote_run, 'ROOT', tmp_path)
    monkeypatch.setattr(remote_run, 'REPO', repo)
    monkeypatch.setattr(remote_run, 'OUT', out)
    monkeypatch.setattr(remote_run.subprocess, 'check_output', lambda args, **_k:
                        '' if 'status' in args else 'a' * 40 + '\n')
    monkeypatch.setattr(remote_run.subprocess, 'run', lambda *_a, **_k: SimpleNamespace(returncode=0))
    downloads = []
    monkeypatch.setitem(sys.modules, 'huggingface_hub', SimpleNamespace(
        HfApi=lambda: downloads.append('must not be reached'), snapshot_download=lambda *_a, **_k: None))
    def fail(name, args, **_kwargs):
        assert name == 'gpu-preflight'
        assert protocol()['cuda_test_selectors'][-1] in args
        raise RuntimeError('CUPTI did not record CUDA')
    monkeypatch.setattr(remote_run, 'command', fail)
    exported = []
    monkeypatch.setattr(remote_run, 'export', exported.append)
    assert remote_run.main() == 1
    assert not downloads and len(exported) == 1 and exported[0]['status'] == 'failed'


@pytest.mark.parametrize('mutation', [None, 'unchanged', 'zero_gradient', 'wrong_input'])
def test_all_288_adapters_and_complete_input_updates_are_real(tmp_path, mutation):
    import torch

    values = {f'lora_{index}': torch.tensor([1.]) for index in range(288)}
    final = {name: value + 1 for name, value in values.items()}
    inputs = torch.arange(8, dtype=torch.long).reshape(4, 1, 2)
    path = tmp_path / 'inputs.pt'
    torch.save(inputs, path)
    capture = {'initial_adapters': values,
               'updates': [{'adapters': values}, {'adapters': final}],
               'microbatches': [{'input_ids': inputs[index].clone(),
                                 'gradients': {name: torch.ones_like(value) for name, value in values.items()}}
                                for index in range(4)]}
    spec = {'accuracy_updates': 2, 'accumulation': 2, 'training_data_path': str(path)}
    if mutation == 'unchanged':
        final['lora_0'] = values['lora_0'].clone()
    elif mutation == 'zero_gradient':
        for row in capture['microbatches']:
            row['gradients']['lora_0'].zero_()
    elif mutation == 'wrong_input':
        capture['microbatches'][0]['input_ids'].add_(1)
    if mutation:
        with pytest.raises(ValueError):
            remote_run.validate_full_capture(capture, spec)
    else:
        assert remote_run.validate_full_capture(capture, spec)['adapters_nonzero_changed_and_nonzero_gradients'] == 288


@pytest.mark.parametrize('mutation', ['wrong_input', 'wrong_loss'])
def test_wrong_cross_profile_control_is_retained_and_stops_success(tmp_path, monkeypatch, mutation):
    (tmp_path / 'profiles').mkdir()
    monkeypatch.setattr(remote_run, 'OUT', tmp_path)
    monkeypatch.setattr(remote_run, 'qualify_accuracy', lambda *_: {'status': 'accuracy_passed', 'accuracy_passed': True})
    monkeypatch.setattr(remote_run, 'command', lambda *_a, **_k: None)
    def profile(_directory, arm, *_args):
        report = profile_report()
        if arm == 'two_read_cache':
            if mutation == 'wrong_input':
                report['inputs']['canonical_index_sha256'] = 'f' * 64
            else:
                report['profile_update']['losses'][0] += .001
        return report
    monkeypatch.setattr(remote_run, 'validate_profile_outputs', profile)
    with pytest.raises(ValueError, match='Cross-profile'):
        remote_run.accuracy_then_profiles(tmp_path / 'spec.json', protocol())
    result = json.loads((tmp_path / 'profiles/comparison.json').read_text())
    assert not result['passed']
    assert result['speed_verdict'] == 'NO VERDICT'


@pytest.mark.parametrize('field,value', [
    ('physical_gpu_gib_class', 24), ('max_ram_bytes', 64 * 2**30),
    ('swap_must_be_disabled', False), ('minimum_root_free_bytes', 15 * 2**30),
    ('minimum_data_free_bytes', 99 * 2**30),
])
def test_native_hardware_and_disk_reserves_remain_frozen(field, value):
    candidate = protocol()
    candidate['native_boundary'][field] = value
    with pytest.raises(ValueError, match='boundary changed'):
        validate(candidate)


@pytest.mark.parametrize('field,value', [
    ('timing_workers', 4), ('accuracy_updates', 1), ('rounds', 2),
    ('grouped_expert_routes_default', True), ('practical_lower_bound_percent', 0),
])
def test_combined_candidate_protocol_cannot_weaken_qualification(field, value):
    candidate = protocol()
    candidate['performance']['dispatch_qualification'][field] = value
    with pytest.raises(ValueError, match='protocol changed'):
        validate(candidate)


def full_host():
    return {'num_gpus': 1, 'gpu_frac': 1., 'gpu_ram': 8192, 'cpu_ram': 31413,
            'compute_cap': 860, 'disk_space': 360.9}


@pytest.mark.parametrize('field,value', [
    ('num_gpus', 4), ('gpu_frac', .25), ('cpu_ram', 131072), ('gpu_ram', 16384),
    ('disk_space', 143), ('compute_cap', 750),
])
def test_fractional_or_ineligible_offers_refuse_before_allocation(field, value):
    offer = full_host()
    assert cloud.validate_full_host(offer)
    offer[field] = value
    with pytest.raises(ValueError):
        cloud.validate_full_host(offer)


def routes():
    return [{'kind': 'provider_proxy', 'host': 'ssh4.vast.ai', 'port': 12345, 'instance_id': 42},
            {'kind': 'provider_direct', 'host': '192.0.2.4', 'port': 54321, 'instance_id': 42}]


def test_api_routes_use_only_actual_row_ports_and_tolerate_absent_port_mapping():
    assert cloud.api_ssh_routes({'id': 42, 'ports': None}) == []
    row = {'id': 42, 'ssh_host': 'ssh4.vast.ai', 'ssh_port': 12345,
           'public_ipaddr': '192.0.2.4', 'ports': {'22/tcp': [{'HostPort': '54321'}]}}
    assert cloud.api_ssh_routes(row) == routes()
    row['ssh_host'] = 'bad host; command'
    assert cloud.api_ssh_routes(row) == [routes()[1]]


@pytest.mark.parametrize('mutation', ['unlisted_route', 'wrong_pool', 'unverified', 'actual_id', 'source'])
def test_selected_ssh_route_requires_actual_owned_identity_and_api_provenance(tmp_path, monkeypatch, mutation):
    policy = {'instance_id': 42, 'source_sha256': 'a' * 64}
    pool = {'instance_id': 42, 'label': cloud.LABEL, 'routes': routes()}
    chosen = {**routes()[0], 'identity_verified': True, 'actual_container_id': '42',
              'source_sha256': 'a' * 64}
    if mutation == 'unlisted_route':
        chosen['port'] += 1
    elif mutation == 'wrong_pool':
        pool['instance_id'] = 99
    elif mutation == 'unverified':
        chosen['identity_verified'] = False
    elif mutation == 'actual_id':
        chosen['actual_container_id'] = '99'
    else:
        chosen['source_sha256'] = 'b' * 64
    monkeypatch.setattr(cloud, 'receipt', lambda: policy)
    cloud.save('api-ssh-routes.json', pool)
    cloud.save('vast-connection.json', chosen)
    with pytest.raises(ValueError):
        cloud.ssh_args()


def test_unselected_probe_routes_still_enforce_host_key_policy(tmp_path, monkeypatch):
    monkeypatch.setattr(cloud, 'receipt', lambda: {'instance_id': 42})
    cloud.save('api-ssh-routes.json', {'instance_id': 42, 'label': cloud.LABEL, 'routes': routes()})
    args = cloud.ssh_args(routes()[0])
    assert 'StrictHostKeyChecking=accept-new' in args
    assert not any(value in args for value in ('StrictHostKeyChecking=no', 'UserKnownHostsFile=/dev/null'))
    assert args[-1] == 'root@ssh4.vast.ai' and '-T' in args


@pytest.mark.parametrize('failure', [None, 'timeout', 'wrong_id', 'wrong_label', 'wrong_source', 'both_timeout'])
def test_read_only_route_probe_selects_only_successful_actual_identity(tmp_path, monkeypatch, failure):
    import subprocess

    policy = {'instance_id': 42, 'source_sha256': 'a' * 64}
    cloud.save('api-ssh-routes.json', {'instance_id': 42, 'label': cloud.LABEL, 'routes': routes()})
    calls = []
    def native(command, *, timeout, route):
        calls.append(route['kind'])
        assert timeout == 15 and 'actual_container_id' in command
        if failure == 'both_timeout' or (failure == 'timeout' and route['kind'] == 'provider_proxy'):
            raise subprocess.TimeoutExpired(command, timeout)
        actual = {'actual_container_id': '42', 'label': cloud.LABEL, 'source_sha256': 'a' * 64}
        if route['kind'] == 'provider_proxy':
            if failure == 'wrong_id':
                actual['actual_container_id'] = '99'
            if failure == 'wrong_label':
                actual['label'] = 'colleague'
            if failure == 'wrong_source':
                actual['source_sha256'] = 'b' * 64
        return SimpleNamespace(returncode=0, stdout=json.dumps(actual).encode(), stderr=b'')
    monkeypatch.setattr(cloud, 'ssh', native)
    passed = controller.probe_ssh_routes(policy)
    proof = json.loads((tmp_path / 'route-readiness.json').read_text())
    assert set(calls) == {'provider_proxy', 'provider_direct'} and proof['read_only']
    if failure == 'both_timeout':
        assert not passed and not (tmp_path / 'vast-connection.json').exists()
    else:
        chosen = json.loads((tmp_path / 'vast-connection.json').read_text())
        assert passed and chosen['identity_verified'] and chosen['actual_container_id'] == '42'
        if failure:
            assert chosen['kind'] == 'provider_direct'


@pytest.mark.parametrize('root_gib,data_gib,passes', [(16, 100, True), (15, 100, False), (16, 99, False)])
def test_disk_reserve_checked_again_after_dependencies_before_large_download(tmp_path, monkeypatch, root_gib, data_gib, passes):
    monkeypatch.setattr(remote_run, 'OUT', tmp_path)
    monkeypatch.setattr(remote_run.shutil, 'disk_usage', lambda path: SimpleNamespace(
        free=(data_gib if str(path) == '/data' else root_gib) * 2**30))
    if passes:
        assert remote_run.pre_download_disk_gate()['passed']
    else:
        with pytest.raises(RuntimeError, match='reserve'):
            remote_run.pre_download_disk_gate()
    assert json.loads((tmp_path / 'pre-download-disk.json').read_text())['passed'] is passes


def test_order_receipts_bind_same_source_spec_and_preserve_failed_phase(tmp_path, monkeypatch):
    monkeypatch.setattr(remote_run, 'OUT', tmp_path)
    spec = tmp_path / 'spec.json'
    remote_run.phase_receipt('native_accuracy', 'started', spec)
    remote_run.phase_receipt('native_accuracy', 'completed', spec)
    remote_run.phase_receipt('baseline_profile_two_read', 'started', spec, ['python', 'profile'])
    row = json.loads((tmp_path / 'phase-order.json').read_text())
    assert [item['status'] for item in row['records']] == ['started', 'completed', 'started']
    assert row['source_commit'] == 'a' * 40 and row['spec_sha256'] == remote_run.digest(spec)
    spec.write_text('{"changed":true}')
    with pytest.raises(ValueError, match='identity changed'):
        remote_run.phase_receipt('dispatch_qualification', 'started', spec)


@pytest.mark.parametrize('report_available', [True, False])
def test_failed_native_gate_retains_capacity_observations_before_refusal(tmp_path, monkeypatch, report_available):
    observed = {'passed': False, 'native_ram_limit_bytes': 64 * 2**30,
                'error': 'Require actual RAM boundary'}
    calls = []
    def remote(command, **_kwargs):
        calls.append(command)
        if len(calls) == 1:
            raise ConnectionError('nonzero native preflight')
        if not report_available:
            raise ConnectionError('report transport unavailable')
        return json.dumps(observed).encode()
    monkeypatch.setattr(controller, '_remote', remote)
    if report_available:
        with pytest.raises(RuntimeError, match='gate did not pass'):
            controller._native_gate()
        assert json.loads((tmp_path / 'capacity-preflight.json').read_text()) == observed
    else:
        with pytest.raises(ConnectionError, match='nonzero native preflight'):
            controller._native_gate()
    assert len(calls) == 2


@pytest.mark.parametrize('mutation', [None, 'accuracy', 'gate', 'timing_count', 'summary'])
def test_dispatch_result_validation_requires_complete_trajectory_and_paired_timing(tmp_path, monkeypatch, mutation):
    import final_comparison as grouped
    monkeypatch.setattr(grouped, 'configure', lambda *_: None)

    monkeypatch.setattr(remote_run, 'OUT', tmp_path)
    summary = {'passes_practical_2_percent_gate': False}
    monkeypatch.setattr(grouped, 'timing_summary', lambda *_: summary)
    row = {'status': 'completed', 'accuracy_passed': True, 'source_commit': 'a' * 40,
           'spec_sha256': remote_run.digest(tmp_path / 'spec.json'), 'accuracy': {},
           'timing_blocks': [{} for _ in range(8)], 'timing_summary': dict(summary)}
    control = {'passed': True, 'adapters_nonzero_changed_and_nonzero_gradients': 288,
               'updates': 2, 'microbatches': 4}
    for variant in ('ordinary_legacy', 'legacy', 'grouped'):
        row['accuracy'][variant] = {'capture_controls': dict(control)}
    for variant, reference in (('legacy', 'ordinary_legacy'), ('grouped', 'ordinary_legacy'), ('grouped', 'legacy')):
        row['accuracy'][variant]['versus_' + reference] = {'passed': True}
    if mutation == 'accuracy':
        row['accuracy']['grouped']['capture_controls']['microbatches'] = 2
    elif mutation == 'gate':
        row['accuracy']['grouped']['versus_legacy']['passed'] = False
    elif mutation == 'timing_count':
        row['timing_blocks'].pop()
    elif mutation == 'summary':
        row['timing_summary']['passes_practical_2_percent_gate'] = True
    (tmp_path / 'run.json').write_text(json.dumps(row))
    if mutation:
        with pytest.raises(ValueError):
            remote_run.validate_dispatch_outputs(tmp_path, tmp_path / 'spec.json')
    else:
        proof = remote_run.validate_dispatch_outputs(tmp_path, tmp_path / 'spec.json')
        assert proof['accuracy_passed'] and proof['timing_workers'] == 8
        assert proof['recomputed_timing_summary']['passes_practical_2_percent_gate'] is False


def test_real_git_crlf_deployment_retains_exact_bytes_and_clean_commit_with_local_normalization(tmp_path):
    import subprocess

    def git(root, *arguments):
        return subprocess.check_output(['git', *arguments], cwd=root, stderr=subprocess.STDOUT)
    origin, deployed = tmp_path / 'origin', tmp_path / 'deployed'
    origin.mkdir()
    deployed.mkdir()
    git(origin, 'init', '-q')
    git(origin, 'config', '--local', 'core.autocrlf', 'false')
    git(origin, 'config', '--local', 'user.name', 'Offline Fixture')
    git(origin, 'config', '--local', 'user.email', 'offline@example.invalid')
    canonical = b'first source line\nsecond source line\n'
    frozen = canonical.replace(b'\n', b'\r\n')
    files = {'source.py': canonical, '.gitattributes': b'fixture.json text eol=lf\n',
             'fixture.json': b'{"stable":"LF"}\n', 'binary.bin': bytes(range(256)) * 2}
    for name, payload in files.items():
        (origin / name).write_bytes(payload)
        (deployed / name).write_bytes(frozen if name == 'source.py' else payload)
    git(origin, 'add', '.')
    git(origin, 'commit', '-qm', 'frozen local fixture')
    expected = git(origin, 'rev-parse', 'HEAD').strip()
    before = {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in deployed.iterdir()}
    git(deployed, 'init', '-q')
    git(deployed, 'config', '--local', 'core.autocrlf', 'false')
    git(deployed, 'remote', 'add', 'origin', str(origin))
    git(deployed, 'fetch', '--quiet', '--depth=1', 'origin', expected.decode())
    git(deployed, 'reset', '--mixed', 'FETCH_HEAD')
    assert b'source.py' in git(deployed, 'status', '--porcelain', '--untracked-files=no')
    git(deployed, 'config', '--local', 'core.autocrlf', 'true')
    git(deployed, 'reset', '--mixed', 'FETCH_HEAD')
    assert not git(deployed, 'status', '--porcelain', '--untracked-files=no').strip()
    assert git(deployed, 'rev-parse', 'HEAD').strip() == expected
    assert all(hashlib.sha256((deployed / name).read_bytes()).hexdigest() == sha
               for name, sha in before.items())
    setup = (Path(__file__).parent / 'setup.sh').read_text()
    assert setup.index('git config --local core.autocrlf true') < setup.index('git reset --mixed')
    assert setup.index('git status --porcelain --untracked-files=no') < setup.index('python3 -m pip install uv')


def test_dirty_deployed_source_refuses_before_cuda_or_model_download(tmp_path, monkeypatch):
    repo, out = tmp_path / 'repo', tmp_path / 'results'
    repo.mkdir()
    archive = tmp_path / 'source.tar.gz'
    archive.write_bytes(b'frozen source')
    (tmp_path / 'source-manifest.json').write_text(json.dumps({
        'archive_sha256': remote_run.digest(archive), 'source_commit': 'a' * 40, 'files': {}}))
    (tmp_path / 'protocol.json').write_text(json.dumps(protocol()))
    monkeypatch.setattr(remote_run, 'REPO', repo)
    monkeypatch.setattr(remote_run, 'OUT', out)
    monkeypatch.setattr(remote_run.subprocess, 'check_output', lambda args, **_k:
                        ' M source.py\n' if 'status' in args else 'a' * 40 + '\n')
    monkeypatch.setattr(remote_run.subprocess, 'run', lambda *_a, **_k: pytest.fail('Dependencies or GPU reached'))
    monkeypatch.setattr(remote_run, 'command', lambda *_a, **_k: pytest.fail('CUDA or model reached'))
    exported = []
    monkeypatch.setattr(remote_run, 'export', exported.append)
    assert remote_run.main() == 1
    assert len(exported) == 1 and 'dirty before CUDA or model download' in exported[0]['error']
