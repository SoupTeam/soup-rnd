"""Root-invoked local source/ops freeze. This never calls a provider or creates SSH keys."""

from __future__ import annotations

import argparse
import gzip
import json
import os
import subprocess
import sys
import tarfile
from pathlib import Path

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT / '.deps'))

import controller  # noqa: E402


def save(path, value):
    temporary = path.with_suffix(path.suffix + '.incoming')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    os.replace(temporary, path)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-dir', type=Path, required=True)
    parser.add_argument('--source-commit', required=True)
    args = parser.parse_args(argv)
    source = Path(os.path.realpath(args.source_dir))
    if (ROOT / 'vast-rental.json').exists():
        raise RuntimeError('Never refreeze an already receipted lease')
    if not (ROOT / 'ssh-key').is_file() or not (ROOT / 'ssh-key.pub').is_file():
        raise RuntimeError('Root must create the new protected local SSH key before freezing')
    def git(*parts):
        return subprocess.check_output(['git', *parts], cwd=source)
    if git('rev-parse', 'HEAD').decode().strip() != args.source_commit:
        raise ValueError('Requested source commit is not the current local HEAD')
    if git('status', '--porcelain', '--untracked-files=no').strip():
        raise ValueError('Tracked source changes remain; wait for every writer FINAL')
    names = sorted(name.decode() for name in git('ls-files', '-z').split(b'\0') if name)
    archive = ROOT / 'source.tar.gz'
    temporary = ROOT / 'source.tar.gz.incoming'
    files = {}
    with temporary.open('wb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|') as tar:
            for name in names:
                path = controller._contained(source, name)
                if path.is_symlink() or not path.is_file():
                    raise ValueError('Source must contain ordinary tracked files only: ' + name)
                row = {'bytes': path.stat().st_size, 'sha256': controller.cloud.digest(path)}
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = row['bytes'], 0o644, 0
                with path.open('rb') as handle:
                    tar.addfile(info, handle)
                if path.stat().st_size != row['bytes'] or controller.cloud.digest(path) != row['sha256']:
                    raise RuntimeError('Source changed during freezing: ' + name)
                files[name] = row
    if git('status', '--porcelain', '--untracked-files=no').strip():
        raise RuntimeError('Source changed during freezing')
    os.replace(temporary, archive)
    save(ROOT / 'source-manifest.json', {'source_commit': args.source_commit,
         'archive_sha256': controller.cloud.digest(archive), 'files': files})
    protocol = json.loads((ROOT / 'protocol.json').read_text())
    protocol['source_commit'] = args.source_commit
    save(ROOT / 'protocol.json', protocol)
    names = [*controller.REQUIRED, 'controller.py', 'launch.py', 'cloud.py', 'transport.py',
             'range_transport.py', 'launch_safety.py', 'diagnostics.py', 'prepare_freeze.py', 'ssh-key.pub',
             'prior-budget-context.json', 'test_controller.py', 'test_profile_ops.py',
             'test_native_transport.py', 'test_setup_bytes.py', 'test_diagnostic_receipt.py',
             'test_diagnostics_concurrency.py',
             'test_standalone_protocol.py',
             'ops-tests.xml', 'test_final_comparison.py', 'audit_final_comparison.py',
             'api_rate_limit.py', 'api_transport.py', 'checkpoint_integrity.py',
             'test_f13_independent_transport_review.py', 'test_f13_cross_process.py',
             'f14-input-repair-tests.xml', 'test_f14_independent_integrity.py',
             'key-control.json', 'key-dacl-control.json']
    rows = {name: {'bytes': (ROOT / name).stat().st_size,
                   'sha256': controller.cloud.digest(ROOT / name)} for name in names}
    save(ROOT / 'launch-manifest.json', {'files': rows,
         'retention_estimate_bytes': 1500000000, 'raw_estimate_bytes': 12 * 2**30,
         'source_commit': args.source_commit})
    controller.freeze_check()
    from rich.console import Console
    Console().print({'source_commit': args.source_commit, 'source_files': len(files),
                     'source_archive_bytes': archive.stat().st_size, 'frozen': True,
                     'rental_started': False})


if __name__ == '__main__':
    main()
