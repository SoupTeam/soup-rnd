"""Isolated tiny-file checkpoint mutants; no stage edits, GPU or network access."""

import hashlib
import importlib.util
import json
import socket
import tempfile
from pathlib import Path

from rich.console import Console

ROOT = Path(__file__).parent


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    controls = load(ROOT / "test_f14_independent_integrity.py", "f14_independent_controls")
    source = ROOT / "checkpoint_integrity.py"
    before_sha = hashlib.sha256(source.read_bytes()).hexdigest()
    same_size = (
        controls.test_same_size_wrong_sha_persists_actual_hash_before_repair_only_bad_file)
    final_recheck = (
        controls.test_valid_thirteen_shards_need_no_redownload_and_are_all_rechecked)
    actual_f8 = controls.test_actual_f8_official_map_and_prepared_fingerprint_remain_compatible
    cases = [
        ("third_forced_download_accepted", "MAX_FORCED_REDOWNLOADS = 2",
         "MAX_FORCED_REDOWNLOADS = 3",
         lambda tmp: controls.test_global_two_repair_budget_is_not_reset_per_bad_file(tmp)),
        ("same_size_wrong_sha_accepted", 'elif observed["observed_sha256"] != frozen[name][1]:',
         "elif False:",
         lambda tmp: same_size(tmp)),
        ("final_full_recheck_skipped", 'if phase != "final_recheck":', "if False:",
         lambda tmp: final_recheck(tmp)),
        ("wrong_native_prepare_fingerprint_accepted",
         'if actual_weights != {name: pair[1] for name, pair in expected.items()}:', "if False:",
         lambda tmp: controls.test_nf4_prepare_fingerprint_requires_every_original_official_sha(
             tmp, "prepared_sha")),
        ("official_pin_map_replaced", "if value != OFFICIAL_PIN_MAP_SHA256:", "if False:",
         lambda _tmp: actual_f8()),
    ]
    rows = []

    def blocked(*_args, **_kwargs):
        raise AssertionError("Mutation controls must never access the network")

    old_connect, old_connect_ex = socket.socket.connect, socket.socket.connect_ex
    try:
        socket.socket.connect = socket.socket.connect_ex = blocked
        for number, (name, old, new, test) in enumerate(cases):
            folder = Path(tempfile.mkdtemp(prefix="f14-mutant-" + name + "-", dir=ROOT))
            baseline = folder / "baseline"
            baseline.mkdir()
            controls.integrity = load(source, "original_integrity_" + str(number))
            test(baseline)
            text = source.read_text(encoding="utf-8")
            if text.count(old) != 1:
                raise ValueError("Mutation target is not unique: " + name)
            mutant = folder / "checkpoint_integrity.py"
            mutant.write_text(text.replace(old, new), encoding="utf-8")
            controls.integrity = load(mutant, "mutant_integrity_" + str(number))
            fixture = folder / "mutant"
            fixture.mkdir()
            killed = False
            try:
                test(fixture)
            except BaseException as error:
                killed = True
                reason = type(error).__name__ + ": " + str(error)[:300]
            rows.append({"name": name, "baseline_passed": True, "killed": killed,
                         "failure": reason if killed else None, "sandbox": str(folder)})
            if not killed:
                raise AssertionError("Mutant survived: " + name)
    finally:
        socket.socket.connect, socket.socket.connect_ex = old_connect, old_connect_ex
    if hashlib.sha256(source.read_bytes()).hexdigest() != before_sha:
        raise AssertionError("Original helper changed during isolated mutation tests")
    report = {"schema_version": 1, "status": "all_isolated_integrity_mutants_killed",
              "source_helper_sha256": before_sha, "network_access_forbidden": True,
              "stage_inputs_modified": False, "mutations": rows}
    (ROOT / "f14-independent-mutation-review.json").write_text(json.dumps(report, indent=2) + "\n")
    Console().print({"status": report["status"], "mutants": len(rows)})


if __name__ == "__main__":
    main()
