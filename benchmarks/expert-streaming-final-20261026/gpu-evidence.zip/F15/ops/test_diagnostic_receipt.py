"""Offline controls for the baseline-only receipt consumed by the combined audit."""

import json

import pytest

import remote_run


@pytest.fixture
def baseline(tmp_path, monkeypatch):
    monkeypatch.setattr(remote_run, 'ROOT', tmp_path)
    monkeypatch.setattr(remote_run, 'OUT', tmp_path / 'results')
    (tmp_path / 'results/profiles').mkdir(parents=True)
    (tmp_path / 'source-manifest.json').write_text(json.dumps({'source_commit': 'a' * 40}))
    spec = tmp_path / 'spec.json'
    spec.write_text('{"frozen":true}')
    protocol = {'performance': {
        'accuracy_arms': ['ordinary', 'two_read', 'two_read_cache'],
        'profile_arms': ['two_read', 'two_read_cache'],
        'profile_runner': 'benchmarks/harness/expert_cache_profile.py',
        'max_trace_bytes': 134217728,
    }}
    commands = []
    monkeypatch.setattr(remote_run, 'qualify_accuracy', lambda *_: {
        'status': 'accuracy_passed', 'accuracy_passed': True,
    })
    monkeypatch.setattr(remote_run, 'command', lambda name, *_args, **_kwargs:
                        commands.append(name))
    monkeypatch.setattr(remote_run, 'validate_profile_outputs',
                        lambda _directory, arm, *_args: {'arm': arm})
    monkeypatch.setattr(remote_run, 'compare_profiles', lambda *_: {'passed': True})
    return tmp_path / 'results', spec, protocol, commands


def test_completed_baseline_receipt_matches_auditor_without_claiming_candidate_timing(baseline):
    out, spec, protocol, commands = baseline
    reports = remote_run.accuracy_then_profiles(spec, protocol)
    receipt = json.loads((out / 'diagnostic-only.json').read_text())
    assert set(reports) == {'two_read', 'two_read_cache'}
    assert commands == ['profile-two_read', 'profile-two_read_cache']
    # These exact fields are required by ProfileAudit.execute in the combined audit.
    assert receipt['no_unprofiled_performance_verdict'] is True
    assert receipt['profiled_times_are_diagnostic_only'] is True
    assert receipt['source_commit'] == 'a' * 40
    assert receipt['spec_sha256'] == remote_run.digest(spec)
    assert receipt['scope'] == 'native_accuracy_and_baseline_profiles_only'
    assert receipt['separate_unprofiled_qualification'] == 'results/dispatch-qualification/run.json'
    assert receipt['accuracy_arms'] == ['ordinary', 'two_read', 'two_read_cache']
    assert receipt['profile_arms'] == ['two_read', 'two_read_cache']
    assert 'timing_summary' not in receipt
    order = json.loads((out / 'phase-order.json').read_text())['records']
    assert order[-1]['phase'] == 'cross_profile_comparison'
    assert order[-1]['status'] == 'completed'
    assert not (out / 'dispatch-qualification').exists()


@pytest.mark.parametrize('failure', ['accuracy', 'profile', 'comparison'])
def test_failed_baseline_cannot_emit_successful_diagnostic_receipt(baseline, monkeypatch, failure):
    out, spec, protocol, _commands = baseline
    if failure == 'accuracy':
        monkeypatch.setattr(remote_run, 'qualify_accuracy', lambda *_: {
            'status': 'failed', 'accuracy_passed': False,
        })
    elif failure == 'profile':
        def refuse(*_args):
            raise ValueError('profile incomplete')
        monkeypatch.setattr(remote_run, 'validate_profile_outputs', refuse)
    else:
        monkeypatch.setattr(remote_run, 'compare_profiles', lambda *_: {'passed': False})
    with pytest.raises(ValueError):
        remote_run.accuracy_then_profiles(spec, protocol)
    assert not (out / 'diagnostic-only.json').exists()
    assert not (out / 'dispatch-qualification').exists()
