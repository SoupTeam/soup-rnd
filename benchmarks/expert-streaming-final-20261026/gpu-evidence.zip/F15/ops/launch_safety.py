"""Pure local checks for the immutable combined Kanana F15 lease."""

from __future__ import annotations

import re

PURPOSE = 'ordinary streaming versus full two-read caches grouped routing, accuracy first'
PLAN = {'native_accuracy_phase_in_this_lease': False, 'large_profiles_in_this_lease': False, 'dispatch_qualification': True, 'timing_reference': 'ordinary_legacy', 'timing_candidate': 'grouped'}

MODEL = "kakaocorp/kanana-2-30b-a3b-base-2601"
REVISION = "0d31365acf656e5f9a593cacc4913e9c0d36cb1c"
KANANA_TEST = "tests/test_two_read_cache_kanana.py::test_real_cuda_nf4_bf16_kanana_worker_trajectories"
NF4_TEST = "tests/test_stream_expert_cache_nf4.py::test_real_cuda_nf4_expert_cache_preserves_complete_optimizer_trajectories"
GROUPED_TEST = "tests/test_expert_grouped_routes.py::test_real_cuda_nf4_bf16_grouped_route_worker_trajectories"
PROFILER_TEST = "tests/test_expert_cache_profile.py::test_real_cuda_profiler_collects_kernel_and_h2d_events"


STORAGE_CAPACITY_PLAN = {'schema_version': 1,
 'root_provider_gb': 32,
 'volume_provider_gb': 112,
 'advertised_combined_pool_required': 144,
 'minimum_pre_download_root_free_bytes': 17179869184,
 'minimum_pre_download_data_free_bytes': 107374182400,
 'data_components_bytes': {'official_bf16_weights': 61343935088,
                           'observed_nf4_store': 16624721373,
                           'conservative_uv_cache': 7763013632,
                           'one_fresh_bad_shard_temporary': 4999552848},
 'data_worst_case_bytes': 90731222941,
 'minimum_pre_prepare_data_free_bytes': 29387287853,
 'actual_statvfs_is_authoritative': True,
 'provider_gb_to_gib_conversion_assumed': False,
 'root_setup_evidence': {'f8/capacity-preflight.json': {'bytes': 2379,
                                                        'sha256': '5b03bb271bfeb76bb7f63ee557aa6e9bd393f08c924d19b05fb6a4cb1e55ba73'},
                         'f8/pre-download-disk.json': {'bytes': 195,
                                                       'sha256': 'ef7270e8fe4c4f10e5d79607a08a52457c2e80236befa25dda9e5b77fd13bf9d'},
                         'f14/capacity-preflight.json': {'bytes': 2622,
                                                         'sha256': '9cfae4c4712bbe9dbd24463dff6be94efbcdd3dbdf1bac8c4a86e1d243508176'},
                         'f14/pre-download-disk.json': {'bytes': 195,
                                                        'sha256': '4a62a752bb3ddef7911dae9189b66058c0cb85223c8805fa9174dd3d0cdb60be'}},
 'raw_outputs_reserve_is_unchanged': True,
 'full_bad_bf16_input_payload_retained': False,
 'root_components_bytes': {'raw_outputs_reserve': 12884901888,
                           'encoded_archive_reserve': 1500000000,
                           'transfer_probe': 100000000,
                           'scratch': 2147483648},
 'root_worst_case_output_bytes': 16632385536,
 'output_filesystem': 'root',
 'model_and_uv_cache_filesystem': 'data',
 'minimum_pre_prepare_root_free_bytes': 17179869184,
 'conservative_root_setup_allowance_bytes': 7763013632,
 'actual_root_setup_max_observed_bytes': 7460089856}


def validate_protocol(protocol, *, source_commit, stage_id):
    if (not re.fullmatch("[0-9a-f]{40}", source_commit)
            or protocol.get("source_commit") != source_commit
            or protocol.get("stage_id") != stage_id
            or protocol.get("accuracy_first") is not True
            or protocol.get("purpose") != PURPOSE):
        raise ValueError("Frozen final-comparison identity differs")
    if protocol.get("execution_plan") != PLAN:
        raise ValueError("Final execution plan changed")
    model = protocol.get("model", {})
    if (model.get("repo_id") != MODEL or model.get("revision") != REVISION
            or model.get("weight_shards") != 13 or model.get("weights_bytes") != 61343935088):
        raise ValueError("Pinned public Kanana checkpoint identity changed")
    selectors = protocol.get("cuda_test_selectors")
    expected_names = {KANANA_TEST.rsplit("::", 1)[-1], NF4_TEST.rsplit("::", 1)[-1] + "[lru]",
                      NF4_TEST.rsplit("::", 1)[-1] + "[static]", GROUPED_TEST.rsplit("::", 1)[-1]}
    if (not isinstance(selectors, list) or len(selectors) != 3
            or set(selectors) != {KANANA_TEST, NF4_TEST, GROUPED_TEST}
            or set(protocol.get("cuda_expected_case_names", [])) != expected_names):
        raise ValueError("All four actual CUDA/Kanana/NF4/grouped numerical cells are required before download")
    expected_performance = {
        "accuracy_runner": "benchmarks/harness/two_read_cache_worker.py",
        "accuracy_arms": ["ordinary", "two_read", "two_read_cache"],
        "profile_runner": "benchmarks/harness/expert_cache_profile.py",
        "profile_arms": ["two_read", "two_read_cache"],
        "profile_warmup_updates": 2, "profile_optimizer_updates": 1,
        "profile_first_microbatch_only": True, "unprofiled_context_updates": 1,
        "max_trace_bytes": 134217728, "host_cache_policy": "static",
        "host_cache_bytes": 8 * 2**30, "device_cache_bytes": 2 * 2**30,
        "accuracy_updates": 2, "accumulation": 2, "sequence_length": 512, "batch_size": 1,
        "prepare_native_timing_fields": {"rounds": 4, "warmup_updates": 2, "timed_updates": 6},
        "profiled_times_are_diagnostic_only": True,
        "dispatch_qualification": {"runner": "/root/liger/final_comparison.py",
            "accuracy_variants": ["ordinary_legacy", "legacy", "grouped"],
            "timing_variants": ["ordinary_legacy", "grouped"], "rounds": 4, "warmup_updates": 2,
            "timed_updates": 6, "accuracy_updates": 2, "timing_workers": 8,
            "grouped_expert_routes_default": False, "practical_lower_bound_percent": 2.0},
    }
    if protocol.get("performance") != expected_performance:
        raise ValueError("Frozen accuracy/profile/cache-ceiling protocol changed")
    if protocol.get("admission_fallback_allowed") is not False:
        raise ValueError("Cache admission must fail closed without a smaller-budget fallback")
    expected_boundary = {"physical_gpu_gib_class": 8, "max_ram_bytes": 32 * 2**30,
                         "swap_must_be_disabled": True,
                         "minimum_data_free_bytes": 100 * 2**30,
                         "minimum_root_free_bytes": 16 * 2**30}
    if protocol.get("native_boundary") != expected_boundary:
        raise ValueError("Physical8GB/native32GiB/no-swap/disk reserve boundary changed")
    expected_financial = {"maximum_stage_usd": 3.0, "prior_usd": 0,
                          "maximum_seconds": 14400, "root_provider_gb": 32,
                          "volume_provider_gb": 112, "download_allowance_decimal_gb": 90,
                          "upload_allowance_decimal_gb": 2}
    if protocol.get("financial") != expected_financial:
        raise ValueError("Frozen 4-hour 3USD budget/disk/network boundary changed")
    if protocol.get("storage_capacity_plan") != STORAGE_CAPACITY_PLAN:
        raise ValueError("Justified root32/volume112 capacity plan changed")
    expected_integrity = {
        "helper": "checkpoint_integrity.py", "official_shards": 13,
        "official_sha256_required": True, "fresh_bad_shard_redownload_global_limit": 2,
        "expected_metadata_immutable": True, "full_final_recheck_required": True,
        "prepared_model_fingerprint_must_match_official_shas": True,
        "hub_version": "1.33.0", "force_download": True,
        "failed_f13_sha_gate": "FAILED and retained separately; no acceptance relaxation"}
    if protocol.get("checkpoint_input_integrity") != expected_integrity:
        raise ValueError("Official checkpoint integrity/repair boundary changed")
    expected_transport = {'implementation': 'native OpenSSH binary stdin/stdout',
                          'upload': 'atomic byte/SHA verified and fsynced before rename',
                          'probe_bytes': 262144, 'raw_python_tcp_or_sftp_allowed': False,
                          'route_selection': 'API-supplied proxy and direct only; actual owned container identity before selecting verified route; no host-key bypass'}
    if protocol.get('transport') != expected_transport:
        raise ValueError('Native verified binary transport preflight boundary changed')
    retention = protocol.get("retention", {})
    if (retention.get("format") != "soup-lossless-results-v1"
            or retention.get("encoded_estimate_bytes") != 1500000000
            or retention.get("raw_estimate_bytes") != 12 * 2**30
            or retention.get("actual_encoded_export_size_is_authoritative") is not True):
        raise ValueError("Complete result retention estimate/proof changed")
    return {"source_commit": source_commit, "model": MODEL, "revision": REVISION,
            "accuracy_arms": expected_performance["accuracy_arms"],
            "profile_arms": expected_performance["profile_arms"], "cuda_cells": 4,
            "performance_verdict": "baseline profiles diagnostic only; dispatch paired timing separate"}
