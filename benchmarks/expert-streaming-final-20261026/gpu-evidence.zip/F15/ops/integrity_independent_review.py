"""Independent tiny-file checkpoint integrity/repair controls; no external network."""

import ast
import copy
import hashlib
import json
import socket
from pathlib import Path

import checkpoint_integrity as integrity
import pytest


@pytest.fixture(autouse=True)
def forbid_actual_network(monkeypatch):
    def blocked(*_args, **_kwargs):
        raise AssertionError("Independent integrity controls must never access an actual network")

    monkeypatch.setattr(socket.socket, "connect", blocked)
    monkeypatch.setattr(socket.socket, "connect_ex", blocked)


def sha(payload):
    return hashlib.sha256(payload).hexdigest()


def fixture(tmp_path):
    root = tmp_path / "weights"
    root.mkdir()
    content = {f"model-{index:05d}-of-00013.safetensors": f"official-shard-{index:02d}".encode()
               for index in range(1, 14)}
    pins = {name: {"bytes": len(payload), "sha256": sha(payload)}
            for name, payload in content.items()}
    for name, payload in content.items():
        (root / name).write_bytes(payload)
    return root, content, pins, tmp_path / "checkpoint-integrity.json"


def verify(root, pins, path, download):
    return integrity.verify_checkpoint(root, pins, path, download,
        repo_id="kakaocorp/kanana-2-30b-a3b-base-2601",
        revision="0d31365acf656e5f9a593cacc4913e9c0d36cb1c")


def corrupt(root, content, number=12):
    name = f"model-{number:05d}-of-00013.safetensors"
    payload = bytes([content[name][0] ^ 1]) + content[name][1:]
    (root / name).write_bytes(payload)
    return name, payload


def test_valid_thirteen_shards_need_no_redownload_and_are_all_rechecked(tmp_path):
    root, content, pins, path = fixture(tmp_path)
    calls = []
    result = verify(root, pins, path, lambda name: calls.append(name))
    assert result["status"] == "passed" and result["all_shards_verified"] is True
    assert result["expected_files"] == 13 and result["final_verified_files"] == pins
    assert result["forced_redownloads_used"] == 0 and calls == []
    complete = [row for row in result["events"] if row["event"] == "hash_completed"]
    assert len(complete) == 26
    assert {row["filename"] for row in complete if row["phase"] == "initial"} == set(content)
    assert {row["filename"] for row in complete if row["phase"] == "final_recheck"} == set(content)
    assert all(row["passed"] and row["observed_sha256"] == pins[row["filename"]]["sha256"]
               and row["observed_bytes"] == pins[row["filename"]]["bytes"] for row in complete)


def test_same_size_wrong_sha_persists_actual_hash_before_repair_only_bad_file(tmp_path):
    root, content, pins, path = fixture(tmp_path)
    bad, payload = corrupt(root, content)
    calls = []

    def download(name):
        calls.append(name)
        before = json.loads(path.read_text())
        hashes = [row for row in before["events"] if row["event"] == "hash_completed"]
        assert len(hashes) == 13
        row = next(row for row in hashes if row["filename"] == bad)
        assert row["observed_sha256"] == sha(payload) != row["expected_sha256"]
        assert row["observed_bytes"] == row["expected_bytes"]
        assert row["error_category"] == "sha256_mismatch" and row["passed"] is False
        assert before["events"][-1]["event"] == "forced_download_started"
        (root / name).write_bytes(content[name])
        return root / name

    result = verify(root, pins, path, download)
    assert result["status"] == "passed" and result["final_verified_files"] == pins
    assert calls == [bad] and result["forced_redownloads_used"] == 1
    assert result["helper_sha256"] == sha(Path(integrity.__file__).read_bytes())
    assert Path(result["helper_path"]).is_file()
    assert result["full_bad_payload_retained"] is False


def test_global_two_repair_budget_is_not_reset_per_bad_file(tmp_path):
    root, content, pins, path = fixture(tmp_path)
    bad = [corrupt(root, content, number)[0] for number in (1, 2, 3)]
    calls = []

    def download(name):
        calls.append(name)
        (root / name).write_bytes(content[name])
        return root / name

    with pytest.raises(integrity.CheckpointIntegrityError):
        verify(root, pins, path, download)
    result = json.loads(path.read_text())
    assert result["status"] == "failed" and result["all_shards_verified"] is False
    assert calls == bad[:2] and result["forced_redownloads_used"] == 2
    initial = [row for row in result["events"]
               if row["event"] == "hash_completed" and row["phase"] == "initial"]
    assert len(initial) == 13 and sum(not row["passed"] for row in initial) == 3


def test_repeated_bad_bytes_never_pass_and_both_actual_hashes_are_retained(tmp_path):
    root, content, pins, path = fixture(tmp_path)
    bad, payload = corrupt(root, content)
    calls = []

    def download(name):
        calls.append(name)
        return root / name

    with pytest.raises(integrity.CheckpointIntegrityError):
        verify(root, pins, path, download)
    result = json.loads(path.read_text())
    assert result["status"] == "failed" and calls == [bad, bad]
    post = [row for row in result["events"]
            if row["event"] == "hash_completed" and row["phase"] == "post_redownload"]
    assert len(post) == 2 and all(row["observed_sha256"] == sha(payload) for row in post)
    assert result["final_verified_files"] == {}


def test_callback_cannot_replace_expected_official_metadata_even_with_same_length(tmp_path):
    root, content, pins, path = fixture(tmp_path)
    frozen = copy.deepcopy(pins)
    bad, payload = corrupt(root, content)

    def download(name):
        pins[name]["sha256"] = sha(payload)
        return root / name

    with pytest.raises(integrity.CheckpointIntegrityError):
        verify(root, pins, path, download)
    result = json.loads(path.read_text())
    assert result["status"] == "failed" and result["expected_pins"] == frozen
    initial_bad = [row for row in result["events"]
                   if row["event"] == "hash_completed" and row["filename"] == bad]
    assert initial_bad[0]["observed_sha256"] == sha(payload)
    assert result["all_shards_verified"] is False


def test_wrong_returned_path_does_not_adopt_another_good_file(tmp_path):
    root, content, pins, path = fixture(tmp_path)
    bad, _ = corrupt(root, content)
    replacement = tmp_path / "another-file.safetensors"
    replacement.write_bytes(content[bad])
    with pytest.raises(integrity.CheckpointIntegrityError):
        verify(root, pins, path, lambda _name: replacement)
    result = json.loads(path.read_text())
    assert result["status"] == "failed"
    assert result["events"][-1]["error_category"] == "wrong_returned_path"


def test_repair_cannot_hide_corruption_of_an_earlier_good_shard(tmp_path):
    root, content, pins, path = fixture(tmp_path)
    bad, _ = corrupt(root, content)
    calls = []

    def download(name):
        calls.append(name)
        if name == bad:
            (root / name).write_bytes(content[name])
            corrupt(root, content, 1)
        return root / name

    with pytest.raises(integrity.CheckpointIntegrityError):
        verify(root, pins, path, download)
    result = json.loads(path.read_text())
    first = "model-00001-of-00013.safetensors"
    assert calls == [bad, first] and result["status"] == "failed"
    assert any(row["event"] == "hash_completed" and row["phase"] == "final_recheck"
               and row["filename"] == first and row["passed"] is False
               for row in result["events"])


def test_size_mismatch_keeps_the_actual_full_sha_before_repair(tmp_path):
    root, content, pins, path = fixture(tmp_path)
    bad = "model-00012-of-00013.safetensors"
    changed = content[bad] + b"EXTRA"
    (root / bad).write_bytes(changed)

    def download(name):
        before = json.loads(path.read_text())
        row = next(row for row in before["events"]
                   if row["event"] == "hash_completed" and row["filename"] == bad)
        assert row["error_category"] == "size_mismatch"
        assert row["observed_sha256"] == sha(changed) and row["observed_bytes"] == len(changed)
        (root / name).write_bytes(content[name])
        return root / name

    assert verify(root, pins, path, download)["status"] == "passed"


def test_realpath_containment_refuses_a_redirected_foreign_checkpoint_path(tmp_path, monkeypatch):
    root, _, pins, path = fixture(tmp_path)
    bad = root / "model-00012-of-00013.safetensors"
    original = integrity.os.path.realpath

    def redirect(value):
        return str(tmp_path / "outside.safetensors") if Path(value) == bad else original(value)

    monkeypatch.setattr(integrity.os.path, "realpath", redirect)
    with pytest.raises(integrity.CheckpointIntegrityError):
        verify(root, pins, path, lambda _name: None)
    assert json.loads(path.read_text())["status"] == "failed"


def test_symbolic_link_marker_is_refused_even_when_it_resolves_inside_root(tmp_path, monkeypatch):
    root, _, pins, path = fixture(tmp_path)
    bad = root / "model-00012-of-00013.safetensors"
    original = Path.is_symlink
    monkeypatch.setattr(Path, "is_symlink", lambda value: value == bad or original(value))
    with pytest.raises(integrity.CheckpointIntegrityError):
        verify(root, pins, path, lambda _name: None)
    assert json.loads(path.read_text())["status"] == "failed"


def test_failed_network_download_keeps_previous_observed_hash_and_failed_receipt(tmp_path):
    root, content, pins, path = fixture(tmp_path)
    bad, payload = corrupt(root, content)

    def download(_name):
        raise TimeoutError("fixture transport failed")

    with pytest.raises(integrity.CheckpointIntegrityError):
        verify(root, pins, path, download)
    result = json.loads(path.read_text())
    assert result["status"] == "failed" and result["forced_redownloads_used"] == 1
    assert result["events"][-1]["event"] == "forced_download_failed"
    assert any(row["filename"] == bad and row["observed_sha256"] == sha(payload)
               for row in result["events"])


@pytest.mark.parametrize("corruption", ["prepared_sha", "missing", "receipt_sha", "not_passed"])
def test_nf4_prepare_fingerprint_requires_every_original_official_sha(tmp_path, corruption):
    root, _, pins, path = fixture(tmp_path)
    result = verify(root, pins, path, lambda _name: None)
    spec = {"model_fingerprint": {name: row["sha256"] for name, row in pins.items()}}
    integrity.verify_prepared_fingerprint(spec, result, pins)
    first = next(iter(pins))
    if corruption == "prepared_sha":
        spec["model_fingerprint"][first] = "a" * 64
    elif corruption == "missing":
        spec["model_fingerprint"].pop(first)
    elif corruption == "receipt_sha":
        result["final_verified_files"][first]["sha256"] = "b" * 64
    else:
        result["status"] = "failed"
    with pytest.raises(integrity.CheckpointIntegrityError):
        integrity.verify_prepared_fingerprint(spec, result, pins)


@pytest.mark.parametrize("bad_name", ["../outside.safetensors", "/outside.safetensors",
                                     "subdir/file.safetensors", "subdir\\file.safetensors"])
def test_pinned_filename_cannot_escape_weights_directory(tmp_path, bad_name):
    with pytest.raises(integrity.CheckpointIntegrityError):
        verify(tmp_path, {bad_name: {"bytes": 1, "sha256": "a" * 64}},
               tmp_path / "receipt.json", lambda _name: None)


def test_actual_installed_hub_force_replaces_cached_and_partial_bytes_without_network(tmp_path):
    result = integrity.verify_hub_force_semantics(tmp_path / "hub-control")
    assert result["passed"] is True and result["hub_version"] == "1.33.0"
    assert result["cached_destination_replaced"] is True and result["resume_size"] == 0
    assert result["fresh_stream_position"] == 0 and result["real_network_invoked"] is False
    assert result["http_function_restored"] is True


STAGE = Path(r"C:\Users\esenb\Documents\SoupResearch\kanana-30b-final-gpu-20261026-f15")


def test_actual_remote_force_callback_is_fixed_to_same_model_revision_and_target(
    tmp_path, monkeypatch,
):
    import huggingface_hub

    source = ast.parse((STAGE / "remote_run.py").read_text(encoding="utf-8"))
    function = next(node for node in ast.walk(source)
                    if isinstance(node, ast.FunctionDef) and node.name == "fresh_pinned_shard")
    calls = []

    def download(**kwargs):
        calls.append(kwargs)
        return str(tmp_path / kwargs["filename"])

    monkeypatch.setattr(huggingface_hub, "hf_hub_download", download)
    namespace = {"hf_hub_download": download,
                 "MODEL": "kakaocorp/kanana-2-30b-a3b-base-2601",
                 "REVISION": "0d31365acf656e5f9a593cacc4913e9c0d36cb1c",
                 "weights": str(tmp_path),
                 "pins": {"model-00012-of-00013.safetensors": {}}}
    exec(compile(ast.Module(body=[function], type_ignores=[]), str(STAGE / "remote_run.py"),
                 "exec"), namespace)
    name = "model-00012-of-00013.safetensors"
    assert namespace["fresh_pinned_shard"](name) == str(tmp_path / name)
    assert calls == [{"repo_id": namespace["MODEL"], "revision": namespace["REVISION"],
                      "filename": name, "local_dir": str(tmp_path),
                      "force_download": True, "local_files_only": False}]


def test_remote_declares_upload_and_export_of_the_actual_checkpoint_helper():
    controller = ast.parse((STAGE / "controller.py").read_text(encoding="utf-8"))
    required = next(node.value for node in controller.body if isinstance(node, ast.Assign)
                    and any(isinstance(target, ast.Name) and target.id == "REQUIRED"
                            for target in node.targets))
    assert "checkpoint_integrity.py" in ast.literal_eval(required)
    remote = ast.parse((STAGE / "remote_run.py").read_text(encoding="utf-8"))
    export = next(node for node in remote.body
                  if isinstance(node, ast.FunctionDef) and node.name == "export")
    assert any(isinstance(node, ast.Constant) and node.value == "checkpoint_integrity.py"
               for node in ast.walk(export))
    main = next(node for node in remote.body
                if isinstance(node, ast.FunctionDef) and node.name == "main")
    calls = [node for node in ast.walk(main) if isinstance(node, ast.Call)]
    def line(method):
        return next(node.lineno for node in calls
                    if isinstance(node.func, ast.Attribute) and node.func.attr == method)
    prepare = next(node.lineno for node in calls
                   if isinstance(node.func, ast.Name) and node.func.id == "command"
                   and node.args and isinstance(node.args[0], ast.Constant)
                   and node.args[0].value == "prepare")
    snapshot = next(node.lineno for node in calls
                    if isinstance(node.func, ast.Name) and node.func.id == "snapshot_download")
    assert line("validate_official_pins") < snapshot < line("verify_checkpoint")
    assert line("verify_checkpoint") < prepare < line("verify_prepared_fingerprint")
    text = (STAGE / "remote_run.py").read_text(encoding="utf-8")
    assert "helper_path != Path(os.path.realpath(expected_helper))" in text
    assert "launch['files']['checkpoint_integrity.py']['sha256']" in text


def test_actual_f8_official_map_and_prepared_fingerprint_remain_compatible():
    old = STAGE.with_name("kanana-30b-dispatch-gpu-20261026-f8") / "retained/results"
    pinned = json.loads((old / "model-pinned.json").read_text())
    spec = json.loads((old / "prepared/spec.json").read_text())
    pins = {name: {"bytes": row["bytes"], "sha256": row["lfs"]["sha256"]}
            for name, row in pinned["files"].items()}
    assert integrity.validate_official_pins(pins) == integrity.OFFICIAL_PIN_MAP_SHA256
    verified = {"status": "passed", "all_shards_verified": True, "final_verified_files": pins}
    assert integrity.verify_prepared_fingerprint(spec, verified, pins)["files"] == 13
    first = next(iter(pins))
    pins[first]["sha256"] = "a" * 64
    with pytest.raises(integrity.CheckpointIntegrityError):
        integrity.validate_official_pins(pins)
