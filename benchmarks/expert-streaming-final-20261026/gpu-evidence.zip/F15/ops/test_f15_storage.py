"""Offline disk admission controls; numerical, RAM and swap requirements stay fixed."""

import copy
import json
from pathlib import Path
from types import SimpleNamespace

import cloud
import pytest
import remote_run
from launch_safety import validate_protocol

ROOT = Path(__file__).parent


def protocol():
    return json.loads((ROOT / "protocol.json").read_text())


def test_justified_plan_and_actual_old_volume_units():
    value = protocol()
    plan = value["storage_capacity_plan"]
    proof = json.loads((ROOT / "storage-capacity-plan.json").read_text())
    assert plan == proof["plan"]
    assert cloud.DISK_GB == 32 and cloud.VOLUME_GB == 112
    assert plan["advertised_combined_pool_required"] == 144
    assert sum(plan["data_components_bytes"].values()) == plan["data_worst_case_bytes"]
    assert plan["data_worst_case_bytes"] <= 100 * 2**30 < 112 * 2**30
    assert proof["evidence"]["f8/pre-download-disk.json"]["observed"][
        "data_free_bytes"] == 150 * 2**30
    assert plan["provider_gb_to_gib_conversion_assumed"] is False
    assert plan["actual_statvfs_is_authoritative"] is True
    assert sum(plan["root_components_bytes"].values()) < 16 * 2**30
    assert plan["output_filesystem"] == "root"
    for field in ("physical_gpu_gib_class", "max_ram_bytes", "swap_must_be_disabled"):
        previous = json.loads((ROOT.with_name(
            "kanana-30b-final-gpu-20261026-f14") / "protocol.json").read_text())
        assert value["native_boundary"][field] == previous["native_boundary"][field]


@pytest.mark.parametrize("section,component", [
    (section, component) for section in ("data_components_bytes", "root_components_bytes")
    for component in protocol()["storage_capacity_plan"][section]
])
def test_frozen_capacity_components_cannot_be_silently_reduced(section, component):
    value = protocol()
    value["storage_capacity_plan"][section][component] -= 1
    with pytest.raises(ValueError, match="capacity plan"):
        validate_protocol(value, source_commit=value["source_commit"], stage_id=cloud.STAGE)


@pytest.mark.parametrize("root_delta,data_delta,passes", [(0, 0, True), (-1, 0, False),
                                                          (0, -1, False)])
def test_actual_remaining_disk_gate_is_exact_and_retains_failure(
        tmp_path, monkeypatch, root_delta, data_delta, passes):
    value = protocol()
    required = value["storage_capacity_plan"]["minimum_pre_prepare_data_free_bytes"]
    monkeypatch.setattr(remote_run, "ROOT", tmp_path)
    monkeypatch.setattr(remote_run, "OUT", tmp_path)
    monkeypatch.setattr(remote_run.shutil, "disk_usage", lambda path: SimpleNamespace(
        free=16 * 2**30 + root_delta if path == tmp_path else required + data_delta))
    if passes:
        assert remote_run.pre_prepare_disk_gate(value)["passed"]
    else:
        with pytest.raises(RuntimeError, match="reserve is insufficient"):
            remote_run.pre_prepare_disk_gate(value)
    receipt = json.loads((tmp_path / "pre-prepare-disk.json").read_text())
    assert receipt["passed"] is passes
    assert receipt["minimum_data_bytes"] == required
    assert len(receipt["capacity_plan_sha256"]) == 64


def test_remaining_plan_identity_cannot_be_mutated_consistently_with_a_larger_weight_assumption():
    value = copy.deepcopy(protocol())
    value["storage_capacity_plan"]["minimum_pre_prepare_data_free_bytes"] -= 1
    with pytest.raises(RuntimeError, match="plan differs"):
        remote_run.pre_prepare_disk_gate(value)


@pytest.mark.parametrize("pool,passes", [(146, True), (144, True), (143.999, False)])
def test_root_and_local_volume_must_fit_same_advertised_pool(pool, passes):
    offer = {"num_gpus": 1, "gpu_frac": 1, "gpu_ram": 8188,
             "cpu_ram": 31741, "compute_cap": 890, "disk_space": pool}
    if passes:
        cloud.validate_full_host(offer)
    else:
        with pytest.raises(ValueError, match="combined pool"):
            cloud.validate_full_host(offer)
