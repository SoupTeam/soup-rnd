"""Independent cold-process controls; synthetic data only, no GPU or provider calls."""

from __future__ import annotations

import ast
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

PREP = Path(__file__).parent
OPS = PREP.parent / "kanana-30b-final-gpu-20261026-f9"
SOURCE = Path(r"C:\Users\esenb\.codex\worktrees\expert-dispatch-opt-20261026\soup-rnd-d2")
DEPS = PREP.parent / "kanana-30b-dispatch-gpu-20261026-f8" / ".deps"


def assignment(path: Path, name: str):
    """Read literal deployment constants without importing provider-capable modules."""
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(
            isinstance(target, ast.Name) and target.id == name for target in node.targets
        ):
            value = node.value
            if isinstance(value, ast.Call) and isinstance(value.func, ast.Name):
                assert value.func.id == "frozenset" and len(value.args) == 1
                return frozenset(ast.literal_eval(value.args[0]))
            return ast.literal_eval(value)
    raise AssertionError(f"Missing literal deployment constant {name}")


def test_all_required_remote_inputs_are_uploadable_without_widening_path_scope() -> None:
    required = set(assignment(OPS / "controller.py", "REQUIRED"))
    allowed = assignment(OPS / "transport.py", "UPLOAD_ALLOWLIST")
    assert required <= allowed, f"Required inputs refused by transport: {required - allowed}"
    assert "final_comparison.py" in required
    assert "launch-manifest.json" in allowed
    assert all(Path(name).name == name and "/" not in name and "\\" not in name
               and name not in {".", "..", "ssh-key", "vast_api_key"}
               for name in allowed)


def test_private_wrapper_is_frozen_verified_deployed_and_retained() -> None:
    required = set(assignment(OPS / "controller.py", "REQUIRED"))
    manifest = json.loads((OPS / "launch-manifest.json").read_text(encoding="utf-8"))
    assert required <= manifest["files"].keys()
    wrapper = OPS / "final_comparison.py"
    frozen = manifest["files"][wrapper.name]
    assert frozen["bytes"] == wrapper.stat().st_size
    assert frozen["sha256"] == hashlib.sha256(wrapper.read_bytes()).hexdigest()
    assert wrapper.read_bytes() == (PREP / wrapper.name).read_bytes()
    controller = (OPS / "controller.py").read_text(encoding="utf-8")
    assert "for name in REQUIRED:" in controller and "_verify_remote_inputs(REQUIRED)" in controller
    remote = ast.parse((OPS / "remote_run.py").read_text(encoding="utf-8"))
    export = next(node for node in remote.body if isinstance(node, ast.FunctionDef)
                  and node.name == "export")
    assert any(isinstance(node, ast.Constant) and node.value == "final_comparison.py"
               for node in ast.walk(export)), "Private execution source omitted from retention"


@pytest.mark.parametrize("remove_initialization", [False, True])
def test_remote_final_summary_initializes_wrapper_in_cold_process(
    tmp_path: Path, remove_initialization: bool,
) -> None:
    """Real recomputation passes cold; removing configure must fail without any rental."""
    sys.path.insert(0, str(PREP))
    fixture_spec = importlib.util.spec_from_file_location(
        "independent_final_fixture", PREP / "test_final_comparison.py")
    fixture = importlib.util.module_from_spec(fixture_spec)
    fixture_spec.loader.exec_module(fixture)
    blocks = fixture.blocks()
    final = fixture.final
    result = {
        "status": "completed", "accuracy_passed": True,
        "source_commit": final.SOURCE_COMMIT,
        "timing_blocks": blocks,
        "timing_summary": final.timing_summary(blocks, fixture.COMMON),
        "accuracy": {},
    }
    for variant in ("ordinary_legacy", "legacy", "grouped"):
        result["accuracy"][variant] = {
            "capture_controls": {"passed": True,
                "adapters_nonzero_changed_and_nonzero_gradients": 288,
                "updates": 2, "microbatches": 4},
        }
    result["accuracy"]["legacy"]["versus_ordinary_legacy"] = {"passed": True}
    result["accuracy"]["grouped"]["versus_ordinary_legacy"] = {"passed": True}
    result["accuracy"]["grouped"]["versus_legacy"] = {"passed": True}
    spec_path = tmp_path / "spec.json"
    spec_path.write_text("{}", encoding="utf-8")
    result["spec_sha256"] = fixture.q.digest(spec_path)
    directory = tmp_path / "qualification"
    directory.mkdir()
    (directory / "run.json").write_text(json.dumps(result), encoding="utf-8")
    (tmp_path / "source-manifest.json").write_text(
        json.dumps({"source_commit": final.SOURCE_COMMIT}), encoding="utf-8")
    (tmp_path / "results").mkdir()
    payload = (OPS / "remote_run.py").read_text(encoding="utf-8")
    needle = "    grouped.configure(REPO)\n"
    assert payload.count(needle) == 1, "Final remote parent needs exactly one explicit init"
    if remove_initialization:
        payload = payload.replace(needle, "")
    remote = tmp_path / "remote_under_test.py"
    remote.write_text(payload, encoding="utf-8")
    child = """
import importlib.util
import sys
from pathlib import Path
sys.path[:0] = [sys.argv[1], sys.argv[2]]
import final_comparison
assert final_comparison.QUALIFIER is None, 'Wrapper must be cold before validator'
spec = importlib.util.spec_from_file_location('actual_remote_parent', sys.argv[3])
remote = importlib.util.module_from_spec(spec)
spec.loader.exec_module(remote)
remote.ROOT = Path(sys.argv[4])
remote.REPO = Path(sys.argv[5])
remote.OUT = remote.ROOT / 'results'
proof = remote.validate_dispatch_outputs(remote.ROOT / 'qualification', remote.ROOT / 'spec.json')
assert proof['status'] == 'verified'
assert final_comparison.QUALIFIER is not None
"""
    environment = os.environ.copy()
    environment["PYTHONPATH"] = str(DEPS)
    completed = subprocess.run(
        [sys.executable, "-c", child, str(OPS), str(DEPS), str(remote),
         str(tmp_path), str(SOURCE)],
        env=environment, capture_output=True, text=True, timeout=60, check=False,
    )
    if remove_initialization:
        assert completed.returncode != 0
        assert "NoneType" in completed.stderr and "require" in completed.stderr
    else:
        assert completed.returncode == 0, completed.stderr
        proof = json.loads((tmp_path / "results" / "dispatch-validation.json").read_text())
        assert proof["timing_workers"] == 8
        assert proof["recomputed_timing_summary"]["reference_variant"] == "ordinary_legacy"
        assert proof["recomputed_timing_summary"]["candidate_variant"] == "grouped"
