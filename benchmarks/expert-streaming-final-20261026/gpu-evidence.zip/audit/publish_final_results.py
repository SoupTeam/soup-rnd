"""Prepare final-study artifacts after full independent audits and exact cleanup.

This script never rents resources, changes Git, or publishes to GitHub. Failed,
missing or mismatched audit/retention evidence prevents creation of a report.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import re
import statistics
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path
from typing import Any

PREP = Path(__file__).parent
RESEARCH = PREP.parent
SOURCE = "43cf0b34afe0d8850d76bf86d60663ab5c85cdb2"
STAGE_ID = "soup-kanana-30b-final-20261026-f15"
STAGE_TAG = "F15"
WRAPPER = "de941d3b016b5941a3c36f01e49df5d1bffd8f1c68a9fe740e2b86ad4c34fe6f"
SOURCE_ARCHIVE = "0062717d0c9512649a9971c41a3918c9323f41516cdef47e21220f32e485bd71"
F14_INFRA_AUDITOR = "e8014ed199e3f73674ad7110bd6f6e75c7ef8e0fd016e67c6b0f4c3bd0ab40f8"
FAILED_COSTS = {"f10": .32485022243101314, "f11": .375203967960521,
                "f12": .46872694519811453, "f13": .5978399936107378, "f14": .649492666241615}
AUDITOR_HASHES = {
    "audit_final_comparison.py":
        "15d64f4289d3763801d9a296bbd96a7482b9eb8073676a48a1a615e5e15f38d5",
    "audit_final_infrastructure.py":
        "6c2eed12596fd76e49bca74ba214d506032339138915d17e88195640bc783bf6"}
MODEL = "kakaocorp/kanana-2-30b-a3b-base-2601"
MODEL_REVISION = "0d31365acf656e5f9a593cacc4913e9c0d36cb1c"
VARIANTS = ("ordinary_legacy", "grouped")
GIB = 2**30
MAX_ZIP = 5000 * 1024  # Repository check-added-large-files --maxkb=5000.
TENSOR_PACKET_LIMIT = 64 * 2**10


def require(condition: Any, message: str) -> None:
    if not condition:
        raise ValueError(message)


def read(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def encoded(value: Any) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n").encode()


def sha(path: Path) -> str:
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 2**20), b""):
            result.update(chunk)
    return result.hexdigest()


def contained(root: Path, name: str) -> Path:
    base = os.path.realpath(root)
    path = Path(os.path.realpath(os.path.join(base, name)))
    require(os.path.normcase(os.path.commonpath((base, path))) == os.path.normcase(base),
            "Evidence escapes its retained root")
    require(path.is_file() and not (root / name).is_symlink(), "Nonordinary evidence path")
    return path


def check_private(value: bytes, secrets: tuple[bytes, ...]) -> None:
    require(not any(secret and secret in value for secret in secrets),
            "An exact private credential appears in publication input")
    require(re.search(rb"-----BEGIN [A-Z ]*PRIVATE KEY-----", value) is None,
            "Private-key material appears in publication input")
    try:
        parsed = json.loads(value)
    except (ValueError, UnicodeDecodeError):
        return

    def visit(item: Any) -> None:
        if isinstance(item, dict):
            for key, child in item.items():
                sensitive = str(key).lower() in {
                    "api_key", "apikey", "container_api_key", "authorization", "password",
                    "access_token", "refresh_token", "hf_token", "private_key",
                }
                if sensitive:
                    require(child in (None, "", "[redacted]", "REDACTED"),
                            "Nonempty credential field in publication JSON")
                visit(child)
        elif isinstance(item, list):
            for child in item:
                visit(child)

    visit(parsed)


def write_packet(path: Path, entries: list[tuple[str, bytes, str]]) -> dict[str, Any]:
    """Exact bytes with complete-byte alias comparisons and restoration checks."""
    index: dict[str, Any] = {"schema_version": 1, "format": "exact-byte-content-aliases-v1",
                             "files": {}}
    canonical: dict[tuple[int, str], tuple[str, bytes]] = {}
    originals: dict[str, bytes] = {}
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, value, provenance in entries:
            require(name not in originals and name != "files.json"
                    and not name.startswith(("/", "\\")) and ".." not in Path(name).parts,
                    "Duplicate or unsafe packet member")
            originals[name] = value
            key = (len(value), hashlib.sha256(value).hexdigest())
            if key in canonical:
                member, prior = canonical[key]
                require(prior == value, "Alias hash candidate differs in complete bytes")
            else:
                member = name
                canonical[key] = (name, value)
                item = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
                item.compress_type = zipfile.ZIP_DEFLATED
                archive.writestr(item, value, compresslevel=9)
            index["files"][name] = {"member": member, "bytes": key[0], "sha256": key[1],
                                     "provenance": provenance}
        raw_index = encoded(index)
        archive.writestr("files.json", raw_index)
    require(path.stat().st_size <= MAX_ZIP,
            "Complete evidence exceeds repository 5000 KiB limit; no files dropped")
    with zipfile.ZipFile(path) as archive:
        require(len(archive.namelist()) == len(set(archive.namelist()))
                and set(archive.namelist()) == {row[0] for row in canonical.values()}
                | {"files.json"}, "Archive member set differs")
        require(archive.read("files.json") == raw_index, "Restoration index changed")
        for name, row in index["files"].items():
            restored = archive.read(row["member"])
            require(restored == originals[name] and len(restored) == row["bytes"]
                    and hashlib.sha256(restored).hexdigest() == row["sha256"],
                    "Restored logical evidence differs")
    return {"bytes": path.stat().st_size, "sha256": sha(path),
            "index_sha256": hashlib.sha256(raw_index).hexdigest(),
            "logical_originals": len(originals), "stored_members": len(canonical),
            "aliases": len(originals) - len(canonical),
            "all_aliases_full_byte_compared": True, "all_originals_restore_verified": True}


def verify_audits(stage: Path, numerical: dict, infrastructure: dict) -> dict:
    require(numerical.get("status") == "passed_independent_final_numerical_timing_audit",
            "Full independent numerical/timing audit has not passed")
    require(infrastructure.get("status")
            == "passed_final_infrastructure_retention_cleanup_audit",
            "Full independent infrastructure/retention/cleanup audit has not passed")
    require(infrastructure.get("audit_version") == 5,
            "F15 requires the independent v5 capacity/integrity infrastructure audit")
    require(infrastructure.get("source_commit") == SOURCE
            and infrastructure.get("stage_id") == STAGE_ID and infrastructure.get("checks"),
            "Infrastructure audit identity/controls differ")
    for report, name in ((numerical, "audit_final_comparison.py"),
                         (infrastructure, "audit_final_infrastructure.py")):
        require(AUDITOR_HASHES[name] is not None,
                "The independently reviewed v5 infrastructure auditor is not frozen")
        require(report.get("audit_script_sha256") == sha(PREP / name) == AUDITOR_HASHES[name],
                "Executed independent auditor source changed")
        require(report.get("archive_manifest_sha256") == sha(stage / "archive-manifest.json"),
                "Independent audit is not bound to this retained archive")
        require(report.get("bundle_verified_sha256") == sha(stage / "bundle-verified.json"),
                "Independent audit is not bound to this verified retention receipt")
    run_path = stage / "retained/results/dispatch-qualification/run.json"
    require(numerical.get("qualification_run_sha256") == sha(run_path)
            and infrastructure.get("qualification_run_sha256") == sha(run_path)
            and numerical.get("source_commit") == SOURCE
            and numerical.get("stage_id") == STAGE_ID,
            "Numerical audit is not bound to this completed study")
    run = read(run_path)
    require(run.get("status") == "completed" and run.get("accuracy_passed") is True
            and run.get("source_commit") == SOURCE
            and run.get("timing_contrast") == list(VARIANTS), "Completed contrast differs")
    require(numerical.get("workers") == 11
            and len(numerical.get("accuracy_gates", {})) == 3
            and all(row.get("passed") is True for row in numerical["accuracy_gates"].values()),
            "Full numerical trajectories have not independently passed")
    for key, value in numerical["timing_recomputed"].items():
        require(run["timing_summary"].get(key) == value, "Independent timing differs")
    require(len(run.get("timing_blocks", [])) == 8, "Timing worker count differs")
    require(run.get("original_gates") == {
        "reference_relative_rtol": .01, "atol": 1e-5, "loss_three_decimal": True, "finite": True},
        "Original numerical gates differ")
    return run


def verify_stage_freeze(stage: Path) -> None:
    """Check the actual successful lease against the approved F15 source/cap/deadline."""
    protocol, rental = read(stage / "protocol.json"), read(stage / "vast-rental.json")
    launch = read(stage / "launch-manifest.json")
    financial = protocol["financial"]
    require(protocol["source_commit"] == SOURCE and protocol["stage_id"] == STAGE_ID
            and rental["stage_id"] == STAGE_ID and rental["source_sha256"] == SOURCE_ARCHIVE
            and financial["maximum_stage_usd"] == rental["maximum_usd"] == 3.0
            and financial["maximum_seconds"] == rental["maximum_seconds"] == 14400
            and financial["download_allowance_decimal_gb"] == 90
            and financial["root_provider_gb"] == rental["allocated_disk_gb"] == 32
            and financial["volume_provider_gb"] == rental["volume_size_gb"] == 112
            and protocol["native_boundary"]["minimum_root_free_bytes"] == 16 * GIB
            and protocol["native_boundary"]["minimum_data_free_bytes"] == 100 * GIB
            and protocol["native_boundary"]["swap_must_be_disabled"] is True
            and financial["prior_usd"] == rental["prior_usd"] == 0,
            "Successful F15 source/cap/deadline differs from authorization")
    for name in ("protocol.json", "final_comparison.py", "source.tar.gz"):
        path, row = contained(stage, name), launch["files"][name]
        require(path.stat().st_size == row["bytes"] and sha(path) == row["sha256"],
                "Successful F15 launch freeze changed")
    require(launch["files"]["final_comparison.py"]["sha256"] == WRAPPER
            and launch["files"]["source.tar.gz"]["sha256"] == SOURCE_ARCHIVE,
            "Successful F15 source/wrapper differs from frozen recipe")
    plan_path = contained(stage, "storage-capacity-plan.json")
    plan = read(plan_path)["plan"]
    require(sha(plan_path) == launch["files"]["storage-capacity-plan.json"]["sha256"]
            and protocol["storage_capacity_plan"] == plan
            and plan["root_provider_gb"] == 32 and plan["volume_provider_gb"] == 112
            and plan["advertised_combined_pool_required"] == 144
            and plan["minimum_pre_download_root_free_bytes"] == 16 * GIB
            and plan["minimum_pre_download_data_free_bytes"] == 100 * GIB
            and plan["raw_outputs_reserve_is_unchanged"] is True
            and plan["root_components_bytes"]["raw_outputs_reserve"] == 12 * GIB
            and plan["actual_statvfs_is_authoritative"] is True,
            "F15 preregistered exact storage-capacity plan differs")


def verify_files(root: Path, rows: dict) -> None:
    require(bool(rows), "No retained originals indexed")
    for name, row in rows.items():
        path = contained(root, name)
        require(path.stat().st_size == row["bytes"] and sha(path) == row["sha256"],
                "Failed-stage retained original changed")


def failed_lease(stage: Path, tag: str) -> tuple[dict, dict]:
    ledger = read(stage / "stage-ledger.json")
    absence = read(stage / "independent-vast-absence.json")
    identity = "soup-kanana-30b-final-20261026-" + tag
    require(ledger["stage_id"] == identity and len(ledger["completed_leases"]) == 1,
            "Failed-stage ledger identity differs")
    lease = ledger["completed_leases"][0]
    require(lease["verified_absent"] is True and lease["volume_verified_absent"] is True
            and absence["verified_absent"] is True
            and absence["instance_verified_absent"] is True
            and absence["volume_verified_absent"] is True
            and absence["instance_id"] == lease["instance_id"]
            and absence["volume_id"] == lease["volume_id"]
            and absence["label"] == identity,
            "Failed-stage exact cleanup IDs differ")
    require(math.isclose(lease["conservative_usd"], FAILED_COSTS[tag], abs_tol=1e-12),
            "Frozen failed-stage cost changed")
    return lease, absence


def failed_archive(stage: Path, tag: str, allow_model_capture: bool = False) -> tuple[dict, dict]:
    outer, bundle = read(stage / "archive-manifest.json"), read(stage / "bundle-verified.json")
    archive = "result.tar.gz" if bundle.get("format") == "raw-tar-gzip" else "result.lossless.tar"
    require(outer["source_commit"] == SOURCE
            and outer["stage_status"]["status"] == bundle["stage_status"]["status"] == "failed"
            and bundle["all_manifested_raw_files_retained"] is True
            and bundle["whole_archive_verified"] is True
            and bundle["verified_files"] == len(outer["files"])
            and sha(stage / archive) == outer["sha256"] == bundle["sha256"],
            "Failed-stage full archive retention differs")
    verify_files(stage / "retained", outer["files"])
    full_model_prefixes = ("results/prepared/", "results/dispatch-qualification/")
    require(allow_model_capture or not any(name.startswith(full_model_prefixes)
                                          for name in outer["files"]),
            "Failed-stage unexpectedly contains full-model accuracy/timing")
    return outer, bundle


def failed_f11_proof(stage: Path) -> dict:
    outer, bundle = failed_archive(stage, "f11")
    lease, absence = failed_lease(stage, "f11")
    stop, retained = read(stage / "operator-download-stop.json"), read(
        stage / "retained/results/operator-stop.json")
    require(stop == retained and stop["status"] == "ABORTED_BEFORE_MODEL_ACCURACY_AND_TIMING"
            and stop["phase_before"]["phase"] == "download"
            and stop["numerical_or_timing_gates_changed"] is False
            and stop["real_model_accuracy_verdict"] == stop["real_model_speed_verdict"]
            == "NO VERDICT" and stop["instance_id"] == lease["instance_id"]
            and stop["volume_id"] == lease["volume_id"],
            "F11 operator download abort was relabelled")
    cases = ET.parse(stage / "retained/results/gpu-preflight.xml").findall(".//testcase")
    require(len(cases) == 4 and all(case.find(kind) is None for case in cases
            for kind in ("failure", "error", "skipped")), "F11 four numerical CUDA controls differ")
    require(bundle["verified_files"] == 87 and bundle["original_bytes"] == 9146052
            and outer["sha256"]
            == "c3633bab338a036a9fe0fbd83b058aa8a2ae6a3a1fb2975c9291ffd657d1684f",
            "F11 frozen original archive identity differs")
    return {"status": "FAILED_OPERATOR_DOWNLOAD_ABORT", "full_30b_verdict": "NO VERDICT",
            "numerical_cuda_cases_passed": 4, "conservative_usd": lease["conservative_usd"],
            "lease": lease, "exact_cleanup": absence, "operator_stop": stop,
            "full_retained_originals": outer, "bundle_sha256": sha(stage / "bundle-verified.json")}


def failed_f12_proof(stage: Path) -> dict:
    index = read(stage / "failure-evidence-index.json")
    lease, absence = failed_lease(stage, "f12")
    require(index["status"] == "FAILED_PROVIDER_API_THROTTLE_DURING_BOOT"
            and index["source_commit"] == SOURCE and index["operator_process_exit_code"] == 1
            and index["cleanup"] == absence and index["ledger"] == read(stage / "stage-ledger.json")
            and index["instance_id"] == lease["instance_id"]
            and index["volume_id"] == lease["volume_id"]
            and index["numerical_speed_memory_verdict"] == "NO VERDICT: GPU work did not start"
            and lease["actual_network_telemetry_retained"] is False,
            "F12 allocated boot failure was relabelled or released")
    rows = index["indexed_exact_local_files"]
    require(len(rows) == 92 and not any(name.startswith("retained/") for name in rows)
            and "429" in read(stage / "controller-failure.json")["error"]
            and read(stage / "controller-failure.json")["archive_collected"] is False,
            "F12 pre-SSH API failure scope differs")
    verify_files(stage, rows)
    source = index["source_archive"]
    require((stage / "source.tar.gz").stat().st_size == source["bytes"]
            and sha(stage / "source.tar.gz") == source["sha256"] == SOURCE_ARCHIVE,
            "F12 retained source archive changed")
    return {"status": index["status"], "full_30b_verdict": "NO VERDICT",
            "conservative_usd": lease["conservative_usd"], "lease": lease,
            "exact_cleanup": absence, "full_retained_local_index": index,
            "index_sha256": sha(stage / "failure-evidence-index.json")}


def failed_f13_proof(stage: Path) -> dict:
    outer, bundle = failed_archive(stage, "f13")
    lease, absence = failed_lease(stage, "f13")
    status = read(stage / "retained/results/stage-status.json")
    failure = read(stage / "retained/results/failure.json")
    message = "Checkpoint LFS SHA mismatch: model-00012-of-00013.safetensors"
    require(status["status"] == failure["status"] == "failed"
            and message in status["error"] and message in failure["error"]
            and message in outer["stage_status"]["error"]
            and bundle["verified_files"] == 94 and bundle["original_bytes"] == 9633426
            and outer["sha256"]
            == "b861a01dde238cfba66ad0ff4cb6666cee9b2810906c56b4b61622bc93010b78",
            "F13 checkpoint-integrity failure was relabelled")
    cases = ET.parse(stage / "retained/results/gpu-preflight.xml").findall(".//testcase")
    require(len(cases) == 4 and all(case.find(kind) is None for case in cases
            for kind in ("failure", "error", "skipped")), "F13 four numerical CUDA controls differ")
    pinned_path = stage / "retained/results/model-pinned.json"
    pinned = read(pinned_path)
    reference_stage = RESEARCH / "kanana-30b-dispatch-gpu-20261026-f8"
    reference_name = "results/model-pinned.json"
    reference_path = reference_stage / "retained" / reference_name
    reference_row = read(reference_stage / "archive-manifest.json")["files"][reference_name]
    verify_files(reference_stage / "retained", {reference_name: reference_row})
    reference = read(reference_path)
    expected_names = {f"model-{index:05d}-of-00013.safetensors" for index in range(1, 14)}
    require(pinned == reference and pinned["repo_id"] == MODEL
            and pinned["revision"] == MODEL_REVISION and pinned["weights_bytes"] == 61343935088
            and set(pinned["files"]) == expected_names
            and all(row["bytes"] == row["lfs"]["size"]
                    and re.fullmatch("[0-9a-f]{64}", row["lfs"]["sha256"])
                    for row in pinned["files"].values()),
            "F13 official thirteen-shard model pins differ from frozen reference")
    return {"status": "FAILED_CHECKPOINT_INTEGRITY", "full_30b_verdict": "NO VERDICT",
            "numerical_cuda_cases_passed": 4, "conservative_usd": lease["conservative_usd"],
            "lease": lease, "exact_cleanup": absence, "full_retained_originals": outer,
            "bundle_sha256": sha(stage / "bundle-verified.json"),
            "official_pins_sha256": sha(pinned_path), "all_13_official_pins_equal_f8": True,
            "reference_pin_original": {"name": reference_name, **reference_row},
            "actual_bad_shard_sha256": "NOT RECORDED by original F13 code",
            "failure_cause": "UNKNOWN; no corruption-source attribution",
            "full_30b_accuracy_and_timing": "NOT RUN: checkpoint verification failed before NF4"
                " prepare"}


def failed_f14_proof(stage: Path) -> dict:
    prefix = "results/dispatch-qualification/"
    worker_prefix = prefix + "accuracy/ordinary_legacy/"
    run = read(stage / "retained" / prefix / "run.json")
    worker = read(stage / "retained" / worker_prefix / "result.json")
    lease, absence = failed_lease(stage, "f14")
    require(run["status"] == "failed" and run["source_commit"] == SOURCE
            and run["accuracy"] == {} and run["timing_blocks"] == []
            and worker["status"] == "failed" and worker["phase"] == "accuracy"
            and worker["arm"] == "ordinary" and "cgroup swap was observed" in worker["error"]
            and worker["accuracy"]["updates"] == 2 and worker["accuracy"]["microbatches"] == 4
            and worker["accuracy"]["adapters"] == 288,
            "F14 invalid ordinary-only capture was relabelled as a passed comparison")
    resources = worker["accuracy"]["resources"]
    before = resources["before"]["cgroup"]["constraints"]
    after = resources["after"]["cgroup"]["constraints"]
    require(all(row["memory.swap.current"] == row["memory.swap.max"] == 0 for row in before)
            and any(row["memory.swap.current"] == 51142656 and row["memory.swap.max"] == "max"
                    for row in after)
            and resources["sampled_peak_cgroup_swap_bytes"] == 51175424
            and resources["sampled_peak_process_swap_bytes"] == 0
            and resources["after"]["process_swap_bytes"] == 0,
            "F14 failed cgroup no-swap boundary differs")
    cases = ET.parse(stage / "retained/results/gpu-preflight.xml").findall(".//testcase")
    integrity = read(stage / "retained/results/checkpoint-integrity.json")
    prepared = read(stage / "retained/results/prepared-integrity.json")
    require(len(cases) == 4 and all(case.find(kind) is None for case in cases
            for kind in ("failure", "error", "skipped")) and integrity["status"] == "passed"
            and integrity["all_shards_verified"] is True
            and len(integrity["final_verified_files"]) == 13
            and prepared["passed"] is True and prepared["files"] == 13,
            "F14 prior numerical CUDA/input/preparation evidence differs")
    outer, bundle = failed_archive(stage, "f14", allow_model_capture=True)
    require(bundle["verified_files"] == 116 and bundle["original_bytes"] == 1181854272
            and outer["sha256"]
            == "197d76ddf0540d8901da0fc50bba42b998e6976b0f9af4df71dc21954e6f0c0a"
            and outer["files"][worker_prefix + "capture.pt"]["sha256"]
            == worker["accuracy"]["capture_sha256"]
            and all(not name.startswith(prefix) or name == prefix + "run.json"
                    or name.startswith(worker_prefix) for name in outer["files"]),
            "F14 retained failed capture/archive scope differs")
    diagnosis_path = contained(PREP, "f14-resource-scope-diagnosis.json")
    diagnosis = read(diagnosis_path)
    require(diagnosis["status"] == "failed_resource_boundary_preserved_offline_diagnosis"
            and diagnosis["stage_id"] == "soup-kanana-30b-final-20261026-f14"
            and diagnosis["source_commit"] == SOURCE
            and diagnosis["archive_manifest_sha256"] == sha(stage / "archive-manifest.json")
            and diagnosis["fresh_absence_sha256"] == sha(stage / "independent-vast-absence.json")
            and all(outer["files"].get(name) == row for name, row in diagnosis["evidence"].items()),
            "F14 offline scope diagnosis is not bound to the retained failed originals")
    return {"status": "FAILED_CGROUP_NO_SWAP_BOUNDARY", "full_30b_verdict": "NO VERDICT",
            "conservative_usd": lease["conservative_usd"], "lease": lease,
            "exact_cleanup": absence, "full_retained_originals": outer,
            "bundle_sha256": sha(stage / "bundle-verified.json"),
            "ordinary_capture": "Retained invalid-condition 2-update/4-microbatch baseline only;"
                " no optimized capture, full comparative accuracy or timing verdict",
            "observed_cgroup_swap_after_bytes": 51142656,
            "sampled_peak_cgroup_swap_bytes": resources["sampled_peak_cgroup_swap_bytes"],
            "sampled_peak_process_swap_bytes": 0,
            "sampled_peak_rss_bytes": resources["sampled_peak_rss_bytes"],
            "resource_scope_diagnosis_sha256": sha(diagnosis_path),
            "failure_cause": "UNKNOWN: no policy/remapping attribution; no host mutation"}


def failed_f10_proof(stage: Path) -> dict:
    """Preserve the failed profiler prerequisite without calling it a numerical failure."""
    outer, bundle = failed_archive(stage, "f10")
    require(outer["source_commit"] == SOURCE
            and bundle["all_manifested_raw_files_retained"] is True
            and bundle["whole_archive_verified"] is True
            and bundle["verified_files"] == len(outer["files"]),
            "Failed F10 full retention was not verified")
    require(sha(stage / "result.lossless.tar") == outer["sha256"] == bundle["sha256"],
            "Failed F10 encoded archive changed")
    for name, row in outer["files"].items():
        path = contained(stage / "retained", name)
        require(path.stat().st_size == row["bytes"] and sha(path) == row["sha256"],
                "Failed F10 retained original changed")
    status = read(stage / "retained/results/stage-status.json")
    require(status["status"] == "failed" and "gpu-preflight" in status["error"],
            "F10 failed preflight was relabelled")
    require(not any(name.startswith(("results/prepared/", "results/dispatch-qualification/"))
                    for name in outer["files"]),
            "F10 contains unexpected full-model accuracy/timing artifacts")
    cases = ET.parse(stage / "retained/results/gpu-preflight.xml").findall(".//testcase")
    failures = [case for case in cases if case.find("failure") is not None]
    require(len(cases) == 5 and len(failures) == 1
            and failures[0].get("name") == "test_real_cuda_profiler_collects_kernel_and_h2d_events"
            and all(case.find("error") is None and case.find("skipped") is None for case in cases),
            "F10 prerequisite failure scope differs")
    absence = read(stage / "independent-vast-absence.json")
    require(absence["verified_absent"] is True
            and absence["instance_verified_absent"] is True
            and absence["volume_verified_absent"] is True,
            "Failed F10 exact cleanup is incomplete")
    ledger = read(stage / "stage-ledger.json")
    require(ledger["stage_id"] == "soup-kanana-30b-final-20261026-f10"
            and len(ledger["completed_leases"]) == 1,
            "Failed F10 ledger identity differs")
    lease = ledger["completed_leases"][0]
    require(lease["verified_absent"] is True and lease["volume_verified_absent"] is True
            and absence["instance_id"] == lease["instance_id"]
            and absence["volume_id"] == lease["volume_id"], "Failed F10 cleanup IDs differ")
    lease, absence = failed_lease(stage, "f10")
    return {"status": "FAILED_GPU_PROFILER_PREREQUISITE", "full_30b_verdict": "NO VERDICT",
            "lease": lease, "cuda_cases": 5,
            "numerical_cuda_cases_passed": 4, "failed_cases": [failures[0].get("name")],
            "full_30b_accuracy_and_timing": "NOT RUN: stopped before checkpoint download",
            "conservative_usd": lease["conservative_usd"], "exact_cleanup": absence,
            "full_retained_originals": outer, "bundle_sha256": sha(stage / "bundle-verified.json")}


def make_budget(stage: Path, failed: Path, reconciliation_path: Path,
                failed_stages: dict[str, dict]) -> dict:
    context = read(stage / "prior-budget-context.json")
    require(set(failed_stages) == set(FAILED_COSTS), "All five failed paid stages required")
    initial = context["prior_remaining_usd"] + context["new_authorized_usd"]
    prior_costs = {tag: proof["conservative_usd"] for tag, proof in failed_stages.items()}
    before = initial - math.fsum(prior_costs.values())
    require(math.isclose(initial, 6.202879736617223, abs_tol=1e-12)
            and math.isclose(context["aggregate_remaining_before_f15_usd"], before, abs_tol=1e-12)
            and all(math.isclose(context["failed_" + tag + "_cost_usd"], cost, abs_tol=1e-12)
                    and math.isclose(cost, FAILED_COSTS[tag], abs_tol=1e-12)
                    for tag, cost in prior_costs.items()), "Task authorization context differs")
    reconciliation = read(reconciliation_path)
    require(reconciliation["status"]
            == "reconciled_failed_before_allocation_prospective_allowances_releasable"
            and reconciliation["creation_outcome"]["instance_id"] is None
            and reconciliation["creation_outcome"]["volume_id"] is None
            and reconciliation["reconciliation"]["may_release_for_next_stage_admission"] is True
            and reconciliation["reconciliation"][
                "run_attributable_expected_rental_storage_and_model_network_usd"] == 0,
            "Failed F9 offer was not reconciled as no allocation")
    verify_files(failed, reconciliation["evidence"])
    ledger = read(stage / "stage-ledger.json")
    require(ledger["stage_id"] == STAGE_ID and ledger["maximum_stage_usd"] == 3.0
            and len(ledger["completed_leases"]) == 1, "One final F15 lease required")
    leases = ledger["completed_leases"]
    all_leases = leases + [proof["lease"] for proof in failed_stages.values()]
    require(all(row.get("verified_absent") is True
                and row.get("volume_verified_absent") is True for row in all_leases),
            "Final owned GPU/disk cleanup is incomplete")
    require(len({row["instance_id"] for row in all_leases}) == len(all_leases)
            and len({row["volume_id"] for row in all_leases}) == len(all_leases),
            "Duplicate or reused lease cost")
    require(all(proof["status"].startswith("FAILED")
                and proof["full_30b_verdict"] == "NO VERDICT" for proof in failed_stages.values()),
            "Failed stage cannot be relabelled as a benchmark")
    cost = math.fsum(row["conservative_usd"] for row in leases)
    require(math.isfinite(cost) and 0 <= cost <= 3.0 and before - cost >= 0,
            "Authorized budget exceeded")
    return {"prior_remaining_usd": context["prior_remaining_usd"],
            "new_authorized_usd": context["new_authorized_usd"],
            "remaining_before_f10_usd": initial,
            **{"failed_" + tag + "_conservative_usd": cost for tag, cost in prior_costs.items()},
            "failed_paid_stages_conservative_usd": math.fsum(prior_costs.values()),
            "remaining_before_f15_usd": before, "f15_conservative_usd": cost,
            "all_new_attempts_conservative_usd": math.fsum([*prior_costs.values(), cost]),
            "remaining_usd": before - cost, "leases": leases,
            "failed_f9_raw_prospective_ledger_usd": reconciliation[
                "ledger_decomposition_usd"]["raw_conservative_usd"],
            "failed_f9_reconciled_expected_run_cost_usd": 0.0,
            "semantics": "Conservative task estimates, not provider invoices. Failed"
                         " F10/F11/F12/F13/F14"
                         " each charged once and deducted before F15; F12 actual lease keeps"
                         " its full fallback estimate. F9 prospective allowance retained and"
                         " released only after definitive no-allocation evidence; no refund"
                         " or invoice verification claimed. Shared peers excluded."}


def execution_scope(run: dict) -> dict:
    """Report recorded worker settings separately from an unrecorded debug flag."""
    workers = [cell["result"]["worker"] for cell in run["accuracy"].values()]
    workers.extend(cell["result"]["worker"] for cell in run["timing_blocks"])
    expected = {"deterministic_algorithms": True, "allow_tf32": False,
                "training_mode": "eval with differentiable LoRA updates; dropout disabled"}
    require(len(workers) == 11 and all(all(worker["environment"].get(key) == value
            for key, value in expected.items()) for worker in workers),
            "Recorded execution settings differ across the eleven study workers")
    fill = [worker["environment"].get("fill_uninitialized_memory") for worker in workers]
    return {"recorded_in_all_11_workers": expected,
            "source_derived_settings": {"lora_dropout": 0.0, "model_mode": "eval",
                "source_file": "benchmarks/harness/two_read_cache_worker.py",
                "source_commit": SOURCE},
            "fill_uninitialized_memory": {
                "status": "NO VERDICT: runtime flag not persisted" if any(value is None
                    for value in fill) else "recorded in all eleven workers",
                "recorded_values": fill if all(value is not None for value in fill) else None,
                "source_scope": "Frozen worker enables torch.use_deterministic_algorithms(True);"
                    " it does not explicitly set or record fill_uninitialized_memory."},
            "generalization": "Controlled deterministic/eval/dropout-disabled recipe only;"
                " no universal/default nondeterministic CLI or full-training speedup claim.",
            "allocation_fill_cause": "NO VERDICT: no causal profile separates allocation-fill"
                " overhead from other cache or scheduling effects."}


def make_summary(stage: Path, run: dict, numerical: dict, infrastructure: dict,
                 budget: dict, failed_stages: dict[str, dict]) -> dict:
    capacity = read(stage / "retained/results/capacity-preflight.json")
    protocol = read(stage / "protocol.json")
    require(protocol["source_commit"] == SOURCE and protocol["stage_id"] == STAGE_ID
            and protocol["model"]["repo_id"] == MODEL
            and protocol["model"]["revision"] == MODEL_REVISION, "Study/model identity changed")
    require(capacity["passed"] is True and 7900 <= capacity["gpu_memory_mib"] <= 8300
            and 0 < capacity["native_ram_limit_bytes"] <= 32 * GIB,
            "Native physical GPU/RAM capacity proof differs")
    absolute, blocks = {}, []
    for variant in VARIANTS:
        rows = [cell["result"] for cell in run["timing_blocks"] if cell["variant"] == variant]
        require(len(rows) == 4, "Four balanced workers per arm required")
        absolute[variant] = {
            "median_step_seconds": statistics.median(
                value for row in rows for value in row["worker"]["timing"]["update_seconds"]),
            "median_setup_seconds": statistics.median(row["worker"]["setup"]["seconds"]
                                                       for row in rows),
            "median_whole_entry_seconds": statistics.median(
                row["fresh_process_wall_seconds"] for row in rows),
            "max_step_allocated_bytes": max(row["worker"]["timing"]["cuda"][
                "peak_allocated_bytes"] for row in rows),
            "max_step_reserved_bytes": max(row["worker"]["timing"]["cuda"][
                "peak_reserved_bytes"] for row in rows),
            "max_sampled_timing_rss_bytes": max(row["worker"]["timing"]["resources"][
                "sampled_peak_rss_bytes"] for row in rows),
        }
    require(run["timing_summary"].get("absolute") == absolute,
            "Derived absolute timings/memory differ from retained worker data")
    for cell in run["timing_blocks"]:
        result, raw = cell["result"], cell["result"]["worker"]
        blocks.append({"round": cell["round"], "position": cell["position"],
            "variant": cell["variant"], "pid": raw["pid"],
            "setup_seconds": raw["setup"]["seconds"],
            "whole_entry_seconds": result["fresh_process_wall_seconds"],
            "warmup_update_seconds": raw["warmup"]["update_seconds"],
            "timed_update_seconds": raw["timing"]["update_seconds"],
            "recorded_timed_last_microbatch_losses": raw["timing"]["losses"]})
    return {"schema_version": 1, "stage_id": STAGE_ID, "source_commit": SOURCE,
        "model": protocol["model"], "hardware": capacity,
        "recipe": {"frozen_base": "NF4", "compute": "BF16", "adapters": "FP32 attention LoRA",
                   "rank": 4, "alpha": 8, "tokens": 512, "batch": 1, "accumulation": 2,
                   "host_cache_bytes": 8 * GIB, "device_cache_bytes": 2 * GIB,
                   "host_cache_policy": "static", "inputs": "frozen random token IDs",
                   "execution_scope": execution_scope(run)},
        "accuracy": {"status": numerical["status"], "comparisons": numerical["accuracy_gates"],
                     "scope": "Three independent 2-AdamW-update/4-microbatch full captures;"
                              " 288 trainable LoRA tensors (A/B for 144 adapted attention"
                              " projections) receive gradients and update in each arm."},
        "timing": {**numerical["timing_recomputed"], "absolute": absolute,
                   "reference": VARIANTS[0], "candidate": VARIANTS[1],
                   "paired_rounds": 4, "warmup_updates_per_worker": 2,
                   "timed_updates_per_worker": 6, "all_timing_blocks": blocks},
        "infrastructure_audit_status": infrastructure["status"], "budget": budget,
        "checkpoint_integrity": infrastructure["checkpoint_integrity"],
        "storage_capacity_audit": infrastructure["storage_capacity"],
        "storage_capacity_plan": read(stage / "storage-capacity-plan.json"),
        "failed_stages": {tag: {key: value for key, value in proof.items()
            if key not in ("full_retained_originals", "full_retained_local_index")}
            for tag, proof in failed_stages.items()},
        "recording_limits": {
            "first_timed_microbatch_scalar": "NO VERDICT: not persisted",
            "timed_final_adapter_and_AdamW_tensor_parity": "NO VERDICT: final timing tensors"
                " not persisted; full numerical tensors cover the separate accuracy phase",
            "quality_convergence_full_finetuning": "NOT EVALUATED",
            "physical_NVMe": capacity.get("physical_nvme_verified", False),
            "storage_scope": capacity.get("storage_scope", "physical backing unverified")}}


def render(summary: dict) -> str:
    timing, capacity, budget = summary["timing"], summary["hardware"], summary["budget"]
    bitwise = all(row.get("bitwise") is True
                  for row in summary["accuracy"]["comparisons"].values())
    rows = []
    for variant, title in ((VARIANTS[0], "Ordinary streaming (three-read)"),
                           (VARIANTS[1], "Two-read + RAM/GPU caches + grouped routes")):
        row = timing["absolute"][variant]
        rows.append(f"| {title} | {row['median_step_seconds']:.4f} | "
            f"{row['median_setup_seconds']:.3f} | {row['median_whole_entry_seconds']:.3f} | "
            f"{row['max_step_allocated_bytes']/GIB:.3f} / "
            f"{row['max_step_reserved_bytes']/GIB:.3f} | "
            f"{row['max_sampled_timing_rss_bytes']/GIB:.3f} |")
    interval = timing["paired_bootstrap_95_percent"]
    gate = "PASS" if timing["passes_practical_2_percent_gate"] else "NO PRACTICAL WIN"
    table = "\n".join(rows)
    table_header = ("| Variant | Median step, s | Setup, s | Whole eight-update entry, s | "
                    "Step allocated / reserved VRAM, GiB | Sampled timing RSS, GiB |")
    return f"""# Kanana 30B: ordinary streaming versus the complete expert-streaming variant

Direct same-host comparison at source [`43cf0b34`](https://github.com/SoupTeam/soup-rnd/commit/{SOURCE}).
The candidate combines two-read expert replay, static RAM/GPU expert caches and grouped
integer route preparation. Experimental opt-in APIs; defaults/CLI are unchanged.

## Accuracy before timing

Pinned `{MODEL}` at `{MODEL_REVISION}` (30.67B MoE parameters).
Frozen NF4 base, BF16 compute, FP32 attention LoRA rank 4 / alpha 8;
512 tokens, batch 1, accumulation 2, frozen random inputs and initial adapters.
Physical **{capacity['gpu_name']} {capacity['gpu_memory_mib']} MiB**;
native workload RAM ceiling **{capacity['native_ram_limit_bytes']/GIB:.6f} GiB**, swap disabled.
Candidate cache payload ceilings: static host **8 GiB**, device **2 GiB**.
Preregistered storage uses provider ROOT **32 GB** and data volume **112 GB**.
Actual free-space floors are **16 GiB ROOT / 100 GiB data** before download;
the separate before-NF4 check retains the root floor and requires 29,387,287,853 data
bytes free. The unchanged 12 GiB raw-output reserve and 1.5 GB encoded archive
reserve are budgeted on ROOT. Admission uses measured filesystem free bytes;
provider GB are not assumed to equal GiB. RAM, VRAM and no-swap gates are unchanged.
All eleven workers record deterministic algorithms enabled, TF32 disabled and eval
mode with differentiable LoRA updates and dropout disabled. The frozen worker enables
`torch.use_deterministic_algorithms(True)`; the runtime allocation debug flag
`fill_uninitialized_memory` was not persisted: **NO VERDICT** on its runtime value.
These timings apply to this controlled recipe. They do not establish a universal
gain for default nondeterministic CLI training. Allocation-fill overhead may affect
the contrast, but no causal profile identifies its contribution or a kernel cause.

All three complete accuracy trajectories (ordinary, legacy two-read+caches, complete
candidate) independently passed the original `rtol=.01`, `atol=1e-5`, finite and
three-decimal loss gates. Each capture covers **2 AdamW updates / 4 microbatches**;
all **288 trainable LoRA tensors** (A/B for 144 adapted attention projections)
receive nonzero gradients and change. Captured comparison
bitwise agreement: **{bitwise}**. This does not establish downstream task quality
or convergence equivalence.

## Fresh unprofiled comparison

{table_header}
| --- | ---: | ---: | ---: | ---: | ---: |
{table}

Paired step-time reduction: **{timing['step_time_reduction_percent']:.3f}%**;
throughput increase: **{timing['throughput_increase_percent']:.3f}%**.
Descriptive paired-bootstrap 95% interval for time reduction:
**[{interval[0]:.3f}%, {interval[1]:.3f}%]**. Original lower-bound >=2% gate: **{gate}**.

Four balanced AB/BA pairs, eight fresh processes, two warmup and six measured
optimizer updates per process: 16 warmup and 48 measured updates total.
Percentages use geometric means of per-pair median ratios, so they need not equal
the ratio of the two pooled medians shown above. Whole entry includes process/import
bootstrap, setup/admission, all eight updates and validation; shared model download
and NF4 preparation are excluded. Setup cost must be amortized by longer training.
RSS sampling can miss brief peaks and excludes kernel/filesystem page-cache charges;
the RSS column is not a claim that this fits on a host with that much RAM.

This cohort is a direct ordinary-versus-complete comparison on the hardware above.
Earlier 16B/30B studies remain separate; their percentages are not added or used
as timing denominators here. No physical NVMe claim follows from a container mount.

## Recording and retention limits

Recorded timed last-microbatch losses pass the original gates. The first timed
microbatch scalar and final timed adapter/AdamW tensors were not persisted:
**NO VERDICT** for their numerical parity. Full tensor parity applies to the
separate accuracy captures, not every timed update or full convergence.

Both independent audits passed: numerical/timing and infrastructure/retention/cleanup.
The v5 infrastructure audit checks captured SHA256/size receipts for all thirteen
official shards, bounded fresh input repair, the imported helper and native prepared
fingerprints before accuracy. Full 61 GB model weights and rejected payloads are not
retained; the local audit verifies those recorded receipts and fingerprints rather
than rehashing a retained full checkpoint.
`gpu-evidence.zip` contains exact selected originals and audit/control sources;
`files.json` maps all logical originals to stored members, sizes and SHA256 values.
`F15/ops/` contains the exact frozen private launch/transport helpers and CPU/mutation
controls, bound to the launch manifest and independent prelease operational review.
That operational review establishes no GPU accuracy or speed result by itself.
Aliases are accepted only after full byte comparison, and every logical original
is restored and verified after ZIP creation. Complete tensor payloads larger than 64 KiB remain
locally retained and hash indexed in `evidence-manifest.json`; they are explicitly
omitted from Git, not discarded. Frozen production input archives are also retained
locally and indexed separately. The compact ZIP alone cannot replay full numerical
captures. [Summary](gpu-results-summary.json).

## Budget and cleanup

F9's rejected offer created no identified GPU or disk. Its raw prospective ledger
and no-allocation reconciliation are preserved, without claiming a verified invoice
or refund. F10 stopped at its profiler prerequisite: four numerical CUDA cases
passed, the CUDA/CUPTI profiler-event case failed; full 30B accuracy and timing
were not run. F11 passed four numerical CUDA controls but was stopped during
checkpoint download before full 30B accuracy/timing. F12 failed at provider API 429
during boot, before authenticated SSH or GPU work. All failed attempts remain
**FAILED / NO VERDICT** for full 30B accuracy and speed, with originals retained.
F13 passed four numerical CUDA controls but failed the unchanged official SHA256
checkpoint gate for shard 12 before NF4 preparation or full 30B accuracy/timing.
All thirteen expected official shard pins equal the earlier frozen reference. The
actual rejected shard digest was not recorded by that original code; its failure
cause remains unknown. F13 is also **FAILED / NO VERDICT** for full 30B results.
F14 verified the official inputs and produced only the ordinary 2-update/4-microbatch
capture before the unchanged no-swap gate failed. Cgroup swap was observed while
process swap remained zero; policy/remapping cause is unknown. That capture is
retained from an invalid run. No optimized capture, timing or full comparative
accuracy verdict exists for F14: **FAILED / NO VERDICT**.
F15 uses four actual
numerical CUDA controls and unprofiled timing; it makes no passed-profile claim.
Numerical tolerances and the complete 30B accuracy/timing recipe are unchanged.

Failed F10 conservative cost: **${budget['failed_f10_conservative_usd']:.6f}**.
Failed F11 conservative cost: **${budget['failed_f11_conservative_usd']:.6f}**.
Failed F12 conservative fallback: **${budget['failed_f12_conservative_usd']:.6f}**.
Failed F13 conservative cost: **${budget['failed_f13_conservative_usd']:.6f}**.
Failed F14 conservative cost: **${budget['failed_f14_conservative_usd']:.6f}**.
F15 conservative cost: **${budget['f15_conservative_usd']:.6f}**;
remaining task authorization: **${budget['remaining_usd']:.6f}** from
${budget['remaining_before_f15_usd']:.6f} before F15.
Initial task authorization was ${budget['remaining_before_f10_usd']:.6f}; each paid
failed attempt is deducted exactly once. F9's prospective allowance is not spend.
These are conservative estimates with reserves, **not invoices**.
Exact owned F10, F11, F12, F13, F14 and F15 instances and persistent volumes were independently
confirmed absent.
Shared-account colleagues' resources were untouched.
"""


def failed_packet_entries(failed_roots: dict[str, Path], failed_stages: dict[str, dict]):
    entries: list[tuple[str, bytes, str]] = []
    failed_omissions = {}
    for tag in ("f10", "f11", "f13", "f14"):
        failed_root = failed_roots[tag]
        failed_omissions[tag] = {}
        for name, row in failed_stages[tag]["full_retained_originals"]["files"].items():
            path = contained(failed_root / "retained", name)
            if (path.suffix in (".pt", ".bin", ".safetensors")
                    and row["bytes"] > TENSOR_PACKET_LIMIT):
                failed_omissions[tag][name] = {**row, "reason": "Complete large failed-attempt"
                    " tensor retained locally and hash indexed; exact XML/logs included"}
            else:
                require(row["bytes"] <= 16 * 2**20, "Oversize failed-attempt structural evidence")
                entries.append((tag.upper() + "/" + name, path.read_bytes(),
                                "Exact failed-attempt original; no full-model verdict"))
        for name in ("archive-manifest.json", "bundle-verified.json", "stage-ledger.json",
                     "vast-deletion.json", "vast-volume-deletion.json",
                     "independent-vast-absence.json"):
            entries.append((tag.upper() + "/proofs/" + name,
                            contained(failed_root, name).read_bytes(),
                            "Failed attempt full retention/cost/exact cleanup"))
    entries.append(("F11/proofs/operator-download-stop.json",
                    contained(failed_roots["f11"], "operator-download-stop.json").read_bytes(),
                    "Exact operator abort before full 30B accuracy/timing"))
    for name in failed_stages["f12"]["full_retained_local_index"]["indexed_exact_local_files"]:
        path = contained(failed_roots["f12"], name)
        require(path.stat().st_size <= 16 * 2**20, "Oversize F12 structural evidence")
        entries.append(("F12/" + name, path.read_bytes(), "Exact indexed failed boot/API attempt"))
    entries.append(("F12/failure-evidence-index.json",
                    contained(failed_roots["f12"], "failure-evidence-index.json").read_bytes(),
                    "All 92 F12 originals and retained source archive hash index"))
    reference = RESEARCH / "kanana-30b-dispatch-gpu-20261026-f8/retained/results/model-pinned.json"
    entries.append(("reference-pins/F8/model-pinned.json", reference.read_bytes(),
                    "Exact thirteen-shard expected-pin reference only; no timing denominator"))
    for tag in ("f13", "f14"):
        old_ops, _old_ops_binding = frozen_ops_entries(failed_roots[tag], tag=tag)
        entries.extend(old_ops)
    entries.append(("audit/f14-resource-scope-diagnosis.json",
                    contained(PREP, "f14-resource-scope-diagnosis.json").read_bytes(),
                    "Bound offline failed-resource diagnosis; no cause or comparative verdict"))
    return entries, failed_omissions


def frozen_ops_entries(stage: Path, tag: str = "f15") -> tuple[list[tuple[str, bytes, str]], dict]:
    """Retain the exact private operations sources and controls used by this launch."""
    launch = read(stage / "launch-manifest.json")
    identity = "soup-kanana-30b-final-20261026-" + tag
    rows = launch["files"]
    critical = {"api_transport.py", "api_rate_limit.py", "cloud.py", "controller.py",
                "launch.py", "launch_safety.py", "transport.py", "range_transport.py",
                "test_controller.py"}
    if tag in ("f14", "f15"):
        critical.add("checkpoint_integrity.py")
        require(any(name.startswith("test_") and ("checkpoint" in name or "integrity" in name)
                    and name.endswith(".py") for name in rows),
                "F14 launch omits checkpoint-integrity CPU controls")
    if tag == "f15":
        critical.update({"storage-capacity-plan.json", "audit-v5-freeze-review.json",
                         "test_f15_independent_capacity.py", "test_f15_storage.py"})
    require(critical <= set(rows), "Launch omits critical frozen operations sources")
    review_path = contained(PREP, tag + "-independent-ops-review.json")
    review = read(review_path)
    require(review["stage_id"] == identity
            and review["launch_manifest_sha256"] == sha(stage / "launch-manifest.json")
            and review["verified_launch_inputs"] == len(rows)
            and review["wrapper_sha256"] == WRAPPER,
            "Independent operational review is not bound to this frozen launch")
    if tag in ("f14", "f15"):
        expected_version = 4 if tag == "f14" else 5
        expected_auditor = F14_INFRA_AUDITOR if tag == "f14" else AUDITOR_HASHES[
            "audit_final_infrastructure.py"]
        expected_status = ("passed_independent_f14_prelease_operational_integrity_review"
                           if tag == "f14"
                           else "passed_independent_f15_prelease_capacity_integrity_review")
        cap_key = "stage_maximum_usd" if tag == "f14" else "stage_cap_usd"
        require(review["status"] == expected_status and review["source_commit"] == SOURCE
                and review["financial"][cap_key] == 3.0
                and review["financial"]["maximum_seconds"] == 14400
                and review["infrastructure_auditor_version"] == expected_version
                and review["infrastructure_auditor_sha256"] == expected_auditor
                and review["checkpoint_helper_sha256"] == rows["checkpoint_integrity.py"]["sha256"]
                and review["numerical_auditor_sha256"]
                == rows["audit_final_comparison.py"]["sha256"],
                "Operational integrity review identity/helper/auditor differs")
        if tag == "f14":
            require(review["financial"]["download_allowance_decimal_gb"] == 90
                    and review["mutation_review_sha256"]
                    == rows["f14-independent-mutation-review.json"]["sha256"]
                    and review["actual_successful_f8_native_schema_control_sha256"]
                    == rows["f14-actual-f8-schema-control-final.json"]["sha256"],
                    "F14 final helper mutation/native-schema controls differ")
        else:
            plan = read(contained(stage, "storage-capacity-plan.json"))["plan"]
            require(review["preregistered_storage_plan"] == plan
                    == read(contained(stage, "protocol.json"))["storage_capacity_plan"]
                    and review["test_reports_overlap"] is True
                    and review["actual_f14_swap_negative_still_rejected"] is True
                    and review["source_and_precision_unchanged_vs_f14"] is True,
                    "F15 independent capacity review changed storage or weakened prior boundaries")
        for filename, expected in review["test_case_counts_by_report"].items():
            cases = ET.parse(contained(stage, filename)).findall(".//testcase")
            require(len(cases) == expected and all(case.find(kind) is None for case in cases
                    for kind in ("failure", "error", "skipped")),
                    "Separately reported CPU control counts/status differ")
        freeze_name = ("audit-v4-freeze-review.json" if tag == "f14"
                       else "audit-v5-freeze-review.json")
        freeze = read(contained(stage, freeze_name))
        hash_key = "audit_script_sha256" if tag == "f14" else "infrastructure_auditor_sha256"
        require(freeze["status"] == "frozen_before_" + tag + "_gpu_data"
                and freeze["audit_version"] == expected_version
                and freeze[hash_key] == expected_auditor
                and freeze["numerical_auditor_sha256"]
                == AUDITOR_HASHES["audit_final_comparison.py"],
                "Independent auditor freeze receipt differs")
    else:
        require(review["status"] == "passed_independent_f13_prelease_operational_review"
                and review["production_source_commit"] == SOURCE
                and review["stage_maximum_usd"] == 3.0 and review["stage_maximum_seconds"] == 14400,
                "Prior F13 operational review differs")
        for group, suffix, hash_field in (
                ("independent_cpu_controls", ".xml", "junit_sha256"),
                ("combined_preflight_cpu_controls", ".xml", "junit_sha256"),
                ("actual_os_process_controls", ".xml", "junit_sha256"),
                ("independent_cpu_controls", ".json", "mutation_review_sha256")):
            require(any(name.endswith(suffix) and row["sha256"] == review[group][hash_field]
                        for name, row in rows.items()),
                    "Operational review/control receipts differ from launch")
    entries = []
    selected = {}
    for name, row in rows.items():
        is_source = Path(name).suffix in (".py", ".sh") or name == "constraints.txt"
        is_control = Path(name).suffix in (".xml", ".json")
        if not (is_source or is_control):
            continue
        require(not any(part in (".deps", "__pycache__") for part in Path(name).parts),
                "Dependency/cache trees cannot enter the public operations packet")
        value = contained(stage, name).read_bytes()
        require(len(value) == row["bytes"]
                and hashlib.sha256(value).hexdigest() == row["sha256"],
                "Frozen operations source/control changed")
        entries.append((tag.upper() + "/ops/" + name, value,
                        "Exact launch-manifest operations source/control; private keys excluded"))
        selected[name] = row
    entries.append(("audit/" + tag + "-independent-ops-review.json", review_path.read_bytes(),
                    "Independent prelease operations review, not a GPU result"))
    return entries, {"launch_manifest_sha256": sha(stage / "launch-manifest.json"),
                     "independent_ops_review_sha256": sha(review_path), "files": selected,
                     "prelease_stage_numerical_auditor_sha256": review.get(
                         "numerical_auditor_sha256"),
                     "executed_numerical_auditor_sha256": AUDITOR_HASHES[
                         "audit_final_comparison.py"],
                     "report_scope": "Prelease embedded auditor copies and current executed"
                         " independent audit sources are separately bound; CPU report groups"
                         " overlap and are not summed."}


def build(stage: Path, numerical_path: Path, infrastructure_path: Path, out: Path,
          failed: Path, reconciliation_path: Path, secrets: tuple[bytes, ...],
          failed_f10_stage: Path | None = None, failed_f11_stage: Path | None = None,
          failed_f12_stage: Path | None = None, failed_f13_stage: Path | None = None,
          failed_f14_stage: Path | None = None) -> dict:
    numerical, infrastructure = read(numerical_path), read(infrastructure_path)
    run = verify_audits(stage, numerical, infrastructure)
    failed_f10_stage = failed_f10_stage or RESEARCH / "kanana-30b-final-gpu-20261026-f10"
    failed_f11_stage = failed_f11_stage or RESEARCH / "kanana-30b-final-gpu-20261026-f11"
    failed_f12_stage = failed_f12_stage or RESEARCH / "kanana-30b-final-gpu-20261026-f12"
    failed_f13_stage = failed_f13_stage or RESEARCH / "kanana-30b-final-gpu-20261026-f13"
    failed_f14_stage = failed_f14_stage or RESEARCH / "kanana-30b-final-gpu-20261026-f14"
    verify_stage_freeze(stage)
    failed_stages = {"f10": failed_f10_proof(failed_f10_stage),
                     "f11": failed_f11_proof(failed_f11_stage),
                     "f12": failed_f12_proof(failed_f12_stage),
                     "f13": failed_f13_proof(failed_f13_stage),
                     "f14": failed_f14_proof(failed_f14_stage)}
    budget = make_budget(stage, failed, reconciliation_path, failed_stages)
    summary = make_summary(stage, run, numerical, infrastructure, budget, failed_stages)
    require(not out.exists(), "Refuse replacing an existing publication draft")
    entries: list[tuple[str, bytes, str]] = []
    outer = read(stage / "archive-manifest.json")
    require(outer["source_commit"] == SOURCE and outer.get("files"), "Raw archive identity differs")
    omissions = {}
    for name, row in outer["files"].items():
        path = contained(stage / "retained", name)
        require(path.stat().st_size == row["bytes"] and sha(path) == row["sha256"],
                "Retained original no longer matches the audited manifest")
        large = (path.suffix in (".pt", ".bin", ".safetensors")
                 and row["bytes"] > TENSOR_PACKET_LIMIT)
        if large:
            omissions[name] = {**row, "reason": "Complete large original retained locally;"
                                   " hash indexed, not included in Git"}
            continue
        require(row["bytes"] <= 16 * 2**20, "Unexpected structural evidence exceeds 16 MiB")
        entries.append((STAGE_TAG + "/" + name, path.read_bytes(), "Exact retained original"))
    for name in ("bundle-verified.json", "network-preflight.json", "stage-ledger.json",
                 "vast-deletion.json", "vast-volume-deletion.json", "independent-vast-absence.json",
                 "ops-tests.xml", "prior-budget-context.json", "launch-manifest.json",
                 "archive-manifest.json", "protocol.json", "vast-rental.json"):
        path = contained(stage, name)
        entries.append((STAGE_TAG + "/proofs/" + name, path.read_bytes(), "Own-only local proof"))
    ops_entries, frozen_ops = frozen_ops_entries(stage)
    entries.extend(ops_entries)
    failed_entries, failed_omissions = failed_packet_entries({
        "f10": failed_f10_stage, "f11": failed_f11_stage, "f12": failed_f12_stage,
        "f13": failed_f13_stage, "f14": failed_f14_stage}, failed_stages)
    entries.extend(failed_entries)
    reconciliation = read(reconciliation_path)
    for name in reconciliation["evidence"]:
        path = contained(failed, name)
        entries.append(("F9/" + name, path.read_bytes(), "Exact failed-offer reconciliation input"))
    entries.append(("F9/budget-reconciliation.json", reconciliation_path.read_bytes(),
                    "No-allocation reconciliation; original prospective ledger preserved"))
    for label, path in (("numerical-audit.json", numerical_path),
                         ("infrastructure-audit.json", infrastructure_path)):
        entries.append(("audit/" + label, path.read_bytes(), "Executed independent audit result"))
    for name in ("audit_final_comparison.py", "audit_final_infrastructure.py",
                 "final_comparison.py", "test_final_comparison.py",
                 "test_final_ops_review.py", "publish_final_results.py",
                 "test_publish_final_results.py", "publication-helper-tests.xml"):
        path = contained(PREP, name)
        entries.append(("audit/" + name, path.read_bytes(), "Audit/qualification/review source"))
    entries.append(("summary.json", encoded(summary), "Derived from audited fresh raw workers"))
    for _name, value, _provenance in entries:
        check_private(value, secrets)
    input_archives = {}
    for tag, root in (("f15", stage), ("f10", failed_f10_stage),
                      ("f11", failed_f11_stage), ("f12", failed_f12_stage),
                      ("f13", failed_f13_stage),
                      ("f14", failed_f14_stage)):
        source = contained(root, "source.tar.gz")
        require(sha(source) == SOURCE_ARCHIVE, "Retained frozen production input archive changed")
        input_archives[tag] = {"source.tar.gz": {"bytes": source.stat().st_size,
            "sha256": SOURCE_ARCHIVE, "reason": "Frozen production input archive retained locally;"
            " unchanged source commit linked in README and exact launch hash included"}}
    out.mkdir(parents=True)
    packet = write_packet(out / "gpu-evidence.zip", entries)
    manifest = {"schema_version": 1, "source_commit": SOURCE, "stage_id": STAGE_ID,
                "packet": packet, "full_retained_originals": outer,
                "public_packet_omissions": omissions,
                "tensor_packet_limit_bytes": TENSOR_PACKET_LIMIT,
                "retained_input_archive_omissions": input_archives,
                "frozen_operations_sources_and_controls": frozen_ops,
                "failed_full_retained_originals": {tag: proof.get("full_retained_originals",
                    proof.get("full_retained_local_index"))
                    for tag, proof in failed_stages.items()},
                "failed_packet_omissions": failed_omissions,
                "numerical_audit_sha256": sha(numerical_path),
                "infrastructure_audit_sha256": sha(infrastructure_path),
                "failed_offer_reconciliation_sha256": sha(reconciliation_path),
                "budget": budget, "scope": "Compact exact-byte evidence. Large original"
                    " tensors retained locally and hash indexed, not uploaded to Git."}
    outputs = {"README.md": render(summary).encode(),
               "gpu-results-summary.json": encoded(summary),
               "evidence-manifest.json": encoded(manifest), ".gitattributes": b"*.zip -text\n"}
    for name, value in outputs.items():
        check_private(value, secrets)
        (out / name).write_bytes(value)
    return {"prepared": str(out), "packet": packet, "timing": numerical["timing_recomputed"],
            "remaining_usd": budget["remaining_usd"]}


def build_failure_only(out: Path, unallocated_stage: Path, failed: Path,
                       reconciliation_path: Path, secrets: tuple[bytes, ...],
                       failed_roots: dict[str, Path] | None = None) -> dict:
    """Prepare honest failed-attempt evidence when no final paid lease was allocated."""
    require(not out.exists(), "Refuse replacing an existing publication draft")
    require(not (unallocated_stage / "vast-rental.json").exists()
            and not (unallocated_stage / "vast-allocation-intent.json").exists(),
            "Failure-only preallocation report cannot omit a final allocated or ambiguous lease")
    if (unallocated_stage / "stage-ledger.json").exists():
        require(read(unallocated_stage / "stage-ledger.json")["completed_leases"] == [],
                "Failure-only preallocation report cannot omit a final paid lease")
    roots = failed_roots or {tag: RESEARCH / ("kanana-30b-final-gpu-20261026-" + tag)
                             for tag in FAILED_COSTS}
    proofs = {"f10": failed_f10_proof(roots["f10"]), "f11": failed_f11_proof(roots["f11"]),
              "f12": failed_f12_proof(roots["f12"]), "f13": failed_f13_proof(roots["f13"]),
              "f14": failed_f14_proof(roots["f14"])}
    reconciliation = read(reconciliation_path)
    require(reconciliation["status"]
            == "reconciled_failed_before_allocation_prospective_allowances_releasable"
            and reconciliation["creation_outcome"]["instance_id"] is None
            and reconciliation["creation_outcome"]["volume_id"] is None
            and reconciliation["reconciliation"][
                "run_attributable_expected_rental_storage_and_model_network_usd"] == 0,
            "F9 no-allocation reconciliation differs")
    verify_files(failed, reconciliation["evidence"])
    leases = [proof["lease"] for proof in proofs.values()]
    require(len({lease["instance_id"] for lease in leases}) == len(leases)
            and len({lease["volume_id"] for lease in leases}) == len(leases),
            "A paid failed lease was counted twice")
    costs = {tag: proof["conservative_usd"] for tag, proof in proofs.items()}
    total = math.fsum(costs.values())
    initial = 1.202879736617223 + 5.0
    require(all(proof["status"].startswith("FAILED")
                and proof["full_30b_verdict"] == "NO VERDICT" for proof in proofs.values())
            and total <= initial, "Failure-only report cannot claim passed comparative evidence")
    summary = {"schema_version": 1, "status": "FAILED_NO_COMPARATIVE_VERDICT",
        "source_commit": SOURCE, "model": {"repo_id": MODEL, "revision": MODEL_REVISION},
        "comparative_accuracy": "NO VERDICT", "paired_timing": "NO VERDICT",
        "throughput_or_memory_gain": "NO VERDICT",
        "failed_stages": {tag: {key: value for key, value in proof.items()
            if key not in ("full_retained_originals", "full_retained_local_index")}
            for tag, proof in proofs.items()},
        "budget": {"initial_authorization_usd": initial, "failed_costs_usd": costs,
            "failed_paid_total_usd": total, "remaining_usd": initial - total,
            "f9_expected_cost_usd": 0,
            "f9_raw_prospective_allowance_usd": reconciliation["ledger_decomposition_usd"][
                "raw_conservative_usd"],
            "semantics": "Conservative task estimates, not invoices; each actual failed lease"
                " counted once. F9 rejected offer created no identified resource; its prospective"
                " allowance is not spend or a verified refund."},
        "final_stage_scope": "No final allocation intent or rental receipt exists locally;"
            " this report cannot be used if a final lease was allocated or ambiguous.",
        "retention_scope": "All failed original archives and files hash verified locally."
            " Public ZIP contains exact selected originals and frozen operations controls;"
            " tensor payloads >64KiB remain local and hash indexed, so ZIP alone cannot replay"
            " full numerical captures. No provider invoice, causal profile, downstream quality"
            " or successful full 30B comparative benchmark is claimed."}
    entries, omissions = failed_packet_entries(roots, proofs)
    for name in reconciliation["evidence"]:
        entries.append(("F9/" + name, contained(failed, name).read_bytes(),
                        "Exact rejected-offer no-allocation reconciliation evidence"))
    entries.append(("F9/budget-reconciliation.json", reconciliation_path.read_bytes(),
                    "Prospective allowance reconciled separately from actual paid failed leases"))
    for name in ("publish_final_results.py", "test_publish_final_results.py",
                 "publication-helper-tests.xml"):
        entries.append(("audit/" + name, contained(PREP, name).read_bytes(),
                        "Failure-only publication controls; no passed benchmark audit claimed"))
    entries.append(("failure-summary.json", encoded(summary),
                    "Verified failed-attempt evidence only"))
    for _name, value, _scope in entries:
        check_private(value, secrets)
    table = "\n".join(f"| {tag.upper()} | {proof['status']} | ${costs[tag]:.6f} |"
                       for tag, proof in proofs.items())
    report = f"""# Final Kanana 30B comparison: no comparative verdict

Source `{SOURCE}`; pinned `{MODEL}` revision `{MODEL_REVISION}`.
No complete valid ordinary-versus-full comparison was obtained. There is **NO VERDICT**
for comparative accuracy, paired timing, throughput or memory gains. Earlier cohorts
are not timing denominators, and no speedup percentage is reported here.

| Attempt | Failed boundary | Conservative cost |
| --- | --- | ---: |
{table}

F9's rejected offer created no identified instance or volume; expected cost is $0.
Its original $1.2690072383850324 prospective allowance is retained as evidence and
is not counted as spend. F10 passed four numerical CUDA controls but failed CUPTI
readiness. F11 stopped during slow download. F12 failed at provider API 429 during
boot. F13 failed official shard-12 SHA verification; the rejected digest was not
recorded, so the cause is unknown and the expected pins remain unchanged.

F14 passed four numerical CUDA and all official input/preparation checks, then
produced only an ordinary 2-AdamW-update/4-microbatch capture before the strict
no-swap gate failed. Cgroup swap was 51,142,656 bytes after accuracy, with sampled
peak 51,175,424 bytes, while process swap stayed zero. The capture is retained
from an invalid run; no optimized capture or timing exists. Policy/remapping cause
is unknown. No source, no-swap, precision or numerical gate was relaxed.

Every paid attempt remains **FAILED / NO VERDICT**. Exact owned instances and disks
were independently verified absent after their attempts. Conservative paid total:
**${total:.6f}**; remaining from ${initial:.6f}: **${initial-total:.6f}**.
These are conservative estimates, **not provider invoices**.

`gpu-evidence.zip` restores all selected originals exactly after full-byte deduplication.
Large tensors over 64 KiB remain fully retained locally; `evidence-manifest.json`
records every omitted name, size, SHA256 and reason. Full model weights and bad
input payloads were not retained. The ZIP alone cannot replay complete tensor captures.
The F14 failed ordinary worker recorded deterministic algorithms on, TF32 off and
eval mode with differentiable LoRA updates/dropout disabled. The allocation-fill
runtime flag was not recorded, and no causal profile attributes cache effects.
""".encode()
    manifest = {"schema_version": 1, "status": summary["status"], "source_commit": SOURCE,
        "failed_full_retained_originals": {tag: proof.get("full_retained_originals",
            proof.get("full_retained_local_index")) for tag, proof in proofs.items()},
        "failed_packet_omissions": omissions, "tensor_packet_limit_bytes": TENSOR_PACKET_LIMIT,
        "budget": summary["budget"], "scope": summary["retention_scope"]}
    input_archives = {}
    for tag, root in roots.items():
        source = contained(root, "source.tar.gz")
        require(sha(source) == SOURCE_ARCHIVE, "Failed-stage retained production input changed")
        input_archives[tag] = {"source.tar.gz": {"bytes": source.stat().st_size,
            "sha256": SOURCE_ARCHIVE, "reason": "Frozen production input archive retained"
                " locally; unchanged source commit identified in README"}}
    manifest["retained_input_archive_omissions"] = input_archives
    check_private(report, secrets)
    check_private(encoded(manifest), secrets)
    out.mkdir(parents=True)
    packet = write_packet(out / "gpu-evidence.zip", entries)
    manifest["packet"] = packet
    (out / "README.md").write_bytes(report)
    (out / "gpu-results-summary.json").write_bytes(encoded(summary))
    (out / "evidence-manifest.json").write_bytes(encoded(manifest))
    (out / ".gitattributes").write_bytes(b"*.zip -text\n")
    return {"prepared": str(out), "status": summary["status"], "packet": packet,
            "remaining_usd": initial - total}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", type=Path)
    parser.add_argument("--failure-only", action="store_true")
    parser.add_argument("--numerical-audit", type=Path)
    parser.add_argument("--infra-audit", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--failed-stage", type=Path,
                        default=RESEARCH / "kanana-30b-final-gpu-20261026-f9")
    parser.add_argument("--failed-reconciliation", type=Path,
                        default=PREP / "f9-budget-reconciliation.json")
    parser.add_argument("--failed-f10-stage", type=Path,
                        default=RESEARCH / "kanana-30b-final-gpu-20261026-f10")
    parser.add_argument("--failed-f11-stage", type=Path,
                        default=RESEARCH / "kanana-30b-final-gpu-20261026-f11")
    parser.add_argument("--failed-f12-stage", type=Path,
                        default=RESEARCH / "kanana-30b-final-gpu-20261026-f12")
    parser.add_argument("--failed-f13-stage", type=Path,
                        default=RESEARCH / "kanana-30b-final-gpu-20261026-f13")
    parser.add_argument("--failed-f14-stage", type=Path,
                        default=RESEARCH / "kanana-30b-final-gpu-20261026-f14")
    args = parser.parse_args()
    key_path = Path(r"C:\Users\esenb\.config\vastai\vast_api_key")
    secrets = (key_path.read_bytes().strip(),)
    if args.failure_only:
        result = build_failure_only(args.out,
            args.stage or RESEARCH / "kanana-30b-final-gpu-20261026-f15", args.failed_stage,
            args.failed_reconciliation, secrets, {"f10": args.failed_f10_stage,
                "f11": args.failed_f11_stage, "f12": args.failed_f12_stage,
                "f13": args.failed_f13_stage, "f14": args.failed_f14_stage})
    else:
        if not all((args.stage, args.numerical_audit, args.infra_audit)):
            parser.error("Success publication requires --stage, --numerical-audit "
                         "and --infra-audit")
        result = build(args.stage, args.numerical_audit, args.infra_audit, args.out,
                       args.failed_stage, args.failed_reconciliation, secrets,
                       args.failed_f10_stage, args.failed_f11_stage, args.failed_f12_stage,
                       args.failed_f13_stage,
                       args.failed_f14_stage)
    from rich.console import Console

    Console().print(result)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
