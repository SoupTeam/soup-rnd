"""CPU refusal controls for the private final two-arm contrast."""

import copy
import importlib.util
from pathlib import Path
from types import SimpleNamespace

import audit_final_comparison as independent
import final_comparison as final
import pytest

ROOT = Path(r"C:\Users\esenb\.codex\worktrees\expert-dispatch-opt-20261026\soup-rnd-d2")
q = final.configure(ROOT)
module_spec = importlib.util.spec_from_file_location(
    "original_qualification_controls", ROOT / "tests/test_expert_dispatch_qualification.py")
controls = importlib.util.module_from_spec(module_spec)
module_spec.loader.exec_module(controls)
COMMON = SimpleNamespace(RTOL=.01, ATOL=1e-5)


def blocks():
    rows = controls.timing_blocks()
    for row in rows:
        result = row["result"]
        raw, envelope = result["worker"], result["envelope"]
        envelope["source_commit"] = final.SOURCE_COMMIT
        for name in ("arm",):
            raw[name] = q.NATIVE_ARMS[row["variant"]]
        result["native_arm"] = envelope["native_arm"] = raw["arm"]
        ordinary = row["variant"] == "ordinary_legacy"
        for stage, count in (("warmup", 2), ("timing", 6)):
            raw[stage]["update_seconds"] = [1.0 if ordinary else .6] * count
            for point, after in (("runtime_before", False), ("runtime_after", True)):
                snapshot = controls.cache_snapshot(not ordinary, after)
                if ordinary and after:
                    snapshot["expert_cache"].update(
                        logical_fetches=150, storage_reads=150,
                        materializations=150, storage_bytes_read=15000)
                snapshot["expert_grouped_routes"] = q.expected_routes(not ordinary)
                raw[stage][point] = snapshot
    return rows


def test_complete_two_arm_result_preserves_denominators_and_all_gates():
    result = final.timing_summary(blocks(), COMMON)
    assert result["reference_variant"] == "ordinary_legacy"
    assert result["native_arms"] == {"ordinary_legacy": "ordinary", "grouped": "two_read_cache"}
    assert result["step_time_reduction_percent"] == pytest.approx(40.)
    assert result["throughput_increase_percent"] == pytest.approx(66.6666666667)
    assert result["paired_bootstrap_95_percent"] == pytest.approx([40., 40.])
    assert len(result["read_schedule_checks"]) == len(result["recorded_loss_gates"]) == 8
    assert result["passes_practical_2_percent_gate"] is True
    assert "native_arm_for_both" not in result and "equal_cache_work" not in result
    assert q.VARIANTS == final.VARIANTS
    assert Path(q.__file__).absolute() == Path(final.__file__).absolute()
    assert q.ACCURACY_VARIANTS == ("ordinary_legacy", "legacy", "grouped")


@pytest.mark.parametrize("corruption", [
    "short", "position", "duplicate_pid", "native_arm", "different_source", "spec",
    "route_flag", "wrong_constructor", "empty_constructor", "not_restored", "bad_proof",
    "loss", "nan_time", "negative_time", "finite_state", "incomplete", "changed_rtol",
    "changed_atol", "baseline_cache", "candidate_ceiling", "candidate_inactive",
    "negative_counter", "accounting", "read_ratio", "warmup_cache", "warmup_read_ratio",
])
def test_corruptions_cannot_grant_a_speed_verdict(corruption):
    rows = blocks()
    common = copy.copy(COMMON)
    base = rows[0]["result"]
    cand = rows[1]["result"]
    if corruption == "short":
        rows.pop()
    elif corruption == "position":
        rows[0]["position"] = 1
    elif corruption == "duplicate_pid":
        cand["worker"]["pid"] = cand["envelope"]["pid"] = base["worker"]["pid"]
    elif corruption == "native_arm":
        base["worker"]["arm"] = "two_read_cache"
    elif corruption == "different_source":
        base["envelope"]["source_commit"] = "a" * 40
    elif corruption == "spec":
        base["worker"]["spec_sha256"] = "x" * 64
    elif corruption == "route_flag":
        base["worker"]["timing"]["runtime_after"]["expert_grouped_routes"] = q.expected_routes(True)
    elif corruption == "wrong_constructor":
        base["envelope"]["dispatch"]["mode"] = "grouped_constructor"
    elif corruption == "empty_constructor":
        base["envelope"]["dispatch"]["factory_calls"] = 0
    elif corruption == "not_restored":
        base["envelope"]["dispatch"]["factory_restored"] = False
    elif corruption == "bad_proof":
        base["envelope"]["dispatch"]["build_proofs"][0]["expert_modules"] = 46
    elif corruption == "loss":
        cand["worker"]["timing"]["losses"][0] += .001
    elif corruption in ("nan_time", "negative_time"):
        base["worker"]["timing"]["update_seconds"][0] = (
            float("nan") if corruption == "nan_time" else -1)
    elif corruption == "finite_state":
        base["worker"]["timing"]["finite_state_checks_per_update"] = False
    elif corruption == "incomplete":
        base["worker"]["timing"]["updates_complete"] = 5
    elif corruption == "changed_rtol":
        common.RTOL = .1
    elif corruption == "changed_atol":
        common.ATOL = .1
    else:
        phase = "warmup" if corruption.startswith("warmup") else "timing"
        before = cand["worker"][phase]["runtime_before"]["expert_cache"]
        after = cand["worker"][phase]["runtime_after"]["expert_cache"]
        if corruption == "baseline_cache":
            base["worker"][phase]["runtime_after"]["expert_cache"]["host"]["budget_bytes"] = 1
        elif corruption == "candidate_ceiling":
            before["device"]["budget_bytes"] -= 1
        elif corruption in ("candidate_inactive", "warmup_cache"):
            after["device"]["hits"] = 0
        elif corruption == "negative_counter":
            after["storage_reads"] = -1
        elif corruption == "accounting":
            after["materializations"] += 1
        elif corruption in ("read_ratio", "warmup_read_ratio"):
            for key in ("logical_fetches", "storage_reads", "materializations"):
                after[key] += 1
    with pytest.raises(ValueError):
        final.timing_summary(rows, common)


def test_public_recipe_and_defaults_still_refuse_changes():
    q.validate_protocol(controls.spec())
    for key, value in (("rounds", 3), ("host_cache_bytes", 7 * 2**30),
                       ("warmup_updates", 1), ("timed_updates", 5),
                       ("accuracy_updates", 1), ("seq_len", 256)):
        changed = controls.spec()
        changed[key] = value
        with pytest.raises(ValueError):
            q.validate_protocol(changed)


def test_private_wrapper_launches_all_workers_through_itself(tmp_path, monkeypatch):
    import json
    import subprocess

    row = blocks()[0]["result"]
    path = tmp_path / "spec.json"
    path.write_text("{}")
    identity = {key: row["envelope"][key] for key in (
        "source_commit", "expert_module_sha256", "runtime_module_sha256",
        "constructor_source_sha256", "wrapper_sha256")}
    observed = []
    monkeypatch.setattr(q, "project", lambda *_: (
        SimpleNamespace(verify_spec=lambda *_args, **_kwargs: None), None, None, None, identity))

    def fake_run(command, **_kwargs):
        observed.append(command)
        out = Path(command[command.index("--out") + 1])
        raw = row["worker"]
        raw["spec_sha256"] = q.digest(path)
        (out / "result.json").write_text(json.dumps(raw))
        env = row["envelope"]
        env["spec_sha256"] = q.digest(path)
        env["native_result_sha256"] = q.digest(out / "result.json")
        (out / "dispatch-envelope.json").write_text(json.dumps(env))
        return SimpleNamespace(returncode=0)

    monkeypatch.setattr(subprocess, "run", fake_run)
    q.launch(path, {"timeout_seconds": 60}, "ordinary_legacy", "timing", tmp_path / "out",
             ROOT, final.SOURCE_COMMIT)
    assert Path(observed[0][1]).absolute() == Path(final.__file__).absolute()
    assert observed[0][observed[0].index("--variant") + 1] == "ordinary_legacy"


def test_independent_audit_recomputes_same_contrast():
    rows = blocks()
    expected = final.timing_summary(rows, COMMON)
    actual = independent.recompute_timing(rows)
    assert all(expected[key] == value for key, value in actual.items())


@pytest.mark.parametrize("corruption", ["counter", "schedule", "source", "pid", "cache", "loss"])
def test_independent_audit_rejects_relabelled_or_mismatched_work(corruption):
    rows = blocks()
    result = rows[0]["result"]
    if corruption == "counter":
        result["worker"]["timing"]["runtime_after"]["expert_cache"]["logical_fetches"] += 1
    elif corruption == "schedule":
        rows[0]["position"] = 1
    elif corruption == "source":
        result["envelope"]["source_commit"] = "b" * 40
    elif corruption == "pid":
        duplicate = result["worker"]["pid"]
        rows[1]["result"]["worker"]["pid"] = rows[1]["result"]["envelope"]["pid"] = duplicate
    elif corruption == "cache":
        result["worker"]["warmup"]["runtime_before"]["expert_cache"]["host"]["budget_bytes"] = 1
    else:
        result["worker"]["timing"]["losses"][0] += .001
    with pytest.raises(ValueError):
        independent.recompute_timing(rows)
