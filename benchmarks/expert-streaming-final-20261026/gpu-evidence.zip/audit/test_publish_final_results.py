"""Offline controls for publication privacy, lossless evidence and audit bindings."""

import hashlib
import json
import random
import zipfile

import pytest

import publish_final_results as publish


def test_exact_alias_packet_restores_each_original_and_binds_index(tmp_path):
    target = tmp_path / "packet.zip"
    payload = b"an exact synthetic receipt\n" * 100
    entries = [("first/receipt.json", payload, "synthetic receipt one"),
               ("second/receipt.json", payload, "synthetic duplicate receipt"),
               ("other.txt", b"different", "separate bytes")]
    result = publish.write_packet(target, entries)
    assert result["logical_originals"] == 3 and result["stored_members"] == 2
    assert result["aliases"] == 1 and result["all_originals_restore_verified"] is True
    with zipfile.ZipFile(target) as archive:
        index = archive.read("files.json")
        assert hashlib.sha256(index).hexdigest() == result["index_sha256"]
        rows = json.loads(index)["files"]
        assert rows["second/receipt.json"]["member"] == "first/receipt.json"
        for name, original, _ in entries:
            assert archive.read(rows[name]["member"]) == original


@pytest.mark.parametrize("value", [
    b'{"nested":{"api_key":"do-not-publish"}}',
    b'{"access_token":"sensitive"}',
    b'-----BEGIN OPENSSH ' b'PRIVATE KEY-----\nsynthetic\n',
    b'prefix-exact-fake-account-key-suffix',
], ids=["nested-api", "access-token", "private-key-header", "exact-secret"])
def test_private_material_never_enters_packet(value):
    with pytest.raises(ValueError):
        publish.check_private(value, (b"exact-fake-account-key",))


def test_reference_to_key_loading_code_and_redacted_values_are_not_credentials():
    publish.check_private(b'KEY_FILE.read_text().strip()', (b"exact-fake-account-key",))
    publish.check_private(b'{"api_key":"[redacted]","hf_token":null}', ())


@pytest.mark.parametrize("name", ["../escape", "/absolute", "a/../../escape"])
def test_evidence_member_cannot_escape_restoration_root(tmp_path, name):
    with pytest.raises(ValueError):
        publish.write_packet(tmp_path / "packet.zip", [(name, b"synthetic", "test")])


def test_over_size_packet_is_refused_without_silent_dropping(tmp_path, monkeypatch):
    monkeypatch.setattr(publish, "MAX_ZIP", 32)
    with pytest.raises(ValueError, match="no files dropped"):
        publish.write_packet(tmp_path / "packet.zip", [("original", b"synthetic", "test")])


def test_failed_numerical_audit_creates_no_publication_files(tmp_path):
    numerical = tmp_path / "numerical.json"
    infrastructure = tmp_path / "infrastructure.json"
    numerical.write_text('{"status":"failed"}', encoding="utf-8")
    infrastructure.write_text('{"status":"passed_final_infrastructure_retention_cleanup_audit"}',
                              encoding="utf-8")
    out = tmp_path / "must-not-exist"
    with pytest.raises(ValueError, match="numerical/timing audit has not passed"):
        publish.build(tmp_path / "no-stage", numerical, infrastructure, out,
                      tmp_path / "no-failed-stage", tmp_path / "no-reconciliation", ())
    assert not out.exists()


def test_passed_numerical_audit_alone_cannot_publish(tmp_path):
    with pytest.raises(ValueError, match="infrastructure/retention/cleanup"):
        publish.verify_audits(tmp_path,
            {"status": "passed_independent_final_numerical_timing_audit"}, {"status": "failed"})


def test_audits_are_bound_to_executed_scripts_archive_bundle_and_final_run(tmp_path, monkeypatch):
    monkeypatch.setattr(publish, "PREP", tmp_path)
    for name in ("audit_final_comparison.py", "audit_final_infrastructure.py",
                 "archive-manifest.json", "bundle-verified.json"):
        (tmp_path / name).write_bytes(b"synthetic binding\n" + name.encode())
    monkeypatch.setattr(publish, "AUDITOR_HASHES", {name: publish.sha(tmp_path / name)
        for name in ("audit_final_comparison.py", "audit_final_infrastructure.py")})
    directory = tmp_path / "retained/results/dispatch-qualification"
    directory.mkdir(parents=True)
    run = {"status": "completed", "accuracy_passed": True, "source_commit": publish.SOURCE,
           "timing_contrast": list(publish.VARIANTS), "timing_blocks": [{}] * 8,
           "timing_summary": {"synthetic": "matched"}, "original_gates": {
               "reference_relative_rtol": .01, "atol": 1e-5,
               "loss_three_decimal": True, "finite": True}}
    path = directory / "run.json"
    path.write_text(json.dumps(run), encoding="utf-8")
    binding = {"source_commit": publish.SOURCE, "stage_id": publish.STAGE_ID,
               "archive_manifest_sha256": publish.sha(tmp_path / "archive-manifest.json"),
               "bundle_verified_sha256": publish.sha(tmp_path / "bundle-verified.json"),
               "qualification_run_sha256": publish.sha(path)}
    numerical = {**binding, "status": "passed_independent_final_numerical_timing_audit",
        "workers": 11, "accuracy_gates": {name: {"passed": True} for name in ("a", "b", "c")},
        "audit_script_sha256": publish.sha(tmp_path / "audit_final_comparison.py"),
        "timing_recomputed": {"synthetic": "matched"}}
    infrastructure = {**binding,
        "status": "passed_final_infrastructure_retention_cleanup_audit", "audit_version": 5,
        "checks": ["synthetic"],
        "audit_script_sha256": publish.sha(tmp_path / "audit_final_infrastructure.py")}
    assert publish.verify_audits(tmp_path, numerical, infrastructure) == run
    for key in ("archive_manifest_sha256", "bundle_verified_sha256", "qualification_run_sha256",
                "audit_script_sha256", "source_commit", "stage_id"):
        changed = dict(numerical, **{key: "stale"})
        with pytest.raises(ValueError):
            publish.verify_audits(tmp_path, changed, infrastructure)
    path.write_text(json.dumps(dict(run, status="changed")), encoding="utf-8")
    with pytest.raises(ValueError, match="bound"):
        publish.verify_audits(tmp_path, numerical, infrastructure)


@pytest.fixture
def budget_case(tmp_path):
    stage, failed = tmp_path / "successful", tmp_path / "f9"
    stage.mkdir()
    failed.mkdir()
    original = failed / "rejected-create.json"
    original.write_bytes(b'{"allocation":null}\n')
    initial = 6.202879736617223
    before = initial - sum(publish.FAILED_COSTS.values())
    context = {"aggregate_remaining_before_f15_usd": before,
               "prior_remaining_usd": 1.202879736617223, "new_authorized_usd": 5.,
               **{"failed_" + tag + "_cost_usd": cost
                  for tag, cost in publish.FAILED_COSTS.items()}}
    (stage / "prior-budget-context.json").write_bytes(publish.encoded(context))
    ledger = {"stage_id": publish.STAGE_ID, "maximum_stage_usd": 3.,
        "completed_leases": [{"instance_id": 123, "volume_id": 124,
            "verified_absent": True, "volume_verified_absent": True, "conservative_usd": .5}]}
    (stage / "stage-ledger.json").write_bytes(publish.encoded(ledger))
    reconciliation = tmp_path / "reconcile.json"
    reconciliation.write_bytes(publish.encoded({
        "status": "reconciled_failed_before_allocation_prospective_allowances_releasable",
        "creation_outcome": {"instance_id": None, "volume_id": None},
        "reconciliation": {"may_release_for_next_stage_admission": True,
            "run_attributable_expected_rental_storage_and_model_network_usd": 0},
        "evidence": {original.name: {"bytes": original.stat().st_size,
                                    "sha256": publish.sha(original)}},
        "ledger_decomposition_usd": {"raw_conservative_usd": 1.2690072383850324}}))
    proofs = {tag: {"status": "FAILED_TEST_FIXTURE", "full_30b_verdict": "NO VERDICT",
        "conservative_usd": cost, "lease": {"instance_id": 200+i, "volume_id": 300+i,
            "verified_absent": True, "volume_verified_absent": True, "conservative_usd": cost}}
        for i, (tag, cost) in enumerate(publish.FAILED_COSTS.items())}
    return stage, failed, reconciliation, proofs


def test_all_failed_paid_stages_charged_once_f9_reserve_is_not_an_invoice(budget_case):
    result = publish.make_budget(*budget_case)
    prior = sum(publish.FAILED_COSTS.values())
    assert result["remaining_usd"] == pytest.approx(6.202879736617223 - prior - .5)
    assert result["remaining_before_f15_usd"] == pytest.approx(3.786765941175221)
    assert result["all_new_attempts_conservative_usd"] == pytest.approx(prior + .5)
    assert result["failed_paid_stages_conservative_usd"] == pytest.approx(2.4161137954420016)
    assert result["failed_f9_raw_prospective_ledger_usd"] == 1.2690072383850324
    assert result["failed_f9_reconciled_expected_run_cost_usd"] == 0
    assert "not provider invoices" in result["semantics"]


@pytest.mark.parametrize("mutation", ["release_f12", "double_deduct_f11", "relabel_f11",
                                    "missing_f12", "duplicate_instance", "duplicate_volume",
                                    "f14_over_cap", "f9_changed", "unclean_failed",
                                    "release_f13", "double_deduct_f13"])
def test_budget_denies_wrong_cost_relabelling_and_aliases(budget_case, mutation):
    stage, failed, reconciliation, proofs = budget_case
    context_path = stage / "prior-budget-context.json"
    context = publish.read(context_path)
    ledger_path = stage / "stage-ledger.json"
    ledger = publish.read(ledger_path)
    if mutation == "release_f12":
        context["failed_f12_cost_usd"] = 0
    elif mutation == "release_f13":
        context["failed_f13_cost_usd"] = 0
    elif mutation == "double_deduct_f13":
        context["aggregate_remaining_before_f15_usd"] -= proofs["f13"]["conservative_usd"]
    elif mutation == "double_deduct_f11":
        context["aggregate_remaining_before_f15_usd"] -= proofs["f11"]["conservative_usd"]
    elif mutation == "relabel_f11":
        proofs["f11"]["status"] = "passed"
    elif mutation == "missing_f12":
        del proofs["f12"]
    elif mutation == "duplicate_instance":
        proofs["f12"]["lease"]["instance_id"] = 123
    elif mutation == "duplicate_volume":
        proofs["f12"]["lease"]["volume_id"] = 124
    elif mutation == "f14_over_cap":
        ledger["completed_leases"][0]["conservative_usd"] = 3.01
    elif mutation == "f9_changed":
        (failed / "rejected-create.json").write_bytes(b'changed')
    elif mutation == "unclean_failed":
        proofs["f11"]["lease"]["volume_verified_absent"] = False
    context_path.write_bytes(publish.encoded(context))
    ledger_path.write_bytes(publish.encoded(ledger))
    with pytest.raises(ValueError):
        publish.make_budget(stage, failed, reconciliation, proofs)


@pytest.mark.parametrize("tag,verifier", [("f10", publish.failed_f10_proof),
    ("f11", publish.failed_f11_proof), ("f12", publish.failed_f12_proof),
    ("f13", publish.failed_f13_proof), ("f14", publish.failed_f14_proof)])
def test_real_retained_failed_stages_stay_failed_and_charge_actual_ledger_once(tag, verifier):
    stage = publish.RESEARCH / ("kanana-30b-final-gpu-20261026-" + tag)
    result = verifier(stage)
    assert result["status"].startswith("FAILED")
    assert result["full_30b_verdict"] == "NO VERDICT"
    assert result["conservative_usd"] == publish.FAILED_COSTS[tag]
    assert result["exact_cleanup"]["verified_absent"] is True
    if tag == "f11":
        assert len(result["full_retained_originals"]["files"]) == 87
        assert result["operator_stop"]["phase_before"]["phase"] == "download"
    elif tag == "f14":
        assert len(result["full_retained_originals"]["files"]) == 116
        assert result["observed_cgroup_swap_after_bytes"] == 51142656
        assert result["sampled_peak_process_swap_bytes"] == 0
        assert result["ordinary_capture"].startswith("Retained invalid-condition")
    elif tag == "f13":
        assert len(result["full_retained_originals"]["files"]) == 94
        assert result["all_13_official_pins_equal_f8"] is True
        assert result["actual_bad_shard_sha256"].startswith("NOT RECORDED")
        assert result["failure_cause"].startswith("UNKNOWN")
    elif tag == "f12":
        assert len(result["full_retained_local_index"]["indexed_exact_local_files"]) == 92
        assert result["lease"]["actual_network_telemetry_retained"] is False


@pytest.mark.parametrize("tag,filename,key,value", [
    ("f11", "operator-download-stop.json", "status", "completed"),
    ("f11", "operator-download-stop.json", "numerical_or_timing_gates_changed", True),
    ("f11", "bundle-verified.json", "whole_archive_verified", False),
    ("f11", "independent-vast-absence.json", "volume_id", -1),
    ("f12", "failure-evidence-index.json", "status", "passed"),
    ("f12", "failure-evidence-index.json", "numerical_speed_memory_verdict", "passed"),
    ("f12", "controller-failure.json", "archive_collected", True),
    ("f12", "independent-vast-absence.json", "verified_absent", False),
])
def test_real_failed_stage_metadata_mutations_fail_closed(monkeypatch, tag, filename, key, value):
    stage = publish.RESEARCH / ("kanana-30b-final-gpu-20261026-" + tag)
    original_read = publish.read

    def altered(path):
        data = original_read(path)
        if path == stage / filename:
            data[key] = value
        return data

    monkeypatch.setattr(publish, "read", altered)
    with pytest.raises(ValueError):
        (publish.failed_f11_proof if tag == "f11" else publish.failed_f12_proof)(stage)


def test_retained_original_content_change_is_detected(tmp_path):
    original = tmp_path / "original.json"
    original.write_bytes(b"original")
    rows = {original.name: {"bytes": original.stat().st_size, "sha256": publish.sha(original)}}
    publish.verify_files(tmp_path, rows)
    original.write_bytes(b"tampered")
    with pytest.raises(ValueError, match="retained original changed"):
        publish.verify_files(tmp_path, rows)


def test_real_failed_packet_includes_every_small_original_and_restores_below_cap(
        tmp_path, record_testsuite_property):
    roots = {tag: publish.RESEARCH / ("kanana-30b-final-gpu-20261026-" + tag)
             for tag in publish.FAILED_COSTS}
    proofs = {"f10": publish.failed_f10_proof(roots["f10"]),
              "f11": publish.failed_f11_proof(roots["f11"]),
              "f12": publish.failed_f12_proof(roots["f12"]),
              "f13": publish.failed_f13_proof(roots["f13"]),
              "f14": publish.failed_f14_proof(roots["f14"])}
    entries, omissions = publish.failed_packet_entries(roots, proofs)
    new_ops, _new_binding = publish.frozen_ops_entries(
        publish.RESEARCH / "kanana-30b-final-gpu-20261026-f15")
    entries.extend(new_ops)
    for _name, value, _scope in entries:
        publish.check_private(value, ())
    names = {name for name, _value, _scope in entries}
    for tag in ("f10", "f11", "f13", "f14"):
        rows = proofs[tag]["full_retained_originals"]["files"]
        for name, row in rows.items():
            if name in omissions[tag]:
                assert row["bytes"] > 64 * 1024
                assert omissions[tag][name]["sha256"] == row["sha256"]
                assert "retained locally" in omissions[tag][name]["reason"]
            else:
                assert tag.upper() + "/" + name in names
        assert not any(name.endswith((".xml", ".log", ".json")) for name in omissions[tag])
    assert "F11/proofs/operator-download-stop.json" in names
    assert "F12/controller-failure.json" in names
    assert "F12/failure-evidence-index.json" in names
    assert not any(name.endswith("/ssh-key") for name in names)
    receipt = publish.write_packet(tmp_path / "failed-only.zip", entries)
    record_testsuite_property("all_failed_plus_f15_ops_packet_bytes", receipt["bytes"])
    assert receipt["bytes"] < publish.MAX_ZIP
    assert receipt["all_originals_restore_verified"] is True
    assert receipt["aliases"] > 0


@pytest.fixture
def freeze_case(tmp_path, monkeypatch):
    protocol = {"stage_id": publish.STAGE_ID, "source_commit": publish.SOURCE,
                "financial": {"maximum_stage_usd": 3., "maximum_seconds": 14400,
                              "download_allowance_decimal_gb": 90, "root_provider_gb": 32,
                              "volume_provider_gb": 112, "prior_usd": 0},
                "native_boundary": {"minimum_root_free_bytes": 16 * publish.GIB,
                    "minimum_data_free_bytes": 100 * publish.GIB, "swap_must_be_disabled": True}}
    rental = {"stage_id": publish.STAGE_ID, "source_sha256": publish.SOURCE_ARCHIVE,
              "maximum_usd": 3., "maximum_seconds": 14400, "prior_usd": 0,
              "allocated_disk_gb": 32, "volume_size_gb": 112}
    (tmp_path / "protocol.json").write_bytes(publish.encoded(protocol))
    (tmp_path / "vast-rental.json").write_bytes(publish.encoded(rental))
    (tmp_path / "final_comparison.py").write_bytes(b"synthetic wrapper")
    (tmp_path / "source.tar.gz").write_bytes(b"synthetic source")
    (tmp_path / "storage-capacity-plan.json").write_bytes(publish.encoded({"plan": {
        "root_provider_gb": 32, "volume_provider_gb": 112,
        "advertised_combined_pool_required": 144,
        "minimum_pre_download_root_free_bytes": 16 * publish.GIB,
        "minimum_pre_download_data_free_bytes": 100 * publish.GIB,
        "raw_outputs_reserve_is_unchanged": True,
        "root_components_bytes": {"raw_outputs_reserve": 12 * publish.GIB},
        "actual_statvfs_is_authoritative": True}}))
    protocol["storage_capacity_plan"] = publish.read(
        tmp_path / "storage-capacity-plan.json")["plan"]
    (tmp_path / "protocol.json").write_bytes(publish.encoded(protocol))
    original_sha = publish.sha

    def fixture_sha(path):
        return {"final_comparison.py": publish.WRAPPER,
                "source.tar.gz": publish.SOURCE_ARCHIVE}.get(path.name, original_sha(path))

    monkeypatch.setattr(publish, "sha", fixture_sha)
    (tmp_path / "launch-manifest.json").write_bytes(publish.encoded({"files": {
        name: {"bytes": (tmp_path / name).stat().st_size, "sha256": fixture_sha(tmp_path / name)}
        for name in ("protocol.json", "final_comparison.py", "source.tar.gz",
                     "storage-capacity-plan.json")}}))
    return tmp_path


@pytest.mark.parametrize("mutation", [None, "deadline", "cap", "source", "identity", "wrapper",
                                     "root_layout", "volume_layout"])
def test_f15_freeze_requires_approved_source_cap_deadline_and_storage(freeze_case, mutation):
    stage = freeze_case
    if mutation in ("deadline", "cap", "source", "identity", "root_layout", "volume_layout"):
        rental = publish.read(stage / "vast-rental.json")
        key, value = {"deadline": ("maximum_seconds", 7200), "cap": ("maximum_usd", 4.),
                      "source": ("source_sha256", "changed"),
                      "identity": ("stage_id", "soup-kanana-30b-final-20261026-f11"),
                      "root_layout": ("allocated_disk_gb", 64),
                      "volume_layout": ("volume_size_gb", 150)}[mutation]
        rental[key] = value
        (stage / "vast-rental.json").write_bytes(publish.encoded(rental))
    elif mutation == "wrapper":
        launch = publish.read(stage / "launch-manifest.json")
        launch["files"]["final_comparison.py"]["sha256"] = "changed"
        (stage / "launch-manifest.json").write_bytes(publish.encoded(launch))
    if mutation:
        with pytest.raises(ValueError):
            publish.verify_stage_freeze(stage)
    else:
        publish.verify_stage_freeze(stage)


def test_real_f13_packet_contains_exact_frozen_helpers_tests_and_review_with_restore(tmp_path):
    stage = publish.RESEARCH / "kanana-30b-final-gpu-20261026-f13"
    entries, binding = publish.frozen_ops_entries(stage, tag="f13")
    sources = {name: value for name, value, _provenance in entries}
    launch = publish.read(stage / "launch-manifest.json")
    for name, row in launch["files"].items():
        if name.endswith((".py", ".sh")) or name == "constraints.txt":
            assert sources["F13/ops/" + name] == (stage / name).read_bytes()
            assert hashlib.sha256(sources["F13/ops/" + name]).hexdigest() == row["sha256"]
    for critical in ("api_transport.py", "api_rate_limit.py", "cloud.py", "controller.py",
                     "launch.py", "test_f13_independent_transport_review.py"):
        assert "F13/ops/" + critical in sources
    assert "audit/f13-independent-ops-review.json" in sources
    assert binding["launch_manifest_sha256"] == publish.sha(stage / "launch-manifest.json")
    assert not any(name.endswith(("ssh-key", "ssh-key.pub", "source.tar.gz")) for name in sources)
    duplicate = sources["F13/ops/api_transport.py"]
    entries.append(("duplicate/api_transport.py", duplicate, "Exact duplicate restoration control"))
    for _name, value, _scope in entries:
        publish.check_private(value, ())
    packet = publish.write_packet(tmp_path / "ops.zip", entries)
    assert packet["aliases"] > 0 and packet["all_originals_restore_verified"] is True


@pytest.mark.parametrize("mutation", ["missing_helper", "changed_source_hash", "stale_review"])
def test_frozen_ops_packet_rejects_missing_changed_or_unreviewed_launch(monkeypatch, mutation):
    stage = publish.RESEARCH / "kanana-30b-final-gpu-20261026-f13"
    original_read = publish.read

    def altered(path):
        data = original_read(path)
        if path == stage / "launch-manifest.json":
            if mutation == "missing_helper":
                del data["files"]["api_rate_limit.py"]
            elif mutation == "changed_source_hash":
                data["files"]["api_transport.py"]["sha256"] = "changed"
        elif (path == publish.PREP / "f13-independent-ops-review.json"
              and mutation == "stale_review"):
            data["launch_manifest_sha256"] = "stale"
        return data

    monkeypatch.setattr(publish, "read", altered)
    with pytest.raises(ValueError):
        publish.frozen_ops_entries(stage, tag="f13")


@pytest.mark.parametrize("mutation", ["status", "official_pin", "cost", "cleanup"])
def test_real_failed_f13_cannot_be_relabelled_repriced_or_repin_model(monkeypatch, mutation):
    stage = publish.RESEARCH / "kanana-30b-final-gpu-20261026-f13"
    original_read = publish.read

    def altered(path):
        data = original_read(path)
        if mutation == "status" and path == stage / "retained/results/stage-status.json":
            data["status"] = "completed"
        elif mutation == "official_pin" and path == stage / "retained/results/model-pinned.json":
            data["files"]["model-00012-of-00013.safetensors"]["lfs"]["sha256"] = "0" * 64
        elif mutation == "cost" and path == stage / "stage-ledger.json":
            data["completed_leases"][0]["conservative_usd"] = 0
        elif mutation == "cleanup" and path == stage / "independent-vast-absence.json":
            data["volume_verified_absent"] = False
        return data

    monkeypatch.setattr(publish, "read", altered)
    with pytest.raises(ValueError):
        publish.failed_f13_proof(stage)


def test_f14_cannot_accept_previous_v3_infrastructure_audit():
    with pytest.raises(ValueError, match="requires the independent v5"):
        publish.verify_audits(publish.PREP,
            {"status": "passed_independent_final_numerical_timing_audit"},
            {"status": "passed_final_infrastructure_retention_cleanup_audit", "audit_version": 3})


def test_f14_ops_cannot_reuse_f13_launch_without_checkpoint_helper_and_controls():
    stage = publish.RESEARCH / "kanana-30b-final-gpu-20261026-f13"
    with pytest.raises(ValueError, match="checkpoint-integrity CPU controls"):
        publish.frozen_ops_entries(stage, tag="f14")


def test_actual_f14_frozen_ops_and_final_integrity_controls_are_exact_and_bound(tmp_path):
    stage = publish.RESEARCH / "kanana-30b-final-gpu-20261026-f14"
    entries, binding = publish.frozen_ops_entries(stage, tag="f14")
    sources = {name: value for name, value, _scope in entries}
    for filename in ("checkpoint_integrity.py", "remote_run.py", "preflight_remote.py",
                     "controller.py", "transport.py", "test_f14_independent_integrity.py",
                     "f14-independent-mutation-review.json", "f14-input-repair-tests.xml",
                     "audit-v4-freeze-review.json", "f14-actual-f8-schema-control-final.json"):
        assert sources["F14/ops/" + filename] == (stage / filename).read_bytes()
    assert binding["launch_manifest_sha256"] == publish.sha(stage / "launch-manifest.json")
    assert "audit/f14-independent-ops-review.json" in sources
    assert publish.F14_INFRA_AUDITOR == publish.sha(stage / "audit_final_infrastructure.py")
    for _name, value, _scope in entries:
        publish.check_private(value, ())
    result = publish.write_packet(tmp_path / "f14-ops.zip", entries)
    assert result["all_originals_restore_verified"] is True


@pytest.mark.parametrize("mutation", ["helper", "v4_pin", "final_schema", "report_count"])
def test_actual_f14_review_mutations_cannot_replace_final_helper_or_controls(monkeypatch, mutation):
    original_read = publish.read

    def altered(path):
        data = original_read(path)
        if path == publish.PREP / "f14-independent-ops-review.json":
            if mutation == "helper":
                data["checkpoint_helper_sha256"] = "old helper"
            elif mutation == "v4_pin":
                data["infrastructure_auditor_sha256"] = "old audit"
            elif mutation == "final_schema":
                data["actual_successful_f8_native_schema_control_sha256"] = "old schema"
            elif mutation == "report_count":
                data["test_case_counts_by_report"]["f14-input-repair-tests.xml"] += 225
        return data

    monkeypatch.setattr(publish, "read", altered)
    with pytest.raises(ValueError):
        publish.frozen_ops_entries(
            publish.RESEARCH / "kanana-30b-final-gpu-20261026-f14", tag="f14")


@pytest.fixture
def settings_run():
    def cell():
        return {"result": {"worker": {"environment": {
            "deterministic_algorithms": True, "allow_tf32": False,
            "training_mode": "eval with differentiable LoRA updates; dropout disabled"}}}}
    return {"accuracy": {name: cell() for name in ("ordinary_legacy", "legacy", "grouped")},
            "timing_blocks": [cell() for _ in range(8)]}


def test_execution_scope_reports_recorded_settings_and_unrecorded_fill_as_no_verdict(settings_run):
    result = publish.execution_scope(settings_run)
    assert result["recorded_in_all_11_workers"]["deterministic_algorithms"] is True
    assert result["recorded_in_all_11_workers"]["allow_tf32"] is False
    assert result["fill_uninitialized_memory"]["status"].startswith("NO VERDICT")
    assert result["fill_uninitialized_memory"]["recorded_values"] is None
    assert "no universal" in result["generalization"]
    assert result["allocation_fill_cause"].startswith("NO VERDICT")


@pytest.mark.parametrize("key,value", [("deterministic_algorithms", False),
                                      ("allow_tf32", True), ("training_mode", "training")])
def test_execution_scope_requires_actual_worker_settings(settings_run, key, value):
    settings_run["timing_blocks"][-1]["result"]["worker"]["environment"][key] = value
    with pytest.raises(ValueError, match="Recorded execution settings differ"):
        publish.execution_scope(settings_run)


@pytest.mark.parametrize("mutation", ["passed_worker", "allow_swap", "timing", "zero_cost"])
def test_failed_f14_invalid_baseline_cannot_become_valid_or_unpaid(monkeypatch, mutation):
    stage = publish.RESEARCH / "kanana-30b-final-gpu-20261026-f14"
    original_read = publish.read

    def altered(path):
        data = original_read(path)
        if path == stage / ("retained/results/dispatch-qualification/accuracy/"
                            "ordinary_legacy/result.json"):
            if mutation == "passed_worker":
                data["status"] = "passed"
            elif mutation == "allow_swap":
                data["accuracy"]["resources"]["after"]["cgroup"]["constraints"][0][
                    "memory.swap.current"] = 0
        elif (path == stage / "retained/results/dispatch-qualification/run.json"
              and mutation == "timing"):
            data["timing_blocks"] = [{"fabricated": True}]
        elif path == stage / "stage-ledger.json" and mutation == "zero_cost":
            data["completed_leases"][0]["conservative_usd"] = 0
        return data

    monkeypatch.setattr(publish, "read", altered)
    with pytest.raises(ValueError):
        publish.failed_f14_proof(stage)


@pytest.mark.parametrize("receipt", ["vast-rental.json", "vast-allocation-intent.json"])
def test_failure_only_cannot_hide_a_final_active_or_ambiguous_lease(tmp_path, receipt):
    stage = tmp_path / "active-final"
    stage.mkdir()
    (stage / receipt).write_bytes(b'{"instance_id":123}')
    out = tmp_path / "never-created"
    with pytest.raises(ValueError, match="cannot omit a final allocated or ambiguous lease"):
        publish.build_failure_only(out, stage, tmp_path / "f9", tmp_path / "reconciliation", ())
    assert not out.exists()


def test_failure_only_preserves_costs_invalid_capture_and_no_verdict(tmp_path):
    out = tmp_path / "failed-draft"
    final_stage = tmp_path / "no-allocation"
    final_stage.mkdir()
    result = publish.build_failure_only(out, final_stage,
        publish.RESEARCH / "kanana-30b-final-gpu-20261026-f9",
        publish.PREP / "f9-budget-reconciliation.json", ())
    summary = publish.read(out / "gpu-results-summary.json")
    manifest = publish.read(out / "evidence-manifest.json")
    assert summary["status"] == "FAILED_NO_COMPARATIVE_VERDICT"
    assert summary["paired_timing"] == summary["comparative_accuracy"] == "NO VERDICT"
    assert "timing" not in summary and "accuracy" not in summary
    assert summary["budget"]["failed_paid_total_usd"] == pytest.approx(2.4161137954420016)
    assert result["remaining_usd"] == pytest.approx(3.786765941175221)
    assert summary["budget"]["f9_expected_cost_usd"] == 0
    assert summary["failed_stages"]["f14"]["status"] == "FAILED_CGROUP_NO_SWAP_BOUNDARY"
    capture = "results/dispatch-qualification/accuracy/ordinary_legacy/capture.pt"
    assert capture in manifest["failed_packet_omissions"]["f14"]
    assert manifest["failed_packet_omissions"]["f14"][capture]["bytes"] > 64 * 1024
    assert manifest["retained_input_archive_omissions"]["f14"]["source.tar.gz"][
        "sha256"] == publish.SOURCE_ARCHIVE
    assert result["packet"]["bytes"] <= publish.MAX_ZIP
    assert result["packet"]["all_originals_restore_verified"] is True
    report = (out / "README.md").read_text()
    assert "no speedup percentage" in report
    assert "invalid run" in report and "not provider invoices" in report


def test_actual_f15_final_review_packages_exact_capacity_plan_tests_and_v5(tmp_path):
    stage = publish.RESEARCH / "kanana-30b-final-gpu-20261026-f15"
    entries, binding = publish.frozen_ops_entries(stage)
    originals = {name: value for name, value, _scope in entries}
    for name in ("storage-capacity-plan.json", "test_f15_independent_capacity.py",
                 "test_f15_storage.py", "audit-v5-freeze-review.json", "checkpoint_integrity.py",
                 "remote_run.py", "preflight_remote.py", "f15-independent-capacity.xml"):
        assert originals["F15/ops/" + name] == (stage / name).read_bytes()
    assert "audit/f15-independent-ops-review.json" in originals
    assert binding["launch_manifest_sha256"] == publish.sha(stage / "launch-manifest.json")
    assert publish.AUDITOR_HASHES["audit_final_infrastructure.py"] == publish.sha(
        publish.PREP / "audit_final_infrastructure.py")
    assert publish.AUDITOR_HASHES["audit_final_comparison.py"] == publish.sha(
        publish.PREP / "audit_final_comparison.py")
    for _name, value, _scope in entries:
        publish.check_private(value, ())
    receipt = publish.write_packet(tmp_path / "f15-ops.zip", entries)
    assert receipt["all_originals_restore_verified"] is True


@pytest.mark.parametrize("mutation", ["old_audit", "old_layout", "weaken_swap", "sum_counts"])
def test_f15_review_cannot_revert_capacity_audit_or_relabel_failed_swap(monkeypatch, mutation):
    stage = publish.RESEARCH / "kanana-30b-final-gpu-20261026-f15"
    original_read = publish.read

    def altered(path):
        data = original_read(path)
        if path == publish.PREP / "f15-independent-ops-review.json":
            if mutation == "old_audit":
                data["infrastructure_auditor_sha256"] = publish.F14_INFRA_AUDITOR
            elif mutation == "old_layout":
                data["preregistered_storage_plan"]["root_provider_gb"] = 24
            elif mutation == "weaken_swap":
                data["actual_f14_swap_negative_still_rejected"] = False
            elif mutation == "sum_counts":
                data["test_reports_overlap"] = False
        return data

    monkeypatch.setattr(publish, "read", altered)
    with pytest.raises(ValueError):
        publish.frozen_ops_entries(stage)


def test_repository_cap_rejects_packet_in_gap_below_former_five_mib_limit(tmp_path):
    assert publish.MAX_ZIP == 5_120_000
    payload = random.Random(43).randbytes(publish.MAX_ZIP + 1)
    target = tmp_path / "hook-gap.zip"
    with pytest.raises(ValueError, match="repository 5000 KiB limit; no files dropped"):
        publish.write_packet(target, [("incompressible.bin", payload, "Synthetic cap boundary")])
    assert 5_120_000 < target.stat().st_size < 5 * 2**20
