"""Immutable Kanana-30B baseline profiles then separate grouped-dispatch qualification."""

from __future__ import annotations

import gzip
import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import sys
import time
import traceback
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path('/root/liger')
REPO = ROOT / 'repo'
OUT = ROOT / 'results'
MODEL = 'kakaocorp/kanana-2-30b-a3b-base-2601'
REVISION = '0d31365acf656e5f9a593cacc4913e9c0d36cb1c'
SOURCE_BYTES = 61343935088


def digest(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for chunk in iter(lambda: handle.read(8 * 2**20), b''):
            value.update(chunk)
    return value.hexdigest()


def retain_exact_metadata(source, destination, expected_sha256):
    """Retain original metadata bytes only when their frozen identity remains stable."""
    source, destination = Path(source), Path(destination)
    temporary = destination.with_name(destination.name + '.incoming')
    if destination.exists() or destination.is_symlink() or temporary.exists() or temporary.is_symlink():
        raise FileExistsError('Refuse replacing existing retained metadata')
    before = source.stat()
    if digest(source) != expected_sha256:
        raise ValueError('Metadata source differs from its prepared fingerprint')
    try:
        shutil.copyfile(source, temporary)
        if temporary.stat().st_size != before.st_size or digest(temporary) != expected_sha256:
            raise ValueError('Copied metadata differs from its prepared fingerprint')
        after = source.stat()
        if (after.st_size != before.st_size or after.st_mtime_ns != before.st_mtime_ns
                or digest(source) != expected_sha256):
            raise ValueError('Metadata source changed while retaining its bytes')
        with temporary.open('r+b') as retained:
            retained.flush()
            os.fsync(retained.fileno())
        if destination.exists() or destination.is_symlink():
            raise FileExistsError('Retained metadata destination appeared during copying')
        os.replace(temporary, destination)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return {'bytes': before.st_size, 'sha256': expected_sha256}


def save(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)


def phase_receipt(phase, status, spec_path, command=None):
    path = OUT / 'phase-order.json'
    source = json.loads((ROOT / 'source-manifest.json').read_text())['source_commit']
    identity = {'source_commit': source, 'spec_sha256': digest(spec_path)}
    value = json.loads(path.read_text()) if path.exists() else {**identity, 'records': []}
    if any(value.get(key) != expected for key, expected in identity.items()):
        raise ValueError('Phase order identity changed')
    record = {'phase': phase, 'status': status, 'monotonic': time.monotonic(), 'unix': time.time()}
    if command is not None:
        record['command'] = command
    value['records'].append(record)
    save(path, value)


def pre_download_disk_gate():
    root_free, data_free = shutil.disk_usage(ROOT).free, shutil.disk_usage('/data').free
    proof = {'root_free_bytes': root_free, 'data_free_bytes': data_free,
             'minimum_root_bytes': 48 * 2**30, 'minimum_data_bytes': 130 * 2**30,
             'passed': root_free >= 48 * 2**30 and data_free >= 130 * 2**30,
             'unix': time.time()}
    save(OUT / 'pre-download-disk.json', proof)
    if not proof['passed']:
        raise RuntimeError('Root48GiB/data130GiB free reserve must hold before large download')
    return proof


def command(name, arguments, *, timeout=14400):
    save(OUT / 'stage-status.json', {'status': 'running', 'phase': name, 'unix': time.time()})
    with (OUT / (name + '.log')).open('wb') as log:
        process = subprocess.run(arguments, cwd=REPO, stdout=log, stderr=subprocess.STDOUT,
                                 timeout=timeout)
    save(OUT / (name + '-exit.json'), {'returncode': process.returncode, 'unix': time.time()})
    if process.returncode:
        raise RuntimeError(f'{name} failed with exit code {process.returncode}')


def export(status):
    import lossless_results

    export_dir = ROOT / 'exports'
    export_dir.mkdir(exist_ok=True)
    archive = export_dir / 'result.lossless.tar'
    files = [path for path in OUT.rglob('*') if path.is_file()]
    files += [ROOT / name for name in ('setup.log', 'source-manifest.json', 'constraints.txt',
                                      'preflight_remote.py', 'remote_run.py', 'setup.sh',
                                      'protocol.json', 'final_comparison.py', 'launch-manifest.json',
                                      'lossless_results.py')
              if (ROOT / name).is_file()]
    names = [path.relative_to(ROOT).as_posix() for path in files]
    packed = lossless_results.pack(ROOT, names, archive)
    mapping = {path.relative_to(ROOT).as_posix(): {
        'bytes': path.stat().st_size, 'sha256': digest(path),
    } for path in files}
    save(export_dir / 'archive-manifest.json', {
        'format': packed['format'], 'archive_bytes': packed['archive_bytes'],
        'sha256': packed['archive_sha256'], 'original_bytes': packed['original_bytes'],
        'files': mapping,
        'source_commit': json.loads((ROOT / 'source-manifest.json').read_text())['source_commit'],
        'stage_status': status,
    })


def validate_cuda_xml(path, expected_names):
    cases = ET.parse(path).findall('.//testcase')
    if len(cases) != len(expected_names) or any(
        case.find('skipped') is not None or case.find('failure') is not None
        or case.find('error') is not None for case in cases
    ):
        raise RuntimeError('All four required native CUDA numerical cells must pass without skips')
    if {case.attrib['name'] for case in cases} != set(expected_names):
        raise RuntimeError('CUDA XML differs from the frozen Kanana/NF4 preflight selection')


def qualify_accuracy(spec_path, out, protocol):
    """Original comparator, complete original captures, three fresh native workers."""
    import torch

    from benchmarks.harness import two_read_cache as native
    from benchmarks.harness import two_read_cache_common as common

    spec = json.loads(Path(spec_path).read_text())
    native.verify_spec(spec, content=True)
    out.mkdir(parents=True, exist_ok=False)
    arms = protocol['performance']['accuracy_arms']
    report = {'status': 'running', 'spec_sha256': digest(spec_path), 'accuracy': {},
              'source_commit': json.loads((ROOT / 'source-manifest.json').read_text())['source_commit'],
              'unchanged_reference_relative_rtol': common.RTOL,
              'unchanged_atol': common.ATOL, 'speed_verdict': 'not measured'}
    try:
        for arm in arms:
            save(OUT / 'stage-status.json', {'status': 'running', 'phase': 'accuracy-' + arm,
                                           'unix': time.time()})
            worker = native.launch_worker(Path(spec_path), spec, arm, 'accuracy', out / arm)
            report['accuracy'][arm] = {'worker': worker}
            save(out / 'run.json', report)
        reference = torch.load(out / 'ordinary/capture.pt', map_location='cpu', weights_only=True)
        report['accuracy']['ordinary']['capture_controls'] = validate_full_capture(reference, spec)
        report['accuracy']['ordinary']['gate'] = common.validate_capture(reference)
        for arm in arms[1:]:
            candidate = torch.load(out / arm / 'capture.pt', map_location='cpu', weights_only=True)
            if (len(candidate['updates']) != spec['accuracy_updates'] or
                    len(candidate['microbatches']) != spec['accuracy_updates'] * spec['accumulation']):
                raise ValueError('Accuracy capture omitted full updates/microbatches')
            report['accuracy'][arm]['capture_controls'] = validate_full_capture(candidate, spec)
            report['accuracy'][arm]['gate'] = common.compare_captures(reference, candidate)
            del candidate
        del reference
        two = torch.load(out / 'two_read/capture.pt', map_location='cpu', weights_only=True)
        both = torch.load(out / 'two_read_cache/capture.pt', map_location='cpu', weights_only=True)
        report['combined_vs_two_read_gate'] = common.compare_captures(two, both)
        del two, both
        for arm in arms:
            path = out / arm / 'capture.pt'
            result = report['accuracy'][arm]
            if digest(path) != result['worker']['accuracy']['capture_sha256']:
                raise ValueError('Original accuracy capture identity changed: ' + arm)
            result['capture_sha256'] = digest(path)
            if not result['gate']['passed']:
                raise ValueError('Original numerical gate failed: ' + arm)
        if not report['combined_vs_two_read_gate']['passed']:
            raise ValueError('Combined versus two-read numerical gate failed')
        report['expert_counter_deltas'] = accuracy_counter_controls(report['accuracy'])
        native.verify_spec(spec, content=True)
        report['status'] = 'accuracy_passed'
        report['accuracy_passed'] = True
    except BaseException as exc:
        report.update(status='failed', error=f'{type(exc).__name__}: {exc}')
        raise
    finally:
        save(out / 'run.json', report)
    return report


def validate_full_capture(capture, spec):
    """Require all real adapters to train, not merely equal empty/zero trajectories."""
    import torch

    if (len(capture['updates']) != spec['accuracy_updates'] or
            len(capture['microbatches']) != spec['accuracy_updates'] * spec['accumulation'] or
            len(capture['initial_adapters']) != 288):
        raise ValueError('Capture omits all 288 adapters or complete optimizer/microbatch updates')
    initial, final = capture['initial_adapters'], capture['updates'][-1]['adapters']
    if not all('lora_' in name and value.dtype == torch.float32 and final[name].dtype == torch.float32
               and torch.count_nonzero(value).item() > 0 and torch.count_nonzero(final[name]).item() > 0
               and not torch.equal(value, final[name]) for name, value in initial.items()):
        raise ValueError('Every adapter must be nonzero and actually change')
    if not all(any(torch.count_nonzero(batch['gradients'][name]).item() > 0
                   for batch in capture['microbatches']) for name in initial):
        raise ValueError('Every adapter must receive a nonzero gradient')
    inputs = torch.load(spec['training_data_path'], map_location='cpu', weights_only=True)
    if not all(torch.equal(batch['input_ids'], inputs[index])
               for index, batch in enumerate(capture['microbatches'])):
        raise ValueError('Capture inputs differ from the frozen training input')
    return {'adapters_nonzero_changed_and_nonzero_gradients': 288,
            'optimizer_updates': spec['accuracy_updates'],
            'microbatches': spec['accuracy_updates'] * spec['accumulation'],
            'inputs_exact': True}


def accuracy_counter_controls(accuracy):
    """Retain evidence of the two-read schedule and both admitted full cache tiers."""
    deltas = {}
    for arm in ('ordinary', 'two_read', 'two_read_cache'):
        stage = accuracy[arm]['worker']['accuracy']
        before, after = stage['runtime_before']['expert_cache'], stage['runtime_after']['expert_cache']
        row = {key: after[key] - before[key] for key in (
            'logical_fetches', 'storage_reads', 'storage_bytes_read', 'materializations')}
        for tier in ('host', 'device'):
            row[tier + '_hits'] = after[tier]['hits'] - before[tier]['hits']
            expected = (8 * 2**30 if tier == 'host' else 2 * 2**30) if arm == 'two_read_cache' else 0
            if before[tier]['budget_bytes'] != expected or after[tier]['budget_bytes'] != expected:
                raise ValueError('Full cache ceiling changed during accuracy')
        if not 0 < row['storage_reads'] <= row['logical_fetches']:
            raise ValueError('Invalid expert read evidence')
        if arm != 'two_read_cache':
            if row['storage_reads'] != row['logical_fetches'] or row['host_hits'] or row['device_hits']:
                raise ValueError('Uncached accuracy arm unexpectedly used caches')
        elif min(row['host_hits'], row['device_hits']) <= 0:
            raise ValueError('Both admitted cache tiers must actually be exercised')
        deltas[arm] = row
    if (deltas['ordinary']['logical_fetches'] * 2 != deltas['two_read']['logical_fetches'] * 3 or
            deltas['two_read']['logical_fetches'] != deltas['two_read_cache']['logical_fetches']):
        raise ValueError('Native three/two-read visit invariant changed')
    return deltas


def validate_profile_outputs(directory, arm, spec_path, maximum_trace_bytes):
    """Validate complete actual CUDA diagnostic proof and lossless trace bytes."""
    directory = Path(directory)
    report = json.loads((directory / 'profile-result.json').read_text())
    if (report.get('status') != 'passed' or report.get('phase') != 'diagnostic_profile'
            or report.get('arm') != arm or report.get('spec_sha256') != digest(spec_path)
            or report.get('unprofiled_speed_verdict') != 'NO VERDICT'):
        raise ValueError('Diagnostic result identity/status/scope differs from frozen request')
    counts = report.get('profile_event_counts', {})
    for key in ('event_count', 'cuda_event_count', 'cuda_kernel_event_count',
                'cuda_copy_event_count', 'cuda_h2d_event_count'):
        if type(counts.get(key)) is not int or counts[key] <= 0:
            raise ValueError('Actual CUDA/CPU/H2D profile evidence is missing: ' + key)
    if counts['event_count'] <= counts['cuda_event_count']:
        raise ValueError('Actual CPU profile events are missing')
    trace = report.get('trace', {})
    if (trace.get('path') != 'trace.json.gz' or trace.get('decoded_verified') is not True
            or trace.get('within_bound') is not True
            or trace.get('maximum_encoded_bytes') != maximum_trace_bytes):
        raise ValueError('Lossless bounded trace proof is missing or changed')
    path = directory / 'trace.json.gz'
    if (path.stat().st_size != trace.get('bytes') or not 0 < path.stat().st_size <= maximum_trace_bytes
            or digest(path) != trace.get('sha256')):
        raise ValueError('Complete encoded trace size/SHA differs from its proof')
    decoded, size = hashlib.sha256(), 0
    with gzip.open(path, 'rb') as handle:
        for chunk in iter(lambda: handle.read(8 * 2**20), b''):
            size += len(chunk)
            decoded.update(chunk)
    if size != trace.get('decoded_bytes') or decoded.hexdigest() != trace.get('decoded_sha256'):
        raise ValueError('Complete decoded trace differs from its original bytes')
    averages = json.loads((directory / 'key-averages.json').read_text())
    if (not isinstance(averages, dict) or not isinstance(averages.get('key_averages'), list)
            or not averages['key_averages']
            or any(not isinstance(row.get('name'), str) or not row['name']
                   for row in averages['key_averages'])
            or any(averages.get(key) != value for key, value in counts.items())):
        raise ValueError('Unfiltered key-average events/counters are missing or differ')
    if json.loads((directory / 'trace-retention.json').read_text()) != trace:
        raise ValueError('Trace retention receipts disagree')
    return report


def compare_profiles(reference, candidate):
    """Same fixed inputs/adapters and original scalar loss gates, no speed verdict."""
    from benchmarks.harness.two_read_cache_common import ATOL, RTOL

    checks = []
    def check(value, label):
        checks.append({'check': label, 'passed': bool(value)})
    for key in ('spec_sha256', 'inputs', 'initial_adapters', 'scope'):
        check(reference.get(key) is not None and reference.get(key) == candidate.get(key),
              'exact cross-profile ' + key)
    for name, row in (('two_read', reference), ('two_read_cache', candidate)):
        stage = row.get('profile_update', {})
        check(row.get('warmup', {}).get('updates_complete') == 2 and
              row.get('unprofiled_context', {}).get('updates_complete') == 1 and
              stage.get('optimizer_updates') == 1 and stage.get('accumulation') == 2 and
              stage.get('profiled_microbatches') == [0] and
              stage.get('unprofiled_microbatches') == [1] and
              stage.get('finite_training_state') is True,
              name + ': two warmup + context + one complete accumulated profile update')
        check(len(row.get('initial_adapters', {}).get('tensors', {})) == 288,
              name + ': all 288 initial adapters are hash-indexed')
    expected = reference.get('profile_update', {}).get('losses', [])
    actual = candidate.get('profile_update', {}).get('losses', [])
    losses = []
    valid = isinstance(expected, list) and isinstance(actual, list) and len(expected) == len(actual) == 2
    check(valid, 'both accumulated microbatch losses persisted')
    if valid:
        for index, (left, right) in enumerate(zip(expected, actual)):
            finite = (type(left) in (int, float) and type(right) in (int, float) and
                      math.isfinite(left) and math.isfinite(right))
            passed = finite and abs(right - left) <= ATOL + RTOL * abs(left) and f'{right:.3f}' == f'{left:.3f}'
            check(passed, 'original reference-relative / three-decimal loss gate micro ' + str(index))
            losses.append({'microbatch': index, 'reference': left, 'candidate': right, 'passed': passed})
    state = {}
    for key in ('state_before_profile', 'state_after_profile'):
        left, right = reference.get(key, {}), candidate.get(key, {})
        valid_hashes = all(isinstance(row.get('canonical_index_sha256'), str) and
                          re.fullmatch('[0-9a-f]{64}', row['canonical_index_sha256'])
                          for row in (left, right))
        check(valid_hashes, 'complete canonical training-state hash exists: ' + key)
        equal = valid_hashes and left == right
        state[key] = {'reference': left.get('canonical_index_sha256'),
                      'candidate': right.get('canonical_index_sha256'),
                      'bitwise_hashes_equal': bool(equal),
                      'verdict': 'canonical tensor hashes equal' if equal else 'NO VERDICT: hashes alone cannot test numerical tolerance'}
    return {'passed': all(row['passed'] for row in checks), 'checks': checks,
            'loss_gates': losses, 'reference_relative_rtol': RTOL, 'atol': ATOL,
            'training_state_hash_comparison': state, 'speed_verdict': 'NO VERDICT',
            'profiler_timing_scope': 'inclusive/nested and concurrent row totals are not additive',
            'scope': 'full numerical captures passed separately before profiling; only canonical hashes retained for profiled training state'}


def accuracy_then_profiles(spec_path, protocol):
    """A failed or incomplete numerical phase cannot start the diagnostic profiler."""
    phase_receipt('native_accuracy', 'started', spec_path)
    gate = qualify_accuracy(spec_path, OUT / 'accuracy', protocol)
    if gate.get('status') != 'accuracy_passed' or gate.get('accuracy_passed') is not True:
        raise ValueError('Complete unchanged numerical gates must pass before profiling')
    phase_receipt('native_accuracy', 'completed', spec_path)
    reports = {}
    for arm in protocol['performance']['profile_arms']:
        directory = OUT / 'profiles' / arm
        arguments = [sys.executable, protocol['performance']['profile_runner'],
                '--spec', str(spec_path), '--arm', arm, '--out', str(directory),
                '--warmup-updates', '2',
                '--max-trace-bytes', str(protocol['performance']['max_trace_bytes'])]
        phase_receipt('baseline_profile_' + arm, 'started', spec_path, arguments)
        command('profile-' + arm, arguments, timeout=900)
        reports[arm] = validate_profile_outputs(directory, arm, spec_path,
                                                protocol['performance']['max_trace_bytes'])
        phase_receipt('baseline_profile_' + arm, 'completed', spec_path)
    phase_receipt('cross_profile_comparison', 'started', spec_path)
    comparison = compare_profiles(reports['two_read'], reports['two_read_cache'])
    save(OUT / 'profiles/comparison.json', comparison)
    if not comparison['passed']:
        raise ValueError('Cross-profile input/adapter/loss controls failed')
    phase_receipt('cross_profile_comparison', 'completed', spec_path)
    # This receipt covers only the completed baseline diagnostics. The later
    # qualification keeps its unprofiled timing verdict in a separate run.json.
    save(OUT / 'diagnostic-only.json', {
        'purpose': 'native accuracy and baseline diagnostic profiles only',
        'scope': 'native_accuracy_and_baseline_profiles_only',
        'accuracy_arms': protocol['performance']['accuracy_arms'],
        'profile_arms': protocol['performance']['profile_arms'],
        'profiled_times_are_diagnostic_only': True,
        'no_unprofiled_performance_verdict': True,
        'source_commit': json.loads((ROOT / 'source-manifest.json').read_text())['source_commit'],
        'spec_sha256': digest(spec_path),
        'separate_unprofiled_qualification': 'results/dispatch-qualification/run.json',
    })
    return reports


def validate_dispatch_outputs(directory, spec_path):
    sys.path.insert(0, str(ROOT))
    import final_comparison as grouped
    grouped.configure(REPO)
    from benchmarks.harness import two_read_cache_common as common

    row = json.loads((Path(directory) / 'run.json').read_text())
    source = json.loads((ROOT / 'source-manifest.json').read_text())['source_commit']
    if (row.get('status') != 'completed' or row.get('accuracy_passed') is not True
            or row.get('source_commit') != source or row.get('spec_sha256') != digest(spec_path)
            or set(row.get('accuracy', {})) != {'ordinary_legacy', 'legacy', 'grouped'}):
        raise ValueError('Dispatch qualification identity/complete accuracy differs')
    for variant in ('ordinary_legacy', 'legacy', 'grouped'):
        control = row['accuracy'][variant].get('capture_controls', {})
        if (control.get('passed') is not True or control.get('adapters_nonzero_changed_and_nonzero_gradients') != 288
                or control.get('updates') != 2 or control.get('microbatches') != 4):
            raise ValueError('Dispatch full accuracy control is incomplete: ' + variant)
    for variant, reference in (('legacy', 'ordinary_legacy'), ('grouped', 'ordinary_legacy'), ('grouped', 'legacy')):
        if row['accuracy'][variant].get('versus_' + reference, {}).get('passed') is not True:
            raise ValueError('Original dispatch numerical gate failed')
    if len(row.get('timing_blocks', [])) != 8:
        raise ValueError('Eight complete balanced fresh timing workers are required')
    recalculated = grouped.timing_summary(row['timing_blocks'], common)
    if recalculated != row.get('timing_summary'):
        raise ValueError('Dispatch raw timing summary does not recompute')
    # A negative speed result is valid evidence and is never silently discarded.
    proof = {'status': 'verified', 'source_commit': source, 'spec_sha256': digest(spec_path),
             'accuracy_passed': True, 'timing_workers': 8, 'recomputed_timing_summary': recalculated}
    save(OUT / 'dispatch-validation.json', proof)
    return proof


def main():
    OUT.mkdir(exist_ok=True)
    final = {'status': 'failed', 'phase': 'initializing', 'unix': time.time()}
    try:
        protocol = json.loads((ROOT / 'protocol.json').read_text())
        manifest = json.loads((ROOT / 'source-manifest.json').read_text())
        if digest(ROOT / 'source.tar.gz') != manifest['archive_sha256']:
            raise RuntimeError('Deployed source archive changed')
        for name, row in manifest['files'].items():
            if digest(REPO / name) != row['sha256']:
                raise RuntimeError('Deployed source bytes differ: ' + name)
        if subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() != (
            manifest['source_commit']
        ):
            raise RuntimeError('Deployed Git HEAD differs from frozen source')
        if subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'],
                                   cwd=REPO, text=True).strip():
            raise RuntimeError('Deployed tracked Git source is dirty before CUDA or model download')
        with (OUT / 'pip-freeze.txt').open('wb') as handle:
            subprocess.run([sys.executable, '-m', 'pip', 'freeze'], stdout=handle, check=True)
        # Run actual CUDA kernels and the real full-query BF16 graph before the 61.34 GB checkpoint download.
        gpu_tests = protocol['cuda_test_selectors']
        command('gpu-preflight', [sys.executable, '-m', 'pytest', *gpu_tests,
                                  '-q', '-o', 'addopts=', '--tb=short',
                                  '--basetemp=' + str(OUT / 'pytest-tmp'),
                                  '--junitxml=' + str(OUT / 'gpu-preflight.xml')], timeout=900)
        validate_cuda_xml(OUT / 'gpu-preflight.xml', protocol['cuda_expected_case_names'])
        save(OUT / 'stage-status.json', {'status': 'running', 'phase': 'download', 'unix': time.time()})
        from huggingface_hub import HfApi, snapshot_download

        info = HfApi().model_info(MODEL, revision=REVISION, files_metadata=True)
        model_files = [item for item in info.siblings if item.rfilename.endswith('.safetensors')]
        if (info.sha != REVISION or len(model_files) != protocol['model']['weight_shards']
                or sum(item.size for item in model_files) != SOURCE_BYTES):
            raise RuntimeError('Public pinned checkpoint identity or size changed')
        for item in model_files:
            sha = item.lfs.get('sha256') if isinstance(item.lfs, dict) else getattr(item.lfs, 'sha256', None)
            if not isinstance(sha, str) or re.fullmatch('[0-9a-f]{64}', sha) is None:
                raise RuntimeError('Pinned checkpoint shard is missing its public LFS SHA256')
        pinned = {
            'repo_id': MODEL, 'revision': info.sha, 'weights_bytes': SOURCE_BYTES,
            'files': {item.rfilename: {'bytes': item.size, 'lfs': item.lfs}
                      for item in model_files},
        }
        # LFS metadata objects are dataclasses in some Hub releases.
        save(OUT / 'model-pinned.json', json.loads(json.dumps(pinned, default=lambda obj: vars(obj))))
        pre_download_disk_gate()
        download_started = time.perf_counter()
        weights = snapshot_download(MODEL, revision=REVISION, local_dir='/data/kanana30b',
                                    allow_patterns=['*.json', '*.safetensors'], max_workers=4)
        for item in model_files:
            path = Path(weights) / item.rfilename
            if path.stat().st_size != item.size:
                raise RuntimeError('Incomplete checkpoint file: ' + item.rfilename)
            sha = item.lfs.get('sha256') if isinstance(item.lfs, dict) else getattr(item.lfs, 'sha256', None)
            if digest(path) != sha:
                raise RuntimeError('Checkpoint LFS SHA mismatch: ' + item.rfilename)
        save(OUT / 'model-download.json', {'seconds': time.perf_counter() - download_started,
                                           'source_bytes': SOURCE_BYTES, 'revision': REVISION})
        command('prepare', [sys.executable, 'benchmarks/harness/two_read_cache.py', 'prepare',
                           '--weights', weights, '--shards', '/data/kanana30b-nf4-experts',
                           '--out', str(OUT / 'prepared'), '--host-cache-gib', '8',
                           '--device-cache-gib', '2', '--max-host-gib', '32',
                           '--seq-len', '512', '--batch-size', '1', '--accumulation', '2',
                           '--accuracy-updates', '2', '--warmup-updates', '2',
                           '--timed-updates', '6', '--rounds', '4',
                           '--host-cache-policy', 'static'], timeout=1200)
        prepared = json.loads((OUT / 'prepared/spec.json').read_text())
        retain_exact_metadata(Path(weights) / 'config.json', OUT / 'model-config.json',
                              prepared['model_fingerprint']['config.json'])
        retain_exact_metadata(Path('/data/kanana30b-nf4-experts/index.json'), OUT / 'cache-index.json',
                              prepared['store_fingerprint']['index.json'])
        spec_path = OUT / 'prepared/spec.json'
        # This lease runs the public qualifier's three full accuracy captures
        # before all eight timing workers; F7 diagnostics stay separate.
        arguments = [sys.executable, protocol['performance']['dispatch_qualification']['runner'],
                     'run', '--spec', str(spec_path), '--out', str(OUT / 'dispatch-qualification'),
                     '--source-root', str(REPO), '--source-commit', manifest['source_commit']]
        phase_receipt('dispatch_qualification', 'started', spec_path, arguments)
        command('dispatch-qualification', arguments, timeout=9000)
        validate_dispatch_outputs(OUT / 'dispatch-qualification', spec_path)
        phase_receipt('dispatch_qualification', 'completed', spec_path)
        final = {'status': 'completed', 'phase': 'complete', 'unix': time.time(),
                 'purpose': 'standalone_accuracy_first_dispatch_qualification'}
    except BaseException as exc:
        final = {'status': 'failed', 'phase': 'failed', 'error': f'{type(exc).__name__}: {exc}',
                 'traceback': traceback.format_exc(), 'unix': time.time()}
        save(OUT / 'failure.json', final)
    finally:
        save(OUT / 'stage-status.json', {**final, 'archive_ready': False})
        export(final)
        save(OUT / 'stage-status.json', {**final, 'archive_ready': True})
    return 0 if final['status'] == 'completed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
