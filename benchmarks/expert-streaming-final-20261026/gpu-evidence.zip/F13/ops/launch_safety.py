"""Pure local checks for the immutable combined Kanana F13 lease."""

from __future__ import annotations

import re

PURPOSE = 'ordinary streaming versus full two-read caches grouped routing, accuracy first'
PLAN = {'native_accuracy_phase_in_this_lease': False, 'large_profiles_in_this_lease': False, 'dispatch_qualification': True, 'timing_reference': 'ordinary_legacy', 'timing_candidate': 'grouped'}

MODEL = "kakaocorp/kanana-2-30b-a3b-base-2601"
REVISION = "0d31365acf656e5f9a593cacc4913e9c0d36cb1c"
KANANA_TEST = "tests/test_two_read_cache_kanana.py::test_real_cuda_nf4_bf16_kanana_worker_trajectories"
NF4_TEST = "tests/test_stream_expert_cache_nf4.py::test_real_cuda_nf4_expert_cache_preserves_complete_optimizer_trajectories"
GROUPED_TEST = "tests/test_expert_grouped_routes.py::test_real_cuda_nf4_bf16_grouped_route_worker_trajectories"
PROFILER_TEST = "tests/test_expert_cache_profile.py::test_real_cuda_profiler_collects_kernel_and_h2d_events"


def validate_protocol(protocol, *, source_commit, stage_id):
    if (not re.fullmatch("[0-9a-f]{40}", source_commit)
            or protocol.get("source_commit") != source_commit
            or protocol.get("stage_id") != stage_id
            or protocol.get("accuracy_first") is not True
            or protocol.get("purpose") != PURPOSE):
        raise ValueError("Frozen final-comparison identity differs")
    if protocol.get("execution_plan") != PLAN:
        raise ValueError("Final execution plan changed")
    model = protocol.get("model", {})
    if (model.get("repo_id") != MODEL or model.get("revision") != REVISION
            or model.get("weight_shards") != 13 or model.get("weights_bytes") != 61343935088):
        raise ValueError("Pinned public Kanana checkpoint identity changed")
    selectors = protocol.get("cuda_test_selectors")
    expected_names = {KANANA_TEST.rsplit("::", 1)[-1], NF4_TEST.rsplit("::", 1)[-1] + "[lru]",
                      NF4_TEST.rsplit("::", 1)[-1] + "[static]", GROUPED_TEST.rsplit("::", 1)[-1]}
    if (not isinstance(selectors, list) or len(selectors) != 3
            or set(selectors) != {KANANA_TEST, NF4_TEST, GROUPED_TEST}
            or set(protocol.get("cuda_expected_case_names", [])) != expected_names):
        raise ValueError("All four actual CUDA/Kanana/NF4/grouped numerical cells are required before download")
    expected_performance = {
        "accuracy_runner": "benchmarks/harness/two_read_cache_worker.py",
        "accuracy_arms": ["ordinary", "two_read", "two_read_cache"],
        "profile_runner": "benchmarks/harness/expert_cache_profile.py",
        "profile_arms": ["two_read", "two_read_cache"],
        "profile_warmup_updates": 2, "profile_optimizer_updates": 1,
        "profile_first_microbatch_only": True, "unprofiled_context_updates": 1,
        "max_trace_bytes": 134217728, "host_cache_policy": "static",
        "host_cache_bytes": 8 * 2**30, "device_cache_bytes": 2 * 2**30,
        "accuracy_updates": 2, "accumulation": 2, "sequence_length": 512, "batch_size": 1,
        "prepare_native_timing_fields": {"rounds": 4, "warmup_updates": 2, "timed_updates": 6},
        "profiled_times_are_diagnostic_only": True,
        "dispatch_qualification": {"runner": "/root/liger/final_comparison.py",
            "accuracy_variants": ["ordinary_legacy", "legacy", "grouped"],
            "timing_variants": ["ordinary_legacy", "grouped"], "rounds": 4, "warmup_updates": 2,
            "timed_updates": 6, "accuracy_updates": 2, "timing_workers": 8,
            "grouped_expert_routes_default": False, "practical_lower_bound_percent": 2.0},
    }
    if protocol.get("performance") != expected_performance:
        raise ValueError("Frozen accuracy/profile/cache-ceiling protocol changed")
    if protocol.get("admission_fallback_allowed") is not False:
        raise ValueError("Cache admission must fail closed without a smaller-budget fallback")
    expected_boundary = {"physical_gpu_gib_class": 8, "max_ram_bytes": 32 * 2**30,
                         "swap_must_be_disabled": True,
                         "minimum_data_free_bytes": 130 * 2**30,
                         "minimum_root_free_bytes": 48 * 2**30}
    if protocol.get("native_boundary") != expected_boundary:
        raise ValueError("Physical8GB/native32GiB/no-swap/disk reserve boundary changed")
    expected_financial = {"maximum_stage_usd": 3.0, "prior_usd": 0,
                          "maximum_seconds": 14400, "root_provider_gb": 64,
                          "volume_provider_gb": 150, "download_allowance_decimal_gb": 75,
                          "upload_allowance_decimal_gb": 2}
    if protocol.get("financial") != expected_financial:
        raise ValueError("Frozen 4-hour 3USD budget/disk/network boundary changed")
    expected_transport = {'implementation': 'native OpenSSH binary stdin/stdout',
                          'upload': 'atomic byte/SHA verified and fsynced before rename',
                          'probe_bytes': 262144, 'raw_python_tcp_or_sftp_allowed': False,
                          'route_selection': 'API-supplied proxy and direct only; actual owned container identity before selecting verified route; no host-key bypass'}
    if protocol.get('transport') != expected_transport:
        raise ValueError('Native verified binary transport preflight boundary changed')
    retention = protocol.get("retention", {})
    if (retention.get("format") != "soup-lossless-results-v1"
            or retention.get("encoded_estimate_bytes") != 1500000000
            or retention.get("raw_estimate_bytes") != 12 * 2**30
            or retention.get("actual_encoded_export_size_is_authoritative") is not True):
        raise ValueError("Complete result retention estimate/proof changed")
    return {"source_commit": source_commit, "model": MODEL, "revision": REVISION,
            "accuracy_arms": expected_performance["accuracy_arms"],
            "profile_arms": expected_performance["profile_arms"], "cuda_cells": 4,
            "performance_verdict": "baseline profiles diagnostic only; dispatch paired timing separate"}
