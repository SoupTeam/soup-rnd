"""Actual OS-process controls for the shared API start limiter; no network."""

import json
import os
import subprocess
import sys
import time
from pathlib import Path

STAGE = Path(__file__).parent.parent / "kanana-30b-final-gpu-20261026-f13"


def child(command, *arguments):
    options = {"stdout": subprocess.PIPE, "stderr": subprocess.PIPE, "text": True}
    if os.name == "nt":
        options["creationflags"] = subprocess.CREATE_NO_WINDOW
    return subprocess.Popen([sys.executable, "-c", command, str(STAGE), *map(str, arguments)],
                            **options)


def test_simultaneous_real_processes_have_a_shared_two_second_start_floor(tmp_path):
    command = """
import json, sys, time
from pathlib import Path
sys.path.insert(0, sys.argv[1])
from api_rate_limit import SharedAdmission
started = SharedAdmission(Path(sys.argv[2])).wait(deadline=time.monotonic()+20)
Path(sys.argv[3]).write_text(json.dumps({'started':started}))
"""
    children = [child(command, tmp_path / "gate", tmp_path / f"result-{index}.json")
                for index in range(3)]
    try:
        for process in children:
            _out, error = process.communicate(timeout=25)
            assert process.returncode == 0, error
        starts = sorted(json.loads((tmp_path / f"result-{index}.json").read_text())["started"]
                        for index in range(3))
        assert all(right - left >= 1.95 for left, right in zip(starts, starts[1:]))
    finally:
        for process in children:
            if process.poll() is None:
                process.terminate()
                process.wait(timeout=5)


def test_crashed_process_cannot_leave_a_permanent_api_mutex(tmp_path):
    command = """
import sys, time
from pathlib import Path
sys.path.insert(0, sys.argv[1])
from api_rate_limit import exclusive
with exclusive(Path(sys.argv[2]), time.monotonic()+10):
    Path(sys.argv[3]).write_text('lock acquired')
    time.sleep(30)
"""
    marker = tmp_path / "locked.txt"
    process = child(command, tmp_path / "admission.lock", marker)
    try:
        deadline = time.monotonic() + 10
        while not marker.exists() and time.monotonic() < deadline:
            time.sleep(.05)
        assert marker.exists(), "Child did not acquire its isolated test mutex"
        process.terminate()
        process.wait(timeout=5)
        command = """
import sys, time
from pathlib import Path
sys.path.insert(0, sys.argv[1])
from api_rate_limit import exclusive
with exclusive(Path(sys.argv[2]), time.monotonic()+3):
    Path(sys.argv[3]).write_text('lock recovered')
"""
        successor = child(command, tmp_path / "admission.lock", tmp_path / "recovered.txt")
        _out, error = successor.communicate(timeout=6)
        assert successor.returncode == 0, error
        assert (tmp_path / "recovered.txt").read_text() == "lock recovered"
    finally:
        if process.poll() is None:
            process.terminate()
            process.wait(timeout=5)
