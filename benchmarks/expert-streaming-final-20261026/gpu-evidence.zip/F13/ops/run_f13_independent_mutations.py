"""Kill isolated operator mutants without changing any stage input or network state."""

import hashlib
import importlib.util
import json
import tempfile
from pathlib import Path

from rich.console import Console

ROOT = Path(__file__).parent
SOURCE = Path(r"C:\Users\esenb\Documents\SoupResearch\kanana-30b-final-gpu-20261026-f13")


def main():
    spec = importlib.util.spec_from_file_location(
        "independent_f13_controls", ROOT / "test_f13_independent_transport_review.py")
    controls = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(controls)
    cases = [
        ("create_wrongly_retryable", "cloud.py", 'readonly = method == "GET" or',
         'readonly = True or method == "GET" or',
         lambda tmp: controls.test_live_cloud_create_never_uses_readonly_retry_classifier(tmp)),
        ("nontransient_boot_error_softened", "controller.py", "except ReadOnlyTransientError as error:",
         "except Exception as error:",
         lambda _tmp: controls.test_nontransient_identity_or_numerical_errors_are_not_softened()),
        ("unfrozen_public_key_accepted", "controller.py",
         'if expected != {"bytes": len(public), "sha256": public_sha}:', "if False:",
         lambda tmp: controls.test_attachment_refuses_unfrozen_public_key_before_any_mutation(tmp)),
        ("ssh_retries_non_429_error", "controller.py",
         "except MutationRateLimitRefusalError as error:", "except Exception as error:",
         lambda tmp: controls.test_attachment_never_retries_ambiguous_or_non_429_errors(
             tmp, RuntimeError("HTTP500"))),
        ("ssh_wrong_resource_retry", "controller.py",
         '"instance_id", "label", "stage_id", "maximum_usd", "source_sha256")):',
         '"label", "stage_id", "maximum_usd", "source_sha256")):',
         lambda tmp: controls.test_attachment_refuses_any_replacement_key_or_lease_after_429(
             tmp, "receipt")),
        ("cached_identity_route_disabled", "controller.py",
         'if probe_ssh_routes(policy):\n                return True\n            if _remaining',
         'if False:\n                return True\n            if _remaining',
         lambda _tmp: controls.test_cached_exact_identity_route_can_recover_while_api_status_is_throttled()),
    ]
    report = {"schema_version": 1, "no_network_or_provider_calls": True,
              "stage_inputs_not_modified": True, "mutations": []}
    for name, filename, before, after, test in cases:
        sandbox = Path(tempfile.mkdtemp(prefix=name + "-", dir=ROOT))
        for base in ("controller.py", "cloud.py"):
            (sandbox / base).write_bytes((SOURCE / base).read_bytes())
        controls.STAGE = sandbox
        fixture = sandbox / "fixture"
        fixture.mkdir()
        test(fixture)
        original = (sandbox / filename).read_text(encoding="utf-8")
        if original.count(before) != 1:
            raise ValueError("Mutation target is not unique: " + name)
        (sandbox / filename).write_text(original.replace(before, after), encoding="utf-8")
        fixture = sandbox / "mutant-fixture"
        fixture.mkdir()
        killed = False
        try:
            test(fixture)
        except BaseException as error:
            killed = True
            reason = type(error).__name__ + ": " + str(error)[:400]
        report["mutations"].append({"name": name, "baseline_passed": True, "killed": killed,
            "sandbox": str(sandbox), "failure": reason if killed else None,
            "original_source_sha256": hashlib.sha256((SOURCE / filename).read_bytes()).hexdigest()})
        if not killed:
            raise AssertionError("Independent controls did not kill mutation: " + name)
    report["status"] = "all_isolated_mutants_killed"
    (ROOT / "f13-independent-mutation-review.json").write_text(json.dumps(report, indent=2) + "\n")
    Console().print({"status": report["status"], "mutants": len(cases)})


if __name__ == "__main__":
    main()
