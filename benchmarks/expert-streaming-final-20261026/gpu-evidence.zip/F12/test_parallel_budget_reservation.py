"""Offline controls for the independently capped second GPU lease."""

import hashlib
import json
import math
from pathlib import Path

import cloud

ROOT = Path(__file__).parent
SIBLING = ROOT.parent / "kanana-30b-final-gpu-20261026-f11"


def test_two_hard_caps_fit_shared_remainder_without_releasing_active_sibling():
    context = json.loads((ROOT / "prior-budget-context.json").read_text())
    sibling = json.loads((SIBLING / "vast-rental.json").read_text())
    assert sibling["stage_id"] == "soup-kanana-30b-final-20261026-f11"
    assert sibling["maximum_usd"] == context["reserved_active_f11_maximum_usd"] == 3.
    assert sibling["instance_id"] == context["reserved_f11_instance_id"] == 57816217
    assert sibling["volume_id"] == context["reserved_f11_volume_id"] == 57816216
    assert cloud.MAXIMUM_USD == context["new_stage_cap_usd"] == 2.8
    initial = context["prior_remaining_usd"] + context["new_authorized_usd"]
    remaining = initial - context["failed_f10_cost_usd"]
    assert math.isclose(remaining, context["aggregate_remaining_before_f12_usd"], abs_tol=1e-12)
    assert math.isclose(remaining - sibling["maximum_usd"],
                        context["available_for_f12_admission_usd"], abs_tol=1e-12)
    assert cloud.MAXIMUM_USD + sibling["maximum_usd"] <= remaining
    assert cloud.MAXIMUM_USD <= context["available_for_f12_admission_usd"]


def test_both_leases_keep_identical_production_wrapper_and_numerical_protocol():
    for name in ("source.tar.gz", "source-manifest.json", "final_comparison.py", "constraints.txt"):
        assert hashlib.sha256((ROOT / name).read_bytes()).digest() == hashlib.sha256(
            (SIBLING / name).read_bytes()).digest()
    own = json.loads((ROOT / "protocol.json").read_text())
    sibling = json.loads((SIBLING / "protocol.json").read_text())
    for key in ("source_commit", "model", "cuda_test_selectors", "cuda_expected_case_names",
                "performance", "admission_fallback_allowed", "native_boundary", "retention",
                "transport", "execution_plan"):
        assert own[key] == sibling[key]
    assert own["financial"]["maximum_stage_usd"] == 2.8
    assert sibling["financial"]["maximum_stage_usd"] == 3.
    assert own["financial"]["maximum_seconds"] == sibling["financial"]["maximum_seconds"] == 7200
