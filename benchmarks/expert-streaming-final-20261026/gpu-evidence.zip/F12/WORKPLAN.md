# Independent Minnesota RTX5060 final comparison

User authorized two simultaneous leases. Active F11 cap USD3 fully reserved; F12 hard cap USD2.8, two hours, cleanup+unknown reserves unchanged. Physical8GB/nativeRAM<=32GiB/noSwap gates mandatory, no emulated VRAM. Same production43cf/privatewrapper/inputs/pins/four actual numericalCUDA/three complete accuracy trajectories/eight fresh ABBA timing processes. No numerical/performance tolerance changes. Preserve all raw originals, then delete exact owned instance+volume. Never touch F11 or colleagues.
