"""Read-only Vast inventory and matched-volume quotes; no lease can be created here."""

from __future__ import annotations

import math
import shutil
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from rich.console import Console

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT / ".deps"))

import cloud  # noqa: E402

OFFER_FIELDS = (
    "id", "machine_id", "gpu_name", "gpu_ram", "cpu_ram", "disk_name", "disk_bw",
    "disk_space", "dph_base", "dph_total", "storage_cost", "inet_down_cost", "inet_up_cost",
    "reliability", "verification", "cuda_max_good", "compute_cap", "gpu_display_active",
)
VOLUME_FIELDS = ("id", "machine_id", "disk_space", "storage_cost", "disk_name", "disk_bw")


def readonly_api(path, method="GET", payload=None):
    allowed = (
        method == "GET" and (
            path == "/api/v0/users/current/" or path.startswith("/api/v1/instances/?")
            or path.startswith("/api/v0/volumes?")
        )
    ) or (method == "POST" and path in ("/api/v0/bundles/", "/api/v0/volumes/search/"))
    if not allowed:
        raise RuntimeError("Read-only preflight refused a non-inventory API operation")
    return _original_api(path, method, payload)


_original_api = cloud.api
cloud.api = readonly_api


def main():
    started = time.time()
    credit = float(cloud.api("/api/v0/users/current/")["credit"])
    if not math.isfinite(credit) or credit < 0:
        raise ValueError("Provider returned invalid numeric credit")
    instances = [{key: row.get(key) for key in ("id", "label")}
                 for row in cloud.rows()]
    volumes = [{key: row.get(key) for key in ("id", "machine_id", "name", "label")}
               for row in cloud.volume_rows()]
    offers = cloud.offers()
    machines = list(dict.fromkeys(offer["machine_id"] for offer in offers))
    machine_volumes = {}
    failures = []
    # Independent inventory calls only. Limit concurrency to avoid provider throttling.
    with ThreadPoolExecutor(max_workers=4) as pool:
        pending = {pool.submit(cloud.volume_offers, machine): machine for machine in machines}
        for future in as_completed(pending):
            machine = pending[future]
            try:
                machine_volumes[machine] = future.result()
            except Exception as exc:
                # Never retain raw authenticated responses or request objects.
                failures.append({"machine_id": machine, "error_type": type(exc).__name__})
    candidates = []
    for offer in offers:
        for volume in machine_volumes.get(offer["machine_id"], []):
            try:
                quote = cloud.quote(offer, volume_offer=volume)
            except (ValueError, KeyError, TypeError) as exc:
                failures.append({"offer_id": offer["id"], "volume_ask_id": volume.get("id"),
                                 "error_type": type(exc).__name__})
                continue
            candidates.append({
                "offer": {key: offer.get(key) for key in OFFER_FIELDS},
                "volume": {key: volume.get(key) for key in VOLUME_FIELDS},
                "quote": quote,
                "within_stage_and_current_credit": (
                    quote["total_stage_admission_usd"] <= min(cloud.MAXIMUM_USD, credit)
                ),
            })
    candidates.sort(key=lambda row: (
        not row["within_stage_and_current_credit"],
        row["quote"]["total_stage_admission_usd"], row["offer"]["id"], row["volume"]["id"],
    ))
    # Keep at most one best local-volume pairing per GPU offer, then five GPU offers.
    selected = []
    selected_ids = set()
    for candidate in candidates:
        identity = candidate["offer"]["id"]
        if identity in selected_ids:
            continue
        selected.append(candidate)
        selected_ids.add(identity)
        if len(selected) == 5:
            break
    result = {
        "stage_id": cloud.STAGE, "label": cloud.LABEL, "unix": time.time(),
        "maximum_stage_usd": cloud.MAXIMUM_USD, "credit_usd": credit,
        "quote_seconds": 7200, "prospective_download_decimal_gb": 75,
        "prospective_upload_decimal_gb": 2, "prior_stage_usd": 0,
        "allocated_root_disk_gb": cloud.DISK_GB, "separate_volume_gb": cloud.VOLUME_GB,
        "account_instances": instances, "account_volumes": volumes,
        "offers_returned": len(offers), "machines_scanned": len(machines),
        "matched_pairs_quoted": len(candidates), "best_five_distinct_offers": selected,
        "inventory_failures": failures, "read_only": True, "rental_started": False,
        "local_free_bytes": shutil.disk_usage(ROOT).free,
        "ssh_private_key_present": cloud.SSH_KEY.is_file(),
        "transport": "native OpenSSH; paramiko is neither imported nor required",
        "wall_seconds": time.time() - started,
    }
    cloud.save("read-only-preflight.json", result)
    Console().print(result)


if __name__ == "__main__":
    main()
