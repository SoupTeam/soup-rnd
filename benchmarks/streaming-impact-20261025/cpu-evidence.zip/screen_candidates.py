"""CPU-only opportunity screening using frozen real headers and pinned upstream source."""

import ast
import hashlib
import io
import json
import sys
import types
from collections.abc import Sequence
from dataclasses import dataclass
from itertools import pairwise
from pathlib import Path

from rich.console import Console

ROOT = Path(__file__).parent
OLD = ROOT / "inputs"
REF = "51777d12077df022db8ee8a57cf46ed2f76909ef"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate_plan(plan, sizes, align=256):
    assert len(plan.placements) == len(sizes)
    regions = {}
    for size, (arena, start) in zip(sizes, plan.placements):
        assert start % align == 0 and start + size <= plan.arena_sizes[arena]
        if size:
            regions.setdefault(arena, []).append((start, start + size))
    for intervals in regions.values():
        intervals.sort()
        assert all(left[1] <= right[0] for left, right in pairwise(intervals))


def planner_from_snapshot(path=None):
    path = path or ROOT / "upstream_layer_stream_runtime.py"
    wanted = {"ArenaPlan", "_next_power_of_two", "plan_pinned_arenas",
              "_plan_in_order", "_plan_largest_first"}
    constants = {"PINNED_ARENA_BYTES", "PINNED_ARENA_MAX_BYTES", "PINNED_ARENA_ALIGN"}
    nodes = []
    for node in ast.parse(path.read_text(encoding="utf-8")).body:
        if isinstance(node, (ast.FunctionDef, ast.ClassDef)) and node.name in wanted or isinstance(node, ast.Assign) and any(
            isinstance(target, ast.Name) and target.id in constants for target in node.targets
        ):
            nodes.append(node)
    required = {"ArenaPlan", "_next_power_of_two", "plan_pinned_arenas"}
    assert required <= {node.name for node in nodes if hasattr(node, "name")}
    assert len([node for node in nodes if isinstance(node, ast.Assign)]) == len(constants)
    # Only the inspected pure planner definitions/constants, never upstream imports/setup.
    namespace = {"__name__": __name__, "dataclass": dataclass,
                 "List": list, "Sequence": Sequence, "Tuple": tuple}
    compiled = compile(ast.Module(body=nodes, type_ignores=[]), str(path), "exec")
    exec(compiled, namespace)  # noqa: S102 - inspected pure definitions from pinned source
    return namespace["plan_pinned_arenas"]


def memory_arithmetic():
    old_plan = planner_from_snapshot(OLD / "old_layer_stream_runtime.py")
    observed = OLD / "cache-header-observation.json"
    headers = json.loads(observed.read_bytes())["shard_headers"]
    upstream = planner_from_snapshot()
    physical = json.loads((OLD / "capacity-preflight.json").read_bytes())["ram_scope"][
        "host_mem_total_bytes"]
    cases = []
    for count in range(13):
        start = (64 - count) // 2
        excluded = set(range(start, start + count))
        names = [f"layer_{idx:03}.safetensors" for idx in range(64) if idx not in excluded]
        names += ["large_embed_tokens.safetensors", "large_lm_head.safetensors"]
        sizes = []
        for name in names:
            header = headers[name]["header"]
            sizes.extend(header[key]["data_offsets"][1] - header[key]["data_offsets"][0]
                         for key in sorted(header) if key != "__metadata__")
        before, after = old_plan(sizes), upstream(sizes)
        validate_plan(before, sizes)
        validate_plan(after, sizes)
        assert after.pinned_bytes <= before.pinned_bytes
        cases.append({"hypothetical_gpu_exclusions": sorted(excluded),
                      "cpu_payload_bytes": sum(sizes),
                      "old_arena_bytes": before.pinned_bytes,
                      "current_upstream_arena_bytes": after.pinned_bytes,
                      "saved_allocation_bytes": before.pinned_bytes - after.pinned_bytes,
                      "payload_under_55_percent_physical": sum(sizes) < .55 * physical,
                      "arena_under_55_percent_physical": after.pinned_bytes < .55 * physical})
    return {"header_observation_sha256": digest(observed), "cases": cases,
            "allocation_bounds_and_nonoverlap_checked": True,
            "scope": "Planner arithmetic only; GPU-excluded full RAM source does not exist yet. "
                     "Excludes extras, transient copies and runtime; available/cgroup admission "
                     "and real training still required."}


def disk_auto_branch():
    path = ROOT / "upstream_stream_setup.py"
    nodes = [node for node in ast.walk(ast.parse(path.read_text(encoding="utf-8")))
             if isinstance(node, ast.FunctionDef) and node.name == "_configure_stream_recompute"]
    assert len(nodes) == 1
    calls = []
    policy = types.ModuleType("soup_cli.utils.layer_stream")
    policy.STREAM_RECOMPUTE_HEADROOM = .85
    policy.TIER_DISK = "disk"
    runtime = types.ModuleType("soup_cli.utils.layer_stream_runtime")
    runtime.plan_stream_recompute_auto = lambda *a, **kw: calls.append(kw)
    saved = {name: sys.modules.get(name) for name in (policy.__name__, runtime.__name__)}
    for name in ("soup_cli", "soup_cli.utils"):
        saved[name] = sys.modules.get(name)
        if name not in sys.modules:
            parent = types.ModuleType(name)
            parent.__path__ = []
            sys.modules[name] = parent
    sys.modules[policy.__name__] = policy
    sys.modules[runtime.__name__] = runtime
    try:
        sink = io.StringIO()
        namespace = {"console": Console(file=sink, force_terminal=False)}
        compiled = compile(ast.Module(body=nodes, type_ignores=[]), str(path), "exec")
        exec(compiled, namespace)  # noqa: S102 - inspected setup method from pinned source
        configure = namespace["_configure_stream_recompute"]
        tcfg = types.SimpleNamespace(stream_recompute="auto", stream_vram_override=None)
        model = types.SimpleNamespace(cached_decoder_layers=63, decoder_layers=64)
        configure(None, model, tcfg, tier="disk", on_cuda=True, task="sft",
                  step_shape=(1, 512, 151936))
        disk_calls = len(calls)
        assert disk_calls == 0
        configure(None, model, tcfg, tier="ram", on_cuda=True, task="sft",
                  step_shape=(1, 512, 151936))
        ram_calls = len(calls)
        assert ram_calls == 1
        return {"disk_auto_reaches_measurement": False, "ram_positive_control_reaches_it": True,
                "native_messages": sink.getvalue(), "scope": "Real extracted setup method, "
                "stubbed imports/planner; branch behavior only, no GPU/performance claim."}
    finally:
        for name, module in saved.items():
            if module is None:
                sys.modules.pop(name, None)
            else:
                sys.modules[name] = module


def embedding_arithmetic():
    config = json.loads((OLD / "model-32-pinned-config.json").read_bytes())
    vocab, hidden = config["vocab_size"], config["hidden_size"]
    full = vocab * hidden * 2
    info = json.loads((OLD / "joint-provenance.json").read_bytes())
    feature = info["cache_feature"]
    pinned_staging = feature["pinned_bytes_total"] - feature["stats_after_setup"]["allocated_bytes"]
    decoder_span = (feature["staging_payload_bytes"] - 2 * full) // 2
    tiny_staging = planner_from_snapshot()([decoder_span, decoder_span], align=4096).pinned_bytes
    return {"model": "Qwen3-32B", "frozen_bf16_matrix_bytes": full,
            "observed_large_loads_per_optimizer_update": 4,
            "full_large_weight_h2d_bytes_per_update": 4 * full,
            "two_microbatches_of_512_gathered_embedding_rows_max_bytes": 2 * 512 * hidden * 2,
            "observed_current_pinned_staging_bytes": pinned_staging,
            "hypothetical_decoder_only_staging_bytes": tiny_staging,
            "hypothetical_pinned_staging_saved_bytes": pinned_staging - tiny_staging,
            "candidate": "Gather frozen embedding rows; reuse existing large GPU slot for "
                         "an immutable output head instead of embedding/head ping-pong.",
            "scope": "Shape/traffic arithmetic, not measured savings. Untied frozen embedding/head "
                     "only. Existing prefetch hides transfers; row I/O, semantics and timing need tests."}


def embedding_cpu_control():
    import torch
    from torch.nn import functional

    generator = torch.Generator().manual_seed(792)
    cases = []
    for dtype in (torch.float32, torch.bfloat16):
        weights = torch.randn((1024, 32), generator=generator).to(dtype)
        original = weights.clone()
        ids = torch.randint(0, 1024, (2, 17), generator=generator)
        ids[:, 0] = 0
        baseline = functional.embedding(ids, weights, padding_idx=0)
        unique, inverse = torch.unique(ids, sorted=True, return_inverse=True)
        rows = weights.index_select(0, unique)
        candidate = functional.embedding(inverse.reshape_as(ids), rows)
        assert torch.equal(baseline, candidate)
        base = torch.randn((16, 32), generator=generator).to(dtype)
        initial_a = torch.randn((2, 32), generator=generator).to(dtype)
        initial_b = torch.randn((16, 2), generator=generator).to(dtype)

        def gradients(embedded, initial_a=initial_a, initial_b=initial_b, base=base):
            adapter_a = initial_a.clone().requires_grad_()
            adapter_b = initial_b.clone().requires_grad_()
            result = functional.linear(embedded, base) + .5 * functional.linear(
                functional.linear(embedded, adapter_a), adapter_b)
            result.float().square().mean().backward()
            return adapter_a.grad, adapter_b.grad

        first, second = gradients(baseline), gradients(candidate)
        assert all(torch.equal(a, b) for a, b in zip(first, second))
        bad = rows.clone()
        bad[0, 0] += 1
        wrong = functional.embedding(inverse.reshape_as(ids), bad)
        assert not torch.equal(wrong, baseline)
        assert any(not torch.equal(a, b) for a, b in zip(first, gradients(wrong)))
        assert torch.equal(weights, original)
        cases.append({"dtype": str(dtype), "embedding_and_downstream_lora_grads_bitwise": True,
                      "wrong_row_negative_control_detected": True,
                      "frozen_source_unchanged": True})
    return {"cases": cases, "scope": "Small CPU lookup/downstream-gradient controls only; "
            "not the Soup streamed runtime, no GPU, no I/O or speed qualification."}


def prequantized_source_control():
    from upstream_fp8_block import check_source_quantization

    assert check_source_quantization(None, arch="qwen3") is None
    config = {"quant_method": "bitsandbytes", "load_in_4bit": True,
              "bnb_4bit_quant_type": "nf4", "bnb_4bit_use_double_quant": True}
    try:
        check_source_quantization(config, arch="qwen3")
    except ValueError as error:
        return {"native_unquantized_positive_control": True, "prequantized_nf4_refused": True,
                "error_type": type(error).__name__, "error": str(error),
                "scope": "Current source admission only. A protective refusal is correct until "
                         "packed-source decoding is implemented; never bypass it."}
    raise AssertionError("Expected current source gate to reject prequantized NF4")


def main():
    result = {"date": "2026-10-25", "cpu_only": True, "gpu_rentals": 0,
              "upstream_ref": REF,
              "source_sha256": {name: digest(ROOT / name) for name in
                  ("upstream_layer_stream_runtime.py", "upstream_stream_setup.py",
                   "upstream_fp8_block.py")},
              "memory_planner": memory_arithmetic(), "disk_auto": disk_auto_branch(),
              "embedding_candidate": embedding_arithmetic(),
              "embedding_cpu_control": embedding_cpu_control(),
              "prequantized_source": prequantized_source_control()}
    (ROOT / "candidate-screen.json").write_text(json.dumps(result, indent=2) + "\n")
    Console().print(result)


if __name__ == "__main__":
    main()
