#!/usr/bin/env bash
set -euo pipefail
cd /workspace/d3-run-0035af1
export PYTHONPATH=src:benchmarks/harness
exec /workspace/d3-dev-venv/bin/python -u benchmarks/harness/d3_training_gate.py series --prepared /workspace/d3-olmoe-training-prep-20261022/prepared --out /workspace/d3-formal-0035af1 --library /workspace/d3-dev-venv/lib/python3.12/site-packages/nvidia/cu13/lib/libcublas.so.13
