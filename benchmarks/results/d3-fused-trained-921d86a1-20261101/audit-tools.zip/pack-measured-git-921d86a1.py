"""Export existing Git objects only; no commits or pushes are created."""
import hashlib
import json
import subprocess
import sys
import zipfile
from pathlib import Path

root = Path(r"C:\ml\soup\soup-rnd-d3")
work = Path(r"C:\ml\soup\work\d3-fused-research")
head = "921d86a19d96e62ecc12c7c6aef49074f3ebb14d"
with zipfile.ZipFile(work / "frozen-source-921d86a1.zip") as archive:
    source = json.loads(archive.read("FROZEN-D3-FUSED-SOURCE.json"))
assert source["git_head"] == head
listing = subprocess.check_output(["git", "ls-tree", "-r", "-t", "-z", head], cwd=root)
objects = {head, subprocess.check_output(["git", "rev-parse", head + "^{tree}"], cwd=root).decode().strip()}
found = set()
for item in listing.split(b"\0"):
    if not item:
        continue
    header, name = item.split(b"\t", 1)
    _, kind, oid = header.decode().split()
    name = name.decode()
    if (kind == "tree" and any(path.startswith(name + "/") for path in source["git_blob_sha256"])) or ("--trees-only" not in sys.argv and name in source["git_blob_sha256"]):
        objects.add(oid)
    if name in source["git_blob_sha256"]:
        found.add(name)
assert found == set(source["git_blob_sha256"])
output = work / ("measured-git-meta-921d86a1.pack" if "--trees-only" in sys.argv else "measured-git-921d86a1.pack")
with output.open("wb") as stream:
    subprocess.run(["git", "pack-objects", "--stdout"], input=("\n".join(sorted(objects)) + "\n").encode(), stdout=stream, cwd=root, check=True)
print(json.dumps({"existing_commit":head,"objects":len(objects),"source_blobs":len(found),"bytes":output.stat().st_size,"sha256":hashlib.sha256(output.read_bytes()).hexdigest()}))
