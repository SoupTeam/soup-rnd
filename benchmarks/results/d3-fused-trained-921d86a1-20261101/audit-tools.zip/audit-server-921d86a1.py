"""CPU-only replay using existing measured Git objects, without creating a commit."""
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

started = time.time()
root = Path("/root/d3-fused-formal-921d86a1")
pack = Path("/root/measured-git-meta-921d86a1.pack")
assert hashlib.sha256(pack.read_bytes()).hexdigest() == "b2da2df8b5280f88b07f051f2265fee48ffb5c86e08789364848147934df65ae"
database = Path("/root/d3-measured-object-audit-921d86a1.git")
if not database.exists():
    subprocess.run(["git", "init", "--bare", str(database)], check=True)
    with pack.open("rb") as stream:
        subprocess.run(["git", "--git-dir=" + str(database), "index-pack", "--stdin"], stdin=stream, check=True)
os.environ["GIT_DIR"] = str(database)
os.environ["CUDA_VISIBLE_DEVICES"] = ""
source = json.loads((root / "FROZEN-D3-FUSED-SOURCE.json").read_text())
for name, expected in source["git_blob_sha256"].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected
subprocess.run(
    ["git", "hash-object", "-w", "--no-filters", "--stdin-paths"],
    input=("\n".join(str(root / name) for name in source["git_blob_sha256"]) + "\n").encode(),
    stdout=subprocess.DEVNULL, check=True,
)
sys.path[:0] = [str(root), str(root / "src")]
os.chdir(root)
import torch
torch.set_num_threads(1)
from benchmarks.harness.d3_fused_trainer_analysis import analyze
from benchmarks.harness.d3_trainer_gate import save

result = analyze(Path("/root/d3-fused-data/inputs-01/formal-session-01"))
assert result["status"] == "qualification_complete_pending_review"
assert result["fresh_processes"] == 112 and result["complete_pretrained_series"] is True
output = Path("/root/d3-fused-analysis-921d86a1.json")
save(output, result)
receipt = {
    "kind": "CPU-only audit on source host; local full-archive verification remains separate",
    "git_head": result["source"]["git_head"],
    "status": result["status"],
    "source_blobs_verified": len(result["source"]["git_blob_sha256"]),
    "native_tensor_payloads_verified": result["native_tensor_payloads_verified"],
    "fresh_processes": result["fresh_processes"],
    "analysis_sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
    "new_gpu_execution": False,
    "new_git_commit_created": False,
    "elapsed_seconds": round(time.time() - started, 1),
}
save(Path("/root/d3-fused-analysis-921d86a1.receipt.json"), receipt)
print(json.dumps(receipt, indent=2), flush=True)
print(json.dumps(result["cohorts"], indent=2), flush=True)
