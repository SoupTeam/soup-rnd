"""Audit the complete retained ZIP and publish a small report on the source host."""
import hashlib,json,shutil,time,zipfile
from collections import Counter
from pathlib import Path

start=time.time()
base=Path('/root/d3-fused-data/inputs-01/formal-session-01')
archive=Path('/root/d3-fused-trained-921d86a1-20261101.zip')
out=Path('/root/d3-fused-report-921d86a1')
out.mkdir(exist_ok=True)
analysis_path=Path('/root/d3-fused-analysis-921d86a1.json')
analysis=json.loads(analysis_path.read_text())
assert analysis['status']=='qualification_complete_pending_review' and analysis['fresh_processes']==112
receipt=json.loads(archive.with_suffix('.receipt.json').read_text())
def digest_file(path):
 h=hashlib.sha256()
 with path.open('rb') as stream:
  while chunk:=stream.read(8*2**20):h.update(chunk)
 return h.hexdigest()
assert archive.stat().st_size==receipt['bytes'] and digest_file(archive)==receipt['sha256']
manifest=json.loads(archive.with_suffix('.manifest.json').read_text())
with zipfile.ZipFile(archive) as zipped:
 assert json.loads(zipped.read('MANIFEST.json'))==manifest
 assert set(zipped.namelist())==set(manifest['payloads'])|{'MANIFEST.json'}
 assert len(zipped.namelist())==len(manifest['payloads'])+1
 for index,(name,expected) in enumerate(manifest['payloads'].items(),1):
  h=hashlib.sha256();length=0
  with zipped.open(name) as incoming:
   while chunk:=incoming.read(8*2**20):h.update(chunk);length+=len(chunk)
  assert length==expected['bytes'] and h.hexdigest()==expected['sha256'],name
  if index%500==0:print(json.dumps({'verified_payloads':index,'total':len(manifest['payloads'])}),flush=True)
state=json.loads((base/'session.json').read_text())
ledger=[]
for row in state['cells']:
 path=base/row['name']/'result.json'
 assert digest_file(path)==row['result_sha256']
 value=json.loads(path.read_text())
 assert value['status']=='ok' and value['F1']['outcome']=='ok'
 ledger.append({**{k:row[k] for k in ('name','kind','codec','training','mode','status','returncode','result_sha256')},'pid':value['pid'],'F1':value['F1']['outcome']})
assert len(ledger)==112 and len({r['pid'] for r in ledger})==112
assert all(r=={'status':'complete','target':5} for r in state['repeat_calculations'].values())
def save(name,value):
 (out/name).write_bytes((json.dumps(value,indent=2,allow_nan=False)+'\n').encode())
shutil.copyfile(analysis_path,out/'analysis.json')
shutil.copyfile(base/'protocol.json',out/'protocol.json')
shutil.copyfile(archive.with_suffix('.manifest.json'),out/'raw-archive-manifest.json')
shutil.copyfile(Path('/root/d3-fused-analysis-921d86a1.receipt.json'),out/'cpu-replay-receipt.json')
save('cells.json',ledger)
save('raw-archive-retention.json',{'status':'verified_on_source_host_only','archive':str(archive),'archive_bytes':receipt['bytes'],'archive_sha256':receipt['sha256'],'payloads':len(manifest['payloads']),'full_local_backup_complete':False,'note':'The complete archive remains on the source instance. Local partial downloads are not a backup. Do not destroy its only complete copy.'})
verification={'kind':'complete source-host CPU/archive audit; no new CUDA measurement','git_head':analysis['source']['git_head'],'formal_cells':112,'F1_ok':112,'source_blobs_verified':len(analysis['source']['git_blob_sha256']),'native_tensor_payloads_verified':analysis['native_tensor_payloads_verified'],'archive_payloads_verified':len(manifest['payloads']),'all_archive_crcs_and_hashes_passed':True,'all_repeat_targets':state['repeat_calculations'],'analysis_sha256':digest_file(analysis_path),'full_local_backup_complete':False,'elapsed_seconds':round(time.time()-start,1)}
save('verification.json',verification)
lines=['# D3 packed fused public trainer: completed qualification','',
'Measured commit: `'+analysis['source']['git_head']+'`. One RTX 3090 24 GiB (sm_86), pinned pretrained OLMoE revision `6d84c48581ece794365f2b8e9cfb043c68ade9c5`. Frozen routed experts, q/v attention LoRA, seven synthetic 512-token rows, accumulation windows 2/2/2/1, four SGD updates; one warmup and three timed windows. Ordinary/L2L and NF4/nested NF4 are separate cohorts.','',
'All **112/112** declared processes completed: **24 correctness, 80 timing and eight CUDA profiles**, all F1 OK. All eight packed-fused resident/streamed correctness cells passed. Every repetition calculation retains five blocks: **zero additions and zero replacements**.','',
'The original CPU analyzer verifies actual measured Git source blobs, retained native tensors, A/A, effective negative/restored controls, exact gradients/updates, real adapter save/reload, same-kernel resident/streamed pairs, timing windows and actual CUDA traces. The source-host archive audit separately verifies every ZIP payload and the complete archive SHA-256. This is CPU replay of recorded evidence, not a new GPU run.','',
'| Recipe | Staged tok/s | Packed hybrid tok/s | Paired time change | Training peak allocated MiB, staged / packed |','|---|---:|---:|---:|---:|']
for key,row in analysis['cohorts'].items():
 a,b=row['grouped'],row['fused']
 lines.append(f"| {key} | {a['input_tokens_per_second']:.3f} | {b['input_tokens_per_second']:.3f} | {row['mean_paired_time_change_pct']:+.3f}% | {a['allocator_peak_bytes']['allocated']['median']/2**20:.2f} / {b['allocator_peak_bytes']['allocated']['median']/2**20:.2f} |")
lines+=['','Negative paired time change means faster. The frozen statistic is the mean of within-block fused/staged time ratios; throughput ratios are not substituted for it. Peaks are synchronized PyTorch training allocator measurements after warmup, not total-device memory certification. Reserved peaks and whole-child RSS remain in analysis.json.','',
'| Profile | Backend | Actual CUDA kernels | Packed fused kernels |','|---|---|---:|---:|']
for profile in analysis['profiles']:
 lines.append(f"| {profile['codec']}/{profile['training']} | {profile['mode']} | {profile['kernels']} | {profile['fused']} |")
lines+=['','## Scope and retained evidence','',
'The staged comparator and packed candidate have explicitly different high-row dispatch profiles. Staged uses native rows 1..128 and 481..512; packed hybrid uses native rows 1..128 and fused WMMA rows 129..512. Native SiLU, routing and ordered scatter remain unchanged. This compares complete backends, including their row-policy difference; it does not isolate fusion alone. Small-row fallback is not counted as fused work.','',
'The packed pool does not retain a complete dense MoE layer. Separate resident-expert references are correctness-only controls; they are not full-resident-model timing runs. No convergence, general speedup, full-weight training, 8 GiB fit, physical-host isolation or default change is established. Guest F1 and this pinned hardware/software recipe delimit the result.','',
'The full raw ZIP is retained at `'+str(archive)+'` on the source instance: '+str(receipt['bytes'])+' bytes, SHA-256 `'+receipt['sha256']+'`. Its '+str(len(manifest['payloads']))+' payload identities are in raw-archive-manifest.json. It retains source snapshots, all raw tensors/adapters, traces, replay records and logs. Original/generated checkpoint/cache payload omissions are explicit in that manifest.','',
'**A complete local backup is not yet present.** This small publication contains the report, analysis, protocol, per-cell ledger, verification and raw manifest; it does not contain the full tensor/trace archive. Source-host CPU/ZIP checks must not be mislabeled as an independent local full-archive replay. Preserve the source instance or obtain another verified complete copy before deleting it.','',
'The historical staged 234-cell study and unsuccessful development candidates remain unchanged. Current-head CI, issue-tracking decision and final owner/reviewer D3 acceptance remain separate. No additional GPU repetition is requested by this completed rule.','']
(out/'report.md').write_bytes('\n'.join(lines).encode())
(out/'.gitattributes').write_bytes(b'*.json text eol=lf\n*.md text eol=lf\n*.zip binary\n')
save('SHA256SUMS.json',{p.name:digest_file(p) for p in sorted(out.iterdir()) if p.is_file() and p.name!='SHA256SUMS.json'})
packet=Path('/root/d3-fused-report-921d86a1.zip')
with zipfile.ZipFile(packet,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as zipped:
 for path in sorted(out.iterdir()):zipped.write(path,path.name)
with zipfile.ZipFile(packet) as zipped:assert zipped.testzip() is None
summary={'status':'report_ready','packet':str(packet),'bytes':packet.stat().st_size,'sha256':digest_file(packet),'verification':verification}
Path('/root/d3-fused-report-921d86a1.receipt.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2),flush=True)
