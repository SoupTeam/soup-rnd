# F2 matrix (new hardware only)

NOT_RUN is not a measurement or an OOM.

| Condition | Length | Outcomes | supervised tok/s | step s | VRAM alloc/res GiB | sampled RAM GiB | sampled read MB/s | GPU % | SM MHz |
|---|---:|---|---:|---:|---:|---:|---:|---:|---:|
| ram | 128 | bench:FAIL=5; bench:NO_VERDICT=1; train:FAIL=6 | — | — | — | — | — | — | — |
| ram | 384 | bench:FAIL=6; train:FAIL=6 | — | — | — | — | — | — | — |
| ram | 1024 | bench:FAIL=6; train:FAIL=6 | — | — | — | — | — | — | — |
| nvme | 128 | NOT_RUN | — | — | — | — | — | — | — |
| nvme | 384 | NOT_RUN | — | — | — | — | — | — | — |
| nvme | 1024 | NOT_RUN | — | — | — | — | — | — | — |
| refusal | 128 | NOT_RUN | — | — | — | — | — | — | — |
| refusal | 384 | NOT_RUN | — | — | — | — | — | — | — |
| refusal | 1024 | NOT_RUN | — | — | — | — | — | — | — |

Descriptive only. No 10% effect claim without the F1 repeats rule.
