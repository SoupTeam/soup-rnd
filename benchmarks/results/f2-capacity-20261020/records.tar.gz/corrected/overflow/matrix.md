# F2 matrix (new hardware only)

NOT_RUN is not a measurement or an OOM.

| Condition | Length | Outcomes | supervised tok/s | step s | VRAM alloc/res GiB | sampled RAM GiB | sampled read MB/s | GPU % | SM MHz |
|---|---:|---|---:|---:|---:|---:|---:|---:|---:|
| ram | 128 | NOT_RUN | — | — | — | — | — | — | — |
| ram | 384 | NOT_RUN | — | — | — | — | — | — | — |
| ram | 1024 | NOT_RUN | — | — | — | — | — | — | — |
| nvme | 128 | bench:NO_VERDICT=2; bench:PASS=10; train:PASS=12 | 10.748 (n=10) | 8.6278 | 3.064/3.217 | 20.446 | 5877.013 | 59.98 | 2835 |
| nvme | 384 | bench:PASS=12; train:PASS=12 | 40.325 (n=12) | 8.6457 | 3.486/3.898 | 20.501 | 5869.247 | 60.20 | 2820 |
| nvme | 1024 | bench:PASS=12; train:PASS=12 | 113.597 (n=12) | 8.7064 | 4.868/5.521 | 20.460 | 5834.785 | 60.87 | 2820 |
| refusal | 128 | NOT_RUN | — | — | — | — | — | — | — |
| refusal | 384 | NOT_RUN | — | — | — | — | — | — | — |
| refusal | 1024 | NOT_RUN | — | — | — | — | — | — | — |

Descriptive only. No 10% effect claim without the F1 repeats rule.
