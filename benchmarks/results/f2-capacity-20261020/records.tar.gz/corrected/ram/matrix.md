# F2 matrix (new hardware only)

NOT_RUN is not a measurement or an OOM.

| Condition | Length | Outcomes | supervised tok/s | step s | VRAM alloc/res GiB | sampled RAM GiB | sampled read MB/s | GPU % | SM MHz |
|---|---:|---|---:|---:|---:|---:|---:|---:|---:|
| ram | 128 | bench:PASS=12; train:PASS=12 | 78.168 (n=12) | 1.1857 | 2.230/2.465 | 24.462 | 0.000 | 99.17 | 2820 |
| ram | 384 | bench:PASS=12; train:PASS=12 | 270.762 (n=12) | 1.2873 | 2.642/3.037 | 24.511 | 0.000 | 99.36 | 2794 |
| ram | 1024 | bench:PASS=12; train:PASS=12 | 419.648 (n=12) | 2.3556 | 4.036/4.697 | 24.474 | 0.000 | 99.67 | 2790 |
| nvme | 128 | NOT_RUN | — | — | — | — | — | — | — |
| nvme | 384 | NOT_RUN | — | — | — | — | — | — | — |
| nvme | 1024 | NOT_RUN | — | — | — | — | — | — | — |
| refusal | 128 | NOT_RUN | — | — | — | — | — | — | — |
| refusal | 384 | NOT_RUN | — | — | — | — | — | — | — |
| refusal | 1024 | NOT_RUN | — | — | — | — | — | — | — |

Descriptive only. No 10% effect claim without the F1 repeats rule.
