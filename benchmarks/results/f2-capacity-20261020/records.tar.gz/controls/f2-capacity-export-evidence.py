"""Run after measurement only: immutable whitelisted F2 records and trained adapters."""
import hashlib
import json
import shutil
import subprocess
import tarfile
import time
from pathlib import Path

repo = Path('/workspace/f2-repo')
root = repo / 'out/f2-capacity-20261020-cache-reclaim'
old = repo / 'out/f2-capacity-20261020'
destination = Path('/workspace/f2-capacity-export')
destination.mkdir(exist_ok=False)
assert Path('/workspace/f2-capacity-corrected-campaign.done').exists()
source = subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
assert source == 'fed4c760bf7d8619bc265636c33e80ba7901f868'

def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(4*1024**2), b''):
            result.update(chunk)
    return result.hexdigest()

frozen = json.loads((root / 'frozen.json').read_text())
snapshot = root / 'frozen-inputs'
snapshot.mkdir(exist_ok=False)
index = {}
for number, (original, expected) in enumerate(frozen['inputs'].items()):
    path = Path(original)
    assert digest(path) == expected
    target = snapshot / (f'{number:03d}-' + path.name)
    shutil.copy2(path, target)
    assert digest(target) == expected
    index[original] = {'path': target.relative_to(root).as_posix(), 'sha256': expected}
(root / 'frozen-inputs-index.json').write_text(json.dumps(index,indent=2))
final_hashes = {}
for name, expected in frozen['files'].items():
    path = Path(name)
    actual = digest(path)
    assert actual == expected['sha256'], name
    assert path.stat().st_size == expected['bytes']
    final_hashes[name] = {'sha256':actual,'bytes':path.stat().st_size}
(root / 'final-tensor-hash-verification.json').write_text(json.dumps({
    'source_commit':source,'unix_s':time.time(),'files':final_hashes},indent=2))

packages = destination / 'packages.txt'
packages.write_bytes(subprocess.check_output(['/workspace/f2-venv/bin/python','-m','pip','freeze']))
source_archive = destination / 'measured-source.tar'
subprocess.run(['git','-C',str(repo),'archive','--format=tar','--output',str(source_archive),
    source,'src','pyproject.toml','benchmarks/harness','benchmarks/f2-capacity-20261020.md',
    'benchmarks/f2-14b-reference.md','AGENTS.md','CONTRIBUTING.md',
    'tests/test_f2_capacity_reference.py','tests/test_stream_container_memory.py'],check=True)
top_names = (
    'f2-capacity-build-stores-attempt-1.log', 'f2-capacity-build-stores-v2.log',
    'f2-capacity-corrected-cpu.log','f2-capacity-corrected-cpu.xml',
    'f2-capacity-corrected-ruff.log','f2-capacity-corrected-stage.log',
    'f2-capacity-corrected-mapping.log','f2-capacity-corrected-freeze.log',
    'f2-capacity-corrected-campaign.log','f2-capacity-corrected-campaign-exit.status',
    'f2-capacity-campaign.log','f2-capacity-freeze.log',
    'f2-capacity-guard-ready-v2.json','f2-capacity-export-evidence.py',
    'f2-capacity-stage.log')
members = []
records = destination / 'records.tar.gz'
with tarfile.open(records,'w:gz',compresslevel=6) as output:
    for phase, prefix in ((root,'corrected'),(old,'interrupted')):
        for path in sorted(phase.rglob('*')):
            rel = path.relative_to(phase)
            if (not path.is_file() or path.is_symlink() or 'adapters' in rel.parts
                or path.suffix not in ('.json','.jsonl','.log','.md','.txt','.py')):
                continue
            name = prefix + '/' + rel.as_posix()
            output.add(path,arcname=name)
            members.append({'path':name,'bytes':path.stat().st_size,'sha256':digest(path)})
    for name in top_names:
        path = Path('/workspace') / name
        if path.is_file():
            output.add(path,arcname='controls/'+name)
            members.append({'path':'controls/'+name,'bytes':path.stat().st_size,
                            'sha256':digest(path)})
    checkpoint = Path('/workspace/qwen14b')
    for name in ('f2-source.json','config.json','generation_config.json',
                 'tokenizer_config.json','special_tokens_map.json'):
        path = checkpoint / name
        if path.is_file():
            output.add(path,arcname='checkpoint-metadata/'+name)
            members.append({'path':'checkpoint-metadata/'+name,
                            'bytes':path.stat().st_size,'sha256':digest(path)})
    for path in (packages, source_archive):
        output.add(path,arcname=path.name)
        members.append({'path':path.name,'bytes':path.stat().st_size,'sha256':digest(path)})
    manifest = destination / 'records-members.json'
    manifest.write_text(json.dumps(members,indent=2))
    output.add(manifest,arcname=manifest.name)

adapter_rows = []
adapters = destination / 'adapters.tar.gz'
with tarfile.open(adapters,'w:gz',compresslevel=1) as output:
    for cell in sorted((root/'valid-adapters').iterdir()):
        origin = json.loads((cell/'origin.json').read_text())
        for name in ('adapter_model.safetensors','adapter_config.json','origin.json'):
            path = cell/name
            actual = digest(path)
            if name in origin['files']:
                assert actual == origin['files'][name]
            output.add(path,arcname='valid-adapters/'+cell.name+'/'+name)
            adapter_rows.append({'cell':cell.name,'file':name,'bytes':path.stat().st_size,
                                 'sha256':actual})
assert len(adapter_rows) == 18, 'Six first valid adapters are required'
manifest = {'source_commit':source,'created_unix_s':time.time(),
            'prior_cohorts_pooled':False,'adapter_members':adapter_rows,
            'archives':[{'name':p.name,'bytes':p.stat().st_size,'sha256':digest(p)}
                        for p in (records,adapters)],
            'included_tensor_blobs':'six trained adapters only; base/cache full hashes retained',
            'secrets_included':False}
(destination/'manifest.json').write_text(json.dumps(manifest,indent=2))
(destination/'done.json').write_text(json.dumps({'unix_s':time.time(),'success':True}))
