"""Remote-only, single-attempt Moonlight CPU integration verification.

The parent supplies the completed source packet and installed environment. This
runner neither installs dependencies nor qualifies CUDA, Oracle VJP or quality.
"""

from __future__ import annotations

import argparse
import ast
import copy
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import traceback
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any

PROFILE = "moonlight-16b-a3b"
MODEL_ID = "moonshotai/Moonlight-16B-A3B"
REVISION = "476b36a473d4467f94469414bef6cee75c9c8172"
RESULTS = "benchmarks/results/p3-moonlight-quality"
AUX_REPORT = f"{RESULTS}/prelaunch-review-v1/aux-report-v2.json"
AUX_SHA256 = "3b56a594a381822bd33c11cea01d6ff5b1d2ef9508522924f148b1431f62f27a"
CONTRACT = f"{RESULTS}/aux-admission-contract-v2.json"
CONTRACT_SHA256 = "12e9a1f548d3192035f5781e0d568642480a94a383d48fb1f5373a8f2e178cd0"
CONTINUITY = f"{RESULTS}/aux-source-continuity-v1.json"
CONTINUITY_SHA256 = "055426bb633c04cd81933a4c6d3ad5b2bacbccba7d1e76cb6cde5c2349828999"
ORACLE = "benchmarks/harness/p3_deepseek_oracle.py"
ORACLE_SHA256 = "c47fc3bea0a6034bdbaa39e6ac1da7f1b527451f0f5273ee93d1197481ff831b"
CONFIG_SHA256 = "64513a4aa6ffd2337215ea80c880491ad54a180ffb66a53dd9e178c6f8e9f76c"
INVENTORY_SHA256 = "372baec885e52e89d26895f79759758b9600b67c518f80761c437e0f5e08a5ee"
TRAINING = (
    "benchmarks/results/p3-stage2-quality/admission-kaggle-v3/"
    "evidence/dataset/training-sources.jsonl"
)
TRAINING_SHA256 = "8ab0bdfdefde056387835fcaf38914fe2c6879cde1cf89a8f6169629630675a7"
DATA_ROOT = "benchmarks/results/p3-stage2-v2/data-build-kaggle-v1/evidence/data"
DATA_SHA256 = "07f3c65cce76d0b209ce20aff7b096857077ac906156ac4ecf2c7955141b2b81"
AUX_FIELDS = {"aux_loss_alpha", "seq_aux"}
TARGETS = {"q_proj", "kv_a_proj_with_mqa", "kv_b_proj", "o_proj"}
# Exact Git bytes at the reviewed parent 8bc5826d370b349993e790dcc7643aa7f4b489d4.
ORIGINAL_TESTS = {
    "attention": "78028d0adbeea2afb24f78ec1a8bc7e1fd4473d3d17d9c4752cc0aed8791207a",
    "data": "7ad029d7f24b6f0b091fc12f025b98d0077dfaec2c8899eff5087b74f3a3c9f7",
    "eval": "5273e569dd9b0bb65ec91e030b7d690833a2fc82772e5fc4d1e04c9d6456acbd",
    "failfast": "8db4fc34dccd4011820f330ddf9a798057c6b423428b0cb5e405e55a015577ba",
    "gate": "667a8e1c3f4ea32e06f4627481a88d708876eb35b2d376fb0f1f9fa25470f3ef",
    "kaggle": "c0f9814ba1b29859546626ad79f7b985d5e9052aae9dc2e3ee5e6bd592b295d0",
    "model": "f6263b1469c82c2673876a041e51e9f723420d28062a9197e6f181ca2ca708e3",
    "prelaunch_safety": "18c7ac12f045132ec4f65da56f7cede22e2bd7901b4b4c993b862ccc6f12939f",
    "prepare": "f56628ed4712307e6c029186cb48e551ac2dcea4e94c551ef5ba80d15da662d5",
    "smoke": "19ce389d3c8dfbb75dae81e0a48d53e35de2ba30cf4387cac2828cc3ed6db0c8",
    "stage": "1611a316f5cf1f58e3d8b22f2d402e395951b9fd07e6a557ff785040ba38b39c",
    "timing": "ea2640872941b2a28abbc285b640f9b0858ba9d0b3f0933fbea8771dbbee17cb",
    "timing_admission": "8f2f721bbcb1e5ae2cf3b99ec6f82f88a282201370c12c9ea467125e7807f528",
    "train": "d04fa970367dddc9c32c11675c970c7edda6b55ecefd02be4b45736a07f8ff80",
}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def error_record(error: BaseException) -> dict[str, str]:
    return {"type": type(error).__name__, "message": str(error),
            "traceback": traceback.format_exc()}


def write_json(path: Path, value: Any) -> None:
    temporary = path.with_name(path.name + ".writing")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n",
                         encoding="utf-8")
    os.replace(temporary, path)


def descriptor(path: Path) -> dict[str, Any]:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024**2), b""):
            digest.update(block)
    return {"bytes": path.stat().st_size, "sha256": digest.hexdigest()}


def child(root: Path, name: str) -> Path:
    require(not Path(name).is_absolute(), f"absolute packet path: {name}")
    path = root / name
    require(os.path.commonpath((os.path.realpath(root), os.path.realpath(path)))
            == os.path.realpath(root), f"path escapes packet: {name}")
    return path


def rss_observation() -> dict[str, Any]:
    try:
        import resource

        require(sys.platform == "linux", "ru_maxrss byte conversion requires Linux")
        return {
            "status": "OBSERVED", "method": "resource.getrusage.ru_maxrss",
            "self_peak_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
            "children_peak_bytes": resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss * 1024,
            "scope": "lifetime self and reaped-child RSS high-water marks, separately; "
                     "not a concurrent process-tree sum, delta or stage-only peak",
            "gpu_peak_observed": False, "cgroup_peak_observed": False,
        }
    except Exception as error:
        return {"status": "UNAVAILABLE", "error": error_record(error)}


def file_inventory(root: Path) -> dict[str, Any]:
    return {path.relative_to(root).as_posix(): descriptor(path)
            for path in sorted(root.rglob("*")) if path.is_file()}


def execution_sources(repo: Path) -> dict[str, Any]:
    paths = set()
    for directory in ("src/soup_cli", "scripts", "tests", "benchmarks/harness"):
        paths.update((repo / directory).rglob("*.py"))
    paths.update(repo.glob("pyproject.toml"))
    paths.update(repo.glob("pytest.ini"))
    paths.update(repo.glob("ruff.toml"))
    paths.update(repo.glob(".ruff.toml"))
    paths.update(repo.glob("setup.cfg"))
    paths.update(repo.glob("tox.ini"))
    plan = repo / ".superpowers/sdd/p3-moonlight-quality-plan/integration_preflight.py"
    if plan.is_file():
        paths.add(plan)
    return {path.relative_to(repo).as_posix(): descriptor(path) for path in sorted(paths)}


def test_selection(repo: Path) -> dict[str, Any]:
    original = {f"tests/test_p3_deepseek_quality_{name}.py": digest
                for name, digest in ORIGINAL_TESTS.items()}
    deepseek = {path.relative_to(repo).as_posix()
                for path in (repo / "tests").glob("test_p3_deepseek_quality_*.py")}
    moonlight = {path.relative_to(repo).as_posix()
                 for path in (repo / "tests").glob("test_p3_moonlight_*.py")}
    paths = sorted(deepseek | moonlight)
    observed = {}
    for name in paths:
        try:
            observed[name] = descriptor(repo / name)
        except OSError as error:
            observed[name] = {"error": error_record(error)}
    mismatches = [name for name, digest in original.items()
                  if observed.get(name, {}).get("sha256") != digest]
    profile_test = "tests/test_p3_deepseek_quality_profiles.py"
    return {
        "paths": paths, "file_count": len(paths), "original_file_count": len(original),
        "moonlight_file_count": len(moonlight), "files": observed,
        "original_expected_sha256": original, "original_mismatches": mismatches,
        "profile_test": profile_test,
        "valid": not mismatches and profile_test in deepseek
                 and set(original).issubset(deepseek) and bool(moonlight),
        "gpu_policy": "CUDA_VISIBLE_DEVICES is empty; unchanged tests/conftest.py gpu marker "
                      "skips remain in JUnit. No -m override or GPU qualification.",
    }


def ast_inventory(path: Path, relative: str) -> list[dict[str, Any]]:
    """Conservative syntax inventory, not numerical-consumer classification."""
    text = path.read_text(encoding="utf-8-sig")
    lines = text.splitlines(keepends=True)
    tree = ast.parse(text, filename=relative)
    parents = {nested: node for node in ast.walk(tree) for nested in ast.iter_child_nodes(node)}
    result = []
    for node in ast.walk(tree):
        kinds = []
        literal = node.value if isinstance(node, ast.Constant) else None
        symbol = (node.attr if isinstance(node, ast.Attribute) else
                  node.id if isinstance(node, ast.Name) else
                  node.arg if isinstance(node, ast.keyword) else "")
        if ((isinstance(literal, str) and any(field in literal for field in AUX_FIELDS))
                or symbol in AUX_FIELDS):
            kinds.append("aux_field_occurrence")
        if isinstance(node, (ast.Name, ast.Attribute, ast.Subscript)) and isinstance(
            node.ctx, ast.Load,
        ) and "config" in ast.unparse(node).lower():
            kinds.append("config_reference_load")
        if isinstance(node, ast.Call) and "config" in ast.unparse(node).lower():
            kinds.append("config_related_call")
        if not kinds:
            continue
        scope = node
        names = []
        while scope in parents:
            scope = parents[scope]
            if isinstance(scope, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                names.append(scope.name)
        owner = node
        while owner in parents and not isinstance(
            owner, (ast.FunctionDef, ast.AsyncFunctionDef),
        ):
            owner = parents[owner]
        body = getattr(owner, "body", [])
        first = body[0].lineno if body else 1
        last = body[-1].end_lineno if body else len(lines)
        body_text = "".join(lines[first - 1:last])
        segment = ast.get_source_segment(text, node) or ""
        result.append({
            "file": relative, "line": node.lineno, "end_line": node.end_lineno,
            "column": node.col_offset, "node_type": type(node).__name__, "kinds": kinds,
            "function": ".".join(reversed(names)) or "<module>",
            "function_body_first_line": first, "function_body_last_line": last,
            "body_sha256": hashlib.sha256(body_text.encode("utf-8")).hexdigest(),
            "body_ast_sha256": hashlib.sha256(
                ast.dump(ast.Module(body=body, type_ignores=[]), include_attributes=False).encode()
            ).hexdigest(),
            "expression": segment, "classification": "REQUIRES_CORE_REVIEW",
        })
    return sorted(result, key=lambda item: (item["line"], item["column"], item["node_type"]))


def continuity(repo: Path, output: Path, record: dict[str, Any]) -> None:
    from benchmarks.harness import p3_deepseek_quality_model as model

    for name, digest in ((AUX_REPORT, AUX_SHA256), (CONTRACT, CONTRACT_SHA256),
                         (CONTINUITY, CONTINUITY_SHA256)):
        observed = descriptor(child(repo, name))
        record.setdefault("admission_files", {})[name] = observed
        require(observed["sha256"] == digest, f"immutable admission changed: {name}")
        shutil.copyfile(repo / name, output / Path(name).name)
    approved = json.loads((repo / AUX_REPORT).read_bytes())
    mismatches = []
    try:
        record["native_aux_admission"] = model.native_aux_admission(PROFILE)
        require(record["native_aux_admission"] is not None, "native aux admission absent")
    except Exception as error:
        record["native_aux_admission_error"] = error_record(error)
        mismatches.append("installed native/PEFT sources or normalized Oracle admission")
    record["numerical_aux_proof_rerun"] = False
    record["continuity"] = {}
    names = sorted(name for name in approved["sources"]
                   if name.startswith("repository/src/soup_cli/")
                   or name == "repository/" + ORACLE)
    require(names and "repository/" + ORACLE in names, "approved repository coverage absent")
    for name in names:
        relative = name.removeprefix("repository/")
        expected = approved["sources"][name]
        path = child(repo, relative)
        try:
            observed = descriptor(path)
            matched = (observed["sha256"] == expected["sha256"]
                       and observed["bytes"] == expected["bytes"])
            target = output / "current-sources" / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, target)
            record["continuity"][name] = {"expected": expected, "observed": observed,
                                           "matches": matched}
            if not matched:
                mismatches.append(name)
        except Exception as error:
            mismatches.append(name)
            record["continuity"][name] = {"expected": expected, "error": error_record(error)}
    record["oracle_raw_sha256"] = descriptor(repo / ORACLE)["sha256"]
    if record["oracle_raw_sha256"] != ORACLE_SHA256:
        mismatches.append("canonical Oracle raw bytes")
    wrappers = sorted(set((repo / "benchmarks/harness").glob("p3_deepseek_quality_*.py"))
                      | set((repo / "benchmarks/harness").glob("p3_moonlight_*.py")))
    record["quality_wrappers"] = {}
    inventory = []
    for path in wrappers:
        relative = path.relative_to(repo).as_posix()
        target = output / "current-sources" / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
        current = descriptor(path)
        previous = approved["sources"].get("repository/" + relative)
        record["quality_wrappers"][relative] = {
            **current, "approved_previous_sha256": previous["sha256"] if previous else None,
            "changed_since_approved_proof": previous is None or current["sha256"] != previous[
                "sha256"],
        }
        try:
            inventory.extend(ast_inventory(path, relative))
        except Exception as error:
            record["quality_wrappers"][relative]["ast_error"] = error_record(error)
            mismatches.append("wrapper AST inventory: " + relative)
    write_json(output / "wrapper-ast-inventory.json", {
        "scope": "All current quality/Moonlight wrappers, including unchanged files; "
                 "aux literals/attributes/keywords and conservative config references/calls. "
                 "Reads through dynamic aliases require review of retained complete sources.",
        "classification": "Syntax evidence only. No numerical-consumer finding or exemption; "
                          "parent/core review must classify authorized metadata removal.",
        "files": record["quality_wrappers"], "occurrences": inventory,
    })
    record["mismatches"] = mismatches
    require(not mismatches, "approved execution source continuity failed; inspect all mismatches")


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def http_error_302(self, request, response, code, message, headers):
        return response

    http_error_301 = http_error_303 = http_error_307 = http_error_308 = http_error_302


def public_head(url: str, expected: dict[str, Any]) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """HEAD only. Follow same-host metadata redirects, never a weight payload GET."""
    opener = urllib.request.build_opener(NoRedirect())
    hops = []
    for _ in range(6):
        request = urllib.request.Request(url, method="HEAD", headers={"Accept-Encoding": "identity"})
        with opener.open(request, timeout=30) as response:
            headers = response.headers
            etag = headers.get("X-Linked-Etag", headers.get("ETag", "")).strip('"')
            size = headers.get("X-Linked-Size", headers.get("Content-Length", ""))
            commit = headers.get("X-Repo-Commit")
            location = urllib.parse.urljoin(url, headers.get("Location", url))
            hops.append({"method": "HEAD", "status": response.status,
                         "host": urllib.parse.urlsplit(url).hostname,
                         "commit_hash": commit, "etag": etag, "declared_size": size})
            require(response.status in (200, 301, 302, 303, 307, 308), "unexpected HEAD status")
            require(urllib.parse.urlsplit(location).scheme == "https", "non-HTTPS HEAD location")
            if (commit and etag == expected["hub_etag"] and size.isdigit()
                    and int(size) == expected["bytes"]):
                return {"commit_hash": commit, "etag": etag, "size": int(size),
                        "location": location}, hops
            require(response.status != 200, "HEAD lacks verified content identity")
            require(urllib.parse.urlsplit(location).hostname
                    == urllib.parse.urlsplit(url).hostname,
                    "external HEAD redirect lacks verified Hub metadata")
            url = location
    raise ValueError("HEAD exceeded five metadata redirects; no retry")


def hub_metadata(repo: Path, output: Path, record: dict[str, Any]) -> None:
    from benchmarks.harness import p3_deepseek_quality_prepare as prepare
    from benchmarks.harness.p3_deepseek_quality_profiles import get_profile

    profile = get_profile(PROFILE)
    require(profile.model_id == MODEL_ID and profile.revision == REVISION, "profile pin differs")
    require(profile.source_inventory_sha256 == INVENTORY_SHA256, "profile inventory pin differs")
    require(descriptor(repo / RESULTS / "source-inventory-v1.json")["sha256"]
            == INVENTORY_SHA256, "inventory bytes changed")
    record.update(weight_payload_bytes_downloaded=0, config_payload_bytes_downloaded=0,
                  authentication="none; public urllib requests without token or cookies",
                  retries=0, heads={}, model_id=MODEL_ID, revision=REVISION)
    write_json(output / "result.json", record)
    url = f"https://huggingface.co/api/models/{MODEL_ID}/revision/{REVISION}?blobs=true"
    request = urllib.request.Request(url, headers={"Accept-Encoding": "identity"})
    with urllib.request.urlopen(request, timeout=30) as response:
        require(response.status == 200, "Hub metadata API did not return 200")
        payload = response.read(2 * 1024**2 + 1)
    require(len(payload) <= 2 * 1024**2, "Hub metadata response exceeds fixed 2MiB bound")
    (output / "public-hub-metadata.json").write_bytes(payload)
    info = json.loads(payload)
    siblings = []
    for row in info["siblings"]:
        normalized = {**row, "blob_id": row.get("blobId", row.get("blob_id"))}
        if row.get("lfs") is not None:
            normalized["lfs"] = {**row["lfs"], "sha256": row["lfs"].get(
                "sha256", row["lfs"].get("oid"))}
        siblings.append(normalized)
    rows = prepare.hub_inventory({"sha": info["sha"], "siblings": siblings}, profile_id=PROFILE)
    record["inventory"] = rows
    record["metadata_payload_bytes"] = len(payload)
    record["declared_head_count"] = len(rows)
    config_head = None
    for name, expected in sorted(rows.items()):
        head_url = f"https://huggingface.co/{MODEL_ID}/resolve/{REVISION}/{name}"
        head, hops = public_head(head_url, expected)
        prepare.verify_head(head, expected, profile_id=PROFILE)
        record["heads"][name] = {"verified": True, "descriptor": expected, "hops": hops}
        if name == "config.json":
            config_head = head
        write_json(output / "result.json", record)
    require(len(record["heads"]) == len(rows) == 32, "not every declared HEAD was validated")
    require(config_head is not None and rows["config.json"]["bytes"] == 1375,
            "config identity/size absent")
    # _stream_download has no retry loop and bounds the sole payload to 1375 bytes plus EOF.
    try:
        prepare._stream_download(config_head["location"], output / "config.json",
                                 rows["config.json"])
    finally:
        config_path = output / "config.json"
        record["config_payload_bytes_downloaded"] = (
            config_path.stat().st_size if config_path.is_file() else 0)
        record["config_payload_byte_scope"] = "bytes retained from the sole bounded payload GET"
        write_json(output / "result.json", record)
    config = prepare.local_descriptor(output / "config.json", rows["config.json"],
                                      profile_id=PROFILE)
    record["config"] = config
    require(config["sha256"] == CONFIG_SHA256, "config exact SHA256 differs")
    values = json.loads((output / "config.json").read_bytes())
    require(all(values.get(name) == value for name, value in profile.shape.items()),
            "live config profile shape differs")
    require(values.get("aux_loss_alpha") == 0.001 and values.get("seq_aux") is True,
            "live config aux declarations differ")
    require("quantization_config" not in values, "Moonlight source must be BF16, not prequantized")


def normalized_session(repo: Path, output: Path, record: dict[str, Any]) -> None:
    import torch

    from benchmarks.harness import p3_deepseek_quality_model as quality
    from benchmarks.harness.b13_moe_fixture import moe_config, moe_weights_dir
    from benchmarks.harness.p3_deepseek_oracle import DeepseekOracleProbe
    from soup_cli.utils import layer_stream_runtime

    require(not torch.cuda.is_available(), "normalized smoke must remain CPU-only")
    record.update(
        scope="Two independent tiny native BF16 CPU per-expert NF4 construction sessions only",
        oracle_constructor_bypassed=True, oracle_attached=False, oracle_vjp_executed=False,
        cuda_qualification=False, quality_evaluated=False, numerical_aux_proof_rerun=False,
        source_weights="seeded tiny native fixture, not downloaded production weights",
        sessions=[], construction_configs=[],
        oracle_guard_scope="Unchanged _check_config only through object.__new__ and _configs; "
                           "no constructor, hook attachment, forward/backward, CUDA or VJP",
    )
    tiny = Path(tempfile.mkdtemp(prefix="p3-moonlight-normalization-"))
    source, cache = tiny / "weights", tiny / "cache"
    initial = output / "initial.safetensors"
    require(descriptor(repo / ORACLE)["sha256"] == ORACLE_SHA256,
            "Oracle raw bytes differ before guard smoke")
    runtime_directories = []
    previous_profile = sys.getprofile()
    construction_codes = {
        layer_stream_runtime.build_meta_skeleton.__code__: "build_meta_skeleton",
        layer_stream_runtime.build_streamed_model.__code__: "build_streamed_model",
    }

    def observe_construction(frame: Any, event: str, value: Any) -> None:
        if event != "return" or frame.f_code not in construction_codes or value is None:
            return
        name = construction_codes[frame.f_code]
        model = value[0] if name == "build_streamed_model" else value
        config = model.config
        row = {"constructor": name, "config_class": type(config).__name__,
               "present_aux_fields": sorted(AUX_FIELDS & vars(config).keys()),
               "config": config.to_dict()}
        record["construction_configs"].append(row)

    try:
        source = moe_weights_dir(tiny, moe_config(
            hidden_size=128, intermediate_size=128, moe_intermediate_size=64,
            num_hidden_layers=2, q_lora_rank=None, kv_lora_rank=32,
            n_routed_experts=64, num_experts_per_tok=6, n_group=1, topk_group=1,
            scoring_func="sigmoid", topk_method="noaux_tc", routed_scaling_factor=2.446,
            aux_loss_alpha=0.001, seq_aux=True, attention_dropout=0.0,
        ), seed=23)
        original = (source / "config.json").read_bytes()
        original_config = json.loads(original)
        (output / "original-config.json").write_bytes(original)
        record["original_config"] = descriptor(source / "config.json")
        expected_targets = {(layer, target, factor) for layer in range(2)
                            for target in TARGETS for factor in ("A", "B")}
        expected_digest = None
        first_metadata = None
        first_model = None
        sys.setprofile(observe_construction)
        for index in range(2):
            with quality.open_session(source, cache, device="cpu", dtype="bfloat16",
                                      prepare=index == 0, profile_id=PROFILE) as session:
                require(index == 0 or session.model is not first_model,
                        "second session reused first model object")
                if index == 0:
                    first_model = session.model
                runtime_dir = Path(session.runtime_config_directory.name)
                runtime_directories.append(str(runtime_dir))
                normalized = json.loads((runtime_dir / "config.json").read_bytes())
                require(normalized == {key: value for key, value in original_config.items()
                                       if key not in AUX_FIELDS},
                        "normalization changed more than the approved metadata pair")
                require(AUX_FIELDS.isdisjoint(vars(session.config)), "built config has aux fields")
                require(AUX_FIELDS.isdisjoint(vars(session.model.config)),
                        "built model config has aux fields")
                require((source / "config.json").read_bytes() == original, "source config changed")
                changes = session.metadata["source"]["runtime_config_normalization"]
                require([(row["field"], row["source_value"], row["runtime"]) for row in changes]
                        == [("aux_loss_alpha", 0.001, "absent"), ("seq_aux", True, "absent")],
                        "normalization receipt differs")
                params = quality.trainable_parameters(session.model)
                observed = set()
                for name, parameter in params.items():
                    match = re.search(
                        r"\.layers\.(\d+)\.self_attn\.([^.]+)\.lora_([AB])\.default\.weight$",
                        name,
                    )
                    require(match is not None and parameter.dtype == torch.float32
                            and not parameter.is_meta and parameter.device.type == "cpu",
                            f"adapter name/dtype/device differs: {name}")
                    observed.add((int(match[1]), match[2], match[3]))
                require(observed == expected_targets and len(params) == 16,
                        "every layer must have exactly the four FP32 attention adapter targets")
                guard = object.__new__(DeepseekOracleProbe)
                guard._configs = [session.config]
                guard._check_config()
                rejected = copy.deepcopy(session.config)
                rejected.aux_loss_alpha = 0.001
                rejected.seq_aux = True
                guard._configs = [rejected]
                rejection = None
                try:
                    guard._check_config()
                except RuntimeError as error:
                    require("auxiliary" in str(error), "Oracle refused for an unrelated reason")
                    rejection = {"type": type(error).__name__, "message": str(error)}
                require(rejection is not None, "unchanged Oracle accepted original coefficient")
                if index == 0:
                    receipt = quality.write_initial_adapter(session.model, initial,
                                                            profile_id=PROFILE)
                    write_json(output / "initial-adapter-receipt.json", receipt)
                    initial_sha256 = receipt["sha256"]
                    expected_digest = quality.adapter_digest(params)[0]
                    first_metadata = copy.deepcopy(session.metadata)
                else:
                    require(session.metadata == first_metadata, "independent metadata changed")
                    require(quality.load_initial_adapter(session.model, initial, profile_id=PROFILE)
                            == initial_sha256, "shared initial file hash differs")
                    require(quality.adapter_digest(params)[0] == expected_digest,
                            "shared initial adapter digest differs across independent sessions")
                require(descriptor(initial)["sha256"] == initial_sha256,
                        "shared initial adapter file changed")
                digest, tensors = quality.adapter_digest(params)
                record["sessions"].append({
                    "index": index, "prepare": index == 0, "metadata": session.metadata,
                    "runtime_config_directory": str(runtime_dir),
                    "runtime_config": normalized,
                    "runtime_config_sha256": descriptor(runtime_dir / "config.json")["sha256"],
                    "built_config_aux_fields_absent": True,
                    "adapter_digest": digest, "adapter_tensors": tensors,
                    "oracle_normalized_config_accepted": True,
                    "oracle_original_coefficient_rejection": rejection,
                })
                write_json(output / "result.json", record)
            require(not runtime_dir.exists(), "temporary config directory survived session close")
            record["sessions"][-1]["runtime_config_directory_deleted"] = True
        require((source / "config.json").read_bytes() == original, "source changed after sessions")
        require(all(not row["present_aux_fields"] for row in record["construction_configs"]),
                "one native constructor received aux metadata")
        for name in ("build_meta_skeleton", "build_streamed_model"):
            require(sum(row["constructor"] == name for row in record["construction_configs"]) >= 2,
                    f"both independent native constructors were not observed: {name}")
        record["initial"] = descriptor(initial)
        record["adapter_digest"] = expected_digest
        record["source_config_unchanged"] = True
        require(descriptor(repo / ORACLE)["sha256"] == ORACLE_SHA256,
                "Oracle raw bytes changed during guard smoke")
    finally:
        sys.setprofile(previous_profile)
        # Save receipts first, even on construction failure. Keep the adapter and all logs.
        record["temporary_config_directories"] = [
            {"path": name, "deleted": not Path(name).exists()} for name in runtime_directories
        ]
        record["owned_tiny_files_before_cleanup"] = file_inventory(tiny)
        record["resources_before_cleanup"] = rss_observation()
        write_json(output / "result.json", record)
        record["cleanup"] = {}
        for path in (source, cache):
            if path.exists():
                shutil.rmtree(path)
            record["cleanup"][path.name] = {"path": str(path), "deleted": not path.exists()}
        tiny.rmdir()
        record["owned_temp_root_deleted"] = not tiny.exists()
        write_json(output / "result.json", record)


def scoring_admission(repo: Path, output: Path, record: dict[str, Any]) -> None:
    from benchmarks.harness import p3_deepseek_quality_eval as scoring

    _, identity = scoring._scoring_protocol()
    relative = Path("benchmarks/results/p3-stage2-v2/p3-stage2-v2-protocol.json")
    isolated = output / "owned-protocol-probe"
    sibling = isolated / "soup-rnd-p3-fp8" / relative
    sibling.parent.mkdir(parents=True)
    sibling.write_bytes(Path(identity["path"]).read_bytes())
    original = scoring.__file__
    try:
        scoring.__file__ = str(isolated / "isolated-checkout/benchmarks/harness/"
                               "p3_deepseek_quality_eval.py")
        try:
            scoring._scoring_protocol()
        except ValueError as error:
            require("frozen v2 scoring protocol SHA256 mismatch" in str(error),
                    "unrelated scoring protocol refusal")
            record["missing_in_checkout_refused"] = True
        else:
            raise ValueError("missing local scoring protocol borrowed sibling checkout")
    finally:
        scoring.__file__ = original
    record.update(in_checkout_protocol=identity, matching_sibling_protocol=descriptor(sibling),
                  quality_evaluated=False)


def worker(name: str, repo_text: str, output_text: str) -> int:
    """Internal subprocess target; the public CLI remains --repo and --output."""
    from rich.console import Console

    repo, output = Path(repo_text), Path(output_text)
    output.mkdir(parents=True, exist_ok=False)
    record: dict[str, Any] = {"name": name, "status": "FAIL", "resources_before": rss_observation()}
    started = time.monotonic()

    def interrupted(number: int, frame: Any) -> None:
        raise InterruptedError(f"worker interrupted by signal {number}; no retry")

    signal.signal(signal.SIGTERM, interrupted)
    try:
        {"continuity": continuity, "hub-metadata": hub_metadata,
         "normalized-session": normalized_session, "scoring-admission": scoring_admission}[
             name](repo, output, record)
        record["status"] = "PASS"
    except BaseException as error:
        record["error"] = error_record(error)
    finally:
        record["wall_seconds"] = time.monotonic() - started
        record["resources_after"] = rss_observation()
        write_json(output / "result.json", record)
        Console().print_json(data=record)
    return 0 if record["status"] == "PASS" else 1


class Runner:
    def __init__(self, repo: Path, output: Path) -> None:
        self.repo, self.output = repo, output
        # Canonical verification settings, not environment creation or installation.
        self.environment = dict(os.environ)
        self.environment.update(
            PYTHONPATH=os.pathsep.join((str(repo / "src"), str(repo))),
            CUDA_VISIBLE_DEVICES="", P3_QUALITY_DEVICE="cpu", PYTHONHASHSEED="23",
            OMP_NUM_THREADS="2", MKL_NUM_THREADS="2", TOKENIZERS_PARALLELISM="false",
            PYTEST_DISABLE_PLUGIN_AUTOLOAD="1", CUBLAS_WORKSPACE_CONFIG=":4096:8",
            HF_HUB_DISABLE_TELEMETRY="1", HF_HUB_DISABLE_IMPLICIT_TOKEN="1",
            WANDB_DISABLED="true", HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1",
        )
        self.record: dict[str, Any] = {
            "schema": "p3-moonlight-integration-preflight-v1", "status": "FAIL",
            "scope": "CPU integration/control-flow only; no scientific, CUDA or VJP admission",
            "profile_id": PROFILE, "repo": str(repo), "commands": [], "requirements": [],
            "scientific_admission": False, "quality_evaluated": False,
            "production_weight_payload_bytes_downloaded": 0, "numerical_aux_proof_rerun": False,
            "full_tokenizer_parity_rerun": False, "reference_comparison_run": False,
            "resources_before": rss_observation(),
            "verification_settings": {key: self.environment[key] for key in (
                "CUDA_VISIBLE_DEVICES", "P3_QUALITY_DEVICE", "PYTHONHASHSEED", "OMP_NUM_THREADS",
                "MKL_NUM_THREADS", "PYTEST_DISABLE_PLUGIN_AUTOLOAD", "CUBLAS_WORKSPACE_CONFIG",
                "HF_HUB_OFFLINE", "TRANSFORMERS_OFFLINE")},
        }

    def save(self) -> None:
        write_json(self.output / "run.json", self.record)

    def requirement(self, name: str, function: Any) -> None:
        started = time.monotonic()
        row: dict[str, Any] = {"name": name, "status": "FAIL"}
        try:
            value = function()
            if value is not None:
                row["evidence"] = value
            row["status"] = "PASS"
        except Exception as error:
            row["error"] = error_record(error)
            (self.output / (name + ".error.txt")).write_text(row["error"]["traceback"],
                                                           encoding="utf-8")
        row["wall_seconds"] = time.monotonic() - started
        self.record["requirements"].append(row)
        self.save()

    def command(self, name: str, argv: list[str], seconds: int) -> dict[str, Any]:
        row: dict[str, Any] = {
            "name": name, "argv": argv, "cwd": str(self.repo), "timeout_seconds": seconds,
            "status": "RUNNING", "returncode": None, "timed_out": False,
            "stdout_stderr_log": name + ".log", "resources_before": rss_observation(),
        }
        self.record["commands"].append(row)
        self.save()
        started = time.monotonic()
        process = None
        try:
            with (self.output / (name + ".log")).open("xb") as stream:
                process = subprocess.Popen(argv, cwd=self.repo, env=self.environment,
                                           stdout=stream, stderr=subprocess.STDOUT,
                                           start_new_session=True)
                try:
                    process.wait(timeout=seconds)
                except subprocess.TimeoutExpired:
                    row["timed_out"] = True
                    try:
                        os.killpg(process.pid, signal.SIGTERM)
                    except ProcessLookupError:
                        pass
                    try:
                        process.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        pass
                row["status"] = "FINISHED"
        except BaseException as error:
            row["status"] = "ERROR"
            row["error"] = error_record(error)
            if isinstance(error, (InterruptedError, KeyboardInterrupt)):
                raise
        finally:
            if process is not None:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                except Exception as error:
                    row["cleanup_error"] = error_record(error)
                try:
                    process.wait(timeout=10)
                except Exception as error:
                    row["reap_error"] = error_record(error)
                row["returncode"] = process.returncode
            row["wall_seconds"] = time.monotonic() - started
            row["resources_after"] = rss_observation()
            self.save()
        return row

    @staticmethod
    def completed(row: dict[str, Any], code: int = 0) -> None:
        require(row["status"] == "FINISHED" and not row["timed_out"]
                and row["returncode"] == code and "cleanup_error" not in row
                and "reap_error" not in row, f"{row['name']} failed; preserve log, no retry")

    def run_worker(self, name: str, seconds: int) -> None:
        launcher = (
            "import runpy,sys; namespace=runpy.run_path(sys.argv[1]); "
            "raise SystemExit(namespace['worker'](*sys.argv[2:]))"
        )
        row = self.command(name, [sys.executable, "-c", launcher,
                                 os.path.realpath(__file__), name, str(self.repo),
                                 str(self.output / name)], seconds)
        self.completed(row)
        result = json.loads((self.output / name / "result.json").read_bytes())
        require(result["status"] == "PASS", f"{name} evidence did not pass")

    def refusals(self) -> None:
        python = sys.executable
        missing = self.output / "missing-inputs"
        unapproved = self.output / "unapproved-download"
        row = self.command("unapproved-download-smoke", [
            python, "-m", "benchmarks.harness.p3_deepseek_quality_prepare", "download",
            "--profile", PROFILE, "--source", str(missing / REVISION),
            "--output", str(unapproved),
        ], 120)
        self.completed(row, 1)
        require(not unapproved.exists() and not missing.exists(),
                "unapproved download created source or output")
        log = (self.output / row["stdout_stderr_log"]).read_text(encoding="utf-8")
        require("--approved-pilot operator acknowledgement is required" in log,
                "download refused for an unrelated reason")

    def timing_refusal(self) -> None:
        missing = self.output / "missing-inputs"
        destination = self.output / "timing-refusal"
        row = self.command("timing-gate-refusal-smoke", [
            sys.executable, "-m", "benchmarks.harness.p3_deepseek_quality_timing",
            "--profile", PROFILE, "--source", str(missing / "source"),
            "--cache", str(missing / "cache"), "--initial", str(missing / "initial"),
            "--initial-sha256", "a" * 64, "--gate", str(missing / "gate/manifest.json"),
            "--gate-sha256", "b" * 64, "--data-root", str(missing / "data"),
            "--output", str(destination), "--device", "cpu", "--deadline-seconds", "5400",
        ], 120)
        self.completed(row, 1)
        receipt = json.loads((destination / "manifest.json").read_bytes())
        require(receipt.get("status") == "FAILED" and receipt.get("profile_id") == PROFILE
                and receipt.get("deadline_seconds") == 5400
                and "gate" in receipt.get("error", {}).get("message", "").lower()
                and "hardware" not in receipt and "model" not in receipt,
                "90-minute timing bound did not reach missing-gate refusal before execution")

    def native_refusal(self) -> None:
        destination = self.output / "native-refusal"
        row = self.command("native-smoke-refusal", [
            sys.executable, "-m", "benchmarks.harness.p3_deepseek_quality_smoke",
            "--profile", PROFILE, "--output", str(destination),
        ], 120)
        self.completed(row, 1)
        receipt = json.loads((destination / "manifest.json").read_bytes())
        require(receipt.get("status") == "FAILED" and receipt.get("profile_id") == PROFILE
                and receipt.get("scientific_admission") is False
                and receipt.get("failed_stage") == "native_admission"
                and receipt.get("attempts") == []
                and "available CUDA" in receipt.get("error", {}).get("message", ""),
                "native CLI did not refuse CPU at admission")

    def stage_smoke(self, timeout: bool) -> None:
        name = "stage-timeout" if timeout else "stage-success"
        code = ("import signal,time; signal.signal(signal.SIGTERM,signal.SIG_IGN);time.sleep(60)"
                if timeout else "import os;os.write(1,b'stage smoke executed')")
        row = self.command(name + "-smoke", [
            sys.executable, "-m", "benchmarks.harness.p3_deepseek_quality_stage",
            "--output", str(self.output / name), "--seconds", "1" if timeout else "10",
            "--", sys.executable, "-c", code,
        ], 40)
        self.completed(row, 124 if timeout else 0)
        result = json.loads((self.output / name / "result.json").read_bytes())
        require(result["status"] == ("TIMED_OUT" if timeout else "COMPLETE")
                and result["cleanup"]["child_reaped"] is True
                and not result["cleanup"]["errors"]
                and result["scientific_admission"] is False,
                "stage completion/deadline/cleanup receipt differs")
        if not timeout:
            require((self.output / name / "stdout.log").read_bytes() == b"stage smoke executed",
                    "stage success did not retain exact child output")

    def pytest_evidence(self, row: dict[str, Any]) -> dict[str, Any]:
        junit = self.output / "tests.xml"
        root = ET.parse(junit).getroot()
        cases = []
        for node in root.iter("testcase"):
            failure = node.find("failure")
            error = node.find("error")
            skipped = node.find("skipped")
            status = ("FAILED" if failure is not None else "ERROR" if error is not None
                      else "SKIPPED" if skipped is not None else "PASSED")
            cases.append({"classname": node.get("classname"), "name": node.get("name"),
                          "seconds": node.get("time"), "status": status,
                          "skip_reason": (skipped.get("message") or skipped.text)
                          if skipped is not None else None})
        evidence = {"junit": descriptor(junit), "testcase_count": len(cases),
                    "counts": {status: sum(case["status"] == status for case in cases)
                               for status in ("PASSED", "FAILED", "ERROR", "SKIPPED")},
                    "cases": cases, "gpu_skips_are_qualification": False}
        covered_modules = {str(case["classname"]).split(".")[-1] for case in cases}
        evidence["selected_modules_without_cases"] = sorted(
            Path(path).stem for path in self.record["test_selection"]["paths"]
            if Path(path).stem not in covered_modules)
        write_json(self.output / "test-results.json", evidence)
        self.completed(row)
        require(bool(cases) and not evidence["counts"]["FAILED"]
                and not evidence["counts"]["ERROR"], "pytest JUnit failures/empty collection")
        require(not evidence["selected_modules_without_cases"],
                "selected test file produced no JUnit cases")
        for name in (
            "test_native_moonlight_normalization_preserves_source_and_shared_initial_adapter",
            "test_private_assembly_and_public_build_publish_identical_manifest",
        ):
            require(any(case["name"] == name and case["status"] == "PASSED" for case in cases),
                    f"required integration regression was absent or skipped: {name}")
        return evidence

    def inputs(self) -> dict[str, Any]:
        expected = {
            AUX_REPORT: AUX_SHA256, CONTRACT: CONTRACT_SHA256,
            CONTINUITY: CONTINUITY_SHA256,
            f"{RESULTS}/source-inventory-v1.json": INVENTORY_SHA256,
            f"{RESULTS}/source-metadata-admission-v1.json":
                "2c22f9f346d2c58aa82445f8208bf48e12f8bd27f84447b2697f2d0fccc4a180",
            f"{RESULTS}/attention-protocol-v1.json":
                "b7ec8f56ca073a1397a7d4579d6b32550b18b148c67a9f1be2fbc50c873d1363",
            "benchmarks/results/p3-stage2-v2/p3-stage2-v2-protocol.json":
                "685fa5bee528969d9b2eef423c90280d179432ba017fbebed12b687f608a8249",
            TRAINING: TRAINING_SHA256, f"{DATA_ROOT}/manifest.json": DATA_SHA256,
            "tests/fixtures/moonlight_tokenizer_source.zip":
                "287920e7f661d7c07079cd83db7c89c8e88efdf64ff76139e3ef7a4d94b18966",
        }
        result = {}
        failures = []
        for name, digest in expected.items():
            try:
                observed = descriptor(child(self.repo, name))
                result[name] = observed
                if observed["sha256"] != digest:
                    failures.append(name)
            except Exception as error:
                failures.append(name)
                result[name] = {"error": error_record(error)}
        manifest = self.repo / DATA_ROOT / "manifest.json"
        if manifest.is_file():
            for item in json.loads(manifest.read_bytes())["files"].values():
                name = f"{DATA_ROOT}/{item['path']}"
                try:
                    observed = descriptor(child(self.repo / DATA_ROOT, item["path"]))
                    result[name] = observed
                    if observed != {"bytes": item["bytes"], "sha256": item["sha256"]}:
                        failures.append(name)
                except Exception as error:
                    failures.append(name)
                    result[name] = {"error": error_record(error)}
        write_json(self.output / "packet-inputs.json", {"files": result, "failures": failures})
        require(not failures, "packet prerequisites missing/changed; inspect packet-inputs.json")
        return result

    def source_stability(self, before: dict[str, Any]) -> dict[str, Any]:
        after = execution_sources(self.repo)
        changed = sorted(name for name in before.keys() | after.keys()
                         if before.get(name) != after.get(name))
        write_json(self.output / "executed-source-stability.json", {
            "before": before, "after": after, "changed": changed,
            "scope": "All Python bytes in the four lint roots and root test/lint configuration",
        })
        require(not changed, "packet sources changed during verification")
        return {"source_file_count": len(after), "changed": changed}

    def execute(self) -> int:
        from rich.console import Console

        started = time.monotonic()
        try:
            self.requirement("packet-inputs", self.inputs)
            source_snapshot = execution_sources(self.repo)
            write_json(self.output / "executed-sources-before.json", source_snapshot)
            selection = test_selection(self.repo)
            self.record["test_selection"] = selection
            write_json(self.output / "test-selection.json", selection)
            self.requirement("original-tests-unchanged", lambda: require(
                selection["valid"], "missing profile/Moonlight files or original test byte edits"))
            lint = self.command("ruff", [sys.executable, "-m", "ruff", "check",
                                        "src/soup_cli/", "scripts/", "tests/",
                                        "benchmarks/harness/"], 1800)
            # Always collect the one pytest result even when lint failed.
            tests = self.command("quality-tests", [
                sys.executable, "-m", "pytest", *selection["paths"], "-v", "--tb=short", "-rA",
                "-o", "addopts=", "--junitxml=" + str(self.output / "tests.xml"),
                *([] if selection["paths"] else [
                    str(self.output / "absent-selected-tests.py")]),
            ], 1800)
            self.requirement("ruff-result", lambda: self.completed(lint))
            self.requirement("pytest-result", lambda: self.pytest_evidence(tests))
            self.requirement("unapproved-download-refusal", self.refusals)
            self.requirement("stage-success", lambda: self.stage_smoke(False))
            self.requirement("stage-deadline", lambda: self.stage_smoke(True))
            self.requirement("missing-gate-refusal", self.timing_refusal)
            self.requirement("native-cpu-refusal", self.native_refusal)
            self.requirement("hub-zero-weight-metadata", lambda: self.run_worker("hub-metadata", 900))
            self.requirement("normalized-native-session", lambda: self.run_worker(
                "normalized-session", 900))
            self.requirement("scoring-protocol-locality", lambda: self.run_worker(
                "scoring-admission", 120))
            # Run after all commands so retained bytes describe the executed final packet.
            self.requirement("source-continuity", lambda: self.run_worker("continuity", 300))
            self.requirement("executed-source-stability", lambda: self.source_stability(
                source_snapshot))
            resource_ok = self.record["resources_before"].get("status") == "OBSERVED"
            self.requirement("runner-resource-observations", lambda: require(
                resource_ok and rss_observation().get("status") == "OBSERVED",
                "required Linux self/children RSS high-water observations unavailable"))
            self.record["status"] = (
                "PASS" if all(row["status"] == "PASS" for row in self.record["requirements"])
                else "FAIL"
            )
        except BaseException as error:
            self.record["error"] = error_record(error)
        finally:
            self.record["wall_seconds"] = time.monotonic() - started
            self.record["resources_after"] = rss_observation()
            self.save()
            write_json(self.output / "manifest.json", {
                "schema": self.record["schema"], "status": self.record["status"],
                "scope": "All retained files except this manifest; complete logs are not truncated",
                "artifacts": file_inventory(self.output),
            })
        Console().print(f"Moonlight integration preflight: {self.record['status']}")
        return 0 if self.record["status"] == "PASS" else 1


def main() -> int:
    from rich.console import Console

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    try:
        repo = Path(os.path.realpath(args.repo))
        output = Path(os.path.realpath(args.output))
        require(sys.platform == "linux", "remote Linux only; never run on the workstation")
        require(repo.is_dir() and (repo / "src/soup_cli").is_dir(), "completed repository required")
        require(os.path.commonpath((str(repo), str(output))) not in (str(repo), str(output)),
                "output must be separate from the input repository")
        output.mkdir(parents=True, exist_ok=False)
        shutil.copyfile(Path(__file__), output / "integration_preflight.py.txt")
        Console().print("CPU integration only. One attempt per command; retain failures, no admission.")
        runner = Runner(repo, output)

        def interrupted(number: int, frame: Any) -> None:
            raise InterruptedError(f"integration interrupted by signal {number}; no retry")

        previous = signal.signal(signal.SIGTERM, interrupted)
        try:
            return runner.execute()
        finally:
            signal.signal(signal.SIGTERM, previous)
    except Exception as error:
        Console().print(f"Integration preflight refused: {type(error).__name__}: {error}",
                        markup=False)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
