"""Remote-only ordinary-CI probe; the alternate stack cannot qualify scientific execution."""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import os
import subprocess
import sys
import time
import traceback
import xml.etree.ElementTree as ET
from pathlib import Path

from rich.console import Console


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--selection", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    report = {"schema": "p3-moonlight-ci-portability-v1", "status": "FAIL",
              "scope": "Alternate supported Rich version; contract tests only, not qualification",
              "quality_evaluated": False, "native_scientific_qualification": False}
    try:
        report["packages"] = {name: importlib.metadata.version(name) for name in (
            "rich", "numpy", "torch", "transformers", "peft", "huggingface_hub")}
        require(report["packages"]["rich"] == "14.0.0", "alternate Rich version absent")
        from benchmarks.harness.p3_deepseek_quality_model import native_aux_admission

        try:
            native_aux_admission("moonlight-16b-a3b")
        except ValueError as error:
            report["production_refusal"] = {"type": type(error).__name__, "message": str(error)}
            require(str(error) == "Moonlight native aux proof requires rich==13.9.4",
                    "production refused for a different reason")
        else:
            raise ValueError("alternate stack incorrectly passed production scientific admission")
        selection = json.loads(args.selection.read_bytes())
        require(selection["valid"] is True and selection["original_file_count"] == 14,
                "canonical test selection not admitted")
        paths = selection["paths"]
        root = os.path.realpath(args.repo)
        for relative in paths:
            path = args.repo / relative
            require(os.path.commonpath((root, os.path.realpath(path))) == root,
                    "test selection escapes checkout")
            require(digest(path) == selection["files"][relative]["sha256"],
                    "test bytes differ between primary and alternate environments")
        report["test_selection_sha256"] = digest(args.selection)
        junit = args.output / "tests.xml"
        argv = [sys.executable, "-B", "-m", "pytest", *paths, "-v", "--tb=short", "-rA",
                "-o", "addopts=", "--junitxml=" + str(junit)]
        command_started = time.monotonic()
        with (args.output / "pytest.stdout.log").open("x") as stdout, (
            args.output / "pytest.stderr.log"
        ).open("x") as stderr:
            process = subprocess.run(argv, cwd=args.repo, env=dict(os.environ), stdout=stdout,
                                     stderr=stderr, timeout=5400, check=False)
        report["command"] = {"argv": argv, "returncode": process.returncode,
                             "wall_seconds": time.monotonic() - command_started,
                             "deadline_seconds": 5400}
        cases = []
        for node in ET.parse(junit).getroot().iter("testcase"):
            failure, error, skipped = node.find("failure"), node.find("error"), node.find("skipped")
            status = ("FAILED" if failure is not None else "ERROR" if error is not None
                      else "SKIPPED" if skipped is not None else "PASSED")
            cases.append({"classname": node.get("classname"), "name": node.get("name"),
                          "status": status, "seconds": node.get("time"),
                          "skip_reason": (skipped.get("message") or skipped.text)
                          if skipped is not None else None})
        report["counts"] = {status: sum(case["status"] == status for case in cases)
                            for status in ("PASSED", "FAILED", "ERROR", "SKIPPED")}
        report["cases"] = cases
        require(process.returncode == 0 and not report["counts"]["FAILED"]
                and not report["counts"]["ERROR"], "alternate-stack contract tests failed")
        native_name = (
            "test_native_moonlight_normalization_preserves_source_and_shared_initial_adapter"
        )
        native_cases = [case for case in cases if case["name"] == native_name]
        require(len(native_cases) == 1 and native_cases[0]["status"] == "SKIPPED"
                and "rich" in (native_cases[0]["skip_reason"] or "").lower(),
                "unqualified native integration did not skip explicitly for Rich drift")
        primary_path = args.selection.with_name("test-results.json")
        primary = json.loads(primary_path.read_bytes())
        baseline = {(case["classname"], case["name"]): case for case in primary["cases"]}
        alternate = {(case["classname"], case["name"]): case for case in cases}
        require(len(baseline) == len(primary["cases"]) and len(alternate) == len(cases)
                and baseline.keys() == alternate.keys(), "CI test case identity coverage differs")
        gpu_reason = "needs a CUDA device (run the GPU subset with: pytest -m gpu --no-cov)"
        for identity, original in baseline.items():
            observed = alternate[identity]
            if original["name"] == native_name:
                require(original["status"] == "PASSED",
                        "primary native integration was not qualified")
            elif original["status"] == "SKIPPED":
                require(original["skip_reason"] == gpu_reason
                        and observed["status"] == "SKIPPED"
                        and observed["skip_reason"] == gpu_reason,
                        f"unexpected non-GPU or changed skip: {identity}")
            else:
                require(original["status"] == observed["status"] == "PASSED",
                        f"ordinary contract did not pass in both environments: {identity}")
        report["primary_test_results_sha256"] = digest(primary_path)
        report["all_primary_contract_passes_preserved"] = True
        for prefix in (
            "test_moonlight_public_loader_preserves_complete_numerical_diagnostic",
            "test_aux_repository_audit_",
            "test_native_aux_admission_still_refuses_each_unqualified_package",
        ):
            selected = [case for case in cases if case["name"].startswith(prefix)]
            require(bool(selected) and all(case["status"] == "PASSED" for case in selected),
                    f"ordinary contract/source-audit coverage was skipped or failed: {prefix}")
        zero_cases = [case for case in cases if str(case["classname"]).endswith(
            "test_p3_moonlight_gate_zero_reference")]
        require(bool(zero_cases) and all(case["status"] == "PASSED" for case in zero_cases),
                "zero-reference raw-evidence contracts did not execute in ordinary CI")
        report["status"] = "PASS"
    except BaseException:
        report["error"] = traceback.format_exc()
    finally:
        report["wall_seconds"] = time.monotonic() - started
        (args.output / "report.json").write_text(
            json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n", encoding="utf-8")
        Console().print({"ci_portability": report["status"], "scientific_qualification": False})
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
