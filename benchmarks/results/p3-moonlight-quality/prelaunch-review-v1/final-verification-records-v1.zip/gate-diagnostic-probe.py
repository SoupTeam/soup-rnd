"""Remote synthetic raw-evidence publication/readmission, not a scientific gate run."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import time
import traceback
from pathlib import Path

from rich.console import Console


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    report = {
        "schema": "p3-moonlight-derived-diagnostic-api-smoke-v1", "status": "FAIL",
        "scope": "Synthetic production-shaped metadata and CPU raw tensors only",
        "scientific_gate_run": False, "gpu_execution": False, "quality_evaluated": False,
        "pytest_fixtures_or_monkeypatches_applied": False,
    }
    try:
        from benchmarks.harness import p3_deepseek_quality_gate as gate
        from benchmarks.harness.p3_deepseek_quality_model import native_aux_admission
        from tests.test_p3_moonlight_gate import PASSES, _receipt
        from tests.test_p3_moonlight_gate_zero_reference import (
            _gradient_paths,
            _publish,
            _refresh_metrics,
            _zero_reference,
        )

        # The synthetic contract fixture is not a substitute for real installed-source admission.
        report["actual_installed_aux_binding"] = native_aux_admission("moonlight-16b-a3b")
        root = args.output / "synthetic-raw-gate"
        _, result = _receipt(root, verdict="PASS", production=True)
        zero_names = _zero_reference(root, result, all_tensors=False)
        _refresh_metrics(root, result)
        require(all(result["passes"][arm]["gradient_agreement"]["per_tensor"][
            zero_names[0]]["rel_l2"] == math.inf for arm in ("fp8_oracle", "int4_oracle")),
            "synthetic finite-zero-reference case did not produce the frozen infinite ratio")
        manifest, published = _publish(root, result)
        manifest_sha = hashlib.sha256(manifest.read_bytes()).hexdigest()
        admitted = gate.load_gate(manifest, manifest_sha, profile_id="moonlight-16b-a3b")
        expected_paths = _gradient_paths(zero_names, all_tensors=False)
        require(admitted == published and admitted["status"] == "COMPLETE"
                and admitted["verdict"] == "NO_VERDICT", "diagnostic blocked or changed verdict")
        require(admitted["nonfinite_evidence_fields"] == expected_paths,
                "independently reconstructed diagnostic paths differ")
        require(set(admitted["passes"]) == set(PASSES)
                and all(row["status"] == "COMPLETE" for row in admitted["passes"].values()),
                "six-pass raw evidence coverage differs")
        require(not (root / "failure.json").exists(), "derived metric became technical failure")
        report.update(
            status="PASS", synthetic_gate_execution_status=admitted["status"],
            synthetic_gate_diagnostic_verdict=admitted["verdict"],
            manifest_sha256=manifest_sha, nonfinite_diagnostic_paths=expected_paths,
            all_six_synthetic_passes_admitted=True,
        )
    except BaseException:
        report["error"] = traceback.format_exc()
    finally:
        report["wall_seconds"] = time.monotonic() - started
        (args.output / "report.json").write_text(
            json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n", encoding="utf-8")
        Console().print({"raw_diagnostic_api_smoke": report["status"],
                         "scientific_gate_run": False, "quality_evaluated": False})
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
