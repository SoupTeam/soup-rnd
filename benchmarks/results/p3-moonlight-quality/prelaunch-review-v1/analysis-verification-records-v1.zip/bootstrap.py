import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import traceback
import zipfile
from pathlib import Path

PIN = '1cb4bcf56198bbb98141fee93ace2e742fd1273b362667a807595a51f943924e'
output = Path('/kaggle/working/moonlight-analysis-verification-evidence')
output.mkdir(exist_ok=False)
owned = Path(tempfile.mkdtemp(prefix='moonlight-analysis-verification-', dir='/kaggle/working'))
record = {'status': 'FAILED', 'scope': 'Free CPU analysis publication-closure verification; synthetic summary API and original statistics tests only; no model or numerical gate execution', 'commands': [], 'admission_sha256': PIN}


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()


def command(argv, name, env=None, cwd=None, allow_failure=False, seconds=3600):
    started = time.monotonic()
    row = {'name': name, 'deadline_seconds': seconds}
    record['commands'].append(row)
    try:
        with (output / (name + '.log')).open('x') as handle:
            done = subprocess.run(list(map(str, argv)), stdout=handle, stderr=subprocess.STDOUT,
                                  env=env, cwd=cwd, timeout=seconds, check=False)
        row['returncode'] = done.returncode
        if done.returncode and not allow_failure:
            raise RuntimeError(name + ' failed')
        return done.returncode
    finally:
        row['seconds'] = time.monotonic() - started


try:
    choices = [p for p in Path('/kaggle/input').rglob('moonlight-admission.json')
               if digest(p) == PIN]
    if len(choices) != 1:
        raise ValueError('Pinned source admission absent or ambiguous')
    admission_path = choices[0]
    admission = json.loads(admission_path.read_bytes())
    overlay = admission_path.parent / 'source-overlay.bin'
    if digest(overlay) != admission['source_overlay_sha256']:
        raise ValueError('Source archive hash mismatch')
    shutil.copyfile(admission_path, output / 'moonlight-admission.json')
    shutil.copyfile(overlay, output / 'source-overlay.bin')
    if '__file__' in globals() and Path(__file__).is_file():
        shutil.copyfile(__file__, output / 'bootstrap.py')
    root = owned / 'soup'
    root.mkdir()
    with zipfile.ZipFile(overlay) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)) or set(names) != set(admission['source_files_sha256']):
            raise ValueError('Source inventory mismatch')
        for name in names:
            raw = archive.read(name)
            if hashlib.sha256(raw).hexdigest() != admission['source_files_sha256'][name]:
                raise ValueError('Member hash mismatch: ' + name)
            target = os.path.realpath(root / name)
            if os.path.commonpath([os.path.realpath(root), target]) != os.path.realpath(root):
                raise ValueError('Path escape')
            Path(target).parent.mkdir(parents=True, exist_ok=True)
            Path(target).write_bytes(raw)
    dependencies = ('torch==2.11.0', 'transformers==5.19.0', 'peft==0.21.2', 'accelerate==1.15.0', 'bitsandbytes==0.50.2', 'safetensors==0.8.0', 'rich==13.9.4', 'pydantic==2.14.1', 'numpy==2.1.3', 'ruff==0.17.4', 'pytest==8.4.2', 'psutil==7.2.2', 'pyyaml==6.0.3', 'trl==0.29.1', 'datasets==5.1.0', 'requests==2.32.5', 'tiktoken==0.14.0', 'tokenizers==0.23.3', 'regex==2026.11.9', 'blobfile==3.1.0', 'huggingface-hub==2.4.0', 'scipy==1.15.3')
    command([sys.executable, '-m', 'pip', 'install', 'uv==0.13.7'], 'uv')
    uv = [sys.executable, '-m', 'uv']
    environment = owned / 'py312'
    env = dict(os.environ, UV_CACHE_DIR=str(owned / 'uv-cache'))
    command([*uv, 'venv', '--python', '3.12.3', '--seed', environment], 'venv', env)
    python = environment / 'bin/python'
    command([*uv, 'pip', 'install', '--python', python, *dependencies, '-e', root], 'dependencies', env)
    env.update(PYTHONPATH=str(root / 'src') + ':' + str(root), CUDA_VISIBLE_DEVICES='',
               P3_QUALITY_DEVICE='cpu', PYTHONHASHSEED='23', OMP_NUM_THREADS='2',
               MKL_NUM_THREADS='2', TOKENIZERS_PARALLELISM='false',
               PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', CUBLAS_WORKSPACE_CONFIG=':4096:8',
               HF_HUB_DISABLE_TELEMETRY='1', WANDB_DISABLED='true',
               P3_PREFLIGHT_BOOTSTRAP_PYTHON=sys.executable)
    command([*uv, 'pip', 'freeze', '--python', python], 'packages', env)
    statuses = {}
    record['probe_returncodes'] = statuses
    statuses['ruff'] = command([python, '-m', 'ruff', 'check', 'src/soup_cli/', 'scripts/',
                                'tests/', 'benchmarks/harness/'], 'ruff', env, root, True,
                               seconds=300)
    script = admission['probes']['analysis']
    shutil.copyfile(root / script, output / 'analysis-probe.py')
    statuses['analysis'] = command([python, root / script, '--repo', root,
                                    '--output', output / 'analysis'],
                                   'analysis', env, root, True, seconds=2100)
    record['status'] = 'PASS' if all(code == 0 for code in statuses.values()) else 'FAILED'
except BaseException:
    record['error'] = traceback.format_exc()
finally:
    try:
        shutil.rmtree(owned)
        record['bootstrap_owned_directory_deleted'] = not owned.exists()
    except BaseException:
        record['status'] = 'FAILED'
        record['cleanup_error'] = traceback.format_exc()
    (output / 'run-manifest.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    members = {path.relative_to(output).as_posix(): {'bytes': path.stat().st_size, 'sha256': digest(path)}
               for path in sorted(output.rglob('*')) if path.is_file()}
    (output / 'evidence-files.json').write_text(json.dumps({'schema': 'moonlight-retained-evidence-v1', 'files': members, 'self_excluded': True}, indent=2, sort_keys=True) + '\n')
    archive_path = Path('/kaggle/working/moonlight-analysis-verification-evidence.zip')
    with zipfile.ZipFile(archive_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in sorted(output.rglob('*')):
            if path.is_file():
                archive.write(path, arcname=path.relative_to(output).as_posix())
    with zipfile.ZipFile(archive_path) as archive:
        if archive.testzip() is not None:
            raise ValueError('Evidence archive CRC failure')
        for name, item in members.items():
            payload = archive.read(name)
            if len(payload) != item['bytes'] or hashlib.sha256(payload).hexdigest() != item['sha256']:
                raise ValueError('Evidence archive member mismatch: ' + name)
if record['status'] != 'PASS':
    raise SystemExit(1)
