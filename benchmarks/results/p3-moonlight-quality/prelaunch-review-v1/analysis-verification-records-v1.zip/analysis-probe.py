"""Remote-only runbook execution on synthetic pairs; never model-quality evidence."""

from __future__ import annotations

import argparse
import base64
import hashlib
import importlib.metadata
import json
import math
import os
import shutil
import subprocess
import sys
import time
import traceback
from pathlib import Path

from rich.console import Console

PROFILE = "moonlight-16b-a3b"
SCORING = "benchmarks/results/p3-stage2-v2/p3-stage2-v2-protocol.json"
SCORING_SHA = "685fa5bee528969d9b2eef423c90280d179432ba017fbebed12b687f608a8249"
RUNBOOK = "benchmarks/p3-moonlight-quality-runbook.md"
PRIMARY = ("hellaswag", "arc", "boolq", "lambada")
SECONDARY = ("gsm8k", "mbpp")
LENGTHS = (1024, 4096)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def compact(value: object) -> str:
    return json.dumps(value, sort_keys=True, ensure_ascii=False,
                      separators=(",", ":"), allow_nan=False)


def save(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n",
                    encoding="utf-8")


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def descriptor(path: Path) -> dict:
    raw = path.read_bytes()
    return {"bytes": len(raw), "sha256": digest(raw)}


def scipy_receipt() -> dict:
    distribution = importlib.metadata.distribution("scipy")
    require(distribution.version == "1.15.3", "analysis requires scipy==1.15.3")
    files = {}
    for entry in distribution.files or ():
        if entry.hash is None:
            continue
        require(entry.hash.mode == "sha256", "unexpected SciPy RECORD hash algorithm")
        path = distribution.locate_file(entry)
        raw = path.read_bytes()
        observed = base64.urlsafe_b64encode(hashlib.sha256(raw).digest()).decode().rstrip("=")
        require(observed == entry.hash.value, f"SciPy RECORD mismatch: {entry}")
        files[str(entry)] = {"bytes": len(raw), "sha256": digest(raw), "record_matches": True}
    require("scipy/stats/_continuous_distns.py" in files
            and "scipy/stats/_stats_py.py" in files, "SciPy statistics source proof missing")
    return {"version": distribution.version, "all_hashed_record_entries_match": True,
            "hashed_file_count": len(files), "files": files}


def command(argv: list[str], *, repo: Path, output: Path, name: str, seconds: int) -> dict:
    started = time.monotonic()
    with (output / (name + ".stdout.log")).open("x") as stdout, (
        output / (name + ".stderr.log")
    ).open("x") as stderr:
        process = subprocess.run(argv, cwd=repo, env=dict(os.environ), stdout=stdout,
                                 stderr=stderr, timeout=seconds, check=False)
    return {"argv": argv, "returncode": process.returncode,
            "wall_seconds": time.monotonic() - started, "deadline_seconds": seconds,
            "stdout": descriptor(output / (name + ".stdout.log")),
            "stderr": descriptor(output / (name + ".stderr.log"))}


def fixture(root: Path, *, floor: bool, protocol_sha: str, scoring_sha: str) -> dict:
    root.mkdir(parents=True, exist_ok=False)
    primary_ids = {name: [f"synthetic-{name}-{index}" for index in range(4000)]
                   for name in PRIMARY}
    secondary_ids = {name: [f"synthetic-{name}-{index}" for index in range(10)]
                     for name in SECONDARY}
    primary_count = 0
    with (root / "pairs.jsonl").open("x", encoding="utf-8") as stream:
        for endpoint in PRIMARY:
            for length in LENGTHS:
                for index, task_id in enumerate(primary_ids[endpoint]):
                    passed = index < 3200 and not (floor and endpoint == "boolq")
                    stream.write(compact({
                        "profile_id": PROFILE, "benchmark": endpoint, "length": length,
                        "seed": 23, "task_id": task_id, "baseline_pass": passed,
                        "candidate_pass": passed,
                    }) + "\n")
                    primary_count += 1
    secondary_count = 0
    with (root / "nll-pairs.jsonl").open("x", encoding="utf-8") as stream:
        for endpoint in SECONDARY:
            for length in LENGTHS:
                for index, task_id in enumerate(secondary_ids[endpoint]):
                    mean, targets = 1.0 + index / 10, index + 1
                    stream.write(compact({
                        "profile_id": PROFILE, "benchmark": endpoint, "length": length,
                        "seed": 23, "task_id": task_id, "n_targets": targets,
                        "baseline_nll_mean": mean, "candidate_nll_mean": mean + 0.125,
                        "baseline_nll_sum": mean * targets,
                        "candidate_nll_sum": (mean + 0.125) * targets,
                        "nll_mean_difference": 0.125,
                    }) + "\n")
                    secondary_count += 1
    manifest = {
        "status": "COMPLETE", "profile_id": PROFILE, "fixture_only": True,
        "quality_evaluated": False, "include_base_model_evaluation": False,
        "seeds": [23], "lengths": list(LENGTHS), "protocol_sha256": protocol_sha,
        "scoring_protocol": {"sha256": scoring_sha}, "expected_tasks": primary_ids,
        "expected_secondary_tasks": secondary_ids, "primary_rows": primary_count,
        "secondary_rows": secondary_count,
        "files": {name: descriptor(root / name) for name in ("pairs.jsonl", "nll-pairs.jsonl")},
    }
    manifest["manifest_payload_sha256"] = digest(compact(manifest).encode())
    save(root / "manifest.json", manifest)
    return manifest


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    report = {"schema": "p3-moonlight-analysis-api-smoke-v1", "status": "FAIL",
              "scope": "Synthetic runbook/statistics API execution only; not model outcomes",
              "quality_evaluated": False, "base_model_evaluated": False, "commands": []}
    try:
        receipt = scipy_receipt()
        save(args.output / "scipy-record.json", receipt)
        report["scipy_record"] = descriptor(args.output / "scipy-record.json")
        report["packages"] = {name: importlib.metadata.version(name)
                              for name in ("scipy", "numpy", "rich", "pytest")}
        runbook = (args.repo / RUNBOOK).read_text(encoding="utf-8")
        marker = 'python - "$EVIDENCE/paired" "$SCORING_PROTOCOL" "$PROTOCOL_SHA256" <<\'PY\'\n'
        require(runbook.count(marker) == 1, "summary command absent/ambiguous in runbook")
        snippet, separator, _ = runbook.split(marker, 1)[1].partition("\nPY\n")
        require(bool(separator), "runbook summary heredoc is incomplete")
        script = args.output / "executed-summary.py"
        script.write_text(snippet + "\n", encoding="utf-8")
        report["runbook"] = descriptor(args.repo / RUNBOOK)
        report["executed_summary"] = descriptor(script)
        scoring_path = args.repo / SCORING
        require(digest(scoring_path.read_bytes()) == SCORING_SHA, "frozen scoring bytes differ")
        synthetic_protocol = args.output / "synthetic-fixture-protocol.json"
        save(synthetic_protocol, {"fixture_only": True, "quality_evaluated": False,
                                  "purpose": "Statistics API smoke, never study admission"})
        protocol_sha = digest(synthetic_protocol.read_bytes())
        report["cases"] = []
        for name, floor in (("informative", False), ("uninformative", True)):
            paired = args.output / ("synthetic-" + name) / "paired"
            fixture(paired, floor=floor, protocol_sha=protocol_sha, scoring_sha=SCORING_SHA)
            observation = command(
                [sys.executable, "-B", str(script), str(paired), str(scoring_path), protocol_sha],
                repo=args.repo, output=args.output, name=name, seconds=300)
            report["commands"].append(observation)
            require(observation["returncode"] == 0, f"runbook summary failed: {name}")
            summary_path = paired.parent / "quality-summary.json"
            summary = json.loads(summary_path.read_bytes())
            expected = "INCONCLUSIVE_UNINFORMATIVE_FLOOR" if floor else "NONINFERIOR"
            require(summary["gated_quality_decision"] == expected
                    and summary["statistical_quality_decision"] == "NONINFERIOR",
                    "v2 gated/statistical decision separation differs")
            require(summary["quality"]["coverage"]["complete"] is True,
                    "synthetic complete primary coverage was lost")
            require(summary["include_base_model_evaluation"] is False
                    and summary["pair_manifest_sha256"] == digest(
                        (paired / "manifest.json").read_bytes()), "summary input identity differs")
            require({(cell["benchmark"], cell["length"], cell["seed"])
                     for cell in summary["secondary_nll"]}
                    == {(endpoint, length, 23) for endpoint in SECONDARY for length in LENGTHS},
                    "secondary cell coverage differs")
            require(all(cell["status"] == "COMPLETE"
                        and math.isclose(cell["mean_difference"], 0.125, abs_tol=1e-12)
                        for cell in summary["secondary_nll"]), "secondary NLL direction differs")
            report["cases"].append({"fixture_only": True, "name": name, "status": "PASS",
                                    "gated_api_output": expected,
                                    "statistical_api_output": "NONINFERIOR",
                                    "secondary_mean_difference": 0.125,
                                    "summary": descriptor(summary_path)})
        damaged = args.output / "synthetic-hash-rejection" / "paired"
        shutil.copytree(args.output / "synthetic-informative" / "paired", damaged)
        rows_path = damaged / "nll-pairs.jsonl"
        original = rows_path.read_bytes()
        # The summary ignores this redundant field; only byte admission should reject it.
        changed = original.replace(b'"nll_mean_difference":0.125',
                                   b'"nll_mean_difference":0.225', 1)
        require(changed != original and len(changed) == len(original),
                "hash-tamper fixture did not change same-length bytes")
        rows_path.write_bytes(changed)
        rejection = command(
            [sys.executable, "-B", str(script), str(damaged), str(scoring_path), protocol_sha],
            repo=args.repo, output=args.output, name="hash-rejection", seconds=300)
        report["commands"].append(rejection)
        require(rejection["returncode"] != 0
                and not (damaged.parent / "quality-summary.json").exists(),
                "changed paired bytes were accepted")
        rejection_log = (args.output / "hash-rejection.stderr.log").read_text()
        require("assert hashlib.sha256(path.read_bytes()).hexdigest() == descriptor['sha256']"
                in rejection_log and "AssertionError" in rejection_log,
                "tamper refusal did not come from the file SHA256 guard")
        report["same_length_hash_tamper_refused"] = True
        tests = command(
            [sys.executable, "-B", "-m", "pytest", "tests/test_p3_stage2_statistics.py",
             "tests/test_p3_stage2v2_decision.py", "tests/test_p3_stage2v2_results.py",
             "-v", "--tb=short", "-rA", "-o", "addopts=",
             "--junitxml=" + str(args.output / "statistics-tests.xml")],
            repo=args.repo, output=args.output, name="statistics-tests", seconds=1800)
        report["commands"].append(tests)
        require(tests["returncode"] == 0, "existing v2 statistics tests failed")
        report["status"] = "PASS"
    except BaseException:
        report["error"] = traceback.format_exc()
    finally:
        report["wall_seconds"] = time.monotonic() - started
        save(args.output / "report.json", report)
        Console().print({"analysis_api_smoke": report["status"], "quality_evaluated": False})
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
