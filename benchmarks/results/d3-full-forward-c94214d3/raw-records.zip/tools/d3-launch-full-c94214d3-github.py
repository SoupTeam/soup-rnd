"""Transfer verification and one prospective launch from the user's real commit."""
import json
from pathlib import Path
import subprocess
import sys
import time

HEAD='c94214d397ffbe609916221e43fb2efd8c43ad4d'
ROOT=Path('/workspace/d3-full-committed-c94214d3')
OUT=Path('/workspace/d3-full-forward-c94214d3')
PREPARED=Path('/workspace/d3-full-prepared')
LAUNCH=Path('/workspace/d3-full-launch-c94214d3')
LIB=Path('/venv/main/lib/python3.12/site-packages/nvidia/cu13/lib/libcublas.so.13')
if not (ROOT/'.git').is_dir() or OUT.exists() or LAUNCH.exists():
    raise RuntimeError('require fresh actual GitHub clone and no previous session')
def git(*args):return subprocess.check_output(['git','-C',str(ROOT),*args],text=True).strip()
assert git('rev-parse','HEAD')==HEAD
assert git('status','--porcelain','--untracked-files=normal')==''
sys.path[:0]=[str(ROOT/'benchmarks/harness'),str(ROOT/'src')]
import d3_full_model_gate as gate
rule=json.loads((ROOT/'benchmarks/protocols/d3-full-model/protocol.json').read_bytes())
source=gate.frozen(rule)
assert source['git_head']==HEAD
if (PREPARED/f'full-model-attempt-{HEAD}.json').exists():
    raise RuntimeError('attempt already reserved; never retry')
if subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,process_name',
                            '--format=csv,noheader'],text=True).strip():
    raise RuntimeError('visible GPU peers before launch')
LAUNCH.mkdir()
cmd=[sys.executable,str(ROOT/'benchmarks/harness/d3_full_model_gate.py'),'run',
     '--prepared',str(PREPARED),'--library',str(LIB),'--out',str(OUT)]
record={'status':'launch_prechecked','actual_source':source,'command':cmd,
        'prepared':str(PREPARED),'output':str(OUT),'started_unix_s':time.time(),
        'attempts':1,'replacements':0,'formal_scope':'trained whole-model forward only'}
(LAUNCH/'launch.json').write_text(json.dumps(record,indent=2)+'\n')
p=Path('/etc/supervisor/conf.d/d3-full-c94214d3.conf')
if p.exists():raise RuntimeError('refuse duplicate supervisor registration')
p.write_text(f'''[program:d3-full-c94214d3]
command={' '.join(cmd)}
directory={ROOT}
environment=PYTHONPATH="{ROOT}/src"
autostart=false
autorestart=false
startsecs=0
startretries=0
stopasgroup=true
killasgroup=true
redirect_stderr=true
stdout_logfile={LAUNCH}/process.log
stdout_logfile_maxbytes=0
''')
subprocess.run(['supervisorctl','reread'],check=True)
subprocess.run(['supervisorctl','update'],check=True)
subprocess.run(['supervisorctl','start','d3-full-c94214d3'],check=True)
subprocess.run(['supervisorctl','status','d3-full-c94214d3'],check=True)
print('Launched real committed full-model gate; no automatic restarts or replacements.')

