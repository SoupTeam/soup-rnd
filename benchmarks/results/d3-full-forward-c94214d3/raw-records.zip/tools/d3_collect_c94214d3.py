"""Retain a terminal session without changing or rerunning its experiment."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

HEAD = 'c94214d397ffbe609916221e43fb2efd8c43ad4d'
ROOT = Path('/workspace/d3-full-committed-c94214d3')
SESSION = Path('/workspace/d3-full-forward-c94214d3')
LAUNCH = Path('/workspace/d3-full-launch-c94214d3')
PREPARED = Path('/workspace/d3-full-prepared')
BASE = Path('/workspace/d3-full-retained-c94214d3')


def sha(data):
    return hashlib.sha256(data).hexdigest()


session = json.loads((SESSION / 'session.json').read_bytes())
assert session['status'] != 'running', 'Do not collect during an active experiment'
assert session['source']['git_head'] == HEAD
assert not subprocess.check_output([
    'nvidia-smi', '--query-compute-apps=pid,process_name', '--format=csv,noheader',
], text=True).strip(), 'Require idle GPU after terminal status'
assert subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip() == HEAD
assert not subprocess.check_output(['git', '-C', str(ROOT), 'status', '--porcelain'], text=True).strip()
entries = {}
for path in sorted(SESSION.rglob('*')):
    if path.is_file():
        entries['session/' + path.relative_to(SESSION).as_posix()] = path.read_bytes()
for path in sorted(LAUNCH.rglob('*')):
    if path.is_file():
        entries['launch/' + path.relative_to(LAUNCH).as_posix()] = path.read_bytes()
for name in session['source']['git_blob_sha256']:
    data = subprocess.check_output(['git', '-C', str(ROOT), 'show', HEAD + ':' + name])
    assert sha(data) == session['source']['git_blob_sha256'][name], name
    entries['source/' + name] = data
for name in ('mapping.json', 'controls.json', 'full-model-attempt-' + HEAD + '.json'):
    entries['prepared/' + name] = (PREPARED / name).read_bytes()
for codec in ('dense', 'nf4', 'nf4-dq'):
    for name in ('bundle.json', 'config.json'):
        entries['prepared/' + codec + '/' + name] = (PREPARED / codec / name).read_bytes()
for name in ('d3_verify_full_c94214d3.py', 'd3_collect_c94214d3.py', 'd3-launch-full-c94214d3-github.py'):
    entries['tools/' + name] = (Path('/workspace') / name).read_bytes()
audit_path = Path('/workspace/d3-full-audit-c94214d3.json')
if audit_path.exists():
    entries['audit.json'] = audit_path.read_bytes()
entries['supervisor.conf'] = Path('/etc/supervisor/conf.d/d3-full-c94214d3.conf').read_bytes()
manifest = {name: sha(data) for name, data in entries.items()}
full = BASE.with_suffix('.zip')
with zipfile.ZipFile(full, 'x', zipfile.ZIP_DEFLATED) as z:
    for name, data in sorted(entries.items()):
        z.writestr(name, data)
    z.writestr('SHA256SUMS.json', json.dumps(manifest, indent=2) + '\n')
receipt = {'status': session['status'], 'git_head': HEAD, 'entries': len(entries),
           'complete_raw_archive': {'file': full.name, 'bytes': full.stat().st_size,
                                    'sha256': sha(full.read_bytes())},
           'oracle_files': {n: {'sha256': sha(b), 'bytes': len(b)} for n, b in entries.items()
                            if n.endswith('/logits.safetensors')},
           'records_archive_omits_only_native_logit_tensors': True}
records = BASE.with_name(BASE.name + '-records').with_suffix('.zip')
with zipfile.ZipFile(records, 'x', zipfile.ZIP_DEFLATED) as z:
    record_entries = {n: b for n, b in entries.items() if not n.endswith('/logits.safetensors')}
    record_entries['complete-archive-manifest.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
    record_entries['retention-receipt.json'] = (json.dumps(receipt, indent=2) + '\n').encode()
    for name, data in sorted(record_entries.items()):
        z.writestr(name, data)
    z.writestr('SHA256SUMS.json', json.dumps({n: sha(b) for n, b in record_entries.items()}, indent=2) + '\n')
receipt['records_archive'] = {'file': records.name, 'bytes': records.stat().st_size,
                              'sha256': sha(records.read_bytes())}
for archive in (full, records):
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for name, want in json.loads(z.read('SHA256SUMS.json')).items():
            assert sha(z.read(name)) == want, name
BASE.with_suffix('.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))

