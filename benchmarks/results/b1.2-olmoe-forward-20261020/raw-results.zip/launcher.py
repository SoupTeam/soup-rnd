"""Launch the frozen 12-cell B1.2 gate once and retain every attempted cell."""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import os
import shutil
import subprocess
import sys
import time
import traceback
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from rich.console import Console

COMMIT = "99664b09ad0b3238dc0a8a790f207f140239ea31"
BASE = Path("/workspace")
ROOT = BASE / "b12-frozen-99664b09"
MODEL = BASE / "b12-olmoe-pinned"
PREPARED = BASE / "b12-prepared-99664b09.json"
SESSION = BASE / "b1.2-forward-session"
ARCHIVE = BASE / "b12-gate-results-99664b09.zip"
PROTOCOL = "benchmarks/protocols/b1.2-expert-forward/protocol.json"


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def git(*args: str) -> bytes:
    return subprocess.check_output(["git", "-C", str(ROOT), *args], stderr=subprocess.PIPE)


def write_json(path: Path, value: dict) -> None:
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
    temp.replace(path)


def validate() -> tuple[dict, dict]:
    prepared = json.loads(PREPARED.read_text(encoding="utf-8"))
    if prepared.get("status") != "prepared" or prepared["source"]["commit"] != COMMIT:
        raise RuntimeError("Preparation receipt differs from the frozen source")
    if git("rev-parse", "HEAD").decode().strip() != COMMIT:
        raise RuntimeError("Checkout is not at the frozen commit")
    if git("status", "--porcelain", "--untracked-files=normal").strip():
        raise RuntimeError("Frozen checkout has local changes")
    for name, expected in prepared["source"]["git_blob_sha256"].items():
        if hashlib.sha256(git("show", f"HEAD:{name}")).hexdigest() != expected:
            raise RuntimeError(f"Source hash differs: {name}")
    rule = json.loads((ROOT / PROTOCOL).read_text(encoding="utf-8"))
    if prepared["checkpoint_sha256"] != rule["checkpoint_files"]:
        raise RuntimeError("Checkpoint preparation differs from the protocol")
    for name, expected in rule["package_versions"].items():
        if importlib.metadata.version(name).split("+")[0] != expected:
            raise RuntimeError(f"Package differs from protocol: {name}")
    if rule["attempts_per_cell"] != 1 or rule["replacements"] != 0:
        raise RuntimeError("Unexpected attempt budget")
    if shutil.disk_usage(BASE).free < 64 * 2**30:
        raise RuntimeError("Less than 64 GiB free")
    return prepared, rule


def check_result(folder: Path, layer: int, cell: str, code: int) -> dict:
    path = folder / "result.json"
    if not path.is_file():
        return {"verdict": "NO_VERDICT", "reason": "child produced no result.json"}
    result = json.loads(path.read_text(encoding="utf-8"))
    if result.get("source", {}).get("commit") != COMMIT:
        raise RuntimeError("Cell reported a different source commit")
    if result.get("layer") != layer or result.get("cell") != cell:
        raise RuntimeError("Cell identity differs from its invocation")
    if code != 0 and result.get("verdict") == "PASS":
        return {"verdict": "NO_VERDICT", "exit_code": code,
                "reason": "child exit code contradicts PASS"}
    if code != 0 or result.get("verdict") != "PASS":
        return {"verdict": result.get("verdict", "NO_VERDICT"), "exit_code": code}
    checks = ("equal", "negative_differs", "finite", "loads_ok", "budget_ok")
    if not all(result.get("result", {}).get(key) is True for key in checks):
        raise RuntimeError("PASS is missing required acceptance checks")
    return {"verdict": "PASS", "exit_code": 0}


def package() -> None:
    paths = [p for p in sorted(SESSION.rglob("*")) if p.is_file()
             and p.suffix in (".json", ".log", ".py", ".zip")]
    manifest = {}
    with zipfile.ZipFile(ARCHIVE, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in paths:
            name = path.relative_to(SESSION).as_posix()
            data = path.read_bytes()
            manifest[name] = hashlib.sha256(data).hexdigest()
            archive.writestr(name, data)
        archive.writestr("SHA256SUMS.json", json.dumps(manifest, indent=2) + "\n")
    with zipfile.ZipFile(ARCHIVE) as archive:
        if archive.testzip() is not None:
            raise RuntimeError("Result archive CRC failed")


def worker() -> int:
    console = Console(force_terminal=False)
    state = {"kind": "B1.2 frozen trained-layer correctness gate", "commit": COMMIT,
             "started_utc": now(), "status": "running", "cells": [],
             "attempts_per_cell": 1, "replacements": 0,
             "archive_scope": "Reports, logs and source; reconstructed expert weight files "
                              "remain on server and are identified by hashes in cell results"}
    try:
        _, rule = validate()
        env = dict(os.environ, CUDA_VISIBLE_DEVICES="0", HF_HUB_OFFLINE="1",
                   TRANSFORMERS_OFFLINE="1", PYTHONDONTWRITEBYTECODE="1")
        env["PYTHONPATH"] = str(ROOT / "src") + os.pathsep + str(ROOT)
        plan = [(layer, cell) for layer in rule["layers"] for cell in rule["cells"]]
        for number, (layer, cell) in enumerate(plan, 1):
            folder = SESSION / f"layer-{layer:02d}-{cell}"
            if folder.exists():
                raise RuntimeError(f"Existing attempt must not be rerun: {folder}")
            command = [sys.executable, str(ROOT / "benchmarks/harness/b1_expert_forward_gate.py"),
                       "--model-dir", str(MODEL), "--session", str(SESSION),
                       "--layer", str(layer), "--cell", cell, "--power-source", "server"]
            row = {"number": number, "layer": layer, "cell": cell,
                   "started_utc": now(), "command": command}
            state["cells"].append(row)
            console.print(f"Starting {number}/{len(plan)}: layer {layer}, {cell}")
            log = SESSION / f"cell-{number:02d}-{cell}-layer-{layer:02d}.log"
            with log.open("w", encoding="utf-8") as output:
                child = subprocess.Popen(command, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                         stdout=output, stderr=subprocess.STDOUT)
                row["pid"] = child.pid
                write_json(SESSION / "series.json", state)
                started = time.monotonic()
                while True:
                    try:
                        code = child.wait(timeout=30)
                        break
                    except subprocess.TimeoutExpired:
                        console.print(f"Cell {number}/{len(plan)} active "
                                      f"{int(time.monotonic() - started)} s")
            row.update(check_result(folder, layer, cell, code))
            row["finished_utc"] = now()
            row["log"] = log.name
            console.print(f"{row['verdict']}: layer {layer}, {cell}")
            write_json(SESSION / "series.json", state)
            if code != 0 or row["verdict"] != "PASS":
                state["status"] = "stopped_for_review"
                break
        else:
            state["status"] = "all_12_cells_passed" if len(plan) == 12 else "unexpected_plan"
    except (Exception, KeyboardInterrupt) as exc:  # noqa: BLE001 - retain failed gate evidence
        state["status"] = "stopped_for_review"
        state["exception"] = {"type": type(exc).__name__, "message": str(exc)}
        state["traceback"] = traceback.format_exc()
    finally:
        state["finished_utc"] = now()
        write_json(SESSION / "series.json", state)
        console.print(f"Status: {state['status']}")
        package()
        console.print(f"Download: {ARCHIVE}")
    return 0 if state["status"] == "all_12_cells_passed" else 1


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--worker", action="store_true")
    args = parser.parse_args()
    if args.worker:
        # Only the launch path may create this one-shot worker marker.
        with (SESSION / "worker-started.json").open("x", encoding="utf-8") as marker:
            json.dump({"pid": os.getpid(), "started_utc": now()}, marker)
        return worker()
    _, rule = validate()
    if ARCHIVE.exists():
        raise RuntimeError("An archive already exists; inspect it instead of rerunning")
    SESSION.mkdir(exist_ok=False)
    shutil.copyfile(PREPARED, SESSION / PREPARED.name)
    shutil.copyfile(ROOT / PROTOCOL, SESSION / "protocol.json")
    shutil.copyfile(Path(__file__).resolve(), SESSION / "launcher.py")
    source_zip = SESSION / "source.zip"
    subprocess.run(["git", "-C", str(ROOT), "archive", "--format=zip", "-o", str(source_zip),
                    COMMIT, "src/soup_cli", "pyproject.toml", "tests/conftest.py",
                    "tests/__init__.py", "tests/test_b1_expert_shard.py",
                    "tests/test_b1_expert_forward.py", "tests/test_b1_expert_forward_gate.py",
                    "benchmarks/harness/b1_expert_forward_gate.py", PROTOCOL], check=True)
    write_json(SESSION / "launch.json", {"commit": COMMIT, "started_utc": now(),
               "planned_cells": len(rule["layers"]) * len(rule["cells"]),
               "launcher_sha256": hashlib.sha256((SESSION / "launcher.py").read_bytes()).hexdigest(),
               "source_zip_sha256": hashlib.sha256(source_zip.read_bytes()).hexdigest()})
    with (SESSION / "launcher.log").open("w", encoding="utf-8") as log:
        child = subprocess.Popen([sys.executable, "-u", str(SESSION / "launcher.py"), "--worker"],
                                 cwd=BASE, stdin=subprocess.DEVNULL, stdout=log,
                                 stderr=subprocess.STDOUT, start_new_session=True)
    console = Console()
    console.print(f"Started in background. PID: {child.pid}")
    console.print(f"Progress: {SESSION / 'launcher.log'}")
    console.print(f"Result archive after completion or failure: {ARCHIVE}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
