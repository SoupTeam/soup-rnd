Raw F2 records. Source: e6829f159c24e29a7496f4516bd19a94d0ca8f80
All phases and failed attempts are retained. Only f2-campaign-telemetry-fixed enters the NF4 table. Tensor blobs are omitted; full local packet SHA-256 values are in artifact-manifest.json. Public model metadata is in model-metadata.tar.gz.
Extract records, then run reproduce/audit_collected.py on phases/f2-campaign-telemetry-fixed with --harness pointing to the measured checkout benchmarks/harness. Use the source bundle with its base ca9be3cc.
