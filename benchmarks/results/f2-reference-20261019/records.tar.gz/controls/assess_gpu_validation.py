"""Reproduce inherited CUDA characterization assumptions without hiding failures."""
import hashlib
import json
import os
import re
import subprocess
import time
from pathlib import Path

from rich.console import Console

repo = Path('/workspace/f2-repo')
baseline = Path('/tmp/f2-acceptance-home/baseline-a03')
python = '/workspace/f2-venv/bin/python'
expected = {
    'tests/test_issue901_pinned_arenas.py::TestPinnedStoreLivesInArenas::test_the_host_allocator_is_charged_exactly_the_arena_sizes',
    'tests/test_issue901_failed_page_lock_recovery.py::TestOnRealHardware::test_a_failed_page_lock_poisons_the_next_launch_and_only_the_next',
    'tests/test_issue901_failed_page_lock_recovery.py::TestOnRealHardware::test_the_drain_makes_the_first_launch_after_a_failed_page_lock_succeed',
    'tests/test_issue901_failed_page_lock_recovery.py::TestOnRealHardware::test_the_recovery_returns_the_failed_attempts_cached_pinned_blocks',
}
status_path = Path('/workspace/f2-gpu-focused-e6829f15-status.json')
status = json.loads(status_path.read_text())
log_path = Path('/workspace/f2-gpu-focused-e6829f15.log')
log = log_path.read_text()
assert status['exit_code'] == 1 and status['tracked_changes_after_suite'] == ''
assert set(re.findall(r'^FAILED (tests/\S+)', log, re.MULTILINE)) == expected
assert not subprocess.check_output(['git', '-C', str(repo), 'diff', '--name-only',
    'a03be3b3229ff25f640c6f6d9c37145111857de5', status['source_commit'], '--',
    'src/soup_cli', 'tests/test_issue901_pinned_arenas.py',
    'tests/test_issue901_failed_page_lock_recovery.py'], text=True)
env = dict(os.environ, CUDA_VISIBLE_DEVICES='GPU-b1248e58-f621-afa5-d5f4-b27c16d75b40',
           OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', PYTHONPATH=str(baseline / 'src'))
baseline_log = Path('/workspace/f2-baseline-four-cuda-failures.log')
with baseline_log.open('xb') as stream:
    result = subprocess.run([python, '-m', 'pytest', '--no-cov', '-v', '--tb=short',
                             *sorted(expected)], cwd=baseline, env=env,
                            stdout=stream, stderr=subprocess.STDOUT)
assert result.returncode == 1
assert set(re.findall(r'^FAILED (tests/\S+)', baseline_log.read_text(), re.MULTILINE)) == expected
for signature in ("KeyError: 'active_bytes.current'", 'DID NOT RAISE',
                  'assert False is True', 'assert (0 - 0) == 131072'):
    assert signature in log and signature in baseline_log.read_text()
passed = [line.split(' PASSED ')[0] for line in log.splitlines() if ' PASSED ' in line
          and line.startswith('tests/')]
assert len(passed) == 166
assert sum(line.startswith(('tests/test_f2_reference.py::',
                           'tests/test_f2_trace_process_races.py::')) for line in passed) == 35
assert any('test_a_store_spanning_several_arenas_is_still_bit_identical_and_pinned'
           in line for line in passed)
assert any('test_the_pageable_fallback_leaves_a_usable_context' in line for line in passed)
record = {'unix_s': time.time(), 'source_commit': status['source_commit'],
    'gpu_status_sha256': hashlib.sha256(status_path.read_bytes()).hexdigest(),
    'gpu_log_sha256': hashlib.sha256(log_path.read_bytes()).hexdigest(),
    'baseline_log_sha256': hashlib.sha256(baseline_log.read_bytes()).hexdigest(),
    'cuda_suite_green': False, 'baseline_reproduced': True,
    'failures': sorted(expected), 'unexpected_failures': [], 'passed': len(passed),
    'passed_tests': passed,
    'context': 'Unchanged source and tests at baseline reproduce the same four failures '
        'on the same GPU stack. Two characterization tests require a stale CUDA error '
        'that this stack clears; two assume active_bytes.current in host allocator stats. '
        'Real pinned multi-arena identity and recovery/fallback functional tests pass. '
        'No source, runtime, F1 or per-measurement acceptance criteria changed.'}
Path('/workspace/f2-gpu-validation-context.json').write_text(json.dumps(record, indent=2))
Console().print({key: value for key, value in record.items() if key != 'passed_tests'})
