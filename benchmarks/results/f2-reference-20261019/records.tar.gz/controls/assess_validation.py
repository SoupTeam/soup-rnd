"""Retain complete-suite failures; admit F2 only with verified baseline context."""
import hashlib
import json
import re
import subprocess
import time
from pathlib import Path

from rich.console import Console

root = Path('/workspace/f2-repo')
source = 'e6829f159c24e29a7496f4516bd19a94d0ca8f80'
baseline = 'a03be3b3229ff25f640c6f6d9c37145111857de5'
status_path = Path('/workspace/f2-acceptance-server-e6829f15-cpu-v4-status.json')
status = json.loads(status_path.read_text())
assert status['state'] == 'COMPLETED' and status['exit_code'] in (0, 1)
assert status['source_commit'] == source and not status['tracked_changes_after_suite']
log_path = Path('/workspace/f2-acceptance-server-e6829f15-cpu-v4.log')
text = log_path.read_text()
assert 'Required test coverage of 77% reached.' in text
assert 'stopping after' not in text
failures = set(re.findall(r'^FAILED (tests/\S+)', text, re.MULTILINE))
expected = {
    'tests/test_issue580_autodistill_mlx_worker.py::test_worker_verification_survives_a_real_venv_launcher',
    'tests/test_issue837_fast_lora_mlp.py::test_bf16_mlp_stays_within_twice_pefts_error_against_float64[4]',
}
if status['exit_code'] == 1:
    assert failures == expected, failures
    baseline_log = Path('/workspace/f2-baseline-two-failures.log').read_text()
    assert set(re.findall(r'^FAILED (tests/\S+)', baseline_log, re.MULTILINE)) == expected
    for fragment in ("No module named 'pydantic'", 'twice_pefts_error_against_float64'):
        assert fragment in text and fragment in baseline_log
    # Neither implementation nor either regression was changed by the F2
    # telemetry repair. The unrelated CPU/MLX failures remain visible.
    unchanged = subprocess.check_output(['git', '-C', str(root), 'diff', '--name-only',
        baseline, source, '--', 'src/soup_cli', 'tests/test_issue580_autodistill_mlx_worker.py',
        'tests/test_issue837_fast_lora_mlp.py'], text=True)
    assert not unchanged
else:
    assert not failures

f2_rows = [line for line in text.splitlines() if line.startswith((
    'tests/test_f2_reference.py::', 'tests/test_f2_trace_process_races.py::'))]
assert len(f2_rows) == 35 and all(' PASSED ' in line for line in f2_rows)
record = {'unix_s': time.time(), 'source_commit': source, 'baseline_commit': baseline,
    'full_cpu_exit_code': status['exit_code'], 'full_suite_green': not failures,
    'full_cpu_status_sha256': hashlib.sha256(status_path.read_bytes()).hexdigest(),
    'full_cpu_log_sha256': hashlib.sha256(log_path.read_bytes()).hexdigest(),
    'failures': sorted(failures), 'unexpected_failures': [],
    'baseline_reproduced': bool(failures), 'f2_scoped_tests_passed_in_full_suite': len(f2_rows),
    'measurement_scope': 'Transformers NF4 streaming, q/v LoRA; no MLX worker or MLP adapter claim',
    'acceptance_context': 'F2-specific and actual CUDA checks are required separately. '
        'The full suite is NOT called green when inherited failures remain. '
        'F1 and measurement acceptance thresholds are unchanged.',
    'protocol_context_recorded_before_new_measurements': True}
Path('/workspace/f2-validation-context.json').write_text(json.dumps(record, indent=2))
Console().print(record)
