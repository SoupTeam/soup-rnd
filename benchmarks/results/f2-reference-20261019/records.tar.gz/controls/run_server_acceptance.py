"""Full acceptance on the rental before any timing campaign is active."""
import json
import os
import subprocess
import time
import uuid
from pathlib import Path

root = Path('/tmp/f2-acceptance-home/repo')
git = ['/workspace/f2-test-tools/bin/git', '-c', 'safe.directory=' + str(root), '-C', str(root)]
source = subprocess.check_output([*git, 'rev-parse', 'HEAD'], text=True).strip()
assert source == 'e6829f159c24e29a7496f4516bd19a94d0ca8f80'
assert not subprocess.check_output([*git, 'status', '--porcelain',
                                   '--untracked-files=no'], text=True).strip()
log = Path('/workspace/f2-acceptance-server-e6829f15-cpu-v4.log')
status = Path('/workspace/f2-acceptance-server-e6829f15-cpu-v4-status.json')
command = ['runuser', '-u', 'nobody', '--', 'env', 'HOME=/tmp/f2-acceptance-home',
           'PATH=/workspace/f2-cpu-test-venv/bin:/workspace/f2-test-tools/bin:/usr/local/nvidia/bin:/usr/local/cuda/bin:/usr/local/bin:/usr/bin:/bin',
           'OMP_NUM_THREADS=1', 'MKL_NUM_THREADS=1',
           'TOKENIZERS_PARALLELISM=false', '/workspace/f2-cpu-test-venv/bin/python', '-m',
           'pytest', 'tests/', '-v', '--tb=short',
           '--basetemp', '/tmp/f2-acceptance-home/pytest-' + uuid.uuid4().hex, '--maxfail=5']
env = dict(os.environ, OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', TOKENIZERS_PARALLELISM='false',
           CUDA_VISIBLE_DEVICES='GPU-b1248e58-f621-afa5-d5f4-b27c16d75b40')
started = time.time()
status.write_text(json.dumps({'source_commit': source, 'argv': command,
    'role': 'Full CPU suite in same-commit nonroot clone, separate from GPU timing runtime',
    'started_unix_s': started, 'state': 'RUNNING'}))
with log.open('xb') as stream:
    result = subprocess.run(command, cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT)
status.write_text(json.dumps({'source_commit': source, 'argv': command,
    'started_unix_s': started, 'ended_unix_s': time.time(), 'exit_code': result.returncode,
    'state': 'COMPLETED', 'log': str(log),
    'role': 'Full CPU suite in same-commit nonroot clone, separate from GPU timing runtime',
    'tracked_changes_after_suite': subprocess.check_output([*git, 'status',
        '--porcelain', '--untracked-files=no'], text=True)}))
raise SystemExit(result.returncode)
