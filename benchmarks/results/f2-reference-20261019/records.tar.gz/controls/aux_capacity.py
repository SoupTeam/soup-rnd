"""Separate, preregistered BF16 real-capacity check, after the NF4 campaign."""
import argparse
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, '/workspace/f2-repo/benchmarks/harness')
import f2_reference as f2
from arm_validity import disk_reads

BASE = Path('/workspace/f2-repo')
MAIN = BASE / 'out/f2-campaign-telemetry-fixed'
ROOT = BASE / 'out/f2-aux-capacity'
CACHE = BASE / 'out/f2-layer-cache-bf16'
PROTOCOL = Path('/workspace/aux_capacity_protocol.json')
GPU = 'GPU-b1248e58-f621-afa5-d5f4-b27c16d75b40'
DEADLINE = 1792466114


def idle():
    peers = subprocess.check_output(['nvidia-smi', '--id=' + GPU,
        '--query-compute-apps=pid', '--format=csv,noheader,nounits'], text=True).strip()
    if peers:
        raise RuntimeError('GPU compute peers present; leave them untouched')


def memory():
    import psutil
    result = {'unix_s': time.time(), 'physical': psutil.virtual_memory()._asdict()}
    for field in ('memory.max', 'memory.current', 'memory.peak', 'memory.events'):
        path = Path('/sys/fs/cgroup') / field
        result[field] = path.read_text() if path.exists() else None
    return result


def main_finished():
    records = list(MAIN.glob('runs/*/result.json'))
    assert len(records) == 150, 'Primary cohort is incomplete'
    rows = [f2.read_json(path) for path in records]
    for mode in ('ram', 'nvme'):
        for length in f2.LENGTHS:
            assert sum(r['cell'] == f'{mode}-{length}' and r['kind'] == 'bench'
                       and r['status'] == 'PASS' for r in rows) >= 5
    assert not any(r['status'] == 'FAIL' for r in rows)
    idle()


def stage(cost_bound):
    main_finished()
    assert time.time() + 3000 < DEADLINE, 'Insufficient reserved time'
    assert cost_bound <= 3.60, 'Conservative shared-cost gate exceeded'
    assert shutil.disk_usage(BASE).free >= 45_000_000_000, 'Scratch headroom gate'
    f2.prepare(ROOT, Path('/workspace/qwen14b'), CACHE)
    proof = {'unix_s': time.time(), 'main_completed_commands': 150,
        'main_plan_sha256': f2.digest(MAIN / 'plan.json'),
        'protocol_sha256': f2.digest(PROTOCOL), 'controller_sha256': f2.digest(Path(__file__)),
        'source_commit': f2.git('rev-parse', 'HEAD'), 'before': memory(),
        'conservative_cost_bound_with_transfer_reserve_usd': cost_bound,
        'free_disk_bytes': shutil.disk_usage(BASE).free,
        'separate_from_primary_nf4': True}
    assert proof['source_commit'] == 'e6829f159c24e29a7496f4516bd19a94d0ca8f80'
    assert proof['protocol_sha256'] == 'a1d0cd01f232781317fedad74d72931143ac073ae882fafb88be702d6a415f5a'
    f2.write_json(ROOT / 'stage-start.json', proof)
    from soup_cli.utils.layer_shard import resolve_shard_dir, shard_checkpoint
    shard_dir = resolve_shard_dir('/workspace/qwen14b', cache_dir=str(CACHE))
    began = time.time()
    shard_checkpoint('/workspace/qwen14b', shard_dir, dtype='bfloat16', arch='qwen2',
                     quant='none', notify=f2.console.print)
    proof.update(stage_finished_unix_s=time.time(), stage_seconds=time.time()-began,
                 cache_bytes=sum(p.stat().st_size for p in CACHE.rglob('*') if p.is_file()),
                 after=memory(), free_disk_after_bytes=shutil.disk_usage(BASE).free)
    assert proof['free_disk_after_bytes'] >= 15_000_000_000
    f2.write_json(ROOT / 'stage-complete.json', proof)


def mapping():
    main_finished()
    assert (ROOT / 'stage-complete.json').exists()
    destination = ROOT / 'mapping'
    destination.mkdir(exist_ok=False)
    devices = sorted(p.name for p in Path('/sys/block').glob('nvme*n*'))
    records = []
    for path in sorted(CACHE.rglob('*.safetensors')):
        before = {d: disk_reads(d) for d in devices}
        command = ['dd', f'if={path}', 'of=/dev/null', 'bs=4M', 'iflag=direct', 'status=none']
        began = time.time()
        result = subprocess.run(command, text=True, capture_output=True)
        after = {d: disk_reads(d) for d in devices}
        records.append({'path': str(path), 'bytes': path.stat().st_size, 'unix_s': began,
            'argv': command, 'returncode': result.returncode, 'stderr': result.stderr,
            'before': before, 'after': after,
            'delta_bytes': {d: after[d]-before[d] for d in devices}})
        f2.write_json(destination / 'probe-in-progress.json', {'files': records})
        assert result.returncode == 0
    assert records
    total = sum(r['bytes'] for r in records)
    deltas = {d: sum(r['delta_bytes'][d] for r in records) for d in devices}
    candidates = [d for d in devices if all(r['delta_bytes'][d] >= r['bytes']
        and sum(r['delta_bytes'][other] for other in devices if other != d) == 0
        for r in records)]
    evidence = {'unix_s': time.time(), 'files': records, 'cache_bytes': total,
        'delta_bytes': deltas, 'candidate_devices': candidates,
        'method': 'Full O_DIRECT read of every actual BF16 cache safetensors file'}
    f2.write_json(destination / 'evidence.json', evidence)
    assert len(candidates) == 1
    f2.console.print({'mapping': candidates, 'files': len(records), 'bytes': total})


def measure():
    main_finished()
    assert time.time() + 1800 < DEADLINE
    proof = f2.read_json(ROOT / 'mapping/evidence.json')
    assert len(proof['candidate_devices']) == 1
    disk = proof['candidate_devices'][0]
    assert {os.path.realpath(p) for p in CACHE.rglob('*.safetensors')} == {
        os.path.realpath(row['path']) for row in proof['files']}
    assert (ROOT / 'configs').is_dir(), 'stage must prepare the inputs first'
    for path in (ROOT / 'configs').glob('*.json'):
        if path.stem not in ('ram-128', 'nvme-128'):
            path.unlink()
            continue
        config = f2.read_json(path)
        config['training']['quantization'] = 'none'
        if path.stem == 'nvme-128':
            config['training']['stream_source'] = 'auto'
        f2.write_json(path, config)
    plan = f2.read_json(ROOT / 'plan.json')
    plan.update(matrix_approved=True, matrix_approval_reference='User delegated matrix and resumed USD5 work',
        resource_window='Separate BF16 capacity diagnostic after all 150 NF4 commands',
        window_ends_unix=DEADLINE, physical_disk=disk,
        nvme_evidence=str(ROOT / 'mapping/evidence.json'),
        f1_clean_record=str(ROOT / 'clean.json'), f1_foreign_record=str(ROOT / 'foreign.json'),
        auxiliary_only=True, command_count=4, quantization='none',
        primary_results_pooled=False, protocol_sha256=f2.digest(PROTOCOL),
        controller_sha256=f2.digest(Path(__file__)), stage_sha256=f2.digest(ROOT / 'stage-complete.json'))
    f2.write_json(ROOT / 'plan.json', plan)
    f2.freeze(ROOT)
    frozen = f2.read_json(ROOT / 'frozen.json')
    assert frozen['preflight']['gpu']['uuid'] == GPU
    os.environ['CUDA_VISIBLE_DEVICES'] = GPU
    results = []
    for index, (cell, kind) in enumerate((('ram-128', 'train'), ('ram-128', 'bench'),
                                          ('nvme-128', 'train'), ('nvme-128', 'bench')), 1):
        idle()
        f2.write_json(ROOT / f'memory-before-{index}.json', memory())
        row = f2.run_one(ROOT, cell, kind, index, GPU, deadline=DEADLINE, physical_disk=disk)
        if cell == 'ram-128':
            parent = ROOT / 'runs' / f'{index:03d}-{cell}-{kind}'
            log = ' '.join((parent / 'console.log').read_text().split())
            capacity_message = ("training.stream_source='ram'" in log
                and 'GB of RAM is free' in log and "stream_source='auto'" in log)
            capacity_message |= 'base exceeds the physical RAM safety ceiling' in log
            expected = (row['returncode'] != 0 and capacity_message
                and not row['audit'].get('steps') and row['validity']['outcome'] == 'ok'
                and 7.5*1024**3 <= row['audit'].get('physical_vram_bytes', 0) <= 8.5*1024**3)
            classification = {'aux_status': 'EXPECTED_CAPACITY_REFUSAL' if expected else 'NO_VERDICT',
                'raw_generic_f2_status': row['status'], 'source': str(parent / 'result.json'),
                'reason': 'Real BF16 store refused against actual memory availability/safety ceiling; '
                          'this is a planner refusal, not a physical OOM or an HDD experiment'}
            f2.write_json(parent / 'capacity-classification.json', classification)
            results.append(classification)
        else:
            results.append({'aux_status': row['status'], 'cell': cell, 'kind': kind,
                            'reason': row['reason']})
    f2.write_json(ROOT / 'aux-summary.json', {'results': results, 'pooled_with_nf4': False,
        'repeat_claim': 'Functional one-pair diagnostic; no repeated performance claim'})


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase', choices=('stage', 'mapping', 'measure'))
    parser.add_argument('--cost-bound', type=float)
    args = parser.parse_args()
    if args.phase == 'stage':
        assert args.cost_bound is not None
        stage(args.cost_bound)
    elif args.phase == 'mapping':
        mapping()
    else:
        measure()
