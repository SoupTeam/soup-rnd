"""Map the exact NF4 cache files, not a checkpoint on the same overlay pathname."""
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, '/workspace/f2-repo/benchmarks/harness')
import f2_reference as f2
from arm_validity import disk_reads

out = Path('/workspace/f2-actual-cache-disk-mapping-v2')
out.mkdir(exist_ok=False)
devices = sorted(p.name for p in Path('/sys/block').glob('nvme*n*'))
files = sorted(Path('/workspace/f2-repo/out/f2-layer-cache').rglob('*.safetensors'))
assert files
records = []
for path in files:
    before = {d: disk_reads(d) for d in devices}
    command = ['dd', f'if={path}', 'of=/dev/null', 'bs=4M', 'iflag=direct', 'status=none']
    began = time.time()
    result = subprocess.run(command, text=True, capture_output=True)
    after = {d: disk_reads(d) for d in devices}
    record = {'path': str(path), 'bytes': path.stat().st_size, 'unix_s': began,
              'argv': command, 'returncode': result.returncode, 'stderr': result.stderr,
              'before': before, 'after': after,
              'delta_bytes': {d: after[d]-before[d] for d in devices}}
    records.append(record)
    f2.write_json(out / 'probe-in-progress.json', {'files': records})
    assert result.returncode == 0, record
total = sum(r['bytes'] for r in records)
deltas = {d: sum(r['delta_bytes'][d] for r in records) for d in devices}
candidates = [d for d in devices if total*.98 <= deltas[d] <= total+100_000_000
              and sum(deltas[x] for x in devices if x != d) < 100_000_000]
evidence = {'unix_s': time.time(), 'files': records, 'cache_bytes': total,
            'delta_bytes': deltas, 'candidate_devices': candidates,
            'interpretation': 'Every exact NF4 safetensors cache file was read in full '
                'with O_DIRECT while training was stopped. Checkpoint mapping is '
                'not used as a substitute for cache mapping on this multi-device host.'}
f2.write_json(out / 'evidence.json', evidence)
f2.console.print({'cache_bytes': total, 'delta_bytes': deltas, 'candidates': candidates})
assert len(candidates) == 1, 'Cache mapping is not a single verified physical device'
