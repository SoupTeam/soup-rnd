"""Fresh complete F2 cohort after server acceptance and collector repair."""
import os
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, '/workspace/f2-repo/benchmarks/harness')
import f2_reference as f2

SOURCE = 'e6829f159c24e29a7496f4516bd19a94d0ca8f80'
assert f2.git('rev-parse', 'HEAD') == SOURCE
assert not f2.git('status', '--porcelain', '--untracked-files=no')
acceptance_path = Path('/workspace/f2-acceptance-server-e6829f15-cpu-v4-status.json')
acceptance = f2.read_json(acceptance_path)
assert acceptance['state'] == 'COMPLETED' and acceptance['exit_code'] in (0, 1)
assert acceptance['source_commit'] == SOURCE and not acceptance['tracked_changes_after_suite']
validation_path = Path('/workspace/f2-validation-context.json')
validation = f2.read_json(validation_path)
assert validation['source_commit'] == SOURCE and not validation['unexpected_failures']
assert validation['full_cpu_status_sha256'] == f2.digest(acceptance_path)
assert validation['full_suite_green'] or validation['baseline_reproduced']
gpu_check_path = Path('/workspace/f2-gpu-focused-e6829f15-status.json')
gpu_check = f2.read_json(gpu_check_path)
assert gpu_check['source_commit'] == SOURCE and gpu_check['exit_code'] in (0, 1)
assert not gpu_check['tracked_changes_after_suite']
gpu_context_path = Path('/workspace/f2-gpu-validation-context.json')
gpu_context = f2.read_json(gpu_context_path)
assert gpu_context['source_commit'] == SOURCE and not gpu_context['unexpected_failures']
assert gpu_context['gpu_status_sha256'] == f2.digest(gpu_check_path)
assert gpu_context['cuda_suite_green'] or gpu_context['baseline_reproduced']
relay_path = Path('/workspace/f2-relay-readiness.json')
assert f2.read_json(relay_path)['returncode'] == 0
assert Path('/dev/shm/f2-transfer/id_ed25519').is_file()
hardware_path = Path('/workspace/f2-fixed-hardware.json')
assert f2.read_json(hardware_path)['gpu_csv'].startswith('GPU-b1248e58-f621-afa5-d5f4-b27c16d75b40,')
assert f2.read_json(Path('/workspace/f2-deadline-guard-ready-v3.json'))['deadline_unix'] == 1792466714

cache = Path('/workspace/f2-repo/out/f2-layer-cache')
mapping = Path('/workspace/f2-actual-cache-disk-mapping-v2/evidence.json')
proof = f2.read_json(mapping)
assert len(proof['candidate_devices']) == 1
disk = proof['candidate_devices'][0]
expected = {os.path.realpath(p) for p in cache.rglob('*.safetensors')}
assert expected == {os.path.realpath(row['path']) for row in proof['files']}
assert len(expected) == 51
assert all(row['returncode'] == 0 and row['delta_bytes'][disk] >= row['bytes']
           and sum(value for name, value in row['delta_bytes'].items() if name != disk) == 0
           for row in proof['files'])
clean_path = Path('/workspace/f2-fixed-clean.json')
foreign_path = Path('/workspace/f2-fixed-foreign.json')
assert f2.read_json(clean_path)['outcome'] == 'ok'
foreign = f2.read_json(foreign_path)
assert foreign['physical_disk_mapping'] == disk
assert foreign['checks']['foreign_reads']['outcome'] == 'void'

root = Path('/workspace/f2-repo/out/f2-campaign-telemetry-fixed')
f2.prepare(root, Path('/workspace/qwen14b'), cache)
plan = f2.read_json(root / 'plan.json')
plan.update(matrix_approved=True,
    matrix_approval_reference='User delegated matrix on 2026-10-19, then explicitly resumed '
                              'after second pause; shared total reserve remains USD5',
    resource_window='Vast56748309 RTX3060Ti8GiB; host about32GiB, cgroup21.1GiB; '
                    'full cache mapped by full O_DIRECT reads before this cohort',
    window_ends_unix=1792466114, physical_disk=disk, nvme_evidence=str(mapping),
    f1_clean_record=str(clean_path), f1_foreign_record=str(foreign_path),
    acceptance_record=str(acceptance_path), acceptance_sha256=f2.digest(acceptance_path),
    validation_context_record=str(validation_path), validation_context_sha256=f2.digest(validation_path),
    gpu_acceptance_record=str(gpu_check_path), gpu_acceptance_sha256=f2.digest(gpu_check_path),
    gpu_validation_context_record=str(gpu_context_path),
    gpu_validation_context_sha256=f2.digest(gpu_context_path),
    controller_sha256=f2.digest(Path(__file__)),
    post_campaign_export_sha256=f2.digest(Path('/workspace/export_evidence.py')),
    relay_readiness_sha256=f2.digest(relay_path),
    physical_hardware_sha256=f2.digest(hardware_path),
    cache_mapping={'cache_root': str(cache), 'verified_file_count': len(expected),
        'cache_safetensors_bytes': proof['cache_bytes'],
        'all_files_direct_read': True, 'file_manifest_sha256': f2.digest(mapping)},
    prior_phases_pooled=False,
    prior_sampler_pilot='/workspace/f2-repo/out/f2-campaign-cache-mapped',
    fresh_schedule='Full five ABBA blocks per length, controls, both CLI paths; 150 commands',
    telemetry_repair='Omit only known-exited children; missing root or inaccessible live '
                     'process remains unknown. F1 and counted-window requirements unchanged.',
    no_bulk_collection_or_acceptance_tests_during_campaign=True,
    cache_policy='Shipped Linux direct I/O where supported; no manual cache flush or RAM pressure',
    source_model_loss_optimizer_arithmetic_changed=False)
f2.write_json(root / 'plan.json', plan)
f2.freeze(root)
try:
    f2.run(root)
finally:
    # All timing processes have returned before any evidence/adapter reads.
    subprocess.run([sys.executable, '/workspace/export_evidence.py', '--label', 'primary-nf4'],
                   check=True)
