"""Sequential server-only validation and sensor preparation, without measurements."""
import json
import os
import subprocess
import time
from pathlib import Path

from rich.console import Console

python = '/workspace/f2-venv/bin/python'
repo = Path('/workspace/f2-repo')
status_path = Path('/workspace/f2-preparation-v2-status.json')
status = {'started_unix_s': time.time(), 'state': 'RUNNING', 'completed': []}
assert not status_path.exists()
os.environ['CUDA_VISIBLE_DEVICES'] = 'GPU-b1248e58-f621-afa5-d5f4-b27c16d75b40'


def save():
    status_path.write_text(json.dumps(status, indent=2))


def run(name, argv):
    status['active'] = name
    save()
    subprocess.run(argv, cwd=repo, check=True)
    status['completed'].append(name)
    save()


try:
    save()
    while json.loads(Path('/workspace/f2-acceptance-server-e6829f15-cpu-v4-status.json')
                     .read_text())['state'] == 'RUNNING':
        assert time.time() < 1792462514, 'Do not consume the measurement window waiting'
        time.sleep(10)
    run('full-suite assessment', [python, '/workspace/assess_validation.py'])
    run('measurement-runtime baseline comparison', [python, '/workspace/assess_gpu_validation.py'])
    run('ruff', [python, '-m', 'ruff', 'check', 'src/soup_cli/', 'tests/'])
    run('harness ruff', [python, '-m', 'ruff', 'check', 'benchmarks/harness/f2_reference.py',
                       'benchmarks/harness/f2_calibrate.py'])
    run('changelog validation only', [python, '-c',
        'from scripts.assemble_changelog import validate_fragments; '
        'from rich.console import Console; Console().print(len(validate_fragments()))'])
    run('physical hardware', [python, '/workspace/capture_fixed_hardware.py'])
    run('full actual-cache disk mapping', [python, '/workspace/probe_actual_cache_v2.py'])
    mapping = json.loads(Path('/workspace/f2-actual-cache-disk-mapping-v2/evidence.json')
                         .read_text())['candidate_devices']
    assert len(mapping) == 1
    run('clean F1 calibration', [python, 'benchmarks/harness/f2_calibrate.py', 'clean',
        '--output', '/workspace/f2-fixed-clean.json', '--model-path',
        '/workspace/f2-repo/out/f2-layer-cache', '--gpu', os.environ['CUDA_VISIBLE_DEVICES'],
        '--physical-disk', mapping[0], '--seconds', '20'])
    status['state'] = 'READY_FOR_SEPARATE_SSH_FOREIGN_CONTROL'
except BaseException as error:
    status['state'] = 'FAILED'
    status['error'] = repr(error)
    raise
finally:
    status['ended_unix_s'] = time.time()
    save()
    Console().print(status)
