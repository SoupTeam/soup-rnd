"""Archive whitelisted evidence after timing; relay to this task's stopped disk."""
import argparse
import hashlib
import json
import subprocess
import tarfile
import time
from pathlib import Path

from rich.console import Console

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--label', choices=('primary-nf4', 'final-with-capacity'), required=True)
args = parser.parse_args()
repo = Path('/workspace/f2-repo')
destination = Path('/workspace/f2-final-export')
destination.mkdir(exist_ok=True)
archive = destination / (args.label + '.tar.gz')
assert not archive.exists(), 'Keep each completed export immutable'


def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024**2), b''):
            result.update(chunk)
    return result.hexdigest()


phases = [repo / 'out' / name for name in (
    'f2-relocated-diagnostic', 'f2-campaign-relocated', 'f2-campaign-cache-mapped',
    'f2-campaign-telemetry-fixed', 'f2-aux-capacity')]
mapping_dirs = [Path('/workspace') / name for name in (
    'f2-actual-cache-disk-mapping', 'f2-actual-cache-disk-mapping-v2')]
top_files = [Path('/workspace') / name for name in (
    'f2-relocation-verification.json', 'f2-cache-mapping-stop.json', 'f2-telemetry-stop.json',
    'f2-cache-clean.json', 'f2-cache-foreign.json', 'f2-fixed-clean.json', 'f2-fixed-foreign.json',
    'f2-acceptance-server-e6829f15.log', 'f2-acceptance-server-e6829f15-status.json',
    'f2-acceptance-server-e6829f15-v2.log', 'f2-acceptance-server-e6829f15-v2-status.json',
    'f2-acceptance-server-e6829f15-cpu-v3.log', 'f2-acceptance-server-e6829f15-cpu-v3-status.json',
    'f2-acceptance-server-e6829f15-cpu-v4.log', 'f2-acceptance-server-e6829f15-cpu-v4-status.json',
    'f2-gpu-focused-e6829f15.log', 'f2-gpu-focused-e6829f15-status.json',
    'f2-gpu-validation-context.json', 'f2-baseline-four-cuda-failures.log',
    'assess_gpu_validation.py', 'f2-preparation.log', 'f2-preparation-status.json',
    'f2-preparation-v2.log', 'f2-preparation-v2-status.json', 'prepare_fixed_cohort.py',
    'f2-cpu-env-precheck.log',
    'f2-fixed-hardware.json', 'f2-cpu-validation-packages.txt',
    'f2-validation-context.json', 'f2-baseline-two-failures.log',
    'f2-cpu-two-failures-isolated.log', 'assess_validation.py',
    'f2-trace-process-race-red.log',
    'f2-trace-race-green.log', 'f2-server-basetemp-repro.log', 'f2-pause-evidence.tar.gz',
    'launch_telemetry_fixed.py', 'probe_actual_cache_v2.py', 'run_server_acceptance.py',
    'export_evidence.py', 'aux_capacity.py', 'aux_capacity_protocol.json')]
package_freeze = destination / (args.label + '-packages.txt')
package_freeze.write_bytes(subprocess.check_output(['/workspace/f2-venv/bin/python', '-m', 'pip',
                                                  'freeze']))
bundle = destination / (args.label + '-source.bundle')
subprocess.run(['git', '-C', str(repo), 'bundle', 'create', str(bundle),
    'ca9be3cc9f11b91cba76d26f8a0d7ad18787c4ff..HEAD'], check=True)

index = {'unix_s': time.time(), 'label': args.label,
    'source_commit': subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'],
                                           text=True).strip(),
    'phases': [], 'adapters': [], 'secrets_included': False}
blobs = set()
with tarfile.open(archive, 'w:gz', compresslevel=1) as output:
    for phase in phases:
        if not phase.exists():
            continue
        results = list(phase.glob('runs/*/result.json'))
        index['phases'].append({'phase': phase.name, 'completed_results': len(results)})
        for path in sorted(phase.rglob('*')):
            relative = path.relative_to(phase)
            if not path.is_file() or 'adapters' in relative.parts:
                continue
            if path.suffix in ('.json', '.jsonl', '.log', '.md', '.txt'):
                output.add(path, arcname='phases/' + phase.name + '/' + relative.as_posix())
        for path in sorted((phase / 'adapters').glob('*/adapter_model.safetensors')):
            sha = digest(path)
            config = path.with_name('adapter_config.json')
            config_sha = digest(config)
            index['adapters'].append({'phase': phase.name, 'cell': path.parent.name,
                'source_path': str(path), 'sha256': sha, 'bytes': path.stat().st_size,
                'config_sha256': config_sha})
            for blob, name in ((path, sha + '.safetensors'), (config, config_sha + '.json')):
                if name not in blobs:
                    output.add(blob, arcname='adapter-blobs/' + name)
                    blobs.add(name)
    for directory in mapping_dirs:
        for path in sorted(directory.rglob('*.json')):
            output.add(path, arcname='controls/' + directory.name + '/' +
                       path.relative_to(directory).as_posix())
    for path in top_files:
        if path.is_file():
            output.add(path, arcname='controls/' + path.name)
    output.add(package_freeze, arcname='packages.txt')
    output.add(bundle, arcname='source.bundle')
    index_path = destination / (args.label + '-index.json')
    index_path.write_text(json.dumps(index, indent=2))
    output.add(index_path, arcname='index.json')

manifest = destination / (args.label + '-sha256.json')
record = {'archive': archive.name, 'bytes': archive.stat().st_size,
          'sha256': digest(archive), 'source_commit': index['source_commit'],
          'created_unix_s': time.time(), 'relay_instance': 56717237}
manifest.write_text(json.dumps(record, indent=2))
key = Path('/dev/shm/f2-transfer/id_ed25519')
known = Path('/dev/shm/f2-transfer/known_hosts')
assert key.is_file() and known.is_file(), 'Only the ephemeral task SSH key may relay this export'
remote_shell = ('ssh -i ' + str(key) + ' -p 38080 -o UserKnownHostsFile=' + str(known) +
                ' -o StrictHostKeyChecking=yes -o BatchMode=yes -o ConnectTimeout=20')
command = ['rsync', '-rt', '--checksum', '--partial', '--timeout=90', '-e', remote_shell,
           str(archive), str(manifest),
           'vastai_kaalia@92.190.14.191::C.56717237/workspace/f2-final-export/']
with (destination / (args.label + '-relay.log')).open('wb') as log:
    result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=600)
record['relay_returncode'] = result.returncode
(destination / (args.label + '-relay-status.json')).write_text(json.dumps(record, indent=2))
if result.returncode == 0:
    key.unlink()  # Keep no private key on the measured server after successful relay.
Console().print(record)
raise SystemExit(result.returncode)
