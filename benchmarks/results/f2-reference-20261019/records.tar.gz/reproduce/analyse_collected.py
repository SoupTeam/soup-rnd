"""Descriptive F2 summaries and the unchanged F1 pilot rule; never pool machines."""
import argparse
import csv
import json
import statistics
import sys
from collections import Counter
from dataclasses import asdict
from pathlib import Path

from rich.console import Console

parser = argparse.ArgumentParser()
parser.add_argument('directory', type=Path)
parser.add_argument('--harness', type=Path, required=True)
args = parser.parse_args()
sys.path.insert(0, str(args.harness))
import f2_reference as f2
from arm_validity import Run, blocks_to_add, repeats

root = args.directory
frozen = f2.read_json(root / 'frozen.json')
records = []
for path in sorted(root.glob('runs/*/result.json')):
    row = f2.read_json(path)
    row['_id'] = path.parent.name
    row['_index'] = int(path.parent.name.split('-')[0])
    records.append(row)

cells = []
for mode in f2.MODES:
    for length in f2.LENGTHS:
        name = f'{mode}-{length}'
        selected = [r for r in records if r['cell'] == name]
        bench = [r for r in selected if r['status'] == 'PASS' and r['kind'] == 'bench']
        working = [r for r in selected if r['status'] == 'PASS']
        entry = {'cell': name,
                 'counts': dict(Counter(f"{r['kind']}:{r['status']}" for r in selected)),
                 'valid_bench_runs': len(bench), 'valid_working_commands': len(working)}
        if working:
            entry['cuda_reported_total_bytes'] = sorted({r['audit']['physical_vram_bytes'] for r in working})
            for key in ('allocated', 'reserved'):
                entry[f'peak_{key}_all_phases_bytes'] = max(
                    max(r['audit'][f'peak_{key}_bytes'],
                        r['audit'].get(f'setup_peak_{key}_bytes', 0)) for r in working)
            entry['peak_sampled_process_tree_rss_bytes'] = max(
                r['telemetry']['sampled_peak_process_tree_rss_bytes'] for r in working)
            entry['observed_total_tokens_per_step'] = sorted({
                step['total_tokens'] for r in working for step in r['audit']['steps']})
        if bench:
            times = [r['bench']['timing']['median_seconds'] for r in bench]
            rates = [r['bench']['throughput']['useful_tokens_per_second'] for r in bench]
            physical_rates = [r['telemetry']['sampled_read_bytes_delta'] /
                              max(1e-9, r['telemetry']['sampled_span_seconds']) / 1e6 for r in bench]
            entry.update(step_seconds_median=statistics.median(times),
                step_seconds_min=min(times), step_seconds_max=max(times),
                supervised_tokens_per_second_median=statistics.median(rates),
                total_tokens_per_second_median=statistics.median(
                    r['bench']['throughput']['total_tokens_per_second'] for r in bench),
                native_step_seconds=[r['bench']['timing']['step_seconds'] for r in bench],
                sampled_physical_read_MBps_median=statistics.median(physical_rates),
                sampled_physical_read_MBps_min=min(physical_rates),
                sampled_physical_read_MBps_max=max(physical_rates),
                mean_gpu_util_percent=statistics.mean(
                    r['telemetry']['mean_gpu_util_percent'] for r in bench),
                median_sm_clock_mhz=statistics.median(
                    r['telemetry']['median_sm_clock_mhz'] for r in bench),
                median_power_watts=statistics.median(
                    r['telemetry']['median_power_watts'] for r in bench),
                valid_bench_ids=[r['_id'] for r in bench])
        cells.append(entry)

by_pair = {(r['_index']-1)//2: r for r in records if r['kind'] == 'bench'}
repeat_plans = {}
for length_index, length in enumerate(f2.LENGTHS):
    valid, rejected = [], []
    for block in range(5):
        pairs = [(block * 3 + length_index) * 5 + slot for slot in range(4)]
        rows = [by_pair.get(pair) for pair in pairs]
        if any(r is None or r['status'] != 'PASS' for r in rows):
            rejected.append({'block': block+1, 'runs': [r['_id'] if r else None for r in rows],
                             'statuses': [r['status'] if r else 'NOT_RUN' for r in rows]})
            continue
        assert [r['cell'].split('-')[0] for r in rows] == ['ram', 'nvme', 'nvme', 'ram']
        valid.append([Run(r['bench']['timing']['median_seconds'], r['validity']['outcome'])
                      for r in rows])
    decision = {'valid_complete_blocks': len(valid), 'rejected_or_incomplete_blocks': rejected,
                'claim': 'Descriptive only; no 10-percent effect claim'}
    if len(valid) == 5:
        decision['unchanged_f1_repeats'] = asdict(repeats(valid))
        decision['blocks_to_add_for_10_percent_effect'] = blocks_to_add(valid)
    else:
        decision['repeat_verdict'] = 'NO_VERDICT: fewer than five wholly valid F2 pilot blocks'
    repeat_plans[str(length)] = decision

events = Counter()
clock_unknown = []
for row in records:
    record = row['validity'].get('gpu_clock', {})
    events.update(record.get('reasons_seen', {}))
    if record.get('outcome') != 'ok':
        clock_unknown.append(row['_id'])

summary = {'source_commit': frozen['commit'], 'physical_box': frozen['preflight'],
    'records': len(records), 'scheduled': 150, 'statuses': dict(Counter(r['status'] for r in records)),
    'cells': cells, 'repeat_plans': repeat_plans, 'whole_execution_clock_event_samples': dict(events),
    'unknown_clock_records': clock_unknown,
    'invalid': [{'id': r['_id'], 'status': r['status'], 'reason': r['reason'],
                 'f1': r['validity']['outcome'], 'telemetry': r['telemetry']}
                for r in records if r['status'] not in ('PASS', 'EXPECTED_REFUSAL')],
    'notes': ['All records retained, including invalid outcomes.',
              'Only PASS bench records enter descriptive throughput summaries.',
              'Clock-event samples cover whole execution; trace summaries cover counted steps.',
              'Shipped I/O defaults: Linux disk reader uses direct I/O where supported; no manual cache flush or RAM pressure.',
              'The disk tier is forced, not natural RAM overflow.',
              'Unmapped overlay foreign reads are unknown; mapping calibration is retained.',
              'CUDA available total and NVML physical board total can differ by driver reservations.']}
f2.write_json(root / 'analysis.json', summary)
with (root / 'runs.csv').open('w', newline='', encoding='utf-8') as stream:
    fields = ['id', 'cell', 'kind', 'status', 'reason', 'step_seconds', 'supervised_tok_s',
              'allocated_bytes', 'reserved_bytes', 'sampled_rss_bytes', 'read_MB_s',
              'gpu_util', 'sm_mhz', 'power_watts']
    writer = csv.DictWriter(stream, fieldnames=fields)
    writer.writeheader()
    for row in records:
        bench = row.get('bench') or {}
        telemetry = row['telemetry']
        writer.writerow(dict(id=row['_id'], cell=row['cell'], kind=row['kind'], status=row['status'],
            reason=row['reason'], step_seconds=bench.get('timing', {}).get('median_seconds'),
            supervised_tok_s=bench.get('throughput', {}).get('useful_tokens_per_second'),
            allocated_bytes=row['audit'].get('peak_allocated_bytes'),
            reserved_bytes=row['audit'].get('peak_reserved_bytes'),
            sampled_rss_bytes=telemetry.get('sampled_peak_process_tree_rss_bytes'),
            read_MB_s=(telemetry['sampled_read_bytes_delta'] /
                       telemetry['sampled_span_seconds'] / 1e6
                       if telemetry.get('sampled_span_seconds', 0) > 0 and
                       telemetry.get('sampled_read_bytes_delta') is not None else None),
            gpu_util=telemetry.get('mean_gpu_util_percent'),
            sm_mhz=telemetry.get('median_sm_clock_mhz'), power_watts=telemetry.get('median_power_watts')))
Console().print({'records': len(records), 'statuses': summary['statuses'], 'repeats': repeat_plans})
