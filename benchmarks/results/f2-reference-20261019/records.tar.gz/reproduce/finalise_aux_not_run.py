"""Preserve the failed preparation gate; do not manufacture a capacity verdict."""
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

from rich.console import Console

root = Path('/workspace/f2-repo/out/f2-aux-capacity')
assert not (root / 'frozen.json').exists() and not list(root.glob('runs/*/command.json'))
inspection = json.loads((root / 'mapping-inspection.json').read_text())
assert len(inspection['attempts']) == 2
assert all(not row['candidate_devices'] for row in inspection['attempts'])
assert json.loads((root / 'final-relay-readiness.json').read_text())['returncode'] == 0
summary = {'unix_s': time.time(), 'outcome': 'NOT_RUN', 'cli_measurement_commands': 0,
    'prepared_quantization': 'none', 'prepared_cache_bytes': 29_540_125_474,
    'reason': 'The preregistered single-device mapping gate required zero other-device '
        'reads for every complete actual-cache O_DIRECT read. Neither retained full '
        '51-file preparation attempt met it: other-device totals 4096 and 282624 bytes. '
        'The one declared preparation retry is exhausted; no capacity or automatic '
        'overflow training claim is made.',
    'protocol_sha256': hashlib.sha256(Path('/workspace/aux_capacity_protocol.json')
                                      .read_bytes()).hexdigest(),
    'thresholds_changed': False, 'f1_calibration_executed': False,
    'measurements_executed': False, 'pooled_with_nf4': False,
    'main_nf4_matrix': 'Completed 150 commands; accepted raw data retained separately'}
(root / 'aux-summary.json').write_text(json.dumps(summary, indent=2))
Console().print(summary)
subprocess.run([sys.executable, '/workspace/export_evidence.py', '--label',
                'final-with-capacity'], check=True)
