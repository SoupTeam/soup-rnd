"""One retained preparation retry; keep the exact original physical-device rule."""
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

from rich.console import Console

root = Path('/workspace/f2-repo/out/f2-aux-capacity')
mapping = root / 'mapping'
prior = root / 'mapping-attempt-1'
assert not (root / 'frozen.json').exists() and not list(root.glob('runs/*/command.json'))
assert not prior.exists()
evidence_path = mapping / 'evidence.json'
evidence = json.loads(evidence_path.read_text())
assert evidence['candidate_devices'] == []
assert evidence['delta_bytes']['nvme1n1'] == 4096
assert all(row['returncode'] == 0 and row['delta_bytes']['nvme0n1'] >= row['bytes']
           for row in evidence['files'])
assert os.path.commonpath([os.path.realpath(root), os.path.realpath(mapping)]) == str(root)
record = {'unix_s': time.time(), 'prior_evidence_sha256':
    hashlib.sha256(evidence_path.read_bytes()).hexdigest(),
    'reason': 'All actual cache files read fully on nvme0n1; a 4KiB other-device read '
        'made the first strict preparation control inconclusive.',
    'first_attempt_retained': str(prior), 'maximum_preparation_retries': 1,
    'measurement_attempts_so_far': 0,
    'criterion_unchanged': 'Every file full O_DIRECT read; each selected-device delta >= '
        'file bytes; all other devices exactly zero for every file.',
    'no_measured_arm_replaced_or_pooled': True}
(root / 'mapping-retry-decision.json').write_text(json.dumps(record, indent=2))
mapping.rename(prior)
with (root / 'mapping-retry.log').open('xb') as stream:
    result = subprocess.run([sys.executable, '/workspace/aux_capacity.py', 'mapping'],
        cwd='/workspace/f2-repo', stdout=stream, stderr=subprocess.STDOUT)
record['retry_returncode'] = result.returncode
(root / 'mapping-retry-outcome.json').write_text(json.dumps(record, indent=2))
Console().print({'mapping_preparation_retry_exit_code': result.returncode})
raise SystemExit(result.returncode)
