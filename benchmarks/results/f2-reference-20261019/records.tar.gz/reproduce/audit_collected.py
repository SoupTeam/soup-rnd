"""Cross-check original F2 files after collection; CPU only, no new measurements."""

import argparse
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

from rich.console import Console

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('directory', type=Path)
parser.add_argument('--harness', type=Path, required=True)
args = parser.parse_args()
sys.path.insert(0, str(args.harness))
import f2_reference as f2
from soup_cli.bench.train_run import config_hash

root = args.directory
frozen = f2.read_json(root / 'frozen.json')
old_root = next(path.rsplit('/', 1)[0] for path in frozen['inputs'] if path.endswith('/plan.json'))
for original, expected in frozen['inputs'].items():
    assert original.startswith(old_root + '/')
    current = root / original[len(old_root)+1:]
    assert f2.digest(current) == expected, f'frozen input differs: {current}'

counts = defaultdict(Counter)
fingerprints = defaultdict(set)
shapes = defaultdict(set)
raw_statuses = Counter()
checked = 0
for result_path in sorted(root.glob('runs/*/result.json')):
    parent = result_path.parent
    record = f2.read_json(result_path)
    audit = f2.read_json(parent / 'audit.json')
    validity = f2.read_json(parent / 'validity.json')
    command = f2.read_json(parent / 'command.json')
    log = (parent / 'console.log').read_text(encoding='utf-8')
    assert f2.digest(parent / 'console.log') == record['log_sha256']
    assert command['environment_overrides']['CUDA_VISIBLE_DEVICES'] == frozen['preflight']['gpu']['uuid']
    assert command['native_cli_argv'] == ['soup', '--verbose', *command['argv'][command['argv'].index('--')+1:]]
    bench = f2.read_json(parent / 'bench.json') if (parent / 'bench.json').exists() else None
    rows = [json.loads(line) for line in (parent / 'trace.jsonl').read_text(encoding='utf-8').splitlines()]
    telemetry = f2.trace_summary(rows, audit)
    assert telemetry == record['telemetry'], f'telemetry summary differs: {parent}'
    # CUDA's total excludes some driver/graphics reservations; NVML reports
    # physical board capacity. Both must identify the declared 8 GiB class.
    assert 7.5 * 1024**3 <= audit.get('physical_vram_bytes', 0) <= frozen['preflight']['gpu']['memory_bytes']
    mode = record['cell'].split('-')[0]
    expected_status, reason = f2.judge(dict(record, audit=audit, validity=validity,
        bench=bench, log=log, telemetry_complete=telemetry['complete'],
        tier_confirmed=f2.tier_confirmed(mode, log)), record['kind'], mode)
    assert expected_status == record['status'], (parent, expected_status, record['status'], reason)
    if bench:
        assert config_hash(bench['resolved_config']) == bench['config_hash']
        prepared = f2.read_json(root / 'configs' / f"{record['cell']}.json")
        prepared.pop('output')
        assert prepared == bench['resolved_config'], f'native config differs from freeze: {parent}'
        assert bench['tokens']['useful'] == sum(step['useful_tokens'] for step in audit['steps'][4:])
        assert bench['tokens']['total'] == sum(step['total_tokens'] for step in audit['steps'][4:])
        assert bench['timing']['step_seconds'] == [step['wall_seconds'] for step in audit['steps'][4:]]
        assert bench['memory']['max_memory_allocated_bytes'] == audit['peak_allocated_bytes']
        assert bench['memory']['max_memory_reserved_bytes'] == audit['peak_reserved_bytes']
    if expected_status == 'PASS':
        fingerprints[record['cell']].add(audit['fingerprint_first'])
        observed = {step['total_tokens'] for step in audit['steps'][4:]}
        shapes[record['cell']].update(observed)
        assert observed == {int(record['cell'].split('-')[1])}, (parent, observed)
    counts[(record['cell'], record['kind'])][expected_status] += 1
    raw_statuses[expected_status] += 1
    checked += 1

summary = {'measured_source_commit': frozen['commit'], 'records_rejudged_from_original_files': checked,
    'scheduled_records': 2 * len(f2.schedule()), 'statuses': dict(raw_statuses),
    'cells': [{'cell': cell, 'kind': kind, 'statuses': dict(values)}
              for (cell, kind), values in sorted(counts.items())],
    'initial_fingerprint_variants': {cell: len(values) for cell, values in fingerprints.items()},
    'initial_fingerprint_variants_across_cells': len(set().union(*fingerprints.values())),
    'observed_total_tokens_per_step': {cell: sorted(values) for cell, values in shapes.items()},
    'checkpoint_cache_hashes': 'Recorded and rechecked at freeze/campaign start; '
        'this raw-record replay does not rehash tensor files'}
f2.write_json(root / 'audit-summary.json', summary)
Console().print(summary)
