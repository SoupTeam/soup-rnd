"""Summarise retained physical-mapping preparation attempts without changing criteria."""
import hashlib
import json
import time
from pathlib import Path

from rich.console import Console

root = Path('/workspace/f2-repo/out/f2-aux-capacity')
summaries = []
for name in ('mapping-attempt-1', 'mapping'):
    path = root / name / 'evidence.json'
    proof = json.loads(path.read_text())
    bad = [{'file': Path(row['path']).name, 'bytes': row['bytes'],
            'delta_bytes': row['delta_bytes']}
           for row in proof['files'] if row['delta_bytes']['nvme0n1'] < row['bytes']
           or row['delta_bytes']['nvme1n1'] != 0]
    summaries.append({'attempt': name, 'evidence_sha256':
        hashlib.sha256(path.read_bytes()).hexdigest(), 'files': len(proof['files']),
        'cache_bytes': proof['cache_bytes'], 'delta_bytes': proof['delta_bytes'],
        'candidate_devices': proof['candidate_devices'], 'nonconforming_rows': bad})
record = {'unix_s': time.time(), 'attempts': summaries,
          'auxiliary_measurement_started': (root / 'frozen.json').exists()}
(root / 'mapping-inspection.json').write_text(json.dumps(record, indent=2))
Console().print(record)
