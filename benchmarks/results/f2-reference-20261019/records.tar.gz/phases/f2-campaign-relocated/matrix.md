# F2 matrix (new hardware only)

NOT_RUN is not a measurement or an OOM.

| Condition | Length | Outcomes | supervised tok/s | step s | VRAM alloc/res GiB | sampled RAM GiB | sampled read MB/s | GPU % | SM MHz |
|---|---:|---|---:|---:|---:|---:|---:|---:|---:|
| ram | 128 | bench:PASS=2; train:PASS=2 | 78.665 (n=2) | 1.1692 | 2.230/2.465 | 19.916 | 0.000 | 99.58 | 1958 |
| ram | 384 | bench:NO_VERDICT=1; bench:PASS=1; train:PASS=2 | 222.329 (n=1) | 1.5355 | 2.642/3.037 | 19.916 | 0.000 | 99.92 | 1950 |
| ram | 1024 | bench:PASS=1; train:PASS=1 | 304.978 (n=1) | 3.1807 | 4.036/4.697 | 19.978 | 0.000 | 99.00 | 1950 |
| nvme | 128 | bench:PASS=2; train:PASS=2 | 7.639 (n=2) | 11.4756 | 2.230/2.465 | 13.950 | 1075.997 | 14.48 | 1665 |
| nvme | 384 | bench:PASS=2; train:PASS=2 | 20.563 (n=2) | 16.6048 | 2.642/3.037 | 13.952 | 768.498 | 13.38 | 1665 |
| nvme | 1024 | bench:NO_VERDICT=1; train:PASS=2 | — | — | — | — | — | — | — |
| refusal | 128 | bench:EXPECTED_REFUSAL=1; train:EXPECTED_REFUSAL=1 | — | — | — | — | — | — | — |
| refusal | 384 | bench:EXPECTED_REFUSAL=1; train:EXPECTED_REFUSAL=1 | — | — | — | — | — | — | — |
| refusal | 1024 | NOT_RUN | — | — | — | — | — | — | — |

Descriptive only. No 10% effect claim without the F1 repeats rule.
