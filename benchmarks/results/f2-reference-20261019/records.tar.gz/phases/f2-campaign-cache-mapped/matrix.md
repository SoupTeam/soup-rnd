# F2 matrix (new hardware only)

NOT_RUN is not a measurement or an OOM.

| Condition | Length | Outcomes | supervised tok/s | step s | VRAM alloc/res GiB | sampled RAM GiB | sampled read MB/s | GPU % | SM MHz |
|---|---:|---|---:|---:|---:|---:|---:|---:|---:|
| ram | 128 | bench:PASS=3; train:PASS=3 | 79.781 (n=3) | 1.1473 | 2.230/2.465 | 19.937 | 0.000 | 98.81 | 1950 |
| ram | 384 | bench:PASS=2; train:PASS=2 | 219.636 (n=2) | 1.5669 | 2.642/3.037 | 19.950 | 0.000 | 99.31 | 1935 |
| ram | 1024 | bench:NO_VERDICT=1; bench:PASS=1; train:PASS=2 | 302.647 (n=1) | 3.2537 | 4.036/4.697 | 19.943 | 0.000 | 99.85 | 1950 |
| nvme | 128 | bench:NO_VERDICT=1; bench:PASS=1; train:PASS=2 | 5.831 (n=1) | 14.0820 | 2.230/2.465 | 13.912 | 821.605 | 8.23 | 1665 |
| nvme | 384 | bench:NO_VERDICT=1; bench:PASS=1; train:PASS=2 | 19.480 (n=1) | 19.0130 | 2.642/3.037 | 13.923 | 729.077 | 11.17 | 1665 |
| nvme | 1024 | bench:NO_VERDICT=2; train:PASS=2 | — | — | — | — | — | — | — |
| refusal | 128 | bench:EXPECTED_REFUSAL=1; train:EXPECTED_REFUSAL=1 | — | — | — | — | — | — | — |
| refusal | 384 | bench:EXPECTED_REFUSAL=1; train:EXPECTED_REFUSAL=1 | — | — | — | — | — | — | — |
| refusal | 1024 | bench:EXPECTED_REFUSAL=1; train:EXPECTED_REFUSAL=1 | — | — | — | — | — | — | — |

Descriptive only. No 10% effect claim without the F1 repeats rule.
