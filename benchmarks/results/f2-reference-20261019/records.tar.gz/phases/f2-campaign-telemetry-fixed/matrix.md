# F2 matrix (new hardware only)

NOT_RUN is not a measurement or an OOM.

| Condition | Length | Outcomes | supervised tok/s | step s | VRAM alloc/res GiB | sampled RAM GiB | sampled read MB/s | GPU % | SM MHz |
|---|---:|---|---:|---:|---:|---:|---:|---:|---:|
| ram | 128 | bench:PASS=10; train:PASS=10 | 79.159 (n=10) | 1.1493 | 2.230/2.465 | 19.938 | 0.000 | 99.55 | 1950 |
| ram | 384 | bench:PASS=10; train:PASS=10 | 221.271 (n=10) | 1.5417 | 2.642/3.037 | 19.956 | 0.000 | 99.28 | 1942 |
| ram | 1024 | bench:PASS=10; train:PASS=10 | 304.212 (n=10) | 3.2109 | 4.036/4.697 | 19.979 | 0.000 | 99.75 | 1935 |
| nvme | 128 | bench:PASS=10; train:NO_VERDICT=1; train:PASS=9 | 5.104 (n=10) | 17.5272 | 2.230/2.465 | 13.940 | 717.952 | 8.94 | 1665 |
| nvme | 384 | bench:PASS=10; train:PASS=10 | 19.484 (n=10) | 17.6339 | 2.642/3.037 | 13.958 | 729.569 | 11.10 | 1665 |
| nvme | 1024 | bench:PASS=10; train:NO_VERDICT=1; train:PASS=9 | 52.078 (n=10) | 18.4591 | 4.036/4.697 | 13.978 | 688.489 | 20.59 | 1665 |
| refusal | 128 | bench:EXPECTED_REFUSAL=5; train:EXPECTED_REFUSAL=5 | — | — | — | — | — | — | — |
| refusal | 384 | bench:EXPECTED_REFUSAL=5; train:EXPECTED_REFUSAL=5 | — | — | — | — | — | — | — |
| refusal | 1024 | bench:EXPECTED_REFUSAL=5; train:EXPECTED_REFUSAL=5 | — | — | — | — | — | — | — |

Descriptive only. No 10% effect claim without the F1 repeats rule.
