# D3 packed NF4 grouped GEMM candidate

Status, 2026-11-01: host validation and a finite development CUDA gate are
implemented. The new kernel has not been compiled or executed on physical CUDA.
The existing completed OLMoE studies measured the staged restore/GEMM path;
their results do not qualify this candidate. Trainer dispatch is unchanged.

## Existing implementations inspected

| Source | Finding and reuse decision |
| --- | --- |
| Soup upstream `c38330cfae3c91e8d5ec880e8966a387ee025a74`, `layer_stream_runtime.py` | Checkpoint-visible wrapper calls bitsandbytes `gemm_4bit` for eligible ordinary 2D projections. It has no grouped packed routed-expert API. Preserve it as a comparator; do not call a per-expert launch loop a grouped kernel. |
| RND D1 `benchmarks/harness/d1_fused_nf4.py`, current D3 base `55d5f9b7` | Tiled Triton NF4 forward/dX already decodes inside GEMM. Reused this in-repository algorithm as the candidate foundation, with D3 pointer tables and independent expert programs. D1's WMMA results are shape/card-specific, and its retained A100 dX failure prevents importing a universal exactness claim. |
| [grouped-nf4-gemm](https://github.com/pjordanandrsn/grouped-nf4-gemm/tree/6928361657ddd4fb22062b328548c93e2557fcb7), MIT | `kernel/nf4_grouped.py` supplies a useful grouped packed-GEMM design. Its documented arithmetic may feed FP32/TF32 decoded weights to dot rather than first rounding to the baseline BF16 weights; nested statistics are de-nested at repack. It is not a drop-in implementation of this D3 gate. No external source was copied or made a runtime dependency. |
| [bitsandbytes CUDA operators](https://github.com/bitsandbytes-foundation/bitsandbytes/blob/main/bitsandbytes/backends/cuda/ops.py) | Ready fused NF4 forward for eligible 2D cells, without a matching grouped routed-expert contract. |
| [Unsloth kernel utilities](https://github.com/unslothai/unsloth/blob/main/unsloth/kernels/utils.py) | Existing fused ordinary-projection paths are useful comparison points; they do not replace the bounded D3 expert storage/lease contract. |
| [Triton grouped GEMM tutorial](https://triton-lang.org/main/getting-started/tutorials/08-grouped-gemm.html) | Pointer/geometry scheduling reference; not NF4 or native-bitwise qualification. |

The upstream refs were inspected in separate research checkouts; the D3 branch
was not rebased or committed. External licenses were read before the reuse
decision. Original Soup/D1 code remains the implementation source.

Local validation: 77 selected CPU tests pass (`test_d3_fused_group.py`, existing
`test_d1_fused_nf4.py` and the repository GPU-marker regression). Full repository
Ruff passes for `src/soup_cli/ scripts/ tests/ benchmarks/`. These checks do not
execute or validate the Triton kernel on CUDA.

## Implemented boundary

`expert_group_fused.py` implements one Triton launch for one through four
independent frozen BF16 input / packed NF4 weight pairs, including empty experts
and different token counts from 0 through 512. Projection dimensions are
positive multiples of 32. A group shares projection shape and NF4 block metadata.
The kernel reads each expert's original packed bytes, code table and scales
through descriptor pointers. Nested scales are decoded inside the mainloop.

The decoded tile is rounded to BF16 before multiplication, then accumulated in
FP32 with one final BF16 output conversion. The transpose variant computes dX
directly from the same packed weights. There is no split-K, atomic accumulation,
full BF16 weight allocation, route modification or SiLU implementation.
This arithmetic choice does not prove the installed cuBLAS reduction matches.

The API refuses autograd-bearing inputs/weights. A future custom backward must
reload packed state under a valid lease before invoking the dX primitive.
The caller retains the packed storage through device completion. Outputs and
the nine-row descriptor table are budgeted before allocation; existing packed
weights, CUDA context and compiler resources are separate. No public training
config enables this candidate yet.

## Next CUDA screen

Use Linux with native BF16, sm_80+, torch, bitsandbytes and Triton. A 12 GB
RTX 3060 is sufficient for this primitive screen; this is not a model-fit test.
Source hashes and software/GPU identities are written into the result. Run
from a source checkout with the corresponding environment active:

```sh
PYTHONPATH=src python benchmarks/harness/d3_fused_nf4_gate.py --out /workspace/d3-fused-screen-01
```

The finite screen has 16 arithmetic cells plus four effective corruption/
restoration controls. Both OLMoE projection geometries, ordinary/nested NF4,
forward/dX, widths one/four, empty experts and rows 1/17/31/128/129/481/512 are
covered. Every grouped output must match both singleton fused execution and
independent bitsandbytes dequantization followed by native BF16 matrix work,
including exact output bits and finite values. An incomplete grid or a native
mismatch fails. No timing verdict follows from this development screen.

After this passes: verify actual one-launch dispatch, memory and input/state
preservation on CUDA; adapt bounded packed-only expert storage (the old pool
still allocates dense slots), lease handling and custom autograd; qualify through
the public trainer. Freeze a new prospective source/protocol before new formal
correctness/performance measurements. Existing archives remain historical.
