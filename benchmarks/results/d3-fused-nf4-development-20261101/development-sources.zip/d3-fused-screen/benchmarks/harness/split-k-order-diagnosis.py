"""Finite small-M WMMA reduction-order hypothesis; no timing or production change."""
import ctypes,json,hashlib
import torch,bitsandbytes as bnb
import d1_wmma_nf4 as d1

torch.manual_seed(314159)
torch.backends.cuda.preferred_blas_library('cublaslt')
torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction=(False,False)
original_source=d1.SOURCE
records=[]
fixtures=[]
for n,k in [(2048,2048),(2048,1024)]:
 raw=torch.randn((n,k),device='cuda',dtype=torch.bfloat16)
 packed,state=bnb.functional.quantize_4bit(raw,blocksize=64,quant_type='nf4',compress_statistics=False)
 dense=bnb.functional.dequantize_4bit(packed,state)
 empty=state.code.new_empty(0)
 for transpose in (False,True):
  for m in (1,17,31,128,129):
   x=torch.randn((m,n if transpose else k),device='cuda',dtype=torch.bfloat16)
   fixtures.append((x,(packed,state.absmax,state.code,empty,empty,empty),(n,k,64,False,0,torch.bfloat16),transpose,x@(dense if transpose else dense.t())))
for parts in (2,4,8):
 for tree in (False,True):
  if tree and parts==2:continue
  source=original_source.replace('float C[TILE_SIZE*TILE_SIZE]','float C[%d*TILE_SIZE*TILE_SIZE]'%parts)
  source=source.replace('int warp_out = warp % (TILE_SIZE/16), warp_m = warp / (TILE_SIZE/16);','int warp_out=0, warp_m=0;')
  span=128//parts
  source=source.replace('int inner=0; inner<REDUCE_TILE; inner+=16',f'int inner=warp*{span}; inner<(warp+1)*{span}; inner+=16')
  source=source.replace('C+warp_m*16*TILE_SIZE+warp_out*16','C+warp*TILE_SIZE*TILE_SIZE')
  terms=[f'C[q+{p}*TILE_SIZE*TILE_SIZE]' for p in range(parts)]
  if tree:
   while len(terms)>1:terms=[f'({terms[i]}+{terms[i+1]})' for i in range(0,len(terms),2)]
   expr=terms[0]
  else:expr='+'.join(terms)
  source=source.replace('CONVERT(C[q])',f'CONVERT({expr})')
  d1.SOURCE=source;d1._CACHE.clear()
  for x,saved,metadata,transpose,native in fixtures:
   n,k,bs,nested,b2,dt=metadata;m=x.shape[0];cols=k if transpose else n
   y=torch.empty((m,cols),device='cuda',dtype=torch.bfloat16)
   driver,mod,fn,ptx,log=d1.compile_kernel(dt,bs,b2,tile=16,reduction_tile=128)
   ptrs=[ctypes.c_void_p(t.data_ptr()) for t in (x,*saved,y)]
   scalars=[ctypes.c_int(v) for v in (m,n,k,bs,int(nested),b2,int(transpose))]
   params=(ctypes.c_void_p*15)(*(ctypes.cast(ctypes.byref(v),ctypes.c_void_p) for v in ptrs+scalars))
   d1.check(driver,'cuLaunchKernel',fn,(cols+15)//16,(m+15)//16,1,32*parts,1,1,0,ctypes.c_void_p(torch.cuda.current_stream().cuda_stream),params,None)
   row=dict(parts=parts,tree=tree,shape=[m,n,k],transpose=transpose,source_sha256=hashlib.sha256(source.encode()).hexdigest(),differences=int((y.view(torch.int16)!=native.view(torch.int16)).sum().item()))
   records.append(row);print(json.dumps(row),flush=True)
open('split-k-order-diagnosis.json','w').write(json.dumps(records,indent=2)+'\n')
