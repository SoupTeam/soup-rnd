"""Bounded development diagnosis of native reduction order; no performance gate."""
import json
import torch
import bitsandbytes as bnb
from d1_wmma_nf4 import matmul

torch.manual_seed(314159)
torch.backends.cuda.preferred_blas_library('cublaslt')
torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction=(False,False)
configs=[(16,16),(16,32),(16,64),(16,128),(32,32),(32,64),(32,128),(64,64),(64,128)]
records=[]
for n,k in [(2048,2048),(2048,1024)]:
    raw=torch.randn((n,k),device='cuda',dtype=torch.bfloat16)
    packed,state=bnb.functional.quantize_4bit(raw,blocksize=64,quant_type='nf4',compress_statistics=False)
    dense=bnb.functional.dequantize_4bit(packed,state)
    empty=state.code.new_empty(0)
    saved=(packed,state.absmax,state.code,empty,empty,empty)
    metadata=(n,k,64,False,0,torch.bfloat16)
    for transpose in (False,True):
        for m in (1,17,129,481):
            x=torch.randn((m,n if transpose else k),device='cuda',dtype=torch.bfloat16)
            native=x@(dense if transpose else dense.t())
            results={}
            for tile,red in configs:
                y=matmul(x,saved,metadata,transpose,tile=tile,reduction_tile=red)
                results[f'{tile}/{red}']=int((y.view(torch.int16)!=native.view(torch.int16)).sum().item())
            row=dict(shape=[m,n,k],transpose=transpose,wmma_differences=results)
            records.append(row)
            print(json.dumps(row),flush=True)
open('native-wmma-diagnosis.json','w').write(json.dumps(records,indent=2)+'\n')
