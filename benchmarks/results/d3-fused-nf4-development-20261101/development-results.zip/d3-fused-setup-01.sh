#!/usr/bin/env bash
set -euo pipefail
cd /root/d3-fused-screen
export UV_LINK_MODE=copy
/root/.local/bin/uv venv --python 3.12 /root/d3-fused-env
/root/.local/bin/uv pip install --python /root/d3-fused-env/bin/python torch==2.14.1 --index-url https://download.pytorch.org/whl/cu130
/root/.local/bin/uv pip install --python /root/d3-fused-env/bin/python bitsandbytes==0.50.2 rich pytest
export PYTHONPATH=/root/d3-fused-screen/src
export OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 MKL_NUM_THREADS=4
/root/d3-fused-env/bin/python - <<'PY'
import json,torch,triton,bitsandbytes
env={'torch':torch.__version__,'cuda':torch.version.cuda,'triton':triton.__version__,
     'bnb':bitsandbytes.__version__,'gpu':torch.cuda.get_device_name(),
     'native_bf16':torch.cuda.is_bf16_supported(including_emulation=False)}
print(json.dumps(env,indent=2))
assert env['native_bf16']
torch.ones((32,32),device='cuda',dtype=torch.bfloat16).square().sum().item()
open('environment.json','w').write(json.dumps(env,indent=2)+'\n')
PY
set +e
timeout 900 /root/d3-fused-env/bin/python -u benchmarks/harness/d3_fused_nf4_gate.py --out /root/d3-fused-screen/attempt-01 > /root/d3-fused-screen/gate-01.log 2>&1
code=$?
printf '%s\n' "$code" > /root/d3-fused-screen/gate-01.exit
exit "$code"
