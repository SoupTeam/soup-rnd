#!/usr/bin/env bash
set -euo pipefail
cd /root/d3-fused-screen
tar -xzf /root/launch-07.tar.gz
export UV_LINK_MODE=copy
/root/.local/bin/uv pip install --python /root/d3-fused-env/bin/python peft==0.20.0 trl==0.29.1 datasets accelerate psutil omegaconf typer > trainer-deps.log 2>&1
/root/d3-fused-env/bin/python - <<'PY'
import pathlib,json,hashlib
p=pathlib.Path('/root/d3-fused-screen')
files={str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest()
       for base in ('src','benchmarks/harness') for f in (p/base).rglob('*.py')}
(p/'DEVELOPMENT-SOURCE.json').write_text(json.dumps({'kind':'working development snapshot, not committed formal source','files':files},indent=2)+'\n')
PY
export PYTHONPATH=/root/d3-fused-screen/src
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
timeout 5400 /root/d3-fused-env/bin/python -u /root/trainer-matrix-01.py > trainer-matrix-01.log 2>&1
