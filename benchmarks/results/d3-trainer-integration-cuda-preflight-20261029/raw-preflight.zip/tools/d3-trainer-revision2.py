import hashlib
import json
import shutil
import sys
import zipfile
from pathlib import Path

if sys.platform == 'win32':
    base = Path('C:/ml/soup/soup-rnd-d3')
    payloads = {rel: (base / rel).read_bytes() for rel in (
        'src/soup_cli/utils/expert_training.py', 'tests/test_d3_trainer_integration.py')}
    with zipfile.ZipFile('C:/ml/soup/work/d3-trainer-revision2.zip', 'w') as archive:
        for name, payload in payloads.items():
            archive.writestr(name, payload)
else:
    root = Path('/root/d3-trainer-development-01')
    target = root / 'source-r2'
    assert not target.exists()
    shutil.copytree(root / 'source', target)
    metadata = json.loads((target / 'DEVELOPMENT-SOURCE.json').read_text())
    for relative, expected in metadata['files'].items():
        assert hashlib.sha256((target / relative).read_bytes()).hexdigest() == expected, relative
    with zipfile.ZipFile('/root/d3-trainer-revision2.zip') as archive:
        assert archive.testzip() is None
        for relative in archive.namelist():
            assert relative in ('src/soup_cli/utils/expert_training.py',
                                'tests/test_d3_trainer_integration.py')
            payload = archive.read(relative)
            (target / relative).write_bytes(payload)
            metadata['files'][relative] = hashlib.sha256(payload).hexdigest()
    metadata['development_revision'] = 2
    (target / 'DEVELOPMENT-SOURCE.json').write_text(json.dumps(metadata, indent=2)+'\n')
    print('Updated development source:', target)
