import hashlib
import json
import os
import subprocess
import traceback
from pathlib import Path

root = Path('/root/d3-trainer-development-01')
version = 'matrix-r4'
destination = root / version
assert not destination.exists()
destination.mkdir()
os.environ['D3_DEVELOPMENT_SOURCE'] = str(root / 'source-r2')
records = []
status = dict(kind='synthetic CUDA development matrix; not a formal pretrained experiment',
              formal_session_started=False, fixed_cells=12, cells=records, status='running')

def write():
    (destination / 'status.json').write_text(json.dumps(status, indent=2)+'\n')

try:
    for codec in ['nf4', 'nf4-dq']:
        for l2l in [False, True]:
            reference = None
            for backend in ['sequential', 'grouped', 'triton']:
                case = f'{version}/{codec}-{int(l2l)}-{backend}'
                command = ['/root/d3-trainer-venv/bin/python', '-u',
                    '/root/d3-trainer-cuda-development-58145733.py', '--case', case,
                    '--backend', backend, '--codec', codec]
                if l2l:
                    command.append('--l2l')
                row = dict(case=case, status='running')
                records.append(row)
                write()
                with (root / (case+'.log')).open('wb') as log:
                    result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT,
                                            timeout=600, check=False)
                assert result.returncode == 0, f'{case}: exit {result.returncode}'
                data = json.loads((root / case / 'status.json').read_text())
                assert data['status'] == 'passed'
                row['status'] = 'passed'
                if reference is None:
                    reference = data
                    reference_folder = root / case
                else:
                    assert data['final_parameters'] == reference['final_parameters'], case+' adapters'
                    for name in ['gradients-0.safetensors', 'gradients-1.safetensors',
                                 'trained-logits.safetensors']:
                        want = hashlib.sha256((reference_folder / name).read_bytes()).hexdigest()
                        got = hashlib.sha256((root / case / name).read_bytes()).hexdigest()
                        assert want == got, case+' '+name
                    row['exact_sequential_gradients_updates_logits'] = True
                write()
    status['status'] = 'passed'
except BaseException:
    if records and records[-1]['status'] == 'running':
        records[-1]['status'] = 'failed'
    status.update(status='failed', traceback=traceback.format_exc())
    raise
finally:
    write()
