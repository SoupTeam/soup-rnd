import hashlib
import json
import os
import sys
import zipfile
from pathlib import Path

packet = Path('/root/d3-trainer-dev-58145733-01.zip')
assert hashlib.sha256(packet.read_bytes()).hexdigest() == '08fa8816387044ef101635ab595826342246b5d1c375dda16584a2f8b7bf9445'
target = Path('/root/d3-trainer-development-01/source')
assert not target.exists()
target.mkdir(parents=True)
with zipfile.ZipFile(packet) as archive:
    assert archive.testzip() is None
    for entry in archive.infolist():
        dest = (target / entry.filename).resolve()
        assert os.path.commonpath([str(target.resolve()), str(dest)]) == str(target.resolve())
    archive.extractall(target)
metadata = json.loads((target / 'DEVELOPMENT-SOURCE.json').read_text())
print(json.dumps(metadata, indent=2)[:1800])
sys.path.insert(0, str(target / 'src'))
import torch
import triton
assert torch.cuda.is_available()
assert torch.cuda.is_bf16_supported(including_emulation=False)
torch.cuda.set_device(0)
x = torch.arange(64, device='cuda', dtype=torch.bfloat16).reshape(8, 8)
assert torch.isfinite(x @ x).all().item()
record = dict(torch=torch.__version__, cuda=torch.version.cuda, triton=triton.__version__,
              gpu=torch.cuda.get_device_name(), native_bf16=True,
              free_bytes=torch.cuda.mem_get_info()[0], formal_session_started=False)
(target.parent / 'cuda-runtime.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
