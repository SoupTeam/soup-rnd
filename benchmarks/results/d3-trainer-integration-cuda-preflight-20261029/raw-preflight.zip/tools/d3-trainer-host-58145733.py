"""Read-only guest inventory for a new D3 trainer qualification host."""
import importlib.util
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time


def command(argv):
    try:
        p = subprocess.run(argv, text=True, capture_output=True, timeout=20)
        return {'exit': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr}
    except Exception as exc:
        return {'error': str(exc)}


memory = {}
for row in Path('/proc/meminfo').read_text().splitlines():
    key, value = row.split(':', 1)
    if key in ('MemTotal', 'MemAvailable', 'SwapTotal', 'SwapFree'):
        memory[key] = value.strip()
target = '/root'
free = shutil.disk_usage(target)
result = {
    'kind': 'read-only inventory, not instrument PASS or a model experiment',
    'instance_id_operator_reported': 58145733,
    'utc_unix_s': time.time(), 'hostname': platform.node(), 'kernel': platform.release(),
    'python': sys.version, 'python_executable': sys.executable,
    'os_release': Path('/etc/os-release').read_text(),
    'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
    'cpus_visible': os.cpu_count(), 'memory': memory,
    'disk': {'path': target, 'total_bytes': free.total, 'free_bytes': free.free},
    'virtualization': command(['systemd-detect-virt']),
    'gpu': command(['nvidia-smi', '--query-gpu=name,uuid,driver_version,memory.total,memory.used,pci.bus_id,temperature.gpu,power.draw', '--format=csv,noheader']),
    'gpu_processes': command(['nvidia-smi', '--query-compute-apps=pid,process_name,used_memory', '--format=csv,noheader']),
    'block_devices': command(['lsblk', '-J', '-o', 'NAME,MAJ:MIN,SIZE,TYPE,FSTYPE,MOUNTPOINTS']),
    'mount': command(['findmnt', '-J', '-T', target, '-o', 'SOURCE,TARGET,FSTYPE,MAJ:MIN']),
    'diskstats': Path('/proc/diskstats').read_text(),
    'sysfs_block_available': Path('/sys/dev/block').is_dir(),
    'systemd': command(['systemctl', 'is-system-running']),
    'tools': {name: shutil.which(name) for name in ('uv', 'python3.12', 'python3', 'pip3', 'git')},
    'modules': {name: bool(importlib.util.find_spec(name)) for name in ('torch', 'pytest', 'transformers')},
}
print(json.dumps(result, indent=2))
