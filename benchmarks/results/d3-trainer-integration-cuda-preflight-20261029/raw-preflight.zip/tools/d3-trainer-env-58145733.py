"""Prepare a separate environment; never execute a model measurement."""
import json
import os
from pathlib import Path
import subprocess
import traceback

root = Path('/root/d3-trainer-environment-58145733')
root.mkdir(exist_ok=False)
python = '/root/d3-trainer-venv/bin/python'
uv = '/root/.local/bin/uv'
state = {'status': 'preparing', 'instance_id': 58145733, 'formal_session_started': False}


def run(name, args):
    state['phase'] = name
    (root/'status.json').write_text(json.dumps(state, indent=2)+'\n')
    with (root/(name+'.log')).open('x') as log:
        subprocess.run(args, env=dict(os.environ, UV_NO_CACHE='1'), stdout=log,
                       stderr=subprocess.STDOUT, check=True, timeout=1800)


try:
    run('python', [uv, 'venv', '--python', '3.12.15', '/root/d3-trainer-venv'])
    run('torch', [uv, 'pip', 'install', '--python', python, 'torch==2.14.1',
                  '--index-url', 'https://download.pytorch.org/whl/cu130'])
    run('training', [uv, 'pip', 'install', '--python', python,
        'triton==3.8.0', 'transformers==5.19.0', 'peft==0.20.0', 'trl==0.29.1',
        'bitsandbytes==0.50.2', 'safetensors==0.8.0', 'pytest', 'pytest-cov',
        'rich', 'numpy', 'psutil', 'accelerate', 'ruff', 'requests',
        'pydantic', 'pyyaml', 'typer<0.21', 'plotext', 'packaging'])
    run('versions', [uv, 'pip', 'freeze', '--python', python])
    state['status'] = 'installed_cuda_preflight_pending'
except BaseException:
    state['status'] = 'failed'
    state['traceback'] = traceback.format_exc()
finally:
    (root/'status.json').write_text(json.dumps(state, indent=2)+'\n')
