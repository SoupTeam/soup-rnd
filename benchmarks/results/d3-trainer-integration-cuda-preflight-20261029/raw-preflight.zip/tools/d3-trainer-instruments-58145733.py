"""Synthetic guest disk controls only; not a model measurement."""
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

root = Path('/root/d3-trainer-development-01')
source = root / 'source-r2'
target = root / 'instruments-01'
sys.path.insert(0, str(source / 'benchmarks/harness'))


def prepare():
    from d3_f1_mapping_probe import discover_guest

    target.mkdir(exist_ok=False)
    fixture = target / 'fixture.bin'
    block = os.urandom(4 * 2**20)
    size = 2 * 2**30
    with fixture.open('xb', buffering=0) as stream:
        os.posix_fallocate(stream.fileno(), 0, size)
        for _ in range(size // len(block)):
            assert stream.write(block) == len(block)
        os.fsync(stream.fileno())
    subprocess.run(['sync'], check=True)
    mapping = discover_guest([fixture])
    (target / 'mapping.json').write_text(json.dumps(mapping, indent=2)+'\n')
    (target / 'fixture.json').write_text(json.dumps(dict(
        kind='synthetic instrument fixture only', bytes=size,
        block_sha256=hashlib.sha256(block).hexdigest(), formal_session_started=False), indent=2)+'\n')


def queued():
    while subprocess.run(['systemctl', 'is-active', '--quiet',
                         'd3-trainer-cuda-matrix-r4']).returncode == 0:
        time.sleep(2)
    matrix = json.loads((root / 'matrix-r4/status.json').read_text())
    assert matrix['status'] == 'passed', 'stop after a failed matrix'
    prepare()
    subprocess.run(['systemd-run', '--unit=d3-trainer-instrument-foreign-01',
        '--property=Type=exec', '/root/d3-trainer-venv/bin/python',
        '/root/d3-trainer-instruments-58145733.py', 'foreign'], check=True)
    from d3_f1_controls import watch
    result = watch(target / 'mapping.json', target / 'controls')
    print(result['status'], flush=True)
    assert result['status'] == 'controls_passed', result


if __name__ == '__main__':
    if sys.argv[1] == 'foreign':
        from d3_f1_controls import foreign
        foreign(target / 'controls')
    else:
        queued()
