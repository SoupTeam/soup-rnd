"""Verify committed source and bound data/host; never execute a model."""
import hashlib,json,os,sys,zipfile
from pathlib import Path

commit='cd6515ac503b15a111050b35db5c33768d506a9b'
packet=Path('/root/d3-public-trainer-cd6515ac.zip')
source=Path('/root/d3-public-trainer-frozen-cd6515ac')
expected='0b041edb8154cc47ae5a2c8c7dd4fac79aff44154155b6429c936e036bcc9b52'
if hashlib.sha256(packet.read_bytes()).hexdigest()!=expected:
    raise ValueError('source archive changed during transfer')
source.mkdir(exist_ok=False)
with zipfile.ZipFile(packet) as archive:
    if archive.testzip() is not None: raise ValueError('source ZIP CRC failed')
    receipt=json.loads(archive.read('FROZEN-D3-TRAINER-SOURCE.json'))
    if receipt['git_head']!=commit:raise ValueError('not the operator committed source')
    files=receipt['git_blob_sha256']
    names=archive.namelist()
    if len(names)!=len(set(names)) or set(names)!=set(files)|{'FROZEN-D3-TRAINER-SOURCE.json'}:
        raise ValueError('source archive membership differs')
    for name in names:
        parts=name.split('/')
        if any(part in ('','..','.') for part in parts) or '\\' in name or ':' in name:
            raise ValueError('noncanonical source name')
        target=source/name
        if os.path.commonpath((os.path.realpath(source),os.path.realpath(target)))!=str(source):
            raise ValueError('source path escape')
        data=archive.read(name)
        if name in files and hashlib.sha256(data).hexdigest()!=files[name]:
            raise ValueError('committed blob mismatch: '+name)
        target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as stream:stream.write(data)
sys.path[:0]=[str(source),str(source/'src')]
from benchmarks.harness.d3_trainer_protocol import read_rule,file_hash,PROTOCOL
from benchmarks.harness.d3_trainer_series import frozen_source,verify_prepared,verify_host
rule=read_rule()
if frozen_source()!=receipt:raise ValueError('executed source identity differs')
manifest=Path(rule['prepared_manifest_path'])
prepared=verify_prepared(manifest,rule)
verify_host(rule,prepared)
result=dict(status='committed_source_and_prepared_host_verified',git_head=commit,
 source=str(source),source_archive_sha256=expected,source_files=len(files),
 protocol_sha256=file_hash(source/PROTOCOL),prepared_sha256=file_hash(manifest),
 prepared_files=len(prepared['files']),boot_id=prepared['boot_id'],gpu=prepared['gpu'],
 formal_execution_started=False,pretrained_model_executed=False)
with Path('/root/d3-public-trainer-freeze-cd6515ac.json').open('x') as stream:
    json.dump(result,stream,indent=2);stream.write('\n')
print(json.dumps(result,indent=2),flush=True)
