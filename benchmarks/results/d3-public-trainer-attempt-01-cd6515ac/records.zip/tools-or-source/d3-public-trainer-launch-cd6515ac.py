"""One operational launch of the committed prospective series, then CPU analysis/retention."""
import datetime,hashlib,json,os,subprocess,sys,traceback,zipfile
from pathlib import Path

commit='cd6515ac503b15a111050b35db5c33768d506a9b'
source=Path('/root/d3-public-trainer-frozen-cd6515ac')
manifest=Path('/root/d3-public-trainer-preparation-01/prepared-02/prepared-final.json')
output=manifest.parent/'formal-cd6515ac-01'
log_path=Path('/root/d3-public-trainer-cd6515ac.log')
receipt=Path('/root/d3-public-trainer-launch-cd6515ac.json')
rule=json.loads((source/'benchmarks/protocols/d3-public-trainer/protocol-draft.json').read_text())
freeze=json.loads(Path('/root/d3-public-trainer-freeze-cd6515ac.json').read_text())
if freeze['git_head']!=commit or str(manifest)!=rule['prepared_manifest_path']:
    raise ValueError('operator source/prepared path mismatch')
if os.path.commonpath((str(manifest.parent),str(output)))!=str(manifest.parent):
    raise ValueError('formal output escapes the prepared public workspace')
if output.exists() or receipt.exists():
    raise ValueError('retain existing attempt; no replacement or output-name retry')
env=dict(os.environ,PYTHONPATH=str(source/'src'),CUBLAS_WORKSPACE_CONFIG=':4096:8',
         OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',HF_HUB_OFFLINE='1',
         TOKENIZERS_PARALLELISM='false',PYTHONUNBUFFERED='1')
record=dict(status='requested',git_head=commit,source=str(source),prepared=str(manifest),
 output=str(output),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 frozen=freeze,operational_pid=os.getpid(),project_commit_or_push_performed=False)
def save():
    receipt.write_text(json.dumps(record,indent=2)+'\n')
with receipt.open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
with log_path.open('x',buffering=1) as log:
    try:
        command=[sys.executable,'-u','-m','benchmarks.harness.d3_trainer_gate','series',
                 '--prepared',str(manifest),'--out',str(output)]
        record['command']=command;save()
        log.write('Committed public-trainer launch '+commit+'\n')
        process=subprocess.run(command,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,
                               check=False)
        record['series_returncode']=process.returncode
        record['status']='series_finished_pending_offline_analysis';save()
        if (output/'session.json').exists():
            analysis=subprocess.run([sys.executable,'-u','-m',
                'benchmarks.harness.d3_trainer_analysis','--session',str(output),
                '--out',str(output/'analysis.json')],cwd=source,env=env,
                stdout=log,stderr=subprocess.STDOUT,check=False)
            record['analysis_returncode']=analysis.returncode
            session=json.loads((output/'session.json').read_text())
            record['session_status']=session['status']
            record['started_cells']=len(session['cells'])
        record['status']='complete' if process.returncode==0 and record.get('analysis_returncode')==0 else 'incomplete_or_failed_retained'
    except BaseException:
        record.update(status='operational_error_retained',traceback=traceback.format_exc())
        log.write(record['traceback'])
    finally:
        record['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
# CPU-only retention, outside all measured windows. Raw session always remains in place.
if output.exists():
    archive_path=Path('/root/d3-public-trainer-results-cd6515ac.zip')
    hashes={}
    with zipfile.ZipFile(archive_path,'x',zipfile.ZIP_DEFLATED,compresslevel=4) as archive:
        payloads={}
        for path in output.rglob('*'):
            if path.is_file() and '__pycache__' not in path.parts:
                payloads['session/'+path.relative_to(output).as_posix()]=path
        for path in (log_path,receipt,Path('/root/d3-public-trainer-freeze-cd6515ac.json'),
                     Path('/root/d3-public-trainer-freeze-cd6515ac.py'),Path(__file__),
                     Path('/root/d3-public-trainer-cd6515ac.zip')):
            payloads['tools-or-source/'+path.name]=path
        for name,path in payloads.items():
            digest=hashlib.sha256()
            with path.open('rb') as inp,archive.open(name,'w',force_zip64=True) as out:
                while block:=inp.read(8*2**20):digest.update(block);out.write(block)
            hashes[name]=digest.hexdigest()
        archive.writestr('MANIFEST.json',json.dumps(hashes,indent=2)+'\n')
    record['archive']=dict(path=str(archive_path),bytes=archive_path.stat().st_size,
        sha256=hashlib.sha256(archive_path.read_bytes()).hexdigest(),payloads=len(hashes))
    save()
raise SystemExit(0 if record['status']=='complete' else 1)
