"""Replay the committed D3 analysis and audit every retained arm/profile."""
import argparse
import hashlib
import importlib.util
import json
import subprocess
import sys
from pathlib import Path


def verify(root, checkout):
    spec = importlib.util.spec_from_file_location("d3_runner", checkout / "benchmarks/harness/d3_grouped_performance.py")
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    sys.path.insert(0, str(checkout / "benchmarks/harness"))
    from arm_validity import Run, blocks_to_add, repeats
    session = json.loads((root / "session.json").read_text())
    protocol = json.loads((checkout / "benchmarks/protocols/d3-grouped-experts/performance-protocol.json").read_text())
    assert session["status"] == "layer_performance_complete", session.get("traceback")
    assert set(session["configurations"]) == set(runner.CODECS)
    assert session["source"]["git_head"] == "0aef6904af8b6cbbc1d9119fcf687d1d0c170f04"
    protocol_hash = hashlib.sha256((checkout / "benchmarks/protocols/d3-grouped-experts/performance-protocol.json").read_bytes().replace(b"\r\n", b"\n")).hexdigest()
    assert session["protocol_sha256"] == protocol_hash
    output = {"scope": "Pinned trained-layer forward; not complete D3 or end-to-end/training acceptance", "source": session["source"], "protocol_sha256": protocol_hash, "formats": {}, "timed_arms": 0, "samples": 0, "profile_arms": 0, "d3_accepted": False}
    for name, digest in session["source"]["git_blob_sha256"].items():
        blob = subprocess.check_output(["git", "-C", str(checkout), "show", "HEAD:" + name])
        assert hashlib.sha256(blob).hexdigest() == digest
    seen = set()
    for codec in runner.CODECS:
        record = session["configurations"][codec]
        blocks = record["blocks"]
        analysis = runner.analyze(blocks, protocol["samples"])
        assert analysis == record["analysis"]
        runs = [[Run(row["median_seconds"], row["F1"]["outcome"]) for row in block] for block in blocks]
        calculation = repeats(runs)
        assert blocks_to_add(runs) == 0
        assert record["repeat_calculation"] == {"sigma": calculation.sigma, "mean_a": calculation.mean_a, "blocks_needed": calculation.blocks_needed}
        groups = {"A": [], "B": []}
        for block_num, block in enumerate(blocks, 1):
            for position, row in enumerate(block):
                folder = f"{codec}-block-{block_num:02d}-{position}-{row['arm']}"
                assert json.loads((root / folder / "result.json").read_text()) == row
                seen.add(folder)
                assert row["source"] == session["source"]
                assert row["protocol_sha256"] == protocol_hash
                assert row["recipe_sha256"] == protocol["recipe_sha256"][codec]
                assert row["negative_sha256"] != row["expected_sha256"]
                assert len(row["visible_workload"]) == 1
                assert row["visible_gpu_peers_before_setup"] == []
                groups[row["arm"]].append(row)
                output["timed_arms"] += 1
                output["samples"] += len(row["samples"])
        profiles = {}
        for arm in ("A", "B"):
            folder = f"{codec}-profile-{arm}"
            row = json.loads((root / folder / "result.json").read_text())
            assert row == record["profiles"][arm]
            assert row["status"] == "ok" and row["F1"]["outcome"] == "ok"
            assert row["mode"] == "profile" and row["formal_measurement"] is True and row["samples"] == []
            assert row["source"] == session["source"] and row["protocol_sha256"] == protocol_hash
            assert row["negative_sha256"] != row["expected_sha256"]
            trace = json.loads((root / folder / "trace.json").read_text())
            kernels = [event for event in trace["traceEvents"] if event.get("cat") == "kernel" and event.get("ph") == "X"]
            assert len(kernels) == row["cuda_kernel_events"] > 0
            profiles[arm] = len(kernels)
            output["profile_arms"] += 1
            seen.add(folder)
        ratio = analysis["mean_block_ratio"]
        output["formats"][codec] = {"analysis": analysis, "wall_reduction_percent": 100 * (1-ratio), "wall_speedup_B_over_A": 1/ratio, "repeat_calculation": record["repeat_calculation"], "profile_kernel_events": profiles, "memory_maxima_bytes": {arm: {key: max(row[key] for row in rows) for key in ("peak_allocated", "peak_reserved", "peak_rss_bytes")} for arm, rows in groups.items()}}
    assert seen == {p.parent.name for p in root.glob("*/result.json")}
    return output


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--session", type=Path, required=True)
    parser.add_argument("--checkout", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    result = verify(args.session, args.checkout)
    args.out.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
