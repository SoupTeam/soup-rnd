"""Render measured CSVs with matplotlib, after analyze.py. Optional, can run locally."""
import argparse
import csv
from pathlib import Path


def main(session):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    for path in sorted(session.glob('attempt-*/series.csv')):
        with path.open(encoding='utf-8') as handle:
            rows = list(csv.DictReader(handle))
        nodes = sorted({r['node'] for r in rows})
        fig, axes = plt.subplots(4, 1, figsize=(11, 10), sharex=True)
        metrics = [('direct_GB_s', 'Direct reads (GB/s)'), ('temperature_c', 'Temperature (°C)'),
                   ('read_IOPS', 'Physical read IOPS'), ('write_MB_s', 'Physical writes (MB/s)')]
        for node in nodes:
            subset = [r for r in rows if r['node'] == node]
            x = [float(r['elapsed_s']) / 60 for r in subset]
            for axis, (field, label) in zip(axes, metrics):
                axis.plot(x, [float(r[field]) for r in subset], label=node, linewidth=.65)
                axis.set_ylabel(label)
                axis.grid(alpha=.25)
                axis.axvspan(0, 10, alpha=.08, color='grey')
        axes[0].legend()
        axes[-1].set_xlabel('Elapsed minutes; first 10 minutes excluded from sustained summary')
        fig.suptitle(path.parent.name + '\nSynthetic direct-read primitive; single observation')
        fig.tight_layout()
        for suffix in ('png', 'svg'):
            fig.savefig(path.parent / ('plot.' + suffix), dpi=160)
        plt.close(fig)
        print('Plotted:', path.parent)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--session', default='c4-session')
    main(Path(parser.parse_args().session).resolve(strict=True))
