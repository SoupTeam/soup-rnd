"""Read-only C4 Linux host inspection. Never formats, mounts or benchmarks disks.

Optional --path arguments are existing intended data directories. Collection is
not a validity PASS: direct I/O, attribution controls and the runner still need
validation before a measurement protocol can be frozen.
"""

import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import tempfile
import zipfile

from storage_discovery import collect


def block_leaves(node, sys_class=Path("/sys/class/block"), seen=None):
    """Resolve partitions and stacked block devices to whole-device leaves."""
    seen = set() if seen is None else set(seen)
    if node in seen:
        raise ValueError("Cycle in block-device topology")
    seen.add(node)
    base = sys_class / node
    if not base.exists():
        raise ValueError("Block device is absent from sysfs: " + node)
    if (base / "partition").exists():
        return block_leaves(base.resolve().parent.name, sys_class, seen)
    slaves = sorted(p.name for p in (base / "slaves").glob("*"))
    if slaves:
        leaves = set()
        for child in slaves:
            leaves.update(block_leaves(child, sys_class, seen))
        return sorted(leaves)
    return [node]


def nvme_identity(node, sys_class=Path("/sys/class/block")):
    base = sys_class / node
    real = base.resolve()
    if not re.fullmatch(r"nvme\d+(?:c\d+)?n\d+", node):
        return {"kind": "not_confirmed_nvme", "node": node}
    controller = next(
        (parent for parent in real.parents if re.fullmatch(r"nvme\d+", parent.name)),
        None,
    )
    if controller is None:
        return {"kind": "unknown_controller", "node": node}

    def read(name):
        try:
            return (controller / name).read_text().strip()
        except OSError:
            return None

    serial = read("serial")
    return {
        "kind": "nvme_namespace",
        "node": node,
        "controller": controller.name,
        "controller_sysfs": str(controller),
        "model": read("model"),
        "serial_sha256": hashlib.sha256(serial.encode()).hexdigest() if serial else None,
        "transport": read("transport"),
    }


def directory_report(path):
    target = Path(path).resolve(strict=True)
    if not target.is_dir():
        raise ValueError("Not a directory: " + str(target))
    dev = target.stat().st_dev
    link = Path("/sys/dev/block") / f"{os.major(dev)}:{os.minor(dev)}"
    if not link.exists():
        raise ValueError("Directory has no visible block backing (overlay/network/unknown)")
    leaves = block_leaves(link.resolve().name)
    stats = os.statvfs(target)
    return {
        "path": str(target),
        "major_minor": f"{os.major(dev)}:{os.minor(dev)}",
        "device": link.resolve().name,
        "leaves": leaves,
        "identities": [nvme_identity(node) for node in leaves],
        "free_bytes": stats.f_bavail * stats.f_frsize,
        "permission_hint_writable": os.access(target, os.W_OK),
        "filesystem_readonly": bool(stats.f_flag & getattr(os, "ST_RDONLY", 1)),
        "write_test_performed": False,
    }


def assess_paths(paths, mem_total):
    """Conservative structural screening; even a clean screen is not a PASS."""
    reasons = []
    if len(paths) != 2:
        return ["Need two existing data-directory paths to assess separate access."]
    identities = []
    for entry in paths:
        if "error" in entry:
            reasons.append(entry["error"])
            continue
        if len(entry["leaves"]) != 1:
            reasons.append(entry["path"] + ": spans multiple devices; not a separate-drive path.")
            continue
        ids = entry["identities"]
        if len(ids) != 1 or ids[0].get("kind") != "nvme_namespace":
            reasons.append(entry["path"] + ": physical NVMe identity is unconfirmed.")
            continue
        identity = ids[0]
        identities.append(identity)
        if identity.get("transport") != "pcie" or not identity.get("serial_sha256"):
            reasons.append(entry["path"] + ": local PCIe/unique device identity is unconfirmed.")
        if entry["filesystem_readonly"] or not entry["permission_hint_writable"]:
            reasons.append(entry["path"] + ": writable filesystem access is unconfirmed.")
        if mem_total is None:
            reasons.append("Host RAM could not be determined.")
        elif entry["free_bytes"] < (mem_total * 5 // 4 + 20 * 1024**3):
            reasons.append(entry["path"] + ": insufficient space for 1.25x RAM plus 20 GiB reserve.")
    if len(identities) == 2:
        for key in ("node", "controller_sysfs", "serial_sha256"):
            a, b = (entry.get(key) for entry in identities)
            if a and b and a == b:
                reasons.append("Both paths share " + key + "; two separate SSDs are not confirmed.")
    return sorted(set(reasons))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--path", action="append", default=[], help="Existing data directory")
    parser.add_argument("--output", default=".", help="Existing directory for diagnostic ZIP")
    args = parser.parse_args()
    if platform.system() != "Linux":
        parser.error("Live collection requires Linux. Local unit tests do not inspect hardware.")
    output_parent = Path(args.output).resolve(strict=True)
    if not output_parent.is_dir():
        parser.error("Output must be an existing directory")
    report = collect()
    report["kind"] = "C4 Linux two-drive readiness collection; not benchmark evidence"
    report["source_sha256"] = {
        name: hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest()
        for name in ("preflight.py", "storage_discovery.py")
    }
    report["nvme_identities"] = [
        nvme_identity(entry["name"])
        for entry in report.get("devices", []) if entry["name"].startswith("nvme")
    ]
    meminfo = report.get("proc", {}).get("meminfo", "")
    match = re.search(r"^MemTotal:\s+(\d+)\s+kB", meminfo, re.MULTILINE) if isinstance(meminfo, str) else None
    mem_total = int(match.group(1)) * 1024 if match else None
    report["host_ram_bytes"] = mem_total
    report["directories"] = []
    for path in args.path:
        try:
            entry = directory_report(path)
        except (OSError, ValueError) as exc:
            entry = {"path": path, "error": str(exc)}
        report["directories"].append(entry)
    reasons = assess_paths(report["directories"], mem_total)
    report["structural_blockers_or_unknowns"] = reasons
    report["suitability"] = "requires_review_not_a_PASS"
    report["remaining_before_timed_runs"] = [
        "Confirm bare-metal/local topology; namespace visibility alone is not proof.",
        "Validate writable paths and aligned direct reads on expendable test files.",
        "Map fresh temperature readings and SMART to each physical drive.",
        "Validate per-device and combined foreign-I/O controls, power and suspend checks.",
        "Test the Linux runner, create and hash the fixtures, freeze exact sources/protocol.",
    ]
    folder = Path(tempfile.mkdtemp(prefix="c4_linux_preflight_", dir=output_parent))
    (folder / "diagnostic.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    archive = folder.with_suffix(".zip")
    with zipfile.ZipFile(archive, "x", zipfile.ZIP_DEFLATED) as bundle:
        bundle.write(folder / "diagnostic.json", "diagnostic.json")
        for name in report["source_sha256"]:
            bundle.write(Path(__file__).with_name(name), name)
    print("Collection complete; suitability requires review, not a PASS.")
    for reason in reasons:
        print(" -", reason)
    print("Saved:", archive)


if __name__ == "__main__":
    main()
