import copy
import tempfile
from pathlib import Path
import unittest

from preflight import assess_paths, block_leaves


class ReadinessTests(unittest.TestCase):
    def paths(self):
        return [
            {
                "path": f"/data{i}", "leaves": [f"nvme{i}n1"],
                "identities": [{
                    "kind": "nvme_namespace", "node": f"nvme{i}n1",
                    "controller_sysfs": f"/sys/controller{i}",
                    "serial_sha256": f"serial{i}", "transport": "pcie",
                }],
                "free_bytes": 200 * 1024**3, "filesystem_readonly": False,
                "permission_hint_writable": True,
            } for i in range(2)
        ]

    def test_no_paths_remains_unknown(self):
        self.assertTrue(assess_paths([], 64 * 1024**3))

    def test_separate_drives_clear_structural_screen_only(self):
        self.assertEqual(assess_paths(self.paths(), 64 * 1024**3), [])

    def test_two_mounts_same_device_rejected(self):
        paths = self.paths()
        paths[1]["identities"] = copy.deepcopy(paths[0]["identities"])
        self.assertTrue(any("share" in x for x in assess_paths(paths, 64 * 1024**3)))

    def test_distinct_namespaces_same_controller_rejected(self):
        paths = self.paths()
        paths[1]["identities"][0]["controller_sysfs"] = "/sys/controller0"
        self.assertTrue(any("controller" in x for x in assess_paths(paths, 64 * 1024**3)))

    def test_raid_path_rejected(self):
        paths = self.paths()
        paths[0]["leaves"] = ["nvme0n1", "nvme1n1"]
        self.assertTrue(any("spans" in x for x in assess_paths(paths, 64 * 1024**3)))

    def test_missing_identity_or_network_nvme_unknown(self):
        for key, value in (("serial_sha256", None), ("transport", "tcp")):
            with self.subTest(key=key):
                paths = self.paths()
                paths[0]["identities"][0][key] = value
                self.assertTrue(assess_paths(paths, 64 * 1024**3))

    def test_missing_ram_or_short_space_unknown(self):
        self.assertTrue(assess_paths(self.paths(), None))
        paths = self.paths()
        paths[0]["free_bytes"] = 80 * 1024**3
        self.assertTrue(assess_paths(paths, 64 * 1024**3))

    def test_readonly_access_not_accepted(self):
        paths = self.paths()
        paths[0]["filesystem_readonly"] = True
        self.assertTrue(assess_paths(paths, 64 * 1024**3))

    def test_error_is_preserved(self):
        paths = self.paths()
        paths[1] = {"error": "overlay has no visible backing"}
        self.assertIn("overlay has no visible backing", assess_paths(paths, 64 * 1024**3))

    def test_stacked_topology_and_cycles(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as temp:
            root = Path(temp)
            for name in ("md0", "nvme0n1", "nvme1n1"):
                (root / name / "slaves").mkdir(parents=True)
            for name in ("nvme0n1", "nvme1n1"):
                (root / "md0" / "slaves" / name).touch()
            self.assertEqual(block_leaves("md0", root), ["nvme0n1", "nvme1n1"])
            (root / "nvme0n1" / "slaves" / "md0").touch()
            with self.assertRaisesRegex(ValueError, "Cycle"):
                block_leaves("md0", root)


if __name__ == "__main__":
    unittest.main()
