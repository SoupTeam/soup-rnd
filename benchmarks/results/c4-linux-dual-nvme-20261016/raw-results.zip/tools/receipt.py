"""Read-only Git object proof linking exact protocol bytes to a commit.

This proves content linkage, not public publication or a trusted timestamp.
The reviewer must independently check the published commit and its chronology.
"""
import argparse
import base64
import hashlib
import json
from pathlib import Path
import re
import subprocess


def oid(kind, data):
    return hashlib.sha1(kind.encode() + b' ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def components(path):
    parts = path.split('/')
    if not parts or any(p in ('', '.', '..') or '\\' in p or '\0' in p for p in parts):
        raise ValueError('Use a relative repository path with forward slashes')
    return parts


def entries(raw):
    result, pos = {}, 0
    while pos < len(raw):
        space = raw.index(b' ', pos)
        end = raw.index(b'\0', space)
        mode = raw[pos:space].decode('ascii')
        name = raw[space + 1:end].decode('utf-8')
        digest = raw[end + 1:end + 21]
        if len(digest) != 20 or name in result:
            raise ValueError('Malformed Git tree')
        result[name] = (mode, digest.hex())
        pos = end + 21
    return result


def decode(value):
    if len(value) > 16_000_000:
        raise ValueError('Oversized receipt object')
    return base64.b64decode(value, validate=True)


def verify_receipt(receipt, protocol_bytes):
    if receipt.get('version') != 1:
        raise ValueError('Unsupported receipt version')
    commit = decode(receipt['commit_base64'])
    if oid('commit', commit) != receipt['commit']:
        raise ValueError('Commit object identity mismatch')
    tree_match = re.match(rb'tree ([0-9a-f]{40})\n', commit)
    stamp = re.search(rb'^committer [^\n]* ([0-9]+) [+-][0-9]{4}$', commit, re.M)
    if tree_match is None or stamp is None:
        raise ValueError('Missing commit tree or committer timestamp')
    target = tree_match[1].decode()
    parts = components(receipt['path'])
    if len(parts) != len(receipt['trees']):
        raise ValueError('Unexpected tree chain length')
    for index, (part, obj) in enumerate(zip(parts, receipt['trees'])):
        raw = decode(obj['base64'])
        if obj['oid'] != target or oid('tree', raw) != target:
            raise ValueError('Tree identity mismatch')
        mode, target = entries(raw)[part]
        allowed = ('100644', '100755') if index == len(parts) - 1 else ('40000', '040000')
        if mode not in allowed:
            raise ValueError('Protocol path contains a link or non-file entry')
    if oid('blob', protocol_bytes) != target or target != receipt['blob_oid']:
        raise ValueError('Committed protocol bytes do not match')
    if hashlib.sha256(protocol_bytes).hexdigest() != receipt['protocol_sha256']:
        raise ValueError('Protocol SHA-256 mismatch')
    return {'commit': receipt['commit'], 'committed_unix_s': int(stamp[1]),
            'path': receipt['path'], 'proof': 'Git content linkage; not trusted publication/time'}


def create(repo, commit, path):
    if re.fullmatch('[0-9a-f]{40}', commit) is None:
        raise ValueError('Pass the full 40-character commit SHA')

    def cat(kind, object_id):
        return subprocess.run(['git', '-C', str(repo), 'cat-file', kind, object_id],
                              check=True, capture_output=True).stdout

    raw_commit = cat('commit', commit)
    target = re.match(rb'tree ([0-9a-f]{40})\n', raw_commit)[1].decode()
    trees = []
    for part in components(path):
        raw = cat('tree', target)
        trees.append({'oid': target, 'base64': base64.b64encode(raw).decode()})
        _, target = entries(raw)[part]
    protocol = cat('blob', target)
    receipt = {'version': 1, 'commit': commit,
               'commit_base64': base64.b64encode(raw_commit).decode(),
               'path': path, 'trees': trees, 'blob_oid': target,
               'protocol_sha256': hashlib.sha256(protocol).hexdigest()}
    verify_receipt(receipt, protocol)
    return receipt


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True)
    parser.add_argument('--commit', required=True)
    parser.add_argument('--path', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    proof = create(Path(args.repo), args.commit, args.path)
    with Path(args.output).open('x', encoding='utf-8', newline='\n') as out:
        json.dump(proof, out, indent=2)
        out.write('\n')
    print('Saved:', args.output, '\nProtocol SHA256:', proof['protocol_sha256'])
