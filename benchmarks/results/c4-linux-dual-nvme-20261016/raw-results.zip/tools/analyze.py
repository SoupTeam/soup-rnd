"""Regenerate descriptive C4 results; never treat a failed/incomplete arm as evidence."""
import argparse
import bisect
import csv
import hashlib
import json
import math
from pathlib import Path

from receipt import verify_receipt
from runner import RULES, device_validity, digest, load, save


def require(condition, message):
    if not condition:
        raise ValueError(message)


def validate_samples(rows, arm, max_gap=5):
    require(bool(rows), 'No samples')
    nodes = arm['nodes']
    previous_time = 0.0
    previous_bytes = {n: 0 for n in nodes}
    previous_disk = arm['disk_before']
    for row in rows:
        elapsed, interval = row['elapsed_s'], row['interval_s']
        require(math.isfinite(elapsed) and math.isfinite(interval), 'Non-finite sample time')
        require(0 < elapsed - previous_time <= max_gap, 'Sample gap/nonmonotonic time')
        require(abs(interval - (elapsed - previous_time)) < 1e-6, 'Inconsistent sample interval')
        require(set(row['bytes']) == set(nodes) == set(row['disk']), 'Device set changed')
        for node in nodes:
            count = row['bytes'][node]
            require(isinstance(count, int) and count >= previous_bytes[node], 'Read counter decreased')
            for metric in ('read_bytes', 'write_bytes', 'read_ios', 'write_ios'):
                require(row['disk'][node][metric] >= previous_disk[node][metric], 'Disk counter decreased')
        require(set(row['temperature']) == set(rows[0]['temperature']) and bool(row['temperature']),
                'Temperature device set changed/missing')
        for item in row['temperature'].values():
            require(bool(item['sensors_c']), 'No temperature readings')
            require(all(math.isfinite(t) and 0 < t < RULES['stop_temperature_c']
                        for t in item['sensors_c']), 'Invalid/stop temperature')
            require(max(item['sensors_c']) == item['max_c'], 'Temperature maximum mismatch')
        previous_time, previous_bytes, previous_disk = elapsed, row['bytes'], row['disk']
    require(abs(rows[-1]['elapsed_s'] - arm['elapsed_s']) < 1e-6, 'Final time mismatch')
    require(rows[-1]['bytes'] == arm['bytes'], 'Final completed-byte mismatch')
    require(rows[-1]['disk'] == arm['disk_after'], 'Final disk-counter mismatch')


def percentile(values, fraction):
    values = sorted(values)
    position = (len(values) - 1) * fraction
    lower, upper = math.floor(position), math.ceil(position)
    return values[lower] + (values[upper] - values[lower]) * (position - lower)


def window_rates(rows, nodes, start=600, width=60, end=None):
    """Full non-overlapping windows, interpolating cumulative bytes at boundaries."""
    end = min(rows[-1]['elapsed_s'], end if end is not None else rows[-1]['elapsed_s'])
    times = [0.0] + [r['elapsed_s'] for r in rows]
    values = [0] + [sum(r['bytes'][n] for n in nodes) for r in rows]

    def at(t):
        i = bisect.bisect_left(times, t)
        if i == 0 or times[i] == t:
            return values[i]
        portion = (t - times[i - 1]) / (times[i] - times[i - 1])
        return values[i - 1] + portion * (values[i] - values[i - 1])

    rates = []
    while start + width <= end + 1e-9:
        rates.append({'start_s': start, 'end_s': start + width,
                      'GB_s': (at(start + width) - at(start)) / width / 1e9})
        start += width
    require(bool(rates), 'Not enough post-warmup data')
    return rates


def summarize(rows, arm, warmup=600, width=60):
    validate_samples(rows, arm)
    per_node = {}
    for key, nodes in [('total', arm['nodes'])] + [(n, [n]) for n in arm['nodes']]:
        windows = window_rates(rows, nodes, warmup, width, arm['target_seconds'])
        values = [r['GB_s'] for r in windows]
        p10 = percentile(values, 0.1)
        per_node[key] = {
            'post_warmup_mean_GB_s': sum(values) / len(values),
            'minimum_60s_GB_s': min(values), 'p10_60s_GB_s': p10,
            'provisional_planner_GB_s': 0.9 * p10,
            'planner_rule': '0.9 * P10 of full post-warmup windows; heuristic, not a lower bound',
            'first_5_windows_GB_s': sum(values[:5]) / len(values[:5]),
            'last_5_windows_GB_s': sum(values[-5:]) / len(values[-5:]),
            'windows': windows,
        }
    return {'metrics': per_node, 'elapsed_s': arm['elapsed_s'],
            'completed_read_bytes': arm['bytes'], 'temperatures_c': {
                node: {'first': rows[0]['temperature'][node]['max_c'],
                       'last': rows[-1]['temperature'][node]['max_c'],
                       'max': max(r['temperature'][node]['max_c'] for r in rows)}
                for node in rows[0]['temperature']}}


def export_samples(folder, rows, arm):
    with (folder / 'series.csv').open('w', encoding='utf-8', newline='') as handle:
        fields = ['elapsed_s', 'node', 'direct_GB_s', 'physical_GB_s', 'write_MB_s',
                  'read_IOPS', 'temperature_c']
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        prior_bytes, prior_disk = {n: 0 for n in arm['nodes']}, arm['disk_before']
        for row in rows:
            for node in arm['nodes']:
                interval, disk = row['interval_s'], row['disk'][node]
                writer.writerow({
                    'elapsed_s': row['elapsed_s'], 'node': node,
                    'direct_GB_s': (row['bytes'][node] - prior_bytes[node]) / interval / 1e9,
                    'physical_GB_s': (disk['read_bytes'] - prior_disk[node]['read_bytes']) / interval / 1e9,
                    'write_MB_s': (disk['write_bytes'] - prior_disk[node]['write_bytes']) / interval / 1e6,
                    'read_IOPS': (disk['read_ios'] - prior_disk[node]['read_ios']) / interval,
                    'temperature_c': row['temperature'][node]['max_c'],
                })
            prior_bytes, prior_disk = row['bytes'], row['disk']


def analyze(session):
    protocol_path = session / 'protocol.json'
    protocol = load(protocol_path)
    require(protocol['status'] == 'frozen', 'Protocol not frozen')
    require(protocol['config']['rules'] == RULES, 'Analyzer rules differ from protocol')
    receipt = verify_receipt(load(session / 'protocol-receipt.json'), protocol_path.read_bytes())
    require(receipt['committed_unix_s'] >= math.floor(protocol['frozen_unix_s']), 'Commit before freeze')
    control_path = session / protocol['controls_path']
    require(digest(control_path) == protocol['controls_sha256'], 'Control hash mismatch')
    control = load(control_path)
    require(control['status'] == 'controls_passed' and len(control['cases']) == 9, 'Incomplete controls')
    for case in control['cases']:
        require(case['passed'], 'Failed control')
        require(digest(control_path.parent / case['case'] / 'arm.json') == case['arm_sha256'],
                'Control arm changed')
    result = {'kind': 'exploratory synthetic direct-read primitive',
              'protocol_sha256': digest(protocol_path), 'protocol_commit': receipt['commit'],
              'limitations': protocol['limitations'], 'attempts': [], 'complete_series': False}
    directories = sorted(session.glob('attempt-*'))
    require(len(directories) <= 3, 'Attempt budget exceeded')
    for ordinal, folder in enumerate(directories, 1):
        arm = load(folder / 'arm.json')
        item = {'directory': folder.name, 'recorded_status': arm['status'], 'accepted': False,
                'arm_sha256': digest(folder / 'arm.json')}
        result['attempts'].append(item)
        try:
            require(folder.name == f'attempt-{ordinal:02d}-{RULES["order"][ordinal-1]}', 'Order changed')
            require(all(a['accepted'] for a in result['attempts'][:-1]), 'Previous attempt not accepted')
            require(arm['status'] == 'candidate' and not arm['errors'], 'Non-candidate attempt')
            require(arm['protocol_sha256'] == result['protocol_sha256'] and
                    arm['protocol_commit'] == receipt['commit'], 'Wrong protocol identity')
            require(arm['sources'] == protocol['config']['sources'], 'Source identity mismatch')
            require(arm['process_exit'] == 0, 'Process failed')
            require(arm['F1']['outcome'] == 'ok', 'F1 not OK')
            checks = arm['F1']['checks']
            require(all(checks[k]['outcome'] == 'ok' for k in ('suspend', 'power', 'foreign_reads')),
                    'Required F1 check not OK')
            require(arm['start_unix_s'] >= receipt['committed_unix_s'], 'Arm before protocol commit')
            expected_seconds = RULES['durations_s'][ordinal-1]
            require(arm['target_seconds'] == expected_seconds and
                    expected_seconds <= arm['elapsed_s'] <= expected_seconds + 5, 'Wrong duration')
            expected_indices = ([0], [1], [0, 1])[ordinal-1]
            nodes = [protocol['config']['drives'][i]['node'] for i in expected_indices]
            require(arm['nodes'] == nodes and all(arm['bytes'][n] > 0 for n in nodes), 'Wrong/idle reader')
            rechecked = device_validity(arm['disk_before'], arm['disk_after'], arm['bytes'])
            require(rechecked == arm['per_device'] and all(x['outcome'] == 'ok' for x in rechecked.values()),
                    'Physical I/O validity failed')
            for drive in protocol['config']['drives']:
                node = drive['node']
                before = arm['smart_before'][node]['nvme_smart_health_information_log']
                after = arm['smart_after'][node]['nvme_smart_health_information_log']
                require(before['critical_warning'] == after['critical_warning'] == 0 and
                        before['media_errors'] == after['media_errors'], 'SMART health changed')
            rows = [json.loads(line) for line in (folder / 'samples.jsonl').read_text().splitlines()]
            item['samples_sha256'] = digest(folder / 'samples.jsonl')
            item.update(summarize(rows, arm, RULES['warmup_s'], RULES['window_s']))
            export_samples(folder, rows, arm)
            item['accepted'] = True
        except (ValueError, KeyError, OSError, TypeError) as exc:
            item['exclusion_reason'] = str(exc)
    result['complete_series'] = len(result['attempts']) == 3 and all(a['accepted'] for a in result['attempts'])
    if result['complete_series']:
        means = [a['metrics']['total']['post_warmup_mean_GB_s'] for a in result['attempts']]
        result['descriptive_both_over_fastest_single'] = means[2] / max(means[:2])
        result['comparison_limit'] = 'Different durations/times; no repeats, confidence interval or causal attribution'
    save(session / 'analysis.json', result)
    lines = ['# C4 Linux exploratory direct-read results', '',
             'One observation per condition. This is not a completed C4 acceptance or Soup training run.', '',
             '| Attempt | Accepted | Post-warmup GB/s | Provisional planner GB/s |',
             '|---|---|---:|---:|']
    for item in result['attempts']:
        metrics = item.get('metrics', {}).get('total', {})
        lines.append(f'| {item["directory"]} | {item["accepted"]} | '
                     f'{metrics.get("post_warmup_mean_GB_s", "—")} | '
                     f'{metrics.get("provisional_planner_GB_s", "—")} |')
        if not item['accepted']:
            lines.append(f'\nExcluded: {item.get("exclusion_reason", "incomplete")}.\n')
    lines += ['', '## Limitations', ''] + ['- ' + x for x in result['limitations']]
    lines += ['', 'Temperature/throughput correlation alone does not establish thermal throttling or its absence.',
              'All attempts and controls remain in the bundle. GB/s uses 10^9 bytes.', '']
    (session / 'report.md').write_text('\n'.join(lines), encoding='utf-8', newline='\n')
    print('Saved:', session / 'analysis.json', '\nComplete exploratory series:', result['complete_series'])
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--session', default='c4-session')
    args = parser.parse_args()
    analyze(Path(args.session).resolve(strict=True))
