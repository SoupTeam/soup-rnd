"""Read-only Linux storage discovery; writes only its diagnostic report.

No benchmarks, mounts, package installation, RAID changes or device writes.
Exit 0 means collection finished, NOT that the host is suitable for C4.
"""
import datetime
import glob
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import tempfile
import zipfile


def command(argv, timeout=12):
    if not shutil.which(argv[0]):
        return {"argv": argv, "status": "missing_tool"}
    try:
        p = subprocess.run(argv, capture_output=True, text=True,
                           errors="replace", timeout=timeout, check=False)
        return {"argv": argv, "returncode": p.returncode,
                "stdout": p.stdout, "stderr": p.stderr}
    except subprocess.TimeoutExpired as e:
        return {"argv": argv, "status": "timeout", "timeout_s": e.timeout}
    except OSError as e:
        return {"argv": argv, "status": "error", "error": str(e)}


def read(path):
    try:
        return Path(path).read_text(errors="replace")[:262144]
    except OSError as e:
        return {"error": str(e)}


def collect():
    result = {"kind": "C4 storage access diagnostic; not performance evidence",
              "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
              "system": platform.system(), "machine": platform.machine(),
              "uid": os.geteuid() if hasattr(os, "geteuid") else None,
              "cwd": str(Path.cwd()), "suitability": "requires_review",
              "limitations": [
                  "Visible sysfs devices may belong to the host and be inaccessible here.",
                  "Two mounts or volumes do not prove two physical drives.",
                  "No writable path, isolation, cooling control or direct-I/O validation is performed.",
                  "Missing tools or denied access are unknown, not proof of missing hardware.",
                  "No RAID changes, benchmarking, package installs or device writes performed."]}
    if platform.system() != "Linux":
        result["status"] = "unsupported_platform"
        return result
    probes = [
        ["lsblk", "--json", "--bytes", "--output",
         "NAME,KNAME,TYPE,SIZE,MODEL,TRAN,ROTA,MAJ:MIN,MOUNTPOINTS"],
        ["findmnt", "--json", "--output", "TARGET,SOURCE,FSTYPE,OPTIONS,MAJ:MIN"],
        ["df", "-B1", "-T"], ["smartctl", "--version"],
        ["nvme", "version"], ["systemd-detect-virt"],
    ]
    result["commands"] = [command(p) for p in probes]
    result["proc"] = {name: read("/proc/" + name) for name in
                      ["meminfo", "diskstats", "mdstat", "self/cgroup", "self/status"]}
    result["cgroup_limits"] = {p: read(p) for p in [
        "/sys/fs/cgroup/memory.max", "/sys/fs/cgroup/memory.current",
        "/sys/fs/cgroup/memory/memory.limit_in_bytes"] if Path(p).exists()}
    devices = []
    for base in sorted(Path("/sys/class/block").glob("*")):
        if base.name.startswith(("loop", "ram")) or (base / "partition").exists():
            continue
        dev = Path("/dev") / base.name
        entry = {"name": base.name, "sysfs_path": str(base.resolve()),
                 "device_node_exists": dev.exists(),
                 "read_permission": os.access(dev, os.R_OK),
                 "slaves": sorted(p.name for p in (base / "slaves").glob("*")),
                 "holders": sorted(p.name for p in (base / "holders").glob("*"))}
        entry["attributes"] = {p: read(base / p) for p in
                               ["dev", "size", "queue/rotational", "device/model", "device/vendor"]
                               if (base / p).exists()}
        # Only information-reading commands, and only for exposed NVMe namespaces.
        if base.name.startswith("nvme") and dev.exists():
            print("Checking telemetry:", dev, flush=True)
            entry["smartctl"] = command(["smartctl", "-a", "-j", str(dev)])
            entry["nvme_smart"] = command(["nvme", "smart-log", str(dev), "-o", "json"])
        devices.append(entry)
    result["devices"] = devices
    result["hwmon"] = []
    for directory in sorted(glob.glob("/sys/class/hwmon/hwmon*")):
        base = Path(directory)
        if "nvme" not in str(read(base / "name")).lower():
            continue
        result["hwmon"].append({"path": str(base.resolve()),
                                "name": read(base / "name"),
                                "temperatures": {p.name: read(p) for p in base.glob("temp*_*")
                                                 if p.name.endswith(("_input", "_label", "_max", "_crit"))}})
    result["status"] = "collection_complete"
    return result


def main():
    out = Path(tempfile.mkdtemp(prefix="c4_storage_check_", dir=Path.cwd()))
    report = collect()
    (out / "diagnostic.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    archive = out.with_suffix(".zip")
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as z:
        z.write(out / "diagnostic.json", "diagnostic.json")
        z.write(Path(__file__), "vast_storage_check.py")
    print("Status:", report["status"])
    print("Suitability: requires review (not a PASS)")
    print("Download:", archive)


if __name__ == "__main__":
    main()
