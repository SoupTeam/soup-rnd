#!/bin/bash
set -u
set -o pipefail
cd /root/c4-linux || exit 90
python3 runner.py run-series --receipt protocol-receipt-293923fb.json 2>&1 | tee c4-session/series-process.log
run_exit=${PIPESTATUS[0]}
analysis_exit=99
if [ "$run_exit" -eq 0 ]; then
    python3 analyze.py --session c4-session 2>&1 | tee c4-session/analysis-process.log
    analysis_exit=${PIPESTATUS[0]}
fi
printf '{"series_exit":%s,"analysis_exit":%s}\n' "$run_exit" "$analysis_exit" > c4-session/launch-result.json
python3 runner.py bundle > bundle-final-293923fb.log 2>&1
bundle_exit=$?
cat bundle-final-293923fb.log
printf 'Series exit: %s; analysis exit: %s; bundle exit: %s\n' "$run_exit" "$analysis_exit" "$bundle_exit"
exit "$run_exit"
