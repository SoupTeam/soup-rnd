# C4 Linux exploratory direct-read results

One observation per condition. This is not a completed C4 acceptance or Soup training run.

| Attempt | Accepted | Post-warmup GB/s | Provisional planner GB/s |
|---|---|---:|---:|
| attempt-01-drive1 | True | 2.339680675985292 | 2.079310228336511 |
| attempt-02-drive2 | True | 1.9296916566211348 | 1.7354148285933655 |
| attempt-03-both | True | 4.019209539822172 | 3.5823883113303046 |

## Limitations

- Three single observations, not ABBA/repeatability certification.
- New-host direct-read primitive, not original Soup training striping.
- No controlled cooling or read-pattern contrast; causal attribution remains open.
- Power uses original F1 no-battery inference; no independent PSU telemetry.
- Physical counters and O_DIRECT do not certify the SSD internal cache or firmware.
- Kernel-hung I/O cannot be guaranteed interruptible by Python.

Temperature/throughput correlation alone does not establish thermal throttling or its absence.
All attempts and controls remain in the bundle. GB/s uses 10^9 bytes.
