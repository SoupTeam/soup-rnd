"""One retained CUDA development invocation; never restart or replace it implicitly."""

from __future__ import annotations

import hashlib
import importlib.metadata as metadata
import json
import os
import subprocess
import sys
import time
from pathlib import Path
from xml.etree import ElementTree


def main():
    root = Path(__file__).resolve().parent
    evidence = root / "cuda-development-01"
    evidence.mkdir(exist_ok=False)
    env = dict(os.environ, PYTHONPATH=str(root / "src") + os.pathsep + str(root),
               PYTHONUNBUFFERED="1", OMP_NUM_THREADS="4", MKL_NUM_THREADS="4",
               HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1",
               TRITON_CACHE_DIR=str(evidence / "triton-cache"))
    snapshot = json.loads((root / "DEVELOPMENT-SNAPSHOT.json").read_text())
    changed = {}
    for relative, expected in snapshot["sha256"].items():
        actual = hashlib.sha256((root / relative).read_bytes()).hexdigest()
        if actual != expected:
            changed[relative] = {"packaged": expected, "executed": actual}
    assert set(changed) <= {"tests/test_d3_expert_activation.py"}, changed
    result = {"kind": "development qualification, not formal D3 acceptance or timing",
              "start_unix": time.time(), "base_commit": snapshot["base_commit"],
              "source_changes_from_packaged_snapshot": changed,
              "sources": {p: hashlib.sha256((root / p).read_bytes()).hexdigest()
                          for p in snapshot["sha256"]},
              "packages": {name: metadata.version(name) for name in sorted({
                  d.metadata["Name"] for d in metadata.distributions() if d.metadata["Name"]
              })}, "cuda_executed": False}
    (evidence / "receipt.json").write_text(json.dumps(result, indent=2) + "\n")
    tests = ["tests/test_d3_expert_activation.py", "tests/test_d3_expert_derivatives.py"]
    base = [sys.executable, "-m", "pytest", *tests, "-m", "gpu", "-o", "addopts="]
    with (evidence / "collection.log").open("w") as log:
        collected = subprocess.run([*base, "--collect-only", "-q"], cwd=root, env=env,
                                   stdout=log, stderr=subprocess.STDOUT)
    result["collection_exit"] = collected.returncode
    if collected.returncode:
        (evidence / "receipt.json").write_text(json.dumps(result, indent=2) + "\n")
        raise SystemExit(collected.returncode)
    command = [*base, "-x", "-vv", "--tb=short", "-o", "junit_family=xunit1",
               "--junitxml=" + str(evidence / "junit.xml")]
    result.update(command=command, cuda_executed=True)
    (evidence / "receipt.json").write_text(json.dumps(result, indent=2) + "\n")
    with (evidence / "pytest.log").open("w", buffering=1) as log:
        process = subprocess.run(command, cwd=root, env=env, stdout=log,
                                 stderr=subprocess.STDOUT)
    result.update(returncode=process.returncode, end_unix=time.time())
    junit = evidence / "junit.xml"
    if junit.is_file():
        records = []
        for case in ElementTree.parse(junit).iter("testcase"):
            row = {"class": case.get("classname"), "name": case.get("name"),
                   "status": "passed", "properties": {}}
            for status in ("failure", "error", "skipped"):
                if case.find(status) is not None:
                    row["status"] = status
            for prop in case.findall("./properties/property"):
                row["properties"][prop.get("name")] = prop.get("value")
            records.append(row)
        result["cases"] = records
        result["all_14_passed"] = len(records) == 14 and all(
            row["status"] == "passed" for row in records
        )
    (evidence / "receipt.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: result.get(k) for k in ("returncode", "all_14_passed", "end_unix")}))
    raise SystemExit(process.returncode)


if __name__ == "__main__":
    main()
