"""Create exactly one non-restarting managed development test job."""

import subprocess
from pathlib import Path

root = Path(__file__).resolve().parent
name = "d3_development_20261022_v2"
config = Path("/etc/supervisor/conf.d") / (name + ".conf")
with config.open("x") as handle:
    handle.write(f"""[program:{name}]
command=/workspace/d3-dev-venv/bin/python -u {root}/dev_gpu_runner.py
directory={root}
autostart=false
autorestart=false
startsecs=0
stdout_logfile=/dev/stdout
stdout_logfile_maxbytes=0
redirect_stderr=true
stopasgroup=true
killasgroup=true
""")
for arguments in (("reread",), ("update", name), ("start", name), ("status", name)):
    subprocess.run(["supervisorctl", *arguments], check=True)
