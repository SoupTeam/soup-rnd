"""Soup CLI — Fine-tune and post-train LLMs in one command."""

__version__ = "0.75.0"
