"""Benchmark instruments (#836)."""
