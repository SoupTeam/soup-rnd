# OLMoE trained-step preparation evidence

No formal D3 training measurement was run during preparation. The initial bundle-preparation attempt and the original preparation mapping/control evidence are retained from revision 4.

After the Vast container was restarted, revision 4 correctly rejected its old mapping before model construction: the container-visible `st_dev` changed from 46 to 49 while inode, size, `mtime_ns`, and the exposed `loop0` backing association were unchanged. A new instrument mapping was measured on the current live container for all 48 expert shards. Current mapping reports loop0 only; this does not certify physical-host disk isolation or physical NVMe identity.

The refreshed independent-process F1 controls passed baseline=ok, own=ok, foreign=void. The first control orchestration attempt is also retained: the foreign process timed out waiting for the watcher marker because the watcher launch was interrupted by SSH loss; no F1 verdict was assigned to that setup attempt. The successful repeat used separate supervisor processes.

The runtime inventory, pinned checkpoint, and three prepared bundles are unchanged. No GPU training cell has run successfully under the refreshed mapping. The remount and control artifacts are setup evidence only and must be frozen in a new commit before any new formal cell.
