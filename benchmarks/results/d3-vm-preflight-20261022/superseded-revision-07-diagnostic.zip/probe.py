import json,mmap,os,sys,time
from pathlib import Path
root=Path('/workspace/d3-run-6f9252a9/source')
sys.path.insert(0,str(root/'benchmarks/harness'))
from arm_validity import ArmWatch,cgroup_disk_reads,cgroup_other_disk_reads,cgroup_io_reads
from d3_f1_controls import verified_selector
prep=Path('/workspace/d3-prepared-6f9252a9')
selector=verified_selector(json.loads((prep/'mapping.json').read_text()))
files=sorted((prep/'dense').glob('experts_*.safetensors'))
assert len(files)==16
for p in files: selector(str(p))
folder=Path('/workspace/d3-io-sweep-6f9252a9')
folder.mkdir(exist_ok=False)
record={'kind':'read-only full-shard F1 instrument diagnostic; no model measurement','commit':'6f9252a90b4d566b15eea4b381cd0b3088f70853','before':cgroup_io_reads(),'files':[]}
with ArmWatch(arm='full-dense-shard-read-control',round=0,run=0,model_path=str(files[0]),disk_device=selector,disk_reads=cgroup_disk_reads,other_disk_reads=cgroup_other_disk_reads) as watch:
    with mmap.mmap(-1,4*2**20) as buf:
        for p in files:
            fd=os.open(p,os.O_RDONLY|os.O_DIRECT)
            n=0
            try:
                remaining=(p.stat().st_size//4096)*4096
                while remaining:
                    count=min(remaining,len(buf))
                    view=memoryview(buf)[:count]
                    try: got=os.readv(fd,[view])
                    finally: view.release()
                    if got!=count: raise RuntimeError('short direct read')
                    remaining-=got; n+=got
            finally: os.close(fd)
            record['files'].append({'path':str(p),'bytes':n})
            print(p.name,n,flush=True)
record.update(after=cgroup_io_reads(),F1=watch.record)
record['deltas']={k:record['after'].get(k,0)-record['before'].get(k,0) for k in record['after'].keys()|record['before'].keys()}
(folder/'report.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'status':watch.record['outcome'],'deltas':record['deltas'],'foreign_reads':watch.record['checks']['foreign_reads']},indent=2),flush=True)
