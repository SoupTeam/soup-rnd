# B1.3 integration ledger

Base: SoupTeam/soup-rnd origin/main 9d8b1d7b4b3eabc1634a1f6c2318814c640535c3 (B1.2 PR25 ancestor fdf067fc).
Integration: b1.3-moe-backward, C:/Users/sydyk/Downloads/soup-rnd-b13.

## Completed source slices

- Installer rename prefactor 63b2b0c1; setup-matt-pocock-skills requested later, separate commit e8b84e6b.
- Ticket 01: ff91881c, integrated 22b2e8dc. Sonnet-max ExpertBackward2.
- Ticket 02: 7c871c81, integrated 9f5a565a. Sonnet-xhigh RuntimeInstall2.
- Verified integration 9f5a565a: CPU 227 passed/35 skipped, CUDA 16 passed (9 new backward + 7 B1 regressions).
- CUDA baseline e8b84e6b: 19 passed/1 skipped (second GPU absent).

## Continuation

User changed delegation to GPT 6.1 Sol only. Stopped Sonnet L2LMoE and ReviewBackward before reports; retain their partial work/probes, no completed acceptance claim.
- L2L partial checkpoint 72526f2c in soup-rnd-b13-t03 (not integrated, WIP).
- SolL2L owns completion in t03: l2l_step.py, trainer guard/counters, new L2L tests CPU/CUDA.
- SolTrainer owns new trainer tests and executable smoke harness in t04 based 72526f2c; no product files, shared L2L interface stable.
- SolBackwardReview independently reviews stable 9f5a565a source/probes; writes outside repo only.
- Authors are never sole reviewers. Final Standards and Spec reviews remain mandatory, parallel new Sol agents.

## Contracts / rulings

- Internal DeepSeek-V3 L2L support does not widen public YAML/CLI/trainer launch support. Planner/default expert activation stays B1.4.
- Routing guard records indices per actual layer/mb and checks recompute, rather than replaying detached route weights (would destroy routing gradients). It may reject divergent recompute; exactness is never silently relaxed. This is within the user's routing/recompute invariant.
- One-slot weights, first-order gradients only; no expert adapters/full-expert weight training. Three reads per expert visit for L2L (forward, recompute, VJP reload) accepted for correctness; no two-read dummy output optimization.
- Fixed exactness in spec remains binding. Mixed-length tolerance and bf16 trainer tolerance come from existing repo contract, not test outcomes.

## Cloud ownership / budget

Vast rental authorized <= $15. Only instance 58239965 (label b13-cuda, RTX3060, ssh3.vast.ai:16730) belongs to this task. Earlier 58148283 disappeared during image load (not in account instances); other instances belong to unrelated tasks.
Hourly quote current 58239965: $0.0674074074 incl storage; at continuation measured ~4.97 hours => ~$0.335 elapsed-rate estimate, excluding bandwidth. Retrieve billing at teardown rather than calling estimate actual.
Bootstrap env / downloaded raw results: C:/Users/sydyk/Downloads/b13-notes/vast/.
Destroy task-owned instance before final response or before any blocking user question. No push/PR/merge into shared branches authorized.

## Independent review corrections

- SolBackwardReview proved dropout activation accepted by the primitive produced equal forward but
  wrong hidden/routing grads, and consumed the outer RNG during ExpertNode recompute. SolL2L owns
  RNG snapshot/fork replay correction; no tolerance changes.
- Ruling: backward recomputation supports stateless activations, including RNG-replayed dropout,
  not arbitrary mutable module state. Refuse buffer-bearing activation modules before differentiable
  reads (keep existing no-grad forward compatibility). BatchNorm without affine otherwise updates its
  running stats twice. Caller mutation of activation mode/closures/weights between forward and
  backward remains outside the usual recompute contract; do not build a general Python state copier.
- SolTrainer uncovered bf16 gradient mismatch against resident HF Trainer while fp32 k=1/2/4 and
  no-dropout uneven cases passed. SolL2L investigates forward/backward autocast ordering; tolerance
  remains the predeclared value.

## First integrated verification / final review wave

Measured clean source 495b38829808fa8624867fc816d7506466838059:
- CPU target invocation: 457 passed, 78 skipped, no failures.
- CUDA RTX3060: 77 passed, 1 skipped (second card), 121 deselected. B1.3 GPU cases:
  16 expert backward + 14 L2L; remaining 47 are B1/B2/RNG regressions.
- Standalone CPU and GPU smoke each PASS k=1,2,4 x two optimizer updates; all configured30
  MLA gradients/loss/output/state exact; corruption affects only backward with gradient max
  differences ~0.498..4.198, forward/loss zero. Arena6144B stable; GPU delta6144B.
- Full Windows non-smoke suite attempted: nine E4 collection errors due POSIX `resource`
  import in unchanged benchmarks/harness/e4_part2_quant.py. Not a full-suite pass.
- Full Ruff and diff whitespace pass. Raw records in b13-notes/final and vast/results/final.
- Task GPU instance stopped after evidence retrieval; not yet destroyed (reverification may need it).

Final independent reviewers (non-authors): sol-xhigh SolStandards, sol-max SolSpec.
Standards requested lazy test collection imports/PEFT parametrization, typed added signatures,
and consolidation of duplicate synthetic initialization (not the eager mathematical oracle).
Spec proved two supported trainable-boundary gaps beyond default MLA fixture:
- embed_tokens LoRA gradients None in L2L vs32 nonzero resident/ordinary-stream grads;
- combined head+decoder dropout.05 missing head RNG draws:44 grads/losses/RNG differ.
Ruling: fix accepted non-expert gradient/RNG support, do not replace with new refusals or
narrow docs. One fresh sol-max SolFinalFix owns complete final review fix wave in t03,
fast-forwarded to495b. Keep original tested evidence attributed to495b, rerun final source
after fixes. Both reviewers perform scoped re-review of their original findings and fix diff.

## Final verified source and closed review

Product/harness/test source e691ffffc64349e53ce6d65b97ae7ab7ac2f1bd8:
- sol-max SolFinalFix repaired embedding VJP and native-head RNG; original IDs, immediate
  backward/no refill, NEFTune/outer RNG, forward AMP and frozen fast path independently checked.
- sol-xhigh SolStandardsFinal and sol-max SolSpecFinal APPROVE. All accepted findings closed.
  Final minor annotation/lazy-CUDA-import integration reviewed independently; no numeric assertion,
  expected value, tolerance or corruption algorithm weakened.
- Fresh CPU476/87 and CUDA86/1; eight standalone smokes over30/32/44/46 trainables, k1/2/4,
  two optimizer updates:48 clean exact windows and48 backward-corrupted gradient failures with
  identical forward/loss. One6144B arena/stable pointer; real reloads and reverse visits.
- Full Ruff and whitespace check pass. Complete configured dev suite coverage86.74% exceeds77%:
  36,488 passed,234 skipped,2 xfailed,12 deselected,20 failed. All20 failures reproduce on9d8b
  under the same dev/GPU/offline environment; no new B1.3 test failure. Do not call it a full PASS.
- Earlier incomplete dev environment's80 failures/9 errors also reproduced onbase; documented
  dev install with pinned training packages repaired dependency/PATH issues. Preserve all history.
- Task Vast58239965 destroyed. Provider instance query19:36:50Z contains neither owned ID
  (earlier58148283 failed boot also absent). Posted charges USD0.565 at19:37:08Z; budget15.
- Evidence publication is separate from measured source and changes no product/harness/tests.
  No remote push/PR/shared-branch merge. Changelog text awaits the actual PR number only.
