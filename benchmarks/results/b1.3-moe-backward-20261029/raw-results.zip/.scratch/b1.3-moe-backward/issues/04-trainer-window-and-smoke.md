# 04: HF trainer windows and an end-to-end MoE L2L smoke

**What to build:** the L2L trainer subclass trains a per-expert DeepSeek-V3 model over several
optimizer steps (k=1 and k>1, short last window, mixed-length windows under the existing padding
contract, bf16 autocast) with results equal to plain HF accumulation on the resident eager model, and
logs expert loads. A smoke harness exercises reader/pool + L2L for k=1 and k>1 with repeated windows,
and the same smoke with the backward-only expert perturbation, emitting a JSON verdict usable on
CPU and CUDA.

**Blocked by:** 03

**Status:** done

**Owner:** sol-xhigh SolTrainer

- [x] E4: per-step gradients/losses exact for equal-length windows; uneven cases within fixed tolerance
- [x] E5 bf16 autocast exact in observed Trainer runs (fixed tolerance unchanged)
- [x] Expert-load counters in the training log
- [x] Integrated CPU and CUDA smoke PASS for k=1,2,4 and two optimizer updates each; real backward corruption fails gradient comparison with unchanged forward/loss
