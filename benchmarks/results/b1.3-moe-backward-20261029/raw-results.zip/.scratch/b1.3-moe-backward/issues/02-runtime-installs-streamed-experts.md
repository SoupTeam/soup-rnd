# 02: Streaming runtime installs streamed experts for a per-expert cache

**What to build:** `build_streamed_model`/`install_streaming` accept a per-expert cache: they open one
expert reader per MoE layer, one bounded pool (planned single slot, runtime device, cache dtype, NF4
code tables from extras), install streamed experts before layer weight maps are taken, own and close
readers/pool, and report expert fetches/bytes in `stats()`. A per-expert DeepSeek-V3 model with LoRA
on non-expert modules trains through the ordinary checkpointed streamed path with exactly the
resident eager result. Fused caches are unchanged; storage-only refusal replaced by honest refusals.

**Blocked by:** 01 for the backward half (forward half can start immediately)

**Status:** done

**Owner:** sonnet-xhigh (worktree `soup-rnd-b13-t02a`, branch `b13/t02a-runtime-install`)

- [x] Reusable test helpers: tiny per-expert DeepSeek-V3 checkpoint, streamed model builder, independent resident eager reference with identical LoRA weights
- [x] Forward: logits and loss `torch.equal` to resident eager (CPU fp32), dense and NF4 cache
- [x] E2: LoRA gradients `torch.equal` to resident eager through the checkpointed streamed path (after 01). Verified with t01's landed `expert_stream.py` overlaid on the t02a src; red in the t02a worktree alone until 01 is integrated.
- [x] Layer pool holds no routed-expert weights; expert fetch counters in `stats()`; `close()` closes readers and pool
- [x] Expert adapters (LoRA targeting routed experts) refused before any expert read. Verified against t01's landed installer (adapter check now precedes the shape check); 0 reads, readers and pool closed.
- [x] Old B1.1 refusal tests replaced by tests of the new boundary
