# 01: Streamed routed experts support backward with arena reloads

**What to build:** the B1.2 streamed-experts module becomes differentiable w.r.t. hidden states and
routing weights. Each hit expert is one autograd node whose backward re-leases the expert through the
same reader and bounded pool (one slot), rebuilds the eager expert body under the forward's autocast
state, and returns exactly the eager gradients. Nothing saved for backward aliases the arena. Routed
expert weights stay frozen. The installer is renamed from `install_expert_forward` to
`install_streamed_experts` (same validation semantics; all callers migrated).

**Blocked by:** None (can start immediately)

**Status:** done

**Owner:** sonnet-max (worktree `soup-rnd-b13-t01`, branch `b13/t01-expert-backward`)

- [x] E1 (spec): output, hidden grad and routing-weight grad `torch.equal` to resident eager for CPU fp32, bf16, fp32 under bf16 autocast, varied router top-k (1,2,4,8), partial/empty/all-hit routing
- [x] NF4 and nested NF4 backward equal an independently dequantized resident reference
- [x] Full DeepseekV3MoE block (router + correction bias + shared experts made trainable for the check): input, router weight and shared-expert grads equal eager
- [x] Backward reloads observable at the public reader/pool boundary: each hit expert read again in backward, unused experts never read
- [x] Arena reuse between forward and backward (other expert leases / another forward) does not change gradients; no lease active after backward; nested lease still refused
- [x] Load failure inside backward propagates and leaves the pool usable
- [x] Trainable routed weights and expert adapters/extra parameters refused with an honest B1.3 message; forward-only refusal removed
- [x] Negative control: expert weights perturbed only for loads inside autograd backward -> output equal, gradients differ; same inputs unperturbed -> equal
- [x] CUDA variants executed on RTX 3060 at 495b3882: all 16 current expert-backward cases passed, including dense/NF4/nested, dropout activation replay and autocast.
