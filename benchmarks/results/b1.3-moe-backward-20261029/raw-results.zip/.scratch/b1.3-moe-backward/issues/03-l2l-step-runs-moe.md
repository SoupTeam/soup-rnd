# 03: The L2L step runs per-expert DeepSeek-V3 models

**What to build:** `L2LStep` admits `deepseek_v3`; a window of k micro-batches loads each layer once,
runs streamed experts in the no-grad forward, then per (layer, micro-batch) recomputes under grad and
backpropagates, re-reading experts through the pool. Results equal resident eager gradient
accumulation bit for bit, including dropout replay. L2L load counters include expert loads. The public
launch guard still refuses everything except Llama/Mistral, with an honest message.

**Blocked by:** 01, 02

**Status:** done

**Owner:** sol-max SolL2L (continued preserved Sonnet partial work)

- [x] E3: k in {1,2,4}, dropout 0 and 0.05: per-mb losses, all LoRA grads and generator state `torch.equal` to resident eager GA
- [x] Different inputs and routing per micro-batch; some experts unused; shared experts active; router top-k varied
- [x] Repeated windows on one stepper and exception recovery equal GA; no stale state
- [x] SFT masked labels equal GA
- [x] Expert loads counted per step; backward reloads and reverse layer traversal observed
- [x] Backward-only weight corruption and broken RNG recompute both fail gradient comparisons

Integrated source 495b3882: combined CPU 457 passed/78 skipped; CUDA L2L-specific 14 passed
(within complete CUDA selection 77 passed/1 two-card skip). Raw evidence in b13-notes/final
and b13-notes/vast/results/final. Backward AMP suspension fixed causal bf16 mismatch;
activation RNG replay and explicit buffered-state refusal address independent review findings.
