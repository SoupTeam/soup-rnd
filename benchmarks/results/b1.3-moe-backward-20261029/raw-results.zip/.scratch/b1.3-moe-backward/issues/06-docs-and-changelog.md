# 06: Docs and changelog for the B1.3 boundary

**What to build:** existing docs describe what B1.3 supports and what stays refused (B1.4), with the
recorded verification; a changelog fragment is prepared without inventing a PR number.

**Blocked by:** 04, 05

**Status:** done

**Owner:** sol-xhigh SolTrainer (existing docs); integrator (publication staging)

- [x] Existing expert-forward page documents backward, reload counts, lifetime, runtime install and L2L
- [x] Current-boundary forward-only refusals corrected; historical B1.2 evidence preserved
- [x] Complete changelog item staged locally; real PR number required before validated fragment publication
