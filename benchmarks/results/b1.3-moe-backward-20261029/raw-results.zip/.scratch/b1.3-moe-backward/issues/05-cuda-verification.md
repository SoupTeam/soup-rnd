# 05: CUDA verification on a rented GPU

**What to build:** the gpu-marked B1.3 and L2L tests plus the smoke harness run on one rented CUDA GPU
(vast.ai, budget <= $15) from the exact integration source; results, environment and source identity
recorded; instance destroyed.

**Blocked by:** 01, 02, 03, 04

**Status:** done

**Owner:** integrator

- [x] Final source e691ffffc64349e53ce6d65b97ae7ab7ac2f1bd8, clean smoke trees recorded
- [x] CUDA selection: 86 passed, 1 skipped (second visible GPU), 121 deselected
- [x] Four CUDA smokes: targets30/32/44/46, k1/2/4, two updates; clean exact, all actual
  backward-only corruption gradient comparisons fail while forward/loss stay exact
- [x] Configured full dev suite: coverage86.74% >77%; 36,488 passed/234 skipped/2 xfailed/
  12 deselected/20 failed. All20 failed nodes also fail on fixed9d8b base in the same environment.
- [x] Task instance58239965 destroyed; final provider query also finds prior58148283 absent.
  Posted owned-task charges USD0.565 at2026-10-29T19:37:08Z; budget USD15. No active task rentals.

Final raw records: `b13-notes/final/source-e691ffff/`, `full-dev-configured-e691ffff/`,
`base-configured-residuals/`, `vast-destroy-confirmed.*`, `vast-final-state.json`,
`vast-task-cost.json`. Provider billing lag, if any, is not guessed.
