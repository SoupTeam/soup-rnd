# 07: Standards and Spec reviews

**What to build:** two independent reviews of the integration diff against base `9d8b1d7b`, by agents
that did not author the reviewed code; confirmed findings fixed and re-verified.

**Blocked by:** 01, 02, 03, 04, 06

**Status:** done

**Owner:** sol-xhigh SolStandards/SolStandardsFinal and sol-max SolSpec/SolSpecFinal
(independent, non-authors).

- [x] Standards APPROVE: lazy collection/PEFT construction, shared fixture/no shim, and all added
  function/callback/test annotations closed; final e691ffff annotation diff independently checked.
- [x] Spec APPROVE: embedding A/B VJP and combined native-head/decoder dropout replay repaired;
  independent original-ID/lifetime/NEFTune/frozen-fast-path probe passes.
- [x] Confirmed findings fixed; final clean e691ffff CPU476/87, CUDA86/1, eight actual smokes
  (targets30/32/44/46, k1/2/4, two updates), full Ruff and diff whitespace all pass.

Reports: `b13-notes/final/standards-final-review.md`, `spec-final-review.md`.
Spec numerical review source34b9 remains attributed to34b9; final e691 execution is separate
integrator evidence, not reassignment of earlier measurements.
