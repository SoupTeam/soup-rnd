# B1.3: MoE backward with streamed expert reloads, integrated with L2L

Status: implemented and independently reviewed; all five B1.3 AC verified on CPU/CUDA.
Full repository has20 baseline-reproduced failures, recorded separately. Base: SoupTeam/soup-rnd
`origin/main` `9d8b1d7b` (contains B1.2, PR #25,
`fdf067fc`; A3 L2L SFT trainer, PR #34). Integration branch: `b1.3-moe-backward`
(worktree `C:/Users/sydyk/Downloads/soup-rnd-b13`). Tickets: `issues/`.
Shared notes for agents: `C:/Users/sydyk/Downloads/b13-notes/` (env, prior art).

## Problem Statement

B1.2 streams routed MoE experts one at a time through a single bounded weight arena, but only
forward: a gradient-bearing input under autograd is refused ("B1.2 is forward-only; expert backward
requires B1.3"), and the streaming runtime refuses per-expert caches outright. The L2L step (one
layer load per accumulation window, RNG replay of dropout) only admits Llama/Mistral. A DeepSeek-V3
MoE model whose routed experts live in a per-expert cache therefore cannot be trained at all, and in
particular not through L2L.

## Solution

Routed experts in a per-expert cache become trainable-through (not trainable themselves): forward
and backward through the streamed experts produce exactly the gradients the resident eager MoE
produces for hidden states, routing weights and every supported trainable parameter (LoRA on
non-expert modules), while expert weights are only ever resident one at a time in the bounded arena
and are re-read from the cache whenever backward needs them. The internal streaming runtime installs
these streamed experts for a per-expert cache, and the internal L2L step/trainer boundary runs
DeepSeek-V3 MoE models with the same forward / recompute / reload / accumulation-window semantics it
has for dense models. Public YAML/CLI, the planner, budgets and defaults are unchanged (B1.4).

## User Stories

1. As an RND engineer, I want a streamed-experts module to support autograd, so that a loss can be backpropagated through routed experts that are not resident.
2. As an RND engineer, I want backward to re-read each routed expert it needs through the existing reader and the bounded pool, so that no hidden resident copy of all experts exists.
3. As an RND engineer, I want only experts that received tokens to be read in forward and in backward, so that unused experts cost nothing.
4. As an RND engineer, I want the gradient w.r.t. hidden states to equal the resident eager MoE bit for bit, so that streaming changes no training result.
5. As an RND engineer, I want the gradient w.r.t. routing weights to equal the resident eager MoE bit for bit, so that the router's influence on lower layers is preserved.
6. As an RND engineer, I want routed-expert base weights to stay frozen and never receive or allocate gradients, so that the frozen-base contract holds.
7. As an RND engineer, I want values saved for backward never to alias the reusable arena, so that loading another expert cannot corrupt a pending backward.
8. As an RND engineer, I want backward to re-enter the forward's autocast state when it recomputes an expert, so that mixed-precision gradients match eager.
9. As an RND engineer, I want dense, NF4 and nested-NF4 expert storage to work in backward, so that the B1.2 storage matrix stays supported.
10. As an RND engineer, I want router, correction bias and shared experts to remain the original modules, so that their arithmetic and gradients are the native ones.
11. As an RND engineer, I want adapters on routed experts and trainable routed-expert weights refused with an honest message, so that unsupported training is never silent.
12. As an RND engineer, I want the internal streaming runtime to install streamed experts for a per-expert cache before it maps layer weights, so that the layer pool never allocates routed-expert weights.
13. As an RND engineer, I want the runtime to own and close the expert readers and pool, so that resources are released with the runtime.
14. As an RND engineer, I want runtime statistics to expose expert fetches and logical bytes, so that reloads are observable.
15. As an RND engineer, I want an ordinary (checkpointed) streamed forward/backward of a per-expert DeepSeek-V3 model to equal the resident eager model, so that the non-L2L path is honest too.
16. As an RND engineer, I want the L2L step to admit DeepSeek-V3, so that MoE models can use layer-major accumulation.
17. As an RND engineer, I want L2L forward, per-layer recompute, expert reload and accumulation window to agree in order and state, so that repeated steps never see stale state.
18. As an RND engineer, I want L2L with k=1 and k>1 micro-batches (k in {1,2,4}) to equal resident eager gradient accumulation, so that L2L is a pure schedule change.
19. As an RND engineer, I want micro-batches with different inputs and different routing in one window, so that per-micro-batch routing replay is exercised.
20. As an RND engineer, I want router top-k varied independently of k, so that both quantities are covered.
21. As an RND engineer, I want LoRA dropout and eager attention dropout replayed by L2L on DeepSeek-V3 so that recompute draws the same masks as accumulation and the outer stream ends where accumulation leaves it.
22. As an RND engineer, I want SFT label masking and the existing mixed-length padding contract to hold for MoE, so that supported masked/uneven cases keep working.
23. As an RND engineer, I want consecutive windows/optimizer steps through the HF trainer subclass to equal plain accumulation, so that the trainer boundary is covered.
24. As an RND engineer, I want a negative control that perturbs expert weights only on backward reloads to fail the reference comparison by gradients, so that the comparison is proven sensitive to the backward path.
25. As an RND engineer, I want a negative control that breaks RNG replay at nonzero dropout to fail the comparison, so that the replay is proven necessary on MoE.
26. As an RND engineer, I want a smoke run on a tiny MoE through reader/pool + L2L for k=1 and k>1 plus its negative control, so that the changed path is exercised end to end.
27. As an RND engineer, I want CUDA variants of the critical checks, so that GPU behaviour is verified, not assumed.
28. As a maintainer, I want the public launch guard, YAML and CLI unchanged, so that B1.4 owns public enablement.
29. As a maintainer, I want docs and a changelog fragment describing the new internal boundary, so that the support contract is discoverable.

## Implementation Decisions

- **Expert autograd node (expert streaming module).** Each hit expert is one custom autograd node
  computing `act(gate) * up -> down -> * routing_weight` on the already-gathered token slice and
  routing-weight slice, inside a pool lease. The gathers (`hidden[token_idx]`,
  `weights[token_idx, top_k_pos, None]`), the `.to(final.dtype)` cast and `index_add_` stay outside
  the node, in eager order and ascending expert order, so the graph around the node matches eager.
- **Saved state.** The node saves only the gathered hidden slice and routing-weight slice (activation
  memory, not arena). It never saves arena views; its outputs are fresh tensors. It records the
  forward's autocast state (enabled, dtype, cache) for the pool's device type, and the expert id.
- **Backward.** Unpack saved tensors first (this may trigger a checkpoint recompute that itself leases
  experts), then lease the expert again through the same reader and pool, rebuild the local graph
  with the arena weights as constants under the recorded autocast state, and take gradients only for
  inputs that need them. The lease ends before the gradients leave the node. Autograd differentiates
  the same ops eager uses; no hand-written derivative.
- **Forward-only refusal removed**; refusals that remain: trainable routed-expert weights, adapters or
  extra parameters on routed experts, reader/pool mismatch, malformed routing. Messages state the
  B1.3 boundary (non-expert adapters only) without claiming B1.4 features.
- **Runtime install.** For an index with `expert_layout == "per_expert"`, the internal streaming
  runtime opens one reader per MoE layer from the index's expert paths/count/shapes/quant specs,
  builds one pool at the runtime device and stream compute dtype with NF4 code tables from extras,
  budget = the planned single slot, and installs streamed experts into the decoder layers before
  layer weight maps are taken. The runtime owns readers and pool, closes them in `close()`, and
  reports expert fetches/bytes in `stats()`. The storage-only refusal is replaced by these honest
  refusals. Fused caches are unchanged.
- **L2L.** The step admits `deepseek_v3` in addition to Llama/Mistral; the public launch guard
  (`refuse_unsupported_l2l`) keeps refusing every architecture outside Llama/Mistral (B1.4).
  L2L counters gain expert loads from the runtime. RNG replay reuses the existing capture/fork
  mechanism and includes actual native-head draws between each micro-batch's decoder draws.
  Trainable embeddings receive an immediate per-micro-batch VJP with their original forward RNG.
  Native DeepSeek expert activations are deterministic; accepted stateless stochastic activations
  fork the recorded CPU/CUDA state during expert backward without consuming the outer stream.
- **Reads per expert visit** (accepted cost of a one-slot arena): ordinary checkpointed path:
  forward + checkpoint recompute + backward; L2L: no-grad forward + grad recompute + backward. No
  read-avoidance tricks in B1.3.
- **No public switch.** No YAML/CLI field, planner, budget option or default change.

## Testing Decisions

Good tests compare against an independent resident eager reference on identical weights, inputs,
seeds, dtype and trainable state, through public seams, with non-degenerate data (no all-zero
gradients, routing that differs across micro-batches, some unused experts, shared experts active).

Pre-registered exactness criteria (fixed before any result; never loosened to pass):

- **E1 block** (streamed experts and full DeepSeek-V3 MoE block vs resident eager): CPU fp32, CPU bf16
  compute, CPU fp32 under bf16 autocast, NF4 nested on/off vs independently dequantized resident:
  `torch.equal` on output, hidden grad, routing-weight grad (block: also router/shared grads when
  made trainable for the check). Zero tolerance.
- **E2 model** (per-expert streamed DeepSeek-V3 + LoRA, ordinary checkpointed path) vs resident eager:
  CPU fp32 `torch.equal` on logits, loss and every LoRA gradient.
- **E3 L2L step** (k in {1,2,4}; dropout 0 and 0.05; two consecutive windows) vs resident eager GA:
  CPU fp32 `torch.equal` on per-micro-batch losses, every LoRA gradient, and generator state after
  the window.
- **E4 trainer** (HF loop, several optimizer steps, short last window) vs plain HF Trainer GA on the
  resident eager model: CPU fp32 `torch.equal` on per-step gradients and losses. Mixed-length
  windows (padding) use the existing contract tolerance `atol=2e-5, rtol=1e-4` from
  `test_windows_with_rows_of_different_lengths_match_accumulation`, with max diff reported.
- **E5 bf16 model level**: tolerance of the existing dense bf16 L2L trainer contract
  (`atol=1e-6, rtol=1e-5`), measured max diff reported, exact equality reported when observed.
- **CUDA**: same criteria with `torch.use_deterministic_algorithms(True)` and
  `CUBLAS_WORKSPACE_CONFIG=:4096:8`, `@pytest.mark.gpu`.

Seams (existing preferred): (1) streamed experts module forward/backward and `install_streamed_experts`;
(2) internal runtime `build_streamed_model`/`install_streaming` + `StreamRuntime.stats/close`;
(3) `L2LStep.run` and `make_l2l_trainer_class` + `attach_l2l_state` with HF accumulation;
(4) reader/pool public boundary (`reader.fetches`, `reader.read_host`, `pool.fetches`, `pool.stats`,
arena storage pointer) for observable reloads and bounded lifetime.

Negative controls (test-only, deterministic, no product switch): (a) perturb expert weights only on
loads that happen inside autograd backward (detected via `torch._C._current_autograd_node()` in a
test wrapper around the public reader/pool load) -> gradients must differ from the reference while
the unperturbed run on the same inputs passes; (b) break RNG replay at dropout 0.05 (e.g. state not
applied on the recompute) -> gradients must differ.

Prior art: `tests/test_b1_expert_forward.py`, `tests/test_l2l_step.py`, `tests/test_l2l_rng.py`,
`tests/test_l2l_trainer_window.py`, `tests/test_l2l_trainer_mode.py`,
`tests/test_b2_deepseek_v3_stream.py` (tiny DeepSeek-V3 fixture, resident parity),
two-read branch notes in `b13-notes/two-read-prior-art.md` (different API; no L2L).

## Out of Scope

Planner, public YAML/CLI switches, budgets and defaults (B1.4); enabling L2L for DeepSeek-V3 in the
public launch guard; training routed-expert weights or adapters on routed experts; read-avoidance
optimizations (two-read/zero-output recompute), async prefetch, throughput claims; architectures
other than DeepSeek-V3 for per-expert storage; trained-checkpoint gates; multi-GPU.

## Further Notes

Exactness argument: per-parameter accumulation order in L2L equals accumulation (micro-batch order
per layer), and the graph around each expert node matches eager, so gradient contributions reach
each buffer in the same order. Any inexactness is a defect to investigate, not a tolerance to add.
