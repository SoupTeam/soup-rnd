# B1.3 changelog publication text

Not a validated changelog fragment: the real PR number is not assigned here.

Publication step: obtain the actual B1.3 PR number, then write the text below to
`changelog.d/0.75.1/<PR>.added.md`, substituting that number in the filename and text.
Do not invent a PR number or place this staging file in the validated fragment folder.

## Fragment text

- **B1.3: internal streamed MoE backward (#<PR>).** Support first-order backward
  through frozen native DeepSeek-V3 routed experts, reloading weights through
  one bounded expert arena. Install per-expert caches in the internal runtime
  and run the existing L2L step/trainer with non-expert LoRA, expert-load counters,
  RNG replay and consistent autocast recomputation. Routed-expert weight training
  and adapters remain refused. Public L2L launch stays Llama/Mistral; planner,
  YAML/CLI fields, budgets and defaults remain B1.4. Add a standalone synthetic
  CPU/CUDA smoke against resident eager gradient accumulation with a real
  backward-only corruption control. The expert arena is not a total-VRAM bound.
