# Standards review — CHANGES REQUESTED

Reviewed the entire packaged diff for `9d8b1d7b...495b3882`, all 21 changed files, against root AGENTS.md, CONTRIBUTING.md, docs/agents/* and changelog.d/README.md. Static review only; no suites rerun or repository changes.

## Documented-standard breaches

1. **P2 — Collection-time heavy imports bypass the prescribed lazy boundary.** `tests/test_b13_l2l_moe.py:30` and `tests/test_b13_moe_runtime.py:50` introduce module-level `import torch`. Runtime tests also execute `sorted(_expert_adapter_configs())` during collection (`:826`), importing PEFT before their training-floor skip marker can act. AGENTS.md:21 says heavy dependencies are imported inside functions, “never at module top”; CONTRIBUTING.md:84 repeats that rule. Keep dependency loading inside test/fixture execution, including parameter construction, so unavailable training dependencies do not prevent collection. The existing lazy B1/L2L CPU tests provide the pattern. This is not a Ruff-enforced rule.

2. **P3 — Newly introduced interfaces omit required annotations.** CONTRIBUTING.md:88 requires type hints for function parameters and return values. Examples include production `RoutingGuard.__init__` (`src/soup_cli/utils/l2l_step.py:182`, missing `-> None`), `ReadProbe._wrap/reset/close`, `_read_evidence`, `_logits`, and `main(argv)` (`benchmarks/harness/b13_moe_backward_smoke.py:107–161,318`), and the trainer comparison helpers (`tests/test_b13_moe_trainer.py:36,86`). Annotate the added signatures consistently; Ruff’s configured E/F/I/N/W rules do not cover this requirement.

## Heuristic judgement — not a documented violation

3. **P2 — Duplicated Code in shared fixture construction.** `benchmarks/harness/b13_moe_fixture.py:55–118` repeats the config, checkpoint randomization, LoRA construction/nonzero-B initialization and resident-adapter copying from `tests/test_b13_moe_runtime.py:65–120,129–139,185–199,291–318`. The new fixture explicitly says, “The sizes/seeds follow test_b13_moe_runtime’s fp32 fixture.” This duplicates the evolving training-state contract, not an independent mathematical oracle. Extract the common construction into a pytest-free support module usable by both; keep resident eager execution and comparisons independent. Otherwise fixture fixes require synchronized edits and smoke/test coverage can drift.

The numerical tests exercise real consumer behavior and actual backward corruption; no duplicated product implementation or mock-assertion echo was found. No missing-changelog finding: the user explicitly defers the numbered fragment until a real PR number exists.
