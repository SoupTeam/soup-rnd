# B1.3 Spec closure — APPROVE

## Scope and provenance

Independent, read-only closure of the two P1 Spec findings on frozen
`34b9f372171189d02a39002383ee1ba28737d04e`, against the original five acceptance criteria
and `.scratch/b1.3-moe-backward/spec.md`. Read `AGENTS.md`, `CONTRIBUTING.md`, both prior
reviews, the complete fix-wave diff, author report, affected implementation/tests/harness and
relevant native PEFT/Transformers behavior. This is not a second broad audit.

The integrator subsequently identified `e691ffffc64349e53ce6d65b97ae7ab7ac2f1bd8` as an
annotation/lazy-test-import closure with unchanged production/harness. I read
`annotation-closure.diff`: it does not change numerical assertions, expectations or execution
arithmetic. Results below are attributed to **34b9**, not relabeled as final-SHA proof. The
older author's dirty-source `fix-wave-*` records remain supporting history only.

## Original findings

### 1. Missing embedding LoRA A/B gradients — ADDRESSED

Required: “every supported trainable parameter (LoRA on non-expert modules)”
(`spec.md:19–25`; original AC3:75–77).

`src/soup_cli/utils/l2l_step.py:367–376,408–440` now retains the gradient reaching each
layer-0 input and performs a real embedding-output VJP against **that micro-batch's original
IDs**. Recompute calls the actual streamed embedding, not a resident replacement or a manual
derivative. Each recompute is immediately differentiated before the next micro-batch.

The existing backward-tail refill is explicitly requested at `:430–432`, including for a
single-layer walk. `StreamedLargeLayer.forward` obtains the owned arena view through
`pool.wait` (`layer_stream_runtime.py:1829–1847`); the existing loader orders refills after
queued compute and waits for completion (`:1174–1204`). No refill occurs between an embedding
recompute and its VJP. No expert-resident copy or new runtime seam was introduced.

Embedding RNG is saved before each original lookup only when embeddings are trainable;
`state_at` restores it for recompute and restores the surrounding stream afterward. With the
existing supported NEFTune/no-dropout configuration this reproduces the original noise without
extra outer draws. Ambient forward autocast is retained; embedding backward explicitly disables
CPU/CUDA autocast (`l2l_step.py:434–440`), matching head/decoder backward. Frozen embeddings skip
both saved RNG and the extra VJP, retaining the existing lookup/load path.

### 2. Decoder-plus-head dropout loses head RNG draws — ADDRESSED

Required: replay CPU/CUDA/dropout state (original AC3:75) and exact E3 losses, all gradients and
final generator state (`spec.md:108–110`).

`capture_layer_call` observes the **native head** after decoder layers and retains its actual
functional-dropout metadata separately (`l2l_step.py:139–172`). The plan is now
`decoder0 … decoderL−1, head` for **each reference micro-batch** (`:362–366`;
`l2l_rng.py:172–194`). Decoder forward/recompute and each stochastic head execute at their
recorded states; the outer stream is left at the complete schedule end (`l2l_step.py:390–403,
443–444`). Shared-expert draws remain inside their native decoder call.

The head takes the RNG wrapper only when `head_draws` is nonempty (`:390–393`), preserving the
draw-free-head path. Vanilla installed PEFT embedding LoRA does not invoke its registered
dropout (`peft/tuners/lora/layer.py:1487–1538`); the fix correctly does not invent embedding draws.

**Unaddressed original Spec findings: none.**

## Permanent coverage and oracle independence

- The shared fixture owns construction, checkpoint/adapter copying and nonzero initialization,
  not the mathematical oracle. The reference independently loads native Transformers eager
  experts; reference GA is ordinary native forward/loss/backward per micro-batch, with no
  streamed/L2L execution (`b13_moe_fixture.py:112–135`; `test_b13_l2l_moe.py:242–271`).
- All `requires_grad` parameters are collected, including embedding A/B, shared experts and
  head, rather than filtering back to MLA. Boundary cases assert **32/44/46 nonzero gradients
  in both arms**, exact losses/gradients/RNG, k=1/2 and A,B,A windows on the same stepper/store
  (`test_b13_l2l_moe.py:446–504`). NEFTune 0.2 and embedding forward-bf16-AMP are included.
  CUDA uses the same native oracle and boundary assertions (`test_b13_l2l_moe_cuda.py:122–151`).
- Ordinary checkpointed E2 now covers 30/32/44/46, all configured gradients nonzero and exact
  (`test_b13_moe_runtime.py:745–776`). Real HF Trainer cases exercise 32/44/46 over three
  optimizer updates, k=1/2 and short last windows, checking gradients, loss, trained state and
  outer RNG (`test_b13_moe_trainer.py:92–146,189–222`).
- Standalone targets 30/32/44/46 run k=1/2/4 with two genuine SGD updates per k. Their negative
  arm changes returned expert down-matrix staging **only inside real autograd backward**,
  before either optimizer updates. The actual computed gradient comparison must fail while
  native forward/loss still match (`b13_moe_backward_smoke.py:125–146,235–350`). The same runs
  require reverse traversal, positive backward reloads, three reads per visit and a stable
  bounded one-slot expert arena. PASS/FAIL is computed, not injected.

No tolerance was weakened: fp32 remains `torch.equal`; the added AMP comparison uses only the
predeclared E5 `atol=1e-6, rtol=1e-5`. Existing uneven-window tolerances/refusals and
NEFTune-plus-dropout refusal remain unchanged. No supported target is newly refused or excluded.
The public architecture guard, product YAML/CLI, planner and frozen routed-expert boundary are
unchanged. Benchmark-only target selection does not expose B1.4 training enablement.

## Evidence inspected

Fresh integrator records in `final/reverified/` identify source **34b9**:

- `cpu-targeted.json/.log/.xml`: **476 passed, 87 skipped**, exit 0.
- `gpu-targeted.json/.log/.xml`: **86 passed, 1 skipped**, exit 0; the skip requires two visible
  CUDA cards. CUDA environment is RTX 3060, torch 2.14.1+cu130, Transformers 5.19.0, PEFT 0.21.2.
- JUnit boundary cases record 32/44/46 nonzero tensors in each arm, zero maximum loss/gradient
  differences and equal RNG. Embedding+NEFTune and CPU/CUDA embedding forward-AMP cases pass;
  AMP differences were observed zero, not merely within tolerance. All six new Trainer cases
  record zero gradient/loss/trained-state differences and equal outer RNG. The existing
  draw-free-head layer-major-RNG negative control also passes unchanged.

I reduced all eight clean-source smoke JSONs (`cpu|gpu-smoke-default|embedding|head-shared|all-
evidence.json`). Every file records `sha=34b9…`, `dirty=false`. Across **48 clean windows and
48 actual backward-corrupted windows**, clean logits/loss/gradients/trained state are exact,
all configured gradients are nonzero in both arms, outer RNG agrees, reverse visits and
three-read accounting hold, backward reloads are positive, and the arena remains bounded.
Every corrupted window preserves forward/loss and fails by computed gradients:

| Target | Nonzero gradient tensors, both arms | CPU corrupted max-gradient-difference range | CUDA range |
| --- | ---: | ---: | ---: |
| MLA | 30 | 0.498075–4.197987 | 0.498075–4.197973 |
| Embedding + MLA | 32 | 0.911452–3.611841 | 0.911449–3.611841 |
| MLA + shared + head, dropout .05 | 44 | 0.829358–3.273990 | 0.684125–2.408230 |
| Combined, dropout .05 | 46 | 2.034620–10.373321 | 1.866372–14.119805 |

### Independent focused consumer probe

I ran one throwaway `python.exe -B -c` subprocess against the current local source, reusing an
existing synthetic checkpoint/cache read-only. It wrote no script, cache checkpoint or source
file, used a separately loaded native eager reference with ordinary GA, and observed the
streamed embedding and large-slot loader. Exit **0**.

At k=2 over two consecutive windows, frozen MLA30/dropout .05, embedding32+NEFTune .2, and
combined46/dropout .05 each had exact losses, all 30/32/46 nonzero gradients and exact outer
RNG. Capture also preserved RNG. Original-ID object identity was observed at both no-grad
lookups and the corresponding grad-enabled recomputes. For trainable embeddings the event
sequence was recompute(mb0), backward(mb0), recompute(mb1), backward(mb1), with embedding slot
ownership and **no intervening refill**; noisy recompute outputs exactly equaled their original
outputs. Frozen embeddings had only the two no-grad calls. All configurations used the same
large-load pattern: three actual refills on the first measured window and two on the next.
The combined case captured decoder draw counts **5/8/8 plus one head draw**; frozen MLA30
captured **5/5/5 plus zero head draws**. This probe confirms consumer behavior, not source text.

## Verdict

**APPROVE.** Both original P1 findings are addressed end to end. No actual new in-scope
fix-wave regression was found. No repository edits, Git/cloud operations, build/lint/broad-suite
reruns or subdelegation were performed by this reviewer. Final-SHA execution evidence remains
the integrator's separate responsibility; the supplied dirty-source and 34b9 records are not
misrepresented as e691 proof.
