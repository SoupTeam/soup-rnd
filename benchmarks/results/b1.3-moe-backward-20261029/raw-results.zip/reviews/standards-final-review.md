# B1.3 final Standards closure — APPROVE

## FINAL review — `e691ffffc64349e53ce6d65b97ae7ab7ac2f1bd8`

**APPROVE. All three original Standards findings are addressed.** No unresolved documented-standard breach or actual new regression was found in this scoped closure review.

The integration owner supplied annotation correction `36c0710b`, merged into final source `e691ffffc64349e53ce6d65b97ae7ab7ac2f1bd8` at the same integration worktree. Independently read all of `annotation-closure.diff` (`34b9f37..e691ffff`, four test files), then checked the final declarations against every remaining item recorded below. Earlier finding-1/finding-3 closure is retained: the annotation correction changes no product, harness, shared construction or mathematical-oracle code.

| Original finding | Final status | Final closure evidence |
| --- | --- | --- |
| 1. Lazy torch/PEFT collection boundary | **ADDRESSED** | Earlier runtime/L2L closure remains unchanged. The primitive CUDA module additionally removes its collection-time `pytest.importorskip("torch")`; torch is now loaded inside `deterministic_kernels` (`tests/test_b13_expert_backward_cuda.py:50–57`). Central `gpu` marker skipping remains in `tests/conftest.py:139–150`. |
| 2. Annotations for added signatures | **ADDRESSED** | Every CPU primitive helper, nested callback and test entry point listed in this report is annotated in the final file, including generator/context-manager return contracts. `tests/test_b13_expert_backward.py:52–196,225–310,337–465,495–735,755–915,946–1118` covers the repaired declarations. All seven primitive CUDA declarations are annotated (`test_b13_expert_backward_cuda.py:51–112`). The three additional B1 entry points are annotated at `test_b1_expert_forward.py:329–331` and `test_b1_expert_shard.py:441–443,460–462`, as are the latter test's nested `unexpected`/`meta_skeleton` callbacks (`:467–474`). |
| 3. One pytest-free construction owner/native oracle independence/no shims | **ADDRESSED** | The construction/caller changes reviewed at `34b9f37` are untouched by the final four-test-file correction. The independently loaded native eager reference and its ordinary GA execution remain separate from streamed/L2L arithmetic. |

### Correction safety and evidence boundary

- The complete supplied correction diff changes annotations and their supporting standard-library/type-checking imports, plus the CUDA torch-import timing described above. It does **not** change any callback body, computation, assertion, expected value, tolerance, parametrized case, corruption mechanism or frozen-expert condition.
- CPU primitive tensor/module annotations use postponed evaluation (`from __future__ import annotations`) and `if TYPE_CHECKING: import torch` (`test_b13_expert_backward.py:16,23,35–36`), so the new annotations do not load torch during collection. The existing B1 files also retain postponed annotations.
- No behavior change was found beyond intentional dependency loading during the GPU fixture rather than module collection. No new compatibility shim, fixture owner, product setting or oracle coupling is introduced.
- This final verdict is **static Standards closure**, not a numerical test result. No repository edits, Git operations, builds, lint or tests were run by this reviewer. Previously reported CPU/CUDA/smoke results for `34b9f37`, and the author's dirty-source results, are not attributed to `e691ffff`. Fresh exact-final-source verification remains the integration owner's separate evidence.

## Historical `34b9f37` review — CHANGES REQUESTED

The following records preserve the original frozen-source findings and exact repair list. Their open-status wording applies only to `34b9f37`; all listed annotation gaps are closed in the FINAL assessment above.

### Historical scope and source

Read-only review of the supplied frozen integration source `34b9f372171189d02a39002383ee1ba28737d04e` in `C:/Users/sydyk/Downloads/soup-rnd-b13`, concentrating on the three accepted Standards findings and the complete nine-file `495b3882..34b9f37` fix wave. The original base is `9d8b1d7b4b3eabc1634a1f6c2318814c640535c3`. This is not a second broad audit.

Read AGENTS.md, CONTRIBUTING.md, applicable agent/changelog guidance, the original prompt and B1.3 specification, both previous reviews, `fix-wave-report.md`, `fix-wave-integrated.diff`, and the affected source/caller context. The previous packaged base diff establishes that the remaining primitive test signatures below were introduced by B1.3, rather than inherited from the base.

No repository edits, Git operations, builds, lint, tests, cloud actions or subdelegation were performed. The only written file is this report. Author results in `fix-wave-report.md` remain **dirty-source author evidence**, not fresh numerical verification of `34b9f37`; the integrator owns exact-source CPU/CUDA verification.

### Original findings at `34b9f37`

| Finding | Closure at `34b9f37` | Evidence |
| --- | --- | --- |
| 1. Collection-time torch/PEFT loading in the new runtime/L2L tests | **ADDRESSED** | `tests/test_b13_moe_runtime.py:33–48` and `tests/test_b13_l2l_moe.py:20–42` no longer import torch at module scope. Torch imports are inside actual consumers. Runtime refusal cases use string parametrization (`test_b13_moe_runtime.py:712`), and `_expert_adapter_config` imports/constructs PEFT only when the test calls it (`:698–711,734`). The CUDA L2L autouse fixture imports torch during fixture execution (`tests/test_b13_l2l_moe_cuda.py:24–34`). Shared fixture module scope contains only standard-library imports/constants. The training-floor marker reads package metadata, not training modules (`tests/test_issue502_qwen35_transformers5.py:43–71`). The supplied unavailable-dependency collection probe is behavioral rather than a source-string test, but its reported 107 collected result belongs to the author's dirty source. |
| 2. Type annotations on added signatures | **UNADDRESSED IN PART** | The originally cited `RoutingGuard.__init__`, smoke `ReadProbe` methods, `_read_evidence`, `_logits`, `main`, and Trainer helpers/callbacks are annotated. The changed runtime/L2L helper and test interfaces are also annotated. However, the B1.3-added primitive CPU/CUDA test modules still have unannotated function parameters and returns. Exact remaining declarations are listed below. This leaves the original finding open; it is not a new fix-wave regression. |
| 3. One pytest-free construction owner, caller migration/no shims, independent native execution | **ADDRESSED** | `benchmarks/harness/b13_moe_fixture.py:36–143` now owns config/checkpoint construction, randomized expert/router weights, LoRA config, nonzero adapter initialization (including both embedding factors), copying, native resident construction and batch generation. Duplicated runtime setup and old helper names/constants were removed; runtime, CPU/CUDA L2L and Trainer consumers use the shared owner directly. Runtime-specific sharding/NF4 reference setup remains at its existing test seam. Shared construction does not share the mathematical execution under test: `resident_base` independently calls native `AutoModelForCausalLM.from_pretrained(..., experts_implementation="eager")` (`:112–126`), resident GA calls that native model and `loss.backward()` (`tests/test_b13_l2l_moe.py:242–271`; smoke `:240–250`), while only the actual arm calls `L2LStep.run`. No compatibility re-export chain or pytest dependency was introduced in the fixture/harness. |

### Historical remaining finding

**P3 — Finish annotations on B1.3-added test interfaces.** CONTRIBUTING.md:88 requires type hints for function parameters and return values; the configured Ruff E/F/I/N/W rules do not enforce this. The accepted fix contract also explicitly covers newly added test/helper signatures, not only the examples quoted in the first review.

Concrete scenario: maintainers or the CUDA module reuse `exact_backward_case`, `check_block_backward`, `check_negative_control` or `check_activation_rng_replay`, but their device/dtype/routing/callback and return/yield contracts remain entirely untyped. The unchanged primitive files are new in the original B1.3 diff, so this is an incomplete repair of an existing documented-standard finding. This is **not** a claim of a numerical/runtime failure.

**Smallest in-scope fix:** add parameter and return annotations to the declarations below, using postponed annotations plus standard-library `Any`, `Path`, `Callable`, `Sequence` and `Iterator`/context-manager types where appropriate. Annotate nested reader/hook/probe callbacks too. Preserve their bodies, lazy dependency boundary, assertions and tolerances; no refactor, product change or new tests are needed for this finding.

### Exact remaining declarations at `34b9f37`

All function declarations in these two B1.3-added files lack parameter/return annotations (implicit `self` is not the concern).

`tests/test_b13_expert_backward.py` — helpers and nested callbacks:

- `46: _upstream(like)`
- `54: _region(device_type, active)`
- `62: _run(module, args, *, amp=None, needs=("hidden", "weights"), checkpoint=None)`
- `89: _same(a, b)`; `97: _parts(want, got)`; `106: _assert_exact(want, got)`
- `111: _assert_signal(run)`; `118: _hit(args)`; `122: _close(*resources)`
- `134: _Loads.__init__(self, monkeypatch, reader)`; `143: read_host(expert, staging)`
- `156: _Loads.outside(self)`; `159: _Loads.inside(self)`
- `163: _perturb_down(expert, host)`
- `175: exact_backward_case(tmp_path, *, device, dtype, nf4=False, nested=False, **routing)`
- `310: _run_block(block, hidden, *, amp)`; `320: _moe_block(device, dtype)`
- `343: check_block_backward(tmp_path, *, device, dtype, nf4=False, nested=False, amp=False)`
- `429: grads_of(model)`; `526: twice(target)`; `590: chain(one, two)`
- `613: check_arena_churn(tmp_path, *, device, dtype)`
- `660: pack(tensor)`; `693: unpack(tensor)`
- `803: check_negative_control(tmp_path, monkeypatch, *, device, dtype, nf4=False, nested=False)`
- `856: _routed_holder(module)`; `975: _rng_equal(left, right)`
- `984: check_activation_rng_replay(tmp_path, *, device, stochastic, checkpoint=None)`
- `1004: exercise(target)`

Its test entry points likewise need parameter annotations and `-> None`: lines **204, 221, 241, 258, 285, 388, 398, 459, 493, 519, 548, 578, 645, 649, 680, 713, 739, 755, 771, 839, 866, 899, 926, 946, 1052, 1062**.

`tests/test_b13_expert_backward_cuda.py`:

- `50: deterministic_kernels()` — yielded fixture, requiring a generator/iterator return annotation.
- Test entry points at **58, 73, 79, 84, 96, 106** — annotate fixture/parameter arguments and `-> None`.

The original B1.3 diff also adds these untyped test entry points in existing files (their neighboring inherited helpers are not being reopened):

- `tests/test_b1_expert_forward.py:328`: `test_forward_builds_no_graph_under_no_grad_or_without_a_grad_bearing_input(tmp_path)`.
- `tests/test_b1_expert_shard.py:441`: `test_runtime_refuses_an_expert_layout_it_cannot_stream_before_touching_the_model(layout)`.
- `tests/test_b1_expert_shard.py:458–460`: `test_model_builder_refuses_an_unknown_expert_layout_before_materializing_weights(monkeypatch, layout)`.

Each needs the fixture/parameter annotations and `-> None`. The renamed/modified inherited declaration at `test_b1_expert_forward.py:309` was already untyped before this branch; it is not counted as an additional newly added signature.

### Historical fix-wave regression and maintenance review

**No actual new fix-wave regression found in this scoped static review.** This is not a claim that numerical verification was run.

- Product changes keep imports lazy and reuse the existing large-slot/backward-tail owner. Embeddings are recomputed and differentiated one micro-batch at a time; no resident expert fallback or second expert arena is introduced (`l2l_step.py:367–376,427–441`).
- Native head draw capture extends the existing replay schedule instead of creating a parallel RNG mechanism (`l2l_step.py:149–171,362–365,390–394`). The draw-free head fast path is retained, and outer RNG advancement still uses the existing replay end state (`:443–444`).
- Gradient collection now follows `requires_grad`, rather than selecting only names containing `lora_` (`b13_moe_fixture.py:19–25`). Broader target comparisons require nonzero gradients from both arms, retain exact fp32 loss/gradient/RNG equality, and use only the predeclared bf16 tolerance (`tests/test_b13_l2l_moe.py:446–471`).
- The standalone smoke still computes a real backward-only reader corruption and requires its gradient comparison to fail while outputs/loss remain equal (`b13_moe_backward_smoke.py:133–144,252–295,325–334`). Its optional target/dropout arguments remain benchmark-only; no public training config, planner or default cutover appears in the fix wave.
- Updated `docs/expert-forward.md:99–137` describes the broader non-expert boundary and retains the existing unsupported-combination/public-guard limits. The previously accepted numbered-changelog deferral remains unchanged.

### Historical verdict

**CHANGES REQUESTED for `34b9f37`**, solely to finish original Standards finding 2. Findings 1 and 3 are addressed. No additional defect or preference-based blocker is raised. Fresh exact-source CPU/GPU verification remains separate integrator evidence and cannot close the remaining annotation obligation.
