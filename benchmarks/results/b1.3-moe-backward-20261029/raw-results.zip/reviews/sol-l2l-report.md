# B1.3 ticket 03 — Sol L2L implementation and CPU evidence

## Scope and source

Worktree: `C:/Users/sydyk/Downloads/soup-rnd-b13-t03`, continuing preserved partial commit
`72526f2c`. No Git state changes or commits, no subdelegation, no CUDA execution by this agent.
The integrator owns final integration and real CUDA evidence.

Assigned/expanded files:

- `src/soup_cli/utils/l2l_step.py`
- `src/soup_cli/trainer/l2l_trainer.py` (preserved partial public-guard/logging changes)
- `tests/test_b13_l2l_moe.py`
- new `tests/test_b13_l2l_moe_cuda.py`
- `src/soup_cli/utils/expert_stream.py` (parent-expanded activation contract fixes)
- `tests/test_b13_expert_backward.py`
- `tests/test_b13_expert_backward_cuda.py`

Existing dense guard/regression files were not edited. SolTrainer owns the separate ticket 04
trainer/smoke/doc files; it was informed of the exact activation boundary and AMP change.

## Behavior delivered

- Internal L2L accepts `deepseek_v3`; public `refuse_unsupported_l2l` remains Llama/Mistral only.
  Expert fetch/byte counters remain per-step and aggregate into MoE-only trainer log fields.
  Dense logs retain their existing fields.
- Routing guard observes only streamed expert indices with a pre-hook; it never replaces or
  detaches differentiable routing weights. One record per `(layer, micro-batch)` replaces the
  partial implementation's unnecessary per-pair list and public introspection helpers. The
  installer already permits at most one routed-experts module per decoder layer.
- Recompute choices/shapes and missing/extra expert calls are checked before expert loads.
  Each pair is released on successful comparison and exceptions; run exit removes hooks and
  remaining records. Deliberate failures in no-grad forward, grad recompute, and actual expert
  backward are propagated, checkpoint flags are restored, and the same stepper/store can run
  a clean exact window afterward.
- Actual head/layer backward calls suspend CPU and CUDA autocast; forward/recompute retain
  the caller's autocast. This fixes the parent-reported bf16 trainer mismatch without changing
  primitive ambient-autocast semantics. SolTrainer's causal evidence is
  `sol-trainer-bf16-diag.json`: disabling only backward autocast restored exact gradients,
  losses, final adapters; disabling the autocast cache alone did not. This agent's own bf16
  step regressions cover k=1,2,4 and two windows with the unchanged E5 tolerance
  `atol=1e-6, rtol=1e-5`; all observed differences were actually zero.
- ExpertNode captures CPU and initialized-CUDA RNG state before its forward body; local VJP
  recompute replays under `l2l_rng.state_at`, preserving the caller's outer stream. Saved
  tensors are still unpacked before the pool lease (checkpoint recomputation can itself lease).
  Actual installer/reader/pool regressions cover native SiLU and admitted `nn.Dropout`, ordinary,
  non-reentrant checkpoint, and reentrant checkpoint execution. Frozen expert weights and
  first-order-only semantics remain unchanged.
- A differentiable streamed-expert call refuses an `nn.Module` activation with any registered
  buffer before any expert fetch: `streamed expert backward requires a stateless activation
  without registered buffers; stateful activation recomputation would update its state twice`.
  Parameterless BatchNorm is the regression; no-grad B1.2 execution remains accepted and exact.
  Arbitrary Python closure/module-mode mutation between forward and backward is not snapshotted:
  callers retain the usual checkpoint-style invariant of unchanged activation behavior.

## Verification actually run

CPU environment: Python 3.12.10, torch 2.14.1+cpu, transformers 5.19.0, PEFT 0.21.2.
Commands below ran from the t03 worktree, using its `src` rather than the venv editable checkout.

### Initial stable-snapshot CPU run

```bash
PYTHONPATH=C:/Users/sydyk/Downloads/soup-rnd-b13-t03/src C:/Users/sydyk/Downloads/soup-rnd/.venv/Scripts/python.exe -m pytest -o addopts="" -o junit_family=legacy -q --tb=short -p no:cacheprovider --junitxml=C:/Users/sydyk/Downloads/b13-notes/sol-l2l-cpu.xml tests/test_b13_l2l_moe.py tests/test_b13_expert_backward.py tests/test_l2l_step.py tests/test_l2l_rng.py tests/test_l2l_trainer_window.py tests/test_l2l_trainer_mode.py tests/test_l2l_trainer_labels.py
```

Observed: **191 passed, 2 failed, 1 warning in 132.80s**. The warning is the existing HF
`pin_memory=True` warning on a CPU-only machine. Breakdown:

| File | Initial passing / collected |
|---|---:|
| new L2L MoE CPU file | 32 / 34 |
| expert backward, including 7 added activation cases | 71 / 71 |
| dense L2L step | 15 / 15 |
| dense RNG | 16 / 16 |
| trainer window | 13 / 13 |
| trainer mode / launch guard | 37 / 37 |
| trainer labels | 7 / 7 |

Concrete failures and disposition:

1. New recompute-failure injection classified reader calls with `torch.is_grad_enabled()`.
   `ExpertNode.forward` disables grad even during a grad-bearing recompute, so the intended
   exception was never injected. Fixed the test to use the real guard visit plus current
   autograd node; product cleanup did not need a further change.
2. An extra optional fused-vs-resident comparison found 30 tiny gradient mismatches (first
   reported maxima `2.2351741790771484e-8`, `2.9802322387695312e-8`, `7.450580596923828e-9`).
   Parent's independent reviewer had already established unchanged inherited fused/eager
   arithmetic differences. Fused eager exactness is not this ticket's per-expert E3 seam.
   The optional comparison was removed, not tolerated or represented as a product fix.
   A short-lived replacement guard-only check passed but was also removed as redundant;
   existing consumer-visible dense/fused regressions remain the unchanged-path evidence.

### Concrete corrections run

```bash
PYTHONPATH=C:/Users/sydyk/Downloads/soup-rnd-b13-t03/src C:/Users/sydyk/Downloads/soup-rnd/.venv/Scripts/python.exe -m pytest -o addopts="" -o junit_family=legacy -q --tb=short -p no:cacheprovider --junitxml=C:/Users/sydyk/Downloads/b13-notes/sol-l2l-cpu-corrections.xml tests/test_b13_l2l_moe.py::test_guard_cleans_up_arbitrary_expert_exceptions_and_the_stepper_can_run_again tests/test_b13_l2l_moe.py::test_fused_cache_remains_unchanged_without_routing_hooks
```

Observed: **4 passed in 54.55s**: three retained forward/recompute/backward exception cases,
plus the subsequently removed redundant fused guard check.

A final explicit eager-attention-dropout requirement was added after reviewing spec story 21:
LoRA dropout .05 plus eager attention dropout .1, two consecutive resident/L2L windows.

```bash
PYTHONPATH=C:/Users/sydyk/Downloads/soup-rnd-b13-t03/src C:/Users/sydyk/Downloads/soup-rnd/.venv/Scripts/python.exe -m pytest -o addopts="" -o junit_family=legacy -q --tb=short -p no:cacheprovider --junitxml=C:/Users/sydyk/Downloads/b13-notes/sol-l2l-attention-cpu.xml tests/test_b13_l2l_moe.py::test_eager_attention_and_lora_dropout_replay_match_resident_accumulation
```

Observed: **1 passed in 19.77s**, both windows' losses, all gradients, RNG exactly equal.

Consolidating only retained tests across those actual runs gives **193 distinct retained CPU
cases observed passing** (34 MoE L2L, 71 expert backward, 88 dense/RNG/trainer regression cases).
This is not a claim that a second full-suite invocation occurred on the final snapshot.

### Touched-file Ruff

```bash
C:/Users/sydyk/Downloads/soup-rnd/.venv/Scripts/python.exe -m ruff check src/soup_cli/utils/l2l_step.py src/soup_cli/trainer/l2l_trainer.py src/soup_cli/utils/expert_stream.py tests/test_b13_l2l_moe.py tests/test_b13_l2l_moe_cuda.py tests/test_b13_expert_backward.py tests/test_b13_expert_backward_cuda.py
```

First run found five E501 line-length findings; fixed them surgically. Subsequent runs,
including the final attention-dropout snapshot, returned **All checks passed!** No formatter.

## Numerical evidence

JUnit properties are saved in the three XML files named above, not reconstructed from a
second implementation. `assert_same` requires `torch.equal`; no tolerance was weakened.

| k | LoRA dropout | LoRA gradients / nonzero | Max loss diff | Max gradient diff | RNG equal | Expert reads |
|---:|---:|---:|---:|---:|---|---:|
| 1 | 0 | 30 / 30 | 0 | 0 | yes | 39 |
| 1 | .05 | 30 / 30 | 0 | 0 | yes | 36 |
| 2 | 0 | 30 / 30 | 0 | 0 | yes | 81 |
| 2 | .05 | 30 / 30 | 0 | 0 | yes | 72 |
| 4 | 0 | 30 / 30 | 0 | 0 | yes | 162 |
| 4 | .05 | 30 / 30 | 0 | 0 | yes | 159 |

Every matrix case asserts different per-micro-batch routing, unused experts, and nonzero
shared-expert output. Router top-k 1 and 3 are tested independently at accumulation k=2,
dropout 0/.05. Masked prompts, padding labels, and an entirely masked row remain exact.
A/B/A windows on one stepper/store remain exact at dropout 0/.05; reseeding repeats exactly,
and changing the seed changes the dropout gradients. Dedicated direct-router testing compares
actual nonzero routing-weight gradients and hidden gradients with the resident block exactly.

Observed read/traversal evidence (k=3): 40 hit-expert visits, **120 total reads**, including
**40 actual backward reads**, 737280 logical bytes. Layer calls were forward
`[0,0,0,1,1,1,2,2,2]`, recompute `[2,2,2,1,1,1,0,0,0]`. Global reader events assert all forward
reads precede the reverse walk and each micro-batch's recompute/backward finishes before the
next. Unused experts are never read; per-step counters equal public reader/runtime deltas.

Negative controls use the **same inputs** with an exact clean run first and after corruption:

| Negative control | Max gradient difference | Differing LoRA tensors | Losses | Other evidence |
|---|---:|---:|---|---|
| Add .5 to expert down weights only inside autograd-engine reader loads | 0.7918660938739777 | 30 | exact | 27 actual backward reads perturbed, both MoE layers; RNG exact; clean repeat exact |
| Do not apply replayed RNG state on recompute at dropout .05 | 0.1861501820385456 | 30 | exact | routing check disabled only for gradient-sensitivity control; clean repeat exact |

With the routing check enabled, the same broken RNG replay raises at the mismatched pair
before its expert read/backward; all hooks/records are cleared and the next clean run is exact.
Direct choice/shape/extra-call/missing-call checks also raise before the offending read and free
pair state. Forward/recompute/backward I/O exceptions preserve the original exception and do
not poison a subsequent window.

Activation replay: all six SiLU/Dropout x ordinary/non-reentrant/reentrant cases had exact
outputs, hidden gradients, routing-weight gradients, and forward/end CPU RNG. Max hidden and
route gradient differences were **0**; backward did not consume the outer RNG despite deliberate
caller RNG draws between forward and backward. Stateful-buffer refusal and no-grad preservation
also passed. Parent-provided pre-fix evidence (not rerun here) was 8.879690170288086 hidden-grad
and 21.0216064453125 route-grad max differences with Dropout.

## Costs and remaining integration evidence

RNG replay adds one global RNG snapshot to each differentiable hit-expert node, including the
deterministic SiLU case, and one fork/restore around local VJP recomputation. A direct local
measurement returned **5056 CPU RNG-state bytes per node**, plus each initialized CUDA
card's state (not measured locally), object metadata, and fork/snapshot/restore operations.
These are generator metadata, not expert weights or arena aliases; no second expert-weight
copy was introduced. No latency or memory-performance claim is made. Registered activation
buffer checking adds a recursive buffer traversal only for module activations on grad calls.

CUDA file adds 14 deterministic gpu-marked L2L cases: 6 E3 matrix cells, real backward-only
corruption, broken RNG replay, 2 repeated/masked windows cases, 2 independent top-k cases,
one fp32-model/bf16-autocast case at k=2, and eager-attention+LoRA-dropout replay. It sets
`CUBLAS_WORKSPACE_CONFIG=:4096:8` at import before importing CPU helpers/torch and restores
deterministic-mode settings afterward. Existing expert CUDA module adds six actual-installer
activation replay cases and one fp32-block/bf16-forward-autocast/backward-outside-autocast
case; the block criterion is exact. Model AMP uses unchanged E5 `1e-6/1e-5`.

**CUDA was not run here, by assignment.** Integrator must run these modules on its real card
in a fresh process and perform its final integrated CPU checks. Documentation/changelog is
owned by SolTrainer/integrator rather than edited outside this dispatch's paths.
