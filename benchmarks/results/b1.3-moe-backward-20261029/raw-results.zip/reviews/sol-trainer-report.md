# SolTrainer: ticket 04 and reachable ticket 06 docs

## Changes and integration requirement

Worktree: `C:/Users/sydyk/Downloads/soup-rnd-b13-t04`, base
`72526f2cd89c551deb829e1c292ef0d1a11fed4c`. No commits, Git state changes, or product-file edits.

New files:

- `tests/test_b13_moe_trainer.py`: real HF Trainer vs `make_l2l_trainer_class(Trainer)` +
  `attach_l2l_state`; independent resident eager native DeepSeek-V3 model, identical checkpoint,
  nonzero LoRA, seeds and dtype. Uses existing `test_b13_moe_runtime` helpers and `_MaskedRows`.
- `benchmarks/harness/b13_moe_fixture.py`: minimal independent synthetic fixture for standalone
  smoke, no pytest/tests imports. One dense + two MoE layers, 8 routed/1 shared expert,
  5 MLA LoRA targets x A/B x 3 layers = 30 supported trainable tensors.
- `benchmarks/harness/b13_moe_backward_smoke.py`: standalone native checkpoint -> per-expert
  sharder -> real reader/pool runtime -> existing `L2LStep.run`, resident eager ordinary GA,
  two real optimizer updates for each k=1,2,4, plus backward-only corruption on identical weights
  before each clean update. JSON verdict derives from actual tensors, loads and reverse visits.

**Merge SolL2L product fix before integration verification.** Unmodified t04 product fails bf16
trainer parity. The successful final checks below deliberately import t03 `src`, not stale t04
`src`. SolL2L owns and landed the AMP fix; no workaround is installed in these tests/harnesses.
The final smoke JSON records the imported t03 package, base SHA, dirty product hash manifest and
separate exact harness/fixture hashes. Integrator must rerun against integrated stable source.

Additional docs, explicitly assigned by Main after CPU smoke:

- `docs/expert-forward.md`: internal B1.3 backward/runtime/L2L, three reads/visit, frozen routed
  weights/no expert adapters/first-order, stateless activation and local RNG replay contract,
  arena vs total VRAM, standalone smoke; old B1.2 protocols/results clearly historical.
- `docs/expert-shard-format.md`: superseded runtime refusal corrected, compatibility/defaults
  unchanged; historical refusal-order/check results retained as historical.
- `docs/performance-and-quantization.md`: concise top/internal L2L clarification and MoE counters.
- Integration staging only: `.scratch/b1.3-moe-backward/changelog-fragment.md` with explicit
  obtain-real-PR-number -> `changelog.d/0.75.1/<PR>.added.md` publication instruction. No invented
  PR number or invalid placeholder fragment added to validated changelog folder.

Final SolL2L handoff clarification is included in expert-forward docs: every differentiable
hit-expert node, even deterministic SiLU, saves a global RNG snapshot; SolL2L measured 5056 CPU
payload bytes/node plus initialized CUDA states/object metadata and fork/restore overhead.
This metadata is outside the arena. Callers must preserve activation behavior (closure state
and module mode) between forward/backward. Buffer-bearing activation modules are refused for
grad calls, while stateless Dropout local RNG replay is supported. Source: sol-l2l-report.md,
Costs and remaining integration evidence. This late clarification changed docs/report only;
the verified Python files and recorded evidence hashes remain unchanged.

## Helper interfaces

Test helpers:

- `_train(model, runtime, path, data, *, k, l2l, bf16) -> dict`: runs complete real HF epoch;
  callback captures every pre-optimizer gradient (all 30), exact unrounded sum of actual trainer
  training-step returns per window, lr schedule, final adapters and cumulative expert logs.
- `_compare(ga, streamed, *, windows, atol, rtol, record_property)`: checks steps, gradients,
  losses, final trained state, rates and increasing real expert-read counters; writes per-step and
  overall max-absolute differences as JUnit properties, including failing tensors.

Standalone helpers:

- `build_fixture(root: Path, *, device="cpu") -> Fixture(config, streamed, resident, runtime)`;
  always `Fixture.close()`.
- `trainables(model)`, `snapshot(model, *, gradients=False)` normalize only `.inner.` wrapper.
- `micro_batches(config, k, *, first, device) -> (ids_list, masked_labels_list)`.
- `run_case(root: Path, *, k: int, device: str) -> dict`.
- CLI: `--device {cpu,cuda} --output PATH`; rich Console stdout; no product/test-only switch.
- `ReadProbe` wraps only public `reader.read_host`; corruption adds 0.5 to real returned down
  staging iff `torch._C._current_autograd_node()` is active. No checkpoint-file mutation. It records
  actual per-layer/expert reads, reloads, shared arena pointers and counter deltas. The correct and
  corruption arms both verify two outside-backward reads for every backward reload (three total).

CUDA launch sets `CUBLAS_WORKSPACE_CONFIG=:4096:8` before CUDA starts, deterministic algorithms,
TF32 disabled. CUDA allocated/reserved peaks are recorded separately from arena plan/allocation.
CUDA was not available/exercised locally; Main owns remote evidence.

## Commands and actual results

All commands run from `C:/Users/sydyk/Downloads/soup-rnd-b13-t04`.
Python is `C:/Users/sydyk/Downloads/soup-rnd/.venv/Scripts/python.exe`.

Initial stable source check (t04 product):

```bash
PYTHONPATH=C:/Users/sydyk/Downloads/soup-rnd-b13-t04/src OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 C:/Users/sydyk/Downloads/soup-rnd/.venv/Scripts/python.exe -m pytest -o addopts="" -q --tb=short -p no:cacheprovider tests/test_b13_moe_trainer.py --junitxml=C:/Users/sydyk/Downloads/b13-notes/sol-trainer-cpu.xml
```

Actual: **5 passed, 3 failed**, 38.29 s; bf16 k=1,2,4 failed fixed 1e-6/1e-5 criterion, not
weakened or xfailed. First reported tensor differences 8.46386e-6 / 6.19888e-6 / 5.00679e-6.

Narrow diagnostic against t03 product (`sol-trainer-bf16-diag.json`): baseline k1 overall
per-step gradient maxima `[0.001220703125, 0.0146484375, 0.1529541015625]`, differing parameter
counts `[24,27,30]`, final state max 0.0254923478. Disabling autocast only around actual
`torch.autograd.backward` made all 3 steps' gradients/losses/final state **exact zero diff**.
Disabling autocast cache around `L2LStep.run` did not improve baseline. Diagnostic was ephemeral
in-memory monkeypatching only, no product edits. Findings sent to SolL2L, which fixed product
backward context while preserving forward/recompute AMP.

Final fixed-product trainer check:

```bash
PYTHONPATH=C:/Users/sydyk/Downloads/soup-rnd-b13-t03/src OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 C:/Users/sydyk/Downloads/soup-rnd/.venv/Scripts/python.exe -m pytest -o addopts="" -o junit_family=legacy -q --tb=short -p no:cacheprovider tests/test_b13_moe_trainer.py --junitxml=C:/Users/sydyk/Downloads/b13-notes/sol-trainer-cpu-fixed.xml
```

Actual: **8 passed**, 40.42 s, zero skips/failures/warnings. Each case performs three real
optimizer steps, masked labels, dataset 2k+1 rows (short final window for k>1). Equal-length
fp32 k=1/2/4 and bf16-autocast k=1/2/4: all 30 per-step grads, unrounded losses and trained state
**exactly zero max diff**. bf16 nevertheless retains preregistered 1e-6/1e-5 assertion.

Uneven/right-padded no-dropout cases retain preregistered 2e-5/1e-4:

| k | step 0 grad | step 1 grad | step 2 grad | loss max | trained state max |
|---|---:|---:|---:|---:|---:|
| 2 | 1.4528632e-7 | 4.0233135e-7 | 3.1664968e-7 | 4.7683716e-7 | 1.1920929e-7 |
| 4 | 1.0803342e-7 | 2.9057264e-7 | 6.5565109e-7 | 0 | 1.4342368e-7 |

Already right-padded rows (attention mask zeros + -100 labels) and padding between differently
sized micro-batches are both exercised. Dropout+uneven refusal is intentionally not duplicated;
existing `test_l2l_trainer_mode.py` owns it. Every case asserts every supported gradient nonzero,
actual adapter changes, exact lr schedule and increasing expert fetch/byte log counters.

Real standalone CPU smoke commands (not pytest):

```bash
PYTHONPATH=C:/Users/sydyk/Downloads/soup-rnd-b13-t04/src OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 C:/Users/sydyk/Downloads/soup-rnd/.venv/Scripts/python.exe benchmarks/harness/b13_moe_backward_smoke.py --device cpu --output C:/Users/sydyk/Downloads/b13-notes/sol-trainer-smoke-cpu.json
PYTHONPATH=C:/Users/sydyk/Downloads/soup-rnd-b13-t03/src OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 C:/Users/sydyk/Downloads/soup-rnd/.venv/Scripts/python.exe benchmarks/harness/b13_moe_backward_smoke.py --device cpu --output C:/Users/sydyk/Downloads/b13-notes/sol-trainer-smoke-cpu-fixed.json
```

Both actually **PASS**, respectively 32.56 s and 37.36 s. The final second JSON has stronger
explicit three-reads-per-visit checking and separate harness hashes; use it for handoff.
Environment: Python 3.12.10, torch 2.14.1+cpu, transformers 5.19.0, peft 0.21.2, accelerate 1.15.0,
safetensors 0.8.0; Windows build 26300. Deterministic algorithms enabled, fp32 exact criterion.

| k | window | clean max grad/loss/state | bad max grad | bad forward/loss | reads / backward reloads |
|---|---|---|---:|---|---|
| 1 | 0 | 0 / 0 / 0 | 1.24025917 | 0 / 0 | 39 / 13 |
| 1 | 1 | 0 / 0 / 0 | 4.19798708 | 0 / 0 | 39 / 13 |
| 2 | 0 | 0 / 0 / 0 | 0.91011274 | 0 / 0 | 81 / 27 |
| 2 | 1 | 0 / 0 / 0 | 0.62466770 | 0 / 0 | 81 / 27 |
| 4 | 0 | 0 / 0 / 0 | 0.49807489 | 0 / 0 | 162 / 54 |
| 4 | 1 | 0 / 0 / 0 | 1.03040230 | 0 / 0 | 159 / 53 |

All 30 trained tensors changed and were compared on every clean update; all 30 gradient tensors
were detected unequal in every corruption arm. Both MoE layers reloaded during real backward;
reverse activation gets were exactly layers 2,1,0, micro-batches ascending within each layer.
One arena, plan=budget=6144 bytes, host staging=20480 bytes; pointer unchanged through all arms/
updates and all observed reads use it. These are arena bounds, not total memory/RSS bounds.
Final per-window logical read bytes: k1 239616/239616; k2 497664/497664; k4 995328/976896.
CUDA peaks are correctly null in CPU evidence, not invented zero-VRAM results.

Touched Python Ruff (initial and after final edits):

```bash
C:/Users/sydyk/Downloads/soup-rnd/.venv/Scripts/python.exe -m ruff check tests/test_b13_moe_trainer.py benchmarks/harness/b13_moe_backward_smoke.py benchmarks/harness/b13_moe_fixture.py
```

Actual final output: **All checks passed!**

## Remaining integration verification / limits

- Integrate SolL2L product changes; stale t04 product by itself retains the proven bf16 defect.
- Main must run new trainer tests and real CPU/CUDA standalone smoke on the final integrated
  snapshot, and add final GPU evidence/source identity only from actual remote output.
- No full-repository test run or CUDA claim from this agent. No trained-model/convergence,
  throughput, giant-checkpoint or total-VRAM claim. Final docs do not publish provisional GPU
  results or reattribute old B1.2 gate evidence.
