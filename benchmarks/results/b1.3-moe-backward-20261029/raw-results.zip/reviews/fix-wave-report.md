# B1.3 final-review fix wave

## Source and scope

Worktree: `C:/Users/sydyk/Downloads/soup-rnd-b13-t03`.
Frozen parent: `495b38829808fa8624867fc816d7506466838059`.
This report measures an **uncommitted dirty fix wave**, not the previously verified frozen source.
The standalone smokes identify the imported package as
`C:/Users/sydyk/Downloads/soup-rnd-b13-t03/src/soup_cli/__init__.py` and record identical full
changed-file SHA-256 manifests across all four smoke invocations. The manifest is preserved in
`fix-wave-smoke-*-evidence.json` and `fix-wave-numerical-summary.json`.

No commits, branches, index operations, subdelegation or cloud operations were performed.
No files outside the brief's repository ownership list were edited. The report and recorded
verification artifacts live outside the worktree. In particular, `layer_stream_runtime.py`
needed no change: its existing backward-tail embedding loader and large-layer wrapper supply
the required lifetime boundary.

Inputs read: `fix-wave-brief.md`, both final review reports and their embedding/head probes and
JSON evidence, original five AC, local spec, AGENTS.md, CONTRIBUTING.md and environment notes.
Installed PEFT 0.21.2 embedding forward was inspected: vanilla embedding LoRA does not call its
registered dropout. The fix does not invent such draws.

## Changed files and fixes

- `src/soup_cli/utils/l2l_step.py`
  - `LayerCall` keeps decoder `draws` unchanged and adds optional `head_draws=()` metadata.
    Capture observes the actual native head forward. Replay now models each resident
    micro-batch's decoder0..decoderL-1 **then head** sequence. A head with real dropout runs
    at its recorded state, and the outer CPU/CUDA stream is left at the complete schedule end.
    A head without draws keeps its prior fast path.
  - After the reverse decoder walk, trainable embeddings get a genuine autograd VJP using
    original IDs and layer-0 input gradients. One embedding forward/backward finishes before
    the next micro-batch. It uses the existing streamed wrapper and embedding refill callback;
    there is no resident fallback, all-expert copy, manual derivative or detached route weight.
  - Embedding forward RNG is saved only when its parameters are trainable. Recompute forks
    that state, so NEFTune receives its original noise without advancing outer RNG. Ambient
    forward AMP remains enabled; actual embedding backward, like the existing head/decoder
    backward, disables CPU/CUDA autocast. Frozen embedding forward/load behavior is retained.
  - Added missing constructor return annotations.
- `src/soup_cli/utils/l2l_rng.py`
  - Documented the decoder-plus-head schedule and annotated the patched functional signatures.
    Replay arithmetic and the primitive expert RNG fix are not replaced.
- `benchmarks/harness/b13_moe_fixture.py`
  - Becomes the single pytest-free construction owner for synthetic config, randomized native
    checkpoint, LoRA config, adapter nonzero initialization, copying, input generation and
    native eager resident construction. All heavy imports remain inside functions.
  - Keeps default 30 MLA trainables and adds explicit synthetic target tuples for embedding32,
    shared/head44 and combined46. Embedding A/B are both initialized nonzero.
- `benchmarks/harness/b13_moe_backward_smoke.py`
  - Annotated all added interfaces; reuses the shared fixture.
  - Default remains MLA30, dropout zero, k=1/2/4, two SGD updates each. Optional benchmark-only
    `--targets embedding|head-shared|all` and `--dropout` exercise the requested broader targets;
    no product YAML, public training CLI, planner or defaults changed.
  - Measures CPU/CUDA outer RNG equality. Forward-logit probes fork their own seeded RNG so
    inspection does not consume masks used by the measured GA/L2L windows. Actual clean and
    backward-corrupted computations still determine every verdict.
- `tests/test_b13_moe_runtime.py`
  - Removed collection-time torch and PEFT-config construction. Refusal parametrization uses
    plain strings and instantiates only the requested PEFT config during test execution.
  - Deleted duplicate config/checkpoint/adapter construction and migrated all affected callers
    directly to the harness fixture: no compatibility aliases or re-export chain.
  - Ordinary checkpointed E2 now also checks embedding32, shared/head44 and combined46 against
    native resident eager, with every configured gradient nonzero and exactly equal.
- `tests/test_b13_l2l_moe.py`
  - Removed module-level torch, moved imports into actual consumers, annotated new interfaces.
  - Adds native resident-GA consumer comparisons for k=1/2 over A,B,A repeated windows for
    embedding32, embedding32+NEFTune(0.2), decoder/shared/head dropout(0.05)44 and combined46.
    Every configured reference and actual gradient must be nonzero. Losses, gradients and outer
    RNG require exact equality. Added embedding VJP bf16 forward-AMP checks using only the
    predeclared E5 tolerance. JUnit records reference and actual nonzero counts.
- `tests/test_b13_l2l_moe_cuda.py`
  - Migrated lazy imports and fixture references; annotated interfaces.
  - Added deterministic CUDA versions of those four boundary configurations at k=1/2, plus
    embedding VJP under bf16 forward AMP. CUDA execution is the integrator's responsibility.
- `tests/test_b13_moe_trainer.py`
  - Migrated shared construction and annotated comparison/training/callback interfaces.
  - Added real Trainer three-update comparisons for embedding32/shared-head44/combined46 at
    k=1/2, including short final windows, all nonzero gradients, trained-state equality and
    outer RNG equality. Equal-length fp32 still uses zero tolerance.
- `docs/expert-forward.md`
  - Corrected the supported non-expert boundary, embedding VJP lifetime/noise replay, native
    head replay and optional synthetic smoke instructions. Existing public guards and the
    NEFTune+dropout / uneven stochastic-window refusals remain documented and unchanged.

Native eager reference execution remains independent of streamed runtime/L2L arithmetic;
only identical starting construction is shared. Expert base weights/adapters, primitive RNG
handling and buffered-activation refusal were not altered. No supported embedding/head target
was refused, excluded from gradient collection or special-cased by input.

## Verification commands and results

All commands below ran from the worktree root with the existing command recorder. It sets
`PYTHONPATH=<worktree>/src;<worktree>`, offline hub/dataset flags and UTF-8 output. Exact argv,
environment, timestamps and exit codes are in each named `.json`; corresponding `.log` files
are preserved. Commands use these exact values:

```bash
P=C:/Users/sydyk/Downloads/soup-rnd/.venv/Scripts/python.exe
R=C:/Users/sydyk/Downloads/b13-notes/run_recorded.py
W=C:/Users/sydyk/Downloads/soup-rnd-b13-t03
F=C:/Users/sydyk/Downloads/b13-notes/final
```

### Stable targeted CPU set

```bash
$P $R --cwd $W --record $F/fix-wave-cpu --source frozen495b3882-plus-fix-wave -- $P -m pytest -o addopts= -o junit_family=legacy -q --tb=short -p no:cacheprovider tests/test_b13_moe_runtime.py tests/test_b13_l2l_moe.py tests/test_b13_l2l_moe_cuda.py tests/test_b13_moe_trainer.py tests/test_l2l_step.py tests/test_l2l_rng.py tests/test_l2l_trainer_mode.py --junitxml=$F/fix-wave-cpu.xml
```

Initial result: **151 passed, 23 skipped, 1 failed**, exit 1. The sole failure was the existing
`test_states_saved_in_layer_major_order_disagree_with_accumulation` negative control: its
replacement `state_at` popped a no-grad decoder state for the newly wrapped, draw-free head.
The concrete correction preserves the old head path unless actual `head_draws` exist; the
full replay schedule still includes the head slot. No test, assertion or tolerance was weakened.
All new boundary and Trainer cases passed in this initial set.

Only the affected RNG/default/boundary subset was rerun after that correction:

```bash
$P $R --cwd $W --record $F/fix-wave-cpu-correction --source frozen495b3882-plus-fix-wave -- $P -m pytest -o addopts= -o junit_family=legacy -q --tb=short -p no:cacheprovider tests/test_l2l_rng.py tests/test_b13_l2l_moe.py::test_e3_l2l_equals_resident_eager_accumulation tests/test_b13_l2l_moe.py::test_supported_trainables_equal_resident_ga_across_repeated_windows tests/test_b13_l2l_moe.py::test_embedding_vjp_keeps_backward_outside_forward_autocast --junitxml=$F/fix-wave-cpu-correction.xml
```

Result: **32 passed**, exit 0. Taken as a union with the unaffected initial cases: **152 unique
passed / 23 skipped / 0 unresolved failures**. This is deliberately not presented as one fresh
full-set green run; the integrator owns fresh integrated source verification. The 23 skips are
CUDA-marked cases on the CPU-only environment.

Pre-existing third-party warnings were retained: two PEFT rank/alpha-pattern warnings from
the deliberate expert-adapter refusal case and one CPU pin-memory warning.

### Touched-file Ruff

```bash
$P $R --cwd $W --record $F/fix-wave-ruff --source frozen495b3882-plus-fix-wave -- $P -m ruff check src/soup_cli/utils/l2l_step.py src/soup_cli/utils/l2l_rng.py benchmarks/harness/b13_moe_fixture.py benchmarks/harness/b13_moe_backward_smoke.py tests/test_b13_moe_runtime.py tests/test_b13_l2l_moe.py tests/test_b13_l2l_moe_cuda.py tests/test_b13_moe_trainer.py
$P $R --cwd $W --record $F/fix-wave-ruff-corrected --source frozen495b3882-plus-fix-wave -- $P -m ruff check src/soup_cli/utils/l2l_step.py src/soup_cli/utils/l2l_rng.py benchmarks/harness/b13_moe_fixture.py benchmarks/harness/b13_moe_backward_smoke.py tests/test_b13_moe_runtime.py tests/test_b13_l2l_moe.py tests/test_b13_l2l_moe_cuda.py tests/test_b13_moe_trainer.py
```

Initial result: four concrete errors (two 101/102-column lines, two local import ordering
errors), exit 1. These were fixed without unrelated formatting. Corrected result:
**All checks passed**, exit 0, eight touched Python files.

### Unavailable-dependency collection

```bash
$P $R --cwd $W --record $F/fix-wave-collection --source frozen495b3882-plus-fix-wave -- $P $F/fix-wave-collection-probe.py
```

Throwaway subprocess blocks torch and PEFT with `ModuleNotFoundError`, then actually runs
pytest collection for the four B1.3 runtime/L2L/CUDA/Trainer modules. Result: **107 collected**,
exit 0, no loaded torch/PEFT module and no PEFT import attempt. The one torch attempt is the
existing central conftest CUDA capability probe, which catches unavailable dependencies.
This is behavioral collection evidence, not a permanent source-string test.

### Real standalone CPU smokes

```bash
$P $R --cwd $W --record $F/fix-wave-smoke-default --source frozen495b3882-plus-fix-wave -- $P benchmarks/harness/b13_moe_backward_smoke.py --device cpu --output $F/fix-wave-smoke-default-evidence.json
$P $R --cwd $W --record $F/fix-wave-smoke-embedding --source frozen495b3882-plus-fix-wave -- $P benchmarks/harness/b13_moe_backward_smoke.py --device cpu --targets embedding --output $F/fix-wave-smoke-embedding-evidence.json
$P $R --cwd $W --record $F/fix-wave-smoke-head --source frozen495b3882-plus-fix-wave -- $P benchmarks/harness/b13_moe_backward_smoke.py --device cpu --targets head-shared --dropout 0.05 --output $F/fix-wave-smoke-head-evidence.json
$P $R --cwd $W --record $F/fix-wave-smoke-all --source frozen495b3882-plus-fix-wave -- $P benchmarks/harness/b13_moe_backward_smoke.py --device cpu --targets all --dropout 0.05 --output $F/fix-wave-smoke-all-evidence.json
```

All four exited 0 and computed **PASS**. Each runs k=1/2/4, two genuine SGD updates per k:
**12 cases / 24 clean update windows and 24 actual backward-corrupted windows** in total.
Every clean output/loss/gradient/trained-state comparison is exact; outer RNG equals resident
GA after every clean window. Every configured reference and actual gradient tensor is nonzero.

| Synthetic configuration | Nonzero gradients in both arms, every update | Max clean loss / grad / state difference | Outer RNG | Max corrupted-gradient difference across its six windows |
| --- | --- | --- | --- | --- |
| Default MLA, dropout 0 | 30/30 | 0 / 0 / 0 | exact | 4.197987079620361 |
| Embedding + MLA, dropout 0 | 32/32 | 0 / 0 / 0 | exact | 3.6118409633636475 |
| MLA + shared + head, dropout .05 | 44/44 | 0 / 0 / 0 | exact | 3.2739899158477783 |
| Embedding + MLA + shared + head, dropout .05 | 46/46 | 0 / 0 / 0 | exact | 10.373320579528809 |

In all 24 corrupted windows, forward and loss remained exact while computed gradients failed
the comparison. Real backward reload counts were positive, the three-reads-per-visit invariant
held, reverse layer traversal matched (2,1,0), the expert arena retained one bounded slot and
one storage pointer throughout. These are synthetic correctness results, not throughput or
total-VRAM-fit claims.

## Additional numerical evidence

`fix-wave-cpu-correction.xml` records zero maximum loss and gradient differences and exact outer
RNG for all eight supported fp32 boundary cases (k=1/2, three consecutive windows each), all
six default MLA dropout/k cases and both embedding forward-AMP cases. Embedding32+NEFTune has
32 nonzero tensors in both arms at every window, including both embedding LoRA factors; the
combined decoder/shared/head .05 configurations have all 44 or 46 nonzero, exact gradients.

`fix-wave-cpu.xml` records all six new real Trainer cases at k=1/2 with three updates each:
32/44/46 nonzero tensors per step; maximum gradient/loss/trained-state differences **0/0/0**;
outer RNG exact. Ordinary checkpointed E2 has all 30/32/44/46 nonzero exact gradients.

Existing uneven-length Trainer checks remain at their preregistered `atol=2e-5, rtol=1e-4`:
observed maximum gradient differences were `4.6938657760620117e-07` (k2) and
`1.1473894119262695e-06` (k4); maximum trained-state differences were
`1.0058283805847168e-07` and `1.9371509552001953e-07`; losses were exact. Existing and added
CPU bf16-forward AMP cases were observed exact without changing the fixed E5 tolerance.

Machine-readable reduced evidence: `fix-wave-numerical-summary.json`. Original per-parameter
values/verdicts, reader events, SHA-256 manifests and environment remain in the smoke JSONs.

## Acceptance mapping and remaining verification

| AC | Fix-wave evidence |
| --- | --- |
| 1: reverse walk, real reloads, bounded lifetime | Existing consumer/read-order tests passed; all four standalone configurations measure reverse (2,1,0), positive backward reloads, three reads per visit and a stable one-slot arena. Embedding VJP uses the existing large loader and immediate backward, no new runtime seam. |
| 2: real L2L/recompute/repeated state | A,B,A on the same stepper/store; new real Trainer three-update cases; standalone two-update k1/2/4 cases. |
| 3: supported gradients, RNG, AMP, routing | Nonzero exact 32/44/46 gradients against independent native resident GA; NEFTune replay; native head dropout interleaving; exact outer RNG; embedding AMP check. Routing/expert implementation and its prior fixes remain intact. |
| 4: k1 and k>1, native reference | New boundary k1/2 tests plus independent default/broader standalone k1/2/4; existing varied router top-k, masked and uneven contracts passed. |
| 5: genuine negative controls | All standalone backward-only perturbations preserve output/loss and fail actual gradient comparison; existing recompute RNG corruption controls passed after the draw-free-head fast-path correction. |

No accepted finding remains knowingly unresolved in the edited code. No tolerances were
widened, supported trainables narrowed, expert training added or public guard removed.

**CPU-only limits:** local torch is `2.14.1+cpu`, Python 3.12.10, Transformers 5.19.0,
PEFT 0.21.2, Accelerate 1.15.0, safetensors 0.8.0. CUDA was not executed here: 23 GPU-marked
cases skipped, including the nine new boundary/AMP variants. Fresh integrated CPU/CUDA source
verification and independent Standards/Spec re-review remain owned by the integrator; the old
frozen-source CUDA PASS is not reassigned to this fix wave.
