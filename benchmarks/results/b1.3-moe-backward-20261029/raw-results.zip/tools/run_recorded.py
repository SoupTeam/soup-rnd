"""Task-local command recorder; not product code or a test fixture."""
from __future__ import annotations

import argparse
import datetime
import json
import os
import pathlib
import subprocess
import time


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cwd", required=True)
    parser.add_argument("--record", required=True)
    parser.add_argument("--source", default="")
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command = args.command[1:] if args.command[:1] == ["--"] else args.command
    if not command:
        parser.error("command required after --")
    record = pathlib.Path(args.record)
    record.parent.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env["PYTHONPATH"] = str(pathlib.Path(args.cwd) / "src") + os.pathsep + args.cwd
    env["HF_HUB_OFFLINE"] = "1"
    env["HF_DATASETS_OFFLINE"] = "1"
    env["TOKENIZERS_PARALLELISM"] = "false"
    env["PYTHONIOENCODING"] = "utf-8"
    env["COVERAGE_FILE"] = str(record.with_suffix(".coverage"))
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    begin = time.monotonic()
    with record.with_suffix(".log").open("w", encoding="utf-8") as output:
        result = subprocess.run(command, cwd=args.cwd, env=env, stdout=output,
                                stderr=subprocess.STDOUT, check=False)
    details = {"command": command, "cwd": args.cwd, "source": args.source,
               "started_utc": started, "duration_seconds": time.monotonic() - begin,
               "exit_code": result.returncode,
               "environment_overrides": {key: env[key] for key in
                   ("PYTHONPATH", "HF_HUB_OFFLINE", "HF_DATASETS_OFFLINE",
                    "TOKENIZERS_PARALLELISM", "PYTHONIOENCODING", "COVERAGE_FILE")}}
    record.with_suffix(".json").write_text(json.dumps(details, indent=2), encoding="utf-8")
    print(json.dumps(details, indent=2))
    lines = record.with_suffix(".log").read_text(encoding="utf-8", errors="replace").splitlines()
    print("\n".join(lines[-18:]))
    return result.returncode


if __name__ == "__main__":
    raise SystemExit(main())
