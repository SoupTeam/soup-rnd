"""Throwaway pytest observation plugin; never imported by the product."""
from __future__ import annotations

import json
import os
from pathlib import Path

ROOT = Path(os.environ["B13_DIAGNOSTICS_DIR"])
ROOT.mkdir(parents=True, exist_ok=True)


def pytest_runtest_logstart(nodeid, location):
    (ROOT / "current-test.json").write_text(json.dumps({"nodeid": nodeid}), encoding="utf-8")


def pytest_runtest_logreport(report):
    if report.failed:
        record = {"nodeid": report.nodeid, "when": report.when,
                  "traceback": report.longreprtext}
        with (ROOT / "failures.jsonl").open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(record) + "\n")


def pytest_sessionfinish(session, exitstatus):
    (ROOT / "session.json").write_text(json.dumps({
        "exitstatus": int(exitstatus), "collected": session.testscollected,
        "failed": session.testsfailed,
    }, indent=2), encoding="utf-8")
