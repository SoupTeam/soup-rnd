"""Benchmark instruments (#836)."""
