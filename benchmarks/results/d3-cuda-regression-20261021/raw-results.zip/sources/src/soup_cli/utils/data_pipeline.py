"""Data Pipeline Pro helpers (v0.42.0).

Schema-first surface for axolotl + LlamaFactory data parity. Live wiring for
heavy paths (S3/GCS loaders, AOT preprocess, PDF/DOCX ingestion, custom prompt
strategies) is intentionally deferred to v0.42.1 — mirrors v0.27.0 MII /
v0.37.0 multipack / v0.39.0 ReLoRA / v0.40.0 Part D / v0.41.0 LLaMA Pro
stub-then-live pattern.

Project policy followed:
- Bool rejected before int isinstance check (v0.30.0 Candidate / v0.34.0
  estimate_run_cost_usd / v0.36.0 Part D make_cache_key).
- Null-byte / oversize string rejection (v0.36.0 chat-template / v0.39.0
  Part E templates / v0.40.5 reward_model field validator).
- Frozen dataclasses for value objects (v0.32.0 SpikeRecoveryStrategy /
  v0.39.0 ReLoRAPolicy / v0.41.0 LrGroup).
- ``MappingProxyType`` for runtime-immutable registries (v0.36.0 _REGISTRY /
  v0.41.0 _OPTIMIZER_PACKAGES).
- ``is None`` over falsy guards (v0.34.0 / v0.39.0 / v0.40.6 policy).
"""

from __future__ import annotations

import functools
import hashlib
import inspect
import json
import logging
import math
import os
import re
import types
from dataclasses import dataclass
from typing import (
    Any,
    Callable,
    Dict,
    FrozenSet,
    Iterable,
    List,
    Mapping,
    Optional,
    Tuple,
)
from urllib.parse import urlparse

# --- Part A: New formats ---------------------------------------------------

# v0.42.0 new format strings on DataConfig.format Literal. Each is matched by
# an entry in ``soup_cli.data.formats._convert_*`` (Part A live wiring) and
# documented in the README's Data Formats section.
NEW_FORMATS_V0_42: FrozenSet[str] = frozenset({
    "prm",
    "pre_tokenized",
    "input_output",
    "video",
    "multimodal",
})


# --- Part B: Remote loading allowlist --------------------------------------

# Closed allowlist of remote URI schemes we recognise on ``DataConfig.train``.
# Each scheme requires a corresponding lazy-imported fsspec backend at load
# time. Live wiring of ``s3fs`` / ``gcsfs`` / ``adlfs`` / ``ocifs`` deferred to
# v0.42.1 — schema gate fires now so a misconfigured YAML fails loudly.
_REMOTE_SCHEMES: Mapping[str, str] = types.MappingProxyType({
    "s3": "s3fs",
    "gs": "gcsfs",
    "gcs": "gcsfs",
    "az": "adlfs",
    "abfs": "adlfs",
    "abfss": "adlfs",
    "oci": "ocifs",
})

# RFC 3986 — bucket / container names cannot contain control chars. We
# additionally reject characters that would let a crafted URL break out of the
# scheme://host/path pattern via embedded query / fragment / userinfo.
_BUCKET_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._\-]{0,62}$")

_MAX_REMOTE_PATH = 2048


def is_remote_uri(value: str) -> bool:
    """Return True iff ``value`` is one of the recognised remote schemes.

    Conservative — rejects bool (subclass of str via type-check below is not
    a concern, but defence-in-depth) and non-string values.
    """
    if not isinstance(value, str):
        return False
    if not value:
        return False
    if "://" not in value:
        return False
    scheme = value.split("://", 1)[0].lower()
    return scheme in _REMOTE_SCHEMES


def validate_remote_uri(value: str) -> str:
    """Validate ``value`` as a recognised remote URI.

    Returns the canonicalised URI (scheme lowercased) on success. Raises
    ``ValueError`` otherwise. Bucket / container name must match
    ``_BUCKET_RE`` to defeat URL-injection attacks against fsspec backends.
    """
    if not isinstance(value, str):
        raise ValueError("remote URI must be a string")
    if not value:
        raise ValueError("remote URI must not be empty")
    if "\x00" in value:
        raise ValueError("remote URI must not contain null bytes")
    if len(value) > _MAX_REMOTE_PATH:
        raise ValueError(f"remote URI must be <= {_MAX_REMOTE_PATH} chars")

    parsed = urlparse(value)
    scheme = (parsed.scheme or "").lower()
    if scheme not in _REMOTE_SCHEMES:
        raise ValueError(
            f"remote URI scheme '{scheme}' not in allowlist: "
            f"{sorted(_REMOTE_SCHEMES)}"
        )
    if parsed.username or parsed.password:
        raise ValueError(
            "remote URI must not embed userinfo — use environment variables "
            "for cloud credentials instead"
        )
    if parsed.fragment:
        raise ValueError("remote URI must not contain a '#' fragment")
    if parsed.query:
        raise ValueError(
            "remote URI must not contain a '?' query string — fsspec backends "
            "interpret query parameters as configuration overrides (SSRF-adjacent)."
        )
    bucket = parsed.netloc
    if not bucket:
        raise ValueError("remote URI must include a bucket / container name")
    if not _BUCKET_RE.match(bucket):
        raise ValueError(
            f"remote URI bucket '{bucket}' must be alphanumeric + ._- "
            "(2-63 chars, leading alnum)"
        )
    return f"{scheme}://{bucket}{parsed.path}"


def required_remote_package(scheme: str) -> Optional[str]:
    """Return the pip-installable package name for a remote scheme."""
    if not isinstance(scheme, str):
        return None
    return _REMOTE_SCHEMES.get(scheme.lower())


# --- Part B: Streaming + sharding bounds -----------------------------------

# Tight bounds — beyond these the pipeline OOMs the DataLoader prefetch queue
# (cf. v0.32.0 GradAccumMonitor MAX_ACCUM=1024 policy).
_MIN_BUFFER_SIZE = 1
_MAX_BUFFER_SIZE = 1_000_000
_MIN_SHARDS = 1
_MAX_SHARDS = 1024


def validate_buffer_size(value: Optional[int]) -> Optional[int]:
    if value is None:
        return None
    if isinstance(value, bool):
        raise ValueError("buffer_size must not be bool")
    if not isinstance(value, int):
        raise ValueError("buffer_size must be an integer")
    if value < _MIN_BUFFER_SIZE or value > _MAX_BUFFER_SIZE:
        raise ValueError(
            f"buffer_size must be in [{_MIN_BUFFER_SIZE}, {_MAX_BUFFER_SIZE}]"
        )
    return value


def validate_shards(value: Optional[int]) -> Optional[int]:
    if value is None:
        return None
    if isinstance(value, bool):
        raise ValueError("shards must not be bool")
    if not isinstance(value, int):
        raise ValueError("shards must be an integer")
    if value < _MIN_SHARDS or value > _MAX_SHARDS:
        raise ValueError(f"shards must be in [{_MIN_SHARDS}, {_MAX_SHARDS}]")
    return value


# --- Part C: AOT preprocessing cache --------------------------------------

# Mirrors v0.36.0 batch_cache.json content-hash policy. Cache key includes
# tokenizer + max_length + format + dataset path → SHA-256 → cache filename.
# Bump whenever the on-disk tokenization of a preprocessed row changes, so a
# dataset cached under an older encoding is never silently reused. v2 (#785):
# the chat path still tokenizes with the tokenizer's default add_special_tokens=True
# but now strips the one doubled leading BOS the chat template already rendered, so a
# row that used to bake in [bos, bos, ...] no longer does. v3 (#791): the chat path
# now also applies TRL's ``add_eos`` rule — a chat row that does not already end on
# the EOS gets one appended — so a cache built before this no longer trains without a
# stop token on templates that render none (the Qwen shape). A v2 cache is rejected.
# v4 (#1067): the chat path now renders with ``data.chat_template`` (it used the
# tokenizer's shipped template whatever the config said) and the template is part
# of the key. A v3 cache recorded no template, so it is rejected, not guessed at.
# v5 (#876): the chat path keeps only the template's own leading BOS, so a
# ``data.chat_template`` preset on a BOS-adding tokenizer no longer caches the
# post-processor's BOS, and a truncated row no longer gains an EOS. A v4 cache is
# rejected.
# v6 (#1054): rows now carry a ``labels`` column masked per the run's loss-mask
# mode (which is itself a key input, see ``mask_mode``); a v5 cache had no labels
# and TRL silently trained on the prompt, so it is rejected.
# v7 (#1127): the key now covers every ``DataConfig`` field that decides which rows
# land in the cache (``val_split``, ``replay*``, the streaming knobs, the media
# directories) plus the top-level ``task``. A v6 cache recorded none of them, so it
# is rejected.
_PREPROCESS_TOKENIZE_SCHEMA = "v7"

# Every ``DataConfig`` field is in exactly one of these two tables (#1127).
# ``tests/test_issue1127_preprocess_cache_key_fields.py`` walks the schema and
# fails on a field that is in neither, so a new field has to be classified before
# it can merge. The value names the ``make_preprocess_cache_key`` input that
# carries the field; ``dataset_path`` fields are folded in by
# ``preprocess_dataset_key_input``, which reads them from this table.
PREPROCESS_KEY_FIELDS: Mapping[str, str] = types.MappingProxyType({
    "train": "dataset_path",
    "interleave": "dataset_path",
    # _finalize caches only the train split, so the split decides the row set.
    "val_split": "dataset_path",
    # _finalize mixes replay rows into the train split before caching.
    "replay": "dataset_path",
    "replay_ratio": "dataset_path",
    "replay_seed": "dataset_path",
    # The streaming loaders pick rows, and their order, from these; val_split
    # then slices that order by position.
    "streaming": "dataset_path",
    "buffer_size": "dataset_path",
    # Vision and audio rows whose file does not resolve under the directory are
    # dropped by the loader before tokenization.
    "image_dir": "dataset_path",
    "audio_dir": "dataset_path",
    "format": "format_name",
    "max_length": "max_length",
    "chat_template": "chat_template",
    "train_on_responses_only": "mask_mode",
    "train_on_messages_with_train_field": "mask_mode",
    "mask_history": "mask_mode",
})

NOT_PREPROCESS_KEY_FIELDS: Mapping[str, str] = types.MappingProxyType({
    "tokenized_path": "where the cache is read from, not an input to it",
    "train_on_prompt": (
        "the schema requires train_on_responses_only: false with it, and that "
        "field already puts the full-sequence mask in mask_mode"
    ),
    "video_dir": "no loader reads it, so it cannot drop or change a row",
    "shards": "no runtime code reads it",
    "raft_shuffle_seed": "RAFT rows carry no messages, so preprocess caches none",
    "raft_epoch_shuffle": "RAFT rows carry no messages, so preprocess caches none",
    "eval_on_each_dataset": "no runtime code reads it (staged, #808)",
    "split_thinking": "no runtime code reads it",
    "image_min_pixels": "no runtime code reads it (staged, #808)",
    "image_max_pixels": "no runtime code reads it (staged, #808)",
    "image_resize_algorithm": "no runtime code reads it (staged, #808)",
    "video_fps": "no runtime code reads it (staged, #808)",
    "video_maxlen": "no runtime code reads it (staged, #808)",
    "add_new_tokens": (
        "pre_tokenized mode rejects this combination: preprocessing tokenizes "
        "with the base tokenizer and never applies live vocabulary expansion"
    ),
    "new_special_tokens": (
        "pre_tokenized mode rejects this combination for the same reason: cached "
        "ids cannot include live special-token expansion"
    ),
    "resize_vocab": "no runtime code reads it",
    "extend_conversation": "no runtime code reads it",
    "skip_prepare_dataset": "no runtime code reads it",
    "remove_unused_columns": (
        "no trainer reads it; the trainers that set remove_unused_columns pass "
        "False (#759)"
    ),
    "prompt_strategy": (
        "pre_tokenized mode rejects this combination because preprocessing "
        "never applies the live prompt formatter"
    ),
    "forget_set": "read by task: unlearn only, which never loads a preprocess cache",
    "retain_set": "read by task: unlearn only, which never loads a preprocess cache",
})

_DATASET_KEY_FIELDS: Tuple[str, ...] = tuple(
    name for name, carrier in PREPROCESS_KEY_FIELDS.items()
    if carrier == "dataset_path"
)


def preprocess_dataset_key_input(data_cfg: Any) -> str:
    """The ``dataset_path`` input both sides of the preprocess cache hash (#443, #1038).

    Folds in every field ``PREPROCESS_KEY_FIELDS`` routes to ``dataset_path``: a
    list ``data.train`` under a different ``data.interleave`` mixture, and since
    #1127 the split, replay and streaming settings and the media directories, all
    of which change which rows are cached. ``soup data preprocess`` and the
    ``pre_tokenized`` training gate both call this, so they cannot hash the row
    set differently: the gate once passed the raw list and
    ``make_preprocess_cache_key`` raised.

    ``getattr`` with a ``None`` default, per #761/#1101: several suites hand this a
    duck-typed stand-in carrying only ``train`` and ``interleave``.
    """
    return json.dumps(
        {name: getattr(data_cfg, name, None) for name in _DATASET_KEY_FIELDS},
        sort_keys=True,
    )


def preprocess_dataset_key_diff(stored: Any, current: str) -> List[str]:
    """The ``data.*`` fields whose values differ between two dataset key inputs (#1272).

    ``stored`` is the ``dataset_key`` a cache recorded in ``metadata.json`` (a
    dict); ``current`` is ``preprocess_dataset_key_input``'s JSON for the config
    being trained. Returns the differing field names in table order, so a refused
    cache can name what changed rather than leave two hashes to compare. A
    ``stored`` value that is not a dict (a hand-edited file) names no field
    rather than claim differences it cannot see.
    """
    now = json.loads(current)
    if not isinstance(stored, dict):
        return []
    return [name for name in _DATASET_KEY_FIELDS if stored.get(name) != now.get(name)]


def preprocess_mask_mode(data_cfg, training_cfg=None) -> str:
    """The loss-mask mode both sides of the preprocess cache hash (#1054).

    Mirrors ``data.sft_format.build_format_row``'s selection exactly (train
    field wins over responses-only; neither means full-sequence), so the cache
    writer and the ``pre_tokenized`` training gate cannot disagree about how a
    cached row was masked. ``train_on_prompt`` is schema-exclusive with
    ``train_on_responses_only``, so it lands in ``"full"`` on its own.

    ``training.train_on_eot`` widens the assistant-only mask over the trailing
    EOT and ``data.mask_history`` (#761) narrows it to the final span, so both
    change the cached row and both get a suffix here. Both reach only the
    assistant-only builder, exactly as in ``build_format_row``.

    Suffixes are appended in a fixed order and read back with ``in``, never
    ``endswith``: with two of them, ``endswith("+eot")`` is False for
    ``responses_only+eot+mask_history`` and the cache silently loses the EOT.

    ``getattr`` throughout, per #761/#1101: several suites hand this a duck-typed
    stand-in carrying only the fields that existed when they were written, and a
    hard attribute access turns those into AttributeError.
    """
    if getattr(data_cfg, "train_on_messages_with_train_field", False):
        return "train_field"
    if not getattr(data_cfg, "train_on_responses_only", True):
        return "full"
    mode = "responses_only"
    if getattr(training_cfg, "train_on_eot", False):
        mode += "+eot"
    if getattr(data_cfg, "mask_history", False):
        mode += "+mask_history"
    return mode


def make_preprocess_cache_key(
    *,
    dataset_path: str,
    tokenizer_name: str,
    max_length: int,
    format_name: str,
    mask_mode: str,
    task: str,
    chat_template: Optional[str] = None,
) -> str:
    """Return a 16-char hex cache key for AOT-tokenized output.

    Defence-in-depth: every input is type-checked and bool-rejected so the
    SHA-256 input is always canonical. Mirrors v0.36.0 ``make_cache_key``.

    ``chat_template`` is the resolved Jinja the chat path renders with (#1067), or
    ``None`` for the tokenizer's shipped template. Hashing the resolved string
    rather than a preset name means an edited preset also invalidates the cache.

    ``task`` is the top-level ``task`` (#1127): ``pretrain`` caches raw text with
    every token trained on, the chat tasks cache templated, masked rows, so a
    cache written for one must not load under the other.
    """
    if not isinstance(dataset_path, str) or not dataset_path:
        raise ValueError("dataset_path must be a non-empty string")
    if "\x00" in dataset_path:
        raise ValueError("dataset_path must not contain null bytes")
    if not isinstance(tokenizer_name, str) or not tokenizer_name:
        raise ValueError("tokenizer_name must be a non-empty string")
    if "\x00" in tokenizer_name:
        raise ValueError("tokenizer_name must not contain null bytes")
    if isinstance(max_length, bool):
        raise ValueError("max_length must not be bool")
    if not isinstance(max_length, int) or max_length <= 0:
        raise ValueError("max_length must be a positive int")
    if not isinstance(format_name, str) or not format_name:
        raise ValueError("format_name must be a non-empty string")
    if chat_template is not None and not isinstance(chat_template, str):
        raise ValueError("chat_template must be a string or None")
    if chat_template is not None and "\x00" in chat_template:
        raise ValueError("chat_template must not contain null bytes")
    if not isinstance(mask_mode, str) or not mask_mode:
        raise ValueError("mask_mode must be a non-empty string")
    if "\x00" in mask_mode:
        raise ValueError("mask_mode must not contain null bytes")
    if not isinstance(task, str) or not task:
        raise ValueError("task must be a non-empty string")
    if "\x00" in task:
        raise ValueError("task must not contain null bytes")
    # A new DataConfig field is classified in PREPROCESS_KEY_FIELDS or
    # NOT_PREPROCESS_KEY_FIELDS before it can merge (#1127). A new parameter here
    # is appended rather than inserted: the segment order is what
    # tests/preprocess_cache_blob.py reproduces for every schema generation.
    blob = (
        f"{_PREPROCESS_TOKENIZE_SCHEMA}\x1f{dataset_path}\x1f{tokenizer_name}"
        f"\x1f{max_length}\x1f{format_name}\x1f{chat_template or ''}"
        f"\x1f{mask_mode}\x1f{task}"
    )
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()[:16]


# --- Part D: Interleave strategies ----------------------------------------

INTERLEAVE_STRATEGIES: FrozenSet[str] = frozenset({
    "concat", "under", "over", "probs",
})

_MAX_INTERLEAVE_DATASETS = 32


@dataclass(frozen=True)
class InterleaveSpec:
    """Frozen value object — interleave plan for multi-dataset training.

    ``probs`` (when ``strategy == 'probs'``) names the per-dataset sampling
    probability and must sum to 1.0 (±1e-6). For ``concat`` / ``under`` /
    ``over`` it is None.
    """

    strategy: str
    probs: Optional[Tuple[float, ...]]


def parse_interleave(
    raw: object, *, num_datasets: int,
) -> Optional[InterleaveSpec]:
    """Parse an interleave directive from a ``soup.yaml`` value.

    Accepts:
    - ``None`` → return ``None`` (legacy single-dataset path).
    - ``str`` (one of ``concat`` / ``under`` / ``over``) → ``InterleaveSpec``
      with probs=None.
    - ``dict`` of the form ``{"strategy": "probs", "probs": [...]}``.

    Raises ``ValueError`` on every other shape — silent acceptance was the
    Axolotl-mode footgun this validator is here to prevent.
    """
    if raw is None:
        return None
    if isinstance(num_datasets, bool):
        raise ValueError("num_datasets must not be bool")
    if not isinstance(num_datasets, int) or num_datasets < 2:
        raise ValueError(
            "interleave requires >= 2 datasets — use a single dataset instead"
        )
    if num_datasets > _MAX_INTERLEAVE_DATASETS:
        raise ValueError(
            f"interleave supports at most {_MAX_INTERLEAVE_DATASETS} datasets"
        )

    if isinstance(raw, str):
        if raw not in INTERLEAVE_STRATEGIES:
            raise ValueError(
                f"interleave strategy must be one of "
                f"{sorted(INTERLEAVE_STRATEGIES)} (got {raw!r})"
            )
        if raw == "probs":
            raise ValueError(
                "interleave='probs' requires a 'probs' list — use "
                "{strategy: probs, probs: [...]} dict form."
            )
        return InterleaveSpec(strategy=raw, probs=None)

    if isinstance(raw, dict):
        strategy = raw.get("strategy")
        probs = raw.get("probs")
        if strategy not in INTERLEAVE_STRATEGIES:
            raise ValueError(
                f"interleave.strategy must be one of "
                f"{sorted(INTERLEAVE_STRATEGIES)} (got {strategy!r})"
            )
        if strategy != "probs":
            if probs is not None:
                raise ValueError(
                    f"interleave strategy={strategy!r} must not set 'probs'"
                )
            return InterleaveSpec(strategy=strategy, probs=None)
        if not isinstance(probs, list) or len(probs) != num_datasets:
            raise ValueError(
                f"interleave.probs must be a list of length {num_datasets} "
                f"(got {type(probs).__name__})"
            )
        cleaned: List[float] = []
        for index, entry in enumerate(probs):
            if isinstance(entry, bool):
                raise ValueError(
                    f"interleave.probs[{index}] must not be bool"
                )
            if not isinstance(entry, (int, float)):
                raise ValueError(
                    f"interleave.probs[{index}] must be numeric"
                )
            entry_f = float(entry)
            if not math.isfinite(entry_f):
                raise ValueError(
                    f"interleave.probs[{index}] must be finite"
                )
            if entry_f <= 0.0 or entry_f > 1.0:
                raise ValueError(
                    f"interleave.probs[{index}] must be in (0.0, 1.0]"
                )
            cleaned.append(entry_f)
        if abs(sum(cleaned) - 1.0) > 1e-6:
            raise ValueError("interleave.probs must sum to 1.0 (±1e-6)")
        return InterleaveSpec(strategy="probs", probs=tuple(cleaned))

    raise ValueError(
        f"interleave must be None, a string, or a dict (got {type(raw).__name__})"
    )


# --- Part D: Image min/max pixels + video fps/maxlen + resize algorithm ---

IMAGE_RESIZE_ALGORITHMS: FrozenSet[str] = frozenset({
    "nearest", "bilinear", "bicubic", "lanczos",
})

_MAX_IMAGE_PIXELS = 1_073_741_824  # 1 GP — Pillow's default DOS guard.
_MAX_VIDEO_MAXLEN = 4096
_MAX_VIDEO_FPS = 240


def validate_image_pixels(name: str, value: Optional[int]) -> Optional[int]:
    if value is None:
        return None
    if isinstance(value, bool):
        raise ValueError(f"{name} must not be bool")
    if not isinstance(value, int):
        raise ValueError(f"{name} must be an integer")
    if value <= 0 or value > _MAX_IMAGE_PIXELS:
        raise ValueError(f"{name} must be in (0, {_MAX_IMAGE_PIXELS}]")
    return value


def validate_video_maxlen(value: Optional[int]) -> Optional[int]:
    if value is None:
        return None
    if isinstance(value, bool):
        raise ValueError("video_maxlen must not be bool")
    if not isinstance(value, int):
        raise ValueError("video_maxlen must be an integer")
    if value <= 0 or value > _MAX_VIDEO_MAXLEN:
        raise ValueError(f"video_maxlen must be in (0, {_MAX_VIDEO_MAXLEN}]")
    return value


def validate_video_fps(value: Optional[float]) -> Optional[float]:
    if value is None:
        return None
    if isinstance(value, bool):
        raise ValueError("video_fps must not be bool")
    if not isinstance(value, (int, float)):
        raise ValueError("video_fps must be numeric")
    value_f = float(value)
    if not math.isfinite(value_f):
        raise ValueError("video_fps must be finite")
    if value_f <= 0.0 or value_f > _MAX_VIDEO_FPS:
        raise ValueError(f"video_fps must be in (0.0, {_MAX_VIDEO_FPS}]")
    return value_f


# --- Part E: Vocab expansion ----------------------------------------------

_MAX_NEW_TOKENS = 10_000  # ~ 30 MB embedding row * dim 8K → still RAM-safe.
_MAX_TOKEN_LEN = 256


def validate_new_tokens(value: Optional[List[str]]) -> Optional[List[str]]:
    """Validate ``add_new_tokens`` / ``new_special_tokens`` lists.

    Returns a new list (defensive copy) so caller mutation cannot leak into
    a stored Pydantic field. Mirrors v0.39.0 rank_pattern policy.
    """
    if value is None:
        return None
    if not isinstance(value, list):
        raise ValueError("must be a list of strings")
    if len(value) > _MAX_NEW_TOKENS:
        raise ValueError(f"too many tokens (max {_MAX_NEW_TOKENS})")
    cleaned: List[str] = []
    seen: set[str] = set()
    for index, token in enumerate(value):
        if not isinstance(token, str):
            raise ValueError(f"entry [{index}] must be a string")
        if not token:
            raise ValueError(f"entry [{index}] must not be empty")
        if "\x00" in token:
            raise ValueError(f"entry [{index}] must not contain null bytes")
        if len(token) > _MAX_TOKEN_LEN:
            raise ValueError(
                f"entry [{index}] must be <= {_MAX_TOKEN_LEN} chars"
            )
        if token in seen:
            raise ValueError(f"duplicate token {token!r}")
        seen.add(token)
        cleaned.append(token)
    return cleaned


def apply_vocab_expansion(tokenizer: Any, model: Any, data_cfg: Any) -> int:
    """Add configured tokens to ``tokenizer`` and resize ``model`` embeddings.

    The helper is intentionally shared by every text trainer so
    ``data.add_new_tokens`` / ``data.new_special_tokens`` are applied in one
    place. It is safe to call even when no expansion is configured.

    Returns:
        Number of tokens added to the tokenizer.
    """
    regular = list(dict.fromkeys(getattr(data_cfg, "add_new_tokens", None) or []))
    special = list(
        dict.fromkeys(getattr(data_cfg, "new_special_tokens", None) or [])
    )
    if not regular and not special:
        return 0

    existing = set()
    if hasattr(tokenizer, "get_vocab"):
        try:
            existing = set(tokenizer.get_vocab().keys())
        except Exception:
            existing = set()

    # Special tokens take precedence if the same string appears in both lists.
    special = [token for token in special if token not in existing]
    special_set = set(special)
    regular = [
        token for token in regular
        if token not in existing and token not in special_set
    ]

    added = 0
    if regular and hasattr(tokenizer, "add_tokens"):
        result = tokenizer.add_tokens(regular)
        added += int(result or 0)
    if special and hasattr(tokenizer, "add_special_tokens"):
        result = tokenizer.add_special_tokens(
            {"additional_special_tokens": special}
        )
        added += int(result or 0)

    if added > 0 and hasattr(model, "resize_token_embeddings"):
        model.resize_token_embeddings(len(tokenizer))
    return added


# --- Part E: Custom prompt strategies -------------------------------------

# Module:fn syntax allowlist — mirrors how Axolotl exposes user transforms.
# Live runtime invocation deferred to v0.42.1; the schema validates the
# reference shape now so a typo fails loudly.
_PROMPT_STRATEGY_RE = re.compile(
    r"^[A-Za-z_][A-Za-z0-9_.]{0,127}:[A-Za-z_][A-Za-z0-9_]{0,127}$"
)


def validate_prompt_strategy(value: Optional[str]) -> Optional[str]:
    if value is None:
        return None
    if not isinstance(value, str):
        raise ValueError("prompt_strategy must be a string")
    if not value:
        raise ValueError("prompt_strategy must not be empty")
    if "\x00" in value:
        raise ValueError("prompt_strategy must not contain null bytes")
    # Regex allows up to 128 chars per side + colon = 257 chars; cap at 260
    # to absorb any future regex relaxation without mismatching the bounds.
    if len(value) > 260:
        raise ValueError("prompt_strategy must be <= 260 chars")
    if not _PROMPT_STRATEGY_RE.match(value):
        raise ValueError(
            "prompt_strategy must match 'module.path:function_name' "
            "(letters / digits / underscore / dot only)."
        )
    return value


# --- v0.53.7 #86: pre-tokenized Arrow shard loader ------------------------
#
# Reads a directory produced by ``soup data preprocess`` (Arrow shards from
# ``datasets.Dataset.save_to_disk``). Used by SFT + Pretrain wrappers to
# short-circuit tokenization when ``data.format='pre_tokenized'`` and
# ``data.tokenized_path`` is set. Containment + symlink TOCTOU defence
# enforced before the heavy ``datasets.load_from_disk`` call.

def load_pretokenized_dataset(
    tokenized_path: str,
    *,
    expected_cache_key: Optional[str] = None,
) -> Any:
    """Load a pre-tokenized Arrow dataset directory.

    Verifies cwd containment, rejects symlinks at the target path (TOCTOU —
    mirrors v0.33.0 #22 / v0.43.0 Part C / v0.44.0 Part B policy), and
    cross-checks ``metadata.json`` cache_key when ``expected_cache_key`` is
    provided. Lazy-imports ``datasets`` so the helper itself loads on a
    fresh interpreter.

    Raises:
        TypeError: if ``tokenized_path`` is not a string.
        ValueError: on null bytes, non-existent path, out-of-cwd path,
            symlink at target, mismatched cache_key, or malformed metadata.
        ImportError: if ``datasets`` is not installed.
    """
    import stat as _stat

    from soup_cli.utils.paths import is_under_cwd

    if not isinstance(tokenized_path, str):
        raise TypeError("tokenized_path must be a string")
    if not tokenized_path:
        raise ValueError("tokenized_path must be a non-empty string")
    if "\x00" in tokenized_path:
        raise ValueError("tokenized_path must not contain null bytes")
    real = os.path.realpath(tokenized_path)
    if not is_under_cwd(real):
        raise ValueError("tokenized_path must stay under cwd")
    # Lstat the ORIGINAL (unresolved) path to detect symlinks at the entry
    # point — mirrors v0.33.0 #22 / v0.43.0 Part C TOCTOU policy.
    try:
        lst = os.lstat(tokenized_path)
    except OSError as exc:
        raise ValueError(f"tokenized_path not found: {tokenized_path!r}") from exc
    if _stat.S_ISLNK(lst.st_mode):
        raise ValueError("tokenized_path must not be a symlink")
    if not os.path.isdir(real):
        raise ValueError(f"tokenized_path must be a directory: {tokenized_path!r}")

    metadata_path = os.path.join(real, "metadata.json")
    if os.path.isfile(metadata_path):
        try:
            import json as _json

            with open(metadata_path, encoding="utf-8") as f:
                metadata = _json.load(f)
        except (OSError, ValueError) as exc:
            raise ValueError(
                f"metadata.json in tokenized_path is unreadable: {exc}"
            ) from exc
        if (
            expected_cache_key is not None
            and metadata.get("cache_key") != expected_cache_key
        ):
            raise ValueError(
                f"cache_key mismatch: expected {expected_cache_key!r}, "
                f"got {metadata.get('cache_key')!r}"
            )

    try:
        from datasets import load_from_disk
    except ImportError as exc:
        raise ImportError(
            "datasets is required for pre_tokenized short-circuit: "
            "pip install datasets"
        ) from exc
    return load_from_disk(real)


# --- v0.53.7 #87: prompt_strategy live resolver ---------------------------
#
# Resolves a validated ``module.path:function_name`` spec into a callable
# applied per-row at SFT format time. Validation surface (regex / null-byte /
# oversize) lives in ``validate_prompt_strategy`` above — this is the runtime
# resolver that lazy-imports the named module and verifies the callable
# signature accepts a single positional argument and returns a ``Mapping``.

_PROMPT_STRATEGY_LOG = logging.getLogger("soup_cli.utils.data_pipeline.prompt_strategy")


@functools.lru_cache(maxsize=64)
def resolve_prompt_strategy(spec: str) -> Callable[[Mapping[str, Any]], Mapping[str, Any]]:
    """Resolve ``module.path:fn_name`` into a callable.

    Lazy-imports the named module via :mod:`importlib`, fetches the
    referenced attribute, and verifies the callable accepts a single
    positional argument. Per-spec ``lru_cache`` so trainer loops do not pay
    the import cost on every row.

    Raises:
        TypeError: if ``spec`` is not a string.
        ValueError: if ``spec`` does not match the validator regex, the
            module cannot be imported, the attribute is missing, or the
            resolved object is not callable / has the wrong signature.
    """
    # Re-validate the shape — defence-in-depth so direct callers cannot
    # bypass the schema-validator that fires on YAML load.
    validate_prompt_strategy(spec)
    # v0.53.7 H-G: ``assert`` is stripped under ``python -O``. Replace with
    # an explicit TypeError so the type narrowing survives optimisation.
    if not isinstance(spec, str):
        raise TypeError(
            f"prompt_strategy must be a str, got {type(spec).__name__}"
        )

    module_path, _, fn_name = spec.partition(":")
    try:
        import importlib

        module = importlib.import_module(module_path)
    except ImportError as exc:
        raise ValueError(
            f"prompt_strategy module {module_path!r} could not be imported: {exc}"
        ) from exc
    if not hasattr(module, fn_name):
        raise ValueError(
            f"prompt_strategy {spec!r}: module {module_path!r} has no attribute "
            f"{fn_name!r}"
        )
    fn = getattr(module, fn_name)
    if not callable(fn):
        raise ValueError(
            f"prompt_strategy {spec!r}: resolved attribute is not callable "
            f"({type(fn).__name__})"
        )
    # Best-effort signature check — builtins / C-extensions may not expose a
    # signature; in that case we skip the check and rely on the per-row
    # exception swallow.
    # v0.53.7 H-E: narrow the catch to TypeError (signature unavailable for
    # builtins / C-extensions). The ValueError raised below is the
    # signature-shape error we explicitly want to surface — swallowing it
    # would let a bad callable through.
    try:
        sig = inspect.signature(fn)
    except (TypeError, ValueError):
        # Signature unavailable (builtin / C-extension); skip the check.
        return fn
    positional_count = 0
    has_var_positional = False
    for param in sig.parameters.values():
        if param.kind in (
            inspect.Parameter.POSITIONAL_ONLY,
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
        ):
            if param.default is inspect.Parameter.empty:
                positional_count += 1
        elif param.kind == inspect.Parameter.VAR_POSITIONAL:
            has_var_positional = True
    if not has_var_positional and positional_count > 1:
        raise ValueError(
            f"prompt_strategy {spec!r}: callable must accept at most one "
            f"required positional argument (found {positional_count})"
        )
    return fn


def apply_prompt_strategy(
    spec: Optional[str], row: Mapping[str, Any]
) -> Mapping[str, Any]:
    """Apply the resolved prompt_strategy to ``row`` if ``spec`` is set.

    Mirrors the v0.33.0 #47 ``CrossDocCollator`` silent-degrade policy: a
    per-row callable exception is logged at DEBUG and the original row is
    returned unchanged (defence so a single transform bug doesn't crash a
    multi-hour training run).
    """
    if spec is None:
        return row
    try:
        fn = resolve_prompt_strategy(spec)
    except (TypeError, ValueError):
        # Hard config errors must surface at trainer setup time, not silently
        # at every row. We re-raise here.
        raise
    try:
        result = fn(row)
    except Exception as exc:  # noqa: BLE001 — user callable can raise anything
        _PROMPT_STRATEGY_LOG.debug(
            "prompt_strategy %r raised on row: %s", spec, exc
        )
        return row
    if not isinstance(result, Mapping):
        _PROMPT_STRATEGY_LOG.debug(
            "prompt_strategy %r returned non-Mapping (%s); using original row",
            spec,
            type(result).__name__,
        )
        return row
    return result


# --- Part F: Document ingestion -------------------------------------------

INGEST_EXTENSIONS: FrozenSet[str] = frozenset({".pdf", ".docx", ".md", ".txt"})


# v0.53.7 #88 — markdown heading-aware splitter.
#
# Splits a markdown document on ATX headings (``^#{1,6}\s``) and emits one
# record per section. A preamble before the first heading is emitted as a
# record with ``section=None`` / ``level=None``. Pure function — no I/O.
_MD_HEADING_RE = re.compile(r"^(#{1,6})\s+(.+?)\s*$")
_MAX_MD_SECTIONS = 10_000


def split_markdown_by_headings(text: str) -> List[Mapping[str, Any]]:
    """Split markdown ``text`` on ATX headings into section records.

    Each output record has three keys: ``section`` (heading text, or ``None``
    for preamble), ``level`` (1-6, or ``None`` for preamble), and ``text``
    (body content following the heading; may be empty).

    Trailing empty whitespace-only sections are emitted as-is; the caller
    decides whether to keep or drop. Capped at ``_MAX_MD_SECTIONS`` to defend
    against pathological inputs.

    Raises ``TypeError`` on non-string input.
    """
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    lines = text.splitlines()
    sections: List[Mapping[str, Any]] = []
    current_section: Optional[str] = None
    current_level: Optional[int] = None
    body: List[str] = []

    def _flush() -> None:
        if current_section is None and not body:
            return
        sections.append(
            {
                "section": current_section,
                "level": current_level,
                "text": "\n".join(body).strip(),
            }
        )

    for line in lines:
        m = _MD_HEADING_RE.match(line)
        if m:
            _flush()
            if len(sections) >= _MAX_MD_SECTIONS:
                break
            current_section = m.group(2).strip()
            current_level = len(m.group(1))
            body = []
        else:
            body.append(line)
    _flush()
    return sections


def detect_ingest_format(path: str) -> str:
    """Return the canonical ingest format for ``path`` based on extension.

    Raises ``ValueError`` on unsupported extensions so the CLI can present a
    friendly error before the lazy import path triggers a confusing
    ImportError on a missing optional dep.
    """
    if not isinstance(path, str) or not path:
        raise ValueError("path must be a non-empty string")
    if "\x00" in path:
        raise ValueError("path must not contain null bytes")
    ext = os.path.splitext(path)[1].lower()
    if ext not in INGEST_EXTENSIONS:
        raise ValueError(
            f"ingest only supports {sorted(INGEST_EXTENSIONS)} — got {ext!r}"
        )
    if ext == ".md":
        return "markdown"
    return ext.lstrip(".")


# --- Public introspection helpers (for tests + docs) ----------------------

def remote_schemes() -> Tuple[str, ...]:
    """Return a sorted, immutable view of recognised remote schemes."""
    return tuple(sorted(_REMOTE_SCHEMES))


def interleave_strategies() -> Tuple[str, ...]:
    return tuple(sorted(INTERLEAVE_STRATEGIES))


def new_formats() -> Tuple[str, ...]:
    return tuple(sorted(NEW_FORMATS_V0_42))


def ingest_extensions() -> Tuple[str, ...]:
    return tuple(sorted(INGEST_EXTENSIONS))


__all__ = [
    "InterleaveSpec",
    "NEW_FORMATS_V0_42",
    "INTERLEAVE_STRATEGIES",
    "IMAGE_RESIZE_ALGORITHMS",
    "INGEST_EXTENSIONS",
    "is_remote_uri",
    "validate_remote_uri",
    "required_remote_package",
    "validate_buffer_size",
    "validate_shards",
    "make_preprocess_cache_key",
    "preprocess_mask_mode",
    "load_pretokenized_dataset",
    "parse_interleave",
    "validate_image_pixels",
    "validate_video_maxlen",
    "validate_video_fps",
    "validate_new_tokens",
    "validate_prompt_strategy",
    "resolve_prompt_strategy",
    "apply_prompt_strategy",
    "detect_ingest_format",
    "split_markdown_by_headings",
    "remote_schemes",
    "interleave_strategies",
    "new_formats",
    "ingest_extensions",
]


# Generator-friendly probe used by tests — confirms the module loads on a
# fresh interpreter without importing torch / transformers / fsspec.
def _selfcheck() -> Dict[str, int]:
    return {
        "new_formats": len(NEW_FORMATS_V0_42),
        "remote_schemes": len(_REMOTE_SCHEMES),
        "interleave_strategies": len(INTERLEAVE_STRATEGIES),
        "image_resize_algorithms": len(IMAGE_RESIZE_ALGORITHMS),
        "ingest_extensions": len(INGEST_EXTENSIONS),
    }


def _iter_immutable(items: Iterable[str]) -> Tuple[str, ...]:
    return tuple(sorted(items))
