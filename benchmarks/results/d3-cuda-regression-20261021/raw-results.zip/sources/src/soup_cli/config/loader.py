"""Load and validate soup.yaml configs."""

import warnings
from pathlib import Path

import yaml
from pydantic import ValidationError
from rich.console import Console

from soup_cli.config.deprecation import SoupConfigDeprecationWarning
from soup_cli.config.schema import SoupConfig
from soup_cli.config.staged_fields import find_staged_config_fields, format_staged_fields
from soup_cli.config.unknown_keys import find_unknown_config_keys, format_unknown_keys
from soup_cli.utils.terminal import for_terminal

console = Console()

#: What to do about a key no model declares (#627).
#:
#: ``"warn"``  -- report and continue. Non-breaking: a config written for a
#:               newer Soup still runs on an older one.
#: ``"error"`` -- refuse to load.
#:
#: Detection is identical either way; this is the only difference between the
#: options argued on #627, kept as one switch so the decision is a one-line
#: change rather than a rewrite.
#:
#: The decision was warn-then-forbid. v0.74.0 shipped ``"warn"`` with a
#: deadline named by
#: :data:`~soup_cli.config.unknown_keys.UNKNOWN_KEY_REJECTION_VERSION` -- by
#: reference, not by number, because the warning stated that version in
#: exactly one place -- and the release that reached it flipped this to
#: ``"error"``. ``TestTheDeadline`` pins the switch to the declared
#: ``__version__`` in both directions, so it can be neither forgotten nor
#: flipped early.
UNKNOWN_KEY_SEVERITY = "error"

#: What to do about a declared config field that is read by nothing (#808).
#:
#: The decision was warn-then-forbid. Ships ``"warn"`` with a deadline named
#: by :data:`~soup_cli.config.staged_fields.STAGED_FIELD_REJECTION_VERSION` -- by
#: reference, not by number, because the warning stated that version in
#: exactly one place -- and the release that reaches it flips this to
#: ``"error"``.
STAGED_FIELD_SEVERITY = "warn"


def _report_unknown_keys(raw: dict) -> "str | None":
    """Return an error string when unknown keys must stop the load.

    Silence is the thing being fixed, so a finding is always surfaced: under
    ``"warn"`` it is printed and ``None`` is returned; under ``"error"`` the
    message is handed back for the caller to raise in its own contract
    (``SystemExit`` for the CLI, ``ValueError`` for the API/UI).
    """
    unknown = find_unknown_config_keys(raw)
    if not unknown:
        return None
    # One report per load with every finding in it, whatever the severity --
    # a config carrying four typos should produce one panel, not four.
    warning = UNKNOWN_KEY_SEVERITY != "error"
    message = format_unknown_keys(unknown, include_deadline=warning)
    if not warning:
        return message
    # The key names in ``message`` came from the config file: escape them.
    console.print(f"[yellow]Warning:[/] {for_terminal(message)}")
    console.print(
        "[dim]An unapplied key is ignored, not defaulted -- the run proceeds as "
        "if you had not written it.[/]"
    )
    return None


def _report_staged_fields(
    raw: dict, *, config: SoupConfig
) -> "str | None":
    """Return an error string when staged fields must stop the load (#808).

    Silence is the thing being fixed: under ``"warn"`` it is printed and
    ``None`` is returned; under ``"error"`` the message is handed back for the
    caller to raise in its own contract (``SystemExit`` for the CLI,
    ``ValueError`` for the API/UI).
    """
    staged = find_staged_config_fields(raw, config=config)
    if not staged:
        return None
    warning = STAGED_FIELD_SEVERITY != "error"
    message = format_staged_fields(staged, include_deadline=warning)
    if not warning:
        return message
    console.print(f"[yellow]Warning:[/] {for_terminal(message)}")
    return None


def _build_config(raw: dict) -> SoupConfig:
    """Construct ``SoupConfig``, printing each deprecated value once (#759).

    Validators report a value that will be refused in a later release as a
    :class:`SoupConfigDeprecationWarning`. Recorded here rather than left to the
    ``warnings`` filters, which print a source line, may show a message once
    per process rather than once per load, or hide it entirely. Any other
    warning raised while building is passed on unchanged.
    """
    try:
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            config = SoupConfig(**raw)
    finally:
        # Outside the ``catch_warnings`` block: re-raising a warning inside it
        # would record it again into the list being walked.
        printed: set = set()
        for item in caught:
            if issubclass(item.category, SoupConfigDeprecationWarning):
                message = str(item.message)
                if message not in printed:
                    printed.add(message)
                    console.print(f"[yellow]Warning:[/] {for_terminal(message)}")
            else:
                warnings.warn_explicit(item.message, item.category, item.filename, item.lineno)
    return config


def load_config(
    path: "Path | str",
    *,
    training_overrides: dict | None = None,
) -> SoupConfig:
    """Load a soup.yaml file and return validated SoupConfig.

    ``training_overrides`` are merged into the YAML ``training:`` mapping
    *before* ``SoupConfig`` is constructed, so CLI flags that map onto
    training fields participate in the same cross-validators as YAML.
    """
    path = Path(path)
    raw = yaml.safe_load(path.read_text(encoding="utf-8"))

    if raw is None:
        console.print("[red]Config file is empty[/]")
        raise SystemExit(1)
    if not isinstance(raw, dict):
        # A bare list ("- a") or scalar would reach SoupConfig(**raw) and die
        # with a TypeError traceback; load_config_from_string already refuses
        # this shape, and the CLI contract here is SystemExit(1).
        console.print(f"[red]Config must be a YAML mapping, got {type(raw).__name__}[/]")
        raise SystemExit(1)

    if training_overrides:
        training = raw.get("training")
        if not isinstance(training, dict):
            training = {}
            raw["training"] = training
        training.update(training_overrides)

    unknown_error = _report_unknown_keys(raw)
    if unknown_error is not None:
        console.print("[red bold]Config validation error:[/]\n")
        console.print(f"  [red]{for_terminal(unknown_error)}[/]")
        raise SystemExit(1)

    try:
        config = _build_config(raw)
    except ValidationError as e:
        console.print("[red bold]Config validation error:[/]\n")
        for err in e.errors():
            loc = " -> ".join(str(part) for part in err["loc"])
            # Both can quote config keys or values from the file.
            console.print(f"  [red]{for_terminal(loc)}:[/] {for_terminal(err['msg'])}")
        raise SystemExit(1)

    staged_error = _report_staged_fields(raw, config=config)
    if staged_error is not None:
        console.print("[red bold]Config validation error:[/]\n")
        console.print(f"  [red]{for_terminal(staged_error)}[/]")
        raise SystemExit(1)

    return config


def load_config_from_string(yaml_str: str) -> SoupConfig:
    """Parse a YAML string and return validated SoupConfig.

    Unlike load_config(), raises ValueError on errors instead of SystemExit,
    making it suitable for API/UI usage.
    """
    raw = yaml.safe_load(yaml_str)
    if raw is None:
        raise ValueError("Config is empty")
    if not isinstance(raw, dict):
        # A non-mapping document (e.g. a bare list "- a") would make
        # SoupConfig(**raw) raise TypeError, breaking this function's
        # ValueError-only contract (API/UI callers only catch ValueError).
        raise ValueError(
            f"Config must be a YAML mapping, got {type(raw).__name__}"
        )

    unknown_error = _report_unknown_keys(raw)
    if unknown_error is not None:
        raise ValueError(unknown_error)

    try:
        config = _build_config(raw)
    except ValidationError as exc:
        errors = []
        for err in exc.errors():
            loc = " -> ".join(str(part) for part in err["loc"])
            errors.append(f"{loc}: {err['msg']}")
        raise ValueError("; ".join(errors))

    staged_error = _report_staged_fields(raw, config=config)
    if staged_error is not None:
        raise ValueError(staged_error)

    return config
