"""Reproduce descriptive C4 analysis from an extracted evidence directory.

Usage: python analyze_c4.py EVIDENCE_DIRECTORY OUTPUT_DIRECTORY
No drive access or benchmark execution.
"""
import hashlib
import json
import math
import sys
from pathlib import Path


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def percentile(values, fraction):
    values = sorted(values)
    index = (len(values) - 1) * fraction
    lo = math.floor(index)
    hi = math.ceil(index)
    return values[lo] + (values[hi] - values[lo]) * (index - lo)


def rate(samples, start, end):
    """Time overlap weighting; assumes constant rate inside each ~1s sample."""
    amount = coverage = 0.0
    for row in samples:
        right = row['elapsed_s']
        left = right - row['interval_s']
        overlap = max(0, min(end, right) - max(start, left))
        amount += row['read_bytes'] * overlap / row['interval_s']
        coverage += overlap
    assert abs(coverage - (end - start)) < 0.001, (start, end, coverage)
    return amount / (end - start) / 1e9


def analyze(root):
    selected = 'run-run-7eab09a633'
    arm = read(root / selected / 'arm.json')
    samples = rows(root / selected / 'samples.jsonl')
    thermal = rows(root / selected / 'temperature.jsonl')
    assert arm == read(root / selected / 'summary.json')
    assert arm['status'] == 'candidate' and arm['elapsed_s'] == 3600
    assert arm['F1']['outcome'] == 'ok'
    assert all(arm['F1']['checks'][key]['outcome'] == 'ok'
               for key in ('suspend', 'power', 'foreign_reads'))
    protocol = read(root / 'protocols' / (arm['protocol_commit'] + '.json'))
    assert protocol == arm['protocol']
    assert arm['fixture']['size_bytes'] > arm['fixture']['physical_ram_bytes']
    assert arm['fixture']['sha256'] == protocol['fixture_sha256']
    assert arm['sources'] == protocol['sources']
    for name, expected in arm['sources'].items():
        assert hashlib.sha256((root / 'runner' / name).read_bytes()).hexdigest() == expected, name
    assert thermal[0]['temperature_c'] <= 40
    assert all('error' not in row and 0 < row['temperature_c'] < 75 for row in thermal)
    assert max(b['monotonic_s'] - a['monotonic_s']
               for a, b in zip(thermal, thermal[1:])) <= 15
    provenance = read(root / 'provenance.json')
    assert provenance['protocol_commit_unix'] < thermal[0]['time_unix']
    previous_time = previous_bytes = 0
    for row in samples:
        assert row['elapsed_s'] > previous_time
        assert abs(row['elapsed_s'] - previous_time - row['interval_s']) < 0.001
        assert row['total_bytes'] - previous_bytes == row['read_bytes']
        assert row['read_bytes'] == row['requests'] * 4 * 1024**2
        assert abs(row['GB_s'] - row['read_bytes'] / row['interval_s'] / 1e9) < 1e-9
        previous_time, previous_bytes = row['elapsed_s'], row['total_bytes']
    assert previous_time == arm['elapsed_s'] and previous_bytes == arm['total_bytes']
    windows = [{'start_s': start, 'end_s': start + 60,
                'GB_s': rate(samples, start, start + 60)} for start in range(600, 3600, 60)]
    attempts = []
    for directory in sorted(root.glob('run-run-*')):
        record = read(directory / 'arm.json') if (directory / 'arm.json').exists() else {}
        data = rows(directory / 'samples.jsonl') if (directory / 'samples.jsonl').exists() else []
        temps = rows(directory / 'temperature.jsonl') if (directory / 'temperature.jsonl').exists() else []
        attempts.append({'run': directory.name, 'status': record.get('status', 'incomplete_no_summary'),
                         'error': record.get('error'),
                         'last_sample_s': data[-1]['elapsed_s'] if data else None,
                         'start_unix': temps[0]['time_unix'] if temps else None,
                         'F1': record.get('F1', {}).get('outcome'),
                         'protocol_commit': record.get('protocol_commit')})
    attempts.sort(key=lambda row: row['start_unix'] or 0)
    read_delta = arm['disk_after']['read_bytes'] - arm['disk_before']['read_bytes']
    p10 = percentile([row['GB_s'] for row in windows], 0.1)
    return {
        'scope': 'Exploratory single-host disk primitive; not formal C4 acceptance',
        'formal_acceptance_claimed': False,
        'deviation': 'Additional interrupted/incomplete attempts beyond the one-replacement declaration; all retained. No retrospective protocol repair.',
        'selected_run': selected, 'protocol_commit': arm['protocol_commit'],
        'integrity_checks': 'passed for selected run; original fixture full rehash and live hardware identity were not repeated during analysis',
        'duration_s': arm['elapsed_s'], 'read_bytes': arm['total_bytes'],
        'sample_count': len(samples), 'thermal_samples': len(thermal),
        'max_sample_interval_s': max(row['interval_s'] for row in samples),
        'temperature_start_c': thermal[0]['temperature_c'],
        'temperature_max_c': max(row['temperature_c'] for row in thermal),
        'temperature_end_c': thermal[-1]['temperature_c'],
        'max_temperature_query_s': max(row['query_s'] for row in thermal),
        'whole_run_GB_s': arm['total_bytes'] / 3600 / 1e9,
        'warmup_0_600_GB_s': rate(samples, 0, 600),
        'postwarmup_600_3600_GB_s': rate(samples, 600, 3600),
        'last_600_GB_s': rate(samples, 3000, 3600),
        'postwarmup_window_min_GB_s': min(row['GB_s'] for row in windows),
        'postwarmup_window_p10_GB_s': p10,
        'planner_heuristic_GB_s': 0.9 * p10,
        'planner_use': 'Provisional estimate for this host/read pattern only; no production default or generalization',
        'physical_read_delta_bytes': read_delta,
        'physical_minus_reader_bytes': read_delta - arm['total_bytes'],
        'physical_write_delta_bytes': arm['disk_after']['write_bytes'] - arm['disk_before']['write_bytes'],
        'foreign_read_check': arm['F1']['checks']['foreign_reads']['reason'],
        'minimum_available_ram_bytes': min(row['ram_available_bytes'] for row in samples),
        'postwarmup_windows': windows, 'attempts': attempts,
        'attribution': 'Temperature association is descriptive. Logical per-process reads and aggregate physical counters cannot prove thermal causation or full physical-I/O isolation.',
    }


if __name__ == '__main__':
    result = analyze(Path(sys.argv[1]))
    target = Path(sys.argv[2])
    target.mkdir(parents=True, exist_ok=True)
    (target / 'analysis.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
    print(json.dumps({key: value for key, value in result.items()
                      if key not in ('postwarmup_windows', 'attempts')}, indent=2))
