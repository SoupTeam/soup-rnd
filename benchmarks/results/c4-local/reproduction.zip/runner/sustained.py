"""C4 Windows reader. Smoke tests are explicitly excluded from research results."""
import argparse
import ctypes
import hashlib
import json
import math
import mmap
import os
import shutil
import stat
import subprocess
import sys
import threading
import time
import uuid
from pathlib import Path

import preflight
import psutil
from preflight import ArmWatch, open_direct, windows_power_supplies

ROOT = Path(__file__).resolve().parent
GIB = 1024**3
MIB = 1024**2


def write_json(path, obj):
    path.write_text(json.dumps(obj, indent=2), encoding='utf-8')


def sources():
    paths = [ROOT / 'sustained.py', ROOT / 'preflight.py',
             *sorted((ROOT / 'source').glob('*.py'))]
    return {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in paths}


def disk_counter():
    counters = psutil.disk_io_counters(perdisk=True)
    if 'PhysicalDrive0' not in counters:
        raise RuntimeError('PhysicalDrive0 I/O counter missing')
    return counters['PhysicalDrive0']._asdict()


def check_mapping():
    if sys.platform != 'win32' or ROOT.drive.upper() != 'C:':
        raise RuntimeError('This runner is scoped to C: on Windows')
    query = "(Get-Partition -DriveLetter C -ErrorAction Stop).DiskNumber"
    p = subprocess.run(['powershell.exe', '-NoProfile', '-Command', query],
                       capture_output=True, text=True, timeout=15, check=False)
    if p.returncode or p.stdout.strip() != '0':
        raise RuntimeError('C: must map to physical disk 0')


class ThermalGuard:
    """Stop on sensor errors or a stale reading. Cannot interrupt a kernel-hung I/O."""

    def __init__(self, log, sensor=preflight.temperature, clock=time.monotonic,
                 interval=5.0, stale=15.0):
        self.log, self.sensor, self.clock = log, sensor, clock
        self.interval, self.stale = interval, stale
        self.last = None
        self.error = None
        self.stop_event = threading.Event()
        self.thread = None

    def sample(self):
        start = self.clock()
        try:
            value = self.sensor()
            if not isinstance(value, (float, int)) or not math.isfinite(value):
                raise RuntimeError('Temperature is missing or nonfinite')
            if not 0 < value < preflight.STOP_C:
                raise RuntimeError(f'Temperature outside operational range: {value}')
            self.last = self.clock()
            row = {'time_unix': time.time(), 'monotonic_s': self.last,
                   'temperature_c': value, 'query_s': self.last - start}
        except Exception as exc:  # noqa: BLE001 -- fail closed and retain sensor failure
            self.error = repr(exc)
            row = {'time_unix': time.time(), 'error': self.error}
        self.log.write(json.dumps(row) + '\n')
        self.log.flush()

    def _loop(self):
        while not self.stop_event.wait(self.interval):
            self.sample()
            if self.error:
                break

    def check(self):
        if self.error:
            raise RuntimeError('Temperature guard: ' + self.error)
        if self.last is None or self.clock() - self.last > self.stale:
            raise RuntimeError('Temperature guard: stale or absent sensor')

    def __enter__(self):
        self.sample()
        self.check()
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()
        return self

    def __exit__(self, *args):
        self.stop_event.set()
        if self.thread:
            self.thread.join(timeout=22)


def check_power():
    if windows_power_supplies()['online'].get('ac_line') is not True:
        raise RuntimeError('AC power missing or unknown')


def fixture_check(path, minimum=0):
    reparse_flag = stat.FILE_ATTRIBUTE_REPARSE_POINT
    if any(getattr(p.lstat(), 'st_file_attributes', 0) & reparse_flag
           for p in (path, path.parent)):
        raise RuntimeError('Fixture links are not allowed')
    path = path.resolve()
    if path.parent != ROOT / 'data' or path.is_symlink():
        raise RuntimeError('Use only the fixture in c4/data')
    cert = json.loads(path.with_suffix('.json').read_text())
    size = path.stat().st_size
    if cert['status'] != 'complete' or cert['size_bytes'] != size or size <= minimum:
        raise RuntimeError('Incomplete fixture or not larger than physical RAM')
    if size % (64 * MIB):
        raise RuntimeError('Fixture must be a multiple of 64 MiB')
    if path.stat().st_mtime_ns != cert['mtime_ns']:
        raise RuntimeError('Fixture changed after preparation')
    return cert


def prepare(job, smoke):
    size = 64 * MIB if smoke else 32 * GIB
    if not smoke and size <= psutil.virtual_memory().total:
        raise RuntimeError('32 GiB fixture must exceed installed physical RAM')
    if shutil.disk_usage(ROOT).free < size + 40 * GIB:
        raise RuntimeError('Need fixture space plus 40 GiB free reserve')
    directory = ROOT / 'data'
    directory.mkdir(exist_ok=True)
    path = directory / ('smoke.bin' if smoke else 'sustained.bin')
    cert = {'status': 'incomplete', 'size_bytes': size,
            'kind': 'smoke' if smoke else 'synthetic random-byte store',
            'physical_ram_bytes': psutil.virtual_memory().total}
    # Exclusive creation ensures reruns never overwrite an existing fixture.
    with path.open('xb') as out, (job / 'temperature.jsonl').open('w') as log:
        write_json(path.with_suffix('.json'), cert)
        digest = hashlib.sha256()
        with ThermalGuard(log) as guard:
            last_progress = time.monotonic()
            for offset in range(0, size, 4 * MIB):
                guard.check()
                check_power()
                block = os.urandom(4 * MIB)
                out.write(block)
                digest.update(block)
                if time.monotonic() - last_progress >= 10:
                    print(f'Prepared {(offset + len(block)) / GIB:.2f}/{size / GIB:.2f} GiB',
                          flush=True)
                    last_progress = time.monotonic()
            out.flush()
            os.fsync(out.fileno())
            guard.check()
    cert.update(status='complete', sha256=digest.hexdigest(), mtime_ns=path.stat().st_mtime_ns)
    write_json(path.with_suffix('.json'), cert)
    return {'status': 'prepared', 'fixture': str(path), 'certificate': cert}


def verify_protocol(args):
    if not args.commit or not args.repo:
        raise RuntimeError('Main measurements require --repo and --commit')
    if len(args.commit) != 40 or any(c not in '0123456789abcdef' for c in args.commit):
        raise RuntimeError('Provide the full protocol commit SHA')
    path = 'benchmarks/results/c4-local/protocol.json'
    p = subprocess.run(['git', '-C', str(args.repo), 'show', args.commit + ':' + path],
                       capture_output=True, timeout=15, check=False)
    if p.returncode:
        raise RuntimeError('Cannot read committed protocol: ' + p.stderr.decode(errors='replace'))
    protocol = json.loads(p.stdout)
    if protocol.get('status') != 'frozen' or protocol['sources'] != sources():
        raise RuntimeError('Protocol is not frozen or runner sources differ')
    if args.pattern not in protocol['patterns'] or protocol['duration_s'] != 3600:
        raise RuntimeError('Pattern/duration not declared')
    return protocol


def run_arm(job, args):
    smoke = args.mode == 'smoke'
    protocol = None if smoke else verify_protocol(args)
    fixture = ROOT / 'data' / ('smoke.bin' if smoke else 'sustained.bin')
    cert = fixture_check(fixture, 0 if smoke else psutil.virtual_memory().total)
    if protocol and cert['sha256'] != protocol['fixture_sha256']:
        raise RuntimeError('Fixture differs from committed protocol')
    duration = 15 if smoke else 3600
    chunk = (4 if args.pattern == 'seq4m' else 64) * MIB
    record = {'kind': 'SMOKE, excluded' if smoke else 'sustained arm',
              'status': 'incomplete', 'fixture': cert, 'pattern': args.pattern,
              'duration_target_s': duration, 'protocol': protocol,
              'protocol_commit': args.commit, 'sources': sources(),
              'python': sys.version, 'psutil': psutil.__version__}
    watch = ArmWatch(arm='c4-' + args.pattern, round=0, run=0,
                     gpu_clock=lambda: None, gpu_memory_used=lambda: None,
                     gpu_processes=lambda: None)
    try:
        with (job / 'temperature.jsonl').open('w') as thermal_log:  # noqa: SIM117 -- explicit sensor log lifetime
            with ThermalGuard(thermal_log) as guard, watch:
                with mmap.mmap(-1, chunk) as buffer, open_direct(str(fixture)) as handle:
                    if ctypes.addressof(ctypes.c_char.from_buffer(buffer)) % 4096:
                        raise RuntimeError('Unaligned direct-I/O buffer')
                    with (job / 'samples.jsonl').open('w') as log:
                        start = previous = time.monotonic()
                        previous_total = total = requests = previous_requests = 0
                        before = disk_counter()
                        record['disk_before'] = before
                        while time.monotonic() - start < duration:
                            guard.check()
                            check_power()
                            if handle.tell() == cert['size_bytes']:
                                handle.seek(0)
                            got = handle.readinto(buffer)
                            if got != chunk:
                                raise RuntimeError(f'Short read: {got}/{chunk}')
                            total += got
                            requests += 1
                            now = time.monotonic()
                            if now - previous >= 1 or now - start >= duration:
                                counters = disk_counter()
                                row = {'elapsed_s': now - start, 'interval_s': now - previous,
                                       'time_unix': time.time(), 'total_bytes': total,
                                       'read_bytes': total - previous_total,
                                       'requests': requests - previous_requests,
                                       'GB_s': (total - previous_total) / (now - previous) / 1e9,
                                       'disk': counters,
                                       'ram_available_bytes': psutil.virtual_memory().available}
                                log.write(json.dumps(row) + '\n')
                                log.flush()
                                previous, previous_total, previous_requests = now, total, requests
                        guard.check()
                        record.update(elapsed_s=time.monotonic() - start, total_bytes=total,
                                      disk_after=disk_counter())
                        check_power()
                        if sources() != record['sources']:
                            raise RuntimeError('Runner sources changed during measurement')
        record['F1'] = watch.record
        record['status'] = 'smoke_passed' if smoke else 'candidate'
        if not watch.record or watch.record['outcome'] != 'ok':
            record['status'] = 'invalid'
    except (Exception, KeyboardInterrupt) as exc:  # noqa: BLE001 -- retain failed and interrupted arms
        record.update(status='invalid', error=repr(exc), F1=watch.record)
    finally:
        write_json(job / 'arm.json', record)
    return record


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=['prepare-smoke', 'prepare', 'smoke', 'run'])
    parser.add_argument('--pattern', choices=['seq4m', 'seq64m'], default='seq4m')
    parser.add_argument('--repo', type=Path)
    parser.add_argument('--commit')
    args = parser.parse_args()
    job = ROOT / ('run-' + args.mode + '-' + uuid.uuid4().hex[:10])
    job.mkdir()
    try:
        check_mapping()
        check_power()
        if args.mode.startswith('prepare'):
            result = prepare(job, args.mode == 'prepare-smoke')
        else:
            result = run_arm(job, args)
    except Exception as exc:  # noqa: BLE001 -- preserve setup errors as evidence
        result = {'status': 'failed', 'error': repr(exc)}
    write_json(job / 'summary.json', result)
    print('Status:', result['status'])
    print('Saved:', job)
    return 0 if result['status'] in ('prepared', 'smoke_passed', 'candidate') else 1


if __name__ == '__main__':
    raise SystemExit(main())
