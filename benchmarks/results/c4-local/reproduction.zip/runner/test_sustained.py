import io
from types import SimpleNamespace

import pytest
import sustained as s


@pytest.mark.parametrize('value', [None, float('nan'), 0, 75, 87])
def test_watchdog_rejects_missing_or_hot_sensor(value):
    guard = s.ThermalGuard(io.StringIO(), sensor=lambda: value)
    guard.sample()
    with pytest.raises(RuntimeError, match='Temperature guard'):
        guard.check()


def test_watchdog_stale_sensor():
    now = [0.0]
    guard = s.ThermalGuard(io.StringIO(), sensor=lambda: 38, clock=lambda: now[0])
    guard.sample()
    guard.check()
    now[0] = 16
    with pytest.raises(RuntimeError, match='stale'):
        guard.check()


@pytest.mark.parametrize('value', [65, 74])
def test_revised_limit_allows_below_stop(value):
    guard = s.ThermalGuard(io.StringIO(), sensor=lambda: value)
    guard.sample()
    guard.check()


def test_watchdog_sensor_failure_retained():
    def broken():
        raise OSError('sensor unavailable')
    log = io.StringIO()
    guard = s.ThermalGuard(log, sensor=broken)
    guard.sample()
    with pytest.raises(RuntimeError, match='sensor unavailable'):
        guard.check()
    assert 'sensor unavailable' in log.getvalue()


@pytest.mark.parametrize('online', [False, None])
def test_ac_loss_or_unknown_refuses(monkeypatch, online):
    monkeypatch.setattr(s, 'windows_power_supplies', lambda: {'online': {'ac_line': online}})
    with pytest.raises(RuntimeError, match='AC power'):
        s.check_power()


def test_measurement_without_protocol_refuses():
    with pytest.raises(RuntimeError, match='require'):
        s.verify_protocol(SimpleNamespace(repo=None, commit=None))


def test_existing_fixture_never_overwritten(tmp_path, monkeypatch):
    monkeypatch.setattr(s, 'ROOT', tmp_path)
    monkeypatch.setattr(s.shutil, 'disk_usage', lambda _: SimpleNamespace(free=100*s.GIB))
    (tmp_path / 'data').mkdir()
    fixture = tmp_path / 'data' / 'smoke.bin'
    fixture.write_bytes(b'keep')
    with pytest.raises(FileExistsError):
        s.prepare(tmp_path, True)
    assert fixture.read_bytes() == b'keep'


def test_fixture_validation_on_installed_python(tmp_path, monkeypatch):
    monkeypatch.setattr(s, 'ROOT', tmp_path)
    directory = tmp_path / 'data'
    directory.mkdir()
    fixture = directory / 'smoke.bin'
    with fixture.open('wb') as handle:
        handle.truncate(64 * s.MIB)
    cert = {'status': 'complete', 'size_bytes': fixture.stat().st_size,
            'mtime_ns': fixture.stat().st_mtime_ns}
    s.write_json(fixture.with_suffix('.json'), cert)
    assert s.fixture_check(fixture) == cert
    with pytest.raises(RuntimeError, match='larger than physical RAM'):
        s.fixture_check(fixture, minimum=64 * s.MIB)
