"""Windows C4 instrument controls, not a sustained performance experiment.

Run elevated. Uses a new 16 MiB fixture per invocation; never overwrites data.
The foreign reader is the parent of the watched process, not its child.
"""
import argparse
import ctypes
import hashlib
import json
import mmap
import os
import subprocess
import sys
import time
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'source'))
from arm_validity import ArmWatch, windows_power_supplies
from safetensors_reader import open_direct

MIB = 1024 * 1024
FIXTURE_BYTES = 16 * MIB
CONTROL_BYTES = 1280 * MIB
STOP_C = 75  # Experimental stop below observed NVMe warning 87 C; not a rated limit.


def save(path, obj):
    path.write_text(json.dumps(obj, indent=2), encoding='utf-8')


def temperature():
    p = subprocess.run([
        r'C:\Program Files\smartmontools\bin\smartctl.exe',
        '-a', '-j', '-d', 'nvme', '/dev/sda'],
        capture_output=True, text=True, timeout=5, check=False)
    if p.returncode:
        raise RuntimeError('Temperature query failed: ' + p.stderr.strip())
    data = json.loads(p.stdout)
    if (data.get('model_name') != 'Micron MTFDKCD512QFM-1BD1AABLA'
            or data.get('serial_number') != '23364304A033'):
        raise RuntimeError('SMART device identity differs from the C4 SSD')
    health = data['nvme_smart_health_information_log']
    if health.get('critical_warning') != 0:
        raise RuntimeError('SMART critical warning is nonzero or unavailable')
    value = health.get('temperature')
    if not isinstance(value, (int, float)) or not 0 < value < STOP_C:
        raise RuntimeError(f'Temperature missing, invalid or at operational stop: {value}')
    return value


def read_direct(path, total_bytes):
    with mmap.mmap(-1, MIB) as buffer:
        address = ctypes.addressof(ctypes.c_char.from_buffer(buffer))
        if address % 4096:
            raise RuntimeError('Buffer is not sector aligned')
        with open_direct(str(path)) as handle:
            size = path.stat().st_size
            done = 0
            while done < total_bytes:
                if handle.tell() == size:
                    handle.seek(0)
                got = handle.readinto(buffer)
                if got != MIB:
                    raise RuntimeError(f'Short read: {got}')
                done += got
    return done


def child(case, job):
    fixture = job.parent / 'fixture.bin'
    with ArmWatch(arm='c4-control-' + case, round=0, run=0,
                  gpu_clock=lambda: None, gpu_memory_used=lambda: None,
                  gpu_processes=lambda: None) as watch:
        save(job / 'ready.json', {'time': time.time()})
        started = time.monotonic()
        own = read_direct(fixture, CONTROL_BYTES) if case == 'own' else 0
        while not (job / 'finish.json').exists():
            if time.monotonic() - started > 45:
                raise TimeoutError('Control coordinator did not finish')
            time.sleep(0.05)
        time.sleep(2.1)
    save(job / 'result.json', {'own_requested_bytes': own, 'F1': watch.record})


def main():
    if sys.platform != 'win32':
        raise RuntimeError('This preflight is for the local Windows NVMe only')
    run = ROOT / ('preflight-' + uuid.uuid4().hex[:10])
    run.mkdir()
    result = {'kind': 'instrument controls, not C4 sustained results',
              'status': 'in_progress', 'controls': [],
              'temperature_stop_c': STOP_C,
              'sources': {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                          for p in [Path(__file__), *sorted((ROOT / 'source').glob('*.py'))]}}
    try:
        result['temperature_before_c'] = temperature()
        power = windows_power_supplies()
        if not power['online'].get('ac_line'):
            raise RuntimeError('Connect AC power before controls')
        # Confirm C: maps to physical disk 0 before associating its temperature.
        p = subprocess.run(['powershell.exe', '-NoProfile', '-Command',
                            "(Get-Partition -DriveLetter C -ErrorAction Stop).DiskNumber"],
                           capture_output=True, text=True, timeout=15, check=False)
        if p.returncode or p.stdout.strip() != '0' or run.drive.upper() != 'C:':
            raise RuntimeError('Fixture/temperature disk mapping not established')
        fixture = run / 'fixture.bin'
        digest = hashlib.sha256()
        with fixture.open('xb') as out:
            for _ in range(FIXTURE_BYTES // MIB):
                block = os.urandom(MIB)
                out.write(block)
                digest.update(block)
            out.flush()
            os.fsync(out.fileno())
        # Verify the bytes delivered by Soup's unbuffered reader.
        with mmap.mmap(-1, MIB) as buffer, open_direct(str(fixture)) as handle:
            if ctypes.addressof(ctypes.c_char.from_buffer(buffer)) % 4096:
                raise RuntimeError('Unaligned verification buffer')
            actual = hashlib.sha256()
            for _ in range(FIXTURE_BYTES // MIB):
                if handle.readinto(buffer) != MIB:
                    raise RuntimeError('Short verification read')
                actual.update(buffer)
        if actual.hexdigest() != digest.hexdigest():
            raise RuntimeError('Direct read differs from written bytes')
        result['direct_read_sha256'] = actual.hexdigest()
        result['fixture_bytes'] = FIXTURE_BYTES
        for case in ('baseline', 'own', 'foreign'):
            result.setdefault('temperatures', []).append(temperature())
            job = run / case
            job.mkdir()
            print('Control:', case, flush=True)
            with (job / 'process.log').open('w') as log:
                process = subprocess.Popen([sys.executable, __file__, '--child', case,
                                            '--job', str(job)], stdout=log, stderr=log)
                try:
                    deadline = time.monotonic() + 20
                    while not (job / 'ready.json').exists():
                        if process.poll() is not None or time.monotonic() > deadline:
                            raise RuntimeError('Control did not start; inspect process.log')
                        time.sleep(0.05)
                    foreign = read_direct(fixture, CONTROL_BYTES) if case == 'foreign' else 0
                    time.sleep(3)
                    save(job / 'finish.json', {'foreign_requested_bytes': foreign})
                    process.wait(timeout=45)
                finally:
                    if process.poll() is None:
                        process.kill()
                        process.wait()
            if process.returncode:
                raise RuntimeError('Control failed; inspect ' + str(job / 'process.log'))
            record = json.loads((job / 'result.json').read_text())
            expected = 'void' if case == 'foreign' else 'ok'
            observed = record['F1']['checks']['foreign_reads']['outcome']
            result['controls'].append({'case': case, 'expected': expected,
                                       'observed': observed})
            if observed != expected:
                raise RuntimeError('Unexpected foreign-read control outcome')
            for check in ('power', 'suspend'):
                if record['F1']['checks'][check]['outcome'] != 'ok':
                    raise RuntimeError(check + ' is not ok')
        result['temperature_after_c'] = temperature()
        result['status'] = 'controls_passed'
        result['limitations'] = [
            '16 MiB fixture only: not a dataset larger than RAM.',
            'Windows F1 process reads cover all devices and do not prove physical reads.',
            'Power/suspend failure controls not yet exercised.',
            'No sustained performance claim; long-run thermal watchdog not yet validated.',
        ]
    except Exception as error:  # noqa: BLE001 -- preserve failures as diagnostic evidence
        result['status'] = 'failed'
        result['error'] = repr(error)
    finally:
        save(run / 'summary.json', result)
        print(json.dumps(result, indent=2))
        print('Saved:', run)
    return 0 if result['status'] == 'controls_passed' else 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--child', choices=['baseline', 'own', 'foreign'])
    parser.add_argument('--job', type=Path)
    args = parser.parse_args()
    if args.child:
        child(args.child, args.job)
    else:
        raise SystemExit(main())
