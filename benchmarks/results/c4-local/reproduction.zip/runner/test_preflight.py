import ctypes
import hashlib
import json
import mmap
import os
from types import SimpleNamespace

import preflight as p
import pytest


def smart_reply(value):
    return {'model_name': 'Micron MTFDKCD512QFM-1BD1AABLA',
            'serial_number': '23364304A033',
            'nvme_smart_health_information_log': {'critical_warning': 0, 'temperature': value}}


@pytest.mark.parametrize('value', [None, 0, 75, 87])
def test_temperature_missing_or_hot_refuses(monkeypatch, value):
    monkeypatch.setattr(p.subprocess, 'run', lambda *a, **kw: SimpleNamespace(
        returncode=0, stdout=json.dumps(smart_reply(value))))
    with pytest.raises(RuntimeError):
        p.temperature()


def test_temperature_reads_expected_disk(monkeypatch):
    monkeypatch.setattr(p.subprocess, 'run', lambda *a, **kw: SimpleNamespace(
        returncode=0, stdout=json.dumps(smart_reply(38))))
    assert p.temperature() == 38


@pytest.mark.parametrize('case', ['identity', 'warning', 'malformed', 'exit'])
def test_smart_invalid_response_refuses(monkeypatch, case):
    data = smart_reply(38)
    if case == 'identity':
        data['serial_number'] = 'different'
    if case == 'warning':
        data['nvme_smart_health_information_log']['critical_warning'] = 2
    monkeypatch.setattr(p.subprocess, 'run', lambda *a, **kw: SimpleNamespace(
        returncode=1 if case == 'exit' else 0, stderr='failed',
        stdout='bad json' if case == 'malformed' else json.dumps(data)))
    with pytest.raises((RuntimeError, ValueError)):
        p.temperature()


def test_smart_query_timeout_refuses(monkeypatch):
    def timeout(*args, **kwargs):
        assert kwargs['timeout'] == 5
        raise p.subprocess.TimeoutExpired('smartctl', 5)
    monkeypatch.setattr(p.subprocess, 'run', timeout)
    with pytest.raises(p.subprocess.TimeoutExpired):
        p.temperature()


def test_real_direct_read_roundtrip(tmp_path):
    data = os.urandom(p.MIB)
    fixture = tmp_path / 'read-control.bin'
    with fixture.open('xb') as out:
        out.write(data)
        out.flush()
        os.fsync(out.fileno())
    with mmap.mmap(-1, p.MIB) as buffer, p.open_direct(str(fixture)) as handle:
        assert ctypes.addressof(ctypes.c_char.from_buffer(buffer)) % 4096 == 0
        assert handle.readinto(buffer) == p.MIB
        assert hashlib.sha256(buffer).digest() == hashlib.sha256(data).digest()
    assert p.read_direct(fixture, 2 * p.MIB) == 2 * p.MIB


def test_short_read_is_rejected(tmp_path):
    fixture = tmp_path / 'short.bin'
    fixture.write_bytes(b'x' * 4096)
    with pytest.raises(RuntimeError, match='Short read'):
        p.read_direct(fixture, p.MIB)
