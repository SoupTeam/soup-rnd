Analyze: python analyze_c4.py PATH_TO_EXTRACTED_RAW OUTPUT
Plot: python plot_c4.py PATH_TO_EXTRACTED_RAW OUTPUT (matplotlib 3.11.2)
Tests: python -m pytest test_analysis.py runner/test_preflight.py runner/test_sustained.py
Live reproduction is Windows-only: install Python 3.11, psutil 7.2.2, smartctl 7.5.
Inspect runner/preflight.py device identity first; do not run against a different disk.
Prepare: python runner/sustained.py prepare (32 GiB writes; not needed for analysis).
Declare and commit a new protocol with regenerated fixture and runner hashes.
Run: python runner/sustained.py run --pattern seq4m --repo REPO --commit FULL_SHA
Historical absolute C: paths and drive-0 assumptions must be reviewed before use.
