import pytest

from analyze_c4 import percentile, rate


def test_weighted_window_crosses_sample_boundaries():
    samples = [{'elapsed_s': 2, 'interval_s': 2, 'read_bytes': 2e9},
               {'elapsed_s': 4, 'interval_s': 2, 'read_bytes': 6e9}]
    assert rate(samples, 1, 3) == 2
    assert rate(samples, 0, 4) == 2


def test_missing_coverage_rejected():
    with pytest.raises(AssertionError):
        rate([{'elapsed_s': 2, 'interval_s': 1, 'read_bytes': 1e9}], 0, 2)


def test_percentile_linear_interpolation():
    assert percentile([4, 1, 3, 2], 0.1) == pytest.approx(1.3)
