"""Plot archived C4 records. Requires matplotlib; no disk benchmark is run."""
import sys
from pathlib import Path

import matplotlib

from analyze_c4 import read, rows

matplotlib.use('Agg')
import matplotlib.pyplot as plt

root, output = map(Path, sys.argv[1:3])
arm = read(root / 'run-run-7eab09a633/arm.json')
data = rows(root / 'run-run-7eab09a633/samples.jsonl')
thermal = rows(root / 'run-run-7eab09a633/temperature.jsonl')
analysis = read(output / 'analysis.json')
fig, axes = plt.subplots(3, 1, figsize=(11, 10), sharex=True, layout='constrained')
minutes = [row['elapsed_s'] / 60 for row in data]
axes[0].plot(minutes, [row['GB_s'] for row in data], color='#9db9ce', lw=0.6,
             label='~1-second samples')
windows = analysis['postwarmup_windows']
axes[0].plot([(r['start_s'] + 30) / 60 for r in windows],
             [r['GB_s'] for r in windows], color='#164b75', lw=2, label='60-second means')
axes[0].axhline(analysis['planner_heuristic_GB_s'], color='#bd6325', ls='--',
                label='Provisional planner heuristic')
axes[0].set_ylabel('Reader throughput (GB/s)')
axes[0].legend(loc='lower right', fontsize=8)
axes[1].plot([(r['time_unix'] - thermal[0]['time_unix']) / 60 for r in thermal],
             [r['temperature_c'] for r in thermal], color='#bd6325')
axes[1].axhline(75, color='#9e3333', ls='--', label='Experimental stop: 75 C')
axes[1].set_ylabel('NVMe temperature (C)')
axes[1].legend(fontsize=8)
previous = arm['disk_before']
excess, writes = [], []
for row in data:
    excess.append((row['disk']['read_bytes'] - previous['read_bytes'] - row['read_bytes'])
                  / row['interval_s'] / 1e6)
    writes.append((row['disk']['write_bytes'] - previous['write_bytes'])
                  / row['interval_s'] / 1e6)
    previous = row['disk']
axes[2].plot(minutes, excess, label='Physical read minus reader (timing residual)', lw=0.7)
axes[2].plot(minutes, writes, label='Physical writes', lw=0.7)
axes[2].set_ylabel('Aggregate disk I/O (MB/s)')
axes[2].legend(fontsize=8)
axes[2].set_xlabel('Elapsed minutes')
for axis in axes:
    axis.axvspan(0, 10, color='#dddddd', alpha=0.35)
    axis.grid(alpha=0.2)
    axis.set_xlim(0, 60)
fig.suptitle('C4 | Micron 512 GB laptop NVMe | one exploratory run\n'
             '32 GiB synthetic store, 4 MiB direct reads; shaded area: declared warmup', fontsize=12)
fig.savefig(output / 'sustained.png', dpi=150)
plt.close(fig)
