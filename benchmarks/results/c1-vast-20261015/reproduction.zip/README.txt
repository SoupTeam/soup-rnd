Extract vast_runner.zip first to obtain vast_runner/. Extract c1_measurement_patch.zip inside that folder.
Use the commands and limitations in probe-c1-batch-vast.md. Base README.txt is historical staging guidance.
Analyze retained results with: python analyze_vast_c1.py raw-results.zip --output analysis.json
This package contains historical Soup sources, not the current main checkout.
The old protocol's fixture certificate is specific to the measured instance. A freshly generated fixture
can have different metadata hashes. Do not bypass the check or reuse this commit SHA for changed files:
declare the new certificate and source identities prospectively before a new measurement series.
