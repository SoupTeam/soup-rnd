"""Audit the retained C1 archive; use only the Python standard library."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import statistics
import zipfile


def digest(data):
    return hashlib.sha256(data).hexdigest()


def analyze(path):
    rows, blocks, excluded = [], [], []
    protocols, identities, certificates = set(), set(), set()
    inputs = {1: set(), 2: set(), 3: set()}
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None, 'ZIP CRC failure'
        def read(name):
            return json.loads(z.read(name))
        names = set(z.namelist())
        specs = sorted(n for n in names if n.startswith('work/c1_c1-') and n.endswith('/spec.json'))
        for sn in specs:
            base = sn[:-9]
            spec, plan = read(sn), read(base+'plan.json')
            protocol = read(base+'protocol.json')
            protocols.add(json.dumps(protocol, sort_keys=True))
            identities.add(json.dumps(plan['host'], sort_keys=True))
            assert spec['protocol_commit'] == '4c2fcf8f326a764047fe0871a3d1da8a331f1894'
            assert spec['manifest_sha256'] == digest(z.read('manifest.json'))
            assert spec['overlay_evidence_sha256'] == digest(z.read(base+'overlay_evidence.json'))
            for source in ('run_overlay_c1.py', 'c1_overlay_control.py'):
                # Source copies are decoded/re-encoded by the runner, with LF on Linux.
                assert digest(z.read(base+source+'.txt')) == protocol['source_hashes'][source]
            a, b = spec['pair'].split(',')
            assert plan['order'] == [a,b,b,a]
            local = []
            for i, condition in enumerate(plan['order']):
                arm = base+f'arm_{i}_{condition}/'
                if arm+'watch.json' not in names:
                    continue
                w, r, proc = read(arm+'watch.json'), read(arm+'result.json'), read(arm+'process/process.json')
                assert digest(z.read(arm+'result.json')) == w['result_sha256']
                assert proc['exit_code'] == 0 and r['status'] == 'completed_preliminary'
                assert r['batch'] == int(condition) and r['seq'] == 512
                assert r['seed'] == 3 and r['input_seed'] == 17
                assert r['direct_io'] is True and r['source_class'] == 'AsyncDiskSource'
                assert r['optimizer'] == 'PagedAdamW8bit' and r['changed_adapter_tensors'] == 640
                assert r['runtime']['n_layers'] == 80 and r['runtime']['tier'] == 'disk'
                certificates.add(json.dumps(r['source_certificate'], sort_keys=True))
                inputs[r['batch']].add(r['input_sha256'])
                m = r['measurement']
                assert m['steps'] == 3 and m['warmup'] == 1 and len(m['records']) == 3
                assert not m['events_on'] and not m['nocopy'] and not m['nodequant']
                times = [x['step_s'] for x in m['records']]
                assert all(math.isfinite(x['loss']) and x['step_s'] > 0 for x in m['records'])
                assert w['median_step_s'] == statistics.median(times)
                assert math.isclose(w['tokens_per_second'], r['batch']*512/w['median_step_s'])
                f = w['F1']
                assert set(f['required']) == {'power','suspend','foreign_reads'}
                if f['outcome'] == 'ok':
                    assert all(f['checks'][k]['outcome'] == 'ok' for k in f['required'])
                assert not f['box_stamp_before']['gpu_processes']
                assert not f['box_stamp_after']['gpu_processes']
                assert f['gpu_clock']['outcome'] == 'ok'
                assert set(f['gpu_clock']['reasons_seen']) <= {'gpu_idle','sw_power_cap'}
                sampled = [float(x['gpu']['stdout'].split(',')[0]) for x in w['gpu_samples'] if x['gpu'].get('code') == 0]
                local.append(dict(block=spec['id'], pair=spec['pair'], position=i, batch=r['batch'],
                    outcome=f['outcome'], median_step_s=w['median_step_s'], tokens_per_second=w['tokens_per_second'],
                    allocated_gb=m['peak_alloc_gb'], reserved_gb=m['peak_reserved_gb'],
                    sampled_device_peak_mib=max(sampled), sampled_process_rss_gb=r['sampled_peak_process_rss_bytes']/1e9,
                    started=proc['started_unix_s'], finished=proc['finished_unix_s'],
                    foreign_read_check=f['checks']['foreign_reads']))
            if base+'block_complete.json' not in names:
                excluded.append(dict(block=spec['id'], arms=local, reason='Whole incomplete/void block excluded'))
                continue
            assert len(local) == 4 and all(x['outcome'] == 'ok' for x in local)
            assert all(local[i]['finished'] <= local[i+1]['started'] for i in range(3))
            blocks.append(dict(pair=spec['pair'], id=spec['id'], arms=local))
            rows.extend(local)
        assert len(protocols) == len(identities) == len(certificates) == 1
        assert all(len(v) == 1 for v in inputs.values())
        assert len(rows) == 60 and len(blocks) == 15
        assert [x['block'] for x in excluded] == ['c1-13-block05']
        repeats = []
        for pair in ('1,2','1,3','2,3'):
            pb = sorted([x for x in blocks if x['pair'] == pair], key=lambda x:x['arms'][0]['started'])
            assert len(pb) == 5
            av = [b['arms'][i]['median_step_s'] for b in pb for i in (0,3)]
            bv = [b['arms'][i]['median_step_s'] for b in pb for i in (1,2)]
            sigma = math.sqrt((statistics.variance(av)+statistics.variance(bv))/2)
            n = max(2, math.ceil(7.85*(sigma/(.1*statistics.mean(av)))**2))
            # Both pilot and recomputation use these same five blocks when N <= 5.
            assert n <= 5, 'More blocks needed; do not publish completion'
            ratios = [statistics.mean(b['arms'][i]['tokens_per_second'] for i in (1,2)) /
                      statistics.mean(b['arms'][i]['tokens_per_second'] for i in (0,3)) for b in pb]
            repeats.append(dict(pair=pair, accepted_blocks=5, sigma=sigma, formula_N=n, blocks_to_add=0,
                                mean_block_throughput_ratio=statistics.mean(ratios), min_ratio=min(ratios), max_ratio=max(ratios)))
        summary = []
        for batch in (1,2,3):
            rr = [r for r in rows if r['batch'] == batch]
            summary.append(dict(batch=batch, arms=len(rr), mean_median_step_s=statistics.mean(r['median_step_s'] for r in rr),
                mean_tokens_per_second=statistics.mean(r['tokens_per_second'] for r in rr),
                min_tokens_per_second=min(r['tokens_per_second'] for r in rr),max_tokens_per_second=max(r['tokens_per_second'] for r in rr),
                **{k:max(r[k] for r in rr) for k in ('allocated_gb','reserved_gb','sampled_device_peak_mib','sampled_process_rss_gb')}))
        return dict(archive_sha256=digest(Path(path).read_bytes()), accepted_arms=len(rows), summary=summary,
                    repeats=repeats, excluded=excluded, host=json.loads(next(iter(identities))),
                    protocol=json.loads(next(iter(protocols))), first_arm_unix_s=min(r['started'] for r in rows), arms=rows)


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('archive', type=Path)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    result = analyze(args.archive)
    args.output.write_text(json.dumps(result,indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'accepted':result['accepted_arms'],'summary':result['summary'],'repeats':result['repeats']},indent=2))
