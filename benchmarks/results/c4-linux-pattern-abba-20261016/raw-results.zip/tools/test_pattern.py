"""Boundary cases specific to the new request-size comparison."""
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import runner
from test_runner import disk


class FakeDirect:
    def __init__(self, short=False):
        self.offset = 0
        self.sizes = []
        self.rewinds = 0
        self.short = short

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass

    def tell(self):
        return self.offset

    def seek(self, position):
        self.offset = position
        self.rewinds += 1

    def readinto(self, buffer):
        size = len(buffer)
        self.sizes.append(size)
        self.offset += size
        return size - 1 if self.short else size


class PatternTests(unittest.TestCase):
    def test_eof_rewind_and_exact_bytes_both_sizes(self):
        for size in (4 * 1024**2, 64 * 1024**2):
            handle = FakeDirect()
            with self.subTest(size=size), patch.object(Path, 'stat', return_value=SimpleNamespace(st_size=2*size)), \
                    patch.object(runner, 'open_direct', return_value=handle):
                total = runner.read_fixed('synthetic', 5 * size, block_bytes=size)
            self.assertEqual(total, 5 * size)
            self.assertEqual(handle.sizes, [size] * 5)
            self.assertEqual(handle.rewinds, 2)

    def test_small_fixture_and_partial_request_rejected(self):
        for footprint, block in ((16*1024**2, 64*1024**2), (129*1024**2, 64*1024**2),
                                 (128*1024**2, 8*1024**2), (0, 4*1024**2)):
            with self.subTest(footprint=footprint, block=block), self.assertRaises(ValueError):
                runner.validate_read_geometry(footprint, block)

    def test_partial_injection_not_rounded_up(self):
        with patch.object(Path, 'stat', return_value=SimpleNamespace(st_size=128*1024**2)):
            with self.assertRaises(ValueError):
                runner.read_fixed('synthetic', 65*1024**2, block_bytes=64*1024**2)

    def test_short_64_mib_read_is_failure(self):
        with patch.object(Path, 'stat', return_value=SimpleNamespace(st_size=128*1024**2)), \
                patch.object(runner, 'open_direct', return_value=FakeDirect(short=True)):
            with self.assertRaises(RuntimeError):
                runner.read_fixed('synthetic', 64*1024**2, block_bytes=64*1024**2)

    def test_read_stops_on_thermal_failure(self):
        class Guard:
            calls = 0

            def check(self):
                self.calls += 1
                if self.calls == 2:
                    raise RuntimeError('thermal stop')

        handle = FakeDirect()
        with patch.object(Path, 'stat', return_value=SimpleNamespace(st_size=128*1024**2)), \
                patch.object(runner, 'open_direct', return_value=handle):
            with self.assertRaisesRegex(RuntimeError, 'thermal stop'):
                runner.read_fixed('synthetic', 128*1024**2, guard=Guard(), block_bytes=64*1024**2)
        self.assertEqual(handle.sizes, [64*1024**2])

    def test_large_request_does_not_relax_physical_tolerance(self):
        self.assertEqual(runner.RULES['physical_read_deficit_tolerance_bytes'], 8*1024**2)
        result = runner.device_validity({'a': disk()}, {'a': disk(48*1024**2)}, {'a': 64*1024**2})
        self.assertEqual(result['a']['outcome'], 'unknown')


if __name__ == '__main__':
    unittest.main()
