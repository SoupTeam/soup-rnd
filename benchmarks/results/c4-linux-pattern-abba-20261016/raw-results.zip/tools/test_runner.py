import base64
import copy
import hashlib
import json
from pathlib import Path
from subprocess import CompletedProcess
import tempfile
import time
import unittest
from unittest.mock import patch

import analyze
import receipt
import runner


def temporary():
    return tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent)


def disk(read=0, write=0, ios=0):
    return {'read_bytes': read, 'write_bytes': write, 'read_ios': ios,
            'write_ios': 0, 'read_ms': 0, 'write_ms': 0, 'inflight': 0, 'io_ms': 0}


def proof_for(content=b'{"test":true}\n', mode='100644'):
    blob = receipt.oid('blob', content)
    raw_tree = mode.encode() + b' protocol.json\0' + bytes.fromhex(blob)
    tree = receipt.oid('tree', raw_tree)
    raw_commit = (f'tree {tree}\nauthor Test <test@example.com> 1000 +0000\n'
                  'committer Test <test@example.com> 1000 +0000\n\nfreeze\n').encode()
    proof = {'version': 1, 'commit': receipt.oid('commit', raw_commit),
             'commit_base64': base64.b64encode(raw_commit).decode(),
             'path': 'protocol.json', 'trees': [{'oid': tree, 'base64': base64.b64encode(raw_tree).decode()}],
             'blob_oid': blob, 'protocol_sha256': hashlib.sha256(content).hexdigest()}
    return proof, content


class SmartTests(unittest.TestCase):
    def snapshots(self, code=0, passed=True, health=None):
        health = {'critical_warning': 0, 'media_errors': 0} if health is None else health
        data = {'smartctl': {'exit_status': code}, 'smart_status': {'passed': passed},
                'nvme_smart_health_information_log': health}
        extra = dict(health, thm_temp1_trans_count=3, thm_temp1_total_time=10)
        return [CompletedProcess([], code, json.dumps(data), ''),
                CompletedProcess([], 0, json.dumps(extra), '')]

    def test_targeted_health_read_and_thermal_counters_retained(self):
        with patch.object(runner.subprocess, 'run', side_effect=self.snapshots()) as call:
            data = runner.smart('nvme0n1')
        self.assertEqual(call.call_args_list[0].args[0],
                         ['smartctl', '-i', '-H', '-A', '-j', '/dev/nvme0n1'])
        self.assertEqual(data['nvme_cli_health']['data']['thm_temp1_trans_count'], 3)

    def test_command_failures_are_not_ignored(self):
        for code in (1, 2, 4, 8, 64, 128, -1):
            with self.subTest(code=code), patch.object(runner.subprocess, 'run',
                                                      side_effect=self.snapshots(code=code)):
                with self.assertRaises(RuntimeError):
                    runner.smart('nvme0n1')

    def test_missing_negative_or_warning_health_rejected(self):
        for health in ({}, {'critical_warning': 0, 'media_errors': -1},
                       {'critical_warning': 1, 'media_errors': 0},
                       {'critical_warning': 0, 'media_errors': None}):
            with self.subTest(health=health), patch.object(runner.subprocess, 'run',
                                                          side_effect=self.snapshots(health=health)):
                with self.assertRaises(RuntimeError):
                    runner.smart('nvme0n1')

    def test_health_must_explicitly_pass(self):
        for passed in (False, None):
            with patch.object(runner.subprocess, 'run', side_effect=self.snapshots(passed=passed)):
                with self.assertRaises(RuntimeError):
                    runner.smart('nvme0n1')

    def test_supplementary_failure_or_disagreement_rejected(self):
        for extra in (CompletedProcess([], 1, '', 'failed'),
                      CompletedProcess([], 0, '{}', ''),
                      CompletedProcess([], 0, '{"critical_warning":0,"media_errors":1}', '')):
            records = self.snapshots()
            records[1] = extra
            with patch.object(runner.subprocess, 'run', side_effect=records):
                with self.assertRaises(RuntimeError):
                    runner.smart('nvme0n1')


class InstrumentTests(unittest.TestCase):
    def test_known_own_reads_ok(self):
        out = runner.device_validity({'a': disk()}, {'a': disk(2_000_000_000)}, {'a': 2_000_000_000})
        self.assertEqual(out['a']['outcome'], 'ok')

    def test_foreign_read_threshold_is_inclusive(self):
        out = runner.device_validity({'a': disk()}, {'a': disk(3_000_000_000)}, {'a': 2_000_000_000})
        self.assertEqual(out['a']['outcome'], 'void')

    def test_foreign_write_void(self):
        self.assertEqual(runner.device_validity({'a': disk()}, {'a': disk(write=runner.LIMIT)}, {})['a']['outcome'], 'void')

    def test_cross_device_cancellation_does_not_pass(self):
        out = runner.device_validity({'a': disk(), 'b': disk()},
                                     {'a': disk(1_000_000_000), 'b': disk(3_000_000_000)},
                                     {'a': 2_000_000_000, 'b': 2_000_000_000})
        self.assertEqual(out['a']['outcome'], 'unknown')
        self.assertEqual(out['b']['outcome'], 'void')

    def test_counter_reset_unknown(self):
        self.assertEqual(runner.device_validity({'a': disk(100)}, {'a': disk(1)}, {})['a']['outcome'], 'unknown')

    def test_missing_device_raises(self):
        with self.assertRaises(KeyError):
            runner.device_validity({'a': disk()}, {}, {})

    def test_short_direct_read_rejected(self):
        class Short:
            def readinto(self, buf):
                return len(buf) - 1
        with self.assertRaises(RuntimeError):
            runner.read_exact(Short(), bytearray(32))

    def test_temperature_stop_and_missing_sensor_fail_closed(self):
        for result in ({'a': {'max_c': 70}}, OSError('missing')):
            guard = runner.ThermalGuard({})
            with patch.object(runner, 'temperatures', side_effect=result if isinstance(result, Exception) else None,
                              return_value=result):
                guard.sample()
                with self.assertRaises(RuntimeError):
                    guard.check()

    def test_stale_sensor_fails(self):
        guard = runner.ThermalGuard({})
        guard.last = time.monotonic() - 20
        guard.reading = {'a': {'max_c': 30}}
        with self.assertRaises(RuntimeError):
            guard.check()

    def test_guard_good_reading(self):
        guard = runner.ThermalGuard({})
        with patch.object(runner, 'temperatures', return_value={'a': {'max_c': 35}}):
            guard.sample()
            self.assertEqual(guard.check()['a']['max_c'], 35)


class BudgetTests(unittest.TestCase):
    def test_incomplete_attempt_is_preserved_and_blocks_next(self):
        with temporary() as td:
            root = Path(td)
            first = runner.claim_attempt(root, 1, 'drive1')
            with self.assertRaises(RuntimeError):
                runner.claim_attempt(root, 2, 'drive2')
            self.assertEqual(runner.load(first / 'arm.json')['status'], 'incomplete')

    def test_four_attempts_no_fifth(self):
        with temporary() as td:
            root = Path(td)
            for index, name in enumerate(runner.RULES['order'], 1):
                folder = runner.claim_attempt(root, index, name)
                runner.save(folder / 'arm.json', {'status': 'candidate'})
            with self.assertRaises(RuntimeError):
                runner.claim_attempt(root, 5, 'replacement')

    def test_same_attempt_cannot_be_overwritten(self):
        with temporary() as td:
            root = Path(td)
            runner.claim_attempt(root, 1, 'drive1')
            with self.assertRaises(RuntimeError):
                runner.claim_attempt(root, 1, 'drive1')

    def test_exclusive_evidence_write(self):
        with temporary() as td:
            path = Path(td) / 'data.json'
            runner.save(path, {'a': 1}, exclusive=True)
            with self.assertRaises(FileExistsError):
                runner.save(path, {'a': 2}, exclusive=True)
            self.assertEqual(runner.load(path), {'a': 1})


class ReceiptTests(unittest.TestCase):
    def test_exact_commit_blob_accepted(self):
        proof, content = proof_for()
        self.assertEqual(receipt.verify_receipt(proof, content)['committed_unix_s'], 1000)

    def test_crlf_blob_is_not_lf_blob(self):
        proof, content = proof_for()
        with self.assertRaises(ValueError):
            receipt.verify_receipt(proof, content.replace(b'\n', b'\r\n'))

    def test_changed_commit_rejected(self):
        proof, content = proof_for()
        proof['commit'] = '0' * 40
        with self.assertRaises(ValueError):
            receipt.verify_receipt(proof, content)

    def test_changed_tree_rejected(self):
        proof, content = proof_for()
        proof['trees'][0]['oid'] = '1' * 40
        with self.assertRaises(ValueError):
            receipt.verify_receipt(proof, content)

    def test_symlink_protocol_rejected(self):
        proof, content = proof_for(mode='120000')
        with self.assertRaises(ValueError):
            receipt.verify_receipt(proof, content)

    def test_path_traversal_rejected(self):
        for path in ('/a', '../a', 'a//b', 'a\\b'):
            with self.assertRaises(ValueError):
                receipt.components(path)


class AnalysisTests(unittest.TestCase):
    def data(self):
        rows = []
        for t in range(1, 181):
            rows.append({'elapsed_s': float(t), 'interval_s': 1.0,
                         'bytes': {'a': 1_000_000_000 * t, 'b': 2_000_000_000 * t},
                         'disk': {'a': disk(1_000_000_000 * t, ios=250*t),
                                  'b': disk(2_000_000_000 * t, ios=500*t)},
                         'temperature': {'a': {'max_c': 40, 'sensors_c': [40]},
                                         'b': {'max_c': 42, 'sensors_c': [42]}}})
        arm = {'nodes': ['a', 'b'], 'disk_before': {'a': disk(), 'b': disk()},
               'disk_after': rows[-1]['disk'], 'bytes': rows[-1]['bytes'],
               'target_seconds': 180, 'elapsed_s': 180.0}
        return rows, arm

    def test_known_constant_rates_and_planner(self):
        rows, arm = self.data()
        result = analyze.summarize(rows, arm, warmup=60)
        self.assertEqual(result['metrics']['total']['post_warmup_mean_GB_s'], 3)
        self.assertAlmostEqual(result['metrics']['total']['provisional_planner_GB_s'], 2.7)
        self.assertEqual(len(result['metrics']['a']['windows']), 2)

    def test_missing_samples_rejected(self):
        rows, arm = self.data()
        del rows[20:30]
        with self.assertRaises(ValueError):
            analyze.validate_samples(rows, arm)

    def test_decreasing_counter_rejected(self):
        rows, arm = self.data()
        rows[30]['bytes']['a'] = 0
        with self.assertRaises(ValueError):
            analyze.validate_samples(rows, arm)

    def test_temperature_stop_rejected(self):
        rows, arm = self.data()
        rows[30]['temperature']['a'] = {'sensors_c': [70], 'max_c': 70}
        with self.assertRaises(ValueError):
            analyze.validate_samples(rows, arm)

    def test_final_record_mismatch_rejected(self):
        rows, arm = self.data()
        arm = copy.deepcopy(arm)
        arm['bytes']['a'] += 1
        with self.assertRaises(ValueError):
            analyze.validate_samples(rows, arm)

    def test_interpolated_window_boundaries(self):
        rows = [{'elapsed_s': t + 0.2, 'bytes': {'a': int((t + .2) * 100)}} for t in range(1, 200)]
        windows = analyze.window_rates(rows, ['a'], 60, 60)
        self.assertAlmostEqual(windows[0]['GB_s'], 100 / 1e9)


class WorkflowTests(unittest.TestCase):
    def test_fixture_error_saved_not_lost(self):
        with temporary() as td, patch.object(runner, 'sources', return_value={}), \
                patch.object(runner, 'verify_host', side_effect=RuntimeError('device changed')):
            config = {'drives': [{'node': 'a'}]}
            result = runner.interval(config, [], [0], 1, Path(td))
            self.assertEqual(result['status'], 'invalid')
            self.assertIn('device changed', result['errors'][0])
            self.assertEqual(runner.load(Path(td) / 'arm.json'), result)

    def test_complete_analysis_and_tamper_rejection(self):
        with temporary() as td, patch.dict(runner.RULES, {'durations_s': [180] * 4, 'warmup_s': 60}):
            session = Path(td)
            control_folder = session / 'controls-01'
            control_folder.mkdir()
            cases = []
            for mode in ('A', 'B'):
                for kind in ('baseline', 'own', 'foreign'):
                    job = control_folder / (mode + '-' + kind)
                    job.mkdir()
                    runner.save(job / 'arm.json', {'fixture': 'test only'})
                    cases.append({'case': job.name, 'passed': True,
                                  'arm_sha256': runner.digest(job / 'arm.json')})
            runner.save(control_folder / 'controls.json', {'status': 'controls_passed', 'cases': cases})
            protocol = {'status': 'frozen', 'frozen_unix_s': 999.0, 'limitations': ['Synthetic test fixture'],
                        'config': {'rules': copy.deepcopy(runner.RULES), 'sources': {'test': 'test'},
                                   'drives': [{'node': 'a'}, {'node': 'b'}]},
                        'controls_path': 'controls-01/controls.json',
                        'controls_sha256': runner.digest(control_folder / 'controls.json')}
            runner.save(session / 'protocol.json', protocol)
            proof, content = proof_for((session / 'protocol.json').read_bytes())
            runner.save(session / 'protocol-receipt.json', proof)
            for i, name in enumerate(runner.RULES['order'], 1):
                folder = session / f'attempt-{i:02d}-{name}'
                folder.mkdir()
                rows, arm = AnalysisTests().data()
                nodes = ['a', 'b']
                arm['block_bytes'] = runner.RULES['block_bytes_by_condition'][name]
                arm['nodes'] = nodes
                for field in ('disk_before', 'disk_after', 'bytes'):
                    arm[field] = {n: arm[field][n] for n in nodes}
                for row in rows:
                    row['bytes'] = {n: row['bytes'][n] for n in nodes}
                    row['disk'] = {n: row['disk'][n] for n in nodes}
                health = {n: {'nvme_smart_health_information_log': {'critical_warning': 0, 'media_errors': 0}}
                          for n in ['a', 'b']}
                arm.update(status='candidate', errors=[], sources=protocol['config']['sources'],
                           start_unix_s=1001 + i * 200, process_exit=0,
                           protocol_sha256=hashlib.sha256(content).hexdigest(), protocol_commit=proof['commit'],
                           smart_before=health, smart_after=health,
                           F1={'outcome': 'ok', 'checks': {k: {'outcome': 'ok'}
                                                         for k in ['suspend', 'power', 'foreign_reads']}})
                arm['per_device'] = runner.device_validity(arm['disk_before'], arm['disk_after'], arm['bytes'])
                runner.save(folder / 'arm.json', arm)
                (folder / 'samples.jsonl').write_text(''.join(json.dumps(r) + '\n' for r in rows))
            result = analyze.analyze(session)
            self.assertTrue(result['complete_series'])
            self.assertEqual(result['pair_B_over_A'], [1, 1])
            first_bytes = (session / 'analysis.json').read_bytes()
            analyze.analyze(session)
            self.assertEqual(first_bytes, (session / 'analysis.json').read_bytes())
            second = session / 'attempt-02-B' / 'arm.json'
            changed = runner.load(second)
            changed['F1']['checks']['power']['outcome'] = 'unknown'
            runner.save(second, changed)
            result = analyze.analyze(session)
            self.assertFalse(result['complete_series'])
            self.assertFalse(result['attempts'][1]['accepted'])
            self.assertFalse(result['attempts'][2]['accepted'])


if __name__ == '__main__':
    unittest.main()
