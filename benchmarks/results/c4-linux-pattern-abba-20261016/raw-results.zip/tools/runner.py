"""Bounded Linux C4 direct-read study. No device formatting, mounting or raw writes.

Only certified fixture files are read. Four ABBA timed attempts, no replacements.
One observation per condition is exploratory; this is not Soup training evidence.
"""
import argparse
import ctypes
import hashlib
import json
import math
import mmap
import os
from pathlib import Path
import platform
import signal
import stat
import subprocess
import sys
import threading
import time
import uuid
import zipfile

from preflight import assess_paths, directory_report
from source.arm_validity import ArmWatch, disk_reads, other_disk_reads
from source.safetensors_reader import open_direct

ROOT = Path(__file__).resolve().parent
GIB = 1024**3
CHUNK = 4 * 1024**2
LIMIT = 1_000_000_000
SOURCE_NAMES = [
    'runner.py', 'preflight.py', 'storage_discovery.py', 'analyze.py', 'receipt.py', 'plot.py',
    'source/arm_validity.py', 'source/safetensors_reader.py',
    'test_runner.py', 'test_preflight.py', 'test_pattern.py', 'README_RU.md',
]
RULES = {
    'start_temperature_c': 45, 'stop_temperature_c': 70,
    'temperature_interval_s': 2, 'temperature_stale_s': 8,
    'foreign_read_limit_bytes': LIMIT, 'write_limit_bytes': LIMIT,
    'physical_read_deficit_tolerance_bytes': 2 * CHUNK,
    'sample_interval_s': 1, 'max_sample_gap_s': 5,
    'warmup_s': 600, 'window_s': 60, 'max_cooldown_s': 1800,
    'order': ['A', 'B', 'B', 'A'], 'durations_s': [3600] * 4,
    'attempt_budget': 4, 'replacements': 0, 'control_round_budget': 2,
    'control_round_timeout_s': 2400, 'block_bytes_by_condition': {'A': CHUNK, 'B': 64 * 1024**2},
    'control_modes': ['A', 'B'], 'indices': [0, 1],
    'analysis': 'Both B/A pair ratios and per-condition repeat ratios; all full 60s windows after 600s; no outlier deletion; first/last five-window ratio; no causal temperature claim',
    'control_seconds': {'baseline': 5, 'own': 60, 'foreign': 20},
    'scope': 'sequential direct-read primitive, QD1 per drive; two observations per request size; concurrent reads only',
}


def digest(path, guard=None):
    h = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(4 * 1024**2), b''):
            if guard is not None:
                guard.check()
            h.update(block)
    return h.hexdigest()


def sources():
    return {name: digest(ROOT / name) for name in SOURCE_NAMES}


def save(path, obj, exclusive=False):
    with Path(path).open('x' if exclusive else 'w', encoding='utf-8', newline='\n') as f:
        json.dump(obj, f, indent=2, allow_nan=False)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def ram_bytes():
    for line in Path('/proc/meminfo').read_text().splitlines():
        if line.startswith('MemTotal:'):
            return int(line.split()[1]) * 1024
    raise RuntimeError('MemTotal unavailable')


def file_identity(path):
    info = Path(path).stat()
    return {key: getattr(info, 'st_' + key) for key in ('dev', 'ino', 'size', 'mtime_ns')}


def counters(nodes):
    out = {}
    for line in Path('/proc/diskstats').read_text().splitlines():
        f = line.split()
        if f[2] in nodes:
            out[f[2]] = {'read_bytes': int(f[5]) * 512,
                         'write_bytes': int(f[9]) * 512,
                         'read_ios': int(f[3]), 'write_ios': int(f[7]),
                         'read_ms': int(f[6]), 'write_ms': int(f[10]),
                         'inflight': int(f[11]), 'io_ms': int(f[12])}
    if set(out) != set(nodes):
        raise RuntimeError('Physical disk counter missing')
    return out


def device_validity(before, after, own):
    result = {}
    for node, initial in before.items():
        rd = after[node]['read_bytes'] - initial['read_bytes']
        wr = after[node]['write_bytes'] - initial['write_bytes']
        residual = rd - own.get(node, 0)
        if rd < 0 or wr < 0 or residual < -RULES['physical_read_deficit_tolerance_bytes']:
            outcome = 'unknown'
        elif residual >= LIMIT or wr >= LIMIT:
            outcome = 'void'
        else:
            outcome = 'ok'
        result[node] = {'outcome': outcome, 'physical_read_bytes': rd,
                        'completed_direct_read_bytes': own.get(node, 0),
                        'residual_read_bytes': residual, 'write_bytes': wr}
    return result


def smart(node):
    # -a also requests optional self-test logs. Some healthy NVMe devices reject
    # that request; select identity/health/attributes without hiding failed reads.
    p = subprocess.run(['smartctl', '-i', '-H', '-A', '-j', '/dev/' + node],
                       capture_output=True, text=True, timeout=12, check=False)
    if p.returncode != 0:
        raise RuntimeError(f'SMART command failed ({p.returncode}): ' + p.stderr.strip())
    data = json.loads(p.stdout)
    if data.get('smartctl', {}).get('exit_status') != 0:
        raise RuntimeError('SMART JSON reports a command failure')
    health = data.get('nvme_smart_health_information_log', {})
    for field in ('critical_warning', 'media_errors'):
        if type(health.get(field)) is not int or health[field] < 0:
            raise RuntimeError('Required NVMe SMART field missing/invalid: ' + field)
    if health['critical_warning'] != 0:
        raise RuntimeError('NVMe critical warning is nonzero')
    if data.get('smart_status', {}).get('passed') is not True:
        raise RuntimeError('SMART health is not passed')
    # nvme-cli exposes thermal-management transition/time counters that
    # smartctl 7.4 may omit. Preserve these without treating zero as proof
    # that the firmware never throttled; unsupported fields may be absent.
    command = ['nvme', 'smart-log', '/dev/' + node, '-o', 'json']
    extra = subprocess.run(command, capture_output=True, text=True, timeout=12, check=False)
    if extra.returncode != 0:
        raise RuntimeError(f'NVMe health log failed ({extra.returncode}): ' + extra.stderr.strip())
    extra_data = json.loads(extra.stdout)
    for field in ('critical_warning', 'media_errors'):
        if type(extra_data.get(field)) is not int or extra_data[field] < 0:
            raise RuntimeError('Required nvme-cli field missing/invalid: ' + field)
        if extra_data[field] != health[field]:
            raise RuntimeError('SMART snapshots disagree on ' + field)
    data['nvme_cli_health'] = {'command': command, 'returncode': extra.returncode,
                               'data': extra_data}
    return data


def temp_paths(identity):
    controller = Path(identity['controller_sysfs']).resolve()
    paths = []
    for hw in Path('/sys/class/hwmon').glob('hwmon*'):
        real = hw.resolve()
        if controller in real.parents:
            paths.extend(str(p.resolve()) for p in hw.glob('temp*_input'))
    if not paths:
        raise RuntimeError('No hwmon temperature mapped to ' + identity['node'])
    return sorted(set(paths))


def temperatures(config):
    out = {}
    for drive in config['drives']:
        values = [int(Path(p).read_text()) / 1000 for p in drive['temperature_paths']]
        if not values or any(not math.isfinite(x) or x <= 0 or x >= 150 for x in values):
            raise RuntimeError('Missing/implausible temperature')
        out[drive['node']] = {'max_c': max(values), 'sensors_c': values}
    return out


class ThermalGuard:
    def __init__(self, config):
        self.config, self.last, self.reading, self.error = config, None, None, None
        self.done = threading.Event()

    def sample(self):
        try:
            reading = temperatures(self.config)
            self.reading, self.last = reading, time.monotonic()
            if max(v['max_c'] for v in reading.values()) >= RULES['stop_temperature_c']:
                raise RuntimeError('Operational temperature stop reached: ' + json.dumps(reading))
        except Exception as exc:
            self.error = repr(exc)

    def loop(self):
        while not self.done.wait(RULES['temperature_interval_s']):
            self.sample()
            if self.error:
                return

    def check(self):
        if self.error or self.last is None:
            raise RuntimeError('Thermal guard: ' + str(self.error))
        if time.monotonic() - self.last > RULES['temperature_stale_s']:
            raise RuntimeError('Temperature sample is stale')
        return self.reading

    def __enter__(self):
        self.sample()
        self.check()
        self.thread = threading.Thread(target=self.loop, daemon=True)
        self.thread.start()
        return self

    def __exit__(self, *args):
        self.done.set()
        self.thread.join(timeout=2)


def verify_host(config):
    if sys.platform != 'linux' or os.geteuid() != 0:
        raise RuntimeError('Run on the dedicated Linux host as root')
    if Path('/proc/sys/kernel/random/boot_id').read_text().strip() != config['boot_id']:
        raise RuntimeError('Boot identity changed; do not resume this protocol')
    if ram_bytes() != config['ram_bytes']:
        raise RuntimeError('RAM changed')
    reports = [directory_report(d['directory']) for d in config['drives']]
    # Space was screened before fixture creation; do not require it twice afterwards.
    for drive, report in zip(config['drives'], reports):
        if report['leaves'] != [drive['node']] or report['identities'] != drive['identities']:
            raise RuntimeError('Device or directory backing changed')
        if report['filesystem_readonly']:
            raise RuntimeError('Filesystem became read-only')
        if temp_paths(drive['identities'][0]) != drive['temperature_paths']:
            raise RuntimeError('Temperature mapping changed')
    if config['sources'] != sources():
        raise RuntimeError('Sources changed after configure')
    if config['rules'] != RULES:
        raise RuntimeError('Rules differ from the configured version')


def configure(args):
    if sys.platform != 'linux' or os.geteuid() != 0:
        raise RuntimeError('Root on Linux is required')
    virt = subprocess.run(['systemd-detect-virt'], capture_output=True, text=True, check=False)
    if virt.stdout.strip() != 'none' or virt.returncode != 1:
        raise RuntimeError('Bare-metal check did not return none')
    ram = ram_bytes()
    reports = [directory_report(p) for p in args.paths]
    problems = assess_paths(reports, ram)
    if problems:
        raise RuntimeError('; '.join(problems))
    size = ((ram * 5 // 4 + 16 * GIB - 1) // (16 * GIB)) * 16 * GIB
    config = {'kind': 'C4 Linux configuration; not frozen measurements',
              'created_unix_s': time.time(), 'sources': sources(), 'rules': RULES,
              'ram_bytes': ram, 'dataset_bytes': size,
              'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
              'platform': platform.platform(), 'python': sys.version, 'drives': []}
    for report in reports:
        if report['free_bytes'] < size + 20 * GIB:
            raise RuntimeError('Need fixture plus 20 GiB reserve on each drive')
        identity = report['identities'][0]
        config['drives'].append({
            'directory': report['path'], 'node': identity['node'],
            'identities': report['identities'], 'temperature_paths': temp_paths(identity),
            'smart_initial': smart(identity['node']),
        })
    temperatures(config)
    # Exercise suspend/process/power sensor availability without reading fixture data.
    watch = make_watch(config, [0, 1], 'configure')
    watch.start()
    time.sleep(1)
    config['instrument_startup'] = watch.stop()
    if config['instrument_startup']['outcome'] != 'ok':
        raise RuntimeError('Initial F1 sensors not OK: ' + json.dumps(config['instrument_startup']))
    session = Path(args.session).resolve()
    session.mkdir(exist_ok=False)
    save(session / 'config.json', config, exclusive=True)
    print('Configured:', session, '\nFixture per SSD:', size / GIB, 'GiB')


def make_watch(config, indices, label):
    nodes = [config['drives'][i]['node'] for i in indices]

    def target_reads(_):
        values = [disk_reads(n) for n in nodes]
        if any(x is None for x in values):
            raise RuntimeError('Missing target counter')
        return sum(values)

    def outside_reads(_):
        # Reuse the original physical-device filter; subtract the other targets.
        value = other_disk_reads(nodes[0])
        for node in nodes[1:]:
            read = disk_reads(node)
            if read is None:
                raise RuntimeError('Missing target counter')
            value -= read
        if value < 0:
            raise RuntimeError('Inconsistent outside-device snapshot')
        return value

    return ArmWatch(arm=label, round=0, run=0, model_path='target-device-set',
                    disk_device=lambda _: '+'.join(nodes), disk_reads=target_reads,
                    other_disk_reads=outside_reads, gpu_clock=lambda: None,
                    gpu_memory_used=lambda: None, gpu_processes=lambda: None)


def create_fixture(path, size, guard):
    h = hashlib.sha256()
    with Path(path).open('xb', buffering=0) as out:
        for offset in range(0, size, CHUNK):
            guard.check()
            block = os.urandom(CHUNK)
            view = memoryview(block)
            while view:
                n = out.write(view)
                if not n:
                    raise RuntimeError('Short fixture write')
                view = view[n:]
            h.update(block)
            if (offset + CHUNK) % (256 * 1024**2) == 0:
                os.fsync(out.fileno())
            if (offset + CHUNK) % (4 * GIB) == 0:
                print('Prepared', Path(path).name, (offset + CHUNK) / GIB, '/', size / GIB,
                      'GiB', flush=True)
        os.fsync(out.fileno())
    info = Path(path).stat()
    if info.st_blocks * 512 < size:
        raise RuntimeError('Fixture may be sparse or compressed')
    return {'path': str(Path(path).resolve()), 'sha256': h.hexdigest(),
            'identity': file_identity(path), 'kind': 'synthetic random bytes'}


def prepare(session, small):
    config = load(session / 'config.json')
    verify_host(config)
    name = 'small-fixtures.json' if small else 'fixtures.json'
    # A start marker makes interrupted preparation explicit and refuses silent overwrite.
    save(session / (name + '.started'), {'unix_s': time.time()}, exclusive=True)
    records = []
    with ThermalGuard(config) as guard:
        for i, drive in enumerate(config['drives']):
            directory = Path(drive['directory']) / ('c4-' + session.name)
            directory.mkdir(exist_ok=True)
            size = 256 * 1024**2 if small else config['dataset_bytes']
            path = directory / ('control.bin' if small else 'dataset.bin')
            records.append(create_fixture(path, size, guard))
    save(session / name, records, exclusive=True)
    print('Prepared:', session / name)


def check_fixture(cert, drive):
    path = Path(cert['path'])
    if path.is_symlink() or not stat.S_ISREG(path.stat().st_mode):
        raise RuntimeError('Fixture must be a regular non-symlink file')
    if Path(drive['directory']).resolve() not in path.resolve().parents:
        raise RuntimeError('Fixture escaped its declared drive directory')
    if file_identity(path) != cert['identity']:
        raise RuntimeError('Fixture changed')
    if directory_report(path.parent)['leaves'] != [drive['node']]:
        raise RuntimeError('Fixture backing changed')



def validate_read_geometry(active_bytes, block_bytes):
    if block_bytes not in (4 * 1024**2, 64 * 1024**2):
        raise ValueError('Request size must be exactly 4 or 64 MiB')
    if active_bytes < block_bytes or active_bytes % block_bytes:
        raise ValueError('Active footprint must contain whole aligned requests')


def adopt_fixtures(session, old_session):
    config = load(session / 'config.json')
    verify_host(config)
    certs = load(old_session / 'fixtures.json')
    if len(certs) != 2:
        raise RuntimeError('Exactly two fixtures required')
    for cert, drive in zip(certs, config['drives']):
        check_fixture(cert, drive)
        if cert['identity']['size'] != config['dataset_bytes']:
            raise RuntimeError('Fixture size differs from new declaration')
        validate_read_geometry(cert['identity']['size'] // 2, 64 * 1024**2)
    if sum(c['identity']['size'] // 2 for c in certs) <= config['ram_bytes']:
        raise RuntimeError('Active aggregate footprint must exceed RAM')
    save(session / 'fixture-adoption.json', {
        'from_session': str(old_session), 'sha256': digest(old_session / 'fixtures.json'),
        'unix_s': time.time(), 'full_rehash_required_at_seal': True}, exclusive=True)
    save(session / 'fixtures.json', certs, exclusive=True)


def read_exact(handle, buffer):
    got = handle.readinto(buffer)
    if got != len(buffer):
        raise RuntimeError(f'Short/unaligned direct read: {got}/{len(buffer)}')


def read_fixed(path, byte_count, seconds=30, guard=None, block_bytes=CHUNK):
    """Control injection, in the orchestrator (a sibling, not child, of the watched process)."""
    end = time.monotonic() + seconds
    size = Path(path).stat().st_size
    validate_read_geometry(size, block_bytes)
    if byte_count <= 0 or byte_count % block_bytes:
        raise ValueError("Injection byte count must be a positive multiple of the request size")
    with open_direct(str(path)) as handle, mmap.mmap(-1, block_bytes) as buffer:
        if ctypes.addressof(ctypes.c_char.from_buffer(buffer)) % 4096:
            raise RuntimeError('Unaligned buffer')
        total = 0
        while total < byte_count:
            if guard is not None:
                guard.check()
            if time.monotonic() >= end:
                raise RuntimeError('Control injection timed out')
            if handle.tell() == size:
                handle.seek(0)
            read_exact(handle, buffer)
            total += block_bytes
    return total


def interval(config, fixtures, indices, seconds, folder, idle=False, ready=None, block_bytes=CHUNK):
    nodes = [config['drives'][i]['node'] for i in indices]
    record = {'status': 'invalid', 'kind': 'read interval', 'start_unix_s': time.time(),
              'nodes': nodes, 'target_seconds': seconds, 'sources': sources(), 'block_bytes': block_bytes}
    stop, begin = threading.Event(), threading.Event()
    lock = threading.Lock()
    totals = {n: 0 for n in nodes}
    errors, threads = [], []
    watch = make_watch(config, indices, folder.name)
    deadline = [None]
    watch_started = False

    def worker(index):
        node, cert = config['drives'][index]['node'], fixtures[index]
        active_bytes = cert['identity']['size'] // len(indices)
        try:
            validate_read_geometry(active_bytes, block_bytes)
            with open_direct(cert['path']) as handle, mmap.mmap(-1, block_bytes) as buffer:
                if ctypes.addressof(ctypes.c_char.from_buffer(buffer)) % 4096:
                    raise RuntimeError('Unaligned buffer')
                begin.wait()
                while not stop.is_set() and time.monotonic() < deadline[0]:
                    if handle.tell() >= active_bytes:
                        handle.seek(0)
                    read_exact(handle, buffer)
                    with lock:
                        totals[node] += block_bytes
        except BaseException as exc:
            with lock:
                errors.append(repr(exc))
            stop.set()

    try:
        verify_host(config)
        for i in indices:
            check_fixture(fixtures[i], config['drives'][i])
        with ThermalGuard(config) as guard:
            record['disk_before'] = counters(nodes)
            watch.start()
            watch_started = True
            if not idle:
                for i in indices:
                    thread = threading.Thread(target=worker, args=(i,), daemon=True)
                    threads.append(thread)
                    thread.start()
            start = previous = time.monotonic()
            deadline[0] = start + seconds
            begin.set()
            if ready:
                Path(ready).write_text('ready', encoding='ascii')
            with (folder / 'samples.jsonl').open('x', encoding='utf-8') as out:
                def sample():
                    nonlocal previous
                    now = time.monotonic()
                    reading = guard.check()
                    with lock:
                        counts = dict(totals)
                    row = {'elapsed_s': now - start, 'interval_s': now - previous,
                           'unix_s': time.time(), 'bytes': counts, 'temperature': reading,
                           'disk': counters(nodes)}
                    if row['interval_s'] > RULES['max_sample_gap_s']:
                        errors.append('Monitoring sample gap exceeded limit')
                        stop.set()
                    out.write(json.dumps(row) + '\n')
                    out.flush()
                    previous = now
                    return row

                print('Started', folder.name, 'target', seconds, 's', flush=True)
                last_print = start
                while time.monotonic() < deadline[0] and not stop.wait(1):
                    row = sample()
                    if time.monotonic() - last_print >= 30:
                        print(folder.name, round(row['elapsed_s']), 's',
                              round(sum(row['bytes'].values()) / GIB, 1), 'GiB', flush=True)
                        last_print = time.monotonic()
                stop.set()
                for thread in threads:
                    thread.join(timeout=3)
                if any(t.is_alive() for t in threads):
                    errors.append('A direct read did not stop; kernel I/O may be stuck')
                row = sample()
                record['elapsed_s'], record['bytes'] = row['elapsed_s'], row['bytes']
                record['disk_after'] = row['disk']
                record['per_device'] = device_validity(record['disk_before'], row['disk'], row['bytes'])
                if not idle and any(row['bytes'][n] == 0 for n in nodes):
                    errors.append('A reader did no work')
                if row['elapsed_s'] < seconds or row['elapsed_s'] > seconds + 5:
                    errors.append('Duration outside declared tolerance')
            guard.check()
    except BaseException as exc:
        errors.append(repr(exc))
    finally:
        stop.set()
        deadline[0] = deadline[0] or time.monotonic()
        begin.set()
        for thread in threads:
            thread.join(timeout=1)
        if watch_started:
            try:
                record['F1'] = watch.stop()
            except BaseException as exc:
                errors.append('F1 finalization failed: ' + repr(exc))
        record['errors'] = errors
        record['end_unix_s'] = time.time()
        record['status'] = 'candidate' if (
            not errors and record.get('F1', {}).get('outcome') == 'ok'
            and all(r['outcome'] == 'ok' for r in record.get('per_device', {}).values())
            and set(record.get('per_device', {})) == set(nodes)
        ) else 'invalid'
        save(folder / 'arm.json', record)
    return record


def cooldown(config, folder):
    deadline = time.monotonic() + RULES['max_cooldown_s']
    with (folder / 'cooldown.jsonl').open('x', encoding='utf-8') as out:
        while True:
            readings = temperatures(config)
            out.write(json.dumps({'unix_s': time.time(), 'temperatures': readings}) + '\n')
            out.flush()
            if max(v['max_c'] for v in readings.values()) <= RULES['start_temperature_c']:
                return
            if time.monotonic() >= deadline:
                raise RuntimeError('Cooldown budget exhausted; no timed arm started')
            time.sleep(10)


def controls(session):
    config, fixtures = load(session / 'config.json'), load(session / 'small-fixtures.json')
    verify_host(config)
    attempts = sorted(session.glob('controls-*'))
    if len(attempts) >= RULES['control_round_budget']:
        raise RuntimeError('Control-round budget exhausted')
    folder = session / f'controls-{len(attempts) + 1:02d}'
    folder.mkdir(exist_ok=False)
    result = {'status': 'failed', 'cases': [], 'sources': sources(), 'start_unix_s': time.time()}
    end = time.monotonic() + RULES['control_round_timeout_s']
    active = None
    try:
        cooldown(config, folder)
        for label in RULES['control_modes']:
            indices = [0, 1]
            block_bytes = RULES['block_bytes_by_condition'][label]
            for case in ('baseline', 'own', 'foreign'):
                if time.monotonic() >= end:
                    raise RuntimeError('Control-round time budget exhausted')
                job = folder / (label + '-' + case)
                job.mkdir()
                spec = {'session': str(session), 'indices': indices, 'case': case, 'block_bytes': block_bytes}
                save(job / 'spec.json', spec, exclusive=True)
                with (job / 'process.log').open('x') as log:
                    active = subprocess.Popen([sys.executable, str(ROOT / 'runner.py'),
                                               '_control', '--spec', str(job / 'spec.json')],
                                              stdout=log, stderr=subprocess.STDOUT)
                    if case == 'foreign':
                        ready_deadline = time.monotonic() + 15
                        while not (job / 'ready').exists():
                            if active.poll() is not None or time.monotonic() >= ready_deadline:
                                raise RuntimeError('Control child did not become ready')
                            time.sleep(0.1)
                        # This process is the child's parent, outside its own-process tree.
                        with ThermalGuard(config) as guard:
                            for i in indices:
                                guard.check()
                                read_fixed(fixtures[i]['path'], 1280 * 1024**2, seconds=8, guard=guard, block_bytes=block_bytes)
                    code = active.wait(timeout=100)
                    active = None
                arm = load(job / 'arm.json')
                expected = 'void' if case == 'foreign' else 'ok'
                f1 = arm.get('F1', {}).get('outcome')
                device_results = [r['outcome'] for r in arm.get('per_device', {}).values()]
                passed = (code == 0 and not arm['errors'] and f1 == expected
                          and len(device_results) == len(indices)
                          and all(x == expected for x in device_results))
                entry = {'case': label + '-' + case, 'expected': expected,
                         'F1': f1, 'devices': device_results, 'passed': passed,
                         'arm_sha256': digest(job / 'arm.json')}
                result['cases'].append(entry)
                print(entry, flush=True)
                if not passed:
                    raise RuntimeError('Control failed; retain records and review')
        result['status'] = 'controls_passed'
    except BaseException as exc:
        result['error'] = repr(exc)
    finally:
        if active is not None and active.poll() is None:
            active.terminate()
            try:
                active.wait(timeout=5)
            except subprocess.TimeoutExpired:
                active.kill()
                active.wait(timeout=5)
        result['end_unix_s'] = time.time()
        save(folder / 'controls.json', result)
    print('Controls:', result['status'], '\nSaved:', folder)
    if result['status'] != 'controls_passed':
        raise RuntimeError('Controls did not pass')


def seal(session):
    config, fixtures = load(session / 'config.json'), load(session / 'fixtures.json')
    verify_host(config)
    rounds = sorted(session.glob('controls-*/controls.json'))
    if not rounds or load(rounds[-1])['status'] != 'controls_passed':
        raise RuntimeError('Latest controls must pass')
    if load(rounds[-1])['sources'] != sources():
        raise RuntimeError('Controls used different sources')
    print('Verifying complete fixture SHA-256 values before freezing...', flush=True)
    with ThermalGuard(config) as guard:
        for cert, drive in zip(fixtures, config['drives']):
            check_fixture(cert, drive)
            guard.check()
            if digest(cert['path'], guard) != cert['sha256']:
                raise RuntimeError('Fixture hash mismatch')
            guard.check()
    protocol = {'status': 'frozen', 'frozen_unix_s': time.time(), 'config': config,
                'fixtures': fixtures, 'controls_path': str(rounds[-1].relative_to(session)),
                'controls_sha256': digest(rounds[-1]),
                'limitations': [
                    'ABBA: two observations per request size, concurrent reads only; descriptive repeatability, no broad certification.',
                    'New-host direct-read primitive, not original Soup training striping.',
                    '4 vs 64 MiB sequential requests only; no controlled cooling/random access. Thermal causality remains open.',
                    'Power uses original F1 no-battery inference; no independent PSU telemetry.',
                    'Physical counters and O_DIRECT do not certify the SSD internal cache or firmware.',
                    'Kernel-hung I/O cannot be guaranteed interruptible by Python.',
                ]}
    save(session / 'protocol.json', protocol, exclusive=True)
    print('Frozen:', session / 'protocol.json')
    print('SHA256:', digest(session / 'protocol.json'))
    print('Commit this exact protocol in Soup before running; create its offline Git receipt.')


def claim_attempt(session, ordinal, name):
    previous = sorted(session.glob('attempt-*'))
    if ordinal != len(previous) + 1 or ordinal > RULES['attempt_budget']:
        raise RuntimeError('Attempt order/budget violation; no automatic replacement')
    if previous and load(previous[-1] / 'arm.json').get('status') != 'candidate':
        raise RuntimeError('Previous attempt failed; stop for review')
    folder = session / f'attempt-{ordinal:02d}-{name}'
    folder.mkdir(exist_ok=False)
    save(folder / 'arm.json', {'status': 'incomplete', 'claimed_unix_s': time.time()}, exclusive=True)
    return folder


def run_series(session, receipt_path):
    from receipt import verify_receipt
    protocol_bytes = (session / 'protocol.json').read_bytes()
    receipt = verify_receipt(load(receipt_path), protocol_bytes)
    protocol = json.loads(protocol_bytes)
    if protocol['status'] != 'frozen' or receipt['committed_unix_s'] > time.time():
        raise RuntimeError('Protocol not frozen/commit timestamp is in the future')
    config = protocol['config']
    if load(session / 'config.json') != config or load(session / 'fixtures.json') != protocol['fixtures']:
        raise RuntimeError('Session configuration/fixtures differ from frozen protocol')
    if receipt['committed_unix_s'] < math.floor(protocol['frozen_unix_s']):
        raise RuntimeError('Commit timestamp precedes protocol freeze')
    verify_host(config)
    if digest(session / protocol['controls_path']) != protocol['controls_sha256']:
        raise RuntimeError('Control evidence changed')
    if list(session.glob('attempt-*')):
        raise RuntimeError('This series was already attempted; no silent resume/replacement')
    save(session / 'protocol-receipt.json', load(receipt_path), exclusive=True)
    for ordinal, (name, seconds, indices) in enumerate(
        zip(RULES['order'], RULES['durations_s'], ([0, 1],) * 4), 1
    ):
        folder = claim_attempt(session, ordinal, name)
        # The attempt is claimed before preconditions; interruptions consume the budget.
        try:
            cooldown(config, folder)
            before = {d['node']: smart(d['node']) for d in config['drives']}
            save(folder / 'smart-before.json', before, exclusive=True)
            spec = {'session': str(session), 'indices': indices, 'seconds': seconds, 'block_bytes': RULES['block_bytes_by_condition'][name]}
            save(folder / 'spec.json', spec, exclusive=True)
            with (folder / 'process.log').open('x') as log:
                child = subprocess.Popen([sys.executable, str(ROOT / 'runner.py'),
                                          '_arm', '--spec', str(folder / 'spec.json')],
                                         stdout=log, stderr=subprocess.STDOUT)
                try:
                    process_deadline = time.monotonic() + seconds + 60
                    while child.poll() is None:
                        if time.monotonic() >= process_deadline:
                            raise RuntimeError('Child exceeded wall-clock budget')
                        print(name, 'running; log:', folder / 'process.log', flush=True)
                        try:
                            child.wait(timeout=30)
                        except subprocess.TimeoutExpired:
                            pass
                    code = child.returncode
                except BaseException:
                    child.terminate()
                    try:
                        child.wait(timeout=8)
                    except subprocess.TimeoutExpired:
                        child.kill()
                        child.wait(timeout=8)
                    raise
            arm = load(folder / 'arm.json')
            arm.update(protocol_sha256=hashlib.sha256(protocol_bytes).hexdigest(),
                       protocol_commit=receipt['commit'], process_exit=code, smart_before=before)
            save(folder / 'arm.json', arm)
            after = {d['node']: smart(d['node']) for d in config['drives']}
            arm['smart_after'] = after
            save(folder / 'arm.json', arm)
            for node in before:
                b = before[node]['nvme_smart_health_information_log']
                a = after[node]['nvme_smart_health_information_log']
                if a['media_errors'] != b['media_errors']:
                    raise RuntimeError('NVMe media-error counter changed')
            for cert, drive in zip(protocol['fixtures'], config['drives']):
                check_fixture(cert, drive)
            verify_host(config)
            if code or arm['status'] != 'candidate':
                arm['status'] = 'invalid'
            save(folder / 'arm.json', arm)
            if arm['status'] != 'candidate':
                raise RuntimeError('Invalid arm; series stopped')
        except BaseException as exc:
            arm = load(folder / 'arm.json')
            arm.update(status='invalid', orchestrator_error=repr(exc))
            save(folder / 'arm.json', arm)
            raise
    print('Four attempts completed. Analyze and bundle; C4 completion is not implied.')


def bundle(session):
    paths = [p for p in session.rglob('*') if p.is_file()]
    if any(p.is_symlink() or p.stat().st_size > 100 * 1024**2 for p in paths):
        raise RuntimeError('Refusing unexpected large/link evidence file')
    archive = session.parent / ('c4_linux_results_' + uuid.uuid4().hex[:8] + '.zip')
    manifest = {}
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as z:
        for p in paths:
            name = 'evidence/' + p.relative_to(session).as_posix()
            z.write(p, name)
            manifest[name] = digest(p)
        for name in SOURCE_NAMES:
            z.write(ROOT / name, 'tools/' + name)
            manifest['tools/' + name] = digest(ROOT / name)
        z.writestr('SHA256SUMS.json', json.dumps(manifest, indent=2) + '\n')
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:
            raise RuntimeError('Bundle CRC failed')
        for name, expected in manifest.items():
            if hashlib.sha256(z.read(name)).hexdigest() != expected:
                raise RuntimeError('Bundle changed while saving: ' + name)
    print('Download:', archive)
    print('SHA256:', digest(archive))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['configure', 'prepare-small', 'controls', 'prepare',
                                           'seal', 'adopt-fixtures', 'run-series', 'bundle', '_control', '_arm'])
    parser.add_argument('--session', default='c4-session')
    parser.add_argument('--paths', nargs=2, default=['/mnt/c4-disk1', '/mnt/c4-disk2'])
    parser.add_argument('--receipt')
    parser.add_argument('--from-session')
    parser.add_argument('--spec')
    args = parser.parse_args()
    if args.command == 'configure':
        configure(args)
        return
    if args.command in ('_control', '_arm'):
        spec_path = Path(args.spec).resolve(strict=True)
        spec = load(spec_path)
        session, folder = Path(spec['session']), spec_path.parent
        control = args.command == '_control'
        if control:
            config = load(session / 'config.json')
            fixtures = load(session / 'small-fixtures.json')
        else:
            protocol = load(session / 'protocol.json')
            config, fixtures = protocol['config'], protocol['fixtures']
        case = spec.get('case', 'own')
        seconds = RULES['control_seconds'][case] if control else spec['seconds']
        record = interval(config, fixtures, spec['indices'], seconds, folder,
                          idle=case != 'own', ready=folder / 'ready' if control else None, block_bytes=spec['block_bytes'])
        # Controls inspect expected VOID themselves; only execution errors fail this process.
        raise SystemExit(1 if record['errors'] else 0)
    session = Path(args.session).resolve(strict=True)
    if args.command == 'prepare-small':
        prepare(session, True)
    elif args.command == 'prepare':
        prepare(session, False)
    elif args.command == 'controls':
        controls(session)
    elif args.command == 'adopt-fixtures':
        adopt_fixtures(session, Path(args.from_session).resolve(strict=True))
    elif args.command == 'seal':
        seal(session)
    elif args.command == 'run-series':
        if not args.receipt:
            parser.error('--receipt is required; protocol must be committed before measurement')
        run_series(session, Path(args.receipt))
    elif args.command == 'bundle':
        bundle(session)


if __name__ == '__main__':
    def interrupted(signum, frame):
        raise KeyboardInterrupt('Signal ' + str(signum))
    if hasattr(signal, 'SIGTERM'):
        signal.signal(signal.SIGTERM, interrupted)
    try:
        main()
    except Exception as exc:
        print('STOP:', exc, file=sys.stderr, flush=True)
        raise SystemExit(1)
