#!/bin/bash
set -eu
cd /root/c4-pattern-v1
python3 runner.py configure --session pattern-session
python3 runner.py prepare-small --session pattern-session
python3 runner.py adopt-fixtures --session pattern-session --from-session /root/c4-linux/c4-session
python3 runner.py controls --session pattern-session
python3 runner.py seal --session pattern-session
