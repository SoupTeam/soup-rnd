# C4 Linux exploratory direct-read results

Two observations per request size in ABBA order. This is not a completed C4 acceptance or Soup training run.

| Attempt | Accepted | Post-warmup GB/s | Provisional planner GB/s |
|---|---|---:|---:|
| attempt-01-A | True | 4.445788689517215 | 3.9347876316970356 |
| attempt-02-B | True | 5.106466118316281 | 4.56767212953202 |
| attempt-03-B | True | 4.751384333286672 | 4.238721647392241 |
| attempt-04-A | True | 4.051210152151184 | 3.627131084613943 |

## Limitations

- ABBA: two observations per request size, concurrent reads only; descriptive repeatability, no broad certification.
- New-host direct-read primitive, not original Soup training striping.
- 4 vs 64 MiB sequential requests only; no controlled cooling/random access. Thermal causality remains open.
- Power uses original F1 no-battery inference; no independent PSU telemetry.
- Physical counters and O_DIRECT do not certify the SSD internal cache or firmware.
- Kernel-hung I/O cannot be guaranteed interruptible by Python.

Temperature/throughput correlation alone does not establish thermal throttling or its absence.
All attempts and controls remain in the bundle. GB/s uses 10^9 bytes.
