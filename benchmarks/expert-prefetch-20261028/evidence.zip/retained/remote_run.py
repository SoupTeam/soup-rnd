"""New CPU-thread/forward-window study; unchanged input and resource safety gates."""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import traceback
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path('/root/liger')
REPO = ROOT / 'repo'
OUT = ROOT / 'results'
MODEL = 'kakaocorp/kanana-2-30b-a3b-base-2601'
REVISION = '0d31365acf656e5f9a593cacc4913e9c0d36cb1c'
SOURCE_BYTES = 61343935088


def digest(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for chunk in iter(lambda: handle.read(8 * 2**20), b''):
            value.update(chunk)
    return value.hexdigest()



def retain_exact_metadata(source, destination, expected_sha256):
    """Retain original metadata bytes only when their frozen identity remains stable."""
    source, destination = Path(source), Path(destination)
    temporary = destination.with_name(destination.name + '.incoming')
    if destination.exists() or destination.is_symlink() or temporary.exists() or temporary.is_symlink():
        raise FileExistsError('Refuse replacing existing retained metadata')
    before = source.stat()
    if digest(source) != expected_sha256:
        raise ValueError('Metadata source differs from its prepared fingerprint')
    try:
        shutil.copyfile(source, temporary)
        if temporary.stat().st_size != before.st_size or digest(temporary) != expected_sha256:
            raise ValueError('Copied metadata differs from its prepared fingerprint')
        after = source.stat()
        if (after.st_size != before.st_size or after.st_mtime_ns != before.st_mtime_ns
                or digest(source) != expected_sha256):
            raise ValueError('Metadata source changed while retaining its bytes')
        with temporary.open('r+b') as retained:
            retained.flush()
            os.fsync(retained.fileno())
        if destination.exists() or destination.is_symlink():
            raise FileExistsError('Retained metadata destination appeared during copying')
        os.replace(temporary, destination)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return {'bytes': before.st_size, 'sha256': expected_sha256}



def save(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)



def phase_receipt(phase, status, spec_path, command=None):
    path = OUT / 'phase-order.json'
    source = json.loads((ROOT / 'source-manifest.json').read_text())['source_commit']
    identity = {'source_commit': source, 'spec_sha256': digest(spec_path)}
    value = json.loads(path.read_text()) if path.exists() else {**identity, 'records': []}
    if any(value.get(key) != expected for key, expected in identity.items()):
        raise ValueError('Phase order identity changed')
    record = {'phase': phase, 'status': status, 'monotonic': time.monotonic(), 'unix': time.time()}
    if command is not None:
        record['command'] = command
    value['records'].append(record)
    save(path, value)



def pre_download_disk_gate():
    root_free, data_free = shutil.disk_usage(ROOT).free, shutil.disk_usage('/data').free
    proof = {'root_free_bytes': root_free, 'data_free_bytes': data_free,
             'minimum_root_bytes': 16 * 2**30, 'minimum_data_bytes': 100 * 2**30,
             'passed': root_free >= 16 * 2**30 and data_free >= 100 * 2**30,
             'unix': time.time()}
    save(OUT / 'pre-download-disk.json', proof)
    if not proof['passed']:
        raise RuntimeError('Root16GiB/data100GiB free reserve must hold before large download')
    return proof



def pre_prepare_disk_gate(protocol):
    plan = protocol['storage_capacity_plan']
    required = sum(plan['data_components_bytes'].values()) - SOURCE_BYTES
    if (required != plan['minimum_pre_prepare_data_free_bytes']
            or plan['actual_statvfs_is_authoritative'] is not True
            or sum(plan['root_components_bytes'].values()) > 16 * 2**30
            or plan['output_filesystem'] != 'root'):
        raise RuntimeError('Immutable remaining NF4/output disk plan differs')
    root_free, data_free = shutil.disk_usage(ROOT).free, shutil.disk_usage('/data').free
    proof = {'unix': time.time(), 'root_free_bytes': root_free, 'data_free_bytes': data_free,
             'minimum_root_bytes': 16 * 2**30, 'minimum_data_bytes': required,
             'capacity_plan_sha256': hashlib.sha256(json.dumps(
                 plan, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
             'passed': root_free >= 16 * 2**30 and data_free >= required}
    save(OUT / 'pre-prepare-disk.json', proof)
    if not proof['passed']:
        raise RuntimeError('Remaining exact NF4/raw/archive/repair disk reserve is insufficient')
    return proof



def command(name, arguments, *, timeout=14400):
    save(OUT / 'stage-status.json', {'status': 'running', 'phase': name, 'unix': time.time()})
    with (OUT / (name + '.log')).open('wb') as log:
        process = subprocess.run(arguments, cwd=REPO, stdout=log, stderr=subprocess.STDOUT,
                                 timeout=timeout)
    save(OUT / (name + '-exit.json'), {'returncode': process.returncode, 'unix': time.time()})
    if process.returncode:
        raise RuntimeError(f'{name} failed with exit code {process.returncode}')



def export(status):
    import lossless_results

    export_dir = ROOT / 'exports'
    export_dir.mkdir(exist_ok=True)
    archive = export_dir / 'result.lossless.tar'
    files = [path for path in OUT.rglob('*') if path.is_file()]
    files += [ROOT / name for name in ('setup.log', 'source-manifest.json', 'constraints.txt',
                                      'preflight_remote.py', 'remote_run.py', 'setup.sh',
                                      'runtime_stack.py', 'test_cpu_overlap_cuda13_independent.py', 'cpu-overlap-cuda13-independent.xml', 'cpu-overlap-cuda13-independent-review.json', 'audit-cuda13-fixture.json', 'software-cohort.json', 'runtime-wheel-lock.json',
                                      'runtime-wheel-requirements.txt', 'cuda13-stack-metadata.json',
                                      'cuda13-transitive-metadata.json', 'prior-attempt-a.json',
                                      'protocol.json', 'transfer_probe.py', 'cpu_overlap_probe.py', 'profile_timeline.py', 'protocol-contract.json',
                                      'test_cpu_overlap_independent.py', 'cpu-overlap-independent.xml',
                                      'cpu-overlap-independent-review.json',
                                      'test_cpu_overlap_runtime.py', 'cpu-overlap-controls.xml', 'checkpoint_integrity.py', 'storage-capacity-plan.json', 'launch-manifest.json',
                                      'source-controls.xml', 'lossless_results.py')
              if (ROOT / name).is_file()]
    names = [path.relative_to(ROOT).as_posix() for path in files]
    packed = lossless_results.pack(ROOT, names, archive)
    mapping = {path.relative_to(ROOT).as_posix(): {
        'bytes': path.stat().st_size, 'sha256': digest(path),
    } for path in files}
    save(export_dir / 'archive-manifest.json', {
        'format': packed['format'], 'archive_bytes': packed['archive_bytes'],
        'sha256': packed['archive_sha256'], 'original_bytes': packed['original_bytes'],
        'files': mapping,
        'source_commit': json.loads((ROOT / 'source-manifest.json').read_text())['source_commit'],
        'stage_status': status,
    })



def validate_cuda_xml(path, expected_names):
    cases = ET.parse(path).findall('.//testcase')
    if len(cases) != len(expected_names) or any(
        case.find('skipped') is not None or case.find('failure') is not None
        or case.find('error') is not None for case in cases
    ):
        raise RuntimeError('All four required native CUDA numerical cells must pass without skips')
    if {case.attrib['name'] for case in cases} != set(expected_names):
        raise RuntimeError('CUDA XML differs from the frozen Kanana/NF4 preflight selection')



def validate_cpu_overlap_outputs(directory, spec_path, protocol):
    import importlib.util

    expected = ROOT / 'transfer_probe.py'
    launch = json.loads((ROOT / 'launch-manifest.json').read_text())
    wanted = launch['files']['transfer_probe.py']['sha256']
    if digest(expected) != wanted:
        raise RuntimeError('Frozen private CPU probe source changed before validation')
    module_spec = importlib.util.spec_from_file_location('private_transfer_probe', expected)
    probe = importlib.util.module_from_spec(module_spec)
    sys.modules[module_spec.name] = probe
    module_spec.loader.exec_module(probe)
    if (os.path.realpath(probe.__file__) != os.path.realpath(expected)
            or digest(Path(probe.__file__)) != wanted):
        raise RuntimeError('Imported CPU probe is not the frozen private uploaded source')
    proof = probe.validate_result(Path(directory), json.loads(Path(spec_path).read_text()), protocol)
    if (not isinstance(proof, dict)
            or proof.get('status') != 'passed_structural_probe_validation'):
        raise RuntimeError('New probe validator did not return the required passed proof status')
    save(OUT / 'transfer-validation.json', proof)
    return proof


def main():
    OUT.mkdir(exist_ok=True)
    final = {'status': 'failed', 'phase': 'initializing', 'unix': time.time()}
    try:
        protocol = json.loads((ROOT / 'protocol.json').read_text())
        manifest = json.loads((ROOT / 'source-manifest.json').read_text())
        if digest(ROOT / 'source.tar.gz') != manifest['archive_sha256']:
            raise RuntimeError('Deployed source archive changed')
        for name, row in manifest['files'].items():
            if digest(REPO / name) != row['sha256']:
                raise RuntimeError('Deployed source bytes differ: ' + name)
        if subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() != (
            manifest['source_commit']
        ):
            raise RuntimeError('Deployed Git HEAD differs from frozen source')
        if subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'],
                                   cwd=REPO, text=True).strip():
            raise RuntimeError('Deployed tracked Git source is dirty before CUDA or model download')
        with (OUT / 'pip-freeze.txt').open('wb') as handle:
            subprocess.run([sys.executable, '-m', 'pip', 'freeze'], stdout=handle, check=True)
        helper = ROOT / 'runtime_stack.py'
        launch = json.loads((ROOT / 'launch-manifest.json').read_text())
        if digest(helper) != launch['files']['runtime_stack.py']['sha256']:
            raise RuntimeError('Runtime stack admission helper differs from frozen uploaded source')
        command('runtime-stack-preflight', [sys.executable, str(helper),
                '--cohort', str(ROOT / 'software-cohort.json'),
                '--wheel-lock', str(ROOT / 'runtime-wheel-lock.json'),
                '--out', str(OUT / 'runtime-stack.json')], timeout=180)
        stack = json.loads((OUT / 'runtime-stack.json').read_text())
        if (stack.get('status') != 'passed_runtime_stack_admission'
                or stack.get('helper_sha256') != digest(helper)
                or stack.get('helper_path') != os.path.realpath(helper)
                or stack.get('cohort_sha256') != digest(ROOT / 'software-cohort.json')):
            raise RuntimeError('Actual CUDA13 runtime admission did not bind the frozen cohort')
        # Run actual CUDA kernels and the real full-query BF16 graph before the 61.34 GB checkpoint download.
        gpu_tests = protocol['cuda_test_selectors']
        command('gpu-preflight', [sys.executable, '-m', 'pytest', *gpu_tests,
                                  '-q', '-o', 'addopts=', '--tb=short',
                                  '--basetemp=' + str(OUT / 'pytest-tmp'),
                                  '--junitxml=' + str(OUT / 'gpu-preflight.xml')], timeout=900)
        validate_cuda_xml(OUT / 'gpu-preflight.xml', protocol['cuda_expected_case_names'])
        command('profiler-preflight', [sys.executable, str(ROOT / 'cpu_overlap_probe.py'),
                 'profiler-preflight', '--out', str(OUT / 'profiler-preflight')], timeout=180)
        save(OUT / 'stage-status.json', {'status': 'running', 'phase': 'download', 'unix': time.time()})
        from huggingface_hub import HfApi, snapshot_download

        info = HfApi().model_info(MODEL, revision=REVISION, files_metadata=True)
        model_files = [item for item in info.siblings if item.rfilename.endswith('.safetensors')]
        if (info.sha != REVISION or len(model_files) != protocol['model']['weight_shards']
                or sum(item.size for item in model_files) != SOURCE_BYTES):
            raise RuntimeError('Public pinned checkpoint identity or size changed')
        for item in model_files:
            sha = item.lfs.get('sha256') if isinstance(item.lfs, dict) else getattr(item.lfs, 'sha256', None)
            if not isinstance(sha, str) or re.fullmatch('[0-9a-f]{64}', sha) is None:
                raise RuntimeError('Pinned checkpoint shard is missing its public LFS SHA256')
        pinned = {
            'repo_id': MODEL, 'revision': info.sha, 'weights_bytes': SOURCE_BYTES,
            'files': {item.rfilename: {'bytes': item.size, 'lfs': item.lfs}
                      for item in model_files},
        }
        # LFS metadata objects are dataclasses in some Hub releases.
        save(OUT / 'model-pinned.json', json.loads(json.dumps(pinned, default=lambda obj: vars(obj))))
        pre_download_disk_gate()
        import checkpoint_integrity
        helper_path = Path(os.path.realpath(checkpoint_integrity.__file__))
        expected_helper = ROOT / 'checkpoint_integrity.py'
        launch = json.loads((ROOT / 'launch-manifest.json').read_text())
        if (helper_path != Path(os.path.realpath(expected_helper))
                or digest(helper_path) != launch['files']['checkpoint_integrity.py']['sha256']):
            raise RuntimeError('Imported checkpoint helper is not the frozen uploaded source')
        normalized_pinned = json.loads(json.dumps(pinned, default=lambda obj: vars(obj)))
        pins = {name: {'bytes': row['bytes'], 'sha256': row['lfs']['sha256']}
                for name, row in normalized_pinned['files'].items()}
        if len(pins) != 13 or sum(row['bytes'] for row in pins.values()) != SOURCE_BYTES:
            raise RuntimeError('Exact official thirteen-shard input map changed')
        checkpoint_integrity.validate_official_pins(pins)
        force_proof = checkpoint_integrity.verify_hub_force_semantics(OUT / 'hub-force-control')
        save(OUT / 'hub-force-download-control.json', force_proof)
        download_started = time.perf_counter()
        weights = snapshot_download(MODEL, revision=REVISION, local_dir='/data/kanana30b',
                                    allow_patterns=['*.json', '*.safetensors'], max_workers=4)
        def fresh_pinned_shard(filename):
            from huggingface_hub import hf_hub_download
            if filename not in pins:
                raise ValueError('Only an exact pinned failing shard may be downloaded')
            return hf_hub_download(repo_id=MODEL, revision=REVISION, filename=filename,
                                   local_dir=weights, force_download=True, local_files_only=False)
        integrity = checkpoint_integrity.verify_checkpoint(
            Path(weights), pins, OUT / 'checkpoint-integrity.json', fresh_pinned_shard,
            repo_id=MODEL, revision=REVISION)
        if integrity['status'] != 'passed' or integrity['all_shards_verified'] is not True:
            raise RuntimeError('Exact official checkpoint verification did not pass')
        save(OUT / 'model-download.json', {'seconds': time.perf_counter() - download_started,
                                           'source_bytes': SOURCE_BYTES, 'revision': REVISION,
                 'checkpoint_integrity_receipt_sha256': digest(OUT / 'checkpoint-integrity.json')})
        pre_prepare_disk_gate(protocol)
        save(OUT / 'prepare-start.json', {'unix': time.time(),
             'all_thirteen_official_shards_verified': True,
             'checkpoint_integrity_status': integrity['status'],
             'helper_sha256': digest(helper_path),
             'checkpoint_integrity_receipt_sha256': digest(OUT / 'checkpoint-integrity.json')})
        command('prepare', [sys.executable, 'benchmarks/harness/two_read_cache.py', 'prepare',
                           '--weights', weights, '--shards', '/data/kanana30b-nf4-experts',
                           '--out', str(OUT / 'prepared'), '--host-cache-gib', '8',
                           '--device-cache-gib', '2', '--max-host-gib', '32',
                           '--seq-len', '512', '--batch-size', '1', '--accumulation', '2',
                           '--accuracy-updates', '2', '--warmup-updates', '2',
                           '--timed-updates', '6', '--rounds', '4',
                           '--host-cache-policy', 'static'], timeout=1200)
        prepared = json.loads((OUT / 'prepared/spec.json').read_text())
        prepared_binding = checkpoint_integrity.verify_prepared_fingerprint(prepared, integrity, pins)
        prepared_binding.update(checkpoint_integrity_receipt_sha256=digest(OUT / 'checkpoint-integrity.json'),
                                prepared_spec_sha256=digest(OUT / 'prepared/spec.json'),
                                helper_sha256=digest(helper_path))
        save(OUT / 'prepared-integrity.json', prepared_binding)
        retain_exact_metadata(Path(weights) / 'config.json', OUT / 'model-config.json',
                              prepared['model_fingerprint']['config.json'])
        retain_exact_metadata(Path('/data/kanana30b-nf4-experts/index.json'), OUT / 'cache-index.json',
                              prepared['store_fingerprint']['index.json'])
        spec_path = OUT / 'prepared/spec.json'
        arguments = [sys.executable, str(ROOT / 'transfer_probe.py'),
                     'run', '--spec', str(spec_path), '--out', str(OUT / 'transfer-probe'),
                     '--source-root', str(REPO), '--source-commit', manifest['source_commit'],
                     '--protocol', str(ROOT / 'protocol.json')]
        phase_receipt('transfer_probe', 'started', spec_path, arguments)
        command('transfer-probe', arguments, timeout=7200)
        validate_cpu_overlap_outputs(OUT / 'transfer-probe', spec_path, protocol)
        phase_receipt('transfer_probe', 'completed', spec_path)
        final = {'status': 'completed', 'phase': 'complete', 'unix': time.time(),
                 'purpose': 'preregistered_expert_transfer_study'}
    except BaseException as exc:
        final = {'status': 'failed', 'phase': 'failed', 'error': f'{type(exc).__name__}: {exc}',
                 'traceback': traceback.format_exc(), 'unix': time.time()}
        save(OUT / 'failure.json', final)
    finally:
        save(OUT / 'stage-status.json', {**final, 'archive_ready': False})
        export(final)
        save(OUT / 'stage-status.json', {**final, 'archive_ready': True})
    return 0 if final['status'] == 'completed' else 1



if __name__ == '__main__':
    raise SystemExit(main())
