"""Accuracy-first same-source sync/packed/lookahead qualification, without cloud API."""

from __future__ import annotations

import argparse
import functools
import hashlib
import importlib.util
import json
import math
import os
import random
import statistics
import subprocess
import sys
import time
import traceback
from pathlib import Path
from unittest.mock import patch

COMMIT = "f5670242e13b2b480a78e8fc1e3c797d6bb13800"
POLICIES = {"native": "sync", "packed": "packed", "prefetch": "prefetch"}
CONTRACT = {"purpose": "packed_nf4_expert_transfer_and_one_expert_lookahead",
            "policies": POLICIES, "accuracy_order": list(POLICIES),
            "accuracy_updates": 2, "accumulation": 2, "warmup_updates": 2,
            "timed_updates": 6, "exploration_order": ["packed", "native", "prefetch"],
            "selection": "fastest_distinct_mode_strictly_faster_than_new_native_median",
            "confirmation_pairs": 4, "confirmation_order": "AB_BA_AB_BA",
            "bootstrap_samples": 5000, "bootstrap_seed": 29,
            "practical_lower_bound_percent": 2., "rtol": .01, "atol": 1e-5,
            "finite": True, "three_decimal_losses": True,
            "all_features": {"two_read": True, "grouped_expert_routes": True,
                             "host_cache_bytes": 8 * 2**30, "device_cache_bytes": 2 * 2**30,
                             "host_cache_policy": "static"},
            "maximum_slot_bytes": 16 * 2**20, "slots": 2,
            "cuda_allocator_backend": "native", "cuda_launch_blocking": "0",
            "full_model_profile": False, "old_timing_denominator_allowed": False}


def require(value, message):
    if not value:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def digest(path):
    hashed = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 2**20), b""):
            hashed.update(block)
    return hashed.hexdigest()


def save(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + f".{os.getpid()}.tmp")
    with temporary.open("w", encoding="utf-8", newline="\n") as sink:
        json.dump(value, sink, indent=2, allow_nan=False)
        sink.write("\n")
        sink.flush()
        os.fsync(sink.fileno())
    os.replace(temporary, path)


def project(root):
    sys.path[:0] = [str(root / "src"), str(root)]
    from benchmarks.harness import expert_cache_dispatch_qualification as qualified

    return qualified, qualified.project(root, COMMIT)


def validate_contract(spec, protocol):
    require(protocol["source_commit"] == spec["git_head"] == COMMIT
            and protocol["execution_plan"] == CONTRACT, "Frozen transfer contract changed")
    from benchmarks.harness import expert_cache_dispatch_qualification as qualified

    qualified.validate_protocol(spec)


def validate_worker(raw, policy, spec, qualified):
    require(raw["status"] == "passed" and raw["arm"] == "two_read_cache",
            "Actual native worker did not pass")
    qualified.validate_native_routes(raw, "grouped")
    from benchmarks.harness import two_read_cache_worker as native_worker

    for phase in ("setup", "accuracy", "warmup", "timing", "lifecycle"):
        if phase in raw:
            native_worker._enforce_stage_limits(spec, raw[phase])
    for phase in ("accuracy", "warmup", "timing"):
        if phase not in raw:
            continue
        qualified.cache_delta(raw, phase, cached=True)
        before, after = (raw[phase][key]["expert_cache"]
                         for key in ("runtime_before", "runtime_after"))
        if policy == "native":
            require("transfer" not in before and "transfer" not in after,
                    "Native arm unexpectedly enabled transfers")
        else:
            require(before["transfer"]["mode"] == after["transfer"]["mode"] == POLICIES[policy],
                    "Actual transfer mode differs")
            count = after["transfer"]["h2d_copies"] - before["transfer"]["h2d_copies"]
            require(count == after["materializations"] - before["materializations"] > 0,
                    "Transfer count is not exactly one per decoded expert")
            require(all(0 <= after["transfer"][key] <= 2 * 16 * 2**20
                        for key in ("pinned_host_bytes", "device_staging_bytes")),
                    "Additional transfer staging exceeded its bound")
    # Reuse the already-qualified native RAM/swap/lifecycle boundaries, not CPU timing.
    helper_path = Path(__file__).with_name("cpu_overlap_probe.py")
    launch = read(Path(__file__).with_name("launch-manifest.json"))
    require(digest(helper_path) == launch["files"][helper_path.name]["sha256"],
            "Resource helper differs from the frozen file")
    module_spec = importlib.util.spec_from_file_location("transfer_resource_gate", helper_path)
    helper = importlib.util.module_from_spec(module_spec)
    module_spec.loader.exec_module(helper)
    require(os.path.realpath(helper.__file__) == os.path.realpath(helper_path),
            "Imported a foreign resource helper")
    helper.validate_resource_boundary(raw, spec)


def worker_main(args):
    import torch

    qualified, (_native, worker, _common, module, identity) = project(args.source_root)
    spec, protocol = read(args.spec), read(args.protocol)
    validate_contract(spec, protocol)
    require(os.environ.get("CUDA_LAUNCH_BLOCKING") == "0"
            and torch.cuda.memory.get_allocator_backend() == "native",
            "Fresh cohort requires native allocator and asynchronous CUDA launches")
    args.out.mkdir(parents=True, exist_ok=True)
    envelope = {"status": "running", "policy": args.policy, "phase": args.phase,
                "pid": os.getpid(), "source": identity, "probe_sha256": digest(__file__),
                "spec_sha256": digest(args.spec), "protocol_sha256": digest(args.protocol),
                "mode": POLICIES[args.policy], "configure_calls": 0}
    envelope.update(cuda_allocator_backend=torch.cuda.memory.get_allocator_backend(),
                    cuda_launch_blocking=os.environ["CUDA_LAUNCH_BLOCKING"])
    original = worker._build

    @functools.wraps(original)
    def build(*parts, **kwargs):
        model, runtime, plan = original(*parts, **kwargs)
        try:
            runtime.expert_fetcher.configure_transfer(POLICIES[args.policy])
            require(runtime.expert_fetcher.transfer_mode == POLICIES[args.policy],
                    "Actual fetcher refused the requested mode")
            envelope["configure_calls"] += 1
            return model, runtime, plan
        except BaseException:
            runtime.close()
            raise

    try:
        with (qualified.dispatch(module, "grouped") as dispatch,
              patch.object(worker, "_build", build)):
            status = worker.run_worker(args.spec, "two_read_cache", args.phase, args.out)
        require(status == 0, "Native worker failed")
        qualified.validate_dispatch_evidence(dispatch, "grouped")
        raw = read(args.out / "result.json")
        validate_worker(raw, args.policy, spec, qualified)
        require(envelope["configure_calls"] == 1, "Wrong actual constructor count")
        envelope.update(status="passed", raw_sha256=digest(args.out / "result.json"),
                        dispatch=dispatch)
    except BaseException as error:
        envelope.update(status="failed", error=f"{type(error).__name__}: {error}",
                        traceback=traceback.format_exc())
    save(args.out / "transfer-envelope.json", envelope)
    return 0 if envelope["status"] == "passed" else 1


def launch(args, policy, phase, out):
    out.mkdir(parents=True, exist_ok=False)
    command = [sys.executable, str(Path(__file__).absolute()), "worker", "--policy", policy,
               "--phase", phase, "--spec", str(args.spec), "--out", str(out),
               "--source-root", str(args.source_root), "--source-commit", COMMIT,
               "--protocol", str(args.protocol)]
    started = time.perf_counter()
    with (out / "worker.log").open("wb") as log:
        process = subprocess.run(command, cwd=args.source_root, stdout=log,
                                 stderr=subprocess.STDOUT,
                                 timeout=read(args.spec)["timeout_seconds"])
    require(process.returncode == 0, f"{policy}/{phase} failed; originals retained")
    proof, raw = read(out / "transfer-envelope.json"), read(out / "result.json")
    require(proof["status"] == raw["status"] == "passed"
            and proof["policy"] == policy and proof["phase"] == phase
            and proof["probe_sha256"] == digest(__file__)
            and proof["spec_sha256"] == raw["spec_sha256"] == digest(args.spec)
            and proof["protocol_sha256"] == digest(args.protocol)
            and proof["raw_sha256"] == digest(out / "result.json"), "Worker binding failed")
    result = {"policy": policy, "phase": phase, "result": raw, "envelope": proof,
              "directory": out.relative_to(args.out).as_posix(),
              "fresh_process_wall_seconds": time.perf_counter() - started}
    save(out / "controller-result.json", result)
    return result


def select_candidate(rows):
    require([row["policy"] for row in rows] == CONTRACT["exploration_order"],
            "Exploratory schedule changed")
    medians = {row["policy"]: statistics.median(row["worker"]["result"]["timing"][
        "update_seconds"]) for row in rows}
    candidates = [name for name in ("packed", "prefetch") if medians[name] < medians["native"]]
    return {"candidate": min(candidates, key=medians.get) if candidates else None,
            "medians_seconds": medians, "exploratory_only": True}


def confirm(rows, candidate, qualified, common):
    pair = ("native", candidate)
    orders = (pair, tuple(reversed(pair))) * 2
    require(len(rows) == 8, "All four new confirmation pairs are required")
    grouped, pids = {}, set()
    for index, row in enumerate(rows):
        number, position = divmod(index, 2)
        require(row["round"] == number and row["position"] == position
                and row["policy"] == orders[number][position], "Confirmation order changed")
        worker = row["worker"]
        require(worker["result"]["pid"] not in pids, "Timing process was reused")
        pids.add(worker["result"]["pid"])
        grouped.setdefault(number, {})[row["policy"]] = worker["result"]
    ratios = []
    for left in grouped.values():
        reference, actual = left["native"], left[candidate]
        for phase in ("warmup", "timing"):
            require(qualified.loss_gate(reference[phase]["losses"], actual[phase]["losses"],
                                        common)["passed"], "Recorded confirmation losses differ")
        ratios.append(math.log(statistics.median(actual["timing"]["update_seconds"]) /
                               statistics.median(reference["timing"]["update_seconds"])))
    rng = random.Random(29)
    draws = sorted(100 * (1 - math.exp(statistics.mean(rng.choices(ratios, k=4))))
                   for _ in range(5000))
    return {"candidate": candidate, "paired_rounds": 4,
            "step_time_reduction_percent": 100 * (1 - math.exp(statistics.mean(ratios))),
            "throughput_increase_percent": 100 * (math.exp(-statistics.mean(ratios)) - 1),
            "paired_bootstrap_95_percent": [draws[124], draws[4874]],
            "passes_practical_2_percent_gate": draws[124] >= 2.,
            "selection_samples_excluded": True}


def run(args):
    import torch

    qualified, (native, _worker, common, _module, identity) = project(args.source_root)
    spec, protocol = read(args.spec), read(args.protocol)
    validate_contract(spec, protocol)
    args.out.mkdir(parents=True, exist_ok=False)
    path = args.out / "run.json"
    result = {"status": "running", "identity": identity, "probe_sha256": digest(__file__),
              "spec_sha256": digest(args.spec), "protocol_sha256": digest(args.protocol),
              "execution_plan": CONTRACT, "accuracy_passed": False,
              "accuracy": {}, "exploration": [], "confirmation": []}
    save(path, result)
    try:
        native.verify_spec(spec, content=True)
        inputs = torch.load(spec["training_data_path"], map_location="cpu", weights_only=True)
        reference = None
        for policy in POLICIES:
            row = launch(args, policy, "accuracy", args.out / "accuracy" / policy)
            capture_path = args.out / row["directory"] / "capture.pt"
            capture = torch.load(capture_path, map_location="cpu", weights_only=True)
            controls = qualified.full_capture_controls(capture, inputs, common)
            if reference is None:
                reference = capture
            comparison = common.compare_captures(reference, capture)
            require(comparison["passed"], f"Original numerical gates failed: {policy}")
            require(digest(capture_path) == row["result"]["accuracy"]["capture_sha256"],
                    "Complete capture SHA differs")
            result["accuracy"][policy] = {"worker": row, "controls": controls,
                                           "versus_native": comparison}
            del capture
            save(path, result)
        del reference
        result["accuracy_passed"] = True
        save(path, result)
        for policy in CONTRACT["exploration_order"]:
            row = launch(args, policy, "timing", args.out / "exploration" / policy)
            result["exploration"].append({"policy": policy, "worker": row})
            save(path, result)
        result["selection"] = select_candidate(result["exploration"])
        candidate = result["selection"]["candidate"]
        save(path, result)
        if candidate is not None:
            pair = ("native", candidate)
            for number, order in enumerate((pair, tuple(reversed(pair))) * 2):
                for position, policy in enumerate(order):
                    row = launch(args, policy, "timing", args.out / "confirmation" /
                                 f"round-{number:02d}" / policy)
                    result["confirmation"].append({"round": number, "position": position,
                                                    "policy": policy, "worker": row})
                    save(path, result)
            result["confirmation_summary"] = confirm(
                result["confirmation"], candidate, qualified, common)
        native.verify_spec(spec, content=True)
        result["status"] = "completed"
        save(path, result)
        validate_result(args.out, spec, protocol)
    except BaseException as error:
        result.update(status="failed", error=f"{type(error).__name__}: {error}",
                      traceback=traceback.format_exc())
        save(path, result)
        return 1
    return 0


def validate_result(directory, spec, protocol):
    validate_contract(spec, protocol)
    result = read(Path(directory) / "run.json")
    require(result["status"] == "completed" and result["accuracy_passed"] is True
            and result["probe_sha256"] == digest(__file__)
            and result["execution_plan"] == CONTRACT
            and set(result["accuracy"]) == set(POLICIES), "Incomplete transfer experiment")
    from benchmarks.harness import expert_cache_dispatch_qualification as qualified
    from benchmarks.harness import two_read_cache_common as common

    rows = [cell["worker"] for cell in result["accuracy"].values()]
    rows += [cell["worker"] for cell in result["exploration"] + result["confirmation"]]
    pids, environments = set(), []
    for row in rows:
        policy, raw, envelope = row["policy"], row["result"], row["envelope"]
        require(raw["pid"] not in pids, "Fresh worker PID reused")
        pids.add(raw["pid"])
        qualified.validate_dispatch_evidence(envelope["dispatch"], "grouped")
        validate_worker(raw, policy, spec, qualified)
        environments.append(raw["environment"])
        original = Path(directory) / row["directory"] / "result.json"
        require(digest(original) == envelope["raw_sha256"] and read(original) == raw,
                "Retained actual worker changed")
    require(all(value == environments[0] for value in environments), "Worker environment changed")
    for policy, cell in result["accuracy"].items():
        require(cell["controls"]["passed"] and cell["versus_native"]["passed"],
                f"Failed full numerical capture: {policy}")
    require(result["selection"] == select_candidate(result["exploration"]), "Selection changed")
    candidate = result["selection"]["candidate"]
    if candidate is None:
        require(not result["confirmation"] and "confirmation_summary" not in result,
                "An unselected candidate was confirmed")
    else:
        require(result["confirmation_summary"] == confirm(
            result["confirmation"], candidate, qualified, common), "Confirmation changed")
    return {"status": "passed_structural_probe_validation", "workers": len(rows),
            "source_commit": COMMIT, "accuracy_policies": list(POLICIES)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("worker", "run"))
    parser.add_argument("--policy", choices=tuple(POLICIES), default="native")
    parser.add_argument("--phase", choices=("accuracy", "timing"), default="accuracy")
    for name in ("spec", "out", "source-root", "protocol"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--source-commit", required=True)
    args = parser.parse_args()
    require(args.source_commit == COMMIT, "Exact frozen candidate commit required")
    return worker_main(args) if args.command == "worker" else run(args)


if __name__ == "__main__":
    raise SystemExit(main())
