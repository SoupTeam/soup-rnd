"""Package only audited transfer results for the existing PR, with no Git actions."""

import hashlib
import importlib.util
import json
import shutil
import statistics
import zipfile
from pathlib import Path

from rich.console import Console

PREP = Path(__file__).parent
STAGE = PREP.parent / "expert-prefetch-gpu-20261028-a"
SOURCE = "f5670242e13b2b480a78e8fc1e3c797d6bb13800"
REPORT = Path(r"C:\Users\esenb\.codex\worktrees\stream-memory-auto-20261023\soup-rnd-d2")
REPORT = REPORT / "benchmarks/expert-prefetch-20261028"


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n",
                    encoding="utf-8", newline="\n")


def main():
    audit_path = PREP / "independent-audit.json"
    audit = read(audit_path)
    assert audit["status"] == "passed_standalone_transfer_audit"
    assert audit["source_commit"] == SOURCE
    assert audit["audit_script_sha256"] == sha(STAGE / "audit_transfer.py")
    assert audit["cleanup"]["verified_absent"] is True
    assert not REPORT.exists()
    library_path = PREP.parent / "expert-cpu-overlap-20261028/package_cpu_evidence.py"
    spec = importlib.util.spec_from_file_location("packet_library", library_path)
    library = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(library)
    library.SOURCE, library.PREP = SOURCE, PREP
    library.expected_auditor = lambda _audit: "audit_transfer.py"

    def verify_stage(stage, path):
        result = read(path)
        assert result == audit
        for name, field in (("archive-manifest.json", "archive_manifest_sha256"),
                            ("bundle-verified.json", "bundle_verified_sha256"),
                            ("launch-manifest.json", "launch_manifest_sha256")):
            assert sha(stage / name) == result[field]
        assert sha(PREP / "audit_transfer.py") == result["audit_script_sha256"]
        archive = read(stage / "archive-manifest.json")
        assert sha(stage / "result.lossless.tar") == archive["sha256"]
        for name, row in archive["files"].items():
            path = library.contained(stage / "retained", name)
            assert path.stat().st_size == row["bytes"] and library.sha(path) == row["sha256"]
        return dict(result, stage_id=read(stage / "protocol.json")["stage_id"]), archive

    library.verify_stage = verify_stage
    # Exact values stay in memory and are never printed or copied to the packet.
    secret_paths = (Path.home() / ".config/vastai/vast_api_key", STAGE / "ssh-key")
    secrets = tuple(value for path in secret_paths for value in
                    (path.read_bytes(), path.read_bytes().strip()))
    packet = library.package(STAGE, audit_path, PREP / "publication", secrets)
    REPORT.mkdir(parents=True)
    for name, source in (("evidence.zip", PREP / "publication/evidence.zip"),
                         ("prototype.patch.zip", PREP / "prototype.patch"),
                         ("audit_transfer.py.txt", STAGE / "audit_transfer.py"),
                         ("archive_audit.py.txt", STAGE / "archive_audit.py"),
                         ("audit_infrastructure.py.txt", STAGE / "audit_infrastructure.py")):
        if source.suffix == ".patch":
            assert sha(source) == "39de52e66859dd0021ab244819acabb74791e20eda45391e5315add5987d2eb0"
            info = zipfile.ZipInfo("prototype.patch", date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            with zipfile.ZipFile(REPORT / name, "w") as archive:
                archive.writestr(info, source.read_bytes(), compresslevel=9)
            with zipfile.ZipFile(REPORT / name) as archive:
                assert archive.read("prototype.patch") == source.read_bytes()
        elif source.suffix == ".py":
            # Readable previews use LF; the packet preserves the frozen executable bytes.
            (REPORT / name).write_bytes(source.read_bytes().replace(b"\r\n", b"\n"))
            assert (REPORT / name).read_bytes() == source.read_bytes().replace(b"\r\n", b"\n")
        else:
            shutil.copyfile(source, REPORT / name)
            assert sha(source) == sha(REPORT / name)
    write(REPORT / "summary.json", audit)
    run_path = STAGE / "retained/results/transfer-probe/run.json"
    assert sha(run_path) == audit["qualification_run_sha256"]
    run = read(run_path)
    confirmation_absolute = {}
    for policy in ("native", audit["selection"]):
        if policy is None:
            continue
        cells = [cell["worker"] for cell in run["confirmation"] if cell["policy"] == policy]
        if not cells:
            continue
        confirmation_absolute[policy] = {
            "median_of_worker_step_medians_seconds": statistics.median(
                statistics.median(cell["result"]["timing"]["update_seconds"]) for cell in cells),
            "all_timed_seconds": [cell["result"]["timing"]["update_seconds"] for cell in cells],
            "median_whole_entry_seconds": statistics.median(
                cell["fresh_process_wall_seconds"] for cell in cells),
            "median_setup_seconds": statistics.median(
                cell["result"]["setup"]["seconds"] for cell in cells),
            "max_allocated_bytes": max(cell["result"]["timing"]["cuda"]["peak_allocated_bytes"]
                                       for cell in cells),
            "max_reserved_bytes": max(cell["result"]["timing"]["cuda"]["peak_reserved_bytes"]
                                      for cell in cells),
            "max_sampled_rss_bytes": max(
                cell["result"]["timing"]["resources"]["sampled_peak_rss_bytes"] for cell in cells)}
    write(REPORT / "tables.json", {"source_commit": SOURCE,
        "qualification_run_sha256": sha(run_path),
        "exploration": audit["exploration"], "confirmation_absolute": confirmation_absolute,
        "confirmation_paired": audit["confirmation"]})
    rows = audit["exploration"]
    table = []
    for policy in ("native", "packed", "prefetch"):
        row = rows[policy]
        table.append(f"| {policy} | {row['median_step_seconds']:.4f} | "
                     f"{row['whole_entry_seconds']:.3f} | "
                     f"{row['cuda']['peak_allocated_bytes'] / 2**30:.4f} | "
                     f"{row['cuda']['peak_reserved_bytes'] / 2**30:.4f} | "
                     f"{row['sampled_peak_rss_bytes'] / 2**30:.4f} |")
    confirmation = audit["confirmation"]
    if confirmation:
        interval = confirmation["paired_bootstrap_95_percent"]
        conclusion = (f"Selected **{confirmation['candidate']}**: four NEW balanced AB/BA "
                      f"pairs give **{confirmation['step_time_reduction_percent']:.3f}%** "
                      f"paired step-time reduction, bootstrap 95% interval "
                      f"**[{interval[0]:.3f}%, {interval[1]:.3f}%]**, "
                      f"**{confirmation['throughput_increase_percent']:.3f}%** throughput "
                      "increase. Selection samples are excluded. ")
        conclusion += ("The unchanged >=2% lower-confidence-bound gate passes." if
                       confirmation["passes_practical_2_percent_gate"] else
                       "The unchanged >=2% lower-confidence-bound gate does NOT pass.")
    else:
        conclusion = ("Neither distinct mode beat the fresh native exploratory median. "
                      "No candidate entered confirmation; no confidence interval is invented.")
    confirmed_table = ""
    if confirmation_absolute:
        confirmed_rows = []
        for policy, cell in confirmation_absolute.items():
            confirmed_rows.append(f"| {policy} | "
                f"{cell['median_of_worker_step_medians_seconds']:.4f} | "
                f"{cell['median_whole_entry_seconds']:.3f} | "
                f"{cell['max_allocated_bytes'] / 2**30:.4f} | "
                f"{cell['max_reserved_bytes'] / 2**30:.4f} | "
                f"{cell['max_sampled_rss_bytes'] / 2**30:.4f} |")
        confirmed_table = ("\nHeld-out confirmation only (four workers per mode): step and entry "
            "are medians of worker summaries; memory is the maximum across these workers.\n\n"
            "| Mode | Step, s | Eight-update entry, s | Allocated GiB | Reserved GiB | RSS GiB |\n"
            "| --- | ---: | ---: | ---: | ---: | ---: |\n" + "\n".join(confirmed_rows) + "\n")
    accuracy = audit["accuracy"]
    all_bitwise = all(value.get("bitwise") is True for value in accuracy.values())
    numerical = "bitwise" if all_bitwise else "under the original numerical gates"
    retention, budget = audit["retention"], audit["budget"]
    readme = f'''# Packed NF4 expert transfer and one-expert lookahead

**Verdict: {audit["speed_verdict"]}.** {conclusion}

## What changed

The opt-in prototype packs an expert's NF4 weights/sidecars into one aligned
pinned byte arena and one H2D copy. `prefetch` also stages the next routed expert
on a separate CUDA stream before the current expert's MLP. Both modes use the
same dequantization/math. Two bounded slots have separate copy-ready and
post-dequantization consumer fences; dense decoded weights own their storage.
Initial GPU allocation happens on the copy stream. No background CPU reader,
new CPU thread policy, CLI/config/default change or automatic placement.

Companion source [{SOURCE[:8]}](https://github.com/SoupTeam/soup-rnd/commit/{SOURCE})
and [portable patch ZIP](prototype.patch.zip) against immutable `43cf0b34`. The production
PR diff is separate; this report does not declare the prototype shipped.

## Same-cohort protocol

Kanana-2-30B-A3B, 30.67B total parameters, revision
`0d31365acf656e5f9a593cacc4913e9c0d36cb1c`, frozen NF4 base/BF16 compute,
FP32 attention LoRA rank4/alpha8, context512, batch1, accumulation2.
Physical RTX4060Ti 8188MiB, native RAM <=32GiB, workload swap disabled.
Torch2.10.0+cu130 / CUDA13 / Triton3.6.0 / bitsandbytes0.50.2, hash-locked
runtime wheels. Native allocator and asynchronous launches are matched.
All three arms already use grouped routes, two-read and static 8GiB RAM/2GiB GPU
expert-weight cache ceilings, with identical inputs/adapters/cache policy.
`native` is the original synchronous path on THIS source/runtime. Older timing
cohorts and ordinary three-read streaming are not denominators.

## Speed and memory

Exploration: fixed packed/native/prefetch order, one fresh process per arm,
two warmup and six measured accumulated AdamW updates, no discarded updates.
The table is exploratory, not a confirmed ranking. Confirmation, when selected,
uses four NEW fresh-process balanced pairs, 5000 paired bootstrap draws/seed29.

| Mode | Median step, s | Eight-update entry, s | Allocated VRAM, GiB | Reserved VRAM, GiB | RSS, GiB |
| --- | ---: | ---: | ---: | ---: | ---: |
{chr(10).join(table)}
{confirmed_table}

Entry includes model/cache setup, warmup, timing and worker startup/validation.
Common checkpoint download/NF4 preparation is separate. RSS is sampled every50ms,
excludes filesystem/kernel charges and is not total system RAM. Added pinned/GPU
staging has two <=16MiB slots per tier and is separately recorded in raw counters.
All actual timing arrays, setup costs, cache/transfer counters and confirmation
results are in [summary.json](summary.json) and [the evidence packet](evidence.zip).
No whole-training speed projection or claim of optimal memory allocation.

## Accuracy first

All ten actual small CUDA controls passed without skips before checkpoint
download, including delayed consumers, ring reuse, initial allocation ordering,
negative missing-fence controls and complete tiny NF4/BF16 optimizer trajectories.
Then all three separate full real-model 2-AdamW-update/4-microbatch captures
matched **{numerical}** before any timing. All288 trainable LoRA tensors/144
attention projections receive gradients and actually update. Original reference-first
rtol=.01/atol=1e-5, finite and three-decimal loss gates were not changed.
The standalone audit reloaded complete captures and replayed the comparisons.

Scope: deterministic algorithms, TF32 off, eval mode with differentiable LoRA
updates and dropout disabled. This is same-NF4 numerical/resource qualification,
not downstream quality/convergence or NF4-vs-BF16 equivalence. Full final timed
tensors and unrecorded first-micro scalar losses retain NO VERDICT. No full-model
profile was taken in this qualification; the previous narrow transfer profile
motivates the hypothesis but does not prove a full-step bottleneck.

## Verification, retention and cleanup

149 scoped CPU source controls passed (10 GPU cases deselected locally), 14 private
runner controls and 81 operator controls passed. The later GPU-only allocation
fix was included in all ten executed GPU controls. Ruff and applicable source
pre-commit passed. Full-suite/hosted-CI success is not inferred.
The pre-data frozen standalone auditor is [audit_transfer.py](audit_transfer.py.txt);
it verifies all original archives/chunks/files, source/input/worker identities,
resource boundaries, full numerical captures, raw timing selection/confirmation,
budget and cleanup. No reported pass flag alone is accepted as numerical proof.
These review snapshots normalize line endings only; exact runnable `.py` originals are in the
packet's `operator/` entries (resolve `aliases.json` when extracting).

All **{retention["verified_files"]} originals / {retention["original_bytes"]:,} bytes**
were retained and hash-verified from the **{retention["archive_bytes"]:,}-byte**
lossless archive. Compact public evidence restores exact bytes using aliases;
large tensors/model/source archives are explicitly hash-indexed as local-only.
The full61GB checkpoint is not retained; its official expected/observed SHA receipts
are. Physical NVMe backing is unverified. Numerical/archive audit and secret scans
passed before publication. [Evidence manifest](evidence-manifest.json).

Owned instance58130492 and persistent volume58130491 were deleted and freshly
verified absent. Shared-account colleague resources were untouched.
Conservative new-task cost **${budget["new_stage_cost_usd"]:.6f} / $5**, remainder
**${budget["new_allowance_remaining_usd"]:.6f}**; these are ledger estimates, not
invoices. The older unused $4.909114 remains a separate allowance, not spent here.
'''
    (REPORT / "README.md").write_text(readme, encoding="utf-8", newline="\n")
    # Publication hashes describe exact bytes, including Windows line endings.
    (REPORT / ".gitattributes").write_text("* -text\n", encoding="utf-8", newline="\n")
    write(REPORT / "evidence-manifest.json", {
        "schema_version": 1, "source_commit": SOURCE, "packet": packet,
        "launch_manifest_sha256": audit["launch_manifest_sha256"],
        "report_files": {path.name: {"bytes": path.stat().st_size, "sha256": sha(path)}
                         for path in REPORT.iterdir() if path.is_file()}})
    Console().print({"report": str(REPORT), "verdict": audit["speed_verdict"],
                     "packet_bytes": packet["bytes"], "allocation": False})


if __name__ == "__main__":
    main()
