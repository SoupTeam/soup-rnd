"""Refresh an unsealed, unallocated stage after local source correctness fixes."""

import hashlib
import io
import json
import os
import subprocess
import tarfile
from pathlib import Path

from rich.console import Console

PREP = Path(__file__).parent
STAGE = PREP.parent / "expert-prefetch-gpu-20261028-a"
SOURCE = Path(r"C:\Users\esenb\.codex\worktrees\expert-prefetch-20261028\soup-rnd-d2")
COMMIT = "f5670242e13b2b480a78e8fc1e3c797d6bb13800"


def main():
    assert not any((STAGE / name).exists() for name in
                   ("launch-manifest.json", "lease-greenlight.json", "vast-rental.json"))
    assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=SOURCE, text=True).strip() == COMMIT
    assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=SOURCE, text=True).strip()
    old = json.loads((STAGE / "source-manifest.json").read_text())
    protocol = json.loads((STAGE / "protocol.json").read_text())
    backup = PREP / "unpaid-source-revision-before-alignment.json"
    if not backup.exists():
        backup.write_text(json.dumps({"source": old, "protocol": protocol}, indent=2) + "\n")
    names = set(old["files"])
    names.update(subprocess.check_output(["git", "diff", "--name-only", "43cf0b34", COMMIT],
                                        cwd=SOURCE, text=True).splitlines())
    files, temporary = {}, STAGE / "source.tar.gz.incoming"
    with tarfile.open(temporary, "w:gz", compresslevel=6) as archive:
        for name in sorted(names):
            path = SOURCE / name
            assert os.path.commonpath((os.path.realpath(SOURCE), os.path.realpath(path))) == str(SOURCE)
            assert path.is_file() and not path.is_symlink()
            raw = path.read_bytes()
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(raw), 0o644, 0
            archive.addfile(info, io.BytesIO(raw))
            files[name] = {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
    with temporary.open("r+b") as handle:
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, STAGE / "source.tar.gz")
    (STAGE / "source-manifest.json").write_text(json.dumps({"source_commit": COMMIT,
        "archive_sha256": hashlib.sha256((STAGE / "source.tar.gz").read_bytes()).hexdigest(),
        "files": files}, indent=2) + "\n")
    prior = protocol["source_commit"]
    protocol["source_commit"] = COMMIT
    (STAGE / "protocol.json").write_text(json.dumps(protocol, indent=2) + "\n")
    safety = STAGE / "launch_safety.py"
    safety.write_text(safety.read_text().replace(prior, COMMIT), encoding="utf-8")
    (STAGE / "transfer_probe.py").write_bytes((PREP / "transfer_probe.py").read_bytes())
    Console().print({"unpaid_source_refreshed": COMMIT, "files": len(files),
                     "archive_bytes": (STAGE / "source.tar.gz").stat().st_size})


if __name__ == "__main__":
    main()
