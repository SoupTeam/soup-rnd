"""Read-only full-cost eligibility and exact historical-owned absence."""

import json
import sys
import time
from pathlib import Path

PREP = Path(__file__).parent
BASE = PREP.parent
STAGE = BASE / "expert-prefetch-gpu-20261028-a"
sys.path[:0] = [str(STAGE), str(BASE / "kanana-30b-final-gpu-20261026-f15/.deps")]

import cloud  # noqa: E402
from rich.console import Console  # noqa: E402


def main():
    assert not (STAGE / "vast-rental.json").exists()
    offers = cloud.api("/api/v0/bundles/", "POST", dict(cloud.QUERY, limit=100))["offers"]
    candidates = []
    for offer in sorted(offers, key=lambda item: (item["machine_id"] != 122165,
                                                 float(item["dph_total"]))):
        if offer["machine_id"] == 58086:
            continue  # known prior profiler/download failure host
        try:
            cloud.validate_full_host(offer)
            volumes = cloud.volume_offers(offer["machine_id"])
            for volume in volumes:
                if float(volume["disk_space"]) < cloud.VOLUME_GB:
                    continue
                quote = cloud.quote(offer, seconds=9000, volume_offer=volume)
                if quote["total_stage_admission_usd"] <= 5.:
                    candidates.append({"offer": offer, "volume": volume, "quote": quote})
        except (ValueError, KeyError):
            continue
        if candidates:
            break
    assert candidates, "No eligible complete-cost physical8GB offer within new USD5; no rental"
    chosen = min(candidates, key=lambda item: item["quote"]["total_stage_admission_usd"])
    credit = float(cloud.api("/api/v0/users/current/")["credit"])
    assert credit >= chosen["quote"]["total_stage_admission_usd"]
    history = []
    for pattern in ("kanana-30b*-gpu-20261026-f*/vast-rental.json",
                    "expert-cpu-overlap-gpu-20261028-*/vast-rental.json"):
        for path in BASE.glob(pattern):
            old = json.loads(path.read_text())
            history.append({name: old.get(name) for name in
                            ("stage_id", "label", "instance_id", "volume_id")})
    instances, volumes = cloud.rows(), cloud.volume_rows()
    old_instances = {cloud.resource_id(row["instance_id"]) for row in history
                     if row["instance_id"] is not None}
    old_volumes = {cloud.resource_id(row["volume_id"]) for row in history
                   if row["volume_id"] is not None}
    assert not any(cloud.resource_id(row["id"]) in old_instances for row in instances)
    assert not any(cloud.resource_id(row["id"]) in old_volumes for row in volumes)
    assert not any(row.get("label") == cloud.LABEL for row in instances)
    cloud.save("historical-owned.json", {"pairs": history})
    cloud.save("fresh-quote.json", {"unix": time.time(), "read_only": True, **chosen,
               "account_credit_usd": credit, "new_task_budget_usd": 5.,
               "all_prior_owned_absent": True, "prior_owned_pairs": len(history),
               "unrelated_instance_ids": [row["id"] for row in instances],
               "unrelated_volume_ids": [row["id"] for row in volumes],
               "rental_started": False})
    Console().print({"offer_id": chosen["offer"]["id"],
                     "machine_id": chosen["offer"]["machine_id"],
                     "gpu": chosen["offer"]["gpu_name"],
                     "volume_ask_id": chosen["volume"]["id"],
                     "full_quote_usd": chosen["quote"]["total_stage_admission_usd"],
                     "credit_sufficient": True, "prior_owned_pairs_absent": len(history),
                     "rental_started": False})


if __name__ == "__main__":
    main()
