"""Offline isolated operator preparation; never rents or modifies old evidence."""

from __future__ import annotations

import hashlib
import importlib.util
import io
import json
import os
import pprint
import subprocess
import tarfile
from pathlib import Path

from rich.console import Console

PREP = Path(__file__).parent
BASE = PREP.parent
OLD = BASE / "expert-cpu-overlap-gpu-20261028-b"
NEW = BASE / "expert-prefetch-gpu-20261028-a"
SOURCE = Path(r"C:\Users\esenb\.codex\worktrees\expert-prefetch-20261028\soup-rnd-d2")
COMMIT = "f5670242e13b2b480a78e8fc1e3c797d6bb13800"
STUDY = "soup-expert-prefetch-20261028-a"


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def replace_function(text, name, replacement):
    start = text.index("def " + name + "(")
    following = text.find("\ndef ", start + 5)
    end = len(text) if following < 0 else following
    return text[:start] + replacement.rstrip() + "\n\n" + text[end:]


def main():
    assert json.loads((OLD / "independent-vast-absence.json").read_text())["verified_absent"]
    assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=SOURCE, text=True).strip() == COMMIT
    assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=SOURCE, text=True).strip()
    NEW.mkdir(exist_ok=False)
    core = ("cloud.py", "controller.py", "transport.py", "api_transport.py", "api_rate_limit.py",
            "diagnostics.py", "launch.py", "range_transport.py", "remote_guard.py", "remote_run.py",
            "preflight_remote.py", "lossless_results.py", "checkpoint_integrity.py", "runtime_stack.py",
            "setup.sh", "constraints.txt", "software-cohort.json", "runtime-wheel-lock.json",
            "runtime-wheel-requirements.txt", "cuda13-stack-metadata.json",
            "cuda13-transitive-metadata.json", "profile_timeline.py", "cpu_overlap_probe.py",
            "storage-capacity-plan.json", "upload-probe.bin", "test_controller.py",
            "test_native_transport.py", "test_diagnostics_concurrency.py", "test_f13_cross_process.py",
            "test_runtime_stack.py", "test_setup_bytes.py")
    for name in core:
        raw = (OLD / name).read_bytes()
        if name.endswith(".py") and name not in {"cpu_overlap_probe.py", "profile_timeline.py"}:
            raw = raw.decode().replace("soup-expert-cpu-overlap-20261028-b", STUDY).replace(
                "soup_expert_cpu_overlap_20261028_b", "soup_expert_prefetch_20261028_a").encode()
        (NEW / name).write_bytes(raw)
    (NEW / "transfer_probe.py").write_bytes((PREP / "transfer_probe.py").read_bytes())
    (NEW / "source-controls.xml").write_bytes((PREP / "source-controls.xml").read_bytes())
    old_manifest = json.loads((OLD / "source-manifest.json").read_text())
    names = set(old_manifest["files"])
    names.update(subprocess.check_output(["git", "diff", "--name-only", "43cf0b34", COMMIT],
                                        cwd=SOURCE, text=True).splitlines())
    files = {}
    with tarfile.open(NEW / "source.tar.gz", "w:gz", compresslevel=6) as archive:
        for name in sorted(names):
            path = SOURCE / name
            assert os.path.commonpath((os.path.realpath(SOURCE), os.path.realpath(path))) == str(SOURCE)
            assert path.is_file() and not path.is_symlink()
            raw = path.read_bytes()
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(raw), 0o644, 0
            archive.addfile(info, io.BytesIO(raw))
            files[name] = {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
    write(NEW / "source-manifest.json", {"source_commit": COMMIT, "files": files,
          "archive_sha256": hashlib.sha256((NEW / "source.tar.gz").read_bytes()).hexdigest()})
    module_spec = importlib.util.spec_from_file_location("new_transfer", NEW / "transfer_probe.py")
    module = importlib.util.module_from_spec(module_spec)
    module_spec.loader.exec_module(module)
    protocol = json.loads((OLD / "protocol.json").read_text())
    protocol.update(stage_id=STUDY, source_commit=COMMIT, purpose=module.CONTRACT["purpose"],
                    execution_plan=module.CONTRACT, performance=module.CONTRACT)
    protocol["financial"]["maximum_stage_usd"] = 5.0
    tests = ("test_real_cuda_packed_ring_preserves_delayed_consumers_and_host_ownership",
             "test_real_cuda_lifetime_control_rejects_missing_consumer_fence",
             "test_real_cuda_unreleased_slot_refuses_overwrite_and_close_drains",
             "test_real_cuda_prefetch_mismatch_reset_identity_and_dense_ownership",
             "test_real_cuda_transfer_preserves_kanana_full_optimizer_trajectories")
    protocol["cuda_test_selectors"] += ["tests/test_expert_transfer.py::" + name for name in tests]
    protocol["cuda_expected_case_names"] += [*tests[:4], tests[4] + "[packed]",
                                              tests[4] + "[prefetch]"]
    write(NEW / "protocol.json", protocol)
    write(NEW / "protocol-contract.json", module.CONTRACT)
    write(NEW / "prior-budget-context.json", {
        "new_user_authorized_usd": 5., "maximum_stage_usd": 5.,
        "prior_unused_separate_usd": 4.909114004480999,
        "prior_unused_is_not_added_to_stage_cap": True, "prior_stage_cost_usd": 0.,
        "scope": "New prototype check; no allocation yet; old studies already closed"})
    required = ("source.tar.gz", "source-manifest.json", "constraints.txt", "preflight_remote.py",
                "setup.sh", "remote_run.py", "remote_guard.py", "lossless_results.py",
                "checkpoint_integrity.py", "storage-capacity-plan.json", "runtime_stack.py",
                "software-cohort.json", "runtime-wheel-lock.json", "runtime-wheel-requirements.txt",
                "cuda13-stack-metadata.json", "cuda13-transitive-metadata.json", "protocol.json",
                "upload-probe.bin", "cpu_overlap_probe.py", "profile_timeline.py",
                "transfer_probe.py", "protocol-contract.json", "source-controls.xml")
    path = NEW / "controller.py"
    text = path.read_text()
    start, end = text.index("REQUIRED ="), text.index('\nREMOTE =')
    text = text[:start] + "REQUIRED = " + repr(required) + "\n" + text[end:]
    text = text.replace('"launch_safety.py", "diagnostics.py", "api_rate_limit.py", "api_transport.py")',
                        '"launch_safety.py", "diagnostics.py", "api_rate_limit.py", "api_transport.py",'
                        ' "durable.py")')
    path.write_text(text, encoding="utf-8")
    path = NEW / "transport.py"
    text = path.read_text()
    start, end = text.index("UPLOAD_ALLOWLIST ="), text.index("\nMAX_REPLY_BYTES")
    text = text[:start] + "UPLOAD_ALLOWLIST = frozenset(" + repr(
        required + ("launch-manifest.json",)) + ")\n" + text[end:]
    path.write_text(text, encoding="utf-8")
    path = NEW / "cloud.py"
    text = path.read_text().replace("MAXIMUM_USD = 5.60", "MAXIMUM_USD = 5.0")
    text = text.replace("USD5.60 subcap within USD5.678490342737433", "new USD5 prototype cap")
    text = replace_function(text, "save", '''def save(name, value):
    from durable import durable_json
    durable_json(ROOT / name, value)
''')
    path.write_text(text, encoding="utf-8")
    path = NEW / "diagnostics.py"
    text = replace_function(path.read_text(), "_save", '''def _save(path, value):
    from durable import durable_json
    durable_json(path, value)
''')
    path.write_text(text, encoding="utf-8")
    path = NEW / "api_rate_limit.py"
    text = path.read_text()
    begin = text.index("                    temporary = state_path.with_name(")
    end = text.index("                    return started", begin)
    text = text[:begin] + '''                    from durable import durable_json
                    durable_json(state_path, {"last_start_monotonic": started,
                        "last_start_unix": time.time(), "pid": os.getpid(), "cleanup": cleanup})
''' + text[end:]
    path.write_text(text, encoding="utf-8")
    path = NEW / "remote_run.py"
    text = path.read_text()
    begin, end = text.index("def validate_cpu_overlap_outputs"), text.index("\ndef main()")
    segment = text[begin:end].replace("cpu_overlap_probe.py", "transfer_probe.py").replace(
        "private_cpu_overlap_probe", "private_transfer_probe").replace(
        "cpu-overlap-validation.json", "transfer-validation.json")
    text = text[:begin] + segment + text[end:]
    text = text.replace("str(ROOT / 'cpu_overlap_probe.py'),\n                     'run'",
                        "str(ROOT / 'transfer_probe.py'),\n                     'run'")
    text = text.replace("OUT / 'cpu-overlap'", "OUT / 'transfer-probe'").replace(
        "'cpu-overlap-probe'", "'transfer-probe'").replace(
        "phase_receipt('cpu_overlap_probe'", "phase_receipt('transfer_probe'").replace(
        "preregistered_cpu_overlap_probe_new_study", "preregistered_expert_transfer_study")
    # Export the actual new runner with the same original-file retention protocol.
    text = text.replace("'cpu_overlap_probe.py', 'profile_timeline.py'",
                        "'transfer_probe.py', 'cpu_overlap_probe.py', 'profile_timeline.py'")
    path.write_text(text, encoding="utf-8")
    safety = '''"""Exact pre-data protocol gate for the new transfer experiment."""
EXPECTED = __EXPECTED__

def validate_protocol(protocol, *, source_commit, stage_id):
    if (protocol != EXPECTED or source_commit != EXPECTED["source_commit"]
            or stage_id != EXPECTED["stage_id"]):
        raise ValueError("Frozen source/science/resource/budget protocol changed")
    return {"source_commit": source_commit, "new_transfer_study": True,
            "cuda_cells": len(EXPECTED["cuda_expected_case_names"])}
'''.replace("__EXPECTED__", pprint.pformat(protocol, width=95, sort_dicts=False))
    (NEW / "launch_safety.py").write_text(safety, encoding="utf-8")
    Console().print({"offline_stage": str(NEW), "source": COMMIT, "source_files": len(files),
                     "gpu_preflight_cells": len(protocol["cuda_expected_case_names"]),
                     "new_budget_cap_usd": 5., "rental_started": False})


if __name__ == "__main__":
    main()
