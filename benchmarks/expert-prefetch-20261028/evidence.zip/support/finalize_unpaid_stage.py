"""Finish and seal the existing unpaid stage, without any provider mutation."""

import ast
import hashlib
import importlib.util
import json
import pprint
import shutil
import sys
import time
from pathlib import Path

from rich.console import Console

PREP = Path(__file__).parent
STAGE = PREP.parent / "expert-prefetch-gpu-20261028-a"
OLD = PREP.parent / "expert-cpu-overlap-20261028"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def main():
    assert not any((STAGE / name).exists() for name in (
        "launch-manifest.json", "lease-greenlight.json", "vast-rental.json"))
    probe = load("new_transfer", PREP / "transfer_probe.py")
    refresh = load("refresh_source", PREP / "refresh_unpaid_source.py")
    refresh.main()
    protocol = json.loads((STAGE / "protocol.json").read_text())
    protocol["execution_plan"] = probe.CONTRACT
    protocol["performance"] = probe.CONTRACT
    for name, value in (("protocol.json", protocol), ("protocol-contract.json", probe.CONTRACT)):
        (STAGE / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
    safety = '"""Exact pre-data protocol gate for the new transfer experiment."""\n'
    safety += "EXPECTED = " + pprint.pformat(protocol, width=95, sort_dicts=False) + "\n\n"
    safety += '''def validate_protocol(protocol, *, source_commit, stage_id):
    if (protocol != EXPECTED or source_commit != EXPECTED["source_commit"]
            or stage_id != EXPECTED["stage_id"]):
        raise ValueError("Frozen source/science/resource/budget protocol changed")
    return {"source_commit": source_commit, "new_transfer_study": True,
            "cuda_cells": len(EXPECTED["cuda_expected_case_names"])}
'''
    (STAGE / "launch_safety.py").write_text(safety, encoding="utf-8")
    path = STAGE / "setup.sh"
    text = path.read_text()
    text = text.replace("export CUDA_VISIBLE_DEVICES=0 PYTHONHASHSEED=0 USE_TF=0\n",
                        "export CUDA_VISIBLE_DEVICES=0 PYTHONHASHSEED=0 USE_TF=0\n"
                        "export CUDA_LAUNCH_BLOCKING=0\n"
                        "export PYTORCH_ALLOC_CONF=backend:native\n"
                        "export PYTORCH_CUDA_ALLOC_CONF=backend:native\n")
    path.write_text(text, encoding="utf-8", newline="\n")
    path = STAGE / "remote_run.py"
    text = path.read_text().replace("'lossless_results.py')", "'source-controls.xml', 'lossless_results.py')")
    path.write_text(text, encoding="utf-8", newline="\n")
    # Reuse only the generic immutable retention/resource primitives of the old auditor.
    original = OLD / "audit_cpu_overlap.py"
    assert sha(original) == "a0b434b3b7f894bcaf07af3b4cfa36e8208d91de090118cd241ed4866e63b54c"
    original_text = original.read_text()
    tree = ast.parse(original_text)
    selected = {"require", "finite", "read", "sha", "contained", "resource_point",
                "resources", "timing_phase", "Originals", "archive_bytes"}
    header = '''"""Pre-data extraction of unchanged retention/resource audit primitives."""
from __future__ import annotations
import functools
import hashlib
import json
import math
import os
import re
import tarfile
import zlib
from pathlib import Path, PurePosixPath
from typing import Any
'''
    header += f'SOURCE = "{probe.COMMIT}"\nGIB, CHUNK = 2**30, 4 * 2**20\n\n'
    functions = [ast.get_source_segment(original_text, node) for node in tree.body
                 if isinstance(node, (ast.FunctionDef, ast.ClassDef)) and node.name in selected]
    assert len(functions) == len(selected)
    (STAGE / "archive_audit.py").write_text(header + "\n\n".join(functions) + "\n")
    foundation = OLD / "audit_cpu_foundation.py"
    assert sha(foundation) == "6c2eed12596fd76e49bca74ba214d506032339138915d17e88195640bc783bf6"
    shutil.copyfile(foundation, STAGE / "audit_infrastructure.py")
    for name in ("audit_transfer.py", "test_transfer_probe.py", "probe-controls.xml",
                 "operator-controls-final.xml"):
        shutil.copyfile(PREP / name, STAGE / name)
    # This is evidence only; the GPU stage still must execute all ten CUDA cases.
    shutil.copyfile(PREP / "final-source-controls.xml", STAGE / "source-controls.xml")
    Console().print({"unpaid_stage_ready_for_final_tests": str(STAGE),
                     "source_commit": probe.COMMIT, "allocation": False, "freeze": False})


def freeze():
    assert not any((STAGE / name).exists() for name in (
        "launch-manifest.json", "lease-greenlight.json", "vast-rental.json"))
    sys.path[:0] = [str(STAGE)]
    import controller

    # Include all scripts/tests/proofs, omit private keys and mutable provider snapshots.
    names = set(controller.REQUIRED)
    names.update(p.name for p in STAGE.glob("*.py"))
    names.update(p.name for p in STAGE.glob("*.xml"))
    names.update(("ssh-key.pub", "key-control.json", "key-dacl-control.json",
                  "prior-budget-context.json", "historical-owned.json",
                  "software-lock-validation.json"))
    manifest = {"stage_id": "soup-expert-prefetch-20261028-a", "unix": time.time(),
                "retention_estimate_bytes": 1500000000, "raw_estimate_bytes": 12 * 2**30,
                "files": {name: {"bytes": (STAGE / name).stat().st_size,
                                  "sha256": sha(STAGE / name)} for name in sorted(names)}}
    from durable import durable_json

    durable_json(STAGE / "launch-manifest.json", manifest)
    controller.freeze_check()
    durable_json(STAGE / "offline-freeze-verification.json", {
        "manifest_sha256": sha(STAGE / "launch-manifest.json"), "unix": time.time(),
        "all_frozen_files_verified": True, "frozen_files": len(names),
        "new_task_cap_usd": 5.0, "rental_started": False})
    Console().print({"freeze_verified": True, "files": len(names),
                     "manifest_sha256": sha(STAGE / "launch-manifest.json")})


if __name__ == "__main__":
    freeze() if "--freeze" in sys.argv else main()
