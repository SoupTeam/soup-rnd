"""Read only this lease's small status files; never queries GPU telemetry."""

import sys
import subprocess
from pathlib import Path

from rich.console import Console

BASE = Path(__file__).parent.parent
STAGE = BASE / "expert-prefetch-gpu-20261028-a"
sys.path.insert(0, str(STAGE))
import cloud  # noqa: E402

CODE = '''import json,sys
from pathlib import Path
root=Path('/root/liger/results')
state=json.loads((root/'stage-status.json').read_text())
result={'stage':state}
path=root/'transfer-probe/run.json'
if path.is_file():
    run=json.loads(path.read_text())
    result.update(status=run['status'],accuracy_passed=run['accuracy_passed'],
        accuracy={name:{'passed':cell['versus_native']['passed'],
                        'bitwise':cell['versus_native']['bitwise']}
                  for name,cell in run['accuracy'].items()},
        exploration={cell['policy']:cell['worker']['result']['timing']['update_seconds']
                     for cell in run['exploration']},
        confirmation_completed=len(run['confirmation']),selection=run.get('selection'),
        confirmation_summary=run.get('confirmation_summary'),error=run.get('error'))
    result['exploratory_memory']={cell['policy']:{
        'allocated_gib':cell['worker']['result']['timing']['cuda']['peak_allocated_bytes']/2**30,
        'reserved_gib':cell['worker']['result']['timing']['cuda']['peak_reserved_bytes']/2**30,
        'rss_gib':cell['worker']['result']['timing']['resources']['sampled_peak_rss_bytes']/2**30}
        for cell in run['exploration']}
    envelopes=sorted((root/'transfer-probe').rglob('transfer-envelope.json'))
    result['worker_envelope_count']=len(envelopes)
    result['worker_envelopes']=[{'path':str(path.relative_to(root)),
        **{key:value for key,value in json.loads(path.read_text()).items()
           if key in ('status','policy','phase','error')}} for path in envelopes[-2:]]
    result['worker_progress']=[{'path':str(path.relative_to(root)),
        'status':value.get('status'),'error':value.get('error'),
        'setup_seconds':value.get('setup',{}).get('seconds'),
        'warmup_complete':value.get('warmup',{}).get('updates_complete'),
        'timed_complete':value.get('timing',{}).get('updates_complete'),
        'timed_seconds':value.get('timing',{}).get('update_seconds')}
        for path in sorted((root/'transfer-probe').rglob('result.json'),
                           key=lambda path:path.stat().st_mtime)[-2:]
        for value in [json.loads(path.read_text())]]
sys.stdout.write(json.dumps(result))
'''


if __name__ == "__main__":
    answer = subprocess.run(cloud.ssh_args() + ["python3 -"], input=CODE.encode(),
                            capture_output=True, check=False, timeout=20)
    if answer.returncode:
        Console().print({"status": "read_only_progress_unavailable", "code": answer.returncode})
    else:
        Console().print(answer.stdout.decode())
