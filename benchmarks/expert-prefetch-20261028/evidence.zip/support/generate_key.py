"""New owner-only stage key; no key bytes are emitted or shared."""

import hashlib
import os
import subprocess
import sys
from pathlib import Path

STAGE = Path(__file__).parent.parent / "expert-prefetch-gpu-20261028-a"
sys.path[:0] = [str(STAGE), str(STAGE.parent / "expert-dispatch-profile-20261026/.key-deps")]

from cryptography.hazmat.primitives import serialization  # noqa: E402
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey  # noqa: E402
from durable import durable_json  # noqa: E402
from rich.console import Console  # noqa: E402


def main():
    private, public = STAGE / "ssh-key", STAGE / "ssh-key.pub"
    assert not private.exists() and not public.exists()
    key = Ed25519PrivateKey.generate()
    raw = key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.OpenSSH,
                            serialization.NoEncryption())
    pub = key.public_key().public_bytes(serialization.Encoding.OpenSSH,
                                        serialization.PublicFormat.OpenSSH)
    for path, data in ((private, raw), (public, pub + b" soup-expert-prefetch-a\n")):
        with path.open("xb") as output:
            output.write(data)
            output.flush()
            os.fsync(output.fileno())
    decoded = serialization.load_ssh_private_key(private.read_bytes(), password=None)
    assert decoded.public_key().public_bytes(serialization.Encoding.OpenSSH,
            serialization.PublicFormat.OpenSSH) == pub
    sid = subprocess.check_output(["powershell.exe", "-NoProfile", "-Command",
        "[System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value"], text=True).strip()
    subprocess.run(["icacls", str(private), "/inheritance:r", "/grant:r", "*" + sid + ":(F)"],
                   stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
    actual = subprocess.check_output(["ssh-keygen", "-y", "-f", str(private)]).strip()
    assert actual.split()[:2] == pub.split()[:2]
    durable_json(STAGE / "key-control.json", {"cipher": "none",
        "private_decodes_without_password": True, "key_pair_matches": True,
        "public_sha256": hashlib.sha256(public.read_bytes()).hexdigest(),
        "actual_openssh_roundtrip_passed": True, "owner_sid": sid})
    Console().print({"new_key_created": True, "actual_openssh_pair_passed": True})


if __name__ == "__main__":
    main()
