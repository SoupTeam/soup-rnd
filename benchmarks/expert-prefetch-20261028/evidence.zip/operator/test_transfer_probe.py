"""Pre-data controls for selection, held-out schedules, byte binding and durable receipts."""

import copy
import importlib.util
import json
from pathlib import Path
from unittest.mock import patch

import pytest

from durable import durable_json
from transfer_probe import CONTRACT, confirm, select_candidate


def exploration(values):
    return [{"policy": name, "worker": {"result": {"timing": {"update_seconds": values[name]}}}}
            for name in CONTRACT["exploration_order"]]


@pytest.mark.parametrize("packed,prefetch,expected", [(9., 8., "prefetch"), (9., 11., "packed"),
                                                      (10., 10., None), (11., 12., None)])
def test_selection_requires_distinct_positive_mode(packed, prefetch, expected):
    rows = exploration({"native": [10.] * 6, "packed": [packed] * 6,
                        "prefetch": [prefetch] * 6})
    assert select_candidate(rows)["candidate"] == expected


def confirmation(candidate_time):
    rows = []
    pair = ("native", "packed")
    for number, order in enumerate((pair, pair[::-1]) * 2):
        for position, policy in enumerate(order):
            raw = {"pid": len(rows) + 1,
                   "warmup": {"losses": [2., 1.]},
                   "timing": {"losses": [1.] * 6, "update_seconds": [
                       10. if policy == "native" else candidate_time] * 6}}
            rows.append({"round": number, "position": position, "policy": policy,
                         "worker": {"result": raw}})
    return rows


def qualified():
    import sys

    root = Path(r"C:\Users\esenb\.codex\worktrees\expert-prefetch-20261028\soup-rnd-d2")
    sys.path[:0] = [str(root), str(root / "src")]
    from benchmarks.harness import expert_cache_dispatch_qualification as q
    from benchmarks.harness import two_read_cache_common as common

    return q, common


@pytest.mark.parametrize("time,passed", [(9., True), (9.9, False), (10., False), (11., False)])
def test_confirmation_keeps_original_practical_gate(time, passed):
    q, common = qualified()
    summary = confirm(confirmation(time), "packed", q, common)
    assert summary["passes_practical_2_percent_gate"] is passed
    assert summary["selection_samples_excluded"] is True


@pytest.mark.parametrize("corrupt", ("schedule", "pid", "loss", "count"))
def test_confirmation_refuses_invalid_or_inaccurate_blocks(corrupt):
    q, common = qualified()
    rows = confirmation(9.)
    if corrupt == "schedule":
        rows[1]["policy"] = "native"
    elif corrupt == "pid":
        rows[1]["worker"]["result"]["pid"] = 1
    elif corrupt == "loss":
        rows[1]["worker"]["result"]["timing"]["losses"][0] = 1.2
    else:
        rows.pop()
    with pytest.raises(ValueError):
        confirm(rows, "packed", q, common)


def test_durable_receipt_syncs_before_replace_and_preserves_prior_on_failure(tmp_path):
    path = tmp_path / "receipt.json"
    durable_json(path, {"old": True})
    with patch("durable.os.fsync", side_effect=OSError("injected crash boundary")):
        with pytest.raises(OSError):
            durable_json(path, {"new": True})
    assert json.loads(path.read_text()) == {"old": True}
    assert list(tmp_path.iterdir()) == [path]
    durable_json(path, {"new": True})
    assert json.loads(path.read_text()) == {"new": True}


def test_protocol_mutations_refuse_before_any_allocation():
    stage = Path(__file__).parent.parent / "expert-prefetch-gpu-20261028-a"
    spec = importlib.util.spec_from_file_location("transfer_safety", stage / "launch_safety.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    original = json.loads((stage / "protocol.json").read_text())
    assert module.validate_protocol(original, source_commit=original["source_commit"],
                                    stage_id=original["stage_id"])["cuda_cells"] == 10
    for section, key, wrong in (("financial", "maximum_stage_usd", 5.01),
                                ("financial", "maximum_seconds", 9001),
                                ("native_boundary", "swap_must_be_disabled", False),
                                ("execution_plan", "rtol", .02),
                                ("execution_plan", "timed_updates", 5)):
        candidate = copy.deepcopy(original)
        candidate[section][key] = wrong
        with pytest.raises(ValueError):
            module.validate_protocol(candidate, source_commit=original["source_commit"],
                                     stage_id=original["stage_id"])
