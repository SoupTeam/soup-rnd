B6 real DeepSeek-V3 671B acceptance repeat, 2026-10-29.
Executed code: c243b0f4f5c85a5c76ba7136231937ee9fbc185d.
Model pin: deepseek-ai/DeepSeek-V3 e815299b0bcbac849fa540c768ef21845365c9eb.
One P4000 8 GiB, FP32 compute, NF4/no double quant, rank-2 attention LoRA.
Two updates; eight prospectively approved WikiText-2 pairs; exact model reload.
The source snapshot includes the frozen protocol/data and their separate dataset attribution.
See benchmarks/b6-acceptance-20261029.md in the PR for commands, raw accounting,
limitations, costs, and external reviewer acceptance status.
The raw executed source archive and manifest preserve exact Windows input bytes.
The adapter_config base path is the measured VM path; load it against an explicitly
constructed model/cache of the pinned revision, as in b6_real_moe.py's reload path.
No base checkpoint weights or giant NF4 cache are distributed in this bundle.
