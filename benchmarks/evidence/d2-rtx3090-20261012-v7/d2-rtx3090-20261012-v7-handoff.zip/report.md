# D2 v7: NF4 wrapper rounding, 2026-10-12

**The remaining three NF4 numerical failures are fixed in the tested matrix.**
Independent CPU replay of 116 saved tensor files verifies 895 positive comparisons,
zero failures. Full D2 acceptance remains open: performance is NO VERDICT, the
final-head full CI and team D2/T00/F1 sign-off are still required.

This supersedes the v6 numerical status in the [first RTX 3090 report](d2-rtx3090-report-20261012.md).
That report, its failed tensors and original source/evidence archives remain unchanged.

## Cause and fix

NF4 storage and PEFT wrapper arithmetic are separate properties. A regular PEFT
`Linear` can contain an NF4 base, as in the streaming path and the original NF4
fixture. With FP32 adapters and low-precision activations, it adds the FP32 update
to the promoted base result and then narrows. PEFT's native `Linear4bit` instead
narrows the scaled update before adding it to the base result.

The old custom path selected the latter behavior whenever a quantization state
was present. This gave the regular PEFT wrapper the wrong cast/add seam. Changing
layout, using `linear` instead of `matmul`, or making the hidden tensor contiguous
did not fix the three failures. Those four experiments are retained.

A same-host one-factor prototype changed only the update policy to the regular
PEFT seam: all four original/additional projection matrices passed (48 cases).
The permanent implementation records the actual wrapper policy in projection
metadata, includes it in the existing QKV cache key and selects the matching
cast/add behavior. It does not alter the packed weights or quantization state.
The single-projection Function accepts an optional policy argument while keeping
the existing seven-argument direct invocation compatible.

The original dense-wrapper fixture and its seed are retained. Additional coverage
constructs actual PEFT `Linear4bit` wrappers using the same quantized base and
copied FP32 adapters. The canonical dense reference-order guards are unchanged;
NF4 custom execution remains distinct from that guarded reference scope.

## Verified results

| Regime | Result |
|---|---|
| Dense FP32/FP16/BF16, dX on/off | PASS, all 123 expected quantities retained |
| Strict50 FP32/FP16/BF16 | PASS, 50/50 loss pairs per dtype match at `.3f`, seed 792 |
| NF4 regular PEFT wrapper, tiny/aligned, FP16/BF16 | PASS, 48/48 cases |
| NF4 native PEFT `Linear4bit`, tiny/aligned, FP16/BF16 | PASS, 48/48 cases |
| NF4 streaming FP16/BF16 | PASS, all 56 adapter gradients plus logits/loss per dtype |
| Streamed changed-adapter controls | Both rejected numerically, 20 real custom execution sites each |
| Selected GPU regressions | 15 passed; zero failures/errors/skips |
| Final selected CPU kernel/rounding/checkpoint invocation | 247 passed, 21 hardware skips |
| Final selected CPU D2 invocation | 774 passed, 7 hardware skips |

Projection cases cover single/QKV/MLP, both dX modes, checkpoint on/off and nonzero
B. Both low-precision arms have identical frozen packed bases and full nested
quantization state. Float64 dequantizes those same bases. Changed-adapter controls
are retained for every passing projection case. Streaming uses four layers and
two slots, with recorded buffer reuse and unchanged shared shard hashes.

Independent tensor replay requires all outputs/gradients from the fixture topology;
omitting the same gradient from all arms fails. Forward and backward are reported
separately, using the unchanged FP32 `assert_close` rule and FP16/BF16 rule
`fast_max_abs_error <= 2 * peft_max_abs_error + 1e-8`.

| Dtype | Forward exact / checked | Backward exact / checked |
|---|---:|---:|
| FP32 | 10 / 10 | 29 / 31 |
| FP16 | 92 / 92 | 333 / 335 |
| BF16 | 92 / 92 | 333 / 335 |

All 772 saved positive NF4/streaming quantities are exact in these finite fixtures.
The six approximate rows are retained dense input-gradient comparisons; they pass
the declared rule. This is not universal bit-exactness. Strict50 FP16/BF16 loss
pairs are exact; FP32's maximum unrounded loss difference is `4.76837158203125e-07`.
The intentionally wrong streaming controls retain their failing tensors/reports.

## Hardware, source and performance boundary

One RTX 3090 (24 GB, capability 8.6), Linux/Python 3.12.3, driver 580.167.08,
torch 2.11.0+cu126, PEFT 0.20.0, Transformers 5.17.0, bitsandbytes 0.50.1,
Triton 3.6.0. Native BF16 CUDA operation passed. The first rental additionally
compiled/executed a real Triton kernel; no Liger/Unsloth comparison is claimed.

Frozen v7 source ZIP SHA-256:

```text
c2debe1fd4bd5326af152185c0c93acfbf55a26fb2f0417bbc71e139b981bff3
```

All GPU source-manifest entries match this archive. The production files match
the executed bytes in the Windows checkout; Git may normalize CRLF/LF. The new
scalar midpoint regression test was added locally after freezing the GPU source.

The final dense shaped-block timing run retains 240 raw arms per dtype. All arms
are marked VOID by the existing peer guard. For example, the first BF16 arm
reports NVML PID 783302 with name `[Not Found]`, while its own PID is 1397. A PID
namespace mismatch is plausible but not established by the retained telemetry.
We cannot identify that process reliably, so no arm is reclassified and there is
no final-head performance ratio or speedup claim. Original v6 descriptive timing
is retained under its original NO VERDICT status.

Absolute allocated/reserved peaks include both models and correctness snapshots;
they do not establish standalone VRAM savings. Fresh-process/accepted telemetry
timing and required compatible baseline comparisons remain open. All fixtures
are synthetic: no real-checkpoint quality, whole-8B or full-training claim follows.

## Handoff and resource cleanup

The [v7 handoff](evidence/d2-rtx3090-20261012-v7/README.md) contains original runtime
experiments, the permanent-source run, positive/negative tensor evidence, source
ZIP, commands/JUnit and the full offline replay. Remote/downloaded hashes and ZIP
CRCs were checked. Earlier failures are preserved, not replaced by the green run.

The second rental stopped through the fixed deadline guard. A brief recovery
restart was also stopped within the original 30-minute wall-clock window. The
later downloads used Vast's stopped-instance data-copy mechanism and a local
temporary rsync container, without restarting the GPU again. Both rented
instances were destroyed and API verification returned no remaining instances.

Observed team balance decreases: first run `$0.1703896`, second run `$0.0787922`,
total approximately **$0.2492**. These are observed balance deltas, not final invoices.
No account API credentials or private SSH keys are included in either handoff.

Final-head full CI, independent team review, valid performance evidence and
D2/T00/F1 completion remain open. Do not mark the full task Done from a passing
numerical subset.
