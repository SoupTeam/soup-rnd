# B6 pilot artifact

Real DeepSeek-V3 causal decoder: 671,026,419,200 parameters.
Source: deepseek-ai/DeepSeek-V3, revision e815299b0bcbac849fa540c768ef21845365c9eb.
Two AdamW updates, rank-2 alpha-4 attention LoRA, NF4 base without double quant, BF16.
This is a capacity/reload pilot, not a quality-qualified production adapter.

adapter/ contains the original measured artifact, including the original config
whose local source path was /root/b6/source. Use the pinned upstream model, not
that now-deleted cloud directory. The benchmark harness builds the streamed
model/cache first and loads weights with load_peft_weights plus
set_peft_model_state_dict; it checks the final parameter digest and exact logits.
The real run did not test ordinary resident loading or a giant soup train CLI run.

executed-source.tar.gz contains the exact executed source, data and pyproject.
pip-freeze.txt pins the measured environment (torch 2.8.0+cu128); install the CUDA
12.8 torch build using the official PyTorch CUDA index. See the repository report
benchmarks/b6-giant-moe-20261028.md for the full command, failures and limitations.
Raw reference logits and both trial adapters are retained in the local complete
results.tar.gz. The repository stores their hashes and completed raw journal.
