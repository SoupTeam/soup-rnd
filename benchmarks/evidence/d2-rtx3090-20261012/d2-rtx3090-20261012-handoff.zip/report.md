# D2 RTX 3090 evidence, 2026-10-12

**D2 remains INCOMPLETE. Do not merge on the strength of this report.** Native
BF16 dense gates and the four-layer NF4 streaming fixture now pass on compatible
hardware. Three saved NF4 quantities still violate the unchanged numerical rule.
No general speedup or full-training performance claim is supported.

## Source and environment

The source baseline is PR #5 head `441a8f8a33e738f4ff7b58fbba4693b02fe21cb9`.
The final GPU candidate is the frozen **v6 source archive**, with its complete
per-file source manifest in the evidence. All source-manifest entries match that
archive. The three production kernels match this update after CRLF/LF
normalization; the handoff retains the exact executed bytes and their hashes.
The later offline audit and its tests were added after the GPU run. The local
QKV observer test was subsequently strengthened to observe both helper aliases.
Do not describe those later files as GPU-tested.

- Linux, Python 3.12.3; one NVIDIA GeForce RTX 3090, 24 GB, capability 8.6.
- Driver 595.71.05; torch 2.11.0+cu126, CUDA runtime 12.6.
- PEFT 0.20.0, Transformers 5.17.0, bitsandbytes 0.50.1, Accelerate 1.14.0.
- Triton 3.6.0: a real add-one kernel compiled and executed. Native BF16 support
  and a BF16 CUDA matrix multiplication were checked. This proves the preflight,
  not compatibility or performance of Liger/Unsloth.
- Synthetic random weights/tokens throughout; no pretrained-model quality claim.

The NF4 candidate preserves separate adapter projection GEMMs and individually
rounded input-gradient edges. It also uses bitsandbytes' packed-base forward
dispatch on CUDA in supported dtypes. CPU/float64 retains dense dequantization.
The existing guarded canonical dense reference scope is unchanged; the generic
NF4 fixture exposes `nf4_projection_order=True`, `reference_order=False`.

## Correctness results for v6

| Regime | Result | Scope |
|---|---|---|
| Dense FP32/FP16/BF16, requested dX | PASS | 22 output/gradient quantities per dtype |
| Dense FP32/FP16/BF16, no dX | PASS | 19 output/adapter-gradient quantities per dtype |
| Strict50, FP32/FP16/BF16 | PASS | 50/50 losses per dtype match at `.3f`, seed 792 |
| NF4 tiny, BF16 | FAIL | 11/12 cases; QKV forward failure below |
| NF4 tiny, FP16 | FAIL | 11/12 cases; MLP backward failure below |
| NF4 aligned, BF16 | FAIL | 11/12 cases; MLP backward failure below |
| NF4 aligned, FP16 | PASS | 12/12 cases |
| NF4 streaming, FP16/BF16 | scoped PASS | 58 quantities per dtype, 4 layers, 2 buffers |
| Selected GPU regressions | PASS | 15 passed, zero failures/errors/skips |
| Additional GPU NF4 arithmetic scope | PASS | 2 passed, 2 CPU cases deselected |

NF4 projection cases cover single/QKV/MLP, both dX modes, and non-reentrant
checkpoint on/off, with FP32 adapters and nonzero B. Each pair uses copied,
identical packed bases and full nested quantization state. Both states remain
unchanged. Float64 uses weights dequantized from those same packed states.
Changed-adapter controls are rejected for passing cases. Earlier failures are
preserved; the aligned shape is additional evidence, not a replacement for tiny.

Streaming uses one immutable NF4 shard set for both low-precision arms and a
dense float64 oracle dequantized from that set. All 56 adapter gradients, logits
and loss are present and finite. Observed custom Functions cover 20 execution
sites; runtime stats record reuse with more layers than buffer slots. The
streaming probe does not contain its own deliberately different control, and
does not establish a streaming training trajectory or optimizer equivalence.

The unchanged per-tensor FP16/BF16 rule is
`fast_max_abs_error <= 2 * peft_max_abs_error + 1e-8`, against float64.
Independent CPU replay of **68 tensor files / 567 quantities** finds exactly
these three failed quantities:

| Fixture / dtype | Case / quantity | Fast error vs float64 | Allowed bound |
|---|---|---:|---:|
| tiny / BF16 | QKV dX=1, checkpoint=0, `Y/k_proj` | 0.006063071312445434 | 0.004331131958220052 |
| tiny / FP16 | MLP dX=1, checkpoint=0, `dB/gate_proj` | 0.0017262033091237639 | 0.0013520681456523128 |
| aligned / BF16 | MLP dX=1, checkpoint=0, `dB/up_proj` | 0.040900648191775524 | 0.03822073457089654 |

Replay records every quantity, including those after a run's first failure, and
distinguishes exact equality from tolerance passes. No tolerance, seed, dtype,
optimizer or original shape was changed to hide a failure. Strict50 BF16/FP16
loss pairs are exact; FP32's maximum unrounded loss difference is
`4.76837158203125e-07`.

## Dense shaped-block timing: NO VERDICT

The fixture uses hidden=4096, KV=1024, intermediate=14336, rank=16, batch=1,
128 tokens. It is an 8B-shaped projection/block fixture, not a complete 8B model.
The corresponding dense correctness gate passes before timing. Forward and
backward use separate synchronized CUDA events, 5 warmups and 10 ABBA rounds,
with two samples per implementation per round; 240 raw arms per dtype.

Offline telemetry review excludes entire rounds with unequal recorded SM clocks
or power states: 1 BF16 round and 2 FP16 rounds. Sampled telemetry is finite and
records only the benchmark's own visible GPU process for included rounds.
All excluded measurements remain in the raw artifacts.

The following are descriptive medians after that exclusion. The ratio is the
median of per-round PEFT/fast total-time ratios; >1 favors fast. It is not computed
by dividing the two separate medians.

| Dtype | Path | dX | Rounds | PEFT total ms | Fast total ms | Paired ratio |
|---|---|---|---:|---:|---:|---:|
| BF16 | single | yes | 10 | 3.573 | 3.596 | 0.989 |
| BF16 | single | no | 10 | 2.995 | 3.131 | 0.955 |
| BF16 | QKV | yes | 10 | 8.555 | 8.757 | 1.017 |
| BF16 | QKV | no | 10 | 6.970 | 7.608 | 0.922 |
| BF16 | MLP | yes | 9 | 9.226 | 8.668 | 1.036 |
| BF16 | MLP | no | 10 | 7.910 | 8.066 | 0.986 |
| FP16 | single | yes | 10 | 3.634 | 3.691 | 0.986 |
| FP16 | single | no | 10 | 3.002 | 3.182 | 0.956 |
| FP16 | QKV | yes | 10 | 9.115 | 8.766 | 1.032 |
| FP16 | QKV | no | 10 | 7.243 | 7.734 | 0.937 |
| FP16 | MLP | yes | 9 | 9.439 | 9.076 | 1.034 |
| FP16 | MLP | no | 9 | 8.148 | 8.217 | 0.988 |

Clock/power/process snapshots are sampled after arms; clocks were not locked and
there is no continuous telemetry during an arm. Models and correctness snapshots
coexist in the same process. Absolute allocated/reserved peaks include both arms
and cached correctness tensors; they cannot establish standalone VRAM savings.
Warmup, inference and optimizer/full-training costs are outside the timed region.
These limitations keep the performance verdict **NO VERDICT**. The measurements
show no consistent improvement and include slower cases. NF4 performance and
Liger/Unsloth comparison were not measured.

## Evidence and replay

The reviewer-accessible bundle and SHA-256 manifest are under
[`evidence/d2-rtx3090-20261012/`](evidence/d2-rtx3090-20261012/README.md).
It includes original v2/v4/v6 source snapshots, original evidence archives,
failed tensors, logs/commands, JUnit and the complete offline audit. Remote final
archive and downloaded bytes matched SHA-256, and ZIP CRC checks passed.
Original archives are unchanged; no credentials or private SSH keys are included.

After extracting the handoff ZIP and its `gpu/d2-final-v6-complete.zip`, run from
this checkout with the training dependencies available:

```bash
PYTHONPATH=src python benchmarks/harness/d2_audit_evidence.py \
  /path/to/extracted/d2-evidence-20261012-v6 \
  --aligned-dir /path/to/extracted/d2-aligned-bf16-v6 \
  --aligned-dir /path/to/extracted/d2-aligned-fp16-v6 \
  --output /path/to/new-audit.json
```

Exit 1 with three failed quantities is the expected replay result, not an
infrastructure failure. Use a new output filename; evidence is not overwritten.
`d2_cloud_run.py` reproduces the bounded basic GPU matrix. Aligned NF4 probes use
`d2_nf4_probe.py --shapes nf4-aligned`; output directories must be new. The GPU
runner does not allocate, stop or destroy cloud instances; resource cleanup is an
operator responsibility separate from the runner's subprocess deadline.

## Completion and cost

The rented GPU was stopped before the one-hour deadline, and the instance was
then destroyed; a subsequent API query returned no remaining instances. The observed
team balance decrease is approximately **$0.1704**, including the setup and
evidence transfer interval. This is a balance delta, not a finalized invoice.
The local detached watchdog did not confirm an automatic stop; cleanup was
performed explicitly and then verified through the API.

Local selected test invocations and commands are in the handoff. They overlap and
must not be summed as unique tests. One initial selected invocation passed 763
tests with 7 hardware skips but exited 1 because the repository-wide 77% coverage
requirement is inappropriate for a selected subset; its original log is retained.
Final selected invocations disable global coverage explicitly: D2 regressions
769 passed / 7 hardware skips; kernel/NF4 regressions 228 passed / 17 hardware
skips; final offline audit regressions 7 passed. These invocations overlap and
do not represent a full repository test run. The repository's coverage
requirement is unchanged. Source/test/harness Ruff checks pass;
immutable raw copied scripts are not lint targets for this change.

`ci:full` has been requested on PR #5. A green full CI run on the final head is
still required. Three NF4 failures, the streaming negative control, accepted
performance evidence, compatible comparison scope where required, independent
review and team D2/T00/F1 completion remain open. No completion sign-off is claimed.
