"""Retain the actual interrupted state; do not invent a completed timing run."""
import json
from pathlib import Path

from rich.console import Console

ROOT=Path(__file__).parent
path=ROOT/'independent-analysis.json'
d=json.loads(path.read_text())
assert not d['performance'] and not d['timing_environment']
assert all(row['passed'] and row['bitwise_equal'] for row in d['primary'].values())
assert d['semantics']['hybrid-r16']['passed'] and d['semantics']['hybrid-r16']['bitwise_equal']
assert d['cost_and_cleanup']['verified_deleted']
d['remote_execution_status_at_interruption']=d['status']
d['status']='INTERRUPTED_AFTER_ACCURACY_BEFORE_TIMING'
d['timing_interpretation_status']='NO_TIMINGS_LOCAL_DISK_EXTRACTION_FAILURE'
d['interruption']={'reason':'Local disk filled during extraction; automatic controller cleanup deleted the instance before timing.',
    'controller_error_retained':True,'canonical_archive_fully_downloaded_and_SHA256_verified':True,
    'all_original_capture_files_recovered_and_verified':True,'numerical_tolerances_unchanged':True}
d['artifact_extraction_recovery']=json.loads((ROOT/'artifact-extraction-recovery.json').read_text())
d['environment_audit']={'count':0,'processes':[],'same_four_core_affinity':None,
    'sampled_compute_peers_at_most_one':None,'timing_eligible':False,
    'timing_status':'NO_TIMING_PROCESSES_WERE_STARTED'}
path.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
(ROOT.parent.parent/'benchmarks/streaming-residency-flashattention-clean-pcie-results-20261020.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
Console().print({'status':d['status'],'all_captures_bitwise_equal':True,'timing_processes':0,'all_original_files_recovered':True})
