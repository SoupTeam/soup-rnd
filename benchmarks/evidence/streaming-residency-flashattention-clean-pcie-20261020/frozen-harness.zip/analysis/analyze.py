"""Independent replay of same-residency accuracy and paired performance."""
import json
import random
import statistics
import sys
import time
from pathlib import Path

from rich.console import Console

ROOT=Path(__file__).parent
REPO=ROOT.parent.parent
sys.path[:0]=[str(ROOT/'source-tree'),str(ROOT/'source-tree/src')]

def main():
    import torch
    from safetensors.torch import load_file
    from benchmarks.harness.liger_streaming_parity import compare
    torch.set_num_threads(1)
    paths={};receipts=[]
    for file in sorted(ROOT.glob('bundle-*-verified.json'),key=lambda p:json.loads(p.read_text())['unix']):
        row=json.loads(file.read_text());receipts.append(row)
        folder=ROOT/'bundles'/row['name']/'retained'
        manifest=json.loads((folder/'original-files.json').read_text())
        for relative in manifest['files']:paths[relative]=folder/relative
    read=lambda relative:json.loads(paths[relative].read_text())
    state=json.loads((ROOT/'remote-progress.json').read_text())
    protocol=json.loads((ROOT/'protocol.json').read_text())
    def compare_trace(a,b):
        first=paths[a+'/trace.safetensors'];second=paths[b+'/trace.safetensors']
        verdict=compare(first.parent,second.parent)
        x=load_file(str(first));y=load_file(str(second))
        assert set(x)==set(y)
        verdict.update(bitwise_equal=all(torch.equal(value,y[name]) for name,value in x.items()),
                       tensors=len(x))
        return verdict
    report={'status':state['status'],'unix':time.time(),'protocol':protocol,
        'source_revision':protocol['upstream_commit'],'source_sha256':protocol['source_sha256'],
        'independent_replay':True,'local_torch':torch.__version__,
        'primary':{},'semantics':{},'performance':{},'execution_errors':{},
        'artifact_receipts':receipts,'remote_gates':state['gates'],'timing_environment':[],
        'semantic_backend_execution':{}}
    for cache in [8,16]:
        for attention in ['sdpa','external','hybrid']:
            prefix=f'results/semantics/r{cache}/{attention}'
            if prefix+'/study-provenance.json' not in paths:continue
            semantic=read(prefix+'/study-provenance.json')
            if prefix+'/attention-residency-provenance.json' not in paths:continue
            backend=read(prefix+'/attention-residency-provenance.json')
            events=semantic.get('attention_and_compiler_events',[])
            report['semantic_backend_execution'][f'{attention}-r{cache}']={
                'profiled_events':events,'backend_provenance':backend,
                'causal_prefix_exact_within_arm':semantic.get('causal_prefix_exact'),
                'masked_padding_isolation_exact_within_arm':semantic.get('masked_padding_isolation_exact')}
            if attention=='hybrid' and state['gates'].get(f'hybrid-r{cache}',{}).get('passed'):
                assert backend['original_semantic_AST_unchanged']
                assert backend['route_counts']['external_unmasked_calls']>0
                assert backend['route_counts']['native_explicit_mask_calls']>0
                assert not backend['route_counts']['fixture_external']
                assert any('flash::flash_fwd_kernel' in event and 'pytorch_flash::' not in event
                           for event in events),events
    if 'results/gates/r16/b1/sdpa-repeat/trace.safetensors' in paths:
        report['primary']['native-repeat']=compare_trace('results/gates/r16/b1/sdpa',
                                                       'results/gates/r16/b1/sdpa-repeat')
    for attention in ['external','hybrid']:
        for cache in [8,16]:
            key=f'{attention}-r{cache}'
            for batch in [1,2]:
                dest=f'results/gates/r{cache}/b{batch}/{attention}'
                gate=state['gates'].get(key,{}).get('comparisons',{}).get(f'b{batch}',{})
                if gate.get('execution_error'):
                    report['execution_errors'][f'{key}-b{batch}']=gate
                elif dest+'/trace.safetensors' in paths:
                    report['primary'][f'{key}-b{batch}']=compare_trace(
                        f'results/gates/r{cache}/b{batch}/sdpa',dest)
            semantic=f'results/semantics/r{cache}/{attention}'
            gate=state['gates'].get(key,{}).get('comparisons',{}).get('semantics',{})
            if gate.get('execution_error'):
                report['execution_errors'][key+'-semantics']=gate
            elif semantic+'/trace.safetensors' in paths:
                report['semantics'][key]=compare_trace(f'results/semantics/r{cache}/sdpa',semantic)
            for batch in [1,2]:
                rows=[r for r in state['timings'] if r['comparison']==key and r['batch']==batch
                      and 'results/'+r['path']+'/metrics.json' in paths]
                pairs=[];samples={'sdpa':[],attention:[]}
                for cycle in sorted({r['cycle'] for r in rows}):
                    matching={r['arm']:r for r in rows if r['cycle']==cycle}
                    if len(matching)!=2:continue
                    metrics={arm:read('results/'+r['path']+'/metrics.json') for arm,r in matching.items()}
                    a=metrics['sdpa'];b=metrics[attention]
                    assert a['data_sha256']==b['data_sha256'] and a['initial_adapter_sha256']==b['initial_adapter_sha256']
                    assert a['amp']==b['amp']=={'bf16':True,'fp16':False}
                    losses=[[r['loss'] for r in metric['training_log_history'] if 'loss' in r] for metric in [a,b]]
                    tensors={arm:load_file(str(paths['results/'+r['path']+'/adapter/adapter_model.safetensors']))
                             for arm,r in matching.items()}
                    first=tensors['sdpa'];second=tensors[attention]
                    assert set(first)==set(second) and len(first)==448
                    exact=all(torch.equal(value,second[name]) for name,value in first.items())
                    close=all(torch.isfinite(value).all() and torch.isfinite(second[name]).all()
                              and torch.allclose(value,second[name],rtol=.01,atol=.00001)
                              for name,value in first.items())
                    loss_close=all(f'{x:.3f}'==f'{y:.3f}' for x,y in zip(*losses,strict=True))
                    assert all(len(values)==14 for values in losses)
                    reduction=(1-b['median_seconds_per_optimizer_step']/a['median_seconds_per_optimizer_step'])*100
                    pairs.append({'cycle':cycle,'time_reduction_percent':reduction,
                        'final_adapter_tensors':448,'final_bitwise_equal':exact,
                        'losses_equal':losses[0]==losses[1],'accuracy_passed':bool(close and loss_close)})
                    for arm,metric in metrics.items():
                        path='results/'+matching[arm]['path']
                        prov=read(path+'/residency-provenance.json')
                        attn=read(path+'/attention-residency-provenance.json')
                        if arm=='hybrid':
                            counts=attn['route_counts']
                            assert counts['external_unmasked_calls']>0
                            assert counts['native_explicit_mask_calls']==0
                            assert not counts['fixture_external']
                        assert len(metric['seconds'])==8
                        assert all(shape==[batch,1024] for shape in metric['input_shapes'])
                        assert metric['deterministic_algorithms'] and prov['allocator_budget_bytes']==10*2**30
                        window=prov['per_update_loads'][-8:]
                        row={'step_seconds':metric['median_seconds_per_optimizer_step'],
                            'peak_allocated_bytes':max(metric['peak_allocated_bytes']),
                            'peak_reserved_bytes':max(metric['peak_reserved_bytes']),
                            'resident_bytes':prov['residency']['resident_bytes'],
                            'pinned_host_bytes':prov['runtime_after_install']['pinned_bytes'],
                            'decoder_loads':statistics.mean(x['decoder_loads'] for x in window),
                            'decoder_logical_bytes':statistics.mean(x['decoder_logical_bytes'] for x in window),
                            'setup_seconds':metric['setup_seconds'],
                            'wall_seconds':metric['training_wall_seconds_including_final_save']}
                        samples[arm].append(row)
                        report['timing_environment'].append({'path':path,'started_unix':prov['started_unix'],
                            'pid':prov['pid'],'affinity':prov['affinity'],
                            'attention':attn,'residency':prov['residency'],
                            'gpu_before':metric.get('gpu_before'),'gpu_after':metric.get('gpu_after')})
                if not pairs:continue
                values=[row['time_reduction_percent'] for row in pairs]
                rng=random.Random(792)
                bootstrap=sorted(statistics.median(rng.choices(values,k=len(values))) for _ in range(20000))
                ci=[bootstrap[500],bootstrap[19500]]
                med=statistics.median(values)
                passed=len(pairs)==4 and all(r['accuracy_passed'] for r in pairs) and med>=2 and ci[0]>0 and sum(v>0 for v in values)/len(values)>=.75
                report['performance'][f'{key}-b{batch}']={'pairs':pairs,'processes':samples,
                    'median_paired_time_reduction_percent':med,'bootstrap95_percent':ci,
                    'practical_speed_gate_passed':passed,'arms':{arm:{name:statistics.median(r[name] for r in rows)
                        for name in rows[0]} for arm,rows in samples.items()}}
    final=ROOT/'final-cost-and-cleanup.json'
    if final.exists():report['cost_and_cleanup']=json.loads(final.read_text())
    (ROOT/'independent-analysis.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    (REPO/'benchmarks/streaming-residency-flashattention-clean-pcie-results-20261020.json').write_text(
        json.dumps(report,indent=2)+'\n',encoding='utf-8')
    Console().print({'status':report['status'],'primary':{k:(v['passed'],v['bitwise_equal']) for k,v in report['primary'].items()},
        'performance':{k:{n:v[n] for n in ['median_paired_time_reduction_percent','bootstrap95_percent','practical_speed_gate_passed']}
                       for k,v in report['performance'].items()}})

if __name__=='__main__':main()
