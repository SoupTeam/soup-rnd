#!/bin/bash
set -euo pipefail
cd /workspace/d1probe
cleanup() {
 if test -s /workspace/d1probe/clock_uuid; then nvidia-smi -i "$(cat /workspace/d1probe/clock_uuid)" -rgc > /workspace/d1probe/results/clock-reset2.txt 2>&1 || true; fi
 touch /workspace/d1probe/done2
}
trap cleanup EXIT
export PATH=/workspace/d1probe/.venv/bin:$PATH
mkdir -p source2
tar -xf source2.tar -C source2
python -m pip install --disable-pip-version-check pytest-cov > results/install-repair.log 2>&1
export CUBLAS_WORKSPACE_CONFIG=:4096:8
export D1_SOURCE_SHA=2c53b0a514f6a8e594eac2ca9da9dd0edfdc37b2
export PYTHONPATH=/workspace/d1probe/source2:/workspace/d1probe/source2/src:/workspace/d1probe/source2/benchmarks/harness
cd source2
python -m pytest tests/test_issue842_checkpoint_visible_nf4.py tests/test_issue968_bnb_nf4_path_divergence.py -m gpu --no-cov -q > ../results/gpu-regressions2.log 2>&1
cd ..
python source2/benchmarks/harness/d1_final_f1.py prepare --data fixture2 --output results/prepare2
cp fixture2/correctness.json results/prepare2/
cp fixture2/native.pt fixture2/candidate.pt results/prepare2/
cp -r fixture2/resident-gate results/prepare2/
python source2/benchmarks/harness/d1_final_f1.py run --data fixture2 --output results/f1
python -m pip freeze > results/packages-final.txt
