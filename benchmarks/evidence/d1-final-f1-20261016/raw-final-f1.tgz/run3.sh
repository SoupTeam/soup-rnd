#!/bin/bash
set -euo pipefail
cd /workspace/d1probe
trap 'touch /workspace/d1probe/done3' EXIT
export PATH=/workspace/d1probe/.venv/bin:$PATH
mkdir -p source3
tar -xf source3.tar -C source3
export CUBLAS_WORKSPACE_CONFIG=:4096:8
export D1_SOURCE_SHA=28c4415f0b515a13e211e6b2a9839b0d5f3f6b16
export PYTHONPATH=/workspace/d1probe/source3/benchmarks/harness:/workspace/d1probe/source2/benchmarks/harness:/workspace/d1probe/source2:/workspace/d1probe/source2/src:/workspace/d1probe/source2/tests
test -e done2
python source3/benchmarks/harness/d1_final_f1.py run --data fixture2 --output results/f1b
python -m pip freeze > results/packages-final.txt
