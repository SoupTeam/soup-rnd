"""Freeze an ungated pretrained Llama 7B; no quality dataset claim."""
import hashlib
import json
from pathlib import Path

import torch
import yaml
from huggingface_hub import snapshot_download
from safetensors.torch import save_file

root = Path('/root/liger')
revision = 'e5961def23172a2384543940e773ab676033c963'
base = Path(snapshot_download('openlm-research/open_llama_7b_v2', revision=revision,
    allow_patterns=['*.json','*.model','*.bin','README.md'], local_dir=str(root/'model')))
# The upstream snapshot is .bin; Soup streaming requires safetensors.
# Convert one shard at a time with weights_only=True; preserve names/dtypes exactly.
index = json.loads((base/'pytorch_model.bin.index.json').read_text())
mapping = {}
for name in sorted(set(index['weight_map'].values())):
    state = torch.load(base/name, map_location='cpu', weights_only=True)
    new = name.replace('pytorch_model','model').replace('.bin','.safetensors')
    save_file({k:v.contiguous() for k,v in state.items()}, str(base/new), metadata={'format':'pt'})
    mapping.update({k:new for k in state})
    del state
(base/'model.safetensors.index.json').write_text(json.dumps(
    {'metadata':index['metadata'],'weight_map':mapping},indent=2))
manifest = {'model_id':'openlm-research/open_llama_7b_v2','revision':revision,
    'conversion':'torch.load weights_only + safetensors, unchanged names/dtypes', 'files':{}}
for file in sorted(base.iterdir()):
    if file.is_file():
        digest = hashlib.sha256()
        with file.open('rb') as handle:
            for chunk in iter(lambda:handle.read(4*1024*1024), b''):
                digest.update(chunk)
        manifest['files'][file.name] = {'bytes':file.stat().st_size,'sha256':digest.hexdigest()}
(root/'results/model-manifest.json').write_text(json.dumps(manifest,indent=2))
data = root/'train.jsonl'
with data.open('w') as handle:
    for number in range(32):
        row = {'messages':[{'role':'user','content':f'Calculate {number} + 1 and explain briefly.'},
            {'role':'assistant','content':(f'{number} + 1 = {number+1}. Add one to the number. ' * 160)}]}
        handle.write(json.dumps(row)+'\n')
config = {'base':str(base),'task':'sft','backend':'transformers',
    'data':{'train':str(data),'format':'chatml','chat_template':'chatml',
            'val_split':0,'max_length':1024},
    'training':{'seed':792,'batch_size':1,'gradient_accumulation_steps':2,'epochs':1,
        'lr':.00002,'warmup_ratio':0,'quantization':'none','stream_layers':True,
        'stream_source':'ram','stream_buffers':2,'stream_read_ahead':2,'stream_pin':True,
        'stream_vram_probe':False,'gradient_checkpointing':True,'fast_lora':False,
        'lora':{'r':4,'alpha':4,'dropout':0,'target_modules':
            ['q_proj','k_proj','v_proj','o_proj','gate_proj','up_proj','down_proj']}}}
(root/'soup.yaml').write_text(yaml.safe_dump(config))
(root/'results/soup.yaml').write_text(yaml.safe_dump(config))
(root/'results/train.jsonl').write_bytes(data.read_bytes())
(root/'results/data-scope.json').write_text(json.dumps({'rows':32,
    'scope':'synthetic arithmetic smoke, no task quality evidence',
    'max_length_is_cap_not_fixed_sequence_length':True,'content_repeated_to_exceed_1024':True,
    'sha256':hashlib.sha256(data.read_bytes()).hexdigest()},indent=2))

config['data']['max_length']=1024
(root/'parity.yaml').write_text(yaml.safe_dump(config))
(root/'results/parity.yaml').write_text(yaml.safe_dump(config))
