"""Run the published research entry module without modifying Soup imports."""
import runpy

runpy.run_module('benchmarks.harness.streaming_residency_bench',run_name='__main__')
