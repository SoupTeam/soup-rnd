"""Audit every timed process against its own lease telemetry."""
import json
from pathlib import Path

from rich.console import Console

ROOT=Path(__file__).parent
d=json.loads((ROOT/'independent-analysis.json').read_text())
paths={}
for receipt in sorted(ROOT.glob('bundle-*-verified.json'),key=lambda p:json.loads(p.read_text())['unix']):
    name=json.loads(receipt.read_text())['name'];folder=ROOT/'bundles'/name/'retained'
    manifest=json.loads((folder/'original-files.json').read_text())
    for relative in manifest['files']:paths[relative]=folder/relative
telemetry=[]
if 'results/gpu-telemetry.jsonl' in paths:
    for line in paths['results/gpu-telemetry.jsonl'].read_text().splitlines():
        try:telemetry.append(json.loads(line))
        except json.JSONDecodeError:pass
state=json.loads((ROOT/'remote-progress.json').read_text())
stages={row['name']:row for row in state['stages']}
rows=[]
for process in d['timing_environment']:
    stage=stages[process['path'].split('/')[-1]]
    start=stage['started_unix']
    end=start+stage['seconds']
    samples=[r for r in telemetry if start<=r['unix']<end]
    peers=[];clocks=[];temperatures=[];device_memory=[]
    for sample in samples:
        peers.append(len([line for line in sample.get('processes','').splitlines()
                          if line.strip() and line.lstrip()[0].isdigit()]))
        for line in sample.get('gpu','').splitlines():
            parts=[value.strip() for value in line.split(',')]
            if len(parts)>=5:
                try:clocks.append(float(parts[2].split()[0]));temperatures.append(float(parts[4]))
                except ValueError:pass
            if len(parts)>=7:
                try:device_memory.append(float(parts[6].split()[0])*2**20)
                except ValueError:pass
    rows.append({'path':process['path'],'affinity':process['affinity'],
        'samples':len(samples),'whole_process_samples_not_step_window_only':True,
        'max_sampled_compute_peers':max(peers,default=None),
        'sm_clock_mhz_range':[min(clocks),max(clocks)] if clocks else None,
        'maximum_temperature_C':max(temperatures,default=None),
        'maximum_sampled_device_memory_bytes':max(device_memory,default=None),
        'device_memory_samples_include_context_not_exact_step_peaks':True})
eligible=all(len(row['affinity'])==4 and row['samples'] and row['max_sampled_compute_peers']<=1 for row in rows)
assert not eligible, 'The replacement decision must retain the observed failed audit'
assert len({tuple(row['affinity']) for row in rows})<=1
out={'processes':rows,'count':len(rows),'same_four_core_affinity':True,
     'sampled_compute_peers_at_most_one':False,'one_gpu_offer_not_whole_host_exclusivity':True,
     'timing_eligible':False,'timing_status':'VOID_EXTERNAL_GPU_COMPUTE_PEERS',
     'maximum_sampled_compute_peers':max(row['max_sampled_compute_peers'] for row in rows),
     'no_memory_binding_claim':True,'samples_cover_whole_process_not_just_timing':True}
(ROOT/'timing-environment-audit.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
d['environment_audit']=out
d['timing_interpretation_status']='VOID_EXTERNAL_GPU_COMPUTE_PEERS'
for row in d['performance'].values():
    row['timing_environment_passed']=False
    row['practical_speed_gate_passed']=False
(ROOT/'independent-analysis.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
(ROOT.parent.parent/'benchmarks/streaming-residency-flashattention-fast-pcie-results-20261020.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
Console().print({'audited_processes':len(rows),'same_affinity':True,'timing_eligible':False,
                'maximum_compute_peers':out['maximum_sampled_compute_peers']})
