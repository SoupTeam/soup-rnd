"""Encrypted tensor bundles and authenticated status; never expose credentials."""
import gzip,hashlib,hmac,http.server,json,os,shutil,subprocess,sys,tarfile,time
from pathlib import Path
ROOT=Path('/root/liger');EXPORT=ROOT/'exports'

def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for data in iter(lambda:f.read(8*1024*1024),b''):h.update(data)
 return h.hexdigest()

def pack(name,selection):
 from cryptography.hazmat.primitives.ciphers.aead import AESGCM
 secrets=json.loads((ROOT/'transfer-secrets.json').read_text());cipher=AESGCM(bytes.fromhex(secrets['key']))
 EXPORT.mkdir(exist_ok=True);staging=ROOT/('export-'+name);staging.mkdir(exist_ok=False)
 records={};seen={}
 live={'results/progress.json','results/gpu-telemetry.jsonl'}
 selection=sorted(set(selection)|{relative for relative in live if (ROOT/relative).is_file()})
 for relative in selection:
  original=ROOT/relative
  if not original.is_file() or original.is_symlink():raise RuntimeError('Invalid artifact '+relative)
  target=staging/relative;target.parent.mkdir(parents=True,exist_ok=True)
  if relative in live or original.stat().st_size <= 10*1024*1024:
   shutil.copyfile(original,target);value=digest(target);size=target.stat().st_size
   records[relative]={'sha256':value,'bytes':size,'snapshot_of_live_file':True}
  else:
   value=digest(original);size=original.stat().st_size
   records[relative]={'sha256':value,'bytes':size}
  key=(size,value)
  if relative in live or original.stat().st_size <= 10*1024*1024:seen.setdefault(key,target)
  else:os.link(seen.setdefault(key,original),target)
 manifest={'files':records,'lossless_hardlinks':True,'source_sha256':digest(ROOT/'source.tar.gz')}
 (staging/'original-files.json').write_text(json.dumps(manifest,indent=2))
 archive=ROOT/(name+'.tar.gz')
 subprocess.run(['tar','-I','gzip -1','-cf',str(archive),'-C',str(staging),'.'],check=True,timeout=600)
 subprocess.run(['tar','-tzf',str(archive)],stdout=subprocess.DEVNULL,check=True,timeout=180)
 index={'name':name,'archive_bytes':archive.stat().st_size,'archive_sha256':digest(archive),'chunks':[],'encrypted':'AES-256-GCM, independent random nonce per 1MiB record'}
 with archive.open('rb') as f:
  for number,data in enumerate(iter(lambda:f.read(1024*1024),b'')):
   nonce=os.urandom(12);encoded=cipher.encrypt(nonce,data,None);filename=f'{name}-{number:04}.enc'
   (EXPORT/filename).write_bytes(encoded)
   index['chunks'].append({'filename':filename,'nonce':nonce.hex(),'bytes':len(encoded),'sha256':hashlib.sha256(encoded).hexdigest()})
 temporary=EXPORT/(name+'.tmp');temporary.write_text(json.dumps(index,indent=2));temporary.replace(EXPORT/(name+'.json'))
 (ROOT/'results'/('bundle-'+name+'.json')).write_text(json.dumps(index,indent=2))
 return index

def serve():
 secrets=json.loads((ROOT/'transfer-secrets.json').read_text())
 class Handler(http.server.SimpleHTTPRequestHandler):
  def __init__(self,*a,**kw):super().__init__(*a,directory=str(EXPORT),**kw)
  def end_headers(self):
   self.send_header('Cache-Control','no-store');super().end_headers()
  def do_GET(self):
   if not hmac.compare_digest(self.headers.get('Authorization',''),'Bearer '+secrets['token']):self.send_error(403);return
   name=self.path.lstrip('/')
   if name in ['progress.json','guard.json']:
    path=ROOT/'results/progress.json' if name=='progress.json' else ROOT/'guard-status.json'
    if not path.exists():self.send_error(404);return
    data=path.read_bytes();self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data);return
   if name=='setup-status.json':
    data=json.dumps({'setup_exited':(ROOT/'setup.exited').exists(),'worker_exited':(ROOT/'worker.exited').exists(),'progress_exists':(ROOT/'results/progress.json').exists()}).encode();self.send_response(200);self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data);return
   if '/' in name or '..' in name or not name.endswith(('.enc','.json')):self.send_error(404);return
   super().do_GET()
  def do_POST(self):
   if not hmac.compare_digest(self.headers.get('Authorization',''),'Bearer '+secrets['token']):self.send_error(403);return
   name=self.path.removeprefix('/ack/')
   if not self.path.startswith('/ack/') or not name or any(c not in 'abcdefghijklmnopqrstuvwxyz0123456789-_' for c in name):self.send_error(404);return
   (ROOT/('ack-'+name)).touch();self.send_response(200);self.send_header('Content-Length','2');self.end_headers();self.wfile.write(b'OK')
  def log_message(self,*a):pass
 class Server(http.server.ThreadingHTTPServer):request_queue_size=32
 EXPORT.mkdir(exist_ok=True);Server(('0.0.0.0',18080),Handler).serve_forever()

if __name__=='__main__':serve()
