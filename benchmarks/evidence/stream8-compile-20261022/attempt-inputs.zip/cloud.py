"""Exact-instance lease utilities for a fresh standalone USD5 study."""
import base64
import hashlib
import http.client
import json
import os
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).parent
LABEL = 'stream8-compile-20261022-a'
SSH_KEY = Path(r'C:\Users\esenb\.codex\tmp\soup-d2-vast-20261012\d2-ssh-20261012')


def save(name, value):
    target = ROOT / name
    temp = target.with_suffix('.tmp')
    temp.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
    temp.replace(target)


def _api_once(path, method='GET', payload=None):
    key = Path(r'C:\Users\esenb\.config\vastai\vast_api_key').read_text().strip()
    req = urllib.request.Request('https://console.vast.ai' + path, method=method,
        data=json.dumps(payload).encode() if payload is not None else None,
        headers={'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json'})
    try:
        with urllib.request.urlopen(req, timeout=30) as response:
            return json.load(response)
    except urllib.error.HTTPError as error:
        message=error.read().decode(errors='replace').replace(key,'[redacted]')[:500]
        raise RuntimeError('Vast HTTP status ' + str(error.code)+': '+message) from None


def api(path, method='GET', payload=None):
    readonly = method == 'GET' or (method == 'POST' and path == '/api/v0/bundles/')
    attempts = 3 if readonly else 1
    for attempt in range(attempts):
        try:
            return _api_once(path, method, payload)
        except (TimeoutError, urllib.error.URLError, http.client.IncompleteRead,
                ConnectionError, json.JSONDecodeError) as error:
            if attempt == attempts - 1:
                raise
        except RuntimeError as error:
            transient = any(str(error).startswith('Vast HTTP status '+str(code)+':')
                            for code in [429,500,502,503,504])
            if not readonly or not transient or attempt == attempts - 1:
                raise
        save('api-read-retry-last.json', {'path': path, 'attempt': attempt+1,
                                        'unix': time.time()})
        time.sleep(2 ** attempt)


def rows():
    result, token = [], None
    while True:
        path = '/api/v1/instances/?limit=25'
        if token:
            import urllib.parse
            path += '&after_token=' + urllib.parse.quote(token)
        reply = api(path)
        result.extend(reply['instances'])
        token = reply.get('next_token')
        if not token:
            return result


def receipt():
    return json.loads((ROOT / 'vast-rental.json').read_text())


def own():
    policy = receipt()
    return next((row for row in rows() if row['id'] == policy['instance_id']), None)


def ssh_args():
    connection = json.loads((ROOT / 'vast-connection.json').read_text())
    return ['ssh', '-T', '-i', str(SSH_KEY), '-o', 'BatchMode=yes', '-o',
        'StrictHostKeyChecking=accept-new', '-o', 'ConnectTimeout=12', '-o',
        'ServerAliveInterval=15', '-o', 'LogLevel=ERROR', '-p', str(connection['port']),
        'root@' + connection['host']]


def ssh(command, timeout=40, stdin=None):
    return subprocess.run(ssh_args() + [command], stdin=stdin or subprocess.DEVNULL,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)


def destroy(reason):
    policy = receipt()
    identity = policy['instance_id']
    for attempt in range(18):
        try:
            row = own()
            if row is None:
                save('vast-deletion.json', {'instance_id': identity,
                    'verified_absent': True, 'unix': time.time(), 'reason': reason})
                (ROOT / 'vast-finished').touch()
                return
            if row.get('label') != LABEL:
                raise RuntimeError('Refusing deletion: label mismatch')
            api(f'/api/v0/instances/{identity}/', 'DELETE', {})
        except Exception as error:
            save('vast-cleanup-retry.json', {'attempt': attempt, 'error': str(error)})
        time.sleep(5)
    raise RuntimeError('Deletion unverified; independent guards remain active')


def main():
    action = sys.argv[1]
    if action == 'guard':
        while not (ROOT / 'vast-finished').exists():
            policy = receipt()
            if time.time() >= policy['created_unix'] + policy['maximum_seconds']:
                destroy('independent local impact time/budget guard')
                return
            time.sleep(5)
        return
    if action == 'allocate':
        if (ROOT / 'vast-rental.json').exists() or any(r.get('label') == LABEL for r in rows()):
            raise RuntimeError('Existing lease or receipt; no duplicate allocation')
        credit = api('/api/v0/users/current/')['credit']
        if credit <= .12:
            raise RuntimeError('Insufficient credit for authorized run')
        offers=json.loads((ROOT/'offers.json').read_text())['offers']
        offers=[o for o in offers if o['id']==55024348]
        if not offers: raise RuntimeError('No eligible preselected offer')
        offer=offers[0]
        offer['dph_total'] += 200 * offer['storage_cost'] / 720
        save('vast-selected-offer.json',offer)
        prior=0
        maximum_seconds=28800
        reserve=180*offer['inet_down_cost']+48*offer['inet_up_cost']+.45
        if maximum_seconds*offer['dph_total']/3600+reserve+prior>4.85:
            raise RuntimeError('Lease cannot fit cumulative USD10 cap with reserves')
        if maximum_seconds*offer['dph_total']/3600+reserve > credit: raise RuntimeError('Account credit below bounded rental allowance')
        policy={'created_unix':time.time(),'maximum_usd':5,'prior_usd':prior,
            'maximum_seconds':maximum_seconds,'label':LABEL,'hourly_usd':offer['dph_total'],
            'down_usd_per_gb':offer['inet_down_cost'],'up_usd_per_gb':offer['inet_up_cost'],
            'source_commit':'d500ae0dca7c4da905f8d59c9866af2f8aaa824b+research-harness',
            'source_sha256':hashlib.sha256((ROOT/'source.tar.gz').read_bytes()).hexdigest()}
        guard = base64.b64encode((ROOT/'remote_guard.py').read_bytes()).decode()
        encoded = base64.b64encode(json.dumps(policy).encode()).decode()
        onstart = ('mkdir -p /root/liger/results\necho ' + encoded +
            ' | base64 -d > /root/liger/policy.json\necho ' + guard +
            ' | base64 -d > /root/liger/remote_guard.py\n'
            'nohup python3 /root/liger/remote_guard.py > /root/liger/guard.log 2>&1 < /dev/null &\n'
            'entrypoint.sh')
        save('vast-allocation-intent.json', policy)
        try:
            response = api(f"/api/v0/asks/{offer['id']}/", 'PUT', {
                'client_id': 'me', 'image': 'vastai/base-image:cuda-12.9-mini-py312-2026-09-07',
                'disk': 200, 'runtype': 'ssh_direc ssh_proxy', 'cancel_unavail': True,
                'label': LABEL, 'onstart': onstart, 'env': {'-p 18080:18080':'1'}, 'price': None,
                'force': False, 'template_hash_id': None})
            save('creation-response.json',{k:response[k] for k in ('success','new_contract','msg','error') if k in response})
            if not response.get('success') or not response.get('new_contract'):
                raise RuntimeError('Creation not confirmed')
            policy['instance_id'] = response['new_contract']
        except Exception as error:
            save('creation-error.json',{'error':str(error),'unix':time.time()})
            matches = [r for r in rows() if r.get('label') == LABEL]
            if len(matches) != 1:
                raise RuntimeError('Unknown creation outcome: reconcile label before retry') from None
            policy['instance_id'] = matches[0]['id']
        save('vast-rental.json', policy)
        child = subprocess.Popen([sys.executable, str(__file__), 'guard'],
            creationflags=subprocess.CREATE_NO_WINDOW,
            stdout=(ROOT/'local-guard.log').open('w'), stderr=subprocess.STDOUT)
        save('vast-local-guard.json', {'pid': child.pid})
        sys.stdout.write(json.dumps(policy) + '\n')
    elif action == 'status':
        row = own()
        safe = {k: row.get(k) for k in ('id','label','actual_status','status_msg','gpu_name',
            'dph_total','start_date','disk_space','cpu_ram')} if row else {'absent': True}
        if row and row.get('ports', {}).get('22/tcp'):
            save('vast-connection.json', {'host': row['public_ipaddr'],
                'port': row['ports']['22/tcp'][0]['HostPort']})
            safe['ssh_port_ready'] = True
        if row and row.get('ports', {}).get('18080/tcp'):
            save('http-connection.json', {'host': row['public_ipaddr'],
                'port': row['ports']['18080/tcp'][0]['HostPort']})
            safe['artifact_port_ready'] = True
        save('vast-status.json', safe)
        sys.stdout.write(json.dumps(safe) + '\n')
    elif action == 'ssh':
        result = ssh(sys.argv[2], int(sys.argv[3]) if len(sys.argv)>3 else 40)
        sys.stdout.buffer.write(result.stdout)
        sys.stderr.buffer.write(result.stderr)
        raise SystemExit(result.returncode)
    elif action == 'upload':
        name = sys.argv[2]
        with (ROOT/name).open('rb') as source:
            result = ssh('cat > /root/liger/' + name, 300, source)
        if result.returncode:
            raise RuntimeError('Upload failed')
    elif action == 'collect':
        result = ssh('tar -czf /root/liger/results.tar.gz -C /root/liger results policy.json guard-status.json guard.log', 900)
        if result.returncode:
            raise RuntimeError(result.stderr.decode(errors='replace'))
        digest = ssh('sha256sum /root/liger/results.tar.gz', 30).stdout.decode().split()[0]
        with (ROOT/'gpu-results.tar.gz').open('wb') as target:
            response = subprocess.run(ssh_args()+['cat /root/liger/results.tar.gz'],
                stdin=subprocess.DEVNULL, stdout=target, stderr=subprocess.PIPE, timeout=1800)
        if response.returncode or hashlib.sha256((ROOT/'gpu-results.tar.gz').read_bytes()).hexdigest()!=digest:
            raise RuntimeError('Result transfer/hash check failed')
        save('gpu-results.sha256.json', {'sha256': digest, 'bytes': (ROOT/'gpu-results.tar.gz').stat().st_size})
        sys.stdout.write('Results downloaded and SHA-256 verified\n')
    elif action == 'delete':
        destroy('operator cleanup after artifact download')


if __name__ == '__main__':
    main()
