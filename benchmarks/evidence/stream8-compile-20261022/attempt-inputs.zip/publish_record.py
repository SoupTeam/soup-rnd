"""Create a compact public record; private provider responses stay ignored."""
import ast
import hashlib
import json
import time
import zipfile
from pathlib import Path

ROOT = Path(__file__).parent
REPO = ROOT.parent.parent
NAME = "stream8-compile-20261022"
PUBLIC = REPO / "benchmarks/evidence" / NAME
PUBLIC.mkdir(parents=True, exist_ok=True)


def read(name):
    return json.loads((ROOT / name).read_text())


def encoded(value):
    return (json.dumps(value, indent=2) + "\n").encode()


diagnostics = {
    name: read(name) for name in (
        "network-preflight.json", "capacity-preflight.json", "gpu-idle-preflight.json",
        "current-source-audit.json", "final-instance-absence.json", "final-budget.json",
        "vast-deletion.json", "controller-error.json", "post-transfer-guard.json",
        "remote-guard-before-setup.json", "reconciled-creation.json",
    )
}
budget = diagnostics["final-budget.json"]
assert budget["conservative_spend_usd"] < 5
assert not diagnostics["final-instance-absence.json"]["active_task_instance_ids"]
assert diagnostics["network-preflight.json"]["sha256_verified"]
assert not diagnostics["network-preflight.json"]["passed"]
summary = {
    "study": NAME, "status": "BLOCKED_BEFORE_MODEL_WORK",
    "upstream": "d500ae0dca7c4da905f8d59c9866af2f8aaa824b",
    "pr_head_before_study": "a3b5c71310703ff3b05195c5add9422d51f5414f",
    "instance_id": 57114362, "label": "stream8-compile-20261022-a",
    "accuracy_verdict": None, "performance_verdict": None, "memory_verdict": None,
    "largest_model_tested": None, "gpu_tests_run": 0, "model_weights_downloaded": False,
    "training_updates": 0, "timing_processes": 0, "compilation_executed": False,
    "arms": {arm: {"status": "NOT_EXECUTED_TRANSPORT_BLOCKER"} for arm in (
        "ordinary_streaming", "persistent_residency", "resident_inductor_default",
        "resident_inductor_precise",
    )},
    "models": {size: {"status": "NOT_TESTED"} for size in ("8B", "14B", "24B", "32B")},
    "initial_offer_unavailable": {"offer_id": 56602875, "error": "no_such_ask",
                                  "instance_created": False, "label_reconciled_empty": True},
    "blocker": "Authenticated binary SSH retention below unchanged 2MiB/s preflight threshold",
    "transport": diagnostics["network-preflight.json"],
    "physical_preflight": diagnostics["capacity-preflight.json"],
    "budget": budget, "cleanup": diagnostics["final-instance-absence.json"],
    "cpu_tests": {"passed": 14, "cuda_skipped": 2, "torch": "2.13.0+cpu",
                  "python": "3.10", "inductor_gpu_validated": False},
    "source": diagnostics["current-source-audit.json"],
    "time_recorded_unix": time.time(),
}
(REPO / "benchmarks" / (NAME + "-results.json")).write_bytes(encoded(summary))
for name, value in diagnostics.items():
    (PUBLIC / name).write_bytes(encoded(value))

# Exact executed controllers are retained as text inside a compact archive.
# No API responses, connection IPs, key values, or transfer secrets are published.
inputs = ["cloud.py", "controller.py", "transport.py", "remote_guard.py",
          "worker.py", "setup.sh", "prepare_model.py", "entry.py", "constraints.txt",
          "pin_entry.py", "pytest_gpu_entry.py", "telemetry.py", "extract_verified.py",
          "artifacts.py", "protocol.json", "publish_record.py"]
with zipfile.ZipFile(PUBLIC / "attempt-inputs.zip", "w", zipfile.ZIP_DEFLATED) as archive:
    for name in inputs:
        archive.writestr(name, (ROOT / name).read_bytes())

# The source comparator is identical to the already committed planned overlay.
old = REPO / "benchmarks/evidence/streaming-residency-compile-8gb-20261021/planned-harness.zip"
with zipfile.ZipFile(old) as archive:
    member = next(name for name in archive.namelist() if name.endswith("liger_streaming_parity.py"))
    module = ast.parse(archive.read(member))
    comparator = next(node for node in module.body
                      if isinstance(node, ast.FunctionDef) and node.name == "compare")
    assert hashlib.sha256(ast.dump(comparator).encode()).hexdigest() == summary["source"]["comparator_ast_sha256"]

manifest = {
    path.name: {"bytes": path.stat().st_size,
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
    for path in PUBLIC.iterdir() if path.is_file() and path.name != "manifest.json"
}
(PUBLIC / "manifest.json").write_bytes(encoded(manifest))
