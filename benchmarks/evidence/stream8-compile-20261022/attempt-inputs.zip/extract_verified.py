"""Hash every exported payload, reusing verified identical files while streaming."""
import hashlib
import json
import os
import tarfile
import time
from pathlib import Path, PurePosixPath

from rich.console import Console

CACHE={}
def digest(path):
    stat=path.stat();key=(stat.st_dev,stat.st_ino,stat.st_size,stat.st_mtime_ns)
    if key not in CACHE:
        h=hashlib.sha256()
        with path.open('rb') as handle:
            for data in iter(lambda:handle.read(8*1024*1024),b''):h.update(data)
        CACHE[key]=h.hexdigest()
    return CACHE[key]

def relative(name):
    assert '\\' not in name and ':' not in name
    path=PurePosixPath(name)
    assert not path.is_absolute() and '..' not in path.parts
    return str(path)

def within(root,path):
    assert os.path.commonpath([os.path.realpath(root),os.path.realpath(path)])==os.path.realpath(root)

def existing_index(base):
    known={}
    for study in base.glob('residency*'):
        for receipt in study.glob('bundle-*-verified.json'):
            folder=study/'bundles'/json.loads(receipt.read_text())['name']/'retained'
            manifest=json.loads((folder/'original-files.json').read_text())
            for name,row in manifest['files'].items():
                path=folder/name;within(study,path)
                known.setdefault((row['bytes'],row['sha256']),path)
    return known

def extract(root,name):
    folder=root/'bundles'/name;within(root,folder)
    archive=folder/'results.tar.gz'
    index=json.loads((folder/'index.json').read_text())
    assert archive.stat().st_size==index['archive_bytes']
    assert digest(archive)==index['archive_sha256']
    with tarfile.open(archive,'r:gz') as source:
        entry=next(item for item in source.getmembers() if relative(item.name)=='original-files.json')
        raw_manifest=source.extractfile(entry).read()
    manifest=json.loads(raw_manifest)
    known=existing_index(root.parent)
    retained=folder/'retained';retained.mkdir(exist_ok=True)
    seen={};deduplicated=0;written=0
    with tarfile.open(archive,'r|gz') as source:
        for item in source:
            name_in_archive=relative(item.name)
            target=retained/name_in_archive;within(retained,target)
            if item.isdir():target.mkdir(parents=True,exist_ok=True);continue
            assert not item.issym() and (item.isfile() or item.islnk())
            target.parent.mkdir(parents=True,exist_ok=True)
            if name_in_archive=='original-files.json':
                data=source.extractfile(item).read();assert data==raw_manifest
                target.write_bytes(data);continue
            expected=manifest['files'][name_in_archive]
            key=(expected['bytes'],expected['sha256'])
            original=known.get(key)
            if original is not None:
                assert original.stat().st_size==key[0] and digest(original)==key[1]
            if item.islnk():
                link=relative(item.linkname)
                assert link in seen and seen[link]==key
                original=retained/link
            else:
                assert item.size==key[0]
                if original is None and target.is_file() and target.stat().st_size==key[0]:
                    if digest(target)==key[1]:original=target
                temporary=target.with_name(target.name+'.stream-incoming')
                within(retained,temporary)
                handle=temporary.open('wb') if original is None else None
                hashed=hashlib.sha256();count=0
                try:
                    stream=source.extractfile(item)
                    for data in iter(lambda:stream.read(8*1024*1024),b''):
                        hashed.update(data);count+=len(data)
                        if handle is not None:handle.write(data)
                finally:
                    if handle is not None:handle.close()
                assert count==key[0] and hashed.hexdigest()==key[1],name_in_archive
                if original is None:
                    os.replace(temporary,target);written+=key[0]
            if original is not None and not (target.exists() and os.path.samefile(target,original)):
                temporary=target.with_name(target.name+'.verified-identical-hardlink')
                within(retained,temporary);assert not temporary.exists()
                os.link(original,temporary);os.replace(temporary,target)
                deduplicated+=key[0]
            assert target.stat().st_size==key[0] and digest(target)==key[1],name_in_archive
            known.setdefault(key,target);seen[name_in_archive]=key
    assert set(seen)==set(manifest['files'])
    return {'all_original_files_verified':len(seen),'deduplicated_bytes':deduplicated,
            'new_payload_bytes_written':written,'archive_sha256':index['archive_sha256'],
            'archive_bytes':index['archive_bytes']}

if __name__=='__main__':
    root=Path(__file__).parent.with_name('residency-fa-clean-vast-20261020')
    name='qualification-hybrid-r16';start=time.time()
    result=extract(root,name)
    receipt={'name':name,'archive_bytes':result['archive_bytes'],'sha256':result['archive_sha256'],
        'all_original_files_verified':result['all_original_files_verified'],'unix':time.time(),
        'seconds':time.time()-start,'recovered_after_local_disk_extraction_failure':True,
        'remote_acknowledgement_sent':False,'authenticated_chunks_and_canonical_archive_preserved':True}
    (root/('bundle-'+name+'-verified.json')).write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    (root/'artifact-extraction-recovery.json').write_text(json.dumps(result|receipt,indent=2),encoding='utf-8')
    folder=root/'bundles'/name
    count=len(json.loads((folder/'index.json').read_text())['chunks'])
    for number in range(count):
        for suffix in ['.part','.verified']:
            path=folder/f'{number:04}{suffix}';within(folder,path);path.unlink(missing_ok=True)
    Console().print(result|{'recovered':True,'seconds':time.time()-start})
