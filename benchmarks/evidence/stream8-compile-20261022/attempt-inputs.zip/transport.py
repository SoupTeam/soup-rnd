"""Authenticated binary SSH with a large receive window and hash-checked retention."""
import hashlib
import json
import re
import subprocess
import time
from pathlib import Path

import paramiko
from rich.console import Console

import cloud

ROOT = Path(__file__).parent


def log(value):
    Console().print(value)


def digest(path):
    hashed = hashlib.sha256()
    with path.open('rb') as source:
        for data in iter(lambda: source.read(8 * 1024 * 1024), b''):
            hashed.update(data)
    return hashed.hexdigest()


def connect():
    connection = json.loads((ROOT / 'vast-connection.json').read_text())
    # OpenSSH first-use records the host key; Paramiko requires that exact trusted key.
    client = paramiko.SSHClient()
    client.load_system_host_keys()
    client.connect(connection['host'], port=int(connection['port']), username='root',
                   key_filename=str(cloud.SSH_KEY), timeout=15, banner_timeout=20,
                   auth_timeout=20, look_for_keys=False, allow_agent=False)
    return client


def stream(command, target, timeout=60):
    started = time.monotonic()
    count = 0
    with connect() as client:
        channel = client.get_transport().open_session(window_size=64 * 1024 * 1024,
                                                     max_packet_size=1024 * 1024)
        channel.settimeout(20)
        channel.exec_command(command)
        with channel.makefile('rb', 1024 * 1024) as source:
            while True:
                data = source.read(1024 * 1024)
                if not data:
                    break
                target.write(data)
                count += len(data)
                if time.monotonic() - started > timeout:
                    raise TimeoutError('binary artifact transfer deadline')
        code = channel.recv_exit_status()
        if code:
            raise RuntimeError('SSH command failed with code ' + str(code))
    return count


def ssh_retry(command, timeout=60, attempts=3):
    import io

    for attempt in range(attempts):
        try:
            sink = io.BytesIO()
            stream(command, sink, timeout)
            return subprocess.CompletedProcess(command, 0, sink.getvalue(), b'')
        except Exception:
            if attempt == attempts - 1:
                raise
            time.sleep(2)


def upload(name):
    assert re.fullmatch(r'[a-zA-Z0-9_.-]+', name)
    with connect() as client, client.open_sftp() as sftp:
        sftp.put(str(ROOT / name), '/root/liger/' + name)


def get(name, timeout=60, method='GET'):
    if name.startswith('ack/'):
        identifier = name.removeprefix('ack/')
        assert method == 'POST' and re.fullmatch(r'[a-z0-9_-]+', identifier)
        command = 'touch /root/liger/ack-' + identifier + '; printf OK'
    else:
        assert method == 'GET' and re.fullmatch(r'[a-z0-9_.-]+', name) and '..' not in name
        remote = {'progress.json': '/root/liger/results/progress.json',
                  'guard.json': '/root/liger/guard-status.json'}.get(
                      name, '/root/liger/exports/' + name)
        command = 'cat ' + remote
    return ssh_retry(command, timeout).stdout


def network_preflight():
    import io

    command = ("python3 -c \"from pathlib import Path;import hashlib,os,json;"
               "data=os.urandom(16*1024*1024);Path('/root/liger/ssh-probe.bin').write_bytes(data);"
               "print(json.dumps({'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}))\"")
    expected = json.loads(ssh_retry(command).stdout)
    started = time.perf_counter()
    sink = io.BytesIO()
    count = stream('cat /root/liger/ssh-probe.bin', sink, 90)
    elapsed = time.perf_counter() - started
    valid = count == expected['bytes'] and hashlib.sha256(sink.getvalue()).hexdigest() == expected['sha256']
    rate = count / 2**20 / elapsed
    proof = {'route': 'SSH Paramiko 64MiB receive window, 1MiB packet', 'bytes': count,
             'seconds': elapsed, 'aggregate_mib_per_second': rate,
             'minimum_mib_per_second': 2, 'sha256_verified': valid,
             'passed': valid and rate >= 2, 'unix': time.time(),
             'prospective_first_model_raw_bound_gib': 12,
             'prospective_transfer_seconds': 12 * 1024 / rate}
    cloud.save('network-preflight.json', proof)
    log(proof)
    assert proof['passed'], 'binary retention preflight failed before model work'


def download(name):
    from extract_verified import extract

    assert re.fullmatch(r'[a-z0-9_-]+', name)
    started = time.time()
    folder = ROOT / 'bundles' / name
    folder.mkdir(parents=True, exist_ok=True)
    index = json.loads(get(name + '.json'))
    (folder / 'index.json').write_text(json.dumps(index, indent=2))
    target = folder / 'results.tar.gz'
    offset = target.stat().st_size if target.exists() else 0
    deadline = cloud.receipt()['created_unix'] + cloud.receipt()['maximum_seconds'] - time.time() - 180
    rate = json.loads((ROOT / 'network-preflight.json').read_text())['aggregate_mib_per_second']
    if (index['archive_bytes'] - offset) / 2**20 / rate * 1.5 > deadline:
        raise RuntimeError('actual archive cannot fit retained transfer/cleanup reserve')
    with target.open('ab') as sink:
        stream(f'tail -c +{offset + 1} /root/liger/{name}.tar.gz', sink, deadline)
    assert target.stat().st_size == index['archive_bytes']
    assert digest(target) == index['archive_sha256']
    statistics = extract(ROOT, name)
    cloud.save('streaming-extraction-' + name + '.json', statistics)
    proof = {'name': name, 'archive_bytes': index['archive_bytes'],
             'sha256': index['archive_sha256'],
             'all_original_files_verified': statistics['all_original_files_verified'],
             'seconds': time.time() - started, 'unix': time.time(),
             'transport': 'authenticated SSH; canonical and original file hashes verified'}
    cloud.save('bundle-' + name + '-verified.json', proof)
    log(proof)
    assert get('ack/' + name, method='POST') == b'OK'
