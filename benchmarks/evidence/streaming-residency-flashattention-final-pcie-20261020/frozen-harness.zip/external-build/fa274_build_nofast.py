"""Build the exact FlashAttention commit vendored by pinned Torch2.8."""
import hashlib,json,os,subprocess,sys,time,traceback
from pathlib import Path
from rich.console import Console
r=Path('/root/liger');out=r/'results';source=r/'flash-attention-274-nofast';commit='979702c87a8713a8e0a5e9fee122b90d2ef13be5'
proof={'started_unix':time.time(),'source_commit':commit,'torch_vendored_source':'https://github.com/pytorch/pytorch/tree/v2.8.0/third_party/flash-attention','status':'STARTED','changes_to_kernel_source':False,'native_torch_arithmetic_macros':['UNFUSE_FMA','FLASHATTENTION_DISABLE_ALIBI','FLASHATTENTION_DISABLE_SOFTCAP']}
def run(args,timeout=120):
 Console().print({'build_command':args[:4]});subprocess.run(args,check=True,timeout=timeout,cwd=source if source.exists() else r)
try:
 import torch
 assert torch.__version__.startswith('2.8.0')
 run([sys.executable,'-m','pip','install','--no-deps','ninja==1.11.1.4'],120)
 run(['git','init',str(source)])
 run(['git','remote','add','origin','https://github.com/Dao-AILab/flash-attention.git'])
 run(['git','fetch','--depth','1','origin',commit],180)
 run(['git','checkout','--detach','FETCH_HEAD'])
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==commit
 run(['git','submodule','update','--init','--depth','1','csrc/cutlass'],240)
 proof['submodules']=subprocess.check_output(['git','submodule','status'],cwd=source,text=True)
 setup=source/'setup.py';before_setup=setup.read_bytes();needle_fast=b'"--use_fast_math",'
 assert before_setup.count(needle_fast)==1
 after_setup=before_setup.replace(needle_fast,b'')
 setup.write_bytes(after_setup)
 (out/'flash274-nofast-setup-before.py').write_bytes(before_setup)
 (out/'flash274-nofast-setup-after.py').write_bytes(after_setup)
 proof['build_script_change']='Remove the sole --use_fast_math nvcc flag; kernel sources unchanged'
 proof['setup_before_sha256']=hashlib.sha256(before_setup).hexdigest();proof['setup_after_sha256']=hashlib.sha256(after_setup).hexdigest()
 proof['setup_diff']=subprocess.check_output(['git','diff','--','setup.py'],cwd=source,text=True)
 proof['nvcc']=subprocess.check_output(['nvcc','--version'],text=True)
 env=os.environ.copy();env.update(FLASH_ATTENTION_FORCE_BUILD='TRUE',FLASH_ATTN_CUDA_ARCHS='80',TORCH_CUDA_ARCH_LIST='8.0',MAX_JOBS='20',NVCC_THREADS='1',NVCC_PREPEND_FLAGS='-DUNFUSE_FMA -DFLASHATTENTION_DISABLE_ALIBI -DFLASHATTENTION_DISABLE_SOFTCAP')
 env.pop('NVCC_APPEND_FLAGS',None)
 proof['build_env']={k:env[k] for k in ['FLASH_ATTENTION_FORCE_BUILD','FLASH_ATTN_CUDA_ARCHS','TORCH_CUDA_ARCH_LIST','MAX_JOBS','NVCC_THREADS','NVCC_PREPEND_FLAGS']}
 check=out/'flash274-nofast-macro-check.cu'
 check.write_text('#if !defined(UNFUSE_FMA) || !defined(FLASHATTENTION_DISABLE_ALIBI) || !defined(FLASHATTENTION_DISABLE_SOFTCAP)\n#error missing_native_macros\n#endif\nint native_flash_macros_enabled = 1;\n')
 checked=subprocess.run(['nvcc','-E','-x','cu',str(check)],env=env,capture_output=True,text=True,timeout=60)
 (out/'flash274-nofast-macro-check.log').write_text(checked.stdout+checked.stderr)
 assert checked.returncode==0 and 'native_flash_macros_enabled = 1' in checked.stdout
 proof['nvcc_prepend_macros_preprocessor_verified']=True
 wheels=r/'fa274-nofast-wheels';wheels.mkdir(exist_ok=True)
 command=[sys.executable,'-m','pip','wheel','--no-deps','--no-build-isolation','--wheel-dir',str(wheels),str(source)]
 child=subprocess.Popen(command,env=env)
 try:
  code=child.wait(timeout=2100)
  if code:raise subprocess.CalledProcessError(code,command)
 except BaseException:
  import psutil
  try:
   descendants=psutil.Process(child.pid).children(recursive=True)
   for process in reversed(descendants):
    try:process.kill()
    except psutil.NoSuchProcess:pass
  except psutil.NoSuchProcess:pass
  if child.poll() is None:child.kill()
  child.wait();raise
 choices=list(wheels.glob('flash_attn-*.whl'));assert len(choices)==1
 ninja_files=list((source/'build').rglob('build.ninja'));assert len(ninja_files)==1
 ninja_bytes=ninja_files[0].read_bytes();assert b'--use_fast_math' not in ninja_bytes
 (out/'flash274-nofast-build.ninja').write_bytes(ninja_bytes)
 proof['ninja_verified_no_use_fast_math']=True
 wheel=choices[0];h=hashlib.sha256()
 with wheel.open('rb') as f:
  for chunk in iter(lambda:f.read(8*1024*1024),b''):h.update(chunk)
 proof['wheel']={'name':wheel.name,'bytes':wheel.stat().st_size,'sha256':h.hexdigest()}
 os.link(wheel,out/('nofast-'+wheel.name));proof['retained_wheel']='results/nofast-'+wheel.name
 run([sys.executable,'-m','pip','install','--no-deps','--target',str(r/'fa274-nofast'),str(wheel)],120)
 proof.update(status='BUILT',seconds=time.time()-proof['started_unix'])
except BaseException as error:
 proof.update(status='FAILED',error=type(error).__name__+': '+str(error));(out/'flash274-nofast-build-error.log').write_text(traceback.format_exc());raise
finally:(out/'flash274-nofast-build-provenance.json').write_text(json.dumps(proof,indent=2))
