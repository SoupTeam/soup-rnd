"""Preserve the rejected optional diagnostic without invalidating completed timings."""
import json
from pathlib import Path

from rich.console import Console

ROOT=Path(__file__).parent
base=ROOT/'bundles/final/retained/results/training-kernel-profile'
window=json.loads((base/'exclusion-window.json').read_text())
log=(base/'profile.log').read_text()
assert window['profile_exit_code']==1
assert 'warmup must be >=1 and measured steps >=2' in log
assert not (base/'kernel-proof.json').exists()
d=json.loads((ROOT/'independent-analysis.json').read_text())
assert d['status']=='COMPLETE' and len(d['timing_environment'])==16
d['post_matrix_kernel_profile_attempt']={'status':'REJECTED_BY_UNCHANGED_INPUT_GUARD',
    'requested_measured_steps':1,'minimum_required_measured_steps':2,
    'no_model_training_in_this_diagnostic_attempt':True,
    'all16_matrix_timing_processes_completed_before_attempt':True,
    'unchanged_core_accuracy_and_performance_results':True,'failure_log_retained':True,
    'exclusion_window':window,
    'separate_registration':json.loads((base/'extra-kernel-proof-registration.json').read_text())}
(ROOT/'independent-analysis.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
(ROOT.parent.parent/'benchmarks/streaming-residency-flashattention-final-pcie-results-20261020.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
Console().print({'core_matrix_complete':True,'optional_profile_failed_input_guard':True,
    'failed_attempt_retained':True})
