"""Hardware qualification before model work; no attention or timing verdict."""
import json
import os
import statistics
from pathlib import Path

import torch

torch.set_num_threads(1)
size=256*1024*1024
source=torch.zeros(size,dtype=torch.uint8,pin_memory=True)
target=torch.empty(size,dtype=torch.uint8,device='cuda')
for _ in range(32):target.copy_(source,non_blocking=True)
torch.cuda.synchronize()
rates=[]
for _ in range(32):
    start=torch.cuda.Event(enable_timing=True);end=torch.cuda.Event(enable_timing=True)
    start.record();target.copy_(source,non_blocking=True);end.record();end.synchronize()
    rates.append(size/(start.elapsed_time(end)/1000)/1e9)
record={'scope':'separate hardware qualification before model capture/timing',
    'samples_GB_per_second':rates,'median_GB_per_second':statistics.median(rates),
    'minimum_required_GB_per_second':16,'passed':statistics.median(rates)>=16,
    'cpu_affinity':sorted(os.sched_getaffinity(0)),'copy_bytes':size,
    'no_attention_candidate_used':True}
Path('/root/liger/results/h2d-hardware-probe.json').write_text(json.dumps(record,indent=2))
assert record['passed'],'Actual pinned H2D bandwidth below confirmation-host requirement'
