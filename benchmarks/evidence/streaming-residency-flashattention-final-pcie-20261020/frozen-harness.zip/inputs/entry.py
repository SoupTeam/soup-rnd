import runpy
runpy.run_module('benchmarks.harness.streaming_residency_attention_bench',run_name='__main__')
