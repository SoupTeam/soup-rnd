"""Pause only the completed benchmark worker; independent budget guards stay live."""
import json
import os
import shutil
import signal
import subprocess
import time
from pathlib import Path

ROOT=Path('/root/liger');OUT=ROOT/'results/training-kernel-profile'
OUT.mkdir(parents=True,exist_ok=True)
state=json.loads((ROOT/'results/progress.json').read_text())
assert state['status'] not in ['COMPLETE','FAILED']
assert len(state['timings'])==16
assert all(len(rows)==4 and all(row['passed'] for row in rows) for rows in state['trajectory_checks'].values())
stages=[row for row in state['stages'] if row['name'].startswith('timing-')]
assert len(stages)==16
last=max(row['started_unix']+row['seconds'] for row in stages)
assert time.time()>last
policy=json.loads((ROOT/'policy.json').read_text())
guard=json.loads((ROOT/'guard-status.json').read_text())
assert guard['conservative_usd']<4.65 and policy['created_unix']+policy['maximum_seconds']-time.time()>600
matches=[]
for path in Path('/proc').glob('[0-9]*/cmdline'):
    try:args=path.read_bytes().rstrip(b'\0').split(b'\0')
    except (FileNotFoundError,PermissionError):continue
    if len(args)==3 and args[1:]==[b'/root/liger/pin_entry.py',b'/root/liger/worker.py']:
        matches.append(int(path.parent.name))
assert len(matches)==1,matches
pid=matches[0]
record={'timing_processes_complete_before_profile':16,'last_timing_finished_unix':last,
    'worker_pid':pid,'suspended_unix':time.time(),'budget_guards_not_suspended':True}
for name in ['profile_training_entry.py','profile_after_matrix_remote.py','extra-kernel-proof-registration.json']:
    shutil.copyfile(ROOT/name,OUT/name)
os.kill(pid,signal.SIGSTOP)
child=None
try:
    environment=os.environ.copy()
    environment.update(PYTHONPATH='/root/liger:/root/liger/repo:/root/liger/repo/src',
        CUDA_VISIBLE_DEVICES='0',PYTHONHASHSEED='0',USE_TF='0',TOKENIZERS_PARALLELISM='false',
        OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',CUBLAS_WORKSPACE_CONFIG=':4096:8',
        WANDB_DISABLED='true',FLASH_ATTENTION_DETERMINISTIC='1')
    with (OUT/'profile.log').open('w') as log:
        child=subprocess.Popen([str(ROOT/'venv/bin/python'),str(ROOT/'profile_training_entry.py')],
            cwd=ROOT/'repo',env=environment,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        try:record['profile_exit_code']=child.wait(timeout=180)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid,signal.SIGKILL);child.wait();record['profile_exit_code']='timeout'
finally:
    record['profile_finished_unix']=time.time()
    (OUT/'exclusion-window.json').write_text(json.dumps(record,indent=2))
    os.kill(pid,signal.SIGCONT)
