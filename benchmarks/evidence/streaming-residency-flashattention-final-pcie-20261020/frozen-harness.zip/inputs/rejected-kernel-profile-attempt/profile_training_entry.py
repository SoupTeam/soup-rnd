"""One actual-shape native training profile; excluded from performance data."""
import hashlib
import json
import runpy
import sys
import time
from pathlib import Path

from pin_entry import pin

ROOT=Path('/root/liger');OUT=ROOT/'results/training-kernel-profile'
OUT.mkdir(parents=True,exist_ok=True)
(OUT/'cpu-pin.json').write_text(json.dumps(pin(),indent=2))
# Pin CPU affinity before importing Torch, exactly as for the matrix.
import torch

sys.argv=[str(ROOT/'entry.py'),'--attention','sdpa','--indices',','.join(map(str,range(8,24))),
    '--config',str(ROOT/'b1.yaml'),'--output',str(OUT/'native'),
    '--warmup','1','--steps','1','--vram-budget-gib','10']
started=time.time()
with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,
    torch.profiler.ProfilerActivity.CUDA],record_shapes=False) as profile:
    runpy.run_path(str(ROOT/'entry.py'),run_name='__main__')
profile.export_chrome_trace(str(OUT/'chrome-trace.json'))
metrics=json.loads((OUT/'native/metrics.json').read_text())
backend=json.loads((OUT/'native/attention-residency-provenance.json').read_text())
assert metrics['input_shapes'] and all(shape==[1,1024] for shape in metrics['input_shapes'])
assert metrics['amp']=={'bf16':True,'fp16':False}
assert backend['construction']['constructed_backends']==['sdpa']
assert len([row for row in metrics['training_log_history'] if 'loss' in row])==2
events={}
for event in profile.events():
    if 'CUDA' in str(event.device_type) and 'flash' in event.name.lower():
        events[event.name]=events.get(event.name,0)+1
record={'scope':'separate actual-shape native 7B streaming training, after all timing processes',
    'excluded_from_all_performance_samples':True,'started_unix':started,'ended_unix':time.time(),
    'backend':'sdpa','input_shapes':metrics['input_shapes'],'amp':metrics['amp'],
    'optimizer_updates':2,'resident_layers':list(range(8,24)),
    'data_sha256':metrics['data_sha256'],'initial_adapter_sha256':metrics['initial_adapter_sha256'],
    'source_sha256':hashlib.sha256((ROOT/'source.tar.gz').read_bytes()).hexdigest(),
    'CUDA_flash_kernel_event_counts':events,
    'native_flash_forward_observed':any('pytorch_flash::' in name and 'flash_fwd' in name for name in events),
    'native_flash_backward_observed':any('pytorch_flash::' in name and 'flash_bwd' in name for name in events),
    'profile_memory_not_a_performance_or_VRAM_comparison':True}
(OUT/'kernel-proof.json').write_text(json.dumps(record,indent=2))
