"""Retain a pre-GPU infrastructure blocker; never fabricate kernel observations."""
import hashlib
import json
import zipfile
from pathlib import Path

from rich.console import Console

ROOT=Path(__file__).parent;REPO=ROOT.parent.parent
failure=json.loads((ROOT/'controller-error.json').read_text())
assert 'getaddrinfo failed' in failure['error']
assert not (ROOT/'remote-progress.json').exists() and not list(ROOT.glob('bundle-*-verified.json'))
cost=json.loads((ROOT/'final-cost-and-cleanup.json').read_text())
assert cost['verified_deleted'] and not cost['active_task_instances'] and cost['total_conservative_usd']<=5
protocol=json.loads((ROOT/'protocol.json').read_text())
assert "'--steps','2'" in (ROOT/'profile_training_entry.py').read_text()
offer=json.loads((ROOT/'vast-selected-offer.json').read_text())
summary={'study':'additional_native_1024_kernel_profile_attempt',
    'status':'BLOCKED_BEFORE_GPU_MODEL_WORK','blocker':'artifact-transfer preflight DNS lookup failed',
    'failure':failure,'no_GPU_model_work_started':True,'scoped_GPU_tests':'NOT_RUN',
    'no_performance_or_VRAM_samples_added':True,'native_flash_forward_at_1024':None,
    'native_flash_backward_at_1024':None,'actual_1024_kernel_profile_not_obtained':True,
    'core_48_process_24_pair_performance_matrix_unchanged':True,
    'semantic_native_kernel_observation_sequence_length':16,
    'corrected_planned_profile':{'warmup':1,'measured_steps':2,'optimizer_updates':3},
    'source_prepared_not_executed_sha256':hashlib.sha256((ROOT/'source.tar.gz').read_bytes()).hexdigest(),
    'protocol':protocol,'cost_and_cleanup':cost,
    'hardware_advertised':{k:offer.get(k) for k in ['gpu_name','cpu_name','pcie_bw','cpu_ram','dph_total']},
    'idle_preflight':json.loads((ROOT/'gpu-idle-preflight.json').read_text()),
    'no_raw_GPU_result_archive':True}
(ROOT/'kernel-proof-audit.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
(REPO/'benchmarks/streaming-residency-native-kernel-profile-results-20261020.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
files={}
for name in ['protocol.json','constraints.txt','b1.yaml','profile_training_entry.py']:
    files['planned-inputs/'+name]=(ROOT/name).read_bytes()
for name in ['controller-error.json','gpu-idle-preflight.json','vast-deletion.json','final-cost-and-cleanup.json','kernel-proof-audit.json']:
    files['attempt/'+name]=(ROOT/name).read_bytes()
files['analysis/build_blocked_profile_evidence.py']=Path(__file__).read_bytes()
manifest={'scope':'Blocked before GPU work; corrected planned caller and failure/cleanup metadata, no kernel proof',
    'files':{name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(files.items())}}
files['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
folder=REPO/'benchmarks/evidence/streaming-residency-native-kernel-profile-20261020'
folder.mkdir(exist_ok=True,parents=True)
with zipfile.ZipFile(folder/'planned-profile.zip','w',compression=zipfile.ZIP_DEFLATED) as zipped:
    for name,data in sorted(files.items()):
        info=zipfile.ZipInfo(name,date_time=(2026,10,20,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16
        zipped.writestr(info,data)
(folder/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
Console().print({'status':summary['status'],'no_kernel_observation_claimed':True,
    'all_instances_deleted':True,'total_conservative_usd':cost['total_conservative_usd']})
