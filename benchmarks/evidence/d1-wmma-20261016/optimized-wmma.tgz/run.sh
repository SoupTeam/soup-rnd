#!/bin/bash
set -euo pipefail
trap 'touch /workspace/d1probe/done' EXIT
cd /workspace/d1probe
python -m venv --without-pip --system-site-packages /workspace/d1probe/.venv
export PATH=/workspace/d1probe/.venv/bin:$PATH
mkdir -p source
tar -xf source.tar -C source
python -m pip install --no-deps bitsandbytes==0.50.2
python -m pip install rich==14.0.0
python -m pip install --disable-pip-version-check --timeout 20 --retries 1 'transformers==5.17.0' 'peft==0.20.0' 'accelerate==1.14.0' 'pydantic>=2,<3' pyyaml psutil safetensors pytest
export CUBLAS_WORKSPACE_CONFIG=:4096:8
export D1_SOURCE_SHA=ba6928e9af116c11d56257cf8d532ec51c3dee17
export PYTHONPATH=/workspace/d1probe/source/benchmarks/harness:/workspace/d1probe/source/src:/workspace/d1probe/source
mkdir -p results
nvidia-smi --query-gpu=name,uuid,driver_version,memory.total --format=csv,noheader > results/gpu.txt
python source/benchmarks/harness/d1_wmma_acceptance.py --output results/acceptance --diagnose-full-fp32-reduction
python source/benchmarks/harness/d1_wmma_step_screen.py --output results/step
