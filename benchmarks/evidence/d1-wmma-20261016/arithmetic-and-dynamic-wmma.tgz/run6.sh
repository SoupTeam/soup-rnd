#!/bin/bash
set -euo pipefail
trap 'touch /workspace/d1probe/done6' EXIT
cd /workspace/d1probe
export PATH=/workspace/d1probe/.venv/bin:$PATH
mkdir -p source6
tar -xf source6.tar -C source6
true
export CUBLAS_WORKSPACE_CONFIG=:4096:8
export D1_SOURCE_SHA=57b0b5d6b6514f8f5141f7fc1765aae98eaf5d5a
export PYTHONPATH=/workspace/d1probe/source6/benchmarks/harness:/workspace/d1probe/source6/src:/workspace/d1probe/source6
python source6/benchmarks/harness/d1_wmma_acceptance.py --output results/precision6 --diagnose-full-fp32-reduction
