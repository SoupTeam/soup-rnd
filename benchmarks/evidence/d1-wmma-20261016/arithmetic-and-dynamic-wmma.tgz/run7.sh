#!/bin/bash
set -euo pipefail
trap 'touch /workspace/d1probe/done7' EXIT
cd /workspace/d1probe
export PATH=/workspace/d1probe/.venv/bin:$PATH
mkdir -p source7
tar -xf source7.tar -C source7
export CUBLAS_WORKSPACE_CONFIG=:4096:8
export D1_SOURCE_SHA=93fbdaf676bdfc13aafed6cf19a070f1d83cfa8c
export PYTHONPATH=/workspace/d1probe/source7/benchmarks/harness
python source7/benchmarks/harness/d1_wmma_step_screen.py --output results/step7
