#!/bin/bash
set -euo pipefail
trap 'touch /workspace/d1probe/done5' EXIT
cd /workspace/d1probe
export PATH=/workspace/d1probe/.venv/bin:$PATH
mkdir -p source5
tar -xf source5.tar -C source5
python -m pip install --disable-pip-version-check --timeout 20 --retries 1 'transformers==5.17.0' 'peft==0.20.0' 'accelerate==1.14.0' 'pydantic>=2,<3' pyyaml psutil safetensors pytest
export CUBLAS_WORKSPACE_CONFIG=:4096:8
export D1_SOURCE_SHA=8739e5464a76e8cc97ac98970a84086b48c0c8ce
export PYTHONPATH=/workspace/d1probe/source5/benchmarks/harness:/workspace/d1probe/source5/src:/workspace/d1probe/source5
python source5/benchmarks/harness/d1_wmma_acceptance.py --output results/acceptance5
