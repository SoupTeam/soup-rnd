#!/bin/bash
set -euo pipefail
trap 'touch /workspace/d1probe/done' EXIT
cd /workspace/d1probe
python -m venv --without-pip --system-site-packages /workspace/d1probe/.venv
export PATH=/workspace/d1probe/.venv/bin:$PATH
mkdir -p source results
tar -xf source.tar -C source
nvidia-smi --query-gpu=name,uuid,driver_version,memory.total --format=csv,noheader > results/gpu.txt
nvidia-smi --query-compute-apps=pid,process_name --format=csv,noheader > results/peers-before.txt
python -m pip install --disable-pip-version-check --timeout 20 --retries 1 --no-deps bitsandbytes==0.50.2
python -m pip install --disable-pip-version-check --timeout 20 --retries 1 rich==14.0.0
export CUBLAS_WORKSPACE_CONFIG=:4096:8
export D1_SOURCE_SHA=0a75ca705fddfd9cffab7661dee9270f1fda25ae
export PYTHONPATH=/workspace/d1probe/source/benchmarks/harness
set +e
python source/benchmarks/harness/d1_arithmetic_screen.py --output results/cuda.json
code=$?
if [ -e results/cuda.json ]; then
  mkdir -p results/order
  python source/benchmarks/harness/d1_order_followup.py --output results/order/cuda.json
fi
set -e
printf '%s\n' "$code" > results/exit-code.txt
python -m pip freeze > results/packages.txt
exit "$code"
