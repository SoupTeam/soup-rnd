#!/bin/bash
set -euo pipefail
trap 'touch /workspace/d1probe/done3' EXIT
cd /workspace/d1probe
export PATH=/workspace/d1probe/.venv/bin:$PATH
mkdir -p source3 results/wmma3
tar -xf source3.tar -C source3
export CUBLAS_WORKSPACE_CONFIG=:4096:8
export D1_SOURCE_SHA=03c90272e5486852434dbea31ad1ca2ed87a8e02
export PYTHONPATH=/workspace/d1probe/source3/benchmarks/harness
python source3/benchmarks/harness/d1_wmma_screen.py --output results/wmma3/cuda.json
