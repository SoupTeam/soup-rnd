#!/bin/bash
set -euo pipefail
trap 'touch /workspace/d1probe/done4' EXIT
cd /workspace/d1probe
export PATH=/workspace/d1probe/.venv/bin:$PATH
mkdir -p source4 results/aligned4
tar -xf source4.tar -C source4
export CUBLAS_WORKSPACE_CONFIG=:4096:8
export D1_SOURCE_SHA=870350e5beb84c9b7c4b124782b29081fa0a961e
export PYTHONPATH=/workspace/d1probe/source4/benchmarks/harness
python source4/benchmarks/harness/d1_wmma_aligned_gate.py --output results/aligned4/cuda.json
