#!/bin/bash
set -euo pipefail
trap 'touch /workspace/d1probe/done2' EXIT
cd /workspace/d1probe
export PATH=/workspace/d1probe/.venv/bin:$PATH
mkdir -p source2 results/arithmetic2 results/order2
tar -xf source2.tar -C source2
export CUBLAS_WORKSPACE_CONFIG=:4096:8
export D1_SOURCE_SHA=32a5d4c8b9098a67751d7106ef7f5b0ac2895ace
export PYTHONPATH=/workspace/d1probe/source2/benchmarks/harness
python source2/benchmarks/harness/d1_arithmetic_screen.py --output results/arithmetic2/cuda.json
python source2/benchmarks/harness/d1_order_followup.py --output results/order2/cuda.json
