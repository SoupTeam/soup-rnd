"""The config-view repair cannot substitute altered evidence."""

import hashlib
import json

import pytest

from replay_config_view import ARMS, selection_view


def fixture(root):
    for arm in ARMS:
        folder = root / "bundles" / ("sweep-joint-capacity-" + arm)
        source = folder / "retained"
        source.mkdir(parents=True)
        raw = ("config-" + arm).encode()
        filename = "case-" + arm + ".yaml"
        manifest = {"files": {filename: {"bytes": len(raw),
                     "sha256": hashlib.sha256(raw).hexdigest()}}}
        encoded = json.dumps(manifest).encode()
        (source / filename).write_bytes(raw)
        (source / "original-files.json").write_bytes(encoded)
        (folder / "index.json").write_text(json.dumps({
            "archive_sha256": "archive", "manifest_sha256": hashlib.sha256(encoded).hexdigest(),
        }))
    return lambda where, name: where / "bundles" / name / "retained"


def test_original_config_bytes_are_copied_to_a_separate_view(tmp_path):
    verify = fixture(tmp_path)
    target, records = selection_view(tmp_path, verify)
    assert len(records) == 4
    assert (target / "case-both.yaml").read_bytes() == b"config-both"
    assert not (tmp_path / "bundles/sweep-joint-selection/retained/case-both.yaml").exists()


@pytest.mark.parametrize("mutation", ["config", "manifest", "view"])
def test_changed_config_manifest_or_existing_view_is_rejected(tmp_path, mutation):
    verify = fixture(tmp_path)
    source = tmp_path / "bundles/sweep-joint-capacity-baseline/retained"
    if mutation == "config":
        (source / "case-baseline.yaml").write_bytes(b"tampered")
    elif mutation == "manifest":
        (source / "original-files.json").write_bytes(b"{}")
    else:
        target = tmp_path / "offline-replay-configs"
        target.mkdir()
        (target / "case-baseline.yaml").write_bytes(b"tampered")
    with pytest.raises(ValueError):
        selection_view(tmp_path, verify)
