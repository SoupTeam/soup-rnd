"""Resolve earlier-exported configs without changing any canonical bundle."""

import hashlib
import json
import os
from pathlib import Path

ARMS = ("baseline", "ram", "vram", "both")


def selection_view(root, verified_bundle):
    root = Path(root)
    # Validate the original selection receipt even though its configs were
    # exported earlier by the capacity stages and are not duplicated there.
    verified_bundle(root, "sweep-joint-selection")
    target = root / "offline-replay-configs"
    target.mkdir(exist_ok=True)
    if os.path.commonpath([os.path.realpath(root), os.path.realpath(target)]) != os.path.realpath(root):
        raise ValueError("Replay view escapes the study")
    records = []
    for arm in ARMS:
        name = "sweep-joint-capacity-" + arm
        source = verified_bundle(root, name)
        index = json.loads((root / "bundles" / name / "index.json").read_bytes())
        raw_manifest = (source / "original-files.json").read_bytes()
        manifest_sha = hashlib.sha256(raw_manifest).hexdigest()
        if manifest_sha != index["manifest_sha256"]:
            raise ValueError("Original manifest identity changed")
        filename = "case-" + arm + ".yaml"
        record = json.loads(raw_manifest)["files"][filename]
        raw = (source / filename).read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        if digest != record["sha256"] or len(raw) != record["bytes"]:
            raise ValueError("Original config bytes changed")
        destination = target / filename
        if destination.exists():
            if destination.read_bytes() != raw:
                raise ValueError("Conflicting local replay view")
        else:
            destination.write_bytes(raw)
        records.append({"arm": arm, "source_bundle": name,
                        "source_archive_sha256": index["archive_sha256"],
                        "source_manifest_sha256": manifest_sha,
                        "file": filename, "bytes": len(raw), "sha256": digest})
    return target, records
