"""Run unchanged numerical gates through a hash-verified config-location view."""

import hashlib
import json
import time
from pathlib import Path

from rich.console import Console

import replay_joint
from replay_config_view import selection_view


def main():
    root = Path(__file__).parent
    original = replay_joint.bundle
    target, origins = selection_view(root, original)
    repair = {
        "only_config_lookup_location_changed": True,
        "original_bundles_not_modified": True,
        "canonical_config_bytes_verified": origins,
        "consumer_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "resolver_sha256": hashlib.sha256((root / "replay_config_view.py").read_bytes()).hexdigest(),
        "original_consumer_sha256": hashlib.sha256((root / "replay_joint.py").read_bytes()).hexdigest(),
    }
    (root / "config-location-repair.json").write_text(json.dumps(repair, indent=2) + "\n")

    def resolve(where, name):
        if name == "sweep-joint-selection":
            original(where, name)
            return target
        return original(where, name)

    replay_joint.bundle = resolve
    try:
        report = replay_joint.accuracy(root)
    finally:
        replay_joint.bundle = original
    if not report["passed"]:
        raise ValueError("Original numerical replay failed")
    destination = root / "independent-accuracy-replay.json"
    destination.write_text(json.dumps(report, indent=2) + "\n")
    approval = {
        "passed": True, "traces": report["traces"],
        "independent_report_sha256": replay_joint.digest(destination), "unix": time.time(),
        "config_location_repair_sha256": replay_joint.digest(root / "config-location-repair.json"),
    }
    (root / "accuracy-approved.json").write_text(json.dumps(approval, indent=2) + "\n")
    import transport

    transport.upload("accuracy-approved.json")
    (root / "accuracy-upload-confirmation.json").write_text(json.dumps({
        "passed": True, "uploaded_unix": time.time(), "traces": report["traces"],
        "independent_report_sha256": approval["independent_report_sha256"],
        "config_location_repair_sha256": approval["config_location_repair_sha256"],
    }, indent=2) + "\n")
    Console().print({"all_eight_captures_independently_replayed": True,
                     "all_candidates_bitwise_equal": all(
                         gate["bitwise_equal"] for gate in report["gates"].values()),
                     "approval_uploaded": True})


if __name__ == "__main__":
    main()
