"""Analyze complete retained diagnostic data while preserving its failed byte gate."""

import json
from pathlib import Path

from audit_expert_profiles_combined import analyze_averages, analyze_trace, digest, verify_gzip

BASE = Path(__file__).parent
STAGE = BASE.parent / "kanana-30b-profile-gpu-20261026-f7"
DIRECTORY = STAGE / "retained/results/profiles/two_read"


def main():
    outer = json.loads((STAGE / "archive-manifest.json").read_text())
    for name in ("profile-result.json", "key-averages.json", "trace-retention.json",
                 "trace.json", "trace.json.gz"):
        path = DIRECTORY / name
        expected = outer["files"]["results/profiles/two_read/" + name]
        assert path.stat().st_size == expected["bytes"] and digest(path) == expected["sha256"]
    profile = json.loads((DIRECTORY / "profile-result.json").read_text())
    proof = json.loads((DIRECTORY / "trace-retention.json").read_text())
    assert profile["status"] == "failed" and "fixed size bound" in profile["error"]
    assert proof["within_bound"] is False and proof["maximum_encoded_bytes"] == 128 * 2**20
    verified = verify_gzip(DIRECTORY / "trace.json.gz", proof)
    averages = json.loads((DIRECTORY / "key-averages.json").read_text())
    report = {
        "status": "diagnostic_data_verified; original_profile_size_gate_FAILED",
        "profile_final_state_hash_verdict": "NO VERDICT: original worker stopped before recording",
        "source_commit": "43cf0b34afe0d8850d76bf86d60663ab5c85cdb2",
        "trace_gate": proof, "full_lossless_trace": verified,
        "averages": analyze_averages(averages),
        "allocation_fill_rows": [row for row in averages["key_averages"]
                                 if "fill" in row["name"].lower()],
        "timeline": analyze_trace(DIRECTORY / "trace.json.gz"),
        "speed_verdict": "NO VERDICT: instrumented times and overlapping totals are not step timings",
    }
    destination = BASE / "f7-profile-diagnostic-analysis.json"
    destination.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    from rich.console import Console

    Console().print({"status": report["status"], "out": str(destination),
                     "timeline_status": report["timeline"]["status"]})


if __name__ == "__main__":
    main()
