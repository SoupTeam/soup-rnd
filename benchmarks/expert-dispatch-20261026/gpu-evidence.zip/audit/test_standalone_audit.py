"""The narrowed cohort must retain the original numerical and timing predicates."""

import inspect
import json

import pytest

from audit_expert_profiles_combined import Audit, ProfileAudit, digest
from audit_standalone_dispatch import FOUNDATION_SHA, StandaloneAudit


def test_original_auditor_bytes_still_exact():
    from pathlib import Path

    assert digest(Path(__file__).with_name("audit_expert_profiles_combined.py")) == FOUNDATION_SHA


def test_all_qualification_numerical_resource_cache_and_bootstrap_predicates_preserved():
    original = inspect.getsource(Audit.qualification)
    standalone = inspect.getsource(StandaloneAudit.qualification)
    restored = standalone.replace(
        'len(self.pids) == 11, "eleven distinct standalone qualification workers"',
        'len(self.pids) == 16, "sixteen distinct native/profile/qualification workers"',
    )
    assert restored.strip() == original.strip()


def test_all_source_recipe_cuda_input_and_metadata_predicates_preserved():
    original = inspect.getsource(ProfileAudit.execute)
    original = original.split('        run = self.read("results/accuracy/run.json")')[0]
    original = original.replace("def execute(self) -> dict:",
                                "def setup_source_and_recipe(self) -> None:", 1)
    original = original.replace("three full accuracy arms then two diagnostic profiles",
        "shared legacy recipe descriptors; actual execution checked separately")
    assert inspect.getsource(StandaloneAudit.setup_source_and_recipe).strip() == original.strip()


@pytest.mark.parametrize("mutation", [None, "capture_bytes", "source", "retention"])
def test_external_reference_cannot_be_silently_substituted(tmp_path, mutation):
    source = "a" * 40
    previous = tmp_path / "previous"
    capture = previous / "retained/results/accuracy/ordinary/capture.pt"
    capture.parent.mkdir(parents=True)
    capture.write_bytes(b"exact original fixture")
    row = {"bytes": capture.stat().st_size, "sha256": digest(capture)}
    manifest = {"source_commit": source, "files": {
        "results/accuracy/ordinary/capture.pt": row}}
    bundle = {"all_manifested_raw_files_retained": True}
    if mutation == "capture_bytes":
        capture.write_bytes(b"different fixture")
    elif mutation == "source":
        manifest["source_commit"] = "b" * 40
    elif mutation == "retention":
        bundle["all_manifested_raw_files_retained"] = False
    (previous / "archive-manifest.json").write_text(json.dumps(manifest))
    (previous / "bundle-verified.json").write_text(json.dumps(bundle))
    audit = StandaloneAudit(tmp_path / "current", tmp_path / "source", source,
                            reference_stage=previous)
    if mutation:
        with pytest.raises(AssertionError):
            audit.file("results/accuracy/ordinary/capture.pt")
    else:
        assert audit.file("results/accuracy/ordinary/capture.pt") == capture
        assert audit.report["external_numerical_reference"]["stage"] == "F7"
