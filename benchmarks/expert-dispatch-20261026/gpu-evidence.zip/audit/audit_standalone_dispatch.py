"""Audit F8's standalone three-accuracy/eight-timing cohort.

The prior F7 profile remains a failed trace-size qualification. This audit makes
no passed-profile claim and preserves the original numerical/timing predicates.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import os
import traceback
import xml.etree.ElementTree as ET
from pathlib import Path

from audit_expert_profiles_combined import (
    ACCURACY_VARIANTS,
    ARMS,
    CUDA_NAMES,
    GIB,
    IDENTITY_PATHS,
    MODEL,
    PROFILES,
    QUALIFICATION,
    REVISION,
    VARIANTS,
    Audit,
    digest,
    full_capture,
    loss_gate,
    recompute_timing,
)

FOUNDATION_SHA = "16c3f1b55e9e5b7e7f20aad80d6c101a3b9bcc81091b4838e1d26cb21a72a9a6"
EXPECTED_PURPOSE = (
    "standalone accuracy-first grouped dispatch qualification after retained F7 profile"
)


class StandaloneAudit(Audit):
    def __init__(self, stage, source, expected_source, *, reference_stage):
        super().__init__(stage, source, expected_source, timeline=False)
        self.reference_stage = reference_stage

    def file(self, name):
        if name != "results/accuracy/ordinary/capture.pt":
            return super().file(name)
        # An additional cross-cohort numerical reference, never a timing denominator.
        manifest = json.loads((self.reference_stage / "archive-manifest.json").read_text())
        bundle = json.loads((self.reference_stage / "bundle-verified.json").read_text())
        self.check(manifest["source_commit"] == self.expected_source
                   and bundle["all_manifested_raw_files_retained"] is True,
                   "external F7 reference source and full retention")
        path = self.reference_stage / "retained" / name
        row = manifest["files"][name]
        self.check(path.stat().st_size == row["bytes"] and digest(path) == row["sha256"],
                   "external original F7 ordinary capture exact bytes")
        self.report["external_numerical_reference"] = {
            "stage": "F7", "path": name, **row,
            "scope": "extra full numerical comparison only; not a speed denominator",
        }
        return path

    def setup_source_and_recipe(self) -> None:
        import torch

        torch.set_num_threads(1)
        self.retention()
        source, protocol = self.read("source-manifest.json"), self.read("protocol.json")
        self.check(
            source["source_commit"] == protocol["source_commit"] == self.expected_source,
            "frozen profiling source commit",
        )
        self.check(
            digest(self.stage / "source.tar.gz") == source["archive_sha256"],
            "private source archive matches the executed frozen source manifest",
        )
        self.check(
            protocol["model"]["repo_id"] == MODEL
            and protocol["model"]["revision"] == REVISION
            and protocol["model"]["weights_bytes"] == 61343935088,
            "pinned official 30B checkpoint",
        )
        self.check(
            json.loads((self.stage / "protocol.json").read_text()) == protocol,
            "private and retained frozen protocols agree",
        )
        self.check(
            str(self.receipt["label"]).startswith(protocol["stage_id"]),
            "owned receipt belongs to this stage",
        )
        performance = protocol["performance"]
        self.check(
            tuple(performance["accuracy_arms"]) == ARMS
            and tuple(performance["profile_arms"]) == PROFILES
            and performance["profiled_times_are_diagnostic_only"] is True,
            "shared legacy recipe descriptors; actual execution checked separately",
        )
        name = "benchmarks/harness/two_read_cache_common.py"
        common_path = self.source / name
        self.check(
            digest(common_path) == source["files"][name]["sha256"],
            "original numerical comparator matches frozen executed bytes",
        )
        loader = importlib.util.spec_from_file_location(
            "frozen_profile_numerical_gates", common_path
        )
        common = importlib.util.module_from_spec(loader)
        loader.loader.exec_module(common)
        self.check(common.RTOL == 0.01 and common.ATOL == 1e-5, "unchanged numerical tolerances")
        self.common, self.source_manifest, self.protocol = common, source, protocol
        capacity = self.read("results/capacity-preflight.json")
        self.check(
            capacity["passed"] is True
            and 7900 <= capacity["gpu_memory_mib"] <= 8300
            and 28 * GIB <= capacity["native_ram_limit_bytes"] <= 32 * GIB
            and int(capacity["container_id"]) == int(self.receipt["instance_id"]),
            "actual owned physical 8-GB/native <=32-GiB startup",
        )
        spec = self.read("results/prepared/spec.json")
        identity = self.outer["files"]["results/prepared/spec.json"]["sha256"]
        self.spec, self.spec_identity = spec, identity
        self.check(
            spec["git_head"] == self.expected_source
            and spec["quant"] == "nf4"
            and spec["dtype"] == "bfloat16"
            and spec["seq_len"] == 512
            and spec["batch_size"] == 1
            and spec["accumulation"] == 2
            and spec["accuracy_updates"] == 2
            and spec["warmup_updates"] == 2
            and spec["timed_updates"] == 6
            and spec["rounds"] == 4
            and spec["lora_r"] == 4
            and spec["lora_alpha"] == 8
            and spec["lora_targets"] == ["q_proj", "kv_b_proj", "o_proj"]
            and spec["host_cache_bytes"] == 8 * GIB
            and spec["device_cache_bytes"] == 2 * GIB
            and spec["host_cache_policy"] == "static"
            and spec["device_cap_bytes"] == 8 * GIB
            and spec["max_host_bytes"] <= 32 * GIB,
            "fixed NF4/BF16 attention-LoRA/cache recipe",
        )
        self.check(
            str(capacity["gpu_uuid"]).removeprefix("GPU-")
            == str(spec["hardware"]["uuid"]).removeprefix("GPU-"),
            "actual GPU UUID",
        )
        for path, sha in spec["source_fingerprint"].items():
            self.check(source["files"][path]["sha256"] == sha, "executed source binding: " + path)
        pinned = self.read("results/model-pinned.json")
        self.check(
            pinned["repo_id"] == MODEL
            and pinned["revision"] == REVISION
            and len(pinned["files"]) == 13
            and pinned["weights_bytes"] == 61343935088
            and sum(row["bytes"] for row in pinned["files"].values()) == 61343935088,
            "all 13 pinned public shards",
        )
        for path, row in pinned["files"].items():
            self.check(
                row["lfs"]["sha256"] == spec["model_fingerprint"][path]
                and row["bytes"] == spec["model_stat"][path][0],
                "pinned LFS binding: " + path,
            )
        config, index = (
            self.read("results/model-config.json"),
            self.read("results/cache-index.json"),
        )
        self.check(
            self.outer["files"]["results/model-config.json"]["sha256"]
            == spec["model_fingerprint"]["config.json"]
            and self.outer["files"]["results/cache-index.json"]["sha256"]
            == spec["store_fingerprint"]["index.json"],
            "actual metadata bytes",
        )
        self.check(
            config["model_type"] == "deepseek_v3"
            and config["num_hidden_layers"] == 48
            and config["n_routed_experts"] == 128
            and config["num_experts_per_tok"] == 6
            and config["rope_interleave"] is True
            and config["q_lora_rank"] is None
            and index["expert_layout"] == "per_expert"
            and index["n_layers"] == 48
            and index["expert_layers"] == list(range(1, 48))
            and index["expert_count"] == 128
            and index["quant"] == "nf4"
            and index["double_quant"] is True
            and index["expert_shapes"] == {"gate_up": [1536, 2048], "down": [2048, 768]},
            "actual native 6016-expert Kanana NF4 layout",
        )
        for part, shape in index["expert_shapes"].items():
            quant = index["expert_quant_specs"][part]
            self.check(
                quant["shape"] == shape
                and quant["nested"] is True
                and quant["blocksize"] == 64
                and quant["nested_blocksize"] == 256
                and quant["quant_type"] == "nf4",
                "actual packed NF4 sidecar layout: " + part,
            )
        cases = ET.parse(self.file("results/gpu-preflight.xml")).findall(".//testcase")
        self.check(
            len(cases) == 5
            and sorted(case.attrib["name"] for case in cases) == sorted(CUDA_NAMES)
            and all(
                case.find(tag) is None for case in cases for tag in ("skipped", "failure", "error")
            ),
            "five actual CUDA controls passed without skips",
        )
        proofs = [
            path for path in self.outer["files"] if path.endswith("/cuda-profiler-proof.json")
        ]
        self.check(len(proofs) == 1, "actual CUDA profiler preflight proof retained")
        proof = self.read(proofs[0])
        self.check(
            proof["event_count"] > proof["cuda_event_count"] > 0
            and proof["cuda_kernel_event_count"] > 0
            and proof["cuda_h2d_event_count"] > 0,
            "actual preflight CPU, CUDA kernels and H2D activity",
        )
        inputs_path = self.file("results/prepared/inputs.pt")
        self.check(digest(inputs_path) == spec["training_data_sha256"], "frozen input bytes")
        inputs = torch.load(inputs_path, map_location="cpu", weights_only=True)
        self.check(
            inputs.dtype == torch.long and tuple(inputs.shape) == (4, 1, 512),
            "frozen input dimensions",
        )

    def qualification(self) -> None:
        import torch

        run = self.read(QUALIFICATION + "/run.json")
        self.check(run["status"] == "completed" and run["accuracy_passed"] is True
                   and run["source_commit"] == self.expected_source
                   and run["spec_sha256"] == self.spec_identity
                   and run["identity"] == self.identity
                   and set(run["accuracy"]) == set(ACCURACY_VARIANTS)
                   and run["gpu_rented_by_runner"] is False
                   and run["original_gates"] == {
                       "reference_relative_rtol": 0.01, "atol": 1e-5,
                       "loss_three_decimal": True, "finite": True},
                   "complete frozen dispatch run with original gates")
        protocol = self.protocol["performance"]["dispatch_qualification"]
        self.check(
            protocol["runner"] == IDENTITY_PATHS["wrapper_sha256"]
            and tuple(protocol["accuracy_variants"]) == ACCURACY_VARIANTS
            and tuple(protocol["timing_variants"]) == VARIANTS
            and protocol["rounds"] == 4 and protocol["warmup_updates"] == 2
            and protocol["timed_updates"] == 6 and protocol["accuracy_updates"] == 2
            and protocol["timing_workers"] == 8
            and protocol["grouped_expert_routes_default"] is False
            and protocol["practical_lower_bound_percent"] == 2.0,
            "fixed three-accuracy/eight-worker dispatch protocol",
        )
        inputs = torch.load(self.file("results/prepared/inputs.pt"),
                            map_location="cpu", weights_only=True)
        losses, counters, accuracy_report, gates = {}, {}, {}, {}
        reference = None
        for variant in ACCURACY_VARIANTS:
            directory = QUALIFICATION + "/accuracy/" + variant
            control = self.qualification_worker(directory, variant, "accuracy")
            self.check(run["accuracy"][variant]["result"] == control,
                       variant + ": saved run/raw accuracy cell")
            raw = control["worker"]
            path = self.file(directory + "/capture.pt")
            self.check(digest(path) == raw["accuracy"]["capture_sha256"],
                       variant + ": original complete capture digest")
            capture = torch.load(path, map_location="cpu", weights_only=True)
            proof = full_capture(capture, inputs, self.common)
            self.check(run["accuracy"][variant]["capture_controls"]["full_microbatch_losses"]
                       == proof["losses"],
                       variant + ": recorded accuracy losses match original full capture")
            losses[variant] = proof["losses"]
            counters[variant] = self.cache(
                raw["accuracy"]["runtime_before"]["expert_cache"],
                raw["accuracy"]["runtime_after"]["expert_cache"], raw["arm"])
            accuracy_report[variant] = proof
            if reference is None:
                reference = capture
            else:
                gate = self.common.compare_captures(reference, capture)
                self.check(gate["passed"], "ordinary_legacy -> " + variant
                           + ": independently rerun full original tensor/AdamW comparator")
                gates["ordinary_legacy_vs_" + variant] = gate
                del capture
        native = torch.load(self.file("results/accuracy/ordinary/capture.pt"),
                            map_location="cpu", weights_only=True)
        same_input_gate = self.common.compare_captures(native, reference)
        self.check(same_input_gate["passed"],
                   "native ordinary vs qualification ordinary original full accuracy gate")
        del reference, native
        left = torch.load(self.file(QUALIFICATION + "/accuracy/legacy/capture.pt"),
                          map_location="cpu", weights_only=True)
        right = torch.load(self.file(QUALIFICATION + "/accuracy/grouped/capture.pt"),
                           map_location="cpu", weights_only=True)
        gate = self.common.compare_captures(left, right)
        self.check(gate["passed"], "legacy -> grouped: original full tensor/AdamW comparator")
        gates["legacy_vs_grouped"] = gate
        del left, right
        self.check(counters["legacy"] == counters["grouped"]
                   and counters["ordinary_legacy"]["logical_fetches"] * 2
                   == counters["legacy"]["logical_fetches"] * 3,
                   "qualification three/two-read and identical candidate cache work")
        blocks = run["timing_blocks"]
        self.check(len(blocks) == 8, "all eight timing blocks retained")
        for block in blocks:
            directory = (QUALIFICATION + f"/timing/round-{block['round']:02d}/"
                         + block["variant"])
            control = self.qualification_worker(directory, block["variant"], "timing")
            self.check(block["result"] == control, directory + ": run/raw timing identity")
            raw = control["worker"]
            for phase in ("warmup", "timing"):
                self.cache(raw[phase]["runtime_before"]["expert_cache"],
                           raw[phase]["runtime_after"]["expert_cache"], "two_read_cache")
            gate = loss_gate(losses[block["variant"]][1::2], raw["warmup"]["losses"])
            self.check(gate["passed"], directory + ": recorded warmup vs full accuracy losses")
        result = recompute_timing(blocks)
        cache_checks = []
        for number in range(4):
            pair = {block["variant"]: block["result"]["worker"] for block in blocks
                    if block["round"] == number}
            deltas = {}
            for variant in VARIANTS:
                stage = pair[variant]["timing"]
                deltas[variant] = self.cache(stage["runtime_before"]["expert_cache"],
                                            stage["runtime_after"]["expert_cache"],
                                            "two_read_cache")
            self.check(deltas["legacy"] == deltas["grouped"],
                       f"round {number}: actual timed cache/expert work equal")
            cache_checks.append({"round": number, "reference": deltas["legacy"],
                                 "candidate": deltas["grouped"], "equal": True})
        saved = run["timing_summary"]
        for key in ("step_time_reduction_percent", "paired_bootstrap_95_percent",
                    "passes_practical_2_percent_gate", "bootstrap_samples", "bootstrap_seed",
                    "paired_rounds", "absolute"):
            self.check(saved[key] == result[key], "independently recomputed timing " + key)
        self.check(saved["reference_variant"] == "legacy"
                   and saved["candidate_variant"] == "grouped"
                   and saved["native_arm_for_both"] == "two_read_cache",
                   "saved timing references same raw native arm")
        result["equal_cache_work"] = cache_checks
        self.report["dispatch_qualification"] = {
            "full_accuracy": accuracy_report, "original_comparisons": gates,
            "native_vs_qualification_ordinary": same_input_gate,
            "accuracy_counter_deltas": counters, "timing": result,
            "sequence_evidence": "Outer phase receipts and hash-bound sequential controller; "
            "no independent timestamps exist for qualification's internal accuracy/timing phases.",
        }
        self.report["unprofiled_speed_verdict"] = (
            "passes >=2% lower-confidence-bound gate" if result["passes_practical_2_percent_gate"]
            else "NO PRACTICAL WIN: lower confidence bound is below 2%")
        self.check(len(self.pids) == 11, "eleven distinct standalone qualification workers")

    def execute(self):
        foundation = Path(__file__).with_name("audit_expert_profiles_combined.py")
        self.check(digest(foundation) == FOUNDATION_SHA,
                   "unchanged original comparator/resource/worker/timing audit implementation")
        self.setup_source_and_recipe()
        self.check(self.protocol["purpose"] == EXPECTED_PURPOSE,
                   "standalone scope explicitly declared")
        plan = self.protocol["execution_plan"]
        self.check(plan["dispatch_qualification"] is True
                   and plan["native_accuracy_phase_in_this_lease"] is False
                   and plan["large_profiles_in_this_lease"] is False
                   and plan["prior_profile_verdict"]
                   == "FAILED_TRACE_SIZE_GATE; full raw trace retained",
                   "no fictitious native/profile phases in this lease")
        self.qualification()
        self.check(len(self.pids) == 11, "exactly eleven fresh qualification workers")
        order = self.read("results/phase-order.json")
        self.check(order["source_commit"] == self.expected_source
                   and order["spec_sha256"] == self.spec_identity,
                   "standalone phase order source/spec")
        records = order["records"]
        self.check([(row["phase"], row["status"]) for row in records] == [
            ("dispatch_qualification", "started"), ("dispatch_qualification", "completed")],
            "only standalone qualification executed")
        self.check(records[0]["unix"] < records[1]["unix"]
                   and records[0]["monotonic"] < records[1]["monotonic"],
                   "standalone phase timestamps increase")
        self.report.update(status="passed_standalone_qualification_audit",
            prior_profile_verdict="F7 FAILED_TRACE_SIZE_GATE; not promoted to passed",
            scope="F8 full numerical qualification and fresh paired timing only")
        return self.report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage-dir", type=Path, required=True)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--reference-stage", type=Path, required=True)
    parser.add_argument("--expected-source", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    audit = StandaloneAudit(args.stage_dir, args.source_root, args.expected_source,
                            reference_stage=args.reference_stage)
    audit.report["audit_script_sha256"] = digest(Path(__file__))
    code = 0
    try:
        audit.execute()
    except BaseException as exc:
        audit.report.update(status="failed", error=repr(exc), traceback=traceback.format_exc())
        code = 1
    temporary = args.out.with_suffix(".incoming")
    temporary.write_text(json.dumps(audit.report, indent=2, allow_nan=False) + "\n")
    os.replace(temporary, args.out)
    from rich.console import Console

    Console().print({"status": audit.report["status"], "checks": len(audit.report["checks"]),
                     "out": str(args.out)})
    return code


if __name__ == "__main__":
    raise SystemExit(main())
