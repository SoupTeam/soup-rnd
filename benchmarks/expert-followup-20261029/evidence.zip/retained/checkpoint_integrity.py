"""Exact pinned checkpoint verification with bounded fresh input repair.

Only input downloading is retried. Expected SHA256/size, numerical tolerances,
production code and training recipe are never changed by this helper.
"""

from __future__ import annotations

import hashlib
import importlib
import inspect
import json
import os
import re
import time
from pathlib import Path
from types import MappingProxyType
from typing import Any, Callable

MAX_FORCED_REDOWNLOADS = 2
HUB_VERSION = "1.33.0"
# Canonical {filename:{bytes,sha256}} map from the official pinned revision,
# independently matching the successful F8 and failed F13 API/LFS metadata.
OFFICIAL_PIN_MAP_SHA256 = "5271df2196b8ebe206cfcaed8e839cb6fa8943997aa4fd1c9ff2caa72582f74a"


class CheckpointIntegrityError(RuntimeError):
    """Pinned input verification failed; no preparation or training may begin."""


def atomic_save(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".incoming")
    with temporary.open("w", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def digest(path: Path) -> str:
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 2**20), b""):
            result.update(block)
    return result.hexdigest()


def normalize(pins: dict[str, dict[str, Any]]) -> dict[str, tuple[int, str]]:
    if type(pins) is not dict or not pins:
        raise CheckpointIntegrityError("Pinned checkpoint map is empty or invalid")
    result = {}
    for name, value in pins.items():
        if (not isinstance(name, str) or Path(name).name != name or "/" in name
                or "\\" in name or name in (".", "..") or not isinstance(value, dict)
                or set(value) != {"bytes", "sha256"} or type(value["bytes"]) is not int
                or value["bytes"] <= 0 or not isinstance(value["sha256"], str)
                or re.fullmatch("[0-9a-f]{64}", value["sha256"]) is None):
            raise CheckpointIntegrityError("Pinned checkpoint entry is invalid")
        result[name] = (value["bytes"], value["sha256"])
    return result


def target(root: Path, name: str) -> Path:
    base = os.path.realpath(root)
    path = Path(os.path.realpath(os.path.join(base, name)))
    if (os.path.normcase(os.path.commonpath((base, path))) != os.path.normcase(base)
            or (root / name).is_symlink()):
        raise CheckpointIntegrityError("Checkpoint path escapes its ordinary local directory")
    return path


def validate_official_pins(pins: dict[str, dict[str, Any]]) -> str:
    checked = normalize(pins)
    canonical = {name: {"bytes": pair[0], "sha256": pair[1]} for name, pair in checked.items()}
    value = hashlib.sha256(json.dumps(canonical, sort_keys=True,
                                     separators=(",", ":")).encode()).hexdigest()
    if value != OFFICIAL_PIN_MAP_SHA256:
        raise CheckpointIntegrityError("Official thirteen-shard SHA256/size map changed")
    return value


def verify_checkpoint(weights_dir: Path, pins: dict[str, dict[str, Any]], receipt_path: Path,
                      download: Callable[[str], str | Path], *, repo_id: str,
                      revision: str) -> dict[str, Any]:
    """Hash all files, repair only failures (at most two), then rehash every file."""
    root, receipt_path = Path(weights_dir), Path(receipt_path)
    frozen = MappingProxyType(normalize(pins))
    original = {name: {"bytes": pair[0], "sha256": pair[1]} for name, pair in frozen.items()}
    receipt: dict[str, Any] = {
        "schema_version": 1, "status": "running", "repo_id": repo_id, "revision": revision,
        "helper_path": os.path.realpath(__file__), "helper_sha256": digest(Path(__file__)),
        "expected_files": len(frozen),
        "expected_total_bytes": sum(pair[0] for pair in frozen.values()),
        "expected_pins": original, "max_forced_redownloads": MAX_FORCED_REDOWNLOADS,
        "expected_pins_sha256": hashlib.sha256(json.dumps(original, sort_keys=True,
            separators=(",", ":")).encode()).hexdigest(),
        "forced_redownloads_used": 0, "events": [], "final_verified_files": {},
        "full_bad_payload_retained": False,
        "bad_payload_retention_scope": "Observed full SHA256/size only; bad full weights and"
                                       " optional byte samples are not retained as outputs."}
    attempts = {name: 0 for name in frozen}

    def save() -> None:
        atomic_save(receipt_path, receipt)

    def unchanged() -> None:
        if pins != original:
            raise CheckpointIntegrityError("Expected pinned metadata changed during verification")

    def event(kind: str, name: str, phase: str, **fields: Any) -> None:
        size, expected_sha = frozen[name]
        receipt["events"].append({"event": kind, "filename": name, "phase": phase,
            "expected_bytes": size, "expected_sha256": expected_sha,
            "observed_bytes": None, "observed_sha256": None, "error_category": None,
            "attempt": attempts[name], "timestamp": time.time(),
            "global_forced_redownloads_used": receipt["forced_redownloads_used"], **fields})
        save()

    def check_file(name: str, phase: str) -> dict[str, Any]:
        unchanged()
        path = target(root, name)
        event("hash_started", name, phase)
        observed: dict[str, Any] = {"observed_bytes": None, "observed_sha256": None,
                                   "error_category": None, "passed": False}
        try:
            before = path.stat()
            observed["observed_bytes"] = before.st_size
            observed["observed_sha256"] = digest(path)
            after = path.stat()
            if (before.st_size, before.st_mtime_ns, before.st_ino) != (
                    after.st_size, after.st_mtime_ns, after.st_ino):
                observed["error_category"] = "file_changed_during_hash"
            elif before.st_size != frozen[name][0]:
                observed["error_category"] = "size_mismatch"
            elif observed["observed_sha256"] != frozen[name][1]:
                observed["error_category"] = "sha256_mismatch"
            else:
                observed["passed"] = True
        except FileNotFoundError:
            observed["error_category"] = "missing_file"
        except OSError as error:
            observed["error_category"] = "hash_io_error"
            observed["error_type"] = type(error).__name__
        observed["observed_matches_expected_filenames"] = [
            other for other, pair in frozen.items() if pair[1] == observed["observed_sha256"]]
        event("hash_completed", name, phase, **observed)
        unchanged()
        return observed

    try:
        save()
        phase = "initial"
        while True:
            results = {name: check_file(name, phase) for name in sorted(frozen)}
            bad = [name for name, result in results.items() if not result["passed"]]
            if not bad:
                if phase != "final_recheck":
                    phase = "final_recheck"
                    continue
                receipt["final_verified_files"] = {name: {"bytes": result["observed_bytes"],
                    "sha256": result["observed_sha256"]} for name, result in results.items()}
                receipt.update(status="passed", all_shards_verified=True, passed_unix=time.time())
                save()
                return receipt
            for name in bad:
                while True:
                    unchanged()
                    if receipt["forced_redownloads_used"] >= MAX_FORCED_REDOWNLOADS:
                        raise CheckpointIntegrityError(
                            "Global two-shard fresh-download limit exhausted")
                    receipt["forced_redownloads_used"] += 1
                    attempts[name] += 1
                    event("forced_download_started", name, "repair")
                    try:
                        returned = download(name)
                    except Exception as error:
                        event("forced_download_failed", name, "repair",
                              error_category="download_error",
                              error_type=type(error).__name__)
                        raise CheckpointIntegrityError(
                            "Fresh pinned shard download failed: " + name) from None
                    unchanged()
                    if os.path.normcase(os.path.realpath(returned)) != os.path.normcase(
                            os.path.realpath(target(root, name))):
                        event("forced_download_failed", name, "repair",
                              error_category="wrong_returned_path")
                        raise CheckpointIntegrityError("Fresh download returned a different file")
                    event("forced_download_completed", name, "repair")
                    if check_file(name, "post_redownload")["passed"]:
                        break
            phase = "final_recheck"
    except BaseException as error:
        message = str(error)
        category = ("expected_metadata_changed" if "metadata changed" in message else
                    "global_repair_limit_exhausted" if "limit exhausted" in message else
                    "wrong_returned_path" if "different file" in message else
                    "download_error" if "download failed" in message else "verification_error")
        receipt.update(status="failed", all_shards_verified=False, failed_unix=time.time(),
                       error_type=type(error).__name__, error=message, error_category=category)
        # Never re-read mutable caller metadata while recording a failure.
        save()
        raise


def verify_prepared_fingerprint(spec: dict[str, Any], receipt: dict[str, Any],
                                pins: dict[str, dict[str, Any]]) -> dict[str, Any]:
    expected = normalize(pins)
    if (receipt.get("status") != "passed" or receipt.get("all_shards_verified") is not True
            or receipt.get("final_verified_files") != {
                name: {"bytes": pair[0], "sha256": pair[1]} for name, pair in expected.items()}):
        raise CheckpointIntegrityError(
            "Prepared model lacks complete exact checkpoint verification")
    actual = spec.get("model_fingerprint", {})
    actual_weights = {name: value for name, value in actual.items()
                      if name.endswith(".safetensors")}
    if actual_weights != {name: pair[1] for name, pair in expected.items()}:
        raise CheckpointIntegrityError(
            "Prepared model fingerprint differs from official pinned weights")
    return {"passed": True, "files": len(expected), "unix": time.time(),
            "scope": "Native prepare fingerprint equals every official pinned weight SHA256",
            "model_fingerprint": actual_weights}


def verify_hub_force_semantics(control_dir: Path) -> dict[str, Any]:
    """Exercise the installed 1.33.0 download primitive with tiny local, network-free data."""
    hub = importlib.import_module("huggingface_hub")
    module = importlib.import_module("huggingface_hub.file_download")
    if hub.__version__ != HUB_VERSION:
        raise CheckpointIntegrityError(
            "Pinned Hub version differs; force-download semantics unverified")
    control_dir = Path(control_dir)
    control_dir.mkdir(parents=True, exist_ok=False)
    destination, partial = control_dir / "destination.bin", control_dir / "stale.incomplete"
    destination.write_bytes(b"CACHED_OLD_BYTES")
    partial.write_bytes(b"PARTIAL_OLD_BYTES")
    calls = []
    original = module.http_get

    def local_writer(_url, stream, **kwargs):
        calls.append({"position": stream.tell(), "resume_size": kwargs.get("resume_size", 0)})
        stream.write(b"SOUP")

    try:
        module.http_get = local_writer
        module._download_to_tmp_and_move(
            incomplete_path=partial, destination_path=destination,
            url_to_download="https://invalid.example/no-network", headers={}, expected_size=4,
            filename="destination.bin", force_download=True,
            etag=hashlib.sha256(b"SOUP").hexdigest(),
            xet_file_data=None)
    finally:
        module.http_get = original
    if (calls != [{"position": 0, "resume_size": 0}] or destination.read_bytes() != b"SOUP"
            or module.http_get is not original):
        raise CheckpointIntegrityError("Hub force download reused cached or partial input bytes")
    return {"passed": True, "hub_version": hub.__version__, "unix": time.time(),
            "source_path": os.path.realpath(inspect.getfile(module)),
            "source_sha256": digest(Path(inspect.getfile(module))),
            "cached_destination_replaced": True, "fresh_stream_position": 0,
            "resume_size": 0, "real_network_invoked": False, "http_function_restored": True,
            "scope": "Installed primitive with cached destination and stale partial;"
                     " only its network writer was temporarily stubbed and then restored"}
