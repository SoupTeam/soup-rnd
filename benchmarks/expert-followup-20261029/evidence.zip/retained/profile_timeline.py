"""Independent audit of baseline profiles and grouped-dispatch qualification.

No GPU, network, cloud API, SSH or resource operation is implemented here.
Profiling is diagnostic; nested/operator times are never added into a step
percentage. The original numerical comparator must match the frozen source SHA.
"""

from __future__ import annotations

import argparse
import ast
import gzip
import hashlib
import importlib.util
import json
import math
import os
import random
import re
import statistics
import struct
import subprocess
import traceback
import xml.etree.ElementTree as ET
from collections import Counter
from collections.abc import Iterator
from pathlib import Path, PurePosixPath
from typing import Any

REVISION = "0d31365acf656e5f9a593cacc4913e9c0d36cb1c"
MODEL = "kakaocorp/kanana-2-30b-a3b-base-2601"
GIB = 2**30
ARMS = ("ordinary", "two_read", "two_read_cache")
PROFILES = ("two_read", "two_read_cache")
CUDA_NAMES = (
    "test_real_cuda_nf4_bf16_kanana_worker_trajectories",
    "test_real_cuda_nf4_expert_cache_preserves_complete_optimizer_trajectories[lru]",
    "test_real_cuda_nf4_expert_cache_preserves_complete_optimizer_trajectories[static]",
    "test_real_cuda_profiler_collects_kernel_and_h2d_events",
    "test_real_cuda_nf4_bf16_grouped_route_worker_trajectories",
)
SCALARS = (
    "aten::item",
    "aten::_local_scalar_dense",
    "aten::is_nonzero",
    "aten::nonzero",
    "aten::where",
)
SHA = re.compile(r"[0-9a-f]{64}\Z")


def require(value: Any, text: str) -> None:
    if not value:
        raise ValueError(text)


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(8 * 2**20), b""):
            value.update(chunk)
    return value.hexdigest()


def finite(value: Any) -> bool:
    return type(value) in (int, float) and math.isfinite(value)


def contained(root: Path, name: str) -> Path:
    require(isinstance(name, str) and name and "\\" not in name, "invalid evidence path")
    parts = PurePosixPath(name)
    require(
        not parts.is_absolute()
        and parts.as_posix() == name
        and not any(part in (".", "..") for part in parts.parts),
        "noncanonical evidence path",
    )
    base = os.path.realpath(root)
    target = os.path.realpath(os.path.join(base, *parts.parts))
    require(
        os.path.normcase(os.path.commonpath((base, target))) == os.path.normcase(base),
        "evidence escaped its root",
    )
    require(Path(target).is_file(), "missing ordinary evidence file: " + name)
    return Path(target)


def loss_gate(reference: list[float], candidate: list[float]) -> dict:
    require(reference and len(reference) == len(candidate), "incomplete loss sequence")
    failures = []
    for number, (expected, actual) in enumerate(zip(reference, candidate)):
        if (
            not finite(expected)
            or not finite(actual)
            or abs(actual - expected) > 1e-5 + 0.01 * abs(expected)
            or f"{actual:.3f}" != f"{expected:.3f}"
        ):
            failures.append({"index": number, "reference": expected, "candidate": actual})
    return {
        "passed": not failures,
        "checks": len(reference),
        "reference_relative_rtol": 0.01,
        "atol": 1e-5,
        "bitwise_scalar_values": reference == candidate,
        "failures": failures,
    }


def tensor_index(values: dict[str, Any]) -> dict:
    import torch

    rows = {}
    for name, tensor in sorted(values.items()):
        require(torch.is_tensor(tensor), "not a tensor")
        value = tensor.detach().cpu().contiguous()
        raw = value.reshape(-1).view(torch.uint8).numpy().tobytes()
        rows[name] = {
            "dtype": str(value.dtype),
            "shape": list(value.shape),
            "bytes": len(raw),
            "sha256": hashlib.sha256(raw).hexdigest(),
        }
    raw = json.dumps(rows, sort_keys=True, separators=(",", ":")).encode()
    return {"tensors": rows, "canonical_index_sha256": hashlib.sha256(raw).hexdigest()}


def validate_hash_index(value: Any) -> dict:
    require(
        isinstance(value, dict) and isinstance(value.get("tensors"), dict) and value["tensors"],
        "tensor hash index absent",
    )
    for name, row in value["tensors"].items():
        require(isinstance(name, str) and name and isinstance(row, dict), "invalid hash row")
        require(
            isinstance(row.get("dtype"), str)
            and row["dtype"].startswith("torch.")
            and isinstance(row.get("shape"), list)
            and all(type(item) is int and item >= 0 for item in row["shape"])
            and type(row.get("bytes")) is int
            and row["bytes"] > 0
            and isinstance(row.get("sha256"), str)
            and SHA.fullmatch(row["sha256"]),
            "invalid tensor hash metadata: " + name,
        )
    raw = json.dumps(value["tensors"], sort_keys=True, separators=(",", ":")).encode()
    require(
        hashlib.sha256(raw).hexdigest() == value.get("canonical_index_sha256"),
        "canonical tensor index digest differs",
    )
    return value["tensors"]


def validate_training_hash_index(value: Any, names: set[str], updates: int) -> None:
    rows = validate_hash_index(value)
    expected = {prefix + name for name in names for prefix in ("adapter/", "gradient/")}
    expected |= {
        f"adamw/{name}/{key}" for name in names for key in ("step", "exp_avg", "exp_avg_sq")
    }
    require(set(rows) == expected, "state hash index omitted adapter/gradient/AdamW tensors")
    step_sha = hashlib.sha256(struct.pack("<f", float(updates))).hexdigest()
    for name, row in rows.items():
        require(
            row["dtype"] == "torch.float32" and row["bytes"] == 4 * math.prod(row["shape"]),
            "state dtype/byte count differs",
        )
        if name.endswith("/step"):
            require(
                row["shape"] == [] and row["sha256"] == step_sha,
                "AdamW step hash does not prove expected updates",
            )


def verify_gzip(path: Path, proof: dict) -> dict:
    require(
        path.stat().st_size == proof["bytes"]
        and digest(path) == proof["sha256"]
        and proof["decoded_verified"] is True,
        "encoded trace size/SHA differs",
    )
    value, count = hashlib.sha256(), 0
    with gzip.open(path, "rb") as source:
        for block in iter(lambda: source.read(8 * 2**20), b""):
            value.update(block)
            count += len(block)
    require(
        count == proof["decoded_bytes"] and value.hexdigest() == proof["decoded_sha256"],
        "decoded trace size/SHA differs",
    )
    return {
        "encoded_bytes": path.stat().st_size,
        "encoded_sha256": proof["sha256"],
        "decoded_bytes": count,
        "decoded_sha256": value.hexdigest(),
        "all_original_trace_bytes_verified": True,
    }


def trace_events(
    source: Any, metadata: dict, *, chunk_bytes: int = 65536, maximum_buffer: int = 8 * 2**20
) -> Iterator[dict]:
    """Stream JSON events with a fixed maximum prefix/event/suffix buffer."""
    decoder, buffer, cursor = json.JSONDecoder(), "", 0
    pattern = re.compile(r'"traceEvents"\s*:\s*\[')
    while True:
        found = pattern.search(buffer)
        if found:
            prefix, cursor = buffer[: found.end()], found.end()
            break
        block = source.read(chunk_bytes)
        require(block, "traceEvents array is missing")
        buffer += block
        require(len(buffer) <= maximum_buffer, "trace prefix exceeds parser bound")
    count = 0
    after_event = False
    while True:
        while cursor < len(buffer) and buffer[cursor].isspace():
            cursor += 1
        if cursor == len(buffer):
            buffer, cursor = "", 0
            block = source.read(chunk_bytes)
            require(block, "unterminated traceEvents array")
            buffer += block
            continue
        if buffer[cursor] == "]":
            suffix = buffer[cursor + 1 :]
            while True:
                block = source.read(chunk_bytes)
                if not block:
                    break
                suffix += block
                require(len(suffix) <= maximum_buffer, "trace suffix exceeds parser bound")
            envelope = json.loads(prefix + "]" + suffix)
            require(
                isinstance(envelope, dict) and envelope.get("traceEvents") == [],
                "invalid trace envelope",
            )
            metadata.update({key: value for key, value in envelope.items() if key != "traceEvents"})
            metadata["parsed_events"] = count
            return
        if after_event:
            require(buffer[cursor] == ",", "trace events lack a JSON comma")
            cursor += 1
            after_event = False
        while cursor < len(buffer) and buffer[cursor].isspace():
            cursor += 1
        while True:
            while cursor < len(buffer) and buffer[cursor].isspace():
                cursor += 1
            try:
                value, end = decoder.raw_decode(buffer, cursor)
                break
            except json.JSONDecodeError:
                buffer, cursor = buffer[cursor:], 0
                block = source.read(chunk_bytes)
                require(block, "invalid or unterminated trace event")
                buffer += block
                require(len(buffer) <= maximum_buffer, "trace event exceeds parser buffer bound")
        require(isinstance(value, dict), "trace event is not an object")
        yield value
        count += 1
        after_event = True
        cursor = end
        if cursor > chunk_bytes:
            buffer, cursor = buffer[cursor:], 0


def interval_union(intervals: list[tuple[float, float]]) -> float:
    if not intervals:
        return 0.0
    ordered = sorted(intervals)
    start, end = ordered[0]
    total = 0.0
    for left, right in ordered[1:]:
        if left > end:
            total += end - start
            start, end = left, right
        else:
            end = max(end, right)
    return total + end - start


def analyze_trace(path: Path, *, maximum_gpu_intervals: int = 1_000_000) -> dict:
    metadata, phases, intervals = {}, {}, {}
    cpu_counts, categories = Counter(), Counter()
    gpu_count, overflow = 0, False
    with gzip.open(path, "rt", encoding="utf-8") as source:
        for event in trace_events(source, metadata):
            name, category = event.get("name", ""), event.get("cat", "")
            categories[str(category)] += 1
            if event.get("ph") != "X":
                continue
            timestamp, duration = event.get("ts"), event.get("dur")
            require(
                finite(timestamp) and finite(duration) and duration >= 0,
                "non-finite or negative complete trace interval",
            )
            if category in ("cpu_op", "user_annotation"):
                cpu_counts[name] += 1
            if name.startswith("soup.profile.microbatch."):
                phases.setdefault(name, []).append(
                    {
                        "start_us": timestamp,
                        "end_us": timestamp + duration,
                        "pid": event.get("pid"),
                        "tid": event.get("tid"),
                    }
                )
            if category not in ("kernel", "gpu_memcpy", "gpu_memset"):
                continue
            gpu_count += 1
            if gpu_count > maximum_gpu_intervals:
                overflow = True
                continue
            args = event.get("args") or {}
            device = str(args.get("device", event.get("pid", "unknown")))
            groups = intervals.setdefault(
                device, {"all": [], "kernel": [], "gpu_memcpy": [], "gpu_memset": [], "h2d": []}
            )
            value = (float(timestamp), float(timestamp + duration))
            groups["all"].append(value)
            groups[category].append(value)
            if category == "gpu_memcpy" and any(
                token in name.lower()
                for token in (
                    "htod",
                    "h2d",
                    "host to device",
                )
            ):
                groups["h2d"].append(value)
    devices = {}
    if not overflow:
        for device, groups in intervals.items():
            events = groups["all"]
            left, right = min(item[0] for item in events), max(item[1] for item in events)
            busy = interval_union(events)
            devices[device] = {
                "event_span_us": right - left,
                "busy_union_us": busy,
                "gaps_inside_observed_device_span_us": max(0.0, right - left - busy),
                "union_us_by_kind": {
                    key: interval_union(value) for key, value in groups.items() if key != "all"
                },
                "events": len(events),
                "first_event_us": left,
                "last_event_end_us": right,
            }
    annotated = [item for rows in phases.values() for item in rows]
    envelope = (
        max(item["end_us"] for item in annotated) - min(item["start_us"] for item in annotated)
        if annotated
        else None
    )
    return {
        "status": "interval_limit_no_union_verdict" if overflow else "parsed",
        "decoded_json_metadata": metadata,
        "event_category_counts": dict(categories),
        "cpu_scalar_counts": {name: cpu_counts[name] for name in SCALARS},
        "soup_marker_counts": {
            name: count for name, count in cpu_counts.items() if name.startswith("soup.")
        },
        "gpu_complete_events": gpu_count,
        "maximum_gpu_intervals": maximum_gpu_intervals,
        "devices": devices,
        "microbatch_cpu_phase_annotations": phases,
        "cpu_phase_envelope_us_excluding_final_sync": envelope,
        "interpretation": "GPU busy is an interval union across streams. Gaps are inside "
        "first-to-last recorded GPU activity only, not a whole-step idle percentage "
        "or proof of a particular bottleneck. CPU phase annotations end before "
        "the final CUDA sync. All durations include profiler overhead.",
    }


def analyze_averages(value: dict) -> dict:
    rows = value.get("key_averages")
    require(isinstance(rows, list) and rows, "unfiltered operator averages absent")
    fields = (
        "cpu_time_total_us",
        "self_cpu_time_total_us",
        "device_time_total_us",
        "self_device_time_total_us",
    )
    for row in rows:
        require(
            isinstance(row.get("name"), str)
            and row["name"]
            and isinstance(row.get("device_type"), str)
            and type(row.get("count")) is int
            and row["count"] > 0
            and all(finite(row.get(key)) for key in fields),
            "invalid profiler aggregate",
        )

    def selected(tokens: tuple[str, ...]) -> list:
        return [row for row in rows if any(token in row["name"].lower() for token in tokens)]

    return {
        "all_operator_averages": rows,
        "operator_rows": len(rows),
        "top_self_cpu": sorted(rows, key=lambda row: row["self_cpu_time_total_us"], reverse=True)[
            :40
        ],
        "top_self_device": sorted(
            rows, key=lambda row: row["self_device_time_total_us"], reverse=True
        )[:40],
        "soup_markers": selected(("soup.",)),
        "scalar_ops": {name: [row for row in rows if row["name"] == name] for name in SCALARS},
        "cuda_sync_or_copy": selected(
            ("synchronize", "memcpy", "aten::to", "aten::_to_copy", "aten::copy_")
        ),
        "nf4": selected(("dequant", "quant_state")),
        "matrix_ops": selected(("aten::mm", "aten::matmul", "aten::bmm", "gemm", "xmma")),
        "interpretation": "All original rows are preserved. Inclusive marker/device times "
        "overlap and must not be added into a whole-step percentage. Rankings are "
        "only for this instrumented first-microbatch diagnostic.",
    }


class ProfileAudit:
    def __init__(
        self, stage: Path, source: Path, expected_source: str, *, timeline: bool = True
    ) -> None:
        require(
            isinstance(expected_source, str) and re.fullmatch("[0-9a-f]{40}", expected_source),
            "explicit exact expected source commit is required",
        )
        self.expected_source = expected_source
        self.stage, self.root, self.source = stage, stage / "retained", source
        self.timeline = timeline
        self.report: dict[str, Any] = {
            "status": "running",
            "checks": [],
            "files": {},
            "accuracy": {},
            "profiles": {},
            "unprofiled_speed_verdict": "NO VERDICT",
        }
        self.pids: set[int] = set()

    def check(self, value: Any, text: str) -> None:
        self.report["checks"].append({"check": text, "passed": bool(value)})
        if not value:
            raise AssertionError(text)

    def file(self, name: str) -> Path:
        path = contained(self.root, name)
        row = {"bytes": path.stat().st_size, "sha256": digest(path)}
        self.check(row == self.outer["files"][name], "retained bytes stable: " + name)
        self.report["files"][name] = row
        return path

    def read(self, name: str) -> Any:
        return json.loads(self.file(name).read_text(encoding="utf-8"))

    def retention(self) -> None:
        self.outer = json.loads((self.stage / "archive-manifest.json").read_text())
        outer = self.outer
        bundle = json.loads((self.stage / "bundle-verified.json").read_text())
        archive = self.stage / "result.lossless.tar"
        self.check(
            outer["format"] == bundle["format"] == "soup-lossless-results-v1"
            and bundle["expected_source_commit"] == bundle["export_source_commit"]
            == self.expected_source
            and outer["source_commit"] == self.expected_source
            and outer["stage_status"]["status"] == "completed",
            "complete frozen cohort",
        )
        self.check(
            archive.stat().st_size == outer["archive_bytes"] and digest(archive) == outer["sha256"],
            "full archive size/SHA",
        )
        self.check(
            bundle["all_manifested_raw_files_retained"] is True
            and bundle["verified_files"] == len(outer["files"])
            and bundle["sha256"] == outer["sha256"]
            and bundle["bytes"] == outer["archive_bytes"],
            "retention receipts agree",
        )
        checked, size = {}, 0
        for name, expected in outer["files"].items():
            path = contained(self.root, name)
            before = path.stat()
            key = (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns)
            identity = checked.get(key) if before.st_ino else None
            if identity is None:
                identity = digest(path)
                if before.st_ino:
                    checked[key] = identity
            self.check(
                before.st_size == expected["bytes"]
                and identity == expected["sha256"]
                and path.stat().st_mtime_ns == before.st_mtime_ns,
                "all-original file size/SHA/containment: " + name,
            )
            self.report["files"][name] = dict(expected)
            size += before.st_size
        self.check(
            size == outer["original_bytes"] == bundle["original_bytes"],
            "all original byte counts agree",
        )
        self.report["retention"] = {
            "files": len(outer["files"]),
            "original_bytes": size,
            "archive_bytes": archive.stat().st_size,
            "archive_sha256": outer["sha256"],
        }
        receipt = json.loads((self.stage / "vast-rental.json").read_text())
        for name in ("vast-deletion.json", "independent-vast-absence.json"):
            proof = json.loads((self.stage / name).read_text())
            self.check(
                proof["verified_absent"] is True
                and proof["volume_verified_absent"] is True
                and int(proof["instance_id"]) == int(receipt["instance_id"])
                and int(proof["volume_id"]) == int(receipt["volume_id"]),
                "exact owned instance/volume absent: " + name,
            )
        self.report["cleanup"], self.receipt = proof, receipt

    def resources(self, stage: dict, label: str, spec: dict) -> None:
        data = stage["resources"]
        self.check(
            type(data["sampled_peak_rss_bytes"]) is int
            and 0 < data["sampled_peak_rss_bytes"] <= spec["max_host_bytes"]
            and data["sampled_peak_process_swap_bytes"] == 0
            and data["sampled_peak_cgroup_swap_bytes"] == 0,
            label + ": sampled RSS and zero process/cgroup swap",
        )
        for point in (data["before"], data["after"]):
            groups = point["cgroup"]["constraints"]
            limits = [point["host_memory"]["MemTotal"]] + [
                row["memory.max"] for row in groups if type(row.get("memory.max")) is int
            ]
            self.check(
                28 * GIB <= min(limits) <= spec["max_host_bytes"] <= 32 * GIB,
                label + ": real native RAM boundary",
            )
            self.check(
                point["process_swap_bytes"] == 0
                and all(row.get("memory.swap.current") in (0, None) for row in groups)
                and (
                    point["host_memory"].get("SwapTotal", 0) == 0
                    or any(row.get("memory.swap.max") == 0 for row in groups)
                ),
                label + ": swap unavailable and unused",
            )
        for name in ("cuda", "cuda_including_diagnostics"):
            if name in stage:
                self.check(
                    all(
                        type(stage[name].get(key)) is int
                        and 0 <= stage[name][key] <= spec["device_cap_bytes"]
                        for key in ("peak_allocated_bytes", "peak_reserved_bytes")
                    ),
                    label + ": unchanged allocator VRAM cap",
                )

    def environment(self, row: dict, label: str, spec: dict) -> None:
        env = row["environment"]
        self.check(
            env["gpu_total_bytes"] == spec["hardware"]["physical_vram_bytes"]
            and 7.5 * GIB <= env["gpu_total_bytes"] <= 8.5 * GIB
            and env["compute_capability"][0] >= 8
            and env["gpu_name"] == spec["hardware"]["name"]
            and env["allow_tf32"] is False
            and env["deterministic_algorithms"] is True,
            label + ": physical BF16 8-GB GPU and fixed numerical mode",
        )
        for name, version in env["versions"].items():
            if name in spec["environment"]["packages"]:
                self.check(
                    version == spec["environment"]["packages"][name],
                    label + ": fixed dependency " + name,
                )
        pid = row["pid"]
        self.check(
            type(pid) is int and pid > 0 and pid not in self.pids,
            label + ": distinct fresh worker PID",
        )
        self.pids.add(pid)

    def admission(self, plan: Any, arm: str, spec: dict) -> None:
        if arm != "two_read_cache":
            self.check(plan is None, arm + ": no cache admission")
        else:
            self.check(
                isinstance(plan, dict)
                and all(
                    plan.get(name) == spec[name]
                    for name in ("host_cache_bytes", "device_cache_bytes", "host_cache_policy")
                ),
                arm + ": exact full cache ceilings without fallback",
            )

    def cache(self, before: dict, after: dict, arm: str) -> dict:
        cached = arm == "two_read_cache"
        delta = {
            name: after[name] - before[name]
            for name in (
                "logical_fetches",
                "storage_reads",
                "storage_bytes_read",
                "materializations",
            )
        }
        for tier, ceiling in (("host", 8 * GIB), ("device", 2 * GIB)):
            expected = ceiling if cached else 0
            self.check(
                all(
                    row["budget_bytes"] == expected
                    and type(row["payload_bytes"]) is int
                    and 0 <= row["payload_bytes"] <= expected
                    for row in (before[tier], after[tier])
                ),
                arm + ": unchanged full " + tier + " ceiling",
            )
            delta[tier + "_hits"] = after[tier]["hits"] - before[tier]["hits"]
        self.check(
            all(type(value) is int and value >= 0 for value in delta.values())
            and delta["logical_fetches"] > 0
            and delta["storage_reads"] > 0
            and delta["storage_bytes_read"] > 0
            and delta["logical_fetches"]
            == delta["storage_reads"] + delta["host_hits"] + delta["device_hits"]
            and delta["materializations"] == delta["logical_fetches"] - delta["device_hits"],
            arm + ": fetch/read/hit/materialization arithmetic",
        )
        if cached:
            self.check(
                min(delta["host_hits"], delta["device_hits"]) > 0
                and before["host_cache_policy"] == after["host_cache_policy"] == "static"
                and before["host"]["evictions"] == after["host"]["evictions"],
                arm + ": both static tiers exercised without replacement",
            )
        else:
            self.check(
                delta["host_hits"] == delta["device_hits"] == 0,
                arm + ": uncached baseline remained uncached",
            )
        return delta

    def execute(self) -> dict:
        import torch

        torch.set_num_threads(1)
        self.retention()
        source, protocol = self.read("source-manifest.json"), self.read("protocol.json")
        self.check(
            source["source_commit"] == protocol["source_commit"] == self.expected_source,
            "frozen profiling source commit",
        )
        self.check(
            digest(self.stage / "source.tar.gz") == source["archive_sha256"],
            "private source archive matches the executed frozen source manifest",
        )
        self.check(
            protocol["model"]["repo_id"] == MODEL
            and protocol["model"]["revision"] == REVISION
            and protocol["model"]["weights_bytes"] == 61343935088,
            "pinned official 30B checkpoint",
        )
        self.check(
            json.loads((self.stage / "protocol.json").read_text()) == protocol,
            "private and retained frozen protocols agree",
        )
        self.check(
            str(self.receipt["label"]).startswith(protocol["stage_id"]),
            "owned receipt belongs to this stage",
        )
        performance = protocol["performance"]
        self.check(
            tuple(performance["accuracy_arms"]) == ARMS
            and tuple(performance["profile_arms"]) == PROFILES
            and performance["profiled_times_are_diagnostic_only"] is True,
            "three full accuracy arms then two diagnostic profiles",
        )
        name = "benchmarks/harness/two_read_cache_common.py"
        common_path = self.source / name
        self.check(
            digest(common_path) == source["files"][name]["sha256"],
            "original numerical comparator matches frozen executed bytes",
        )
        loader = importlib.util.spec_from_file_location(
            "frozen_profile_numerical_gates", common_path
        )
        common = importlib.util.module_from_spec(loader)
        loader.loader.exec_module(common)
        self.check(common.RTOL == 0.01 and common.ATOL == 1e-5, "unchanged numerical tolerances")
        self.common, self.source_manifest, self.protocol = common, source, protocol
        capacity = self.read("results/capacity-preflight.json")
        self.check(
            capacity["passed"] is True
            and 7900 <= capacity["gpu_memory_mib"] <= 8300
            and 28 * GIB <= capacity["native_ram_limit_bytes"] <= 32 * GIB
            and int(capacity["container_id"]) == int(self.receipt["instance_id"]),
            "actual owned physical 8-GB/native <=32-GiB startup",
        )
        spec = self.read("results/prepared/spec.json")
        identity = self.outer["files"]["results/prepared/spec.json"]["sha256"]
        self.spec, self.spec_identity = spec, identity
        self.check(
            spec["git_head"] == self.expected_source
            and spec["quant"] == "nf4"
            and spec["dtype"] == "bfloat16"
            and spec["seq_len"] == 512
            and spec["batch_size"] == 1
            and spec["accumulation"] == 2
            and spec["accuracy_updates"] == 2
            and spec["warmup_updates"] == 2
            and spec["timed_updates"] == 6
            and spec["rounds"] == 4
            and spec["lora_r"] == 4
            and spec["lora_alpha"] == 8
            and spec["lora_targets"] == ["q_proj", "kv_b_proj", "o_proj"]
            and spec["host_cache_bytes"] == 8 * GIB
            and spec["device_cache_bytes"] == 2 * GIB
            and spec["host_cache_policy"] == "static"
            and spec["device_cap_bytes"] == 8 * GIB
            and spec["max_host_bytes"] <= 32 * GIB,
            "fixed NF4/BF16 attention-LoRA/cache recipe",
        )
        self.check(
            str(capacity["gpu_uuid"]).removeprefix("GPU-")
            == str(spec["hardware"]["uuid"]).removeprefix("GPU-"),
            "actual GPU UUID",
        )
        for path, sha in spec["source_fingerprint"].items():
            self.check(source["files"][path]["sha256"] == sha, "executed source binding: " + path)
        pinned = self.read("results/model-pinned.json")
        self.check(
            pinned["repo_id"] == MODEL
            and pinned["revision"] == REVISION
            and len(pinned["files"]) == 13
            and pinned["weights_bytes"] == 61343935088
            and sum(row["bytes"] for row in pinned["files"].values()) == 61343935088,
            "all 13 pinned public shards",
        )
        for path, row in pinned["files"].items():
            self.check(
                row["lfs"]["sha256"] == spec["model_fingerprint"][path]
                and row["bytes"] == spec["model_stat"][path][0],
                "pinned LFS binding: " + path,
            )
        config, index = (
            self.read("results/model-config.json"),
            self.read("results/cache-index.json"),
        )
        self.check(
            self.outer["files"]["results/model-config.json"]["sha256"]
            == spec["model_fingerprint"]["config.json"]
            and self.outer["files"]["results/cache-index.json"]["sha256"]
            == spec["store_fingerprint"]["index.json"],
            "actual metadata bytes",
        )
        self.check(
            config["model_type"] == "deepseek_v3"
            and config["num_hidden_layers"] == 48
            and config["n_routed_experts"] == 128
            and config["num_experts_per_tok"] == 6
            and config["rope_interleave"] is True
            and config["q_lora_rank"] is None
            and index["expert_layout"] == "per_expert"
            and index["n_layers"] == 48
            and index["expert_layers"] == list(range(1, 48))
            and index["expert_count"] == 128
            and index["quant"] == "nf4"
            and index["double_quant"] is True
            and index["expert_shapes"] == {"gate_up": [1536, 2048], "down": [2048, 768]},
            "actual native 6016-expert Kanana NF4 layout",
        )
        for part, shape in index["expert_shapes"].items():
            quant = index["expert_quant_specs"][part]
            self.check(
                quant["shape"] == shape
                and quant["nested"] is True
                and quant["blocksize"] == 64
                and quant["nested_blocksize"] == 256
                and quant["quant_type"] == "nf4",
                "actual packed NF4 sidecar layout: " + part,
            )
        cases = ET.parse(self.file("results/gpu-preflight.xml")).findall(".//testcase")
        self.check(
            len(cases) == 5
            and sorted(case.attrib["name"] for case in cases) == sorted(CUDA_NAMES)
            and all(
                case.find(tag) is None for case in cases for tag in ("skipped", "failure", "error")
            ),
            "five actual CUDA controls passed without skips",
        )
        proofs = [
            path for path in self.outer["files"] if path.endswith("/cuda-profiler-proof.json")
        ]
        self.check(len(proofs) == 1, "actual CUDA profiler preflight proof retained")
        proof = self.read(proofs[0])
        self.check(
            proof["event_count"] > proof["cuda_event_count"] > 0
            and proof["cuda_kernel_event_count"] > 0
            and proof["cuda_h2d_event_count"] > 0,
            "actual preflight CPU, CUDA kernels and H2D activity",
        )
        inputs_path = self.file("results/prepared/inputs.pt")
        self.check(digest(inputs_path) == spec["training_data_sha256"], "frozen input bytes")
        inputs = torch.load(inputs_path, map_location="cpu", weights_only=True)
        self.check(
            inputs.dtype == torch.long and tuple(inputs.shape) == (4, 1, 512),
            "frozen input dimensions",
        )
        run = self.read("results/accuracy/run.json")
        self.check(
            run["status"] == "accuracy_passed"
            and run["accuracy_passed"] is True
            and run["spec_sha256"] == identity
            and run["source_commit"] == self.expected_source
            and run["unchanged_reference_relative_rtol"] == 0.01
            and run["unchanged_atol"] == 1e-5
            and set(run["accuracy"]) == set(ARMS),
            "complete original three-arm numerical phase",
        )
        reference, initial, names = None, None, set()
        losses, counters = {}, {}
        for arm in ARMS:
            directory = "results/accuracy/" + arm
            row = self.read(directory + "/result.json")
            control = self.read(directory + "/controller-result.json")
            self.check(
                all(control.get(key) == value for key, value in row.items())
                and run["accuracy"][arm]["worker"] == control,
                arm + ": controller/raw copies",
            )
            self.check(
                row["status"] == "passed"
                and row["phase"] == "accuracy"
                and row["arm"] == arm
                and row["spec_sha256"] == identity,
                arm + ": worker identity",
            )
            self.environment(row, arm, spec)
            for stage in ("setup", "accuracy"):
                self.resources(row[stage], arm + "/" + stage, spec)
            self.admission(row["setup"]["cache_plan"], arm, spec)
            path = self.file(directory + "/capture.pt")
            self.check(digest(path) == row["accuracy"]["capture_sha256"], arm + ": capture hash")
            capture = torch.load(path, map_location="cpu", weights_only=True)
            self.check(
                len(capture["initial_adapters"]) == 288
                and len(capture["updates"]) == 2
                and len(capture["microbatches"]) == 4,
                arm + ": complete trajectory",
            )
            first, final = capture["initial_adapters"], capture["updates"][-1]["adapters"]
            self.check(
                all(
                    "lora_" in key
                    and value.dtype == final[key].dtype == torch.float32
                    and torch.count_nonzero(value).item() > 0
                    and torch.count_nonzero(final[key]).item() > 0
                    and not torch.equal(value, final[key])
                    for key, value in first.items()
                )
                and all(
                    any(
                        torch.count_nonzero(micro["gradients"][key]).item() > 0
                        for micro in capture["microbatches"]
                    )
                    for key in first
                ),
                arm + ": every adapter nonzero, changed and received nonzero gradient",
            )
            self.check(
                all(
                    torch.equal(micro["input_ids"], inputs[number])
                    for number, micro in enumerate(capture["microbatches"])
                ),
                arm + ": actual frozen tokens",
            )
            if reference is None:
                reference, initial, names = capture, tensor_index(first), set(first)
                gate = common.validate_capture(reference)
            else:
                gate = common.compare_captures(reference, capture)
            self.check(
                gate["passed"] and gate == run["accuracy"][arm]["gate"],
                arm + ": original full trajectory comparator independently reproduced",
            )
            self.report["accuracy"][arm] = gate
            losses[arm] = [float(capture["microbatches"][number]["loss"]) for number in (1, 3)]
            counters[arm] = self.cache(
                row["accuracy"]["runtime_before"]["expert_cache"],
                row["accuracy"]["runtime_after"]["expert_cache"],
                arm,
            )
            self.check(
                counters[arm] == run["expert_counter_deltas"][arm], arm + ": native counters"
            )
            if arm != "ordinary":
                del capture
        del reference
        two = torch.load(
            self.file("results/accuracy/two_read/capture.pt"), map_location="cpu", weights_only=True
        )
        both = torch.load(
            self.file("results/accuracy/two_read_cache/capture.pt"),
            map_location="cpu",
            weights_only=True,
        )
        gate = common.compare_captures(two, both)
        self.check(
            gate["passed"] and gate == run["combined_vs_two_read_gate"],
            "combined versus two-read original full numerical gate independently reproduced",
        )
        self.report["combined_vs_two_read_accuracy"] = gate
        del two, both
        self.check(
            counters["ordinary"]["logical_fetches"] * 2
            == counters["two_read"]["logical_fetches"] * 3
            and counters["two_read"]["logical_fetches"]
            == counters["two_read_cache"]["logical_fetches"],
            "native three/two-read routing schedule",
        )
        self.report["accuracy_counter_deltas"] = counters
        rows = {
            arm: self.profile(
                arm,
                spec,
                identity,
                initial,
                names,
                tensor_index({"input_ids": inputs}),
                losses[arm],
            )
            for arm in PROFILES
        }
        comparison = self.read("results/profiles/comparison.json")
        self.check(
            comparison["passed"] is True and comparison["speed_verdict"] == "NO VERDICT",
            "remote cross-profile controls without a speed verdict",
        )
        for key in ("inputs", "initial_adapters", "scope"):
            self.check(
                rows["two_read"][key] == rows["two_read_cache"][key], "cross-profile exact " + key
            )
        cross = {}
        for stage in ("warmup", "unprofiled_context", "profile_update"):
            gate = loss_gate(
                rows["two_read"][stage]["losses"], rows["two_read_cache"][stage]["losses"]
            )
            self.check(gate["passed"], "cross-profile original loss gate: " + stage)
            cross[stage] = gate
        self.report["cross_profile_loss_gates"] = cross
        state = {}
        for key in ("state_before_profile", "state_after_profile"):
            left, right = rows["two_read"][key], rows["two_read_cache"][key]
            equal = left == right
            state[key] = {
                "reference": left["canonical_index_sha256"],
                "candidate": right["canonical_index_sha256"],
                "bitwise_hashes_equal": equal,
                "verdict": "canonical tensor hashes equal"
                if equal
                else "NO VERDICT: hash differences cannot test numerical tolerance",
            }
            self.check(
                comparison["training_state_hash_comparison"][key]["bitwise_hashes_equal"] == equal,
                "remote extra state-hash information independently reproduced",
            )
        self.report["cross_profile_state_hashes"] = state
        self.check(len(self.pids) == 5, "five distinct accuracy/profile workers")
        diagnostic = self.read("results/diagnostic-only.json")
        self.check(
            diagnostic["no_unprofiled_performance_verdict"] is True
            and diagnostic["profiled_times_are_diagnostic_only"] is True
            and diagnostic["source_commit"] == self.expected_source,
            "diagnostic-only cohort",
        )
        self.report["recipe_and_identity"] = {
            "source_commit": self.expected_source,
            "model": MODEL,
            "model_revision": REVISION,
            "spec_sha256": identity,
            "hardware": spec["hardware"],
            "native_boundary": capacity,
            "environment": spec["environment"],
            "base_storage": "NF4",
            "compute": "BF16",
            "attention_lora_rank": 4,
            "sequence_length": 512,
            "batch_size": 1,
            "accumulation": 2,
            "host_cache_bytes": 8 * GIB,
            "device_cache_bytes": 2 * GIB,
        }
        self.report["limits"] = {
            "quality": "Frozen random tokens/short attention-LoRA trajectories; no downstream "
            "quality, convergence or full-weight training verdict.",
            "profile": "First microbatch only under profiler overhead; second microbatch and "
            "AdamW outside profiler; no repeated unprofiled throughput verdict.",
            "hashes": "Profile-state hash differences alone cannot test numerical tolerances. "
            "Full separate accuracy captures use the original comparator.",
            "storage": "File payload is not physical SSD traffic; "
            "physical NVMe remains unverified.",
            "source": "Large model/store files were fingerprinted remotely, not locally rehashed. "
            "All original output files and actual metadata are independently rehashed.",
        }
        self.report["status"] = "passed_diagnostic_only"
        return self.report

    def profile(
        self,
        arm: str,
        spec: dict,
        identity: str,
        initial: dict,
        names: set[str],
        inputs: dict,
        accuracy_losses: list[float],
    ) -> dict:
        directory = "results/profiles/" + arm
        row = self.read(directory + "/profile-result.json")
        self.check(
            row["status"] == "passed"
            and row["phase"] == "diagnostic_profile"
            and row["arm"] == arm
            and row["spec_sha256"] == identity
            and row["unprofiled_speed_verdict"] == "NO VERDICT",
            arm + ": diagnostic identity",
        )
        self.environment(row, directory, spec)
        self.admission(row["setup"]["cache_plan"], arm, spec)
        for stage in ("setup", "warmup", "unprofiled_context", "profile_update", "postprocess"):
            self.resources(row[stage], directory + "/" + stage, spec)
        for boundary in (row["native_boundary_before"], row["native_boundary_after"]):
            self.check(
                28 * GIB <= boundary["effective_limit_bytes"] <= 32 * GIB
                and boundary["swap_disabled"] is True,
                arm + ": native pre/post profile bound",
            )
        self.check(
            row["inputs"] == inputs and row["initial_adapters"] == initial,
            arm + ": actual input and all initial adapter hashes independently derived",
        )
        self.check(
            row["warmup"]["updates_complete"] == 2
            and row["unprofiled_context"]["updates_complete"] == 1
            and all(
                row[stage]["complete"] is True
                and row[stage]["finite_state_checks_per_update"] is True
                and len(row[stage]["losses"]) == count
                and len(row[stage]["update_seconds"]) == count
                and all(finite(value) and value > 0 for value in row[stage]["update_seconds"])
                for stage, count in (("warmup", 2), ("unprofiled_context", 1))
            ),
            arm + ": complete two warmups and one contextual update",
        )
        warmup_gate = loss_gate(accuracy_losses, row["warmup"]["losses"])
        self.check(warmup_gate["passed"], arm + ": warmup losses match full accuracy phase")
        update = row["profile_update"]
        self.check(
            update["optimizer_updates"] == 1
            and update["accumulation"] == 2
            and update["profiled_microbatches"] == [0]
            and update["unprofiled_microbatches"] == [1]
            and update["finite_training_state"] is True
            and len(update["losses"]) == 2
            and all(finite(value) for value in update["losses"]),
            arm + ": complete finite update",
        )
        scope = row["scope"]
        self.check(
            scope["profiled_optimizer_updates"] == 1
            and scope["profiled_microbatches"] == [0]
            and scope["microbatch_tokens"] == 512
            and scope["activities"] == ["CPU", "CUDA"]
            and all(
                scope[key] is False
                for key in ("record_shapes", "profile_memory", "with_stack", "with_flops")
            ),
            arm + ": fixed bounded first-microbatch profiler scope",
        )
        validate_training_hash_index(row["state_before_profile"], names, 3)
        validate_training_hash_index(row["state_after_profile"], names, 4)
        self.check(True, arm + ": all adapter/gradient/AdamW before/after hash rows")
        counters = self.cache(
            update["runtime_before"]["expert_cache"], update["runtime_after"]["expert_cache"], arm
        )
        trace = row["trace"]
        self.check(
            trace["path"] == "trace.json.gz"
            and trace["within_bound"] is True
            and trace["maximum_encoded_bytes"] == 128 * 2**20
            and 0 < trace["bytes"] <= 128 * 2**20
            and self.read(directory + "/trace-retention.json") == trace,
            arm + ": fixed bounded trace receipt",
        )
        trace_path = self.file(directory + "/trace.json.gz")
        trace_proof = verify_gzip(trace_path, trace)
        self.check(True, arm + ": all encoded and decoded trace bytes rehashed")
        averages = self.read(directory + "/key-averages.json")
        counts = row["profile_event_counts"]
        self.check(
            all(
                type(counts.get(key)) is int
                and counts[key] > 0
                and averages.get(key) == counts[key]
                for key in (
                    "event_count",
                    "cuda_event_count",
                    "cuda_kernel_event_count",
                    "cuda_copy_event_count",
                    "cuda_h2d_event_count",
                )
            )
            and counts["event_count"] > counts["cuda_event_count"],
            arm + ": actual CPU/CUDA/kernel/H2D events",
        )
        analysis = analyze_averages(averages)
        self.check(
            any(item["name"] == "soup.expert.fetch" for item in analysis["soup_markers"]),
            arm + ": actual expert loading markers captured",
        )
        timeline = analyze_trace(trace_path) if self.timeline else {"status": "not_requested"}
        if timeline["status"] == "parsed":
            self.check(
                timeline["gpu_complete_events"] > 0 and timeline["devices"],
                arm + ": actual GPU interval timeline parsed",
            )
            for name in SCALARS:
                expected = sum(
                    item["count"]
                    for item in analysis["scalar_ops"][name]
                    if item["device_type"].lower().endswith("cpu")
                )
                self.check(
                    expected == timeline["cpu_scalar_counts"][name],
                    arm + ": scalar count independently matches trace: " + name,
                )
        self.report["profiles"][arm] = {
            "event_counts": counts,
            "analysis": analysis,
            "timeline": timeline,
            "trace": trace_proof,
            "profile_update_counter_deltas": counters,
            "profile_scope": scope,
            "warmup_accuracy_loss_gate": warmup_gate,
            "memory": {
                stage: {
                    "sampled_peak_rss_bytes": row[stage]["resources"]["sampled_peak_rss_bytes"],
                    "cuda": row[stage]["cuda"],
                }
                for stage in (
                    "setup",
                    "warmup",
                    "unprofiled_context",
                    "profile_update",
                    "postprocess",
                )
            },
            "unprofiled_context_seconds_diagnostic_only": row["unprofiled_context"][
                "update_seconds"
            ],
        }
        return row


QUALIFICATION = "results/dispatch-qualification"
VARIANTS = ("legacy", "grouped")
ORDERS = (("legacy", "grouped"), ("grouped", "legacy")) * 2
ACCURACY_VARIANTS = ("ordinary_legacy", "legacy", "grouped")
NATIVE_ARMS = {
    "ordinary_legacy": "ordinary", "legacy": "two_read_cache", "grouped": "two_read_cache"
}
PHASES = (
    "native_accuracy", "baseline_profile_two_read", "baseline_profile_two_read_cache",
    "cross_profile_comparison", "dispatch_qualification",
)
IDENTITY_PATHS = {
    "expert_module_sha256": "src/soup_cli/utils/expert_stream.py",
    "runtime_module_sha256": "src/soup_cli/utils/layer_stream_runtime.py",
    "wrapper_sha256": "benchmarks/harness/expert_cache_dispatch_qualification.py",
}


def route_flags(enabled: bool) -> dict[str, bool]:
    require(type(enabled) is bool, "route flag must be an actual bool")
    return {str(index): enabled for index in range(1, 48)}


def validate_routes(actual: Any, enabled: bool) -> None:
    require(
        isinstance(actual, dict) and actual == route_flags(enabled)
        and all(type(flag) is bool for flag in actual.values()),
        "actual 47 expert route flags differ",
    )


def validate_dispatch(value: Any, variant: str) -> None:
    require(variant in ACCURACY_VARIANTS and isinstance(value, dict), "invalid dispatch variant")
    enabled = variant == "grouped"
    require(
        value.get("mode") == ("grouped_constructor" if enabled else "legacy_constructor")
        and value.get("grouped_expert_routes") is enabled
        and type(value.get("factory_calls")) is int and value["factory_calls"] == 1
        and value.get("factory_restored") is True
        and isinstance(value.get("build_proofs"), list) and len(value["build_proofs"]) == 1,
        "constructor was not exercised exactly once and restored",
    )
    proof = value["build_proofs"][0]
    require(
        proof.get("checked_before_cache_admission") is True
        and type(proof.get("expert_modules")) is int and proof["expert_modules"] == 47,
        "actual module proof was not obtained before cache admission",
    )
    for name in ("actual_expert_grouped_routes", "runtime_expert_grouped_routes"):
        validate_routes(proof.get(name), enabled)


def constructor_source(path: Path) -> dict[str, Any]:
    """Reproduce inspect.getsource bytes without importing production/model deps."""
    text = path.read_text(encoding="utf-8")
    functions = [node for node in ast.parse(text).body
                 if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
                 and node.name == "build_streamed_model"]
    require(len(functions) == 1, "exact top-level model constructor is absent")
    node = functions[0]
    defaults = dict(zip(
        [arg.arg for arg in node.args.posonlyargs + node.args.args][-len(node.args.defaults):],
        node.args.defaults,
    )) if node.args.defaults else {}
    defaults.update(zip((arg.arg for arg in node.args.kwonlyargs), node.args.kw_defaults))
    flag = defaults.get("grouped_expert_routes")
    require(isinstance(flag, ast.Constant) and flag.value is False,
            "constructor grouped_expert_routes default must remain strictly False")
    start = min([node.lineno] + [item.lineno for item in node.decorator_list]) - 1
    lines = text.splitlines(keepends=True)
    raw = "".join(lines[start:node.end_lineno]).encode("utf-8")
    return {"constructor_source_sha256": hashlib.sha256(raw).hexdigest(),
            "grouped_expert_routes_default": False}


def full_capture(capture: Any, inputs: Any, common: Any) -> dict[str, Any]:
    import torch

    structural = common.validate_capture(capture)
    require(structural["passed"], "original full-capture structural/finite gate failed")
    require(len(capture["initial_adapters"]) == 288
            and len(capture["microbatches"]) == 4 and len(capture["updates"]) == 2,
            "full trajectory must contain 288 adapters/four micros/two AdamW updates")
    initial, final = capture["initial_adapters"], capture["updates"][-1]["adapters"]
    require(all("lora_" in name and value.dtype == final[name].dtype == torch.float32
                and torch.count_nonzero(value).item() > 0
                and torch.count_nonzero(final[name]).item() > 0
                and not torch.equal(value, final[name]) for name, value in initial.items()),
            "every adapter must be FP32/nonzero/changed")
    require(all(any(torch.count_nonzero(batch["gradients"][name]).item() > 0
                    for batch in capture["microbatches"]) for name in initial),
            "every adapter must have a nonzero gradient")
    require(all(torch.equal(batch["input_ids"], inputs[index])
                for index, batch in enumerate(capture["microbatches"])),
            "frozen capture input IDs differ")
    return {"original_validation": structural, "adapters": 288, "microbatches": 4, "updates": 2,
            "losses": [float(batch["loss"]) for batch in capture["microbatches"]]}


def recompute_timing(blocks: list[dict]) -> dict:
    """Recompute paired timing from original values, never trust a saved speed gate."""
    require(len(blocks) == 8, "eight distinct complete timing workers required")
    groups, seen, pids = {}, set(), set()
    for block in blocks:
        number, position, variant = block["round"], block["position"], block["variant"]
        require(type(number) is int and 0 <= number < 4
                and type(position) is int and 0 <= position < 2
                and ORDERS[number][position] == variant
                and (number, variant) not in seen, "balanced AB/BA/AB/BA schedule changed")
        seen.add((number, variant))
        raw = block["result"]["worker"]
        require(type(raw["pid"]) is int and raw["pid"] > 0 and raw["pid"] not in pids,
                "timing workers must use distinct fresh PIDs")
        pids.add(raw["pid"])
        require(raw["arm"] == "two_read_cache" and raw["phase"] == "timing"
                and raw["status"] == "passed", "native timing arm/status changed")
        for phase, count in (("warmup", 2), ("timing", 6)):
            stage = raw[phase]
            require(stage.get("complete") is True and stage.get("updates_complete") == count
                    and stage.get("finite_state_checks_per_update") is True
                    and len(stage.get("update_seconds", [])) == count
                    and len(stage.get("losses", [])) == count
                    and all(finite(value) and value > 0 for value in stage["update_seconds"])
                    and all(finite(value) for value in stage["losses"]),
                    "incomplete/nonfinite warmup or timing")
        groups.setdefault(number, {})[variant] = block["result"]
    logs, checks = [], []
    for number in range(4):
        left, right = (groups[number][name]["worker"] for name in VARIANTS)
        logs.append(math.log(statistics.median(right["timing"]["update_seconds"])
                             / statistics.median(left["timing"]["update_seconds"])))
        for phase in ("warmup", "timing"):
            gate = loss_gate(left[phase]["losses"], right[phase]["losses"])
            require(gate["passed"], "paired recorded loss gate failed")
            checks.append({"round": number, "stage": phase, **gate})
    rng = random.Random(29)
    draws = sorted(100 * (1 - math.exp(statistics.mean(rng.choices(logs, k=4))))
                   for _ in range(5000))
    lower, upper = draws[124], draws[4874]
    absolute = {}
    for variant in VARIANTS:
        rows = [block["result"] for block in blocks if block["variant"] == variant]
        absolute[variant] = {
            "median_step_seconds": statistics.median(
                value for row in rows for value in row["worker"]["timing"]["update_seconds"]),
            "median_setup_seconds": statistics.median(row["worker"]["setup"]["seconds"]
                                                       for row in rows),
            "median_whole_entry_seconds": statistics.median(
                row["fresh_process_wall_seconds"] for row in rows),
            "max_step_allocated_bytes": max(row["worker"]["timing"]["cuda"][
                "peak_allocated_bytes"] for row in rows),
            "max_step_reserved_bytes": max(row["worker"]["timing"]["cuda"][
                "peak_reserved_bytes"] for row in rows),
            "max_sampled_timing_rss_bytes": max(row["worker"]["timing"]["resources"][
                "sampled_peak_rss_bytes"] for row in rows),
        }
    return {
        "step_time_reduction_percent": 100 * (1 - math.exp(statistics.mean(logs))),
        "paired_bootstrap_95_percent": [lower, upper],
        "passes_practical_2_percent_gate": lower >= 2.0,
        "bootstrap_samples": 5000, "bootstrap_seed": 29, "paired_rounds": 4,
        "absolute": absolute, "recorded_loss_gates": checks,
        "first_timed_microbatch_loss": "NO VERDICT: native worker did not record this scalar",
    }


class Audit(ProfileAudit):
    def source_controls(self) -> None:
        actual = subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=self.source, text=True).strip()
        self.check(actual == self.expected_source, "local source HEAD is exact expected commit")
        self.check(not subprocess.check_output(
            ["git", "status", "--porcelain", "--untracked-files=no"], cwd=self.source).strip(),
            "local tracked source clean before numerical comparator import")
        source = self.read("source-manifest.json")
        for name, row in source["files"].items():
            path = contained(self.source, name)
            self.check(digest(path) == row["sha256"], "local frozen source bytes: " + name)
        proof = constructor_source(self.source / IDENTITY_PATHS["runtime_module_sha256"])
        self.identity = {"source_commit": self.expected_source, **{
            name: source["files"][path]["sha256"] for name, path in IDENTITY_PATHS.items()},
            "constructor_source_sha256": proof["constructor_source_sha256"]}
        self.report["constructor_default_control"] = proof

    def retention(self) -> None:
        super().retention()
        self.source_controls()

    def runtime_routes(self, raw: dict, enabled: bool, label: str) -> None:
        snapshots = 0
        for phase in ("setup", "accuracy", "warmup", "timing",
                      "unprofiled_context", "profile_update"):
            if phase not in raw:
                continue
            points = ("runtime_after",) if phase == "setup" else ("runtime_before", "runtime_after")
            for name in points:
                validate_routes(raw[phase].get(name, {}).get("expert_grouped_routes"), enabled)
                snapshots += 1
        self.check(snapshots >= 3, label + ": actual expert flags in every native runtime stage")

    def environment(self, row: dict, label: str, spec: dict) -> None:
        super().environment(row, label, spec)
        # Qualification handles flags independently; native accuracy/profiles stay legacy.
        if not label.startswith(QUALIFICATION):
            self.runtime_routes(row, False, label)

    def phase_order(self) -> None:
        value = self.read("results/phase-order.json")
        self.check(value["source_commit"] == self.expected_source
                   and value["spec_sha256"] == self.spec_identity, "phase-order source/spec")
        records = value["records"]
        expected = [(phase, status) for phase in PHASES for status in ("started", "completed")]
        self.check([(row["phase"], row["status"]) for row in records] == expected,
                   "accuracy -> baseline profiles -> comparison -> qualification order")
        for key in ("monotonic", "unix"):
            times = [row[key] for row in records]
            self.check(all(finite(item) and item > 0 for item in times)
                       and times == sorted(times), "phase-order finite monotone " + key)
        for row in records:
            self.check(row.get("source_commit", self.expected_source) == self.expected_source
                       and row.get("spec_sha256", self.spec_identity) == self.spec_identity,
                       "phase receipt frozen identity")
            if "command" in row:
                self.check(isinstance(row["command"], list) and row["command"]
                           and all(isinstance(part, str) for part in row["command"]),
                           "phase command is an explicit argument array")
        self.report["phase_order"] = value

    def qualification_worker(self, directory: str, variant: str, phase: str) -> dict:
        raw = self.read(directory + "/result.json")
        envelope = self.read(directory + "/dispatch-envelope.json")
        control = self.read(directory + "/controller-result.json")
        self.check(raw["status"] == envelope["status"] == "passed"
                   and raw["phase"] == envelope["phase"] == phase
                   and raw["arm"] == envelope["native_arm"] == NATIVE_ARMS[variant]
                   and envelope["variant"] == variant
                   and raw["pid"] == envelope["pid"]
                   and raw["spec_sha256"] == envelope["spec_sha256"] == self.spec_identity
                   and envelope["native_result_sha256"] == digest(self.file(
                       directory + "/result.json"))
                   and all(envelope.get(key) == val for key, val in self.identity.items()),
                   directory + ": original raw/envelope source/spec/variant/hash")
        self.check(control["worker"] == raw and control["envelope"] == envelope
                   and control["variant"] == variant and control["native_arm"] == raw["arm"]
                   and control["envelope_sha256"] == digest(self.file(
                       directory + "/dispatch-envelope.json"))
                   and finite(control["fresh_process_wall_seconds"])
                   and control["fresh_process_wall_seconds"] > 0,
                   directory + ": controller exact raw copies")
        validate_dispatch(envelope["dispatch"], variant)
        self.runtime_routes(raw, variant == "grouped", directory)
        self.environment(raw, directory, self.spec)
        self.admission(raw["setup"]["cache_plan"], raw["arm"], self.spec)
        for stage in (("setup", "accuracy") if phase == "accuracy"
                      else ("setup", "warmup", "timing")):
            self.resources(raw[stage], directory + "/" + stage, self.spec)
        self.file(directory + "/worker.log")
        return control

    def qualification(self) -> None:
        import torch

        run = self.read(QUALIFICATION + "/run.json")
        self.check(run["status"] == "completed" and run["accuracy_passed"] is True
                   and run["source_commit"] == self.expected_source
                   and run["spec_sha256"] == self.spec_identity
                   and run["identity"] == self.identity
                   and set(run["accuracy"]) == set(ACCURACY_VARIANTS)
                   and run["gpu_rented_by_runner"] is False
                   and run["original_gates"] == {
                       "reference_relative_rtol": 0.01, "atol": 1e-5,
                       "loss_three_decimal": True, "finite": True},
                   "complete frozen dispatch run with original gates")
        protocol = self.protocol["performance"]["dispatch_qualification"]
        self.check(
            protocol["runner"] == IDENTITY_PATHS["wrapper_sha256"]
            and tuple(protocol["accuracy_variants"]) == ACCURACY_VARIANTS
            and tuple(protocol["timing_variants"]) == VARIANTS
            and protocol["rounds"] == 4 and protocol["warmup_updates"] == 2
            and protocol["timed_updates"] == 6 and protocol["accuracy_updates"] == 2
            and protocol["timing_workers"] == 8
            and protocol["grouped_expert_routes_default"] is False
            and protocol["practical_lower_bound_percent"] == 2.0,
            "fixed three-accuracy/eight-worker dispatch protocol",
        )
        inputs = torch.load(self.file("results/prepared/inputs.pt"),
                            map_location="cpu", weights_only=True)
        losses, counters, accuracy_report, gates = {}, {}, {}, {}
        reference = None
        for variant in ACCURACY_VARIANTS:
            directory = QUALIFICATION + "/accuracy/" + variant
            control = self.qualification_worker(directory, variant, "accuracy")
            self.check(run["accuracy"][variant]["result"] == control,
                       variant + ": saved run/raw accuracy cell")
            raw = control["worker"]
            path = self.file(directory + "/capture.pt")
            self.check(digest(path) == raw["accuracy"]["capture_sha256"],
                       variant + ": original complete capture digest")
            capture = torch.load(path, map_location="cpu", weights_only=True)
            proof = full_capture(capture, inputs, self.common)
            self.check(run["accuracy"][variant]["capture_controls"]["full_microbatch_losses"]
                       == proof["losses"],
                       variant + ": recorded accuracy losses match original full capture")
            losses[variant] = proof["losses"]
            counters[variant] = self.cache(
                raw["accuracy"]["runtime_before"]["expert_cache"],
                raw["accuracy"]["runtime_after"]["expert_cache"], raw["arm"])
            accuracy_report[variant] = proof
            if reference is None:
                reference = capture
            else:
                gate = self.common.compare_captures(reference, capture)
                self.check(gate["passed"], "ordinary_legacy -> " + variant
                           + ": independently rerun full original tensor/AdamW comparator")
                gates["ordinary_legacy_vs_" + variant] = gate
                del capture
        native = torch.load(self.file("results/accuracy/ordinary/capture.pt"),
                            map_location="cpu", weights_only=True)
        same_input_gate = self.common.compare_captures(native, reference)
        self.check(same_input_gate["passed"],
                   "native ordinary vs qualification ordinary original full accuracy gate")
        del reference, native
        left = torch.load(self.file(QUALIFICATION + "/accuracy/legacy/capture.pt"),
                          map_location="cpu", weights_only=True)
        right = torch.load(self.file(QUALIFICATION + "/accuracy/grouped/capture.pt"),
                           map_location="cpu", weights_only=True)
        gate = self.common.compare_captures(left, right)
        self.check(gate["passed"], "legacy -> grouped: original full tensor/AdamW comparator")
        gates["legacy_vs_grouped"] = gate
        del left, right
        self.check(counters["legacy"] == counters["grouped"]
                   and counters["ordinary_legacy"]["logical_fetches"] * 2
                   == counters["legacy"]["logical_fetches"] * 3,
                   "qualification three/two-read and identical candidate cache work")
        blocks = run["timing_blocks"]
        self.check(len(blocks) == 8, "all eight timing blocks retained")
        for block in blocks:
            directory = (QUALIFICATION + f"/timing/round-{block['round']:02d}/"
                         + block["variant"])
            control = self.qualification_worker(directory, block["variant"], "timing")
            self.check(block["result"] == control, directory + ": run/raw timing identity")
            raw = control["worker"]
            for phase in ("warmup", "timing"):
                self.cache(raw[phase]["runtime_before"]["expert_cache"],
                           raw[phase]["runtime_after"]["expert_cache"], "two_read_cache")
            gate = loss_gate(losses[block["variant"]][1::2], raw["warmup"]["losses"])
            self.check(gate["passed"], directory + ": recorded warmup vs full accuracy losses")
        result = recompute_timing(blocks)
        cache_checks = []
        for number in range(4):
            pair = {block["variant"]: block["result"]["worker"] for block in blocks
                    if block["round"] == number}
            deltas = {}
            for variant in VARIANTS:
                stage = pair[variant]["timing"]
                deltas[variant] = self.cache(stage["runtime_before"]["expert_cache"],
                                            stage["runtime_after"]["expert_cache"],
                                            "two_read_cache")
            self.check(deltas["legacy"] == deltas["grouped"],
                       f"round {number}: actual timed cache/expert work equal")
            cache_checks.append({"round": number, "reference": deltas["legacy"],
                                 "candidate": deltas["grouped"], "equal": True})
        saved = run["timing_summary"]
        for key in ("step_time_reduction_percent", "paired_bootstrap_95_percent",
                    "passes_practical_2_percent_gate", "bootstrap_samples", "bootstrap_seed",
                    "paired_rounds", "absolute"):
            self.check(saved[key] == result[key], "independently recomputed timing " + key)
        self.check(saved["reference_variant"] == "legacy"
                   and saved["candidate_variant"] == "grouped"
                   and saved["native_arm_for_both"] == "two_read_cache",
                   "saved timing references same raw native arm")
        result["equal_cache_work"] = cache_checks
        self.report["dispatch_qualification"] = {
            "full_accuracy": accuracy_report, "original_comparisons": gates,
            "native_vs_qualification_ordinary": same_input_gate,
            "accuracy_counter_deltas": counters, "timing": result,
            "sequence_evidence": "Outer phase receipts and hash-bound sequential controller; "
            "no independent timestamps exist for qualification's internal accuracy/timing phases.",
        }
        self.report["unprofiled_speed_verdict"] = (
            "passes >=2% lower-confidence-bound gate" if result["passes_practical_2_percent_gate"]
            else "NO PRACTICAL WIN: lower confidence bound is below 2%")
        self.check(len(self.pids) == 16, "sixteen distinct native/profile/qualification workers")

    def execute(self) -> dict:
        super().execute()
        self.phase_order()
        self.qualification()
        self.report["status"] = "passed_combined_audit"
        return self.report


def main() -> int:
    from rich.console import Console

    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    parser.add_argument("--stage-dir", required=True, type=Path)
    parser.add_argument("--source-root", type=Path, default=Path.cwd())
    parser.add_argument("--expected-source", required=True)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--no-timeline", action="store_true")
    args = parser.parse_args()
    audit = Audit(
        args.stage_dir, args.source_root, args.expected_source, timeline=not args.no_timeline
    )
    audit.report["audit_script_sha256"] = digest(Path(__file__))
    code = 0
    try:
        audit.execute()
    except BaseException as exc:  # noqa: BLE001 - preserve any interrupted audit evidence
        audit.report.update(status="failed", error=repr(exc), traceback=traceback.format_exc())
        code = 1
    args.out.parent.mkdir(parents=True, exist_ok=True)
    temporary = args.out.with_suffix(".incoming")
    temporary.write_text(
        json.dumps(audit.report, indent=2, allow_nan=False) + "\n", encoding="utf-8"
    )
    os.replace(temporary, args.out)
    Console().print(
        {
            "status": audit.report["status"],
            "checks": len(audit.report["checks"]),
            "out": str(args.out),
        }
    )
    return code


if __name__ == "__main__":
    raise SystemExit(main())
