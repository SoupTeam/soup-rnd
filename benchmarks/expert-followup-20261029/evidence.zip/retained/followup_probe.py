"""Accuracy-first host packing, late lookahead and expert placement qualification.

No provider API lives here. Source binding and CUDA selectors must be finalized
by the root before the unpaid operator can be sealed or rented.
"""

from __future__ import annotations

import argparse
import contextlib
import functools
import hashlib
import importlib.util
import json
import math
import os
import random
import statistics
import subprocess
import sys
import time
import traceback
from pathlib import Path
from unittest.mock import patch

COMMIT = "9873f3239db47ee6c5539cea8b125261cdba82c1"
GIB = 2**30
BIG_GPU_BYTES = 17 * GIB // 8
CAP_USD = 4.39463027092143
BASELINE = "baseline"
POLICIES = {
    "baseline": {"mode": "packed", "host_packing": False, "placement": False, "gpu": 2 * GIB},
    "hostpacked": {"mode": "packed", "host_packing": True, "placement": False, "gpu": 2 * GIB},
    "prefetch_after": {"mode": "prefetch_after", "host_packing": False,
                       "placement": False, "gpu": 2 * GIB},
    "usage2": {"mode": "packed", "host_packing": False, "placement": True, "gpu": 2 * GIB},
    "larger": {"mode": "packed", "host_packing": False, "placement": False, "gpu": BIG_GPU_BYTES},
    "all": {"mode": "prefetch_after", "host_packing": True, "placement": True,
            "gpu": BIG_GPU_BYTES},
}
CONTRACT = {
    "purpose": "packed_hostcache_usage_placement_late_prefetch_followup",
    "policies": POLICIES, "accuracy_order": list(POLICIES),
    "accuracy_updates": 2, "accumulation": 2, "warmup_updates": 2, "timed_updates": 6,
    "exploration_order": ["hostpacked", "baseline", "usage2", "prefetch_after", "larger", "all"],
    "selection": "fastest_distinct_mode_strictly_faster_than_fresh_packed_baseline_median",
    "confirmation_pairs": 4, "confirmation_order": "AB_BA_AB_BA",
    "bootstrap_samples": 5000, "bootstrap_seed": 29, "practical_lower_bound_percent": 2.,
    "rtol": .01, "atol": 1e-5, "finite": True, "three_decimal_losses": True,
    "all_features": {"two_read": True, "grouped_expert_routes": True,
                     "host_cache_bytes": 8 * GIB, "host_cache_policy": "static"},
    "diagnostic": {"baseline_mode": "packed", "usage_observed_warmup_updates": 2,
                   "context_updates": 1, "profile_updates": 1,
                   "cuda_window": {"phase": "forward", "microbatch": 0,
                                   "skip_fetches": 1024, "fetches": 16},
                   "cpu_host_spans": ["fetch", "storage_read", "packing_layout",
                                      "transfer_stage", "nf4_dequant"],
                   "plans_gpu_bytes": [2 * GIB, BIG_GPU_BYTES],
                   "placement_proxy": "frequency_transfer_bytes_per_dense_byte",
                   "maximum_profile_entries": 65536,
                   "profile_is_timing_denominator": False},
    "maximum_slot_bytes": 16 * 2**20, "slots": 2,
    "cuda_allocator_backend": "native", "cuda_launch_blocking": "0",
    "old_timing_denominator_allowed": False,
}


def require(value, message):
    if not value:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def digest(path):
    hashed = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 2**20), b""):
            hashed.update(block)
    return hashed.hexdigest()


def save(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + f".{os.getpid()}.tmp")
    with temporary.open("w", encoding="utf-8", newline="\n") as sink:
        json.dump(value, sink, indent=2, allow_nan=False)
        sink.write("\n")
        sink.flush()
        os.fsync(sink.fileno())
    os.replace(temporary, path)


def load_private(name):
    expected = Path(__file__).with_name(name)
    launch = read(expected.with_name("launch-manifest.json"))
    require(digest(expected) == launch["files"][name]["sha256"], "Frozen helper changed")
    spec = importlib.util.spec_from_file_location("followup_" + expected.stem, expected)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    require(os.path.realpath(module.__file__) == os.path.realpath(expected),
            "Imported a foreign private helper")
    return module


def project(root):
    sys.path[:0] = [str(root / "src"), str(root)]
    from benchmarks.harness import expert_cache_dispatch_qualification as qualified

    return qualified, qualified.project(root, COMMIT)


def validate_contract(spec, protocol, policy=BASELINE):
    require(policy in POLICIES and protocol["source_commit"] == spec["git_head"] == COMMIT
            and len(COMMIT) == 40 and protocol["execution_plan"] == CONTRACT
            and protocol["preparation_status"] == "READY_ROOT_APPROVED"
            and protocol["financial"]["maximum_stage_usd"] == CAP_USD
            and protocol["financial"]["maximum_seconds"] == 9000,
            "Source, science, remaining authorization or deadline changed")
    from benchmarks.harness import expert_cache_dispatch_qualification as qualified

    normalized = dict(spec, device_cache_bytes=2 * GIB)
    qualified.validate_protocol(normalized)
    require(spec["device_cache_bytes"] == POLICIES[policy]["gpu"],
            "Actual arm budget differs from its declared experimental variable")


def arm_spec(base, policy):
    return dict(base, device_cache_bytes=POLICIES[policy]["gpu"])


def plan_keys(path, policy, base_spec_path):
    from soup_cli.utils.expert_placement import ExpertUsageProfile

    data = read(path)
    require(data["status"] == "passed_usage_profile_and_frozen_plans"
            and data["source_commit"] == COMMIT
            and data["base_spec_sha256"] == digest(base_spec_path)
            and data["probe_sha256"] == digest(__file__)
            and data["observed_updates"] == 2
            and data["observed_requests"] == sum(row["requests"] for row in data["records"]),
            "Usage profile identity/count binding changed")
    require(0 < len(data["records"]) <= 65536
            and set(data["plans"]) == {str(2 * GIB), str(BIG_GPU_BYTES)}, "Invalid profile extent")
    restored = ExpertUsageProfile(max_entries=65536)
    seen = set()
    for row in data["records"]:
        key = tuple(row["key"])
        require(len(key) == 2 and isinstance(key[0], str) and key[0]
                and type(key[1]) is int and key[1] >= 0 and key not in seen,
                "Invalid or repeated portable expert key")
        seen.add(key)
        restored.record_request(key, count=row["requests"], transfer_bytes=row["transfer_bytes"],
                                dense_bytes=row["dense_bytes"])
    budget = POLICIES[policy]["gpu"]
    actual = restored.plan(budget)
    expected = {name: getattr(actual, name) for name in (
        "keys", "payload_bytes", "budget_bytes", "candidate_count", "total_requests",
        "selected_requests", "saved_transfer_bytes_proxy", "policy")}
    require(json.loads(json.dumps(expected)) == data["plans"][str(budget)]
            and len(actual.keys) > 0 and 0 < actual.payload_bytes <= budget,
            "Frozen plan does not reproduce from actual portable usage records")
    return actual.keys


def configure(fetcher, policy, keys):
    value = POLICIES[policy]
    fetcher.configure_transfer(value["mode"])
    fetcher.configure_host_packing(value["host_packing"])
    fetcher.configure_placement(keys if value["placement"] else None)
    fetcher.configure_usage_profile(None)
    require(fetcher.transfer_mode == value["mode"], "Actual transfer mode differs")
    actual = {"mode": fetcher.transfer_mode, "host_packing": fetcher._host_prepacked,
              "placement": fetcher._device_allowlist is not None,
              "gpu": fetcher._device_cache.stats()["budget_bytes"]}
    require(actual == value and fetcher._usage_profile is None,
            "Actual host-cache/placement/observer configuration differs")
    if value["placement"]:
        require(len(fetcher._device_allowlist) == len(keys) > 0,
                "Actual allowlist differs from the nonempty frozen plan")
    return actual


def cache_delta(raw, phase, policy):
    before, after = (raw[phase][key]["expert_cache"]
                     for key in ("runtime_before", "runtime_after"))
    delta = {key: after[key] - before[key] for key in
             ("logical_fetches", "storage_reads", "storage_bytes_read", "materializations")}
    for tier, ceiling in (("host", 8 * GIB), ("device", POLICIES[policy]["gpu"])):
        for point in (before, after):
            require(point[tier]["budget_bytes"] == ceiling
                    and 0 <= point[tier]["payload_bytes"] <= ceiling,
                    "Actual per-arm payload ceiling changed")
        delta[tier + "_hits"] = after[tier]["hits"] - before[tier]["hits"]
    require(all(type(value) is int and value >= 0 for value in delta.values())
            and delta["logical_fetches"] > 0
            and delta["storage_reads"] + delta["host_hits"] + delta["device_hits"]
            == delta["logical_fetches"]
            and delta["materializations"] == delta["logical_fetches"] - delta["device_hits"]
            and min(delta["host_hits"], delta["device_hits"]) > 0,
            "Expert accounting or actual use of both cache tiers failed")
    plan = raw["setup"]["cache_plan"]
    require(plan["host_cache_bytes"] == 8 * GIB
            and plan["device_cache_bytes"] == POLICIES[policy]["gpu"]
            and plan["host_cache_policy"] == before["host_cache_policy"]
            == after["host_cache_policy"] == "static", "Cache admission differs")
    require(before["transfer"]["mode"] == after["transfer"]["mode"] == POLICIES[policy]["mode"]
            and after["transfer"]["h2d_copies"] - before["transfer"]["h2d_copies"]
            == delta["materializations"]
            and all(0 <= after["transfer"][key] <= 32 * 2**20 for key in
                    ("pinned_host_bytes", "device_staging_bytes")),
            "Coalesced H2D count or bounded staging differs")
    requested = POLICIES[policy]
    for point in (before, after):
        require(type(point.get("host_prepacked", False)) is bool
                and point.get("host_prepacked", False) is requested["host_packing"]
                and ("device_placement" in point) is requested["placement"]
                and "usage_profile" not in point, "Actual role/observer cache flags differ")
        if requested["placement"]:
            require(point["device_placement"]["policy"] == "profile_allowlist"
                    and type(point["device_placement"]["keys"]) is int
                    and point["device_placement"]["keys"] > 0,
                    "Usage placement did not install an actual nonempty allowlist")
    layouts = after["transfer"]["layout_builds"] - before["transfer"]["layout_builds"]
    copies = after["transfer"]["host_copy_calls"] - before["transfer"]["host_copy_calls"]
    require(type(layouts) is int and type(copies) is int
            and 0 <= layouts <= delta["materializations"] <= copies,
            "Invalid actual CPU packing-work counters")
    if requested["host_packing"]:
        require(layouts < delta["materializations"],
                "Prepacked host-cache path did not avoid any repeated layout construction")
    else:
        require(layouts == delta["materializations"], "Baseline packing work was altered")
    return delta


def validate_worker(raw, policy, spec, qualified, placement_key_count=None):
    require(raw["status"] == "passed" and raw["arm"] == "two_read_cache",
            "Actual native worker failed")
    qualified.validate_native_routes(raw, "grouped")
    from benchmarks.harness import two_read_cache_worker as native_worker

    for phase in ("setup", "accuracy", "warmup", "timing", "lifecycle"):
        if phase in raw:
            native_worker._enforce_stage_limits(spec, raw[phase])
    for phase in ("accuracy", "warmup", "timing"):
        if phase in raw:
            cache_delta(raw, phase, policy)
            if POLICIES[policy]["placement"]:
                points = (raw[phase][key]["expert_cache"]
                          for key in ("runtime_before", "runtime_after"))
                require(type(placement_key_count) is int and placement_key_count > 0
                        and all(point["device_placement"]["keys"] == placement_key_count
                                for point in points),
                        "Actual allowlist length differs from frozen selected keys")
    load_private("cpu_overlap_probe.py").validate_resource_boundary(raw, spec)


def worker_main(args):
    import torch

    qualified, (_native, worker, _common, module, identity) = project(args.source_root)
    spec, protocol = read(args.spec), read(args.protocol)
    validate_contract(spec, protocol, args.policy)
    require(os.environ.get("CUDA_LAUNCH_BLOCKING") == "0"
            and torch.cuda.memory.get_allocator_backend() == "native",
            "Native allocator and asynchronous launches required")
    require(spec == arm_spec(read(args.base_spec), args.policy),
            "Derived spec changed fields beyond declared GPU budget")
    keys = plan_keys(args.usage_plan, args.policy, args.base_spec)
    args.out.mkdir(parents=True, exist_ok=True)
    envelope = {"status": "running", "policy": args.policy, "phase": args.phase,
                "pid": os.getpid(), "source": identity, "probe_sha256": digest(__file__),
                "spec_sha256": digest(args.spec), "base_spec_sha256": digest(args.base_spec),
                "protocol_sha256": digest(args.protocol),
                "usage_plan_sha256": digest(args.usage_plan), "settings": POLICIES[args.policy],
                "selected_keys": keys if POLICIES[args.policy]["placement"] else [],
                "configure_calls": 0, "cuda_allocator_backend": "native",
                "cuda_launch_blocking": "0"}
    original = worker._build

    @functools.wraps(original)
    def build(*parts, **kwargs):
        model, runtime, admitted = original(*parts, **kwargs)
        try:
            envelope["actual_settings"] = configure(runtime.expert_fetcher, args.policy, keys)
            envelope["usage_observer_enabled"] = runtime.expert_fetcher._usage_profile is not None
            envelope["configure_calls"] += 1
            return model, runtime, admitted
        except BaseException:
            runtime.close()
            raise

    try:
        with (qualified.dispatch(module, "grouped") as dispatch,
              patch.object(worker, "_build", build)):
            status = worker.run_worker(args.spec, "two_read_cache", args.phase, args.out)
        require(status == 0, "Native worker failed")
        qualified.validate_dispatch_evidence(dispatch, "grouped")
        raw = read(args.out / "result.json")
        validate_worker(raw, args.policy, spec, qualified,
                        len(keys) if POLICIES[args.policy]["placement"] else None)
        require(envelope["configure_calls"] == 1, "Wrong actual constructor count")
        envelope.update(status="passed", raw_sha256=digest(args.out / "result.json"),
                        dispatch=dispatch)
    except BaseException as error:
        envelope.update(status="failed", error=f"{type(error).__name__}: {error}",
                        traceback=traceback.format_exc())
    save(args.out / "followup-envelope.json", envelope)
    return 0 if envelope["status"] == "passed" else 1


def select_candidate(rows):
    require([row["policy"] for row in rows] == CONTRACT["exploration_order"],
            "Exploration schedule changed")
    medians = {row["policy"]: statistics.median(row["worker"]["result"]["timing"][
        "update_seconds"]) for row in rows}
    require(all(math.isfinite(value) and value > 0 for value in medians.values()),
            "Nonfinite or nonpositive timing")
    candidates = [name for name in POLICIES if name != BASELINE
                  and medians[name] < medians[BASELINE]]
    return {"candidate": min(candidates, key=medians.get) if candidates else None,
            "medians_seconds": medians, "exploratory_only": True}


def exploration_losses(rows, qualified, common):
    require(len(rows) == len(POLICIES)
            and {row["policy"] for row in rows} == set(POLICIES),
            "All six actual exploratory workers required for loss replay")
    reference = next(row["worker"]["result"] for row in rows if row["policy"] == BASELINE)
    checks = {}
    for row in rows:
        actual = row["worker"]["result"]
        phases = {}
        for phase, count in (("warmup", 2), ("timing", 6)):
            require(len(reference[phase]["losses"]) == len(actual[phase]["losses"]) == count,
                    "Exploratory recorded losses are incomplete")
            phases[phase] = qualified.loss_gate(reference[phase]["losses"],
                                                  actual[phase]["losses"], common)
            require(phases[phase]["passed"],
                    "Original recorded exploratory loss gate failed: " + row["policy"])
        checks[row["policy"]] = phases
    return checks


def confirm(rows, candidate, qualified, common):
    pair = (BASELINE, candidate)
    orders = (pair, pair[::-1]) * 2
    require(len(rows) == 8, "Four fresh confirmation pairs required")
    grouped, pids = {}, set()
    for index, row in enumerate(rows):
        number, position = divmod(index, 2)
        require(row["round"] == number and row["position"] == position
                and row["policy"] == orders[number][position], "Confirmation schedule changed")
        raw = row["worker"]["result"]
        require(raw["pid"] not in pids, "Fresh process reused")
        pids.add(raw["pid"])
        grouped.setdefault(number, {})[row["policy"]] = raw
    logs = []
    for cells in grouped.values():
        reference, actual = cells[BASELINE], cells[candidate]
        for phase in ("warmup", "timing"):
            require(qualified.loss_gate(reference[phase]["losses"], actual[phase]["losses"],
                                        common)["passed"], "Original recorded loss gate failed")
        logs.append(math.log(statistics.median(actual["timing"]["update_seconds"]) /
                             statistics.median(reference["timing"]["update_seconds"])))
    rng = random.Random(29)
    draws = sorted(100 * (1 - math.exp(statistics.mean(rng.choices(logs, k=4))))
                   for _ in range(5000))
    return {"candidate": candidate, "paired_rounds": 4,
            "step_time_reduction_percent": 100 * (1 - math.exp(statistics.mean(logs))),
            "throughput_increase_percent": 100 * (math.exp(-statistics.mean(logs)) - 1),
            "paired_bootstrap_95_percent": [draws[124], draws[4874]],
            "passes_practical_2_percent_gate": draws[124] >= 2.,
            "selection_samples_excluded": True}


def launch(args, policy, phase, out):
    out.mkdir(parents=True, exist_ok=False)
    spec_path = args.out / "specs" / (policy + ".json")
    command = [sys.executable, str(Path(__file__).absolute()), "worker", "--policy", policy,
               "--phase", phase, "--spec", str(spec_path), "--base-spec", str(args.spec),
               "--usage-plan", str(args.out / "diagnostic/usage-profile.json"),
               "--out", str(out), "--source-root", str(args.source_root),
               "--source-commit", COMMIT, "--protocol", str(args.protocol)]
    started = time.perf_counter()
    with (out / "worker.log").open("wb") as log:
        process = subprocess.run(command, cwd=args.source_root, stdout=log,
                                 stderr=subprocess.STDOUT,
                                 timeout=read(args.spec)["timeout_seconds"], check=False)
    require(process.returncode == 0, f"{policy}/{phase} failed; raw evidence retained")
    envelope, raw = read(out / "followup-envelope.json"), read(out / "result.json")
    require(envelope["status"] == raw["status"] == "passed"
            and envelope["policy"] == policy and envelope["phase"] == phase
            and envelope["spec_sha256"] == raw["spec_sha256"] == digest(spec_path)
            and envelope["base_spec_sha256"] == digest(args.spec)
            and envelope["raw_sha256"] == digest(out / "result.json")
            and envelope["probe_sha256"] == digest(__file__), "Worker bindings differ")
    row = {"policy": policy, "phase": phase, "result": raw, "envelope": envelope,
           "directory": out.relative_to(args.out).as_posix(),
           "fresh_process_wall_seconds": time.perf_counter() - started}
    save(out / "controller-result.json", row)
    return row


def run(args):
    import torch

    qualified, (native, _worker, common, _module, identity) = project(args.source_root)
    spec, protocol = read(args.spec), read(args.protocol)
    validate_contract(spec, protocol)
    args.out.mkdir(parents=True, exist_ok=False)
    (args.out / "specs").mkdir()
    path = args.out / "run.json"
    result = {"status": "running", "identity": identity, "probe_sha256": digest(__file__),
              "base_spec_sha256": digest(args.spec), "protocol_sha256": digest(args.protocol),
              "execution_plan": CONTRACT, "accuracy_passed": False,
              "accuracy": {}, "exploration": [], "confirmation": []}
    save(path, result)
    try:
        native.verify_spec(spec, content=True)
        for policy in POLICIES:
            save(args.out / "specs" / (policy + ".json"), arm_spec(spec, policy))
        diagnostic = args.out / "diagnostic"
        diagnostic.mkdir()
        command = [sys.executable, str(Path(__file__).absolute()), "diagnostic", "--spec",
                   str(args.spec), "--base-spec", str(args.spec), "--out", str(diagnostic),
                   "--source-root", str(args.source_root), "--source-commit", COMMIT,
                   "--protocol", str(args.protocol)]
        with (diagnostic / "worker.log").open("wb") as log:
            subprocess.run(command, cwd=args.source_root, stdout=log, stderr=subprocess.STDOUT,
                           timeout=spec["timeout_seconds"], check=True)
        result["diagnostic"] = read(diagnostic / "diagnostic-envelope.json")
        require(result["diagnostic"]["status"] == "passed", "Current packed profile failed")
        result["usage_plan_sha256"] = digest(diagnostic / "usage-profile.json")
        save(path, result)
        inputs = torch.load(spec["training_data_path"], map_location="cpu", weights_only=True)
        reference = None
        for policy in POLICIES:
            row = launch(args, policy, "accuracy", args.out / "accuracy" / policy)
            capture_path = args.out / row["directory"] / "capture.pt"
            capture = torch.load(capture_path, map_location="cpu", weights_only=True)
            controls = qualified.full_capture_controls(capture, inputs, common)
            if reference is None:
                reference = capture
            comparison = common.compare_captures(reference, capture)
            require(comparison["passed"], f"Original full capture gate failed: {policy}")
            require(digest(capture_path) == row["result"]["accuracy"]["capture_sha256"],
                    "Full capture bytes changed")
            result["accuracy"][policy] = {"worker": row, "controls": controls,
                                           "versus_baseline": comparison}
            del capture
            save(path, result)
        del reference
        result["accuracy_passed"] = True
        save(path, result)
        for policy in CONTRACT["exploration_order"]:
            row = launch(args, policy, "timing", args.out / "exploration" / policy)
            result["exploration"].append({"policy": policy, "worker": row})
            save(path, result)
        result["exploration_loss_checks"] = exploration_losses(
            result["exploration"], qualified, common)
        result["selection"] = select_candidate(result["exploration"])
        candidate = result["selection"]["candidate"]
        save(path, result)
        if candidate is not None:
            pair = (BASELINE, candidate)
            for number, order in enumerate((pair, pair[::-1]) * 2):
                for position, policy in enumerate(order):
                    row = launch(args, policy, "timing", args.out / "confirmation" /
                                 f"round-{number:02d}" / policy)
                    result["confirmation"].append({"round": number, "position": position,
                                                    "policy": policy, "worker": row})
                    save(path, result)
            result["confirmation_summary"] = confirm(
                result["confirmation"], candidate, qualified, common)
        native.verify_spec(spec, content=True)
        result["status"] = "completed"
        save(path, result)
        validate_result(args.out, spec, protocol)
    except BaseException as error:
        result.update(status="failed", error=f"{type(error).__name__}: {error}",
                      traceback=traceback.format_exc())
        save(path, result)
        return 1
    return 0


def validate_result(directory, spec, protocol):
    validate_contract(spec, protocol)
    directory = Path(directory)
    result = read(directory / "run.json")
    require(result["status"] == "completed" and result["accuracy_passed"] is True
            and result["probe_sha256"] == digest(__file__)
            and result["execution_plan"] == CONTRACT
            and set(result["accuracy"]) == set(POLICIES), "Incomplete six-arm study")
    from benchmarks.harness import expert_cache_dispatch_qualification as qualified
    from benchmarks.harness import two_read_cache_common as common

    rows = [cell["worker"] for cell in result["accuracy"].values()]
    rows += [cell["worker"] for cell in result["exploration"] + result["confirmation"]]
    pids, environments, logical = set(), [], {}
    for row in rows:
        policy, raw, envelope = row["policy"], row["result"], row["envelope"]
        require(raw["pid"] not in pids, "Fresh worker PID reused")
        pids.add(raw["pid"])
        qualified.validate_dispatch_evidence(envelope["dispatch"], "grouped")
        derived = read(directory / "specs" / (policy + ".json"))
        require(derived == arm_spec(spec, policy), "Derived recipe changed")
        validate_worker(raw, policy, derived, qualified,
                        len(envelope["selected_keys"]) if POLICIES[policy]["placement"] else None)
        environments.append(raw["environment"])
        original = directory / row["directory"] / "result.json"
        require(digest(original) == envelope["raw_sha256"] and read(original) == raw,
                "Actual retained worker bytes changed")
        require(envelope["usage_plan_sha256"] == result["usage_plan_sha256"]
                and envelope["settings"] == POLICIES[policy]
                and envelope["actual_settings"] == POLICIES[policy]
                and envelope["configure_calls"] == 1
                and envelope["usage_observer_enabled"] is False,
                "Actual arm settings/profile binding differ")
        for phase in ("accuracy", "warmup", "timing"):
            if phase in raw:
                count = cache_delta(raw, phase, policy)["logical_fetches"]
                require(phase not in logical or logical[phase] == count,
                        "Modes changed logical expert work")
                logical[phase] = count
    require(all(value == environments[0] for value in environments), "Runtime changed")
    require(result["exploration_loss_checks"] == exploration_losses(
        result["exploration"], qualified, common), "Recorded exploration loss replay changed")
    require(result["selection"] == select_candidate(result["exploration"]), "Selection changed")
    candidate = result["selection"]["candidate"]
    if candidate is None:
        require(not result["confirmation"] and "confirmation_summary" not in result,
                "Unselected candidate was confirmed")
    else:
        require(result["confirmation_summary"] == confirm(
            result["confirmation"], candidate, qualified, common), "Confirmation changed")
    return {"status": "passed_structural_probe_validation", "workers": len(rows),
            "source_commit": COMMIT, "accuracy_policies": list(POLICIES)}


def diagnostic_main(args):
    import torch
    from torch.profiler import record_function

    qualified, (_native, worker, _common, module, identity) = project(args.source_root)
    spec, protocol = read(args.spec), read(args.protocol)
    validate_contract(spec, protocol)
    require(os.environ.get("CUDA_LAUNCH_BLOCKING") == "0"
            and torch.cuda.memory.get_allocator_backend() == "native",
            "Diagnostic requires the same admitted native/async cohort")
    from bitsandbytes import functional as bnb_functional
    from soup_cli.utils import expert_stream, expert_transfer
    from soup_cli.utils.expert_placement import ExpertUsageProfile

    helper = load_private("cpu_overlap_probe.py")
    profile = ExpertUsageProfile(max_entries=65536)
    state = {"phase": "setup", "timed_calls": 0, "configure_calls": 0}
    host_spans = {}
    runtime_holder = {}
    original_build, original_updates = worker._build, worker._timed_updates
    envelope = {"status": "running", "pid": os.getpid(), "source": identity,
                "probe_sha256": digest(__file__), "base_spec_sha256": digest(args.spec),
                "protocol_sha256": digest(args.protocol), "actual_mode": "packed",
                "policy": "baseline_diagnostic", "legacy_helper_policy_label": "native",
                "unprofiled_speed_verdict": "NO VERDICT"}
    save(args.out / "diagnostic-envelope.json", envelope)

    def span_wrapper(name, original):
        @functools.wraps(original)
        def wrapped(*parts, **kwargs):
            started = time.perf_counter()
            try:
                with record_function("soup.followup." + name):
                    return original(*parts, **kwargs)
            finally:
                key = state["phase"] + "/" + name
                entry = host_spans.setdefault(key, {"calls": 0, "seconds": 0.})
                entry["calls"] += 1
                entry["seconds"] += time.perf_counter() - started

        return wrapped

    @functools.wraps(original_build)
    def build(*parts, **kwargs):
        model, runtime, admitted = original_build(*parts, **kwargs)
        try:
            configure(runtime.expert_fetcher, BASELINE, ())
            runtime.expert_fetcher.configure_usage_profile(profile)
            runtime_holder["runtime"] = runtime
            state["configure_calls"] += 1
            return model, runtime, admitted
        except BaseException:
            runtime.close()
            raise

    @functools.wraps(original_updates)
    def timed_updates(model, runtime, optimizer, batches, recipe, updates, **kwargs):
        state["timed_calls"] += 1
        number = state["timed_calls"]
        require(number in (1, 2) and updates == (2 if number == 1 else 1),
                "Legacy diagnostic changed its declared warmup/context calls")
        state["phase"] = "warmup" if number == 1 else "context"
        before = runtime.expert_fetcher.cache_stats()["logical_fetches"]
        try:
            result = original_updates(model, runtime, optimizer, batches, recipe, updates, **kwargs)
            if number == 1:
                runtime.expert_fetcher.configure_usage_profile(None)
                count = runtime.expert_fetcher.cache_stats()["logical_fetches"] - before
                records = [{"key": row.key, "requests": row.requests,
                            "transfer_bytes": row.transfer_bytes, "dense_bytes": row.dense_bytes}
                           for row in profile.snapshot()]
                require(sum(row["requests"] for row in records) == count > 0,
                        "Observer did not record exactly the actual two-warmup fetches")
                lookup = {tuple(row["key"]): row for row in records}
                plans = {}
                for budget in (2 * GIB, BIG_GPU_BYTES):
                    plan = profile.plan(budget)
                    value = {name: getattr(plan, name) for name in (
                        "keys", "payload_bytes", "budget_bytes", "candidate_count",
                        "total_requests",
                        "selected_requests", "saved_transfer_bytes_proxy", "policy")}
                    require(plan.payload_bytes == sum(lookup[key]["dense_bytes"]
                                                      for key in plan.keys)
                            and plan.selected_requests == sum(lookup[key]["requests"]
                                                              for key in plan.keys)
                            and plan.saved_transfer_bytes_proxy == sum(
                                lookup[key]["requests"] * lookup[key]["transfer_bytes"]
                                for key in plan.keys)
                            and 0 < plan.payload_bytes <= budget,
                            "Frozen plan differs from actual recorded requests/cost proxy")
                    plans[str(budget)] = value
                save(args.out / "usage-profile.json", {
                    "status": "passed_usage_profile_and_frozen_plans", "source_commit": COMMIT,
                    "base_spec_sha256": digest(args.spec), "probe_sha256": digest(__file__),
                    "observed_updates": 2, "observed_requests": count,
                    "records": records, "plans": plans,
                    "profiled_training_inputs_sha256": digest(Path(spec["training_data_path"])),
                    "planner_source_sha256": digest(args.source_root /
                        "src/soup_cli/utils/expert_placement.py"),
                    "policy_limit": "Frequency/transfer-bytes proxy; no latency-optimality claim"})
            return result
        finally:
            state["phase"] = "profile_update"

    try:
        with contextlib.ExitStack() as stack:
            for owner, name, label in (
                (expert_stream.ExpertFetcher, "fetch", "fetch"),
                (expert_stream.ExpertShardReader, "read_host", "storage_read"),
                (expert_transfer, "packing_layout", "packing_layout"),
                (expert_transfer.PackedExpertTransfer, "stage", "transfer_stage"),
                (bnb_functional, "dequantize_4bit", "nf4_dequant"),
            ):
                stack.enter_context(patch.object(owner, name,
                                                  span_wrapper(label, getattr(owner, name))))
            dispatch = stack.enter_context(qualified.dispatch(module, "grouped"))
            stack.enter_context(patch.object(worker, "_build", build))
            stack.enter_context(patch.object(worker, "_timed_updates", timed_updates))
            helper.run_profile(args, worker)
        raw = read(args.out / "profile-result.json")
        require(raw["status"] == "passed" and state["timed_calls"] == 2
                and state["configure_calls"] == 1, "Actual diagnostic did not complete")
        helper.validate_resource_boundary(raw, spec)
        qualified.validate_dispatch_evidence(dispatch, "grouped")
        require(all(host_spans["profile_update/" + name]["calls"] > 0
                    for name in CONTRACT["diagnostic"]["cpu_host_spans"]),
                "Missing CPU stage spans in the actual full diagnostic update")
        save(args.out / "cpu-host-spans.json", {
            "spans": host_spans, "scope": "CPU wall spans, including enqueue/waits; nested and "
            "overlapping durations are not additive; not GPU service times or speed verdicts",
            "actual_forward_and_backward": True,
            "profiler_cuda_scope": CONTRACT["diagnostic"]["cuda_window"]})
        envelope.update(status="passed", legacy_profile_sha256=digest(
            args.out / "profile-result.json"), usage_plan_sha256=digest(
                args.out / "usage-profile.json"), host_spans_sha256=digest(
                    args.out / "cpu-host-spans.json"), actual_calls=state,
            dispatch=dispatch, trace_sha256=digest(args.out / "trace.json.gz"))
    except BaseException as error:
        envelope.update(status="failed", error=f"{type(error).__name__}: {error}",
                        traceback=traceback.format_exc())
    save(args.out / "diagnostic-envelope.json", envelope)
    return 0 if envelope["status"] == "passed" else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("worker", "run", "diagnostic"))
    parser.add_argument("--policy", choices=tuple(POLICIES), default=BASELINE)
    parser.add_argument("--phase", choices=("accuracy", "timing"), default="accuracy")
    for name in ("spec", "out", "source-root", "protocol"):
        parser.add_argument("--" + name, type=Path, required=True)
    for name in ("base-spec", "usage-plan"):
        parser.add_argument("--" + name, type=Path)
    parser.add_argument("--source-commit", required=True)
    args = parser.parse_args()
    require(args.source_commit == COMMIT and len(COMMIT) == 40,
            "Exact final root source commit required; stage remains unpaid")
    if args.command == "worker":
        return worker_main(args)
    return diagnostic_main(args) if args.command == "diagnostic" else run(args)


if __name__ == "__main__":
    raise SystemExit(main())
