"""CUDA13 software-cohort admission before numerical CUDA tests or checkpoint download."""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata as metadata
import json
import os
import time
from pathlib import Path
from typing import Any


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 2**20), b""):
            value.update(block)
    return value.hexdigest()


def validate_versions(cohort: dict, actual: dict, installed_names: list[str]) -> None:
    require(cohort["torch_version"] == "2.10.0+cu130"
            and cohort["torch_cuda_version"] == "13.0" and cohort["required_cuda_major"] == 13,
            "New CUDA13 cohort identity differs")
    require(cohort["required_versions"]["triton"] == "3.6.0"
            and cohort["required_versions"]["bitsandbytes"] == "0.50.2",
            "Official Torch/Triton or unchanged bitsandbytes pin differs")
    require(actual == cohort["required_versions"], "Installed coupled CUDA13 versions differ")
    legacy = [name for name in installed_names if name.lower().replace("_", "-").startswith(
        "nvidia-") and name.lower().replace("_", "-").endswith("-cu12")]
    require(not legacy, "Legacy CUDA12 Python distributions remain in the new CUDA13 cohort")
    require(os.environ.get("BNB_CUDA_VERSION") in (None, "", "130"),
            "A foreign bitsandbytes CUDA override is present")


def validate_loaded(cohort: dict, torch: Any, bnb: Any, extension: Any) -> dict:
    require(str(torch.__version__) == "2.10.0+cu130" and torch.version.cuda == "13.0",
            "Actual imported Torch is not the official CUDA13 build")
    require(torch.cuda.is_available() and torch.cuda.device_count() == 1,
            "Actual single CUDA device is unavailable")
    require(str(bnb.__version__) == "0.50.2", "Actual bitsandbytes module version differs")
    require(getattr(extension.lib, "compiled_with_cuda", False) is True,
            "bitsandbytes did not load a CUDA native library")
    name = getattr(getattr(extension.lib, "_lib", None), "_name", None)
    require(isinstance(name, str) and bool(name), "Actual bitsandbytes library path is unavailable")
    target = os.path.realpath(name)
    package = os.path.realpath(os.path.dirname(bnb.__file__))
    require(os.path.commonpath((package, target)) == package
            and Path(target).name == cohort["bitsandbytes_required_native_library"]
            == "libbitsandbytes_cuda130.so" and Path(target).is_file(),
            "Actual bitsandbytes CUDA130 backend is missing, foreign or a fallback")
    return {"torch_actual_version": str(torch.__version__),
            "torch_cuda_version": torch.version.cuda,
            "torch_module_path": os.path.realpath(torch.__file__),
            "bitsandbytes_actual_version": str(bnb.__version__),
            "bitsandbytes_module_path": os.path.realpath(bnb.__file__),
            "bitsandbytes_actual_library_path": target,
            "bitsandbytes_actual_library_sha256": digest(Path(target)),
            "bitsandbytes_compiled_with_cuda": True, "cuda_available": True,
            "cuda_visible_device_count": 1}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cohort", type=Path, required=True)
    parser.add_argument("--wheel-lock", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args(argv)
    row = {"schema_version": 1, "status": "running", "unix_started": time.time(),
           "helper_path": os.path.realpath(__file__), "helper_sha256": digest(Path(__file__)),
           "cohort_sha256": digest(args.cohort), "wheel_lock_sha256": digest(args.wheel_lock),
           "scope": ("Actual installed/imported CUDA13 stack admission; "
                     "not numerical or profiler proof")}
    try:
        cohort = json.loads(args.cohort.read_text())
        lock = json.loads(args.wheel_lock.read_text())
        require(row["wheel_lock_sha256"] == cohort["wheel_lock_sha256"],
                "Official wheel lock differs from the registered cohort")
        require({name: item["version"] for name, item in lock["wheels"].items()}
                == cohort["required_versions"], "Official wheel lock versions differ")
        actual = {}
        for name in cohort["required_versions"]:
            try:
                actual[name] = metadata.version(name)
            except metadata.PackageNotFoundError:
                actual[name] = None
        row["actual_versions"] = actual
        installed = [item.metadata.get("Name", "") for item in metadata.distributions()]
        validate_versions(cohort, actual, installed)
        import bitsandbytes as bnb
        import torch
        from bitsandbytes import cextension

        row.update(validate_loaded(cohort, torch, bnb, cextension))
        row["status"] = "passed_runtime_stack_admission"
    except BaseException as error:
        row.update(status="failed", error=f"{type(error).__name__}: {error}")
    finally:
        row["unix_completed"] = time.time()
        args.out.parent.mkdir(parents=True, exist_ok=True)
        temporary = args.out.with_suffix(args.out.suffix + ".incoming")
        temporary.write_text(json.dumps(row, indent=2, allow_nan=False) + "\n")
        os.replace(temporary, args.out)
    return 0 if row["status"] == "passed_runtime_stack_admission" else 1


if __name__ == "__main__":
    raise SystemExit(main())
