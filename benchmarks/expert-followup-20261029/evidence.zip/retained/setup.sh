#!/bin/bash
set -euo pipefail
trap 'echo "$?" > /root/liger/setup.exit' EXIT
cd /root/liger
mkdir -p repo results exports
tar -xzf source.tar.gz -C repo
python3 preflight_remote.py
# Sparse source deployment is byte-checked by remote_run. Fetching only commit/tree
# metadata preserves the real published HEAD for provenance without a full checkout.
cd repo
git init -q
git config --local core.autocrlf true
git config --local gc.auto 0
git config --local maintenance.auto false
git remote add origin https://github.com/SoupTeam/soup-rnd.git
SOURCE_COMMIT=$(python3 -c "import json; print(json.load(open('/root/liger/source-manifest.json'))['source_commit'])")
git fetch --quiet --depth=1 origin "$SOURCE_COMMIT"
git reset --mixed FETCH_HEAD > /root/liger/git-source.log 2>&1
test -z "$(git status --porcelain --untracked-files=no)"
cd /root/liger
export UV_CACHE_DIR=/data/uv-cache TMPDIR=/data
python3 -m pip install uv
uv venv --python 3.12 /root/liger/venv
uv pip install --python /root/liger/venv/bin/python \
  --constraint /root/liger/constraints.txt --index-strategy unsafe-best-match \
  --extra-index-url https://download.pytorch.org/whl/cu130 \
  -r /root/liger/runtime-wheel-requirements.txt \
  'transformers==5.16.1' 'peft==0.20.0' 'trl==0.29.1' 'accelerate==1.14.0' \
  -e '/root/liger/repo[train]' pytest pytest-cov cryptography pip sentencepiece protobuf einops
uv pip check --python /root/liger/venv/bin/python
export PYTHONPATH=/root/liger/repo:/root/liger/repo/src
export CUDA_VISIBLE_DEVICES=0 PYTHONHASHSEED=0 USE_TF=0
export CUDA_LAUNCH_BLOCKING=0
export PYTORCH_ALLOC_CONF=backend:native
export PYTORCH_CUDA_ALLOC_CONF=backend:native
export TOKENIZERS_PARALLELISM=false OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
export CUBLAS_WORKSPACE_CONFIG=:4096:8 WANDB_DISABLED=true
export HF_HUB_DISABLE_XET=1 TMPDIR=/data
cd /root/liger/repo
/root/liger/venv/bin/python /root/liger/remote_run.py
