"""Standard-library resource gates before installing or transferring model weights."""

import importlib.util
import json
import os
import shutil
import subprocess
import time
import urllib.request
from pathlib import Path

ROOT = Path('/root/liger')


def output(command):
    return subprocess.check_output(command, text=True, timeout=20).strip()


def main():
    result = {'passed': False, 'unix': time.time()}
    try:
        module_path = ROOT / 'repo/src/soup_cli/utils/stream_ram_cache.py'
        spec = importlib.util.spec_from_file_location('native_memory', module_path)
        memory_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(memory_module)
        constraints = []
        for version, directory in memory_module._cgroup_paths(
            Path('/proc/self/cgroup'), Path('/proc/self/mountinfo'),
        ):
            if version != 2:
                raise RuntimeError('A real cgroup-v2 RAM/swap scope is required')
            row = {'path': str(directory)}
            for name in ('memory.max', 'memory.swap.max', 'memory.swap.current'):
                value = (directory / name).read_text().strip()
                row[name] = None if value == 'max' else int(value)
            constraints.append(row)
        meminfo = {
            line.partition(':')[0]: int(line.partition(':')[2].split()[0]) * 1024
            for line in Path('/proc/meminfo').read_text().splitlines()
        }
        limits = [meminfo['MemTotal']] + [
            row['memory.max'] for row in constraints if row['memory.max'] is not None
        ]
        # Record observations before refusing a boundary so failed preflights remain auditable.
        result.update(native_ram_limit_bytes=min(limits), memory_constraints=constraints,
                      host_meminfo=meminfo, process_cgroup=Path('/proc/self/cgroup').read_text(),
                      container_id=os.environ.get('CONTAINER_ID'))
        if not 28 * 2**30 <= min(limits) <= 32 * 2**30:
            raise RuntimeError('Require an actual 28..32 GiB physical/cgroup RAM ceiling')
        if meminfo.get('SwapTotal', 0) and not any(row['memory.swap.max'] == 0 for row in constraints):
            raise RuntimeError('Workload swap is not disabled; no global host settings are changed')
        if any(row['memory.swap.current'] != 0 for row in constraints):
            raise RuntimeError('Cgroup swap use is not zero')
        gpu = output(['nvidia-smi', '--query-gpu=uuid,name,memory.total,utilization.gpu,memory.used',
                      '--format=csv,noheader,nounits'])
        if len(gpu.splitlines()) != 1:
            raise RuntimeError('Require exactly one physical visible GPU')
        uuid, name, total, utilization, used = [item.strip() for item in gpu.split(',')]
        result.update(gpu_uuid=uuid, gpu_name=name, gpu_memory_mib=int(total),
                      gpu_utilization_percent=int(utilization), gpu_initial_used_mib=int(used))
        applications = output(['nvidia-smi', '--query-compute-apps=gpu_uuid,pid,used_memory',
                               '--format=csv,noheader,nounits'])
        if not 7900 <= int(total) <= 8300 or int(utilization) > 10 or int(used) > 256:
            raise RuntimeError('Physical 8 GiB GPU is not idle')
        if any(line.startswith(uuid) for line in applications.splitlines()):
            raise RuntimeError('Another GPU process is present; never terminate it')
        result.update(data_free_bytes=shutil.disk_usage('/data').free,
                      root_free_bytes=shutil.disk_usage(ROOT).free)
        if result['data_free_bytes'] < 100 * 2**30:
            raise RuntimeError('Require at least 100 GiB local volume free before downloading weights')
        if result['root_free_bytes'] < 16 * 2**30 or meminfo['MemAvailable'] < 12 * 2**30:
            raise RuntimeError('Insufficient available setup disk/RAM')
        mount = output(['findmnt', '-T', '/data', '-o', 'TARGET,SOURCE,FSTYPE,OPTIONS'])
        started = time.monotonic()
        prefix = ('https://huggingface.co/kakaocorp/kanana-2-30b-a3b-base-2601/resolve/'
                  '0d31365acf656e5f9a593cacc4913e9c0d36cb1c/')
        with urllib.request.urlopen(prefix + 'config.json', timeout=20) as response:
            config = json.loads(response.read(128 * 1024))
        if not isinstance(config.get('architectures'), list):
            raise RuntimeError('Pinned model configuration is not accessible')
        request = urllib.request.Request(prefix + 'model-00001-of-00013.safetensors',
                                         method='HEAD')
        with urllib.request.urlopen(request, timeout=20) as response:
            if response.status != 200:
                raise RuntimeError('Pinned checkpoint storage is not accessible')
        result['checkpoint_network_probe'] = {
            'config_json_accessible': True, 'shard_head_accessible': True,
            'seconds': time.monotonic() - started, 'model_weights_downloaded': False}
        result.update(passed=True, gpu_uuid=uuid, gpu_name=name, gpu_memory_mib=int(total),
                      native_ram_limit_bytes=min(limits), memory_constraints=constraints,
                      host_meminfo=meminfo, process_cgroup=Path('/proc/self/cgroup').read_text(),
                      mount=mount, physical_nvme_verified=False,
                      storage_scope='Container mount retained; physical NVMe backing is unverified',
                      data_free_bytes=shutil.disk_usage('/data').free,
                      root_free_bytes=shutil.disk_usage(ROOT).free,
                      container_id=os.environ.get('CONTAINER_ID'))
    except BaseException as exc:
        result['error'] = f'{type(exc).__name__}: {exc}'
        raise
    finally:
        (ROOT / 'results').mkdir(parents=True, exist_ok=True)
        (ROOT / 'results/capacity-preflight.json').write_text(json.dumps(result, indent=2) + '\n')


if __name__ == '__main__':
    main()
