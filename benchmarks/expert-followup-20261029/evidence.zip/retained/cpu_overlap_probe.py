"""Private, bounded CPU-thread / expert-fetch diagnostic; never rents resources."""

from __future__ import annotations

import argparse
import contextlib
import functools
import hashlib
import importlib.util
import json
import math
import os
import random
import statistics
import subprocess
import sys
import time
import traceback
from pathlib import Path
from typing import Any
from unittest.mock import patch

COMMIT = "43cf0b34afe0d8850d76bf86d60663ab5c85cdb2"
POLICIES = {"native": None, "t1": 1, "t2": 2, "t4": 4, "t8": 8}
EXPLORATION_ORDER = ("t4", "native", "t8", "t2", "t1")
CONTRACT = {
    "schema_version": 1, "purpose": "cpu_thread_scaling_and_bounded_expert_fetch_profile",
    "policies": POLICIES, "accuracy_order": list(POLICIES),
    "thread_override": "after_native_build_and_initialization_before_first_training_microbatch",
    "accuracy_updates": 2, "accumulation": 2,
    "exploration_order": list(EXPLORATION_ORDER), "warmup_updates": 2, "timed_updates": 6,
    "selection": "fastest_distinct_actual_count_strictly_better_than_new_native_median",
    "confirmation_pairs": 4, "confirmation_order": "AB_BA_AB_BA",
    "confirmation_only_after_positive_exploratory_selection": True,
    "practical_lower_bound_percent": 2.0, "bootstrap_samples": 5000, "bootstrap_seed": 29,
    "profile": {"policy": "native", "warmup_updates": 2, "context_updates": 1,
                "microbatch": 0, "phase": "forward", "skip_fetches": 1024, "fetches": 16,
                "maximum_encoded_trace_bytes": 128 * 2**20,
                "scope": "diagnostic_forward_fetch_window_not_backward_or_whole_step"},
    "all_features": {"native_arm": "two_read_cache", "grouped_expert_routes": True,
                     "host_cache_bytes": 8 * 2**30, "device_cache_bytes": 2 * 2**30,
                     "host_cache_policy": "static"},
    "rtol": .01, "atol": 1e-5, "three_decimal_loss_gate": True,
}


def require(condition: Any, message: str) -> None:
    if not condition:
        raise ValueError(message)


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(8 * 2**20), b""):
            value.update(block)
    return value.hexdigest()


def read(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def save(path: Path, value: Any) -> None:
    temporary = path.with_suffix(path.suffix + ".incoming")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def thread_snapshot(torch: Any) -> dict:
    affinity = sorted(os.sched_getaffinity(0)) if hasattr(os, "sched_getaffinity") else None
    return {"intraop": torch.get_num_threads(), "interop": torch.get_num_interop_threads(),
            "cpu_count": os.cpu_count(), "affinity": affinity,
            "env": {key: os.environ.get(key) for key in (
                "OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS",
                "NUMEXPR_NUM_THREADS", "TOKENIZERS_PARALLELISM")}}


def apply_threads(torch: Any, requested: int | None) -> dict:
    require(requested is None or type(requested) is int and requested in (1, 2, 4, 8),
            "Unregistered CPU thread count")
    started = time.perf_counter()
    before = thread_snapshot(torch)
    if requested is not None:
        torch.set_num_threads(requested)
    after = thread_snapshot(torch)
    require(after["intraop"] == (before["intraop"] if requested is None else requested),
            "Requested thread count did not take effect")
    require(all(before[key] == after[key] for key in ("interop", "affinity", "env")),
            "Thread experiment changed interop, affinity or environment")
    return {"before": before, "after": after, "requested": requested,
            "applied_after_build": True,
            "configuration_seconds_included_in_native_setup": time.perf_counter() - started}


def load_timeline_parser(base: Path | None = None) -> tuple[Any, dict]:
    root = Path(os.path.realpath(base or Path(__file__).parent))
    expected = root / "profile_timeline.py"
    actual = Path(os.path.realpath(expected))
    require(os.path.commonpath((str(root), str(actual))) == str(root),
            "Trace parser escaped the frozen helper directory")
    manifest = read(root / "launch-manifest.json")
    row = manifest["files"]["profile_timeline.py"]
    require(actual.is_file() and actual.stat().st_size == row["bytes"]
            and digest(actual) == row["sha256"], "Frozen trace parser bytes changed")
    imported = importlib.util.spec_from_file_location("cpu_probe_bound_trace_parser", actual)
    require(imported is not None and imported.loader is not None, "Trace parser is not importable")
    module = importlib.util.module_from_spec(imported)
    imported.loader.exec_module(module)
    require(os.path.realpath(module.__file__) == str(actual)
            and digest(Path(module.__file__)) == row["sha256"],
            "Executed a shadowed trace parser")
    return module, {"actual_path": str(actual), "sha256": row["sha256"],
                    "launch_manifest_sha256": digest(root / "launch-manifest.json")}


def validate_thread_control(control: dict, policy: str) -> None:
    require(policy in POLICIES and control.get("applied_after_build") is True
            and control.get("requested") == POLICIES[policy], "Thread policy identity differs")
    before, after = control["before"], control["after"]
    require(all(type(row.get(key)) is int and row[key] > 0
                for row in (before, after) for key in ("intraop", "interop")),
            "Invalid actual thread counts")
    require(after["intraop"] == (before["intraop"] if policy == "native" else POLICIES[policy])
            and all(before[key] == after[key] for key in ("interop", "affinity", "env")),
            "Thread policy relabelled actual count or changed other scheduling state")


def validate_profile(summary: dict, window: dict) -> None:
    require(window.get("skip_fetches") == 1024 and window.get("requested_fetches") == 16
            and window.get("profiled_fetches") == 16 and window.get("started") is True
            and window.get("stopped") is True and window.get("restored") is True
            and window.get("microbatch") == 0 and window.get("phase") == "forward",
            "Incomplete or relabelled forward expert-fetch profile window")
    require(summary.get("event_count", 0) > summary.get("cuda_event_count", 0)
            and summary.get("cuda_kernel_event_count", 0) > 0
            and summary.get("cuda_h2d_event_count", 0) > 0,
            "Actual CPU, CUDA kernel and H2D activity required; no CPU-only fallback")


def select_candidate(exploration: list[dict]) -> dict:
    require(len(exploration) == len(POLICIES)
            and [row["policy"] for row in exploration] == list(EXPLORATION_ORDER),
            "Exploratory schedule differs from preregistration")
    rows = {}
    for row in exploration:
        values = row["step_seconds"]
        require(type(row["actual_threads"]) is int and row["actual_threads"] > 0
                and len(values) == 6 and all(type(v) in (int, float)
                                            and math.isfinite(v) and v > 0 for v in values),
                "Incomplete or non-finite exploratory timing")
        require(row["policy"] not in rows, "Duplicate exploratory policy")
        rows[row["policy"]] = row
    native = rows["native"]
    for policy, row in rows.items():
        require(POLICIES[policy] is None or row["actual_threads"] == POLICIES[policy],
                "Exploratory policy relabelled an actual thread count")
    eligible = [row for row in rows.values()
                if row["actual_threads"] != native["actual_threads"]]
    best = min(eligible, key=lambda row: statistics.median(row["step_seconds"]), default=None)
    base = statistics.median(native["step_seconds"])
    positive = best is not None and statistics.median(best["step_seconds"]) < base
    return {"status": "selected_for_confirmation" if positive else "NO_CONFIRMED_WIN",
            "candidate": best["policy"] if positive else None,
            "native_actual_threads": native["actual_threads"],
            "duplicate_controls": [row["policy"] for row in rows.values()
                                   if row["policy"] != "native"
                                   and row["actual_threads"] == native["actual_threads"]],
            "exploratory_only": True, "not_a_confirmatory_speed_estimate": True}


def confirm_summary(blocks: list[dict], reference_policy: str, candidate_policy: str,
                    common: Any) -> dict:
    require(reference_policy == "native" and candidate_policy in POLICIES
            and candidate_policy != "native" and common.RTOL == .01 and common.ATOL == 1e-5,
            "Confirmation identity or original tolerances changed")
    require(len(blocks) == 8, "Exactly eight fresh balanced confirmation workers required")
    pair = (reference_policy, candidate_policy)
    orders = (pair, tuple(reversed(pair))) * 2
    seen, pids, rounds, baseline_controls = set(), set(), {}, []
    for block in blocks:
        number, position, policy = block["round"], block["position"], block["policy"]
        require(type(number) is int and 0 <= number < 4 and type(position) is int
                and 0 <= position < 2 and orders[number][position] == policy
                and (number, policy) not in seen, "Unbalanced confirmation schedule")
        seen.add((number, policy))
        result = block["result"]
        require(type(result["pid"]) is int and result["pid"] > 0 and result["pid"] not in pids,
                "Confirmation did not use fresh valid processes")
        pids.add(result["pid"])
        validate_thread_control(result["thread_control"], policy)
        baseline_controls.append(result["thread_control"]["before"])
        for stage, count in (("warmup", 2), ("timing", 6)):
            data = result[stage]
            require(data.get("complete") is True and data.get("updates_complete") == count
                    and data.get("finite_state_checks_per_update") is True
                    and len(data["update_seconds"]) == len(data["losses"]) == count
                    and all(type(v) in (int, float) and math.isfinite(v) and v > 0
                            for v in data["update_seconds"]),
                    "Incomplete confirmation training block")
        rounds.setdefault(number, {})[policy] = block
    require(all(value == baseline_controls[0] for value in baseline_controls),
            "Native CPU configuration drifted between confirmation processes")
    logs, losses = [], []
    for number in range(4):
        left, right = (rounds[number][policy]["result"] for policy in pair)
        require(left["thread_control"]["after"]["intraop"] !=
                right["thread_control"]["after"]["intraop"],
                "Identical actual thread counts cannot be a new candidate")
        for stage in ("warmup", "timing"):
            a, b = left[stage]["losses"], right[stage]["losses"]
            require(len(a) == len(b) and all(
                type(x) in (int, float) and type(y) in (int, float) and
                math.isfinite(x) and math.isfinite(y) and
                abs(y - x) <= common.ATOL + common.RTOL * abs(x) and f"{y:.3f}" == f"{x:.3f}"
                for x, y in zip(a, b)), "Confirmation recorded numerical loss gate failed")
            losses.append({"round": number, "stage": stage, "bitwise": a == b})
        logs.append(math.log(statistics.median(right["timing"]["update_seconds"]) /
                             statistics.median(left["timing"]["update_seconds"])))
    rng = random.Random(29)
    draws = sorted(100 * (1 - math.exp(statistics.mean(rng.choices(logs, k=4))))
                   for _ in range(5000))
    lower, upper = draws[124], draws[4874]
    return {"reference": reference_policy, "candidate": candidate_policy,
            "paired_rounds": 4, "step_time_reduction_percent":
            100 * (1 - math.exp(statistics.mean(logs))),
            "throughput_increase_percent": 100 * (math.exp(-statistics.mean(logs)) - 1),
            "paired_bootstrap_95_percent": [lower, upper],
            "passes_practical_2_percent_gate": lower >= 2., "recorded_loss_gates": losses,
            "independent_of_exploratory_selection_samples": True}


def modules(root: Path) -> Any:
    sys.path[:0] = [str(root / "src"), str(root)]
    from benchmarks.harness import expert_cache_dispatch_qualification as qualified

    return qualified


def validate_contract(spec: dict, protocol: dict) -> None:
    require(protocol.get("execution_plan") == CONTRACT, "Execution contract differs")
    require(spec["git_head"] == COMMIT and spec["dtype"] == "bfloat16"
            and spec["quant"] == "nf4" and spec["accuracy_updates"] == 2
            and spec["accumulation"] == 2 and spec["warmup_updates"] == 2
            and spec["timed_updates"] == 6 and spec["seq_len"] == 512
            and spec["batch_size"] == 1 and spec["host_cache_bytes"] == 8 * 2**30
            and spec["device_cache_bytes"] == 2 * 2**30
            and spec["host_cache_policy"] == "static", "Frozen scientific recipe differs")


def validate_resource_boundary(raw: dict, spec: dict) -> None:
    """Keep the previous native8GB/28..32GiB/no-swap acceptance boundary."""
    env = raw["environment"]
    require(env["gpu_total_bytes"] == spec["hardware"]["physical_vram_bytes"]
            and 7 * 2**30 <= env["gpu_total_bytes"] <= 8 * 2**30,
            "Worker differs from the admitted physical8GB GPU")
    limit = spec["host_boundary"]["effective_limit_bytes"]
    require(28 * 2**30 <= limit <= 32 * 2**30
            and spec["host_boundary"]["swap_disabled"] is True,
            "Native RAM or disabled swap boundary differs")
    snapshots = [raw["resources_before"], raw["resources_after"]]
    for name in ("setup", "accuracy", "warmup", "timing", "context",
                 "profile_update", "lifecycle"):
        if name not in raw:
            continue
        resource = raw[name]["resources"]
        require(resource["sampled_peak_cgroup_swap_bytes"] == 0
                and resource["sampled_peak_process_swap_bytes"] == 0,
                "Swap was observed during a worker phase")
        snapshots += [resource["before"], resource["after"]]
    for snapshot in snapshots:
        require(snapshot["process_swap_bytes"] == 0, "Worker process swapped")
        constraints = snapshot["cgroup"]["constraints"]
        physical = snapshot["host_memory"]["MemTotal"]
        finite_limits = [row["memory.max"] for row in constraints
                         if type(row["memory.max"]) is int]
        require(type(physical) is int and physical > 0
                and all(value > 0 for value in finite_limits)
                and min([physical, *finite_limits]) == limit,
                "Effective native RAM minimum changed")
        require(constraints and all(row["memory.swap.current"] == 0 for row in constraints)
                and any(row["memory.max"] == limit for row in constraints)
                and (snapshot["host_memory"].get("SwapTotal", 0) == 0
                     or any(row["memory.swap.max"] == 0 for row in constraints)),
                "Worker native RAM/swap scope changed")


def worker_main(args: Any) -> int:
    import torch

    q = modules(args.source_root)
    native, worker, _common, module, identity = q.project(args.source_root, COMMIT)
    spec, protocol = read(args.spec), read(args.protocol)
    validate_contract(spec, protocol)
    require(args.phase != "profile" or args.policy == "native",
            "The preregistered profile uses native CPU threads only")
    native.verify_spec(spec, content=False)
    args.out.mkdir(parents=True, exist_ok=True)
    proof = {"status": "running", "policy": args.policy, "phase": args.phase,
             "pid": os.getpid(), "source": identity, "probe_sha256": digest(Path(__file__)),
             "spec_sha256": digest(args.spec), "protocol_sha256": digest(args.protocol)}
    envelope = args.out / "cpu-envelope.json"
    save(envelope, proof)
    original = worker._build

    @functools.wraps(original)
    def build(*parts: Any, **kwargs: Any) -> Any:
        started = time.perf_counter()
        values = original(*parts, **kwargs)
        proof["native_build_seconds_before_thread_override"] = time.perf_counter() - started
        proof["thread_control"] = apply_threads(torch, POLICIES[args.policy])
        return values

    try:
        with q.dispatch(module, "grouped") as dispatch, patch.object(worker, "_build", build):
            if args.phase == "profile":
                run_profile(args, worker)
                status = 0
            else:
                status = worker.run_worker(args.spec, "two_read_cache", args.phase, args.out)
        require(status == 0, "Native worker failed; originals retained")
        q.validate_dispatch_evidence(dispatch, "grouped")
        proof["dispatch"] = dispatch
        proof["threads_after_worker"] = thread_snapshot(torch)
        require(proof["threads_after_worker"] == proof["thread_control"]["after"],
                "Thread settings changed during worker execution")
        raw_path = args.out / ("profile-result.json" if args.phase == "profile" else "result.json")
        raw = read(raw_path)
        require(raw["status"] == "passed", "Raw result did not pass")
        if args.phase != "profile":
            q.validate_native_routes(raw, "grouped")
        proof.update(status="passed", raw_sha256=digest(raw_path))
    except BaseException as error:
        proof.update(status="failed", error=f"{type(error).__name__}: {error}",
                     traceback=traceback.format_exc())
    finally:
        save(envelope, proof)
    return 0 if proof["status"] == "passed" else 1


class FetchWindow:
    """One fixed forward-only diagnostic window; always restore the fetcher."""

    def __init__(self, profiler: Any, torch: Any):
        self.profiler, self.torch = profiler, torch
        self.enabled, self.calls = False, 0
        self.stop_attempted = False
        self.evidence = {"skip_fetches": 1024, "requested_fetches": 16, "profiled_fetches": 0,
                         "started": False, "stopped": False, "restored": False,
                         "microbatch": 0, "phase": "forward"}

    def cache_snapshot(self, owner: Any, point: str) -> None:
        stats = getattr(owner, "cache_stats", None)
        if callable(stats):
            self.evidence[point] = stats()

    @contextlib.contextmanager
    def installed(self) -> Any:
        from soup_cli.utils.expert_stream import ExpertFetcher

        original = ExpertFetcher.fetch

        def fetch(*args: Any, **kwargs: Any) -> Any:
            if not self.enabled:
                return original(*args, **kwargs)
            self.calls += 1
            first = self.evidence["skip_fetches"] + 1
            last = self.evidence["skip_fetches"] + self.evidence["requested_fetches"]
            active = first <= self.calls <= last
            if self.calls == first:
                self.cache_snapshot(args[0], "cache_before")
                self.torch.cuda.synchronize()
                self.profiler.start()
                self.evidence["started"] = True
            result = original(*args, **kwargs)
            if active:
                self.evidence["profiled_fetches"] += 1
            if self.calls == last:
                self.cache_snapshot(args[0], "cache_after")
                self.stop_attempted = True
                self.profiler.stop()
                self.evidence["stopped"] = True
            return result

        try:
            with patch.object(ExpertFetcher, "fetch", fetch):
                yield self
        finally:
            try:
                if self.evidence["started"] and not self.stop_attempted:
                    self.stop_attempted = True
                    self.profiler.stop()
                    self.evidence["stopped"] = True
            finally:
                self.evidence["restored"] = ExpertFetcher.fetch is original


def run_profile(args: Any, worker: Any) -> None:
    import torch
    from torch.profiler import ProfilerActivity, profile, record_function

    from benchmarks.harness import expert_cache_profile as p

    spec = read(args.spec)
    result = {"status": "running", "policy": "native", "phase": "profile",
              "pid": os.getpid(), "arm": "two_read_cache",
              "spec_sha256": digest(args.spec), "unprofiled_speed_verdict": "NO VERDICT"}
    path = args.out / "profile-result.json"
    save(path, result)
    runtime, sampler, lifecycle = None, None, None
    try:
        torch.cuda.set_device(0)
        torch.manual_seed(spec["seed"])
        torch.cuda.manual_seed_all(spec["seed"])
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
        torch.use_deterministic_algorithms(True)
        result["environment"] = worker._environment(torch)
        result["resources_before"] = worker._resources()
        lifecycle = worker.ResourceSampler().start()
        batches = torch.load(spec["training_data_path"], map_location="cpu", weights_only=True)
        sampler = worker.ResourceSampler().start()
        model, runtime, plan = worker._build(spec, "two_read_cache")
        result["setup"] = {"resources": sampler.finish(), "cuda": worker._cuda_peaks(torch),
                           "cache_plan": plan, "runtime_after": worker._runtime_snapshot(runtime)}
        worker._enforce_stage_limits(spec, result["setup"])
        sampler = None
        optimizer = worker._optimizer(model, spec)
        result["initial_adapters"] = p._hash_tensors(worker._adapters(model))
        result["input_sha256"] = digest(Path(spec["training_data_path"]))
        result["warmup"] = worker._timed_updates(model, runtime, optimizer, batches, spec, 2)
        result["context"] = worker._timed_updates(model, runtime, optimizer, batches, spec, 1)
        result["state_before"] = p._training_hashes(model, optimizer)
        profiler = profile(activities=[ProfilerActivity.CPU, ProfilerActivity.CUDA],
                           record_shapes=False, profile_memory=False, with_stack=False,
                           with_flops=False)
        window = FetchWindow(profiler, torch)
        result["window"] = window.evidence
        sampler = worker.ResourceSampler().start()
        torch.cuda.reset_peak_memory_stats()
        runtime_before = worker._runtime_snapshot(runtime)
        model.zero_grad(set_to_none=True)
        losses = []
        with p.operation_markers(record_function), window.installed():
            for micro in range(spec["accumulation"]):
                ids = batches[micro].to("cuda")
                window.enabled = micro == 0
                with torch.autocast("cuda", dtype=torch.bfloat16):
                    output = model(input_ids=ids, labels=ids, use_cache=False)
                    loss = output.loss / spec["accumulation"]
                    losses.append(output.loss.detach())
                window.enabled = False
                loss.backward()
                del output, loss
                torch.cuda.synchronize()
        optimizer.step()
        torch.cuda.synchronize()
        worker._finite_training_state(model, optimizer, losses)
        result["profile_update"] = {"losses": [float(v.cpu()) for v in losses],
                                    "updates": 1, "microbatches": 2,
                                    "runtime_before": runtime_before,
                                    "runtime_after": worker._runtime_snapshot(runtime),
                                    "resources": sampler.finish(),
                                    "cuda": worker._cuda_peaks(torch)}
        worker._enforce_stage_limits(spec, result["profile_update"])
        sampler = None
        result["window"] = window.evidence
        before, after = (window.evidence[point] for point in ("cache_before", "cache_after"))
        delta = {key: after[key] - before[key] for key in (
            "logical_fetches", "storage_reads", "storage_bytes_read", "materializations")}
        delta.update({tier + "_hits": after[tier]["hits"] - before[tier]["hits"]
                      for tier in ("host", "device")})
        result["window"]["cache_delta"] = delta
        summary = p.profiler_summary(profiler)
        result["profile_summary"] = summary
        save(args.out / "key-averages.json", summary)
        result["trace"] = p.retain_trace(profiler, args.out, 128 * 2**20)
        parser, parser_binding = load_timeline_parser()
        timeline = parser.analyze_trace(args.out / "trace.json.gz")
        save(args.out / "timeline.json", timeline)
        validate_profile(summary, window.evidence)
        require(delta["logical_fetches"] == 16 and delta["host_hits"] > 0
                and delta["device_hits"] == 0
                and delta["storage_reads"] + delta["host_hits"] == 16,
                "The diagnostic fetch window did not exercise the intended RAM-cache path")
        require(timeline["status"] == "parsed"
                and timeline["event_category_counts"].get("kernel", 0) > 0
                and timeline["event_category_counts"].get("gpu_memcpy", 0) > 0
                and any(row["union_us_by_kind"]["h2d"] > 0
                        for row in timeline["devices"].values()),
                "Actual trace must contain GPU kernel and H2D categories")
        result["timeline_sha256"] = digest(args.out / "timeline.json")
        result["timeline_parser_binding"] = parser_binding
        result["timeline_parser_sha256"] = parser_binding["sha256"]
        result["state_after"] = p._training_hashes(model, optimizer)
        require(result["input_sha256"] == digest(Path(spec["training_data_path"])),
                "Frozen inputs changed during profile")
        result["status"] = "passed"
    except BaseException as error:
        result.update(status="failed", error=f"{type(error).__name__}: {error}",
                      traceback=traceback.format_exc())
        raise
    finally:
        if sampler is not None:
            try:
                result["interrupted_resources"] = sampler.finish()
            except BaseException as error:
                result.update(status="failed", resource_error=f"{type(error).__name__}: {error}")
        if lifecycle is not None:
            try:
                result["lifecycle"] = {"resources": lifecycle.finish()}
                result["lifecycle"]["cuda"] = worker._cuda_peaks(torch)
                worker._enforce_stage_limits(spec, result["lifecycle"])
            except BaseException as error:
                result.update(status="failed", resource_error=f"{type(error).__name__}: {error}")
        if runtime is not None:
            try:
                runtime.close()
            except BaseException as error:
                result.update(status="failed", cleanup_error=f"{type(error).__name__}: {error}")
        try:
            result["resources_after"] = worker._resources()
        except BaseException as error:
            result.update(status="failed", resource_error=f"{type(error).__name__}: {error}")
        save(path, result)


def launch(args: Any, policy: str, phase: str, out: Path) -> dict:
    out.mkdir(parents=True, exist_ok=False)
    command = [sys.executable, str(Path(__file__).absolute()), "worker", "--policy", policy,
               "--phase", phase, "--spec", str(args.spec), "--out", str(out),
               "--source-root", str(args.source_root), "--source-commit", COMMIT,
               "--protocol", str(args.protocol)]
    started = time.perf_counter()
    with (out / "worker.log").open("wb") as log:
        process = subprocess.run(command, cwd=args.source_root, stdout=log,
                                 stderr=subprocess.STDOUT,
                                 timeout=read(args.spec)["timeout_seconds"])
    require(process.returncode == 0, f"{phase}/{policy} failed; all raw evidence retained")
    proof = read(out / "cpu-envelope.json")
    raw_name = "profile-result.json" if phase == "profile" else "result.json"
    raw = read(out / raw_name)
    require(proof["status"] == raw["status"] == "passed" and proof["policy"] == policy
            and proof["phase"] == phase and proof["probe_sha256"] == digest(Path(__file__))
            and proof["spec_sha256"] == raw["spec_sha256"] == digest(args.spec)
            and proof["protocol_sha256"] == digest(args.protocol)
            and proof["raw_sha256"] == digest(out / raw_name), "Worker proof binding failed")
    validate_thread_control(proof["thread_control"], policy)
    raw["thread_control"] = proof["thread_control"]
    result = {"policy": policy, "phase": phase, "result": raw, "envelope": proof,
              "directory": str(out.relative_to(args.out)),
              "fresh_process_wall_seconds": time.perf_counter() - started}
    save(out / "controller-result.json", result)
    return result


def run(args: Any) -> int:
    import torch

    q = modules(args.source_root)
    native, _worker, common, _module, identity = q.project(args.source_root, COMMIT)
    spec, protocol = read(args.spec), read(args.protocol)
    validate_contract(spec, protocol)
    args.out.mkdir(parents=True, exist_ok=False)
    path = args.out / "run.json"
    report = {"status": "running", "accuracy_passed": False, "identity": identity,
              "probe_sha256": digest(Path(__file__)), "spec_sha256": digest(args.spec),
              "protocol_sha256": digest(args.protocol), "execution_plan": CONTRACT,
              "accuracy": {}, "exploration": [], "confirmation": []}
    save(path, report)
    try:
        native.verify_spec(spec, content=True)
        inputs = torch.load(spec["training_data_path"], map_location="cpu", weights_only=True)
        reference = None
        for policy in POLICIES:
            row = launch(args, policy, "accuracy", args.out / "accuracy" / policy)
            capture = torch.load(args.out / row["directory"] / "capture.pt",
                                 map_location="cpu", weights_only=True)
            controls = q.full_capture_controls(capture, inputs, common)
            if reference is None:
                reference = capture
            comparison = common.compare_captures(reference, capture)
            require(comparison["passed"], f"Original full numerical gates failed: {policy}")
            report["accuracy"][policy] = {"worker": row, "controls": controls,
                                          "versus_native": comparison}
            require(digest(args.out / row["directory"] / "capture.pt") ==
                    row["result"]["accuracy"]["capture_sha256"], "Capture byte binding failed")
            del capture
            save(path, report)
        del reference
        report["accuracy_passed"] = True
        save(path, report)
        report["profile"] = launch(args, "native", "profile", args.out / "profile" / "native")
        save(path, report)
        for policy in EXPLORATION_ORDER:
            row = launch(args, policy, "timing", args.out / "exploration" / policy)
            report["exploration"].append({
                "policy": policy, "actual_threads": row["envelope"]["thread_control"][
                    "after"]["intraop"], "step_seconds": row["result"]["timing"][
                        "update_seconds"], "worker": row})
            save(path, report)
        report["selection"] = select_candidate(report["exploration"])
        save(path, report)
        candidate = report["selection"]["candidate"]
        if candidate is not None:
            pair = ("native", candidate)
            for number, order in enumerate((pair, tuple(reversed(pair))) * 2):
                for position, policy in enumerate(order):
                    row = launch(args, policy, "timing", args.out / "confirmation" /
                                 f"round-{number:02d}" / policy)
                    report["confirmation"].append({"round": number, "position": position,
                                                   "policy": policy, **row})
                    save(path, report)
            report["confirmation_summary"] = confirm_summary(
                report["confirmation"], "native", candidate, common)
        native.verify_spec(spec, content=True)
        report["status"] = "completed"
        save(path, report)
        validate_result(args.out, spec, protocol)
    except BaseException as error:
        report.update(status="failed", error=f"{type(error).__name__}: {error}",
                      traceback=traceback.format_exc())
        save(path, report)
        return 1
    return 0


def validate_result(directory: Path, spec: dict, protocol: dict) -> dict:
    validate_contract(spec, protocol)
    result = read(directory / "run.json")
    require(result["status"] == "completed" and result["accuracy_passed"] is True
            and result["execution_plan"] == CONTRACT
            and result["identity"]["source_commit"] == COMMIT
            and result["probe_sha256"] == digest(Path(__file__))
            and set(result["accuracy"]) == set(POLICIES), "Incomplete CPU probe qualification")
    for policy, value in result["accuracy"].items():
        require(value["controls"]["passed"] is True and value["versus_native"]["passed"] is True,
                "Unqualified CPU policy reached timing")
        require(value["worker"]["policy"] == policy
                and value["worker"]["phase"] == "accuracy",
                "Accuracy outer role differs from retained worker")
    require(result["profile"]["policy"] == "native"
            and result["profile"]["phase"] == "profile",
            "Diagnostic profile outer role differs")
    for row in result["exploration"]:
        worker_row = row["worker"]
        require(worker_row["policy"] == row["policy"] and worker_row["phase"] == "timing"
                and row["step_seconds"] == worker_row["result"]["timing"]["update_seconds"]
                and row["actual_threads"] == worker_row["envelope"]["thread_control"][
                    "after"]["intraop"],
                "Exploratory metadata differs from retained timing worker")
    selection = select_candidate(result["exploration"])
    require(selection == result["selection"], "Selection was changed after exploration")
    if selection["candidate"] is None:
        require(not result["confirmation"] and "confirmation_summary" not in result,
                "Unselected candidate was confirmed")
    else:
        from types import SimpleNamespace

        summary = confirm_summary(result["confirmation"], "native", selection["candidate"],
                                  SimpleNamespace(RTOL=.01, ATOL=1e-5))
        require(summary == result["confirmation_summary"], "Confirmation summary differs")
    rows = [value["worker"] for value in result["accuracy"].values()]
    rows += [result["profile"]]
    rows += [value["worker"] for value in result["exploration"]]
    rows += result["confirmation"]
    pids, before, counters = set(), [], {}
    from benchmarks.harness import expert_cache_dispatch_qualification as qualified
    from benchmarks.harness import two_read_cache_worker as worker

    for row in rows:
        policy, phase = row["policy"], row["phase"]
        require(policy in POLICIES and phase in ("accuracy", "profile", "timing"),
                "Unexpected retained worker role")
        relative = row["directory"]
        require(isinstance(relative, str) and relative and not os.path.isabs(relative)
                and "\\" not in relative and all(part not in ("", ".", "..")
                                                  for part in relative.split("/")),
                "Noncanonical worker evidence directory")
        base = os.path.realpath(directory)
        child = Path(os.path.realpath(os.path.join(base, relative)))
        require(os.path.commonpath((base, str(child))) == base,
                "Worker evidence escapes output directory")
        proof = read(child / "cpu-envelope.json")
        raw_name = "profile-result.json" if phase == "profile" else "result.json"
        raw = read(child / raw_name)
        require(proof == row["envelope"] and proof["source"] == result["identity"]
                and proof["probe_sha256"] == result["probe_sha256"]
                and proof["protocol_sha256"] == result["protocol_sha256"]
                and proof["spec_sha256"] == raw["spec_sha256"] == result["spec_sha256"]
                and proof["raw_sha256"] == digest(child / raw_name)
                and proof["phase"] == phase and proof["policy"] == policy
                and proof["status"] == raw["status"] == "passed"
                and type(proof["pid"]) is int and proof["pid"] > 0
                and proof["pid"] == raw["pid"] and proof["pid"] not in pids,
                "Retained source, raw bytes, process or worker binding differs")
        pids.add(proof["pid"])
        validate_thread_control(proof["thread_control"], policy)
        require(proof["threads_after_worker"] == proof["thread_control"]["after"]
                and dict(raw, thread_control=proof["thread_control"]) == row["result"],
                "Retained worker result or final scheduling state changed")
        before.append(proof["thread_control"]["before"])
        qualified.validate_dispatch_evidence(proof["dispatch"], "grouped")
        require(raw["arm"] == "two_read_cache"
                and raw["environment"]["deterministic_algorithms"] is True
                and raw["environment"]["allow_tf32"] is False,
                "Worker arm or deterministic numerical environment differs")
        validate_resource_boundary(raw, spec)
        if phase == "profile":
            require(policy == "native" and raw["window"]["restored"] is True,
                    "Profile policy or restoration changed")
            validate_profile(read(child / "key-averages.json"), raw["window"])
            window = raw["window"]
            a, b = window["cache_before"], window["cache_after"]
            derived = {key: b[key] - a[key] for key in (
                "logical_fetches", "storage_reads", "storage_bytes_read", "materializations")}
            derived.update({tier + "_hits": b[tier]["hits"] - a[tier]["hits"]
                            for tier in ("host", "device")})
            require(derived == window["cache_delta"] and derived["logical_fetches"] == 16
                    and derived["host_hits"] > 0 and derived["device_hits"] == 0
                    and derived["storage_reads"] + derived["host_hits"] == 16,
                    "Profile window cache path was relabelled")
            qualified.validate_native_routes(raw, "grouped")
            for stage in ("warmup", "context", "profile_update"):
                qualified.cache_delta(raw, stage, cached=True)
                for point in ("runtime_before", "runtime_after"):
                    require(raw[stage][point]["expert_grouped_routes"] ==
                            qualified.expected_routes(True),
                            "Diagnostic profile used different grouped expert routes")
            require(raw["timeline_sha256"] == digest(child / "timeline.json")
                    and raw["trace"]["within_bound"] is True
                    and raw["trace"]["sha256"] == digest(child / "trace.json.gz"),
                    "Profile trace/timeline byte binding failed")
            for stage in ("setup", "warmup", "context", "profile_update", "lifecycle"):
                worker._enforce_stage_limits(spec, raw[stage])
        else:
            qualified.validate_native_routes(raw, "grouped")
            stages = ("accuracy",) if phase == "accuracy" else ("warmup", "timing")
            worker._enforce_stage_limits(spec, raw["setup"])
            for stage in stages:
                worker._enforce_stage_limits(spec, raw[stage])
                current = qualified.cache_delta(raw, stage, cached=True)
                require(stage not in counters or counters[stage] == current,
                        "Thread policies performed different expert-cache work")
                counters[stage] = current
            if phase == "accuracy":
                require(raw["accuracy"]["capture_sha256"] == digest(child / "capture.pt"),
                        "Full accuracy capture bytes changed")
    require(all(control == before[0] for control in before),
            "Native CPU state differed between fresh processes")
    return {"status": "passed_structural_probe_validation",
            "requires_independent_raw_artifact_audit": True,
            "speed_verdict": result.get("confirmation_summary", {}).get(
                "passes_practical_2_percent_gate", "NO_CONFIRMED_WIN")}


def profiler_preflight(out: Path) -> int:
    import torch
    from torch.profiler import ProfilerActivity, profile

    sys.path[:0] = [str(Path("/root/liger/repo")), str(Path("/root/liger/repo/src"))]
    from benchmarks.harness.expert_cache_profile import (
        profiler_summary,
        require_cuda_profile,
        retain_trace,
    )
    from soup_cli.utils.expert_stream import ExpertFetcher

    out.mkdir(parents=True, exist_ok=False)
    result = {"status": "running", "model_downloaded": False}
    try:
        require(torch.cuda.is_available(), "Actual CUDA profiler is required")
        source = torch.ones(2**20, pin_memory=True)
        captured = profile(activities=[ProfilerActivity.CPU, ProfilerActivity.CUDA])
        window = FetchWindow(captured, torch)
        result["window"] = window.evidence
        original = ExpertFetcher.fetch

        def synthetic_fetch(*_args: Any, **_kwargs: Any) -> Any:
            return source.to("cuda", non_blocking=True)

        with patch.object(ExpertFetcher, "fetch", synthetic_fetch), window.installed():
            window.enabled = True
            for _ in range(CONTRACT["profile"]["skip_fetches"] + 32):
                device = ExpertFetcher.fetch(None)
                device = device.square()
        torch.cuda.synchronize()
        summary = profiler_summary(captured)
        save(out / "key-averages.json", summary)
        result["window"] = window.evidence
        result["fetcher_restored"] = ExpertFetcher.fetch is original
        result["trace"] = retain_trace(captured, out, 128 * 2**20)
        parser, parser_binding = load_timeline_parser()
        timeline = parser.analyze_trace(out / "trace.json.gz")
        result["timeline_parser_binding"] = parser_binding
        save(out / "timeline.json", timeline)
        require_cuda_profile(summary)
        validate_profile(summary, window.evidence)
        require(result["fetcher_restored"] is True and timeline["status"] == "parsed"
                and timeline["event_category_counts"].get("kernel", 0) > 0
                and timeline["event_category_counts"].get("gpu_memcpy", 0) > 0
                and any(row["union_us_by_kind"]["h2d"] > 0
                        for row in timeline["devices"].values()),
                "Actual dynamic profiler window requires GPU kernels and H2D trace events")
        result["status"] = "passed"
    except BaseException as error:
        result.update(status="failed", error=f"{type(error).__name__}: {error}")
    save(out / "proof.json", result)
    return 0 if result["status"] == "passed" else 1


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("run", "worker", "profiler-preflight", "contract"))
    parser.add_argument("--spec", type=Path)
    parser.add_argument("--protocol", type=Path)
    parser.add_argument("--source-root", type=Path)
    parser.add_argument("--source-commit", default=COMMIT)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--phase", choices=("accuracy", "timing", "profile"))
    parser.add_argument("--policy", choices=tuple(POLICIES))
    args = parser.parse_args()
    require(args.source_commit == COMMIT, "Wrong source commit")
    if args.command == "contract":
        save(args.out, CONTRACT)
        return 0
    if args.command == "profiler-preflight":
        return profiler_preflight(args.out)
    require(all(getattr(args, field) is not None for field in (
        "spec", "protocol", "source_root")), "Missing frozen source/spec/protocol")
    return worker_main(args) if args.command == "worker" else run(args)


if __name__ == "__main__":
    raise SystemExit(main())
