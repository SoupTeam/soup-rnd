"""Build the existing PR's report ONLY after full audit, retention and cleanup.

This module has no provider/GPU calls and performs no Git mutation. Importing it
does not create a report or packet. Frozen audit executables remain unchanged.
"""

from __future__ import annotations

import gzip
import hashlib
import importlib.util
import json
import math
import shutil
import statistics
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

from rich.console import Console

PREP = Path(__file__).parent
STAGE = PREP.parent / "expert-followup-gpu-20261029-a"
SOURCE_ROOT = Path(r"C:\Users\esenb\.codex\worktrees\expert-prefetch-20261028\soup-rnd-d2")
SOURCE = "9873f3239db47ee6c5539cea8b125261cdba82c1"
BASE_SOURCE = "f5670242e13b2b480a78e8fc1e3c797d6bb13800"
CAP_USD = 4.39463027092143
PRIOR_USD = .6053697290785705
GIB = 2**30
BIG_GPU_BYTES = 17 * GIB // 8
POLICIES = ("baseline", "hostpacked", "prefetch_after", "usage2", "larger", "all")
ROOT = Path(r"C:\Users\esenb\.codex\worktrees\stream-memory-auto-20261023\soup-rnd-d2")
REPORT = ROOT / "benchmarks/expert-followup-20261029"


def require(value, message):
    if not value:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def sha(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 2**20), b""):
            value.update(block)
    return value.hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n",
                    encoding="utf-8", newline="\n")


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def patch_bytes():
    return subprocess.check_output(["git", "diff", "--no-ext-diff", "--no-color", "--binary",
                                    BASE_SOURCE, SOURCE], cwd=SOURCE_ROOT)


def numerical_label(value):
    require(value["passed"] is True, "Unqualified numerical result")
    return "bitwise" if value["bitwise"] else "original gates"


def confirmation_table(run):
    result = {}
    for policy in POLICIES:
        cells = [row["worker"] for row in run["confirmation"] if row["policy"] == policy]
        if not cells:
            continue
        result[policy] = {
            "median_of_worker_step_medians_seconds": statistics.median(
                statistics.median(row["result"]["timing"]["update_seconds"]) for row in cells),
            "all_timed_seconds": [row["result"]["timing"]["update_seconds"] for row in cells],
            "median_whole_entry_seconds": statistics.median(
                row["fresh_process_wall_seconds"] for row in cells),
            "median_setup_seconds": statistics.median(
                row["result"]["setup"]["seconds"] for row in cells),
            "max_allocated_bytes": max(row["result"]["timing"]["cuda"]["peak_allocated_bytes"]
                                       for row in cells),
            "max_reserved_bytes": max(row["result"]["timing"]["cuda"]["peak_reserved_bytes"]
                                      for row in cells),
            "max_sampled_rss_bytes": max(
                row["result"]["timing"]["resources"]["sampled_peak_rss_bytes"] for row in cells)}
    return result


def profile_tables(stage, audit, run):
    directory = stage / "retained/results/followup-probe/diagnostic"
    usage, raw = read(directory / "usage-profile.json"), read(directory / "profile-result.json")
    require(sha(directory / "usage-profile.json") == run["usage_plan_sha256"],
            "Placement input differs from audited study")
    before, after = (raw["warmup"][name]["expert_cache"]
                     for name in ("runtime_before", "runtime_after"))
    logical = after["logical_fetches"] - before["logical_fetches"]
    counts = {tier + "_hits": after[tier]["hits"] - before[tier]["hits"]
              for tier in ("host", "device")}
    counts["storage_reads"] = after["storage_reads"] - before["storage_reads"]
    require(logical == usage["observed_requests"] == sum(counts.values()) > 0,
            "Actual recorded learning requests differ")
    counts["logical_fetches"] = logical
    plans = {name: {key: value for key, value in plan.items() if key != "keys"}
             | {"selected_key_count": len(plan["keys"]),
                "recorded_request_coverage_percent": 100 * plan["selected_requests"] / logical}
             for name, plan in usage["plans"].items()}
    require(set(plans) == {str(2 * GIB), str(BIG_GPU_BYTES)}, "Wrong pre-data GPU budgets")
    manifest = read(stage / "launch-manifest.json")
    parser_path = stage / "profile_timeline.py"
    require(sha(parser_path) == manifest["files"][parser_path.name]["sha256"],
            "Frozen profile parser changed")
    parser = load("publication_followup_timeline", parser_path)
    nf4 = {}
    trace_path = directory / "trace.json.gz"
    with gzip.open(trace_path, "rt", encoding="utf-8") as handle:
        for event in parser.trace_events(handle, {}):
            if (event.get("cat") == "kernel" and event.get("ph") == "X"
                    and "dequant" in event.get("name", "").lower()):
                require(type(event["dur"]) in (int, float) and math.isfinite(event["dur"])
                        and event["dur"] >= 0, "Invalid actual dequant-named kernel interval")
                row = nf4.setdefault(event["name"], {"events": 0, "duration_sum_us": 0.})
                row["events"] += 1
                row["duration_sum_us"] += event["dur"]
    return {"learning_updates": 2, "actual_learning_cache_counts": counts,
            "frozen_plan_summaries": plans,
            "usage_profile_sha256": sha(directory / "usage-profile.json"),
            "cpu_spans": audit["diagnostic"]["cpu_spans"],
            "bounded_cuda_timeline": audit["diagnostic"]["timeline"],
            "dequant_named_kernels": nf4, "trace_sha256": sha(trace_path),
            "scope": "CPU spans cover a complete instrumented update. CUDA events cover only "
                     "the declared 16-fetch forward window. Nested/overlapping durations are "
                     "not additive and neither scope is an unprofiled speed denominator."}


def main():
    audit_path = PREP / "independent-audit.json"
    audit = read(audit_path)
    manifest = read(STAGE / "launch-manifest.json")
    require(audit["status"] == "passed_standalone_followup_audit"
            and audit["source_commit"] == SOURCE
            and audit["audit_script_sha256"] == sha(STAGE / "audit_followup.py")
            == manifest["files"]["audit_followup.py"]["sha256"],
            "A passed, exact frozen-source audit is required before publication")
    require(audit["cleanup"]["verified_absent"] is True
            and audit["cleanup"]["instance_verified_absent"] is True
            and audit["cleanup"]["volume_verified_absent"] is True,
            "Owned instance and persistent disk must be absent first")
    require(audit["budget"]["stage_cap_usd"] == CAP_USD
            and 0 <= audit["budget"]["stage_cost_usd"] <= CAP_USD,
            "Wrong remaining-authorized budget")
    require(not REPORT.exists(), "Preserve the existing PR report directory")
    run_path = STAGE / "retained/results/followup-probe/run.json"
    require(sha(run_path) == audit["qualification_run_sha256"], "Raw study was not the audited one")
    run = read(run_path)
    require(set(audit["accuracy"]) == set(audit["exploration"]) == set(POLICIES),
            "Six qualified arms required")
    protocol = read(STAGE / "protocol.json")
    require(protocol["execution_plan"]["policies"]["all"]["gpu"] == BIG_GPU_BYTES
            and protocol["execution_plan"]["policies"]["larger"]["gpu"] == BIG_GPU_BYTES
            and protocol["source_commit"] == SOURCE, "Pre-data arm/source binding differs")
    library = load("followup_packet_library", PREP.parent /
                   "expert-cpu-overlap-20261028/package_cpu_evidence.py")
    library.SOURCE, library.PREP = SOURCE, PREP
    library.MAX_PUBLIC_FILE = 4 * 2**20
    library.expected_auditor = lambda _audit: str(STAGE / "audit_followup.py")

    def verify_stage(stage, path):
        result = read(path)
        require(result == audit, "Audit changed during packaging")
        for name, field in (("archive-manifest.json", "archive_manifest_sha256"),
                            ("bundle-verified.json", "bundle_verified_sha256"),
                            ("launch-manifest.json", "launch_manifest_sha256")):
            require(sha(stage / name) == result[field], "Audit evidence hash differs: " + name)
        outer = read(stage / "archive-manifest.json")
        require(sha(stage / "result.lossless.tar") == outer["sha256"], "Raw archive changed")
        for name, row in outer["files"].items():
            file = library.contained(stage / "retained", name)
            require(file.stat().st_size == row["bytes"] and library.sha(file) == row["sha256"],
                    "Retained original changed: " + name)
        return result, outer

    library.verify_stage = verify_stage
    for name, expected in manifest["files"].items():
        file = library.contained(STAGE, name)
        require(file.stat().st_size == expected["bytes"] and sha(file) == expected["sha256"],
                "Frozen publication input changed after audit: " + name)
    private_paths = (Path.home() / ".config/vastai/vast_api_key", STAGE / "ssh-key")
    secrets = tuple(value for path in private_paths for value in
                    (path.read_bytes(), path.read_bytes().strip()))
    packet = library.package(STAGE, audit_path, PREP / "publication", secrets)
    profile = profile_tables(STAGE, audit, run)
    confirmation = confirmation_table(run)
    patch = patch_bytes()
    require(patch, "Missing immutable companion-source diff")
    library.privacy(patch, secrets)
    REPORT.mkdir(parents=True)
    shutil.copyfile(PREP / "publication/evidence.zip", REPORT / "evidence.zip")
    require(sha(REPORT / "evidence.zip") == packet["sha256"], "Packet copy changed")
    info = zipfile.ZipInfo("prototype.patch", date_time=(1980, 1, 1, 0, 0, 0))
    info.compress_type = zipfile.ZIP_DEFLATED
    with zipfile.ZipFile(REPORT / "prototype.patch.zip", "w") as archive:
        archive.writestr(info, patch, compresslevel=9)
    for name in ("audit_followup.py", "archive_audit.py", "audit_infrastructure.py"):
        (REPORT / (name + ".txt")).write_bytes((STAGE / name).read_bytes().replace(b"\r\n", b"\n"))
    write(REPORT / "summary.json", audit)
    write(REPORT / "tables.json", {"source_commit": SOURCE,
        "qualification_run_sha256": sha(run_path), "exploration": audit["exploration"],
        "confirmation_absolute": confirmation, "confirmation_paired": audit["confirmation"]})
    write(REPORT / "diagnostic.json", profile)
    (REPORT / ".gitattributes").write_text("* -text\n", encoding="utf-8", newline="\n")
    (REPORT / "README.md").write_text(report_text(audit, run, profile, confirmation, protocol),
                                      encoding="utf-8", newline="\n")
    write(REPORT / "evidence-manifest.json", {"schema_version": 1, "source_commit": SOURCE,
        "base_source_commit": BASE_SOURCE, "packet": packet,
        "audit_sha256": sha(audit_path), "auditor_sha256": audit["audit_script_sha256"],
        "launch_manifest_sha256": audit["launch_manifest_sha256"],
        "portable_patch": {"bytes": len(patch), "sha256": hashlib.sha256(patch).hexdigest(),
                           "base_commit": BASE_SOURCE, "source_commit": SOURCE},
        "report_files": {path.name: {"bytes": path.stat().st_size, "sha256": sha(path)}
                         for path in REPORT.iterdir() if path.is_file()}})
    Console().print({"report": str(REPORT), "verdict": audit["speed_verdict"],
                     "packet_bytes": packet["bytes"], "allocation": False,
                     "git_mutations": False})


def report_text(audit, run, profile, confirmation, protocol):
    chosen = audit["confirmation"]
    if chosen:
        interval = chosen["paired_bootstrap_95_percent"]
        verdict = (f"Four NEW balanced AB/BA pairs for **{chosen['candidate']}** give "
            f"**{chosen['step_time_reduction_percent']:.3f}%** paired step-time reduction "
            f"(95% bootstrap **[{interval[0]:.3f}%, {interval[1]:.3f}%]**) and "
            f"**{chosen['throughput_increase_percent']:.3f}%** throughput increase. "
            + ("The unchanged >=2% lower-bound gate passes." if
               chosen["passes_practical_2_percent_gate"] else
               "The unchanged >=2% lower-bound gate does NOT pass."))
    else:
        verdict = ("No distinct exploratory candidate beat the fresh packed baseline. "
                   "No confirmation pairs ran; no confidence interval is manufactured.")
    rows = []
    settings = protocol["execution_plan"]["policies"]
    for name in POLICIES:
        item = audit["exploration"][name]
        rows.append(f"| {name} | {settings[name]['gpu'] / GIB:g} | "
            f"{item['median_step_seconds']:.4f} | {item['whole_entry_seconds']:.3f} | "
            f"{item['cuda']['peak_allocated_bytes'] / GIB:.4f} | "
            f"{item['cuda']['peak_reserved_bytes'] / GIB:.4f} | "
            f"{item['sampled_peak_rss_bytes'] / GIB:.4f} | "
            f"{numerical_label(audit['accuracy'][name])} |")
    held = ""
    if confirmation:
        held_rows = [f"| {name} | {value['median_of_worker_step_medians_seconds']:.4f} | "
            f"{value['median_whole_entry_seconds']:.3f} | "
            f"{value['max_allocated_bytes'] / GIB:.4f} | "
            f"{value['max_reserved_bytes'] / GIB:.4f} | "
            f"{value['max_sampled_rss_bytes'] / GIB:.4f} |"
            for name, value in confirmation.items()]
        held = ("\nHeld-out confirmation only: step and complete entry are medians of four "
            "worker summaries per arm; memory is their observed maximum.\n\n"
            "| Arm | Step, s | Eight-update entry, s | Allocated GiB | Reserved GiB | RSS GiB |\n"
            "| --- | ---: | ---: | ---: | ---: | ---: |\n" + "\n".join(held_rows) + "\n")
    counts = profile["actual_learning_cache_counts"]
    distribution = [f"| {name} | {counts[name]} | "
                    f"{100 * counts[name] / counts['logical_fetches']:.2f}% |"
                    for name in ("device_hits", "host_hits", "storage_reads")]
    plan_rows = [f"| {int(budget) / GIB:g} | {item['selected_key_count']} | "
                f"{item['payload_bytes'] / GIB:.4f} | "
                f"{item['recorded_request_coverage_percent']:.2f}% |"
                for budget, item in profile["frozen_plan_summaries"].items()]
    spans = profile["cpu_spans"]["spans"]
    span_rows = [f"| {name} | {spans['profile_update/' + name]['calls']} | "
                 f"{spans['profile_update/' + name]['seconds']:.6f} |"
                 for name in ("fetch", "storage_read", "packing_layout",
                              "transfer_stage", "nf4_dequant")]
    timeline = profile["bounded_cuda_timeline"]
    gpu_rows = [f"| {name} | {value['event_span_us']:.3f} | "
                f"{value['union_us_by_kind'].get('h2d', 0):.3f} | "
                f"{value['union_us_by_kind'].get('kernel', 0):.3f} |"
                for name, value in timeline["devices"].items()]
    nf4_count = sum(row["events"] for row in profile["dequant_named_kernels"].values())
    nf4_duration = sum(row["duration_sum_us"] for row in profile["dequant_named_kernels"].values())
    budget, retention = audit["budget"], audit["retention"]
    absence = audit["cleanup"]
    capacity = read(STAGE / "retained/results/capacity-preflight.json")
    source_cases = ET.parse(STAGE / "source-controls.xml").findall(".//testcase")
    require(source_cases and all(not any(case.find(tag) is not None
                                        for tag in ("failure", "error", "skipped"))
                                for case in source_cases), "Pre-data CPU controls were not clean")
    bitwise = all(value["bitwise"] for value in audit["accuracy"].values())
    return f'''# Host packing, usage placement and late expert lookahead

**Verdict: {audit["speed_verdict"]}.** {verdict}

## Scope and six arms

Same Kanana-2-30B-A3B (30.67B total parameters), revision
`0d31365acf656e5f9a593cacc4913e9c0d36cb1c`, frozen NF4 base / BF16 compute /
FP32 attention LoRA rank 4, alpha 8, context 512, batch 1, accumulation 2.
Physical **{capacity["gpu_name"]} / {capacity["gpu_memory_mib"]} MiB**;
native RAM ceiling **{capacity["native_ram_limit_bytes"] / GIB:.3f} GiB**, workload swap disabled.
Frozen Torch 2.10.0+cu130 / CUDA 13 / Triton 3.6.0 / bitsandbytes 0.50.2 stack.
All arms already have two-read, grouped routes, packed H2D and an 8 GiB static RAM
expert-weight cache. Defaults, CLI and model arithmetic remain unchanged.

- **baseline:** existing packed transfer, first-fit 2 GiB dense GPU hotset.
- **hostpacked:** immutable prepacked pageable RAM entries, including alignment
  padding charged inside the SAME 8 GiB RAM ceiling; one CPU staging copy per hit.
- **prefetch_after:** next expert preparation after current MLP/index-add enqueue.
- **usage2:** frozen usage-selected GPU entries under the SAME 2 GiB payload ceiling.
- **larger:** first-fit GPU hotset at 2.125 GiB.
- **all:** host packing, late lookahead and usage-selected 2.125 GiB GPU entries.

The 2.125 GiB larger ceiling was fixed **before rental**, based on the existing
conservative admission policy, which reserves the full lazy cache ceiling on top
of measured peaks. This stage did not try 3 GiB, observe a 3 GiB failure, weaken
admission checks or search for a maximum/optimal cache size.

Tested companion source [{SOURCE[:8]}](https://github.com/SoupTeam/soup-rnd/commit/{SOURCE}),
[portable patch ZIP](prototype.patch.zip) against `{BASE_SOURCE[:8]}`. This remains
an opt-in experimental source; the PR's older production implementation is separate.
The baseline here is already optimized packed streaming, not ordinary three-read.
Old results are not denominators and percentages are not added across cohorts.

## Accuracy before speed; exploratory timing and memory

The table has one fresh process per arm, two warmup and six measured AdamW
updates. Every measured update is retained. It is an exploratory comparison,
not a statistically confirmed ranking of all six candidates.

| Arm | GPU cache GiB | Step s | Entry s | Alloc GiB | Reserved GiB | RSS GiB | Accuracy |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
{chr(10).join(rows)}
{held}
Entry includes cache/model setup, warmup, timing, process startup and validation.
Common checkpoint download/NF4 preparation is separate. RSS is sampled every
50 ms, excludes kernel/filesystem charges and is not total system memory.
Only the best distinct positive exploratory candidate enters four NEW balanced
AB/BA confirmation pairs; selection samples are excluded. Bootstrap: 5000 draws,
seed 29; unchanged practical gate: lower 95% bound >=2% step-time reduction.
Negative and NO_CONFIRMED_WIN outcomes are retained without changing gates.

Six separate full 2-AdamW-update / 4-microbatch captures passed before any timing;
comparison result: **{"all bitwise" if bitwise else "original numerical gates; see each arm"}**.
All 288 LoRA tensors / 144 attention projections receive gradients and update.
Original rtol=.01, atol=1e-5, finite and three-decimal loss checks are unchanged;
all recorded exploratory and paired warmup/timed losses are also checked.
Full final timed tensors and unrecorded first-microbatch losses retain NO VERDICT.
This is same-NF4 numerical/resource qualification, not task quality/convergence.

## Frozen usage profile and placement

Plans use ONLY actual logical expert requests from two baseline warmup updates,
including cache hits; speculative prefetches are excluded. All six workers use
the same frozen inputs and initial adapters. Plans are frozen before candidate
accuracy/timing. These input-specific frequencies are not a held-out dataset study.

| Learning request source | Count | Share |
| --- | ---: | ---: |
{chr(10).join(distribution)}

| GPU ceiling GiB | Experts | Payload GiB | Recorded request coverage |
| --- | ---: | ---: | ---: |
{chr(10).join(plan_rows)}

Ranking is frequency times packed-transfer bytes per dense-GPU byte, with exact
integer fractions, stable first-observed ties and whole-entry budget accounting.
It is a greedy traffic proxy, not measured latency or an optimal placement claim.
Plan membership, sums, raw request counts, per-arm budgets and cache conservation
equations independently reproduce. Different plans may change hit/read counts;
logical expert work and numerical gates remain the same.

## Current packed baseline diagnostic

This is a separate instrumented diagnostic, never a speed denominator. CPU spans
cover a complete update's forward/backward; CUDA trace covers ONLY 16 forward
fetches after 1024 skipped fetches in the first microbatch. The scopes differ;
nested/overlapping durations must not be added or turned into whole-step percentages.

| Complete-update CPU wall span | Calls | Inclusive seconds |
| --- | ---: | ---: |
{chr(10).join(span_rows)}

| CUDA device | First-to-last recorded activity, us | H2D union, us | Kernel union, us |
| --- | ---: | ---: | ---: |
{chr(10).join(gpu_rows)}

Within that bounded CUDA window, **{nf4_count} dequant-named kernels** have a summed
duration **{nf4_duration:.3f} us**. Exact names/counts are in [diagnostic.json](diagnostic.json).
These are kernel-category events, not user annotations; their sum is not a
separate additive part of H2D/whole-step time. The profile cannot by itself prove
physical disk starvation or the current whole-training critical path.

## Source, evidence, cleanup and budget

Pre-data scoped source controls: **{len(source_cases)} CPU passes**.
The **{len(protocol["cuda_expected_case_names"])} declared actual CUDA cases** subsequently
passed without skips before the full checkpoint download. Actual runtime library
identity and immutable official wheel hashes were checked. Full-suite/hosted-CI
success is not inferred. The frozen standalone auditor independently reloads all
six captures, reconstructs plans, reparses original CUDA trace, recomputes selection
and paired timing, and checks source, inputs, no-swap resources, budgets and cleanup.

All **{retention["verified_files"]} originals / {retention["original_bytes"]:,} bytes** retained
and hash-verified from **{retention["archive_bytes"]:,} encoded bytes**. Compact public
[evidence.zip](evidence.zip) uses exact-byte aliases; large captures/model payloads
are explicitly hash-indexed as local-only. Runnable original auditors are in the
packet; `.py.txt` review copies normalize line endings only. The full BF16 source
checkpoint is not retained; official expected/observed SHA receipts are retained.
Physical NVMe backing remains unverified.

Owned instance **{absence["instance_id"]}** and persistent volume **{absence["volume_id"]}**
deleted and freshly verified absent. Shared-account colleagues were untouched.
This follow-up conservative cost: **${budget["stage_cost_usd"]:.6f} / ${CAP_USD:.6f}**;
remaining: **${budget["remaining_usd"]:.6f}**. Prior packed-transfer study cost
**${PRIOR_USD:.6f}** is separate, already deducted from the same $5 allowance;
aggregate against that $5 is **${PRIOR_USD + budget["stage_cost_usd"]:.6f}**.
These are conservative ledgers, not invoices. Older unused $4.909114 is not added.

[Full audited summary](summary.json) · [all timing arrays](tables.json) ·
[diagnostic and placement tables](diagnostic.json) · [evidence manifest](evidence-manifest.json).
'''


if __name__ == "__main__":
    main()
