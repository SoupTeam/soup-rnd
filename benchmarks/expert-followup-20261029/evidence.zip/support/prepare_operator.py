"""Create an isolated unpaid follow-up stage from closed, verified primitives."""

from __future__ import annotations

import json
from pathlib import Path

from rich.console import Console

PREP = Path(__file__).parent
BASE = PREP.parent
OLD = BASE / "expert-prefetch-gpu-20261028-a"
NEW = BASE / "expert-followup-gpu-20261029-a"
STUDY = "soup-expert-followup-20261029-a"
MAXIMUM_USD = 4.39463027092143
PENDING = "ROOT_SOURCE_COMMIT_PENDING"


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def main():
    assert json.loads((OLD / "independent-vast-absence.json").read_text())["verified_absent"]
    NEW.mkdir(exist_ok=False)
    names = (
        "cloud.py", "controller.py", "transport.py", "api_transport.py", "api_rate_limit.py",
        "diagnostics.py", "durable.py", "launch.py", "range_transport.py", "remote_guard.py",
        "remote_run.py", "preflight_remote.py", "lossless_results.py", "checkpoint_integrity.py",
        "runtime_stack.py", "setup.sh", "constraints.txt", "software-cohort.json",
        "runtime-wheel-lock.json", "runtime-wheel-requirements.txt", "cuda13-stack-metadata.json",
        "cuda13-transitive-metadata.json", "profile_timeline.py", "cpu_overlap_probe.py",
        "storage-capacity-plan.json", "upload-probe.bin", "software-lock-validation.json",
        "test_controller.py", "test_native_transport.py", "test_diagnostics_concurrency.py",
        "test_f13_cross_process.py", "test_runtime_stack.py", "test_setup_bytes.py")
    for name in names:
        raw = (OLD / name).read_bytes()
        if name in {"cloud.py", "controller.py", "transport.py", "launch.py", "remote_run.py"}:
            text = raw.decode().replace("soup-expert-prefetch-20261028-a", STUDY).replace(
                "soup_expert_prefetch_20261028_a", "soup_expert_followup_20261029_a")
            text = text.replace("transfer_probe.py", "followup_probe.py")
            text = text.replace("transfer-probe", "followup-probe")
            text = text.replace("preregistered_expert_transfer_study", "preregistered_followup_study")
            text = text.replace("MAXIMUM_USD = 5.0", f"MAXIMUM_USD = {MAXIMUM_USD!r}")
            text = text.replace("new USD5 prototype cap", "remaining prior USD5 follow-up cap")
            raw = text.encode()
        (NEW / name).write_bytes(raw)
    protocol = json.loads((OLD / "protocol.json").read_text())
    protocol.update(stage_id=STUDY, source_commit=PENDING,
                    purpose="packed_hostcache_usage_placement_late_prefetch_followup",
                    preparation_status="SOURCE_AND_CUDA_SELECTORS_PENDING")
    protocol["financial"]["maximum_stage_usd"] = MAXIMUM_USD
    protocol["financial"]["prior_usd"] = 0.
    protocol["execution_plan"] = {"status": "ROOT_API_AND_SOURCE_PENDING"}
    protocol["performance"] = protocol["execution_plan"]
    write(NEW / "protocol.json", protocol)
    write(NEW / "prior-budget-context.json", {
        "last_user_allowance_usd": 5., "already_spent_usd": .6053697290785705,
        "maximum_stage_usd": MAXIMUM_USD,
        "prior_separate_unused_usd": 4.909114004480999,
        "prior_separate_unused_is_not_added": True,
        "rental_started": False})
    # No prior scientific XML, keys, source payloads, manifests, or lease receipts copied.
    (NEW / "launch_safety.py").write_text('''"""Fail closed until root binds final source/science/CUDA inputs."""
def validate_protocol(*args, **kwargs):
    raise ValueError("Follow-up stage is UNPAID and UNSEALED: root source/API pending")
''', encoding="utf-8")
    Console().print({"new_unpaid_stage": str(NEW), "cap_usd": MAXIMUM_USD,
                     "private_keys_copied": False, "source_ready": False, "rented": False})


if __name__ == "__main__":
    main()
