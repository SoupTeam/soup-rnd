"""Read only this lease's small status files; no GPU telemetry or process control."""

import json
import subprocess
import sys
from pathlib import Path

from rich.console import Console

STAGE = Path(__file__).parent.parent / "expert-followup-gpu-20261029-a"
sys.path.insert(0, str(STAGE))
import cloud  # noqa: E402

CODE = '''import json,sys,statistics,xml.etree.ElementTree as ET
from pathlib import Path
root=Path('/root/liger/results')
result={'stage':json.loads((root/'stage-status.json').read_text())}
xml=root/'gpu-preflight.xml'
if xml.is_file():
    cases=ET.parse(xml).findall('.//testcase')
    result['actual_cuda_cases']={'count':len(cases),'failed_or_skipped':sum(
        any(row.find(tag) is not None for tag in ('failure','error','skipped')) for row in cases)}
path=root/'followup-probe/run.json'
if path.is_file():
    run=json.loads(path.read_text())
    result.update(status=run['status'],accuracy_passed=run['accuracy_passed'],
        accuracy={name:{'passed':cell['versus_baseline']['passed'],
                        'bitwise':cell['versus_baseline']['bitwise']}
                  for name,cell in run['accuracy'].items()},
        exploration_done=[cell['policy'] for cell in run['exploration']],
        confirmation_completed=len(run['confirmation']),selection=run.get('selection'),
        confirmation_summary=run.get('confirmation_summary'),error=run.get('error'))
    result['exploration']={cell['policy']:{
        'median_step_seconds':statistics.median(cell['worker']['result']['timing']['update_seconds']),
        'allocated_gib':cell['worker']['result']['timing']['cuda']['peak_allocated_bytes']/2**30,
        'rss_gib':cell['worker']['result']['timing']['resources']['sampled_peak_rss_bytes']/2**30}
        for cell in run['exploration']}
    result['confirmation_rows']=[{'round':cell['round'],'policy':cell['policy'],
        'median_step_seconds':statistics.median(cell['worker']['result']['timing']['update_seconds']),
        'whole_entry_seconds':cell['worker']['fresh_process_wall_seconds'],
        'allocated_gib':cell['worker']['result']['timing']['cuda']['peak_allocated_bytes']/2**30,
        'rss_gib':cell['worker']['result']['timing']['resources']['sampled_peak_rss_bytes']/2**30}
        for cell in run['confirmation']]
    result['worker_progress']=[{'path':str(path.relative_to(root)),
        'status':value.get('status'),'error':value.get('error'),
        'setup_seconds':value.get('setup',{}).get('seconds'),
        'warmup_complete':value.get('warmup',{}).get('updates_complete'),
        'timed_complete':value.get('timing',{}).get('updates_complete'),
        'timed_seconds':value.get('timing',{}).get('update_seconds')}
        for path in sorted((root/'followup-probe').rglob('result.json'),
                           key=lambda path:path.stat().st_mtime)[-1:]
        for value in [json.loads(path.read_text())]]
    usage=root/'followup-probe/diagnostic/usage-profile.json'
    if usage.is_file():
        data=json.loads(usage.read_text())
        result['usage']={'observed_requests':data['observed_requests'],
            'experts':len(data['records']),
            'plans':{key:{name:value[name] for name in ('payload_bytes','selected_requests')}
                     for key,value in data['plans'].items()}}
sys.stdout.write(json.dumps(result))
'''


if __name__ == "__main__":
    answer = subprocess.run(cloud.ssh_args() + ["python3 -"], input=CODE.encode(),
                            capture_output=True, check=False, timeout=25)
    if answer.returncode:
        Console().print({"status": "read_only_progress_unavailable", "code": answer.returncode})
    else:
        result = json.loads(answer.stdout)
        if '--compact' in sys.argv:
            result = {name: result.get(name) for name in (
                'status', 'accuracy_passed', 'confirmation_completed', 'confirmation_rows',
                'confirmation_summary', 'worker_progress', 'error')}
        Console().print(json.dumps(result))
