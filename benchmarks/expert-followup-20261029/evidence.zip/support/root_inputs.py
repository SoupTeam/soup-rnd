"""Bind the real CUDA selectors and prior source controls, without provider mutation."""

import json
from pathlib import Path

from rich.console import Console

PREP = Path(__file__).parent
STAGE = PREP.parent / "expert-followup-gpu-20261029-a"
OLD = PREP.parent / "expert-prefetch-gpu-20261028-a"


def main():
    old = json.loads((OLD / "protocol.json").read_text())
    additions = {
        "tests/test_expert_late_prefetch.py": (
            "test_real_cuda_late_prefetch_preserves_kanana_full_optimizer_trajectories",),
        "tests/test_expert_host_packing.py": (
            "test_real_cuda_prepacked_cache_survives_two_tickets_ring_reuse_and_cache_clear",
            "test_real_cuda_prepacked_host_cache_preserves_kanana_full_optimizer_trajectories",
            "test_real_cuda_prepacked_late_prefetch_placement_preserves_kanana_full_optimizer_trajectories",
        ),
    }
    selectors = {key: old[key] for key in ("cuda_test_selectors", "cuda_expected_case_names")}
    for path, names in additions.items():
        selectors["cuda_test_selectors"].extend(path + "::" + name for name in names)
        selectors["cuda_expected_case_names"].extend(names)
    assert len(selectors["cuda_expected_case_names"]) == 14
    (PREP / "cuda-selectors.json").write_text(json.dumps(selectors, indent=2) + "\n")
    Console().print({"actual_cuda_cases_required": 14, "rented": False})


if __name__ == "__main__":
    main()
