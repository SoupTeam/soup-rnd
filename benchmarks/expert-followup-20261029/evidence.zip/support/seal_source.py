"""Root-only final source/protocol binding and a separate offline launch freeze.

Neither command queries a provider, generates keys, creates a greenlight, or rents.
The final clean published source and exact CUDA selectors are explicit inputs.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import io
import json
import os
import pprint
import re
import shutil
import subprocess
import sys
import tarfile
import time
import xml.etree.ElementTree as ET
from pathlib import Path

from rich.console import Console

PREP = Path(__file__).parent
STAGE = PREP.parent / "expert-followup-gpu-20261029-a"
OLD = PREP.parent / "expert-prefetch-gpu-20261028-a"
PENDING = "ROOT_SOURCE_COMMIT_PENDING"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    sys.path.insert(0, str(STAGE))
    from durable import durable_json

    durable_json(path, value)


def unpaid():
    assert not any((STAGE / name).exists() for name in (
        "launch-manifest.json", "lease-greenlight.json", "vast-rental.json")), (
        "Never rewrite a sealed or possibly paid stage")


def module(path):
    spec = importlib.util.spec_from_file_location("bound_" + path.stem, path)
    result = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = result
    spec.loader.exec_module(result)
    return result


def update_private_sources(commit, *, include_audit=False):
    names = ("followup_probe.py", "audit_followup.py") if include_audit else ("followup_probe.py",)
    for name in names:
        path = PREP / name
        if not path.is_file():
            assert name == "audit_followup.py", "Missing actual executable runner"
            continue
        text = path.read_text(encoding="utf-8")
        if PENDING in text:
            text = text.replace(PENDING, commit)
            path.write_text(text, encoding="utf-8", newline="\n")
        assert commit in text, "Private executable belongs to another final source"
        shutil.copyfile(path, STAGE / name)
    for pattern in ("test_followup_probe.py", "test_audit_followup.py", "*-controls.xml"):
        for path in PREP.glob(pattern):
            shutil.copyfile(path, STAGE / path.name)


def bind(args):
    unpaid()
    source, commit = args.source_root, args.commit
    assert re.fullmatch("[0-9a-f]{40}", commit or ""), "An exact final commit is required"
    assert source and args.cuda_selectors and args.source_controls
    actual = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=source, text=True).strip()
    assert actual == commit
    assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=source,
                                       text=True).strip(), "Final source must be clean"
    branch = subprocess.check_output(["git", "branch", "--show-current"], cwd=source,
                                     text=True).strip()
    assert branch
    remote = subprocess.check_output(["git", "ls-remote", "origin", "refs/heads/" + branch],
                                     cwd=source, text=True).split()
    assert remote and remote[0] == commit, "Publish this exact source before paying for deployment"
    selected = json.loads(args.cuda_selectors.read_text())
    selectors, expected = (selected[key] for key in (
        "cuda_test_selectors", "cuda_expected_case_names"))
    assert selectors and len(selectors) == len(set(selectors))
    assert 10 <= len(expected) <= 128 and len(expected) == len(set(expected))
    cases = ET.parse(args.source_controls).findall(".//testcase")
    assert cases and all(case.find("failure") is None and case.find("error") is None
                         for case in cases), "Fresh source controls must not contain failures"
    names = subprocess.check_output(["git", "ls-files", "-z"], cwd=source).decode().split("\0")
    files = {}
    temporary = STAGE / "source.tar.gz.incoming"
    with tarfile.open(temporary, "w:gz", compresslevel=6) as archive:
        for name in sorted(value for value in names if value):
            path = source / name
            assert os.path.normcase(os.path.commonpath((os.path.realpath(source),
                os.path.realpath(path)))) == os.path.normcase(os.path.realpath(source))
            assert path.is_file() and not path.is_symlink(), name
            raw = path.read_bytes()
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(raw), 0o644, 0
            archive.addfile(info, io.BytesIO(raw))
            files[name] = {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
    with temporary.open("r+b") as handle:
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, STAGE / "source.tar.gz")
    save(STAGE / "source-manifest.json", {"source_commit": commit, "files": files,
         "archive_sha256": digest(STAGE / "source.tar.gz")})
    update_private_sources(commit)
    probe = module(STAGE / "followup_probe.py")
    assert probe.COMMIT == commit
    protocol = json.loads((STAGE / "protocol.json").read_text())
    protocol.update(source_commit=commit, preparation_status="READY_ROOT_APPROVED",
                    execution_plan=probe.CONTRACT, performance=probe.CONTRACT,
                    cuda_test_selectors=selectors, cuda_expected_case_names=expected)
    assert protocol["financial"]["maximum_stage_usd"] == probe.CAP_USD
    save(STAGE / "protocol.json", protocol)
    save(STAGE / "protocol-contract.json", probe.CONTRACT)
    shutil.copyfile(args.source_controls, STAGE / "source-controls.xml")
    safety = '"""Exact pre-data source, science, resource and authorization gate."""\n'
    safety += "EXPECTED = " + pprint.pformat(protocol, width=95, sort_dicts=False) + "\n\n"
    safety += '''def validate_protocol(protocol, *, source_commit, stage_id):
    if (protocol != EXPECTED or source_commit != EXPECTED["source_commit"]
            or stage_id != EXPECTED["stage_id"]
            or protocol["preparation_status"] != "READY_ROOT_APPROVED"):
        raise ValueError("Frozen follow-up source/science/resource/budget changed")
    return {"source_commit": source_commit, "new_followup_study": True,
            "cuda_cells": len(EXPECTED["cuda_expected_case_names"])}
'''
    (STAGE / "launch_safety.py").write_text(safety, encoding="utf-8", newline="\n")
    # Preserve generic retention primitives; change only the pre-data source binding.
    raw = (OLD / "archive_audit.py").read_bytes().replace(
        b"f5670242e13b2b480a78e8fc1e3c797d6bb13800", commit.encode())
    (STAGE / "archive_audit.py").write_bytes(raw)
    shutil.copyfile(OLD / "audit_infrastructure.py", STAGE / "audit_infrastructure.py")
    save(STAGE / "source-build-proof.json", {"source_commit": commit, "branch": branch,
        "published_head": remote[0], "clean_source": True, "source_files": len(files),
        "source_archive_sha256": digest(STAGE / "source.tar.gz"), "unix": time.time(),
        "cuda_case_names": expected, "local_source_cases": len(cases), "rented": False})
    Console().print({"source_bound": commit, "source_files": len(files),
                     "cuda_cases": len(expected), "freeze": False, "rental": False})


def freeze():
    unpaid()
    sys.path.insert(0, str(STAGE))
    import controller

    protocol = json.loads((STAGE / "protocol.json").read_text())
    commit = protocol["source_commit"]
    assert re.fullmatch("[0-9a-f]{40}", commit)
    update_private_sources(commit, include_audit=True)
    probe = module(STAGE / "followup_probe.py")
    assert probe.COMMIT == commit and probe.CONTRACT == protocol["execution_plan"], (
        "Runner changed its scientific contract after source binding; rerun bind first")
    for name in ("followup_probe.py", "audit_followup.py", "archive_audit.py"):
        assert (STAGE / name).is_file() and PENDING not in (STAGE / name).read_text()
        assert commit in (STAGE / name).read_text()
    assert (STAGE / "ssh-key").is_file()
    names = set(controller.REQUIRED)
    names.update(path.name for path in STAGE.glob("*.py"))
    names.update(path.name for path in STAGE.glob("*.xml"))
    names.update(("ssh-key.pub", "key-control.json", "key-dacl-control.json",
                  "prior-budget-context.json", "historical-owned.json",
                  "software-lock-validation.json", "source-build-proof.json"))
    manifest = {"stage_id": protocol["stage_id"], "unix": time.time(),
                "retention_estimate_bytes": 1500000000, "raw_estimate_bytes": 12 * 2**30,
                "files": {name: {"bytes": (STAGE / name).stat().st_size,
                                  "sha256": digest(STAGE / name)} for name in sorted(names)}}
    save(STAGE / "launch-manifest.json", manifest)
    controller.freeze_check()
    save(STAGE / "offline-freeze-verification.json", {
        "manifest_sha256": digest(STAGE / "launch-manifest.json"), "unix": time.time(),
        "all_frozen_files_verified": True, "frozen_files": len(names),
        "remaining_task_cap_usd": protocol["financial"]["maximum_stage_usd"],
        "rental_started": False})
    Console().print({"freeze_verified": True, "files": len(names),
                     "manifest_sha256": digest(STAGE / "launch-manifest.json")})


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--freeze", action="store_true")
    parser.add_argument("--source-root", type=Path)
    parser.add_argument("--commit")
    parser.add_argument("--cuda-selectors", type=Path)
    parser.add_argument("--source-controls", type=Path)
    arguments = parser.parse_args()
    freeze() if arguments.freeze else bind(arguments)
