"""Read-only verification of report bytes, ZIP aliases and actual Git blobs."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

from rich.console import Console

PREP = Path(__file__).parent
ROOT = Path(r"C:\Users\esenb\.codex\worktrees\stream-memory-auto-20261023\soup-rnd-d2")
SOURCE_ROOT = Path(r"C:\Users\esenb\.codex\worktrees\expert-prefetch-20261028\soup-rnd-d2")
PREFIX = "benchmarks/expert-followup-20261029/"
REPORT = ROOT / PREFIX


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--revision")
    args = parser.parse_args()
    manifest = json.loads((REPORT / "evidence-manifest.json").read_text())
    for name, expected in manifest["report_files"].items():
        raw = (REPORT / name).read_bytes()
        assert len(raw) == expected["bytes"] and sha(raw) == expected["sha256"], name
    names = [path.name for path in REPORT.iterdir() if path.is_file()]
    for name in names:
        target = (args.revision or "") + ":" + PREFIX + name
        raw = subprocess.check_output(["git", "show", target], cwd=ROOT)
        assert raw == (REPORT / name).read_bytes(), "Actual Git blob differs: " + name
    packet = REPORT / "evidence.zip"
    assert sha(packet.read_bytes()) == manifest["packet"]["sha256"]
    assert packet.stat().st_size <= 5000 * 1024
    with zipfile.ZipFile(packet) as archive:
        aliases = json.loads(archive.read("aliases.json"))
        index = json.loads(archive.read(aliases["evidence-index.json"]))
        count = 0
        for name, row in index["files"].items():
            if row["publication"] == "exact_original_in_packet":
                raw = archive.read(aliases[name])
                assert len(raw) == row["bytes"] and sha(raw) == row["sha256"], name
                count += 1
    with zipfile.ZipFile(REPORT / "prototype.patch.zip") as archive:
        patch = archive.read("prototype.patch")
        assert len(patch) == manifest["portable_patch"]["bytes"]
        assert sha(patch) == manifest["portable_patch"]["sha256"]
        expected = subprocess.check_output([
            "git", "diff", "--no-ext-diff", "--no-color", "--binary",
            manifest["portable_patch"]["base_commit"], manifest["portable_patch"]["source_commit"]],
            cwd=SOURCE_ROOT)
        assert patch == expected
    result = {"status": "passed_exact_followup_publication_verification",
              "git_revision": args.revision or "index", "report_files": len(names),
              "restored_public_originals": count, "evidence_sha256": sha(packet.read_bytes()),
              "manifest_sha256": sha((REPORT / "evidence-manifest.json").read_bytes())}
    (PREP / "publication-verification.json").write_text(json.dumps(result, indent=2) + "\n")
    Console().print(result)


if __name__ == "__main__":
    main()
