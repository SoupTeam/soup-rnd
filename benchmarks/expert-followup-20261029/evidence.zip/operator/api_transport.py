"""Bounded private API transport: shared admission, read-only retries, single create."""

from __future__ import annotations

import http.client
import json
import math
import time
import urllib.error
import urllib.request
from contextlib import contextmanager
from contextvars import ContextVar
from email.utils import parsedate_to_datetime
from typing import Iterator

from api_rate_limit import SharedAdmission

READONLY_ATTEMPTS = 8
READONLY_BACKOFF = (1., 2., 4., 8., 16., 30., 30.)
CLEANUP_SCOPE: ContextVar[bool] = ContextVar("vast_cleanup_api_scope", default=False)
ADMISSION = SharedAdmission()


class ReadOnlyTransientError(RuntimeError):
    """Read-only provider failure; boot polling may resume while its deadline permits."""


class MutationRateLimitRefusalError(RuntimeError):
    """One mutating request was definitively refused; never retried by transport."""

    def __init__(self, message: str, retry_after_seconds: float):
        super().__init__(message)
        if not math.isfinite(retry_after_seconds) or retry_after_seconds < 0:
            raise ValueError("Invalid server mutation rate-limit delay")
        self.retry_after_seconds = retry_after_seconds


@contextmanager
def cleanup_priority() -> Iterator[None]:
    token = CLEANUP_SCOPE.set(True)
    try:
        yield
    finally:
        CLEANUP_SCOPE.reset(token)


def retry_after(headers, body: bytes) -> float:
    values = []
    header = headers.get("Retry-After") if headers is not None else None
    if header is not None:
        try:
            values.append(float(header))
        except (TypeError, ValueError):
            try:
                values.append(parsedate_to_datetime(header).timestamp() - time.time())
            except (TypeError, ValueError, OverflowError):
                pass
    try:
        values.append(float(json.loads(body).get("retry_after", 0)))
    except (ValueError, TypeError, AttributeError):
        pass
    return max([0.] + [value for value in values if math.isfinite(value) and value >= 0])


def request_json(request: urllib.request.Request, *, readonly: bool, secret: str,
                 deadline: float, cleanup: bool = False):
    attempts = READONLY_ATTEMPTS if readonly else 1
    last = "read-only provider operation did not complete"
    for attempt in range(attempts):
        if time.monotonic() >= deadline:
            if readonly:
                raise ReadOnlyTransientError("Read-only API operation deadline: " + last)
            raise TimeoutError("Mutating API operation deadline reached before its only attempt")
        try:
            ADMISSION.wait(cleanup=cleanup or CLEANUP_SCOPE.get(), deadline=deadline)
        except TimeoutError as error:
            if readonly:
                raise ReadOnlyTransientError("Read-only API admission deadline exceeded") from error
            raise
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            if readonly:
                raise ReadOnlyTransientError("Read-only API deadline reached after admission")
            raise TimeoutError("Mutating API deadline reached before its only attempt")
        delay = 0.
        try:
            with urllib.request.urlopen(request, timeout=min(30., remaining)) as response:
                return json.load(response)
        except urllib.error.HTTPError as error:
            body = error.read()
            decoded = body.decode(errors="replace")
            message = (decoded.replace(secret, "[redacted]") if secret else decoded)[:500]
            last = f"Vast HTTP status {error.code}: {message}"
            transient = error.code in (429, 500, 502, 503, 504)
            if not readonly and error.code == 429:
                raise MutationRateLimitRefusalError(
                    last, retry_after(error.headers, body)) from None
            if not readonly or not transient:
                raise RuntimeError(last) from None
            if attempt == attempts - 1:
                raise ReadOnlyTransientError(last) from None
            delay = max(READONLY_BACKOFF[attempt], retry_after(error.headers, body))
        except (TimeoutError, urllib.error.URLError, http.client.IncompleteRead,
                ConnectionError, json.JSONDecodeError) as error:
            if not readonly:
                raise
            last = type(error).__name__
            if attempt == attempts - 1:
                raise ReadOnlyTransientError("Read-only transport exhausted: " + last) from None
            delay = READONLY_BACKOFF[attempt]
        # No file mutex is held while waiting or while an HTTP request is in flight.
        if time.monotonic() + delay >= deadline:
            raise ReadOnlyTransientError("Read-only backoff exceeds operation deadline: " + last)
        time.sleep(delay)
    raise AssertionError("API attempt loop exhausted without an explicit verdict")
