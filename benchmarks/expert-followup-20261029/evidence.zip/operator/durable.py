"""Crash-resistant mutable operator receipts; never truncates the prior target."""

from __future__ import annotations

import json
import os
import time
import uuid
from pathlib import Path


def durable_json(path: Path, value) -> None:
    path = Path(path)
    temporary = path.with_name(path.name + "." + uuid.uuid4().hex + ".incoming")
    try:
        with temporary.open("x", encoding="utf-8", newline="\n") as sink:
            json.dump(value, sink, indent=2, allow_nan=False)
            sink.write("\n")
            sink.flush()
            os.fsync(sink.fileno())
        for attempt in range(6):
            try:
                os.replace(temporary, path)
                break
            except PermissionError:
                if attempt == 5:
                    raise
                time.sleep(.05)
    finally:
        temporary.unlink(missing_ok=True)
