"""CPU controls for the follow-up protocol, budget arms and held-out statistics."""

import contextlib
import copy
import json
import sys
from types import ModuleType, SimpleNamespace

import pytest

import followup_probe as probe


def exploration(times):
    return [{"policy": name, "worker": {"result": {"timing": {
        "update_seconds": [times[name]] * 6}}}} for name in probe.CONTRACT["exploration_order"]]


@pytest.mark.parametrize("winner", [None, "hostpacked", "prefetch_after", "usage2", "larger",
                                  "all"])
def test_selection_uses_only_distinct_positive_fresh_baseline(winner):
    times = dict.fromkeys(probe.POLICIES, 11.)
    times[probe.BASELINE] = 10.
    if winner:
        times[winner] = 8.
    assert probe.select_candidate(exploration(times))["candidate"] == winner


@pytest.mark.parametrize("bad", [float("nan"), float("inf"), 0., -1.])
def test_selection_refuses_unusable_times(bad):
    times = dict.fromkeys(probe.POLICIES, 10.)
    times["all"] = bad
    with pytest.raises(ValueError):
        probe.select_candidate(exploration(times))


def test_selection_refuses_changed_policy_order():
    rows = exploration(dict.fromkeys(probe.POLICIES, 10.))
    rows.reverse()
    with pytest.raises(ValueError):
        probe.select_candidate(rows)


def spec():
    return {"git_head": "f" * 40, "dtype": "bfloat16", "quant": "nf4", "seq_len": 512,
            "batch_size": 1, "accumulation": 2, "accuracy_updates": 2, "warmup_updates": 2,
            "timed_updates": 6, "rounds": 4, "lora_r": 4, "lora_alpha": 8,
            "host_cache_policy": "static", "host_cache_bytes": 8 * probe.GIB,
            "device_cache_bytes": 2 * probe.GIB, "device_cap_bytes": 8 * probe.GIB,
            "max_host_bytes": 32 * probe.GIB, "lora_targets": ["q_proj", "kv_b_proj", "o_proj"]}


def protocol():
    return {"source_commit": "f" * 40, "execution_plan": copy.deepcopy(probe.CONTRACT),
            "preparation_status": "READY_ROOT_APPROVED", "financial": {
                "maximum_stage_usd": probe.CAP_USD, "maximum_seconds": 9000}}


@pytest.mark.parametrize("policy", probe.POLICIES)
def test_exact_only_budget_variable_arms_pass_shared_scientific_contract(monkeypatch, policy):
    monkeypatch.setattr(probe, "COMMIT", "f" * 40)
    base = spec()
    actual = probe.arm_spec(base, policy)
    probe.validate_contract(actual, protocol(), policy)
    assert {key for key in actual if actual[key] != base[key]} <= {"device_cache_bytes"}
    assert base["device_cache_bytes"] == 2 * probe.GIB


@pytest.mark.parametrize("field,value", [("dtype", "float16"), ("seq_len", 256),
    ("accuracy_updates", 1), ("accumulation", 1), ("host_cache_bytes", 7 * probe.GIB),
    ("device_cap_bytes", 9 * probe.GIB)])
def test_scientific_drift_is_not_normalized_away(monkeypatch, field, value):
    monkeypatch.setattr(probe, "COMMIT", "f" * 40)
    actual = probe.arm_spec(spec(), "larger")
    actual[field] = value
    with pytest.raises(ValueError):
        probe.validate_contract(actual, protocol(), "larger")


@pytest.mark.parametrize("mutation", ["cap", "deadline", "pending", "rtol", "GPU"])
def test_authorization_and_original_numerical_contract_fail_closed(monkeypatch, mutation):
    monkeypatch.setattr(probe, "COMMIT", "f" * 40)
    actual, declared = spec(), protocol()
    if mutation == "cap":
        declared["financial"]["maximum_stage_usd"] = 5.
    elif mutation == "deadline":
        declared["financial"]["maximum_seconds"] += 1
    elif mutation == "pending":
        declared["preparation_status"] = "SOURCE_PENDING"
    elif mutation == "rtol":
        declared["execution_plan"]["rtol"] = .02
    else:
        actual["device_cache_bytes"] = probe.BIG_GPU_BYTES
    with pytest.raises(ValueError):
        probe.validate_contract(actual, declared)


def raw_cache(policy):
    budget = probe.POLICIES[policy]["gpu"]
    before = {"logical_fetches": 0, "storage_reads": 0, "storage_bytes_read": 0,
              "materializations": 0, "host_cache_policy": "static",
              "host": {"budget_bytes": 8 * probe.GIB, "payload_bytes": 1234, "hits": 0},
              "device": {"budget_bytes": budget, "payload_bytes": 1234, "hits": 0},
              "transfer": {"mode": probe.POLICIES[policy]["mode"], "h2d_copies": 0,
                           "pinned_host_bytes": 1024, "device_staging_bytes": 1024,
                           "layout_builds": 0, "host_copy_calls": 0}}
    if probe.POLICIES[policy]["host_packing"]:
        before["host_prepacked"] = True
    if probe.POLICIES[policy]["placement"]:
        before["device_placement"] = {"policy": "profile_allowlist", "keys": 2}
    after = copy.deepcopy(before)
    after.update(logical_fetches=100, storage_reads=50, storage_bytes_read=5000,
                 materializations=90)
    after["host"]["hits"], after["device"]["hits"] = 40, 10
    after["transfer"]["h2d_copies"] = 90
    after["transfer"]["layout_builds"] = 50 if probe.POLICIES[policy]["host_packing"] else 90
    after["transfer"]["host_copy_calls"] = 440 if probe.POLICIES[policy]["host_packing"] else 720
    return {"setup": {"cache_plan": {"host_cache_bytes": 8 * probe.GIB,
            "device_cache_bytes": budget, "host_cache_policy": "static"}},
            "timing": {"runtime_before": {"expert_cache": before},
                       "runtime_after": {"expert_cache": after}}}


@pytest.mark.parametrize("policy", probe.POLICIES)
def test_actual_per_arm_budget_and_one_transfer_accounting(policy):
    assert probe.cache_delta(raw_cache(policy), "timing", policy) == {
        "logical_fetches": 100, "storage_reads": 50, "storage_bytes_read": 5000,
        "materializations": 90, "host_hits": 40, "device_hits": 10}


@pytest.mark.parametrize("mutation", ["budget", "logical", "H2D", "mode", "staging",
                                     "hostflag", "planflag", "observer", "fastpath"])
def test_cache_accounting_rejects_fake_work_or_overbudget(mutation):
    raw = raw_cache("all")
    after = raw["timing"]["runtime_after"]["expert_cache"]
    if mutation == "budget":
        after["device"]["budget_bytes"] = 2 * probe.GIB
    elif mutation == "logical":
        after["logical_fetches"] += 1
    elif mutation == "H2D":
        after["transfer"]["h2d_copies"] -= 1
    elif mutation == "mode":
        after["transfer"]["mode"] = "packed"
    elif mutation == "staging":
        after["transfer"]["device_staging_bytes"] = 33 * 2**20
    elif mutation == "hostflag":
        after["host_prepacked"] = False
    elif mutation == "planflag":
        del after["device_placement"]
    elif mutation == "observer":
        after["usage_profile"] = {"entries": 3}
    else:
        after["transfer"]["layout_builds"] = 90
    with pytest.raises(ValueError):
        probe.cache_delta(raw, "timing", "all")


def confirmation(ratio=.8):
    rows = []
    pair = ("baseline", "all")
    for number, order in enumerate((pair, pair[::-1]) * 2):
        for position, policy in enumerate(order):
            raw = {"pid": len(rows) + 1, "warmup": {"losses": [1.] * 2},
                   "timing": {"losses": [1.] * 6, "update_seconds": [
                       10. if policy == "baseline" else ratio * 10] * 6}}
            rows.append({"round": number, "position": position, "policy": policy,
                         "worker": {"result": raw}})
    return rows


def comparators():
    from benchmarks.harness import expert_cache_dispatch_qualification as q
    from benchmarks.harness import two_read_cache_common as common

    return q, common


@pytest.mark.parametrize("mutation", [None, "warmup", "timing", "nonfinite"])
def test_all_exploratory_recorded_losses_keep_original_gate(mutation):
    rows = exploration(dict.fromkeys(probe.POLICIES, 10.))
    for row in rows:
        row["worker"]["result"]["warmup"] = {"losses": [1.] * 2}
        row["worker"]["result"]["timing"]["losses"] = [1.] * 6
    if mutation:
        phase = "warmup" if mutation == "warmup" else "timing"
        rows[0]["worker"]["result"][phase]["losses"][0] = (
            float("nan") if mutation == "nonfinite" else 1.001)
        with pytest.raises(ValueError):
            probe.exploration_losses(rows, *comparators())
    else:
        checks = probe.exploration_losses(rows, *comparators())
        assert set(checks) == set(probe.POLICIES)
        assert all(check["warmup"]["passed"] and check["timing"]["passed"]
                   for check in checks.values())


def test_four_new_pairs_reproduce_original_practical_gate():
    result = probe.confirm(confirmation(), "all", *comparators())
    assert result["step_time_reduction_percent"] == pytest.approx(20.)
    assert result["passes_practical_2_percent_gate"] is True
    assert result["selection_samples_excluded"] is True
    assert not probe.confirm(confirmation(.99), "all", *comparators())[
        "passes_practical_2_percent_gate"]


@pytest.mark.parametrize("mutation", ["missing", "order", "pid", "loss"])
def test_confirmation_refuses_incomplete_reused_or_inaccurate_workers(mutation):
    rows = confirmation()
    if mutation == "missing":
        rows.pop()
    elif mutation == "order":
        rows[0], rows[1] = rows[1], rows[0]
    elif mutation == "pid":
        rows[1]["worker"]["result"]["pid"] = 1
    else:
        rows[1]["worker"]["result"]["timing"]["losses"][0] = 1.001
    with pytest.raises(ValueError):
        probe.confirm(rows, "all", *comparators())


def profile_fixture(tmp_path, monkeypatch):
    from soup_cli.utils.expert_placement import ExpertUsageProfile

    monkeypatch.setattr(probe, "COMMIT", "f" * 40)
    base = tmp_path / "spec.json"
    probe.save(base, spec())
    profile = ExpertUsageProfile()
    records = [{"key": ["/data/layer0", 0], "requests": 9, "transfer_bytes": 2,
                "dense_bytes": 4},
               {"key": ["/data/layer1", 0], "requests": 3, "transfer_bytes": 2,
                "dense_bytes": 4}]
    for row in records:
        profile.record_request(tuple(row["key"]), count=row["requests"],
                               transfer_bytes=row["transfer_bytes"], dense_bytes=row["dense_bytes"])
    plans = {}
    for budget in (2 * probe.GIB, probe.BIG_GPU_BYTES):
        plan = profile.plan(budget)
        plans[str(budget)] = {name: getattr(plan, name) for name in (
            "keys", "payload_bytes", "budget_bytes", "candidate_count", "total_requests",
            "selected_requests", "saved_transfer_bytes_proxy", "policy")}
    data = {"status": "passed_usage_profile_and_frozen_plans", "source_commit": probe.COMMIT,
            "base_spec_sha256": probe.digest(base), "probe_sha256": probe.digest(probe.__file__),
            "observed_updates": 2, "observed_requests": 12, "records": records, "plans": plans}
    path = tmp_path / "usage-profile.json"
    probe.save(path, data)
    return base, path


def test_portable_plan_reproduces_from_recorded_real_request_counts(tmp_path, monkeypatch):
    base, path = profile_fixture(tmp_path, monkeypatch)
    assert probe.plan_keys(path, "all", base) == (("/data/layer0", 0), ("/data/layer1", 0))


@pytest.mark.parametrize("mutation", ["requests", "keys", "payload", "source", "base"])
def test_frozen_plan_tampering_is_rejected(tmp_path, monkeypatch, mutation):
    base, path = profile_fixture(tmp_path, monkeypatch)
    data = json.loads(path.read_text())
    if mutation == "requests":
        data["records"][0]["requests"] += 1
    elif mutation == "keys":
        data["plans"][str(probe.BIG_GPU_BYTES)]["keys"].reverse()
    elif mutation == "payload":
        data["plans"][str(probe.BIG_GPU_BYTES)]["payload_bytes"] = 9
    elif mutation == "source":
        data["source_commit"] = "e" * 40
    else:
        data["base_spec_sha256"] = "0" * 64
    probe.save(path, data)
    with pytest.raises((ValueError, TypeError)):
        probe.plan_keys(path, "all", base)


@pytest.mark.parametrize("failure", [False, True])
def test_cpu_fixture_diagnostic_observes_only_two_warmups_and_restores_patches(
        tmp_path, monkeypatch, failure):
    """A CPU call-order control, explicitly not actual CUDA/profiler evidence."""
    import torch
    from soup_cli.utils import expert_stream, expert_transfer

    monkeypatch.setattr(probe, "COMMIT", "f" * 40)
    monkeypatch.setenv("CUDA_LAUNCH_BLOCKING", "0")
    monkeypatch.setattr(torch.cuda.memory, "get_allocator_backend", lambda: "native")
    bnb = ModuleType("bitsandbytes")
    bnb.functional = ModuleType("bitsandbytes.functional")
    bnb.functional.dequantize_4bit = lambda *_args: None
    monkeypatch.setitem(sys.modules, "bitsandbytes", bnb)
    monkeypatch.setitem(sys.modules, "bitsandbytes.functional", bnb.functional)

    class Reader:
        def read_host(self):
            return None

    class Transfer:
        def stage(self):
            expert_transfer.packing_layout({})

    class Fetcher:
        def __init__(self):
            self.logical = 0
            self.observer = None
            self.transfer_mode = "sync"
            self._host_prepacked = False
            self._device_allowlist = None
            self._usage_profile = None
            self._device_cache = SimpleNamespace(stats=lambda: {"budget_bytes": 2 * probe.GIB})

        def configure_transfer(self, mode):
            self.transfer_mode = mode

        def configure_host_packing(self, enabled):
            assert enabled is False

        def configure_placement(self, keys):
            assert keys is None

        def configure_usage_profile(self, observer):
            self.observer = observer
            self._usage_profile = observer

        def cache_stats(self):
            return {"logical_fetches": self.logical}

        def fetch(self):
            self.logical += 1
            if self.observer is not None:
                self.observer.record_request(("/data/layer0", 0), transfer_bytes=2, dense_bytes=4)
            Reader().read_host()
            Transfer().stage()
            bnb.functional.dequantize_4bit(None)

    monkeypatch.setattr(expert_stream, "ExpertFetcher", Fetcher)
    monkeypatch.setattr(expert_stream, "ExpertShardReader", Reader)
    monkeypatch.setattr(expert_transfer, "PackedExpertTransfer", Transfer)
    monkeypatch.setattr(expert_transfer, "packing_layout", lambda *_args: None)
    runtime = SimpleNamespace(expert_fetcher=Fetcher(), close=lambda: None)
    worker = SimpleNamespace(_build=lambda *_args: (None, runtime, {}))

    def updates(_model, actual, _optimizer, _batches, _recipe, count, **_kwargs):
        for _index in range(count):
            actual.expert_fetcher.fetch()
        return {"updates_complete": count, "complete": True}

    worker._timed_updates = updates
    original_build, original_fetch = worker._build, Fetcher.fetch

    @contextlib.contextmanager
    def dispatch(*_args):
        yield {"cpu_fixture": True}

    qualified = SimpleNamespace(dispatch=dispatch,
        validate_dispatch_evidence=lambda *_args: None)
    monkeypatch.setattr(probe, "project", lambda _root: (qualified,
        (None, worker, None, None, {"source_commit": probe.COMMIT})))

    def run_profile(args, actual_worker):
        model, actual, _plan = actual_worker._build({}, "two_read_cache")
        actual_worker._timed_updates(model, actual, None, None, {}, 2)
        if failure:
            raise ValueError("deliberate CPU diagnostic fixture failure")
        actual_worker._timed_updates(model, actual, None, None, {}, 1)
        for _index in range(3):
            actual.expert_fetcher.fetch()
        probe.save(args.out / "profile-result.json", {"status": "passed"})
        (args.out / "trace.json.gz").write_bytes(b"CPU fixture, not an actual trace")

    helper = SimpleNamespace(run_profile=run_profile,
                             validate_resource_boundary=lambda *_args: None)
    monkeypatch.setattr(probe, "load_private", lambda _name: helper)
    source = tmp_path / "source"
    module = source / "src/soup_cli/utils/expert_placement.py"
    module.parent.mkdir(parents=True)
    module.write_text("CPU fixture only\n")
    inputs = tmp_path / "inputs.pt"
    inputs.write_bytes(b"CPU fixture input hash only")
    recipe = tmp_path / "spec.json"
    probe.save(recipe, dict(spec(), training_data_path=str(inputs)))
    declared = tmp_path / "protocol.json"
    probe.save(declared, protocol())
    out = tmp_path / "diagnostic"
    out.mkdir()
    args = SimpleNamespace(spec=recipe, protocol=declared, source_root=source, out=out)
    assert probe.diagnostic_main(args) == (1 if failure else 0)
    assert worker._build is original_build and Fetcher.fetch is original_fetch
    receipt = probe.read(out / "diagnostic-envelope.json")
    assert receipt["actual_mode"] == "packed"
    assert receipt["status"] == ("failed" if failure else "passed")
    plan = probe.read(out / "usage-profile.json")
    assert plan["observed_updates"] == 2 and plan["observed_requests"] == 2
    assert plan["records"][0]["requests"] == 2
    if not failure:
        assert runtime.expert_fetcher.logical == 6
        spans = probe.read(out / "cpu-host-spans.json")
        assert spans["spans"]["profile_update/fetch"]["calls"] == 3
