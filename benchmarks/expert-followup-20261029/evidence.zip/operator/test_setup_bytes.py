"""Shell entrypoint bytes must survive exact transport onto Linux."""

from pathlib import Path


def test_linux_shell_entrypoint_uses_lf_bytes():
    raw = (Path(__file__).parent / "setup.sh").read_bytes()
    assert raw.startswith(b"#!/bin/bash\n")
    assert b"\r" not in raw
    assert b"\x00" not in raw
    assert raw.endswith(b"\n")
