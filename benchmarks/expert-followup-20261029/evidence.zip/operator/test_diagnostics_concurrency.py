"""Concurrent route diagnostics must not suppress a healthy SSH probe."""

import json
import threading
import time
from concurrent.futures import ThreadPoolExecutor

import diagnostics


def test_operation_records_serialize_concurrent_windows_target_replacements(tmp_path, monkeypatch):
    monkeypatch.setattr(diagnostics, "ROOT", tmp_path)
    original = diagnostics._save
    counters = {"active": 0, "peak": 0}
    guard = threading.Lock()

    def slow_save(path, value):
        with guard:
            counters["active"] += 1
            counters["peak"] = max(counters["peak"], counters["active"])
        try:
            time.sleep(.002)
            original(path, value)
        finally:
            with guard:
                counters["active"] -= 1

    monkeypatch.setattr(diagnostics, "_save", slow_save)

    def record(index):
        return diagnostics.record("route-probe", "started", str(index), route=index)

    with ThreadPoolExecutor(max_workers=8) as executor:
        records = list(executor.map(record, range(32)))
    assert counters == {"active": 0, "peak": 1}
    assert len(records) == 32
    assert len(list((tmp_path / "operation-events").glob("*.json"))) == 32
    assert json.loads((tmp_path / "operation-latest.json").read_text()) in records
    for row in records:
        path = tmp_path / "operation-events" / (row["id"] + "-started.json")
        assert json.loads(path.read_text()) == row
