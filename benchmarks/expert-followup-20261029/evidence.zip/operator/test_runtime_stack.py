"""CPU-only adversarial checks for the registered CUDA13 software admission."""

import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

import pytest
import runtime_stack

ROOT = Path(__file__).parent
COHORT = json.loads((ROOT / "software-cohort.json").read_text())


@pytest.fixture(autouse=True)
def no_foreign_override(monkeypatch):
    monkeypatch.delenv("BNB_CUDA_VERSION", raising=False)


def test_exact_official_wheel_hashes_constraints_and_transitive_resolution():
    lock_path = ROOT / "runtime-wheel-lock.json"
    lock = json.loads(lock_path.read_text())
    assert hashlib.sha256(lock_path.read_bytes()).hexdigest() == COHORT["wheel_lock_sha256"]
    assert {name: row["version"] for name, row in lock["wheels"].items()} == COHORT[
        "required_versions"]
    lines = set((ROOT / "runtime-wheel-requirements.txt").read_text().splitlines())
    assert len(lines) == len(lock["wheels"]) == 20
    for name, row in lock["wheels"].items():
        assert row["url"] + "#sha256=" + row["sha256"] in lines
        assert row["url"].startswith(("https://files.pythonhosted.org/",
                                      "https://download-r2.pytorch.org/"))
        assert len(row["sha256"]) == 64
        assert name + "==" + row["version"] in (ROOT / "constraints.txt").read_text().splitlines()
    validation = json.loads((ROOT / "software-lock-validation.json").read_text())
    assert validation["status"] == "passed_official_dependency_pin_resolution"
    assert validation["wheel_lock_sha256"] == COHORT["wheel_lock_sha256"]
    assert len(validation["active_requires_dist_checks"]) == 34
    assert validation["errors"] == []


def test_exact_versions_pass():
    runtime_stack.validate_versions(COHORT, COHORT["required_versions"],
                                    list(COHORT["required_versions"]))


@pytest.mark.parametrize("name,bad", [("torch", "2.8.0+cu128"), ("triton", "3.4.0"),
    ("nvidia-cuda-cupti", "12.8.90"), ("bitsandbytes", "0.50.1"),
    ("cuda-bindings", "13.0.2")])
def test_mixed_or_unregistered_versions_rejected(name, bad):
    actual = dict(COHORT["required_versions"], **{name: bad})
    with pytest.raises(RuntimeError, match="versions differ"):
        runtime_stack.validate_versions(COHORT, actual, list(actual))


def test_old_cuda12_distribution_rejected_even_if_new_pins_exist():
    with pytest.raises(RuntimeError, match="Legacy CUDA12"):
        runtime_stack.validate_versions(COHORT, COHORT["required_versions"],
                                       ["nvidia-cuda-cupti-cu12"])


def test_old_bnb_override_rejected(monkeypatch):
    monkeypatch.setenv("BNB_CUDA_VERSION", "128")
    with pytest.raises(RuntimeError, match="foreign bitsandbytes"):
        runtime_stack.validate_versions(COHORT, COHORT["required_versions"], [])


def modules(tmp_path):
    pkg = tmp_path / "bitsandbytes"
    pkg.mkdir()
    (pkg / "__init__.py").write_text("# fake only; no binary executed\n")
    library = pkg / "libbitsandbytes_cuda130.so"
    library.write_bytes(b"fake admission-control library bytes")
    torch = SimpleNamespace(__version__="2.10.0+cu130", __file__=str(tmp_path / "torch.py"),
        version=SimpleNamespace(cuda="13.0"),
        cuda=SimpleNamespace(is_available=lambda: True, device_count=lambda: 1))
    bnb = SimpleNamespace(__version__="0.50.2", __file__=str(pkg / "__init__.py"))
    extension = SimpleNamespace(lib=SimpleNamespace(compiled_with_cuda=True,
                                                   _lib=SimpleNamespace(_name=str(library))))
    return torch, bnb, extension, library


def test_actual_native_backend_name_and_containment_recorded(tmp_path):
    torch, bnb, extension, library = modules(tmp_path)
    result = runtime_stack.validate_loaded(COHORT, torch, bnb, extension)
    assert result["bitsandbytes_actual_library_sha256"] == hashlib.sha256(
        library.read_bytes()).hexdigest()
    assert result["torch_cuda_version"] == "13.0"


@pytest.mark.parametrize("fault", ["torch", "cuda12", "no_device", "two_devices", "bnb",
                                  "cpu_backend", "cuda128_backend", "foreign_path"])
def test_actual_loaded_backend_cannot_silently_fallback(tmp_path, fault):
    torch, bnb, extension, library = modules(tmp_path)
    if fault == "torch":
        torch.__version__ = "2.8.0+cu128"
    elif fault == "cuda12":
        torch.version.cuda = "12.8"
    elif fault == "no_device":
        torch.cuda.is_available = lambda: False
    elif fault == "two_devices":
        torch.cuda.device_count = lambda: 2
    elif fault == "bnb":
        bnb.__version__ = "0.50.1"
    elif fault == "cpu_backend":
        extension.lib.compiled_with_cuda = False
    else:
        changed = (library.with_name("libbitsandbytes_cuda128.so") if fault == "cuda128_backend"
                   else tmp_path / library.name)
        changed.write_bytes(library.read_bytes())
        extension.lib._lib._name = str(changed)
    with pytest.raises(RuntimeError):
        runtime_stack.validate_loaded(COHORT, torch, bnb, extension)


def test_failed_version_admission_preserves_receipt_before_any_torch_import(tmp_path, monkeypatch):
    monkeypatch.setattr(runtime_stack.metadata, "version", lambda name:
                        "2.8.0+cu128" if name == "torch" else COHORT["required_versions"][name])
    monkeypatch.setattr(runtime_stack.metadata, "distributions", lambda: [])
    output = tmp_path / "failed.json"
    code = runtime_stack.main(["--cohort", str(ROOT / "software-cohort.json"),
                              "--wheel-lock", str(ROOT / "runtime-wheel-lock.json"),
                              "--out", str(output)])
    assert code == 1
    proof = json.loads(output.read_text())
    assert proof["status"] == "failed" and proof["actual_versions"]["torch"] == "2.8.0+cu128"
    assert "versions differ" in proof["error"]
