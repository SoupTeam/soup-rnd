"""Bounded authenticated SSH ranges, resumable parts, then a frozen whole-file SHA."""

from __future__ import annotations

import hashlib
import io
import json
import os
import re
import shlex
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

CHUNK_BYTES = 4 * 2**20
CONNECTIONS = 4


def file_sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as source:
        for block in iter(lambda: source.read(CHUNK_BYTES), b""):
            digest.update(block)
    return digest.hexdigest()


def atomic_json(path, value):
    target = Path(path)
    temporary = target.with_name(target.name + ".incoming")
    if temporary.is_symlink() or target.is_symlink():
        raise ValueError("Range metadata may not be a symlink")
    temporary.write_text(json.dumps(value, sort_keys=True, allow_nan=False) + "\n")
    os.replace(temporary, target)


def ssh_reader(stream):
    """Return exact payload only after checking the server's range hash and length."""
    def read(remote, offset, size, timeout):
        program = (
            "import hashlib,os,sys; f=open(" + repr(remote) + ",'rb'); "
            f"f.seek({offset}); data=f.read({size}); assert len(data)=={size}; "
            "sys.stdout.buffer.write(hashlib.sha256(data).hexdigest().encode()+b'\\n'+data)"
        )
        sink = io.BytesIO()
        count = stream("python3 -c " + shlex.quote(program), sink, timeout=timeout)
        response = sink.getvalue()
        if count != size + 65 or len(response) != size + 65 or response[64:65] != b"\n":
            raise EOFError("SSH range response has incomplete or extra bytes")
        expected, payload = response[:64].decode("ascii"), response[65:]
        if not re.fullmatch("[0-9a-f]{64}", expected) or hashlib.sha256(payload).hexdigest() != expected:
            raise ValueError("SSH range hash mismatch")
        return payload
    return read


def download(remote, target, total, expected, *, reader, remaining, refresh,
             timeout=600, progress=lambda _row: None):
    """Use the same four-range route for the synthetic probe and the final export."""
    if type(total) is not int or total <= 0 or not re.fullmatch("[0-9a-f]{64}", expected):
        raise ValueError("Invalid frozen artifact byte/hash identity")
    target = Path(target)
    if target.is_symlink():
        raise ValueError("Range target may not be a symlink")
    if target.exists():
        if target.stat().st_size == total and file_sha(target) == expected:
            return {"bytes": total, "sha256": expected, "reused_verified": True}
        raise ValueError("Existing destination is not the declared artifact")
    target.parent.mkdir(parents=True, exist_ok=True)
    parts = target.with_name(target.name + ".ranges-" + expected[:12])
    parts.mkdir(exist_ok=True)
    identity = {"remote": remote, "bytes": total, "sha256": expected, "range_bytes": CHUNK_BYTES}
    index = parts / "identity.json"
    if index.exists() and json.loads(index.read_text()) != identity:
        raise ValueError("Existing range identity differs from the frozen artifact")
    atomic_json(index, identity)
    began = time.monotonic()
    count = (total + CHUNK_BYTES - 1) // CHUNK_BYTES

    def one(number):
        offset = number * CHUNK_BYTES
        size = min(CHUNK_BYTES, total - offset)
        path, metadata = parts / f"{number:06d}.part", parts / f"{number:06d}.json"
        if path.is_symlink() or metadata.is_symlink():
            raise ValueError("Range parts may not be symlinks")
        if path.exists() and metadata.exists():
            saved = json.loads(metadata.read_text())
            if (saved.get("bytes") == size and path.stat().st_size == size
                    and saved.get("sha256") == file_sha(path)):
                return size, True
        for attempt in range(3):
            allowance = min(timeout - (time.monotonic() - began), remaining() - 180)
            if allowance <= 0:
                raise TimeoutError("Range transfer reached its reserved financial/time boundary")
            try:
                payload = reader(remote, offset, size, max(1, min(90, int(allowance))))
                if not isinstance(payload, bytes) or len(payload) != size:
                    raise EOFError("Range reader returned a short or oversized payload")
                temporary = path.with_suffix(".incoming")
                if temporary.is_symlink():
                    raise ValueError("Range temporary may not be a symlink")
                with temporary.open("wb") as output:
                    output.write(payload)
                    output.flush()
                    os.fsync(output.fileno())
                os.replace(temporary, path)
                atomic_json(metadata, {"bytes": size, "sha256": hashlib.sha256(payload).hexdigest()})
                return size, False
            except (OSError, EOFError, RuntimeError, ValueError):
                if attempt == 2:
                    raise
                if remaining() <= 185:
                    raise TimeoutError("Range retry would consume the cleanup reserve") from None
                time.sleep(2)
        raise RuntimeError("Range retries did not finish")

    complete = reused = 0
    last_guard = 0.0
    with ThreadPoolExecutor(max_workers=CONNECTIONS) as pool:
        futures = [pool.submit(one, number) for number in range(count)]
        for future in as_completed(futures):
            size, was_reused = future.result()
            complete += size
            reused += size if was_reused else 0
            if time.monotonic() - last_guard >= 20:
                refresh()
                last_guard = time.monotonic()
            progress({"range_bytes_complete": complete, "total_bytes": total,
                      "reused_bytes": reused, "seconds": time.monotonic() - began})
    temporary = target.with_name(target.name + ".assemble-incoming")
    if temporary.is_symlink():
        raise ValueError("Archive assembly target may not be a symlink")
    digest = hashlib.sha256()
    with temporary.open("wb") as output:
        for number in range(count):
            data = (parts / f"{number:06d}.part").read_bytes()
            digest.update(data)
            output.write(data)
        output.flush()
        os.fsync(output.fileno())
    if temporary.stat().st_size != total or digest.hexdigest() != expected:
        raise ValueError("Complete range reconstruction differs from the frozen archive SHA256")
    os.replace(temporary, target)
    return {"bytes": total, "sha256": expected, "seconds": time.monotonic() - began,
            "ranges": count, "range_bytes": CHUNK_BYTES, "concurrent_connections": CONNECTIONS,
            "reused_bytes": reused, "downloaded_bytes": total - reused,
            "whole_archive_verified": True, "per_range_hashes_verified": True,
            "route": "authenticated bounded SSH ranges from first byte"}
