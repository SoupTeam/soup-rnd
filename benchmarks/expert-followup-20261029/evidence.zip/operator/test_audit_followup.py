"""Bounded negative controls for independent pre-data scientific gate replay."""

import copy

import pytest

import audit_followup as audit


def launch_fixture(monkeypatch):
    monkeypatch.setattr(audit, "SOURCE", "a" * 40)
    execution = {"policies": copy.deepcopy(audit.POLICIES), "exploration_order": audit.ORDER[:],
        "accuracy_order": list(audit.POLICIES), "accuracy_updates": 2, "accumulation": 2,
        "warmup_updates": 2, "timed_updates": 6, "confirmation_pairs": 4,
        "bootstrap_samples": 5000, "bootstrap_seed": 29, "practical_lower_bound_percent": 2.,
        "rtol": .01, "atol": 1e-5, "finite": True, "three_decimal_losses": True,
        "maximum_slot_bytes": 16 * 2**20, "slots": 2, "cuda_allocator_backend": "native",
        "cuda_launch_blocking": "0", "confirmation_order": "AB_BA_AB_BA",
        "old_timing_denominator_allowed": False,
        "all_features": {"two_read": True, "grouped_expert_routes": True,
                         "host_cache_bytes": 8 * audit.GIB, "host_cache_policy": "static"},
        "diagnostic": {"baseline_mode": "packed", "usage_observed_warmup_updates": 2,
            "context_updates": 1, "profile_updates": 1,
            "plans_gpu_bytes": [2 * audit.GIB, audit.BIG_GPU_BYTES],
            "maximum_profile_entries": 65536,
            "profile_is_timing_denominator": False,
            "cuda_window": {"phase": "forward", "microbatch": 0,
                            "skip_fetches": 1024, "fetches": 16}}}
    protocol = {"source_commit": audit.SOURCE, "preparation_status": "READY_ROOT_APPROVED",
                "financial": {"maximum_stage_usd": audit.CAP_USD, "maximum_seconds": 9000},
                "execution_plan": execution}
    rental = {"maximum_usd": audit.CAP_USD, "maximum_seconds": 9000, "created_unix": 20}
    freeze = {"manifest_sha256": "b" * 64, "unix": 19}
    return protocol, rental, freeze


def test_exact_source_original_gates_and_remaining_budget_pass(monkeypatch):
    values = launch_fixture(monkeypatch)
    audit.validate_launch(*values, "b" * 64)


@pytest.mark.parametrize("change", ["source", "cap", "deadline", "freeze", "after_rental",
                                   "precision", "bootstrap", "arm_budget"])
def test_source_budget_and_predata_science_drift_are_rejected(monkeypatch, change):
    protocol, rental, freeze = launch_fixture(monkeypatch)
    if change == "source":
        protocol["source_commit"] = "c" * 40
    elif change == "cap":
        protocol["financial"]["maximum_stage_usd"] = rental["maximum_usd"] = 5.
    elif change == "deadline":
        rental["maximum_seconds"] = 10800
    elif change == "freeze":
        freeze["manifest_sha256"] = "d" * 64
    elif change == "after_rental":
        freeze["unix"] = 21
    elif change == "precision":
        protocol["execution_plan"]["rtol"] = .1
    elif change == "bootstrap":
        protocol["execution_plan"]["bootstrap_samples"] = 10
    else:
        protocol["execution_plan"]["policies"]["usage2"]["gpu"] = 3 * audit.GIB
    with pytest.raises(ValueError):
        audit.validate_launch(protocol, rental, freeze, "b" * 64)


def usage_fixture():
    size = audit.GIB
    rows = [{"key": ["/data/layer", 0], "requests": 2, "transfer_bytes": size,
             "dense_bytes": 9 * size // 8},
            {"key": ["/data/layer", 1], "requests": 3, "transfer_bytes": size,
             "dense_bytes": size},
            {"key": ["/data/layer", 2], "requests": 1, "transfer_bytes": size,
             "dense_bytes": size}]
    plans = {}
    for budget, indexes, count in ((2 * size, (1, 2), 4),
                                    (audit.BIG_GPU_BYTES, (1, 0), 5)):
        plans[str(budget)] = {"keys": [["/data/layer", index] for index in indexes],
            "payload_bytes": budget, "budget_bytes": budget, "candidate_count": 3,
            "total_requests": 6, "selected_requests": count,
            "saved_transfer_bytes_proxy": count * size,
            "policy": "frequency_transfer_bytes_per_dense_byte"}
    return {"observed_updates": 2, "observed_requests": 6, "records": rows, "plans": plans}


def test_recorded_plans_reproduce_from_independent_exact_greedy_math():
    plans = audit.recompute_usage(usage_fixture())
    assert plans[2 * audit.GIB] == (("/data/layer", 1), ("/data/layer", 2))
    assert plans[audit.BIG_GPU_BYTES] == (("/data/layer", 1), ("/data/layer", 0))


@pytest.mark.parametrize("change", ["count", "repeat", "relative", "plan_keys", "payload",
                                   "boolean_count", "learning_length"])
def test_profile_or_plan_relabelling_cannot_pass(change):
    data = usage_fixture()
    if change == "count":
        data["observed_requests"] += 1
    elif change == "repeat":
        data["records"][1]["key"] = data["records"][0]["key"][:]
    elif change == "relative":
        data["records"][0]["key"][0] = "../layer"
    elif change == "plan_keys":
        data["plans"][str(2 * audit.GIB)]["keys"].reverse()
    elif change == "payload":
        data["plans"][str(2 * audit.GIB)]["payload_bytes"] += 1
    elif change == "boolean_count":
        data["records"][0]["requests"] = True
    else:
        data["observed_updates"] = 1
    with pytest.raises(ValueError):
        audit.recompute_usage(data)


def exploration(candidate=9.):
    return [{"policy": name, "seconds": [candidate if name == "hostpacked" else 10.] * 6}
            for name in audit.ORDER]


def test_selection_uses_only_fresh_packed_baseline_and_six_complete_arrays():
    assert audit.select(exploration())["candidate"] == "hostpacked"
    assert audit.select(exploration(11.))["candidate"] is None
    values = exploration()
    values[0]["seconds"] = [1.]
    with pytest.raises(ValueError, match="Incomplete"):
        audit.select(values)


def confirmation(candidate_seconds=9.):
    values = []
    pair = ("baseline", "hostpacked")
    for number, order in enumerate((pair, pair[::-1]) * 2):
        for position, name in enumerate(order):
            raw = {"pid": len(values) + 1, "warmup": {"losses": [3., 2.]},
                   "timing": {"losses": [2.] * 6,
                              "update_seconds": [10. if name == "baseline"
                                                 else candidate_seconds] * 6}}
            values.append({"round": number, "position": position, "policy": name, "raw": raw})
    return values


def test_confirmation_is_held_out_balanced_and_preserves_practical_gate():
    result = audit.confirm(confirmation(), "hostpacked")
    assert result["step_time_reduction_percent"] == pytest.approx(10.)
    assert result["passes_practical_2_percent_gate"] is True
    below = audit.confirm(confirmation(9.9), "hostpacked")
    assert below["passes_practical_2_percent_gate"] is False


@pytest.mark.parametrize("change", ["loss", "round", "pid", "missing"])
def test_confirmation_rejects_inaccurate_reused_or_incomplete_evidence(change):
    rows = confirmation()
    if change == "loss":
        rows[1]["raw"]["timing"]["losses"][0] += .1
    elif change == "round":
        rows[0]["round"] = 1
    elif change == "pid":
        rows[1]["raw"]["pid"] = rows[0]["raw"]["pid"]
    else:
        rows.pop()
    with pytest.raises(ValueError):
        audit.confirm(rows, "hostpacked")


def cache_fixture():
    before = {"logical_fetches": 0, "storage_reads": 0, "storage_bytes_read": 0,
              "materializations": 0, "host_cache_policy": "static", "host_prepacked": True,
              "host": {"budget_bytes": 8 * audit.GIB, "payload_bytes": 100, "hits": 0},
              "device": {"budget_bytes": 2 * audit.GIB, "payload_bytes": 100, "hits": 0},
              "transfer": {"mode": "packed", "h2d_copies": 0, "layout_builds": 0,
                           "host_copy_calls": 0,
                           "pinned_host_bytes": 20, "device_staging_bytes": 20}}
    after = copy.deepcopy(before)
    after.update(logical_fetches=5, storage_reads=1, storage_bytes_read=100, materializations=3)
    after["host"]["hits"], after["device"]["hits"] = 2, 2
    after["transfer"].update(h2d_copies=3, layout_builds=1, host_copy_calls=5)
    return {"setup": {"cache_plan": {"host_cache_bytes": 8 * audit.GIB,
                                     "device_cache_bytes": 2 * audit.GIB,
                                     "host_cache_policy": "static"}},
            "timing": {"runtime_before": {"expert_cache": before},
                       "runtime_after": {"expert_cache": after}}}


def test_actual_host_packing_activity_and_cache_conservation_pass():
    delta = audit.cache_evidence(cache_fixture(), "timing", "hostpacked")
    assert delta["logical_fetches"] == 5 and delta["materializations"] == 3


@pytest.mark.parametrize("change", ["role", "fast_path", "budget", "accounting", "h2d",
                                   "observer", "copy_count"])
def test_reported_settings_cannot_replace_actual_activity_evidence(change):
    raw = cache_fixture()
    after = raw["timing"]["runtime_after"]["expert_cache"]
    if change == "role":
        after["host_prepacked"] = False
    elif change == "fast_path":
        after["transfer"]["layout_builds"] = 3
    elif change == "budget":
        after["host"]["payload_bytes"] = 9 * audit.GIB
    elif change == "accounting":
        after["host"]["hits"] = 1
    elif change == "observer":
        after["usage_profile"] = {"enabled": True}
    elif change == "copy_count":
        after["transfer"]["host_copy_calls"] = 0
    else:
        after["transfer"]["h2d_copies"] = 4
    with pytest.raises(ValueError):
        audit.cache_evidence(raw, "timing", "hostpacked")
