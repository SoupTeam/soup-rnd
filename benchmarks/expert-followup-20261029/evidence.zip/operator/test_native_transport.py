"""Real local binary subprocess upload and bounded native-SSH retry controls."""

import ast
import hashlib
import io
import json
import os
import shlex
import subprocess
import sys

import cloud
import diagnostics
import pytest
import transport


@pytest.fixture(autouse=True)
def local_only(tmp_path, monkeypatch):
    monkeypatch.setattr(diagnostics, 'ROOT', tmp_path)
    monkeypatch.setattr(transport, 'ROOT', tmp_path)
    monkeypatch.setattr(cloud, 'ssh', lambda *_a, **_k: pytest.fail('Live SSH was reached'))
    monkeypatch.setattr(cloud, 'receipt', lambda: {'instance_id': 42})


def remote_upload(tmp_path, payload, *, declared=None, expected=None, identity='42', name='source.tar.gz'):
    metadata = {'name': name, 'bytes': len(payload) if declared is None else declared,
                'sha256': expected or hashlib.sha256(payload).hexdigest(),
                'instance_id': 42, 'nonce': 'testnonce'}
    program = 'ALLOWED=' + repr(tuple(transport.UPLOAD_ALLOWLIST)) + '\nMETA=' + repr(metadata) + '\n'
    program += transport.REMOTE_UPLOAD_PROGRAM.replace("Path('/root/liger')", 'Path(' + repr(str(tmp_path)) + ')')
    return subprocess.run([sys.executable, '-c', program], input=payload, capture_output=True,
                          env={**os.environ, 'CONTAINER_ID': identity}, timeout=15)


def test_real_native_stdin_all_byte_values_survive_atomic_verified_remote_program(tmp_path):
    payload = bytes(range(256)) * 2048 + b'\0\r\n\xffLAST'
    result = remote_upload(tmp_path, payload)
    assert result.returncode == 0, result.stderr
    assert (tmp_path / 'source.tar.gz').read_bytes() == payload
    ack = json.loads(result.stdout)
    assert ack['bytes'] == len(payload) and ack['sha256'] == hashlib.sha256(payload).hexdigest()
    assert ack['container_id'] == '42' and ack['atomic_rename'] and ack['file_fsynced']
    assert not list(tmp_path.glob('*.upload-*'))


@pytest.mark.parametrize('mutation', ['short', 'long', 'hash', 'instance', 'name'])
def test_wrong_byte_count_hash_identity_or_name_never_replaces_existing_file(tmp_path, mutation):
    original = b'preserve original'
    (tmp_path / 'source.tar.gz').write_bytes(original)
    payload = bytes(range(256)) * 8
    changes = {'short': {'declared': len(payload) + 1}, 'long': {'declared': len(payload) - 1},
               'hash': {'expected': '0' * 64}, 'instance': {'identity': '999'},
               'name': {'name': '../ssh-key'}}
    result = remote_upload(tmp_path, payload, **changes[mutation])
    assert result.returncode == 65
    assert (tmp_path / 'source.tar.gz').read_bytes() == original
    assert not list(tmp_path.glob('*.upload-*'))


def test_client_upload_passes_binary_file_handle_and_verifies_ack(tmp_path, monkeypatch):
    payload = bytes(range(256)) * 128
    (tmp_path / 'source.tar.gz').write_bytes(payload)
    observed = []
    def native(command, *, timeout, stdin):
        observed.append((stdin.read(), timeout))
        program = shlex.split(command)[2]
        metadata = ast.literal_eval(program.split('\nMETA=', 1)[1].split('\n', 1)[0])
        ack = {'name': metadata['name'], 'bytes': len(payload), 'sha256': metadata['sha256'],
               'container_id': '42', 'native_binary_upload': True, 'file_fsynced': True, 'atomic_rename': True}
        return subprocess.CompletedProcess(command, 0, json.dumps(ack).encode(), b'')
    monkeypatch.setattr(cloud, 'ssh', native)
    assert transport.upload('source.tar.gz')['bytes'] == len(payload)
    assert observed == [(payload, 120)]


@pytest.mark.parametrize('failure', ['ack_hash', 'nonzero', 'hostkey'])
def test_client_upload_refuses_corrupt_ack_nonzero_or_changed_host_key(tmp_path, monkeypatch, failure):
    (tmp_path / 'source.tar.gz').write_bytes(b'valid local bytes')
    responses = {'ack_hash': (0, b'{"sha256":"wrong"}', b''),
                 'nonzero': (255, b'', b'Connection refused'),
                 'hostkey': (255, b'', b'Host key verification failed.')}
    code, output, error = responses[failure]
    monkeypatch.setattr(cloud, 'ssh', lambda command, **_: subprocess.CompletedProcess(command, code, output, error))
    expected = {'ack_hash': transport.UploadIntegrityError, 'nonzero': transport.NativeSSHFailure,
                'hostkey': transport.HostKeyRefused}[failure]
    with pytest.raises(expected):
        transport.upload('source.tar.gz')


def test_native_commands_retry_timeouts_and_nonzero_only_three_times(tmp_path, monkeypatch):
    calls, sleeps = [], []
    def native(command, *, timeout):
        calls.append(timeout)
        if len(calls) == 1:
            raise subprocess.TimeoutExpired(command, timeout)
        if len(calls) == 2:
            return subprocess.CompletedProcess(command, 255, b'', b'Connection refused')
        return subprocess.CompletedProcess(command, 0, bytes(range(256)), b'')
    monkeypatch.setattr(cloud, 'ssh', native)
    monkeypatch.setattr(transport.time, 'sleep', sleeps.append)
    result = transport.ssh_retry('bounded-test', timeout=7, attempts=3)
    assert result.stdout == bytes(range(256)) and calls == [7, 7, 7] and sleeps == [2, 2]
    failed = [json.loads(path.read_text()) for path in (tmp_path / 'operation-events').glob('*-failed.json')]
    assert len(failed) >= 2 and all(row['traceback'] for row in failed)


def test_host_key_refusal_does_not_retry_or_relax_policy(monkeypatch):
    calls = []
    def native(command, **_):
        calls.append(command)
        return subprocess.CompletedProcess(command, 255, b'', b'REMOTE HOST IDENTIFICATION HAS CHANGED')
    monkeypatch.setattr(cloud, 'ssh', native)
    monkeypatch.setattr(transport.time, 'sleep', lambda *_: pytest.fail('host-key refusal retried'))
    with pytest.raises(transport.HostKeyRefused):
        transport.ssh_retry('read-only', attempts=3)
    assert len(calls) == 1


def test_native_binary_read_never_publishes_partial_nonzero_reply(monkeypatch):
    monkeypatch.setattr(cloud, 'ssh', lambda command, **_: subprocess.CompletedProcess(command, 1, b'partial\0binary', b'failed'))
    target = io.BytesIO()
    with pytest.raises(transport.NativeSSHFailure):
        transport.stream('read-only', target, timeout=5)
    assert target.getvalue() == b''


@pytest.mark.parametrize('attempts,timeout', [(4, 5), (0, 5), (1, 0)])
def test_timeout_and_attempt_limits_are_checked_before_live_call(attempts, timeout):
    with pytest.raises(ValueError):
        transport.ssh_retry('read-only', timeout=timeout, attempts=attempts)


def test_allowlist_rejects_private_key_before_any_native_call():
    with pytest.raises(ValueError):
        transport.upload('ssh-key')
