"""Cross-process API admission for private Vast operators, never credentials.

One OS-released file lock serializes request STARTS, not network operations.
Every cloud/guardian process uses the same directory. Cleanup admissions have
priority over ordinary reads while retaining the same request-rate floor.
"""

from __future__ import annotations

import json
import math
import os
import sys
import threading
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

DEFAULT_DIRECTORY = Path(r"C:\Users\esenb\Documents\SoupResearch\.vast-api-admission-v1")
FLOOR_SECONDS = 2.0
PRIORITY_TTL_SECONDS = 10.0


@contextmanager
def exclusive(path: Path, deadline: float) -> Iterator[None]:
    """OS lock is automatically released on process death; no stale mutex PID file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a+b") as stream:
        stream.seek(0, os.SEEK_END)
        if stream.tell() == 0:
            stream.write(b"0")
            stream.flush()
        locked = False
        try:
            while not locked:
                if time.monotonic() >= deadline:
                    raise TimeoutError("Shared API admission lock deadline exceeded")
                stream.seek(0)
                try:
                    if sys.platform == "win32":
                        import msvcrt

                        msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
                    else:
                        import fcntl

                        fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                    locked = True
                except OSError:
                    time.sleep(min(.05, max(0., deadline - time.monotonic())))
            yield
        finally:
            if locked:
                stream.seek(0)
                if sys.platform == "win32":
                    import msvcrt

                    msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl

                    fcntl.flock(stream.fileno(), fcntl.LOCK_UN)


class SharedAdmission:
    def __init__(self, directory: Path = DEFAULT_DIRECTORY, floor_seconds: float = FLOOR_SECONDS):
        if (type(floor_seconds) not in (int, float) or not math.isfinite(floor_seconds)
                or floor_seconds < 2.0):
            raise ValueError("Shared API request floor must remain at least two seconds")
        self.directory = Path(directory)
        self.floor = float(floor_seconds)

    def _cleanup_pending(self, now: float) -> bool:
        for path in self.directory.glob("cleanup-priority-*.json"):
            try:
                value = json.loads(path.read_text())
                if 0 <= now - value["monotonic"] <= PRIORITY_TTL_SECONDS:
                    return True
            except (OSError, ValueError, KeyError, TypeError):
                continue
        return False

    def wait(self, *, cleanup: bool = False, deadline: float | None = None) -> float:
        deadline = time.monotonic() + 180. if deadline is None else deadline
        self.directory.mkdir(parents=True, exist_ok=True)
        marker = self.directory / f"cleanup-priority-{os.getpid()}-{threading.get_ident()}.json"
        if cleanup:
            marker.write_text(json.dumps({"monotonic": time.monotonic()}))
        try:
            while True:
                now = time.monotonic()
                if now >= deadline:
                    raise TimeoutError("Shared API request admission deadline exceeded")
                if not cleanup and self._cleanup_pending(now):
                    time.sleep(min(.05, deadline - now))
                    continue
                with exclusive(self.directory / "admission.lock", deadline):
                    now = time.monotonic()
                    if not cleanup and self._cleanup_pending(now):
                        continue
                    state_path = self.directory / "admission.json"
                    state = json.loads(state_path.read_text()) if state_path.exists() else {}
                    last = state.get("last_start_monotonic", -self.floor)
                    if type(last) not in (int, float) or not math.isfinite(last):
                        raise ValueError("Shared API monotonic admission state is invalid")
                    # A reboot resets the OS monotonic epoch; there is no surviving old call.
                    delay = self.floor if last > now else max(0., last + self.floor - now)
                    if delay > 0:
                        if now + delay >= deadline:
                            raise TimeoutError("Shared API rate floor exceeds request deadline")
                        time.sleep(delay)
                    started = time.monotonic()
                    if started >= deadline:
                        raise TimeoutError("Shared API admission deadline exceeded after rate wait")
                    if not cleanup and self._cleanup_pending(started):
                        continue
                    from durable import durable_json
                    durable_json(state_path, {"last_start_monotonic": started,
                        "last_start_unix": time.time(), "pid": os.getpid(), "cleanup": cleanup})
                    return started
        finally:
            if cleanup:
                marker.unlink(missing_ok=True)
