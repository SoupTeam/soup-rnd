"""Explicit root launch with unconditional exact-instance/volume cleanup."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT / ".deps"))

import cloud  # noqa: E402
import controller  # noqa: E402
from diagnostics import step  # noqa: E402


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--offer-id", required=True, type=int)
    parser.add_argument("--volume-ask-id", required=True, type=int)
    parser.add_argument("--seconds", default=9000, type=int)
    args = parser.parse_args(argv)
    controller.freeze_check()
    protocol = json.loads((ROOT / "protocol.json").read_text())
    if args.seconds != protocol["financial"]["maximum_seconds"]:
        raise ValueError("Lease deadline differs from the frozen 2.5-hour profile protocol")
    try:
        with step('allocate-exact-owned-lease'):
            cloud.allocate(args)
        with step('controller-main'):
            return controller.main()
    finally:
        if (cloud.ROOT / "vast-rental.json").is_file():
            try:
                with step('finally-exact-owned-cleanup'):
                    cloud.destroy("Outer launch finally: exact-owned instance and volume cleanup")
            finally:
                with step('finally-fresh-absence'):
                    controller.verify_absence()


if __name__ == "__main__":
    main()
