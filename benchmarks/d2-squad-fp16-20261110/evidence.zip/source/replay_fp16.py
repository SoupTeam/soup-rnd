"""Verify transported D2 FP16 data and independently recompute the calibration gates."""
import argparse
import hashlib
import json
import statistics
from pathlib import Path

import torch
from safetensors import safe_open


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main(root):
    torch.set_num_threads(1)
    summary = read(root / "summary.json")
    arms = tuple(summary["arms"])
    model = read(root / "model-manifest.json")
    assert model["dtype"] == "float16"
    assert sha(root / "model-seed-792.safetensors") == model["files"]["seed-792.safetensors"]
    data = read(root / "dataset-manifest.json")
    assert data["counts"] == {"train": 13032, "validation": 1024, "test": 2048}
    assert sha(root / "split-manifest.json") == data["source_manifest_sha256"]
    rows = {}
    evidence = {"status": "verified", "source_status": summary["status"], "arms": {}, "gates": {}}
    for arm in arms:
        raw = read(root / arm / "result.json")
        assert raw["data_sha256"] == sha(root / "dataset-manifest.json")
        assert raw["execution"]["fixture_sha256"] == sha(root / "model-manifest.json")
        assert raw["execution"]["normalization_gate"] == "PASS"
        assert raw["base_unchanged"] and raw["updates"] == len(raw["rows"]) == 20
        assert raw["gpu_uuid"] == summary["jobs"]["peft"]["gpu_uuid"]
        assert sha(root / arm / "snapshot.safetensors") == raw["snapshot_sha256"]
        rows[arm] = raw["rows"]
        steps = [row["full_update_seconds"] for row in rows[arm]]
        assert statistics.median(steps) == summary["jobs"][arm]["median_step_seconds"]
        evidence["arms"][arm] = {
            "snapshot_sha256": raw["snapshot_sha256"],
            "median_step_seconds": statistics.median(steps),
            "peak_allocated_gib": raw["peak_allocated_bytes"] / 2**30,
            "peak_reserved_gib": raw["peak_reserved_bytes"] / 2**30,
            "total_20_update_seconds": sum(steps),
        }
    for arm in arms[1:]:
        baseline = "nora-control" if arm == "nora" else "peft"
        assert [row["ids"] for row in rows[arm]] == [row["ids"] for row in rows[baseline]]
        actual = evidence["arms"][arm]
        ref = evidence["arms"][baseline]
        actual["reference"] = baseline
        for field in ("median_step_seconds", "peak_allocated_gib"):
            actual[f"{field}_change_pct"] = (actual[field] / ref[field] - 1) * 100
        if arm == "nora":
            continue
        observed = summary["gates"][f"{arm}_vs_peft"]
        matches = sum(f"{x['loss']:.3f}" == f"{y['loss']:.3f}"
                      for x, y in zip(rows[baseline], rows[arm]))
        with safe_open(root / baseline / "snapshot.safetensors", framework="pt") as reference, \
                safe_open(root / arm / "snapshot.safetensors", framework="pt") as candidate:
            keys = reference.keys()
            assert keys and keys == candidate.keys()
            failures, maximum, exact = [], 0., 0
            for key in keys:
                a, b = reference.get_tensor(key), candidate.get_tensor(key)
                assert a.shape == b.shape and a.dtype == b.dtype
                assert bool(torch.isfinite(a).all() and torch.isfinite(b).all())
                exact += torch.equal(a, b)
                a, b = a.double(), b.double()
                error = ((b - a).norm() / a.norm().clamp_min(1e-12)).item()
                maximum = max(maximum, error)
                if error > .01:
                    failures.append(key)
        assert set(failures) == {row["name"] for row in observed["tensor_failures"]}
        assert matches == observed["matched_losses"]
        assert observed["passed"] == (matches == 20 and not failures)
        evidence["gates"][arm] = {"losses_match": matches, "tensors": len(keys),
                                  "exact_tensors": exact, "failed_tensors": len(failures),
                                  "maximum_relative_l2": maximum}
    target = root / "local-replay.json"
    target.write_text(json.dumps(evidence, indent=2) + "\n", encoding="utf-8")
    print(target)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    main(parser.parse_args().root)

