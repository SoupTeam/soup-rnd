"""Private one-GPU Soup NF4/FP16 policy benchmark using an offline synthetic model."""

from __future__ import annotations

import argparse
import dataclasses
import hashlib
import json
import os
import shutil
import statistics
import subprocess
import sys
import time
import traceback
from pathlib import Path
from types import SimpleNamespace

from rich.console import Console

GIB = 2**30
MIB = 2**20
SEED = 37
VOCAB = 2048
TARGETS = ("q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj")
CONSOLE = Console()


def save(path: Path, value: dict) -> None:
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    temporary.replace(path)


def read(path: Path) -> dict:
    return json.loads(path.read_text())


def configure_torch(args: argparse.Namespace):
    import torch

    torch.set_num_threads(1)
    if not torch.cuda.is_available() or torch.cuda.device_count() != 1:
        raise RuntimeError("Run with exactly one visible CUDA GPU")
    props = torch.cuda.get_device_properties(0)
    cap = args.cap_gib * GIB
    if props.total_memory < cap:
        raise RuntimeError("GPU has less memory than the requested cap")
    torch.cuda.set_per_process_memory_fraction(cap / props.total_memory, 0)
    torch.manual_seed(SEED)
    torch.cuda.manual_seed_all(SEED)
    torch.use_deterministic_algorithms(True)
    torch.backends.cuda.matmul.allow_tf32 = False
    return torch


def compare(reference, candidate, path=(), report=None) -> dict:
    import torch

    if report is None:
        report = {"checks": 0, "bitwise": True, "max_abs": 0.0}
    if torch.is_tensor(reference):
        if not torch.is_tensor(candidate):
            raise AssertionError(f"Candidate is not a tensor at {path}")
        if reference.shape != candidate.shape or reference.dtype != candidate.dtype:
            raise AssertionError(f"Shape or dtype differs at {path}")
        if not bool(torch.isfinite(reference).all() and torch.isfinite(candidate).all()):
            raise AssertionError(f"Nonfinite at {path}")
        exact = torch.equal(reference, candidate)
        report["checks"] += 1
        report["bitwise"] &= exact
        if not reference.is_floating_point() or path[-1] == "initial":
            if not exact:
                raise AssertionError(f"Exact field differs at {path}")
        elif not torch.allclose(candidate, reference, rtol=.01, atol=1e-5):
            raise AssertionError(f"Original tolerance failed at {path}")
        if path[-1] == "loss" and format(candidate.item(), ".3f") != format(reference.item(), ".3f"):
            raise AssertionError(f"Loss differs at three decimals at {path}")
        if reference.numel() and reference.is_floating_point():
            diff = float((candidate.float() - reference.float()).abs().max())
            report["max_abs"] = max(report["max_abs"], diff)
    elif isinstance(reference, dict):
        if not isinstance(candidate, dict) or reference.keys() != candidate.keys():
            raise AssertionError(f"Mapping keys differ at {path}")
        for name, value in reference.items():
            compare(value, candidate[name], (*path, name), report)
    elif type(reference) is not type(candidate) or reference != candidate:
        raise AssertionError(f"Scalar differs at {path}")
    return report


def prepare(args: argparse.Namespace) -> None:
    torch = configure_torch(args)
    from transformers import LlamaConfig, LlamaForCausalLM

    from soup_cli.utils.layer_shard import shard_checkpoint
    from soup_cli.utils.layer_stream_runtime import build_meta_skeleton, quantised_layer_suffixes

    if args.hidden % 64 or args.layers < 4:
        raise ValueError("Use a hidden size divisible by 64 and at least four layers")
    if shutil.disk_usage(args.work).free < 3 * GIB:
        raise RuntimeError("The offline fixture needs at least 3 GiB free scratch disk")
    config = LlamaConfig(
        vocab_size=VOCAB, hidden_size=args.hidden, intermediate_size=3 * args.hidden,
        num_hidden_layers=args.layers, num_attention_heads=args.hidden // 64,
        num_key_value_heads=args.hidden // 64, max_position_embeddings=max(512, args.seq),
        attention_dropout=0.0, tie_word_embeddings=True, use_cache=False,
    )
    model = LlamaForCausalLM(config).half()
    params = sum(param.numel() for param in model.parameters())
    checkpoint = args.work / "fixture"
    model.save_pretrained(checkpoint, safe_serialization=True)
    del model
    skeleton = build_meta_skeleton(str(checkpoint), dtype="float16", quant="nf4")
    suffixes = quantised_layer_suffixes(skeleton)
    del skeleton
    index = shard_checkpoint(
        str(checkpoint), str(args.work / "shards"), dtype="float16", arch="llama",
        quant="nf4", quant_suffixes=suffixes, double_quant=True, quant_device="cuda",
    )
    if not suffixes or index.quant != "nf4" or index.dtype != "float16" or not index.double_quant:
        raise RuntimeError("The fixture is not double-quantized NF4 with FP16 compute")
    generator = torch.Generator().manual_seed(SEED + 1)
    tokens = torch.randint(3, VOCAB, (16, args.accum, 1, args.seq), generator=generator)
    torch.save(tokens, args.work / "inputs.pt")
    props = torch.cuda.get_device_properties(0)
    save(args.work / "fixture.json", {
        "parameters": params, "layers": args.layers, "hidden": args.hidden, "sequence": args.seq,
        "accumulation": args.accum, "model": "seeded offline synthetic Llama",
        "device": props.name, "device_total_bytes": props.total_memory,
        "device_capability": list(torch.cuda.get_device_capability()),
        "allocator_cap_bytes": args.cap_gib * GIB, "torch": torch.__version__,
        "bnb": __import__("bitsandbytes").__version__,
        "input_sha256": hashlib.sha256((args.work / "inputs.pt").read_bytes()).hexdigest(),
        "precision": "NF4 storage, FP16 compute, FP32 AdamW adapter state",
    })


def snapshot(optimizer, adapters: dict, loss, logits) -> dict:
    return {
        "loss": loss.detach().cpu(),
        "logits": logits.detach().cpu(),
        "gradients": {name: param.grad.detach().cpu().clone() for name, param in adapters.items()},
        "adapters": {name: param.detach().cpu().clone() for name, param in adapters.items()},
        "optimizer": {
            name: {key: (value.detach().cpu().clone() if hasattr(value, "detach") else value)
                   for key, value in optimizer.state[param].items()}
            for name, param in adapters.items()
        },
    }


def worker(args: argparse.Namespace) -> None:
    torch = configure_torch(args)
    from peft import LoraConfig, TaskType

    from soup_cli.config.schema import SoupConfig
    from soup_cli.utils.layer_shard import read_shard_index
    from soup_cli.utils.layer_stream_runtime import (
        build_streamed_model,
        clear_stream_substitution_cache,
    )
    from soup_cli.utils.stream_cache_profile import build_stream_cache_callback, load_measurements
    from soup_cli.utils.stream_residency import configure_stream_residency

    args.out.mkdir(parents=True)
    data = torch.load(args.work / "inputs.pt", weights_only=True).to("cuda:0")
    fixture = read(args.work / "fixture.json")
    checkpoint, shards = args.work / "fixture", args.work / "shards"
    resident = 0 if args.policy == "ordinary" else args.gpu_layers
    ram_mib = 0 if args.policy == "ordinary" else args.ram_mib
    retained = args.policy in ("joint", "auto")
    messages = []
    callback = None
    opt_args = SimpleNamespace(
        world_size=1, per_device_train_batch_size=1, gradient_accumulation_steps=args.accum,
    )
    state = SimpleNamespace(max_steps=args.plan_updates, global_step=0)
    cap = args.cap_gib * GIB
    torch.cuda.reset_peak_memory_stats()
    started = time.perf_counter()
    model, runtime = build_streamed_model(
        model_id=str(checkpoint), shard_dir=str(shards), index=read_shard_index(str(shards)),
        lora_config=LoraConfig(r=4, lora_alpha=4, lora_dropout=0, bias="none",
                               target_modules=list(TARGETS), task_type=TaskType.CAUSAL_LM),
        device="cuda:0", dtype="float16", quant="nf4", buffers=2, pin=True, require_pin=True,
        seed=SEED, tier="disk", read_ahead=2,
    )
    try:
        model.train()
        model.config.use_cache = False
        adapters = {name: param for name, param in model.named_parameters() if param.requires_grad}
        if not adapters or any(param.dtype != torch.float32 for param in adapters.values()):
            raise RuntimeError("Expected materialized FP32 LoRA adapters")
        generator = torch.Generator().manual_seed(SEED + 2)
        with torch.no_grad():
            for name, param in adapters.items():
                if "lora_B" in name:
                    param.copy_(torch.randn(param.shape, generator=generator).mul_(.02))
        optimizer = torch.optim.AdamW(list(adapters.values()), lr=.001, foreach=False, fused=False)
        if args.policy == "ordinary" and args.phase != "record":
            pass
        elif args.policy == "manual" and args.phase != "record":
            plan = configure_stream_residency(
                model, runtime, resident, rows=1, seq_len=args.seq, vocab_size=VOCAB,
                override_bytes=cap, notify=messages.append,
            )
            if not plan.enabled:
                raise RuntimeError("Fixed GPU cache was not admitted")
            runtime.source.configure_ram_cache(ram_mib * MIB)
        else:
            cfg = SoupConfig.model_validate({
                "base": str(checkpoint), "task": "sft",
                "data": {"train": str(args.work / "inputs.pt"), "max_length": args.seq},
                "training": {"batch_size": 1, "gradient_accumulation_steps": args.accum,
                             "seed": SEED, "lr": .001, "quantization": "4bit",
                             "double_quant_on": True, "fp16": True, "bf16": False,
                             "stream_layers": True, "stream_source": "disk",
                             "stream_vram_override": cap, "stream_ram_cache_mb": ram_mib,
                             "stream_resident_layers": resident,
                             "stream_cache_profile": str(args.work / "history.json"),
                             "stream_cache_profile_mode": "reuse" if args.policy == "auto"
                             else "record", "stream_recompute": "auto" if retained else "on",
                             "lora": {"r": 4, "alpha": 4, "dropout": 0,
                                      "target_modules": list(TARGETS)}},
            })
            owner = SimpleNamespace(
                _stream_runtime=runtime,
                trainer=SimpleNamespace(train_dataset=SimpleNamespace(
                    _fingerprint=fixture["input_sha256"])),
                _stream_step_shape=lambda *_: (1, args.seq, VOCAB),
                _close_stream_runtime=runtime.close,
            )
            callback = build_stream_cache_callback(
                owner, cfg, index_path=shards / "index.json", setup_started=started,
                notify=messages.append,
            )
            callback.on_train_begin(opt_args, state, None, model=model, optimizer=optimizer)
            if not callback.identity:
                raise RuntimeError(f"Profile identity missing: {messages}")
        selected = {
            "ram_indices": list(runtime.source.ram_cache_stats()["indices"]),
            "gpu_indices": sorted(runtime.pool.resident_slots),
            "retained_layers": int(getattr(callback, "signature", {}).get("retained_layers", 0)),
        }
        if args.policy == "manual" and (
            not selected["ram_indices"] or len(selected["gpu_indices"]) != resident
        ):
            raise RuntimeError(f"Manual candidate did not receive its RAM/GPU caches: {selected}")
        if args.policy == "joint" and not selected["retained_layers"]:
            if args.phase == "accuracy" and not any("failed" in msg for msg in messages):
                save(args.out / "result.json", {
                    "status": "retention_declined", "placement": selected, "messages": messages,
                })
                return
            raise RuntimeError(f"Previously admitted retention failed: {messages}")
        clear_stream_substitution_cache(model)
        torch.cuda.synchronize()
        setup = time.perf_counter() - started
        finite_losses = []
        samples = []
        phase_started = time.perf_counter()
        for update in range(args.updates):
            if callback and args.phase == "record":
                callback.on_step_begin(opt_args, state, None)
            step_started = time.perf_counter()
            optimizer.zero_grad(set_to_none=True)
            logits = loss = None
            for micro in range(args.accum):
                tokens = data[update % len(data), micro]
                with torch.autocast("cuda", dtype=torch.float16):
                    output = model(input_ids=tokens, labels=tokens, use_cache=False)
                    loss = output.loss
                    logits = output.logits
                (loss / args.accum).backward()
                finite_losses.append(loss.detach())
            optimizer.step()
            if callback and args.phase == "record":
                callback.on_step_end(opt_args, state, None)
            if args.phase == "accuracy":
                proof = snapshot(optimizer, adapters, loss, logits)
                if not all(value is not None for value in proof["gradients"].values()):
                    raise RuntimeError("Missing adapter gradient")
                if args.policy == "ordinary":
                    compare(proof, proof)
                    torch.save(proof, args.out / f"update-{update:02}.pt")
                else:
                    ref = torch.load(args.reference / f"update-{update:02}.pt", weights_only=True)
                    samples.append(compare(ref, proof))
            elif update == 1 or update == args.updates - 1:
                torch.cuda.synchronize()
            if update == 1:
                warmup_wall = time.perf_counter() - phase_started
            if args.phase == "record" and time.perf_counter() - step_started > 120:
                raise RuntimeError("Recording an update exceeded its bounded fixture window")
        torch.cuda.synchronize()
        run_seconds = time.perf_counter() - phase_started
        full_seconds = time.perf_counter() - started
        if not bool(torch.isfinite(torch.stack(finite_losses)).all()):
            raise RuntimeError("Nonfinite loss")
        if any(not bool(torch.isfinite(param).all()) for param in adapters.values()):
            raise RuntimeError("Nonfinite adapter")
        status = Path("/proc/self/status").read_text()
        peak_rss = next(int(row.split()[1]) * 1024 for row in status.splitlines()
                        if row.startswith("VmHWM:"))
        result = {
            "status": "passed", "policy": args.policy, "phase": args.phase,
            "updates": args.updates, "placement": selected, "messages": messages,
            "setup_seconds": setup, "train_seconds": run_seconds, "full_seconds": full_seconds,
            "step_seconds_after_2": ((run_seconds - warmup_wall) / (args.updates - 2)
                                     if args.updates > 2 else None),
            "peak_vram_allocated_bytes": torch.cuda.max_memory_allocated(),
            "peak_vram_reserved_bytes": torch.cuda.max_memory_reserved(),
            "peak_rss_bytes": peak_rss, "losses": torch.stack(finite_losses).cpu().tolist(),
            "comparisons": samples, "adapter_tensors": len(adapters),
            "profile_identity": getattr(callback, "identity", None),
        }
        if result["peak_vram_reserved_bytes"] > cap:
            raise RuntimeError("PyTorch reserved memory exceeded the declared cap")
        if args.phase == "record":
            if not callback or callback.recording:
                raise RuntimeError("Profile did not finish recording")
            records = load_measurements(args.work / "history.json", callback.identity)
            if not any(row.resident_count == len(selected["gpu_indices"])
                       and row.retained_layers == selected["retained_layers"]
                       and tuple(row.ram_indices) == tuple(selected["ram_indices"])
                       for row in records):
                raise RuntimeError(f"Profile did not save the measured candidate: {messages}")
        save(args.out / "result.json", result)
    finally:
        runtime.close()


def command(args: argparse.Namespace, action: str, *extra: str) -> None:
    argv = [
        sys.executable, "-u", __file__, action, "--work", str(args.work),
        "--layers", str(args.layers), "--hidden", str(args.hidden), "--seq", str(args.seq),
        "--accum", str(args.accum), "--ram-mib", str(args.ram_mib),
        "--gpu-layers", str(args.gpu_layers), "--cap-gib", str(args.cap_gib), *extra,
    ]
    subprocess.run(argv, check=True, timeout=600, env=dict(os.environ, CUDA_VISIBLE_DEVICES="0"))


def run(args: argparse.Namespace) -> None:
    args.work.mkdir(parents=True, exist_ok=False)
    report = {"status": "running", "source_sha": args.source_sha, "accuracy": {},
              "record": {}, "timings": [], "probe": "native stream runtime and Trainer callback"}
    report_path = args.work / "summary.json"
    save(report_path, report)

    def launch(name, policy, phase, updates, reference=None):
        destination = args.work / name
        CONSOLE.print(f"[progress] {name} ({updates} updates)")
        extra = [
            "--policy", policy, "--phase", phase, "--updates", str(updates),
            "--out", str(destination),
        ]
        if reference is not None:
            extra += ["--reference", str(reference)]
        command(args, "worker", *extra)
        return read(destination / "result.json")

    try:
        CONSOLE.print("[progress] prepare offline NF4 fixture")
        command(args, "prepare")
        report["fixture"] = read(args.work / "fixture.json")
        reference = args.work / "accuracy-ordinary"
        cases = ("ordinary", "manual", "joint") if not args.no_retention else ("ordinary", "manual")
        for policy in cases:
            report["accuracy"][policy] = launch(
                f"accuracy-{policy}", policy, "accuracy", args.accuracy_steps,
                None if policy == "ordinary" else reference,
            )
            save(report_path, report)
        for policy in cases:
            if report["accuracy"][policy]["status"] != "passed":
                continue
            report["record"][policy] = launch(f"record-{policy}", policy, "record", 8)
            save(report_path, report)
        from soup_cli.utils.stream_cache_profile import choose_cache, load_measurements

        identity = report["record"]["ordinary"]["profile_identity"]
        rows = load_measurements(args.work / "history.json", identity)
        legacy_rows = [
            dataclasses.replace(row, record_only_seconds=0)
            if hasattr(row, "record_only_seconds") else row
            for row in rows
        ]
        limits = dict(ram_mib=args.ram_mib, resident_limit=args.gpu_layers,
                      allow_retention=not args.no_retention)

        def choice(candidates, steps):
            selected = choose_cache(candidates, steps, **limits)
            return dataclasses.asdict(selected) if selected else None

        report["policy_predictions"] = {
            "profiles": [dataclasses.asdict(row) for row in rows],
            "short": {"updates": args.short_steps,
                      "legacy": choice(legacy_rows, args.short_steps),
                      "adjusted": choice(rows, args.short_steps)},
            "long": {"updates": args.long_steps,
                     "legacy": choice(legacy_rows, args.long_steps),
                     "adjusted": choice(rows, args.long_steps)},
        }
        for steps in range(3, max(1024, args.long_steps * 4)):
            legacy, adjusted = choice(legacy_rows, steps), choice(rows, steps)
            if legacy and adjusted and (legacy["gpu_indices"], legacy["ram_indices"],
                                         legacy["retained_layers"]) != (
                adjusted["gpu_indices"], adjusted["ram_indices"], adjusted["retained_layers"],
            ):
                report["policy_predictions"]["first_changed_choice"] = {
                    "updates": steps, "legacy": legacy, "adjusted": adjusted,
                }
                break
        save(report_path, report)
        approved = [row["placement"] for row in report["accuracy"].values()
                    if row["status"] == "passed"]
        for label, updates in (("short", args.short_steps), ("long", args.long_steps)):
            # Apply the selector for the exact eventual job length, and save a first
            # trajectory before timing. The selected replay itself may be a new path.
            approval = launch(
                f"selection-{label}", "auto", "accuracy", updates,
                reference,
            ) if updates <= args.accuracy_steps else launch_accuracy_selection(
                launch, label, updates, args.accuracy_steps, reference,
            )
            if approval["placement"] not in approved:
                raise RuntimeError(f"Auto selected an unqualified placement: {approval['placement']}")
            report["accuracy"][f"selected-{label}"] = approval
            save(report_path, report)
            for pair in range(args.pairs):
                order = ("manual", "auto") if pair % 2 == 0 else ("auto", "manual")
                results = {}
                for policy in order:
                    results[policy] = launch(
                        f"timing-{label}-{pair}-{policy}", policy, "timing", updates,
                    )
                    expected = (approval if policy == "auto" else report["accuracy"]["manual"])
                    if results[policy]["placement"] != expected["placement"]:
                        raise RuntimeError("Timing placement differs from the accuracy arm")
                for a, b in zip(results["manual"]["losses"], results["auto"]["losses"]):
                    if format(a, ".3f") != format(b, ".3f") or abs(a - b) > 1e-5 + .01 * abs(a):
                        raise RuntimeError("A timed loss failed the original tolerance")
                report["timings"].append({"job": label, "updates": updates, **results})
                save(report_path, report)
        report["status"] = "complete"
        report["medians"] = {
            label: {
                policy: {
                    key: statistics.median(
                        row[policy][key] for row in report["timings"] if row["job"] == label
                    )
                    for key in ("full_seconds", "setup_seconds", "step_seconds_after_2",
                                "peak_vram_allocated_bytes", "peak_vram_reserved_bytes",
                                "peak_rss_bytes")
                }
                for policy in ("manual", "auto")
            }
            for label in ("short", "long")
        }
        save(report_path, report)
        CONSOLE.print(report["medians"])
    except BaseException as exc:
        report["status"] = "failed"
        report["error"] = repr(exc)
        report["traceback"] = traceback.format_exc()
        save(report_path, report)
        raise


def launch_accuracy_selection(launch, label, updates, accuracy_steps, reference):
    return launch(f"selection-{label}", "auto", f"accuracy:{accuracy_steps}", updates, reference)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("run", "prepare", "worker"))
    parser.add_argument("--work", type=Path, required=True)
    parser.add_argument("--layers", type=int, default=24)
    parser.add_argument("--hidden", type=int, default=1024)
    parser.add_argument("--seq", type=int, default=256)
    parser.add_argument("--accum", type=int, default=2)
    parser.add_argument("--cap-gib", type=int, default=8)
    parser.add_argument("--ram-mib", type=int, default=96)
    parser.add_argument("--gpu-layers", type=int, default=8)
    parser.add_argument("--short-steps", type=int, default=8)
    parser.add_argument("--long-steps", type=int, default=64)
    parser.add_argument("--accuracy-steps", type=int, default=4)
    parser.add_argument("--pairs", type=int, default=2)
    parser.add_argument("--no-retention", action="store_true")
    parser.add_argument("--source-sha", default="unspecified")
    parser.add_argument("--policy", choices=("ordinary", "manual", "joint", "auto"))
    parser.add_argument("--phase")
    parser.add_argument("--updates", type=int)
    parser.add_argument("--out", type=Path)
    parser.add_argument("--reference", type=Path)
    args = parser.parse_args()
    args.plan_updates = args.updates
    if args.phase and args.phase.startswith("accuracy:"):
        _, count = args.phase.split(":")
        args.phase, args.updates = "accuracy", int(count)
    return args


if __name__ == "__main__":
    os.environ.setdefault("CUDA_VISIBLE_DEVICES", "0")
    os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
    os.environ.setdefault("OMP_NUM_THREADS", "1")
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
    options = parse_args()
    {"run": run, "prepare": prepare, "worker": worker}[options.action](options)

