"""Independent retained-file audit of the frozen native Kanana-30B four-arm experiment.

Nothing runs on import. No cloud, GPU, network or instance-management operation
is performed. The source checkout is read only, and its original numerical
comparator is accepted only after its file hash matches the retained source
manifest. Checkpoints/stores were deliberately not retained: their remote
fingerprints can be cross-checked, not independently rehashed locally.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import os
import random
import statistics
import traceback
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any

GIB = 2**30
ARMS = ("ordinary", "two_read", "cache", "two_read_cache")
ORDERS = tuple(ARMS[index:] + ARMS[:index] for index in range(4))
SOURCE_COMMIT = "97404397dd38487f6daf44ebd26bee81fdaf132c"
MODEL_REVISION = "0d31365acf656e5f9a593cacc4913e9c0d36cb1c"
MODEL_BYTES = 61343935088


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 2**20), b""):
            value.update(chunk)
    return value.hexdigest()


def finite_number(value: Any) -> bool:
    return type(value) in (int, float) and math.isfinite(value)


def loss_gate(reference: list[float], candidate: list[float]) -> dict[str, Any]:
    """Original reference-relative pointwise and three-decimal scalar loss gates."""
    if not reference or len(reference) != len(candidate):
        raise ValueError("recorded loss sequences differ in length or are empty")
    failures = []
    for index, (expected, actual) in enumerate(zip(reference, candidate)):
        if (not finite_number(expected) or not finite_number(actual)
                or abs(actual - expected) > 1e-5 + .01 * abs(expected)
                or f"{actual:.3f}" != f"{expected:.3f}"):
            failures.append({"update": index, "reference": expected, "candidate": actual})
    return {"passed": not failures, "checks": len(reference), "failures": failures,
            "bitwise_scalar_values": reference == candidate}


def paired_result(values: list[tuple[float, float]]) -> dict[str, Any]:
    """Independent geometric ratio calculation and paired-round bootstrap."""
    if not values or any(not finite_number(a) or not finite_number(b) or min(a, b) <= 0
                         for a, b in values):
        raise ValueError("invalid paired timing values")
    logs = [math.log(candidate / reference) for reference, candidate in values]
    rng = random.Random(29)
    draws = sorted(
        100 * (1 - math.exp(math.fsum(rng.choices(logs, k=len(logs))) / len(logs)))
        for _ in range(5000)
    )
    return {"step_time_reduction_percent": 100 * (1 - math.exp(math.fsum(logs) / len(logs))),
            "paired_bootstrap_95_percent": [draws[124], draws[4874]],
            "passes_practical_2_percent_gate": draws[124] >= 2., "paired_rounds": len(logs)}


def counter_delta(before: dict, after: dict, arm: str) -> dict:
    if arm not in ARMS:
        raise ValueError("unknown native four-arm variant")
    cached = arm in ("cache", "two_read_cache")
    row = {}
    for key in ("logical_fetches", "storage_reads", "storage_bytes_read", "materializations"):
        row[key] = after[key] - before[key]
        if type(row[key]) is not int or row[key] < 0:
            raise ValueError("invalid expert counter delta")
    for tier in ("host", "device"):
        row[tier + "_hits"] = after[tier]["hits"] - before[tier]["hits"]
        if type(row[tier + "_hits"]) is not int or row[tier + "_hits"] < 0:
            raise ValueError("invalid cache-hit delta")
        budget = (8 * GIB if tier == "host" else 2 * GIB) if cached else 0
        for snapshot in (before, after):
            data = snapshot[tier]
            if (data["budget_bytes"] != budget or type(data["payload_bytes"]) is not int
                    or not 0 <= data["payload_bytes"] <= budget):
                raise ValueError("cache payload/ceiling differs from the frozen arm")
    if (row["logical_fetches"] <= 0 or row["storage_reads"] <= 0 or
            row["storage_bytes_read"] <= 0 or
            row["storage_reads"] + row["host_hits"] + row["device_hits"] !=
            row["logical_fetches"] or
            row["materializations"] != row["logical_fetches"] - row["device_hits"]):
        raise ValueError("logical/read/hit/materialization counters disagree")
    if not cached:
        if row["host_hits"] or row["device_hits"]:
            raise ValueError("the uncached baseline used a cache")
    else:
        if (before.get("host_cache_policy") != "static" or
                after.get("host_cache_policy") != "static" or
                min(row["host_hits"], row["device_hits"]) <= 0):
            raise ValueError("requested cache policy/tiers were not actually exercised")
        if after["host"]["evictions"] != before["host"]["evictions"]:
            raise ValueError("a static cache evicted admitted entries")
    return row


def verify_schedule(rows: list[dict], rounds: int) -> None:
    if type(rounds) is not int or rounds < 4 or rounds % 4:
        raise ValueError("the native Latin schedule requires a multiple of four rounds")
    seen = set()
    for row in rows:
        number, arm = row["round"], row["arm"]
        if (type(number) is not int or not 0 <= number < rounds or arm not in ARMS or
                row.get("position") != ORDERS[number % 4].index(arm) or (number, arm) in seen):
            raise ValueError("wrong, duplicate or out-of-order native timing block")
        seen.add((number, arm))
    if seen != {(number, arm) for number in range(rounds) for arm in ARMS}:
        raise ValueError("incomplete native four-arm timing matrix")


def expert_payload(index: dict) -> dict[str, int]:
    """Integer tensor payload arithmetic, including two scalar nested offsets."""
    if (index["n_layers"] != 48 or index["expert_layout"] != "per_expert"
            or index["expert_layers"] != list(range(1, 48)) or index["expert_count"] != 128
            or index["dtype"] != "bfloat16" or index["quant"] != "nf4"
            or index["double_quant"] is not True or not index["quant_device"].startswith("cuda")
            or index["expert_shapes"] != {"gate_up": [1536, 2048], "down": [2048, 768]}):
        raise ValueError("cache index is not the expected native Kanana NF4 layout")
    payload = 0
    for part, shape in index["expert_shapes"].items():
        spec = index["expert_quant_specs"][part]
        if (spec["shape"] != shape or spec["nested"] is not True or spec["blocksize"] != 64
                or spec["nested_blocksize"] != 256 or spec["quant_type"] != "nf4"):
            raise ValueError("unexpected NF4 expert sidecar layout")
        weights = math.prod(shape)
        blocks = (weights + 63) // 64
        payload += (weights + 1) // 2 + blocks + ((blocks + 255) // 256) * 4 + 4
    return {"experts": 47 * 128, "packed_nf4_payload_bytes_per_expert": payload,
            "dense_bf16_bytes_per_expert": 3 * 2048 * 768 * 2,
            "all_expert_packed_payload_bytes": payload * 47 * 128,
            "max_host_entries_by_payload": 8 * GIB // payload,
            "max_device_entries_by_payload": 2 * GIB // (3 * 2048 * 768 * 2)}


class Audit:
    def __init__(self, retained: Path, source: Path) -> None:
        self.root, self.source = retained, source
        self.report: dict[str, Any] = {"status": "running", "checks": [], "files": {},
                                       "accuracy": {}, "workers": {}, "comparisons": {}}

    def check(self, condition: Any, message: str) -> None:
        self.report["checks"].append({"passed": bool(condition), "check": message})
        if not condition:
            raise AssertionError(message)

    def file(self, relative: str) -> Path:
        path = self.root / relative
        self.check(path.is_file(), "retained file exists: " + relative)
        self.report["files"][relative] = {"bytes": path.stat().st_size, "sha256": digest(path)}
        return path

    def read(self, relative: str) -> Any:
        return json.loads(self.file(relative).read_text(encoding="utf-8"))

    def resource_stage(self, stage: dict, label: str) -> None:
        resources = stage["resources"]
        self.check(type(resources["sampled_peak_rss_bytes"]) is int and
                   resources["sampled_peak_rss_bytes"] <= 32 * GIB, label + ": sampled RSS cap")
        self.check(resources["sampled_peak_process_swap_bytes"] == 0 and
                   resources.get("sampled_peak_cgroup_swap_bytes") in (0, None),
                   label + ": no process/cgroup swap observed")
        for point in (resources["before"], resources["after"]):
            physical = point["host_memory"]["MemTotal"]
            hard = [item.get("memory.max") for item in point["cgroup"]["constraints"]
                    if type(item.get("memory.max")) is int]
            self.check(28 * GIB <= min([physical, *hard]) <= 32 * GIB,
                       label + ": actual physical/cgroup RAM ceiling")
            self.check(point["process_swap_bytes"] == 0, label + ": boundary process swap zero")
            self.check(point["host_memory"].get("SwapTotal", 0) == 0 or any(
                item.get("memory.swap.max") == 0 for item in point["cgroup"]["constraints"]
            ), label + ": swap capacity unavailable to this workload")
            for item in point["cgroup"]["constraints"]:
                self.check(item.get("memory.swap.current") in (0, None),
                           label + ": boundary cgroup swap zero")
        for field in ("cuda", "cuda_including_diagnostics"):
            if field not in stage:
                continue
            self.check(all(type(stage[field][name]) is int and
                           0 <= stage[field][name] <= 8 * GIB for name in (
                               "peak_allocated_bytes", "peak_reserved_bytes")),
                       label + ": VRAM cap " + field)

    def worker(self, directory: str, arm: str, phase: str, spec: dict, identity: str) -> dict:
        raw = self.read(directory + "/result.json")
        control = self.read(directory + "/controller-result.json")
        self.check(all(control.get(key) == value for key, value in raw.items()),
                   directory + ": controller copy matches raw worker")
        self.check(raw["status"] == "passed" and raw["phase"] == phase and
                   raw["arm"] == arm and raw["spec_sha256"] == identity,
                   directory + ": status/phase/arm/spec identity")
        self.check(type(raw["pid"]) is int and raw["pid"] > 0,
                   directory + ": process identity recorded")
        self.check(raw["environment"]["gpu_total_bytes"] == spec["hardware"]["physical_vram_bytes"]
                   and 7.5 * GIB <= raw["environment"]["gpu_total_bytes"] <= 8.5 * GIB
                   and raw["environment"]["compute_capability"][0] >= 8,
                   directory + ": physical 8 GiB BF16 GPU")
        self.check(raw["environment"]["gpu_name"] == spec["hardware"]["name"],
                   directory + ": same GPU model")
        self.check(raw["environment"]["deterministic_algorithms"] is True and
                   raw["environment"]["allow_tf32"] is False,
                   directory + ": deterministic kernels and disabled TF32")
        for package, version in raw["environment"]["versions"].items():
            if package in spec["environment"]["packages"]:
                self.check(spec["environment"]["packages"][package] == version,
                           directory + ": fixed dependency " + package)
        self.resource_stage(raw["setup"], directory + "/setup")
        if arm in ("ordinary", "two_read"):
            self.check(raw["setup"]["cache_plan"] is None, directory + ": no cache admission")
        else:
            plan = raw["setup"]["cache_plan"]
            self.check(all(plan[key] == spec[key] for key in (
                "host_cache_policy", "host_cache_bytes", "device_cache_bytes")),
                directory + ": exact policy admission")
        for stage in (("accuracy",) if phase == "accuracy" else ("warmup", "timing")):
            self.resource_stage(raw[stage], directory + "/" + stage)
            if stage != "accuracy":
                expected = spec[stage + "_updates" if stage == "warmup" else "timed_updates"]
                self.check(raw[stage]["complete"] is True and
                           raw[stage]["finite_state_checks_per_update"] is True and
                           raw[stage]["updates_complete"] == expected and
                           len(raw[stage]["losses"]) == expected and
                           len(raw[stage]["update_seconds"]) == expected,
                           directory + "/" + stage + ": all finite-checked updates recorded")
                self.check(all(finite_number(value) and value > 0
                               for value in raw[stage]["update_seconds"]),
                           directory + "/" + stage + ": finite positive durations")
        self.check(finite_number(control["fresh_process_wall_seconds"]) and
                   control["fresh_process_wall_seconds"] >= raw["total_worker_seconds"],
                   directory + ": whole-entry time includes worker time")
        self.report["workers"][directory] = {
            "pid": raw["pid"], "whole_entry_seconds": control["fresh_process_wall_seconds"],
            "setup_seconds": raw["setup"]["seconds"],
            "process_lifetime_peak_rss_bytes": raw["resources_after"][
                "process_lifetime_peak_rss_bytes"],
            "environment": raw["environment"],
            "stage_cache_stats": {name: raw[name]["runtime_after"]["expert_cache"]
                                  for name in ("setup", "accuracy") if name in raw},
            "stage_resources": {name: raw[name]["resources"] for name in (
                "setup", "accuracy", "warmup", "timing",
            ) if name in raw},
            "stage_runtime_stats": {name: {
                "before": raw[name].get("runtime_before"), "after": raw[name]["runtime_after"],
            } for name in ("setup", "accuracy", "warmup", "timing") if name in raw},
        }
        for name in ("warmup", "timing"):
            if name in raw:
                self.report["workers"][directory]["stage_cache_stats"][name] = {
                    "before": raw[name]["runtime_before"]["expert_cache"],
                    "after": raw[name]["runtime_after"]["expert_cache"],
                }
        return control

    def execute(self) -> dict:
        import torch

        torch.set_num_threads(1)
        source = self.read("source-manifest.json")
        protocol = self.read("protocol.json")
        self.check(source["source_commit"] == protocol["source_commit"] == SOURCE_COMMIT,
                   "frozen source commit matches the independently selected cohort")
        name = "benchmarks/harness/two_read_cache_common.py"
        self.check(digest(self.source / name) == source["files"][name]["sha256"],
                   "executed original comparator matches retained source bytes")
        loader = importlib.util.spec_from_file_location(
            "frozen_numerical_gates", self.source / name,
        )
        common = importlib.util.module_from_spec(loader)
        loader.loader.exec_module(common)
        capacity = self.read("results/capacity-preflight.json")
        self.check(capacity["passed"] is True and
                   28 * GIB <= capacity["native_ram_limit_bytes"] <= 32 * GIB and
                   7900 <= capacity["gpu_memory_mib"] <= 8300,
                   "native startup resource preflight passed")
        pinned = self.read("results/model-pinned.json")
        self.check(pinned["repo_id"] == "kakaocorp/kanana-2-30b-a3b-base-2601" and
                   pinned["revision"] == MODEL_REVISION and pinned["weights_bytes"] == MODEL_BYTES
                   and len(pinned["files"]) == 13 and
                   sum(item["bytes"] for item in pinned["files"].values()) == MODEL_BYTES,
                   "pinned official Kanana model identity and complete 13-shard size")
        spec = self.read("results/prepared/spec.json")
        self.check(spec["git_head"] == SOURCE_COMMIT, "prepared source Git HEAD")
        self.report["recipe_and_identity"] = {
            "source_commit": SOURCE_COMMIT, "model_repo_id": pinned["repo_id"],
            "model_revision": MODEL_REVISION, "seed": spec["seed"],
            "input_seed": spec["input_seed"], "base_storage": spec["quant"],
            "compute_dtype": spec["dtype"], "adapter_dtype": "torch.float32",
            "lora_r": spec["lora_r"], "lora_alpha": spec["lora_alpha"],
            "lora_targets": spec["lora_targets"], "hardware": spec["hardware"],
            "environment": spec["environment"], "native_capacity_preflight": capacity,
        }
        self.check(spec["dtype"] == "bfloat16" and spec["quant"] == "nf4" and
                   spec["seq_len"] == 512 and spec["batch_size"] == 1 and
                   spec["accumulation"] == 2 and spec["accuracy_updates"] == 2 and
                   spec["warmup_updates"] == 2 and spec["timed_updates"] == 6 and
                   spec["lora_r"] == 4 and spec["lora_alpha"] == 8 and
                   spec["lora_targets"] == ["q_proj", "kv_b_proj", "o_proj"] and
                   spec["host_cache_bytes"] == 8 * GIB and
                   spec["device_cache_bytes"] == 2 * GIB and
                   spec["host_cache_policy"] == "static" and
                   spec["device_cap_bytes"] == 8 * GIB and spec["max_host_bytes"] <= 32 * GIB,
                   "frozen Kanana NF4/BF16 static 8-GiB RAM/2-GiB GPU cache recipe")
        for path, identity in spec["source_fingerprint"].items():
            self.check(source["files"][path]["sha256"] == identity,
                       "executed source fingerprint: " + path)
        for path, metadata in pinned["files"].items():
            self.check(spec["model_fingerprint"][path] == metadata["lfs"]["sha256"] and
                       spec["model_stat"][path][0] == metadata["bytes"],
                       "remote model fingerprint matches public LFS object: " + path)
        config = self.read("results/model-config.json")
        self.check(digest(self.root / "results/model-config.json") ==
                   spec["model_fingerprint"]["config.json"], "retained model config bytes")
        facts = {"model_type": "deepseek_v3", "num_hidden_layers": 48, "hidden_size": 2048,
                 "moe_intermediate_size": 768, "n_routed_experts": 128, "num_experts_per_tok": 6,
                 "q_lora_rank": None, "rope_interleave": True, "n_group": 1, "topk_group": 1,
                 "n_shared_experts": 2, "first_k_dense_replace": 1, "norm_topk_prob": True,
                 "routed_scaling_factor": 2.448, "scoring_func": "sigmoid",
                 "topk_method": "noaux_tc", "rms_norm_eps": 1e-6, "rope_theta": 1000000}
        self.check(all(config.get(key) == value for key, value in facts.items()),
                   "actual official model architecture facts match the qualified tiny control")
        index = self.read("results/cache-index.json")
        self.check(digest(self.root / "results/cache-index.json") ==
                   spec["store_fingerprint"]["index.json"], "retained actual shard index bytes")
        self.report["expert_payload_arithmetic"] = expert_payload(index)
        self.report["model_count_scope"] = {
            "stored_tensor_elements": protocol["model"]["stored_tensor_elements"],
            "router_bias_buffer_elements": protocol["model"]["router_bias_buffer_elements"],
            "parameter_count_excluding_router_bias_buffers": protocol["model"]["parameter_count"],
            "index_reported_total_params": index["total_params"],
            "note": "Stored elements include 6016 frozen correction-bias buffer values; "
            "packed payload arithmetic includes nested scale sidecars and scalar offsets.",
        }
        self.check(protocol["model"]["stored_tensor_elements"] -
                   protocol["model"]["router_bias_buffer_elements"] ==
                   protocol["model"]["parameter_count"] == 30670809088,
                   "buffer-inclusive stored-element count is not mislabeled as parameter count")
        self.check(protocol["model"]["stored_tensor_elements"] * 2 ==
                   protocol["model"]["index_total_tensor_bytes"] == 61341630208,
                   "stored BF16 tensor bytes exclude safetensors header overhead")
        self.report["model_count_scope"]["source_file_header_overhead_bytes"] = (
            MODEL_BYTES - protocol["model"]["index_total_tensor_bytes"]
        )
        input_path = self.file("results/prepared/inputs.pt")
        self.check(digest(input_path) == spec["training_data_sha256"], "frozen token bytes")
        inputs = torch.load(input_path, map_location="cpu", weights_only=True)
        performance = protocol["performance"]
        arms, rounds = tuple(performance["arms"]), performance["rounds"]
        self.check(arms == ARMS, "native ordinary/two-read/cache/combined cohort identified")
        orders = ORDERS
        self.check(type(rounds) is int and rounds >= 4 and rounds % 4 == 0,
                   "complete independently reconstructed balanced schedule")
        report = self.read("results/qualification/run.json")
        self.check(report["status"] == "completed" and report["accuracy_passed"] is True,
                   "controller recorded a complete qualified experiment")
        verify_schedule(report["timing_blocks"], rounds)
        original_spec_hash = self.report["files"]["results/prepared/spec.json"]["sha256"]
        self.check(report["spec_sha256"] == original_spec_hash, "native shared spec hash")
        accuracy, reference = {}, None
        accuracy_warmup_losses = {}
        for arm in arms:
            directory = "results/qualification/accuracy/" + arm
            worker = self.worker(directory, arm, "accuracy", spec, original_spec_hash)
            capture_path = self.file(directory + "/capture.pt")
            capture_hash = self.report["files"][directory + "/capture.pt"]["sha256"]
            self.check(capture_hash == worker["accuracy"]["capture_sha256"],
                       arm + ": complete capture hash bound to its worker")
            capture = torch.load(capture_path, map_location="cpu", weights_only=True)
            self.check(len(capture["initial_adapters"]) == 288 and
                       len(capture["updates"]) == 2 and len(capture["microbatches"]) == 4,
                       arm + ": all 288 adapters and complete accumulated updates captured")
            self.check(all(torch.equal(batch["input_ids"], inputs[index])
                           for index, batch in enumerate(capture["microbatches"])),
                       arm + ": actual token inputs equal frozen inputs")
            initial, final = capture["initial_adapters"], capture["updates"][-1]["adapters"]
            self.check(all("lora_" in name and value.dtype == torch.float32 and
                           final[name].dtype == torch.float32 and
                           torch.count_nonzero(value).item() > 0 and
                           torch.count_nonzero(final[name]).item() > 0 and
                           not torch.equal(value, final[name]) for name, value in initial.items()),
                       arm + ": every adapter is nonzero and actually changed")
            self.check(all(any(torch.count_nonzero(batch["gradients"][name]).item() > 0
                                   for batch in capture["microbatches"]) for name in initial),
                       arm + ": every adapter received a nonzero gradient")
            accuracy_warmup_losses[arm] = [
                float(capture["microbatches"][index]["loss"].item()) for index in (1, 3)
            ]
            if reference is None:
                reference = capture
                gate = common.validate_capture(reference)
            else:
                gate = common.compare_captures(reference, capture)
            self.report["accuracy"][arm] = gate
            self.check(gate["passed"], arm + ": original unchanged full-trajectory gates passed")
            self.check(digest(capture_path) == capture_hash, arm + ": capture stable during audit")
            before = worker["accuracy"]["runtime_before"]["expert_cache"]
            after = worker["accuracy"]["runtime_after"]["expert_cache"]
            accuracy[arm] = counter_delta(before, after, arm)
            if arm != "ordinary":
                del capture
        del reference
        visits = {arm: row["logical_fetches"] for arm, row in accuracy.items()}
        self.check(visits["ordinary"] * 2 == visits["two_read"] * 3 and
                   visits["cache"] == visits["ordinary"] and
                   visits["two_read_cache"] == visits["two_read"],
                   "accuracy visits verify native 3:2 reads and unchanged cache-arm routing")
        self.report["accuracy_counter_deltas"] = accuracy
        blocks = {number: {} for number in range(rounds)}
        for number in range(rounds):
            for position, arm in enumerate(orders[number % len(orders)]):
                directory = f"results/qualification/timing/round-{number:02d}/{arm}"
                result = self.worker(directory, arm, "timing", spec, original_spec_hash)
                blocks[number][arm] = result
                gate = loss_gate(accuracy_warmup_losses[arm], result["warmup"]["losses"])
                self.check(gate["passed"], directory + ": warmup matches accuracy entry state")
                self.check(any(row["round"] == number and row["position"] == position and
                               row["arm"] == arm and row["result"] == result
                               for row in report["timing_blocks"]),
                           directory + ": raw worker belongs to the recorded balanced matrix")
        self.check(len(report["timing_blocks"]) == len(arms) * rounds,
                   "no missing/extra/duplicate timing workers")
        pids = [item["pid"] for item in self.report["workers"].values()]
        self.check(len(pids) == len(set(pids)), "every accuracy/timing worker has a fresh process")
        recorded_loss_gates = {}
        for number, row in blocks.items():
            for arm in arms[1:]:
                for stage in ("warmup", "timing"):
                    gate = loss_gate(row["ordinary"][stage]["losses"], row[arm][stage]["losses"])
                    recorded_loss_gates[f"round-{number}/{arm}/{stage}"] = gate
                    self.check(gate["passed"],
                               f"{number}/{arm}/{stage}: recorded loss sequence parity")
        self.report["recorded_unprofiled_loss_gates"] = recorded_loss_gates
        comparisons = [(arm, "ordinary", arm) for arm in arms[1:]]
        comparisons += [("two_read_cache_vs_" + baseline, baseline, "two_read_cache")
                        for baseline in ("two_read", "cache")]
        for key, baseline, arm in comparisons:
            pairs = [(statistics.median(row[baseline]["timing"]["update_seconds"]),
                      statistics.median(row[arm]["timing"]["update_seconds"]))
                     for row in blocks.values()]
            independent = paired_result(pairs)
            summary = report["timing_summary"]
            published = (summary["comparisons"][key] if baseline == "ordinary" else
                         summary["incremental_comparisons"][key])
            self.check(abs(published["step_time_reduction_percent"] - independent[
                "step_time_reduction_percent"]) < 1e-9 and all(abs(a - b) < 1e-9 for a, b in zip(
                    published["paired_bootstrap_95_percent"], independent[
                        "paired_bootstrap_95_percent"])) and
                published["passes_practical_2_percent_gate"] == independent[
                    "passes_practical_2_percent_gate"],
                key + ": independent paired bootstrap agrees")
            self.report["comparisons"][key] = independent
        self.report["absolute"] = {}
        for arm in arms:
            rows = [block[arm] for block in blocks.values()]
            self.report["absolute"][arm] = {
                "median_step_seconds": statistics.median([
                    value for row in rows for value in row["timing"]["update_seconds"]
                ]),
                "median_setup_seconds": statistics.median(row["setup"]["seconds"] for row in rows),
                "median_whole_entry_seconds": statistics.median(
                    row["fresh_process_wall_seconds"] for row in rows),
                "max_step_allocated_bytes": max(row["timing"]["cuda"]["peak_allocated_bytes"]
                                                for row in rows),
                "max_step_reserved_bytes": max(row["timing"]["cuda"]["peak_reserved_bytes"]
                                               for row in rows),
                "max_sampled_timing_rss_bytes": max(
                    row["timing"]["resources"]["sampled_peak_rss_bytes"] for row in rows),
                "max_process_lifetime_peak_rss_bytes": max(row["resources_after"][
                    "process_lifetime_peak_rss_bytes"] for row in rows),
                "max_observed_host_payload_bytes": max(row["timing"]["runtime_after"][
                    "expert_cache"]["host"]["payload_bytes"] for row in rows),
                "max_observed_device_payload_bytes": max(row["timing"]["runtime_after"][
                    "expert_cache"]["device"]["payload_bytes"] for row in rows),
            }
        baseline = self.report["absolute"]["ordinary"]
        self.report["setup_amortization_estimates"] = {}
        for arm in arms[1:]:
            candidate = self.report["absolute"][arm]
            saved_step = baseline["median_step_seconds"] - candidate["median_step_seconds"]
            extra_setup = candidate["median_setup_seconds"] - baseline["median_setup_seconds"]
            self.report["setup_amortization_estimates"][arm] = {
                "extra_median_setup_seconds": extra_setup,
                "median_seconds_saved_per_update": saved_step,
                "updates_to_amortize_setup": max(0, extra_setup) / saved_step if saved_step > 0
                else None,
                "scope": "Fixed measured recipe; excludes shared download/sharding; descriptive "
                "estimate, not a full-training forecast or confidence bound",
            }
        xml = self.file("results/gpu-preflight.xml")
        cases = ET.parse(xml).findall(".//testcase")
        expected_names = {
            "test_real_cuda_nf4_bf16_kanana_worker_trajectories",
            "test_real_cuda_nf4_expert_cache_preserves_complete_optimizer_trajectories[lru]",
            "test_real_cuda_nf4_expert_cache_preserves_complete_optimizer_trajectories[static]",
        }
        failed_or_skipped = any(case.find("skipped") is not None or
                                case.find("failure") is not None or case.find("error") is not None
                                for case in cases)
        self.check(len(cases) == 3 and not failed_or_skipped and
                   {case.attrib["name"] for case in cases} == expected_names and
                   set(protocol["cuda_expected_case_names"]) == expected_names,
                   "Kanana and both existing NF4 CUDA cells actually passed without skips")
        self.report["recording_limits"] = {
            "unprofiled_loss_scope": "Only last microbatch loss per update was persisted. "
            "All saved warmup/timed losses were compared; first timed microbatch: NO VERDICT. "
            "Complete numerical trajectories cover the separate four-microbatch accuracy phase.",
            "checkpoint_store_scope": "Remote fingerprints cross-checked against pinned LFS/source "
            "metadata; model/store files are absent locally and were not independently rehashed.",
            "quality_scope": "Frozen random token inputs; numerical optimization parity, not "
            "downstream quality, full-model fine-tuning or convergence evidence.",
            "memory_scope": "Cache payload, sampled stage RSS, lifetime RSS and allocator VRAM "
            "are different quantities; sampled RSS may miss short peaks.",
        }
        self.report["status"] = "passed_with_recording_limits"
        return self.report


def main() -> int:
    from rich.console import Console

    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    parser.add_argument("--retained", required=True, type=Path)
    parser.add_argument("--source-root", type=Path, default=Path.cwd())
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    audit = Audit(args.retained, args.source_root)
    audit.report["audit_script_sha256"] = digest(Path(__file__))
    code = 0
    try:
        audit.execute()
    except BaseException as exc:
        audit.report.update(status="failed", error=repr(exc), traceback=traceback.format_exc())
        code = 1
    args.out.parent.mkdir(parents=True, exist_ok=True)
    temporary = args.out.with_suffix(".incoming")
    temporary.write_text(json.dumps(audit.report, indent=2, allow_nan=False) + "\n",
                         encoding="utf-8")
    os.replace(temporary, args.out)
    Console().print({"status": audit.report["status"], "checks": len(audit.report["checks"]),
                     "out": str(args.out)})
    return code


if __name__ == "__main__":
    raise SystemExit(main())
