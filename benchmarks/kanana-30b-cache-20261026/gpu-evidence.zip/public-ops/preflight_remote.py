"""Standard-library resource gates before installing or transferring model weights."""

import importlib.util
import json
import os
import shutil
import subprocess
import time
from pathlib import Path

ROOT = Path('/root/liger')


def output(command):
    return subprocess.check_output(command, text=True, timeout=20).strip()


def main():
    result = {'passed': False, 'unix': time.time()}
    try:
        module_path = ROOT / 'repo/src/soup_cli/utils/stream_ram_cache.py'
        spec = importlib.util.spec_from_file_location('native_memory', module_path)
        memory_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(memory_module)
        constraints = []
        for version, directory in memory_module._cgroup_paths(
            Path('/proc/self/cgroup'), Path('/proc/self/mountinfo'),
        ):
            if version != 2:
                raise RuntimeError('A real cgroup-v2 RAM/swap scope is required')
            row = {'path': str(directory)}
            for name in ('memory.max', 'memory.swap.max', 'memory.swap.current'):
                value = (directory / name).read_text().strip()
                row[name] = None if value == 'max' else int(value)
            constraints.append(row)
        meminfo = {
            line.partition(':')[0]: int(line.partition(':')[2].split()[0]) * 1024
            for line in Path('/proc/meminfo').read_text().splitlines()
        }
        limits = [meminfo['MemTotal']] + [
            row['memory.max'] for row in constraints if row['memory.max'] is not None
        ]
        if not 28 * 2**30 <= min(limits) <= 32 * 2**30:
            raise RuntimeError('Require an actual 28..32 GiB physical/cgroup RAM ceiling')
        if meminfo.get('SwapTotal', 0) and not any(row['memory.swap.max'] == 0 for row in constraints):
            raise RuntimeError('Workload swap is not disabled; no global host settings are changed')
        if any(row['memory.swap.current'] != 0 for row in constraints):
            raise RuntimeError('Cgroup swap use is not zero')
        gpu = output(['nvidia-smi', '--query-gpu=uuid,name,memory.total,utilization.gpu,memory.used',
                      '--format=csv,noheader,nounits'])
        if len(gpu.splitlines()) != 1:
            raise RuntimeError('Require exactly one physical visible GPU')
        uuid, name, total, utilization, used = [item.strip() for item in gpu.split(',')]
        applications = output(['nvidia-smi', '--query-compute-apps=gpu_uuid,pid,used_memory',
                               '--format=csv,noheader,nounits'])
        if not 7900 <= int(total) <= 8300 or int(utilization) > 10 or int(used) > 256:
            raise RuntimeError('Physical 8 GiB GPU is not idle')
        if any(line.startswith(uuid) for line in applications.splitlines()):
            raise RuntimeError('Another GPU process is present; never terminate it')
        if shutil.disk_usage('/data').free < 130 * 2**30:
            raise RuntimeError('Require at least 130 GiB local volume free before downloading weights')
        if shutil.disk_usage(ROOT).free < 12 * 2**30 or meminfo['MemAvailable'] < 12 * 2**30:
            raise RuntimeError('Insufficient available setup disk/RAM')
        mount = output(['findmnt', '-T', '/data', '-o', 'TARGET,SOURCE,FSTYPE,OPTIONS'])
        result.update(passed=True, gpu_uuid=uuid, gpu_name=name, gpu_memory_mib=int(total),
                      native_ram_limit_bytes=min(limits), memory_constraints=constraints,
                      host_meminfo=meminfo, process_cgroup=Path('/proc/self/cgroup').read_text(),
                      mount=mount, physical_nvme_verified=False,
                      storage_scope='Container mount retained; physical NVMe backing is unverified',
                      data_free_bytes=shutil.disk_usage('/data').free,
                      root_free_bytes=shutil.disk_usage(ROOT).free,
                      container_id=os.environ.get('CONTAINER_ID'))
    except BaseException as exc:
        result['error'] = f'{type(exc).__name__}: {exc}'
        raise
    finally:
        (ROOT / 'results').mkdir(parents=True, exist_ok=True)
        (ROOT / 'results/capacity-preflight.json').write_text(json.dumps(result, indent=2) + '\n')


if __name__ == '__main__':
    main()
