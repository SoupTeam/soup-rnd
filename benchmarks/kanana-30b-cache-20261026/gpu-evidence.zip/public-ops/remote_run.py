"""Pinned Kanana-30B native four-arm qualification with unchanged admission and raw retention."""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import traceback
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path('/root/liger')
REPO = ROOT / 'repo'
OUT = ROOT / 'results'
MODEL = 'kakaocorp/kanana-2-30b-a3b-base-2601'
REVISION = '0d31365acf656e5f9a593cacc4913e9c0d36cb1c'
SOURCE_BYTES = 61343935088


def digest(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for chunk in iter(lambda: handle.read(8 * 2**20), b''):
            value.update(chunk)
    return value.hexdigest()


def retain_exact_metadata(source, destination, expected_sha256):
    """Retain original metadata bytes only when their frozen identity remains stable."""
    source, destination = Path(source), Path(destination)
    temporary = destination.with_name(destination.name + '.incoming')
    if destination.exists() or destination.is_symlink() or temporary.exists() or temporary.is_symlink():
        raise FileExistsError('Refuse replacing existing retained metadata')
    before = source.stat()
    if digest(source) != expected_sha256:
        raise ValueError('Metadata source differs from its prepared fingerprint')
    try:
        shutil.copyfile(source, temporary)
        if temporary.stat().st_size != before.st_size or digest(temporary) != expected_sha256:
            raise ValueError('Copied metadata differs from its prepared fingerprint')
        after = source.stat()
        if (after.st_size != before.st_size or after.st_mtime_ns != before.st_mtime_ns
                or digest(source) != expected_sha256):
            raise ValueError('Metadata source changed while retaining its bytes')
        with temporary.open('r+b') as retained:
            retained.flush()
            os.fsync(retained.fileno())
        if destination.exists() or destination.is_symlink():
            raise FileExistsError('Retained metadata destination appeared during copying')
        os.replace(temporary, destination)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return {'bytes': before.st_size, 'sha256': expected_sha256}


def save(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)


def command(name, arguments, *, timeout=7200):
    save(OUT / 'stage-status.json', {'status': 'running', 'phase': name, 'unix': time.time()})
    with (OUT / (name + '.log')).open('wb') as log:
        process = subprocess.run(arguments, cwd=REPO, stdout=log, stderr=subprocess.STDOUT,
                                 timeout=timeout)
    save(OUT / (name + '-exit.json'), {'returncode': process.returncode, 'unix': time.time()})
    if process.returncode:
        raise RuntimeError(f'{name} failed with exit code {process.returncode}')


def export(status):
    import lossless_results

    export_dir = ROOT / 'exports'
    export_dir.mkdir(exist_ok=True)
    archive = export_dir / 'result.lossless.tar'
    files = [path for path in OUT.rglob('*') if path.is_file()]
    files += [ROOT / name for name in ('setup.log', 'source-manifest.json', 'constraints.txt',
                                      'preflight_remote.py', 'remote_run.py', 'setup.sh',
                                      'protocol.json',
                                      'lossless_results.py')
              if (ROOT / name).is_file()]
    names = [path.relative_to(ROOT).as_posix() for path in files]
    packed = lossless_results.pack(ROOT, names, archive)
    mapping = {path.relative_to(ROOT).as_posix(): {
        'bytes': path.stat().st_size, 'sha256': digest(path),
    } for path in files}
    save(export_dir / 'archive-manifest.json', {
        'format': packed['format'], 'archive_bytes': packed['archive_bytes'],
        'sha256': packed['archive_sha256'], 'original_bytes': packed['original_bytes'],
        'files': mapping,
        'source_commit': json.loads((ROOT / 'source-manifest.json').read_text())['source_commit'],
        'stage_status': status,
    })


def validate_cuda_xml(path, expected_names):
    cases = ET.parse(path).findall('.//testcase')
    if len(cases) != len(expected_names) or any(
        case.find('skipped') is not None or case.find('failure') is not None
        or case.find('error') is not None for case in cases
    ):
        raise RuntimeError('All three required native CUDA cells must actually pass, without skips')
    if {case.attrib['name'] for case in cases} != set(expected_names):
        raise RuntimeError('CUDA XML differs from the frozen Kanana/NF4 preflight selection')


def main():
    OUT.mkdir(exist_ok=True)
    final = {'status': 'failed', 'phase': 'initializing', 'unix': time.time()}
    try:
        protocol = json.loads((ROOT / 'protocol.json').read_text())
        manifest = json.loads((ROOT / 'source-manifest.json').read_text())
        if digest(ROOT / 'source.tar.gz') != manifest['archive_sha256']:
            raise RuntimeError('Deployed source archive changed')
        for name, row in manifest['files'].items():
            if digest(REPO / name) != row['sha256']:
                raise RuntimeError('Deployed source bytes differ: ' + name)
        if subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() != (
            manifest['source_commit']
        ):
            raise RuntimeError('Deployed Git HEAD differs from frozen source')
        with (OUT / 'pip-freeze.txt').open('wb') as handle:
            subprocess.run([sys.executable, '-m', 'pip', 'freeze'], stdout=handle, check=True)
        # Run actual CUDA kernels and the real full-query BF16 graph before the 61.34 GB checkpoint download.
        gpu_tests = protocol['cuda_test_selectors']
        command('gpu-preflight', [sys.executable, '-m', 'pytest', *gpu_tests,
                                  '-q', '-o', 'addopts=', '--tb=short',
                                  '--basetemp=' + str(OUT / 'pytest-tmp'),
                                  '--junitxml=' + str(OUT / 'gpu-preflight.xml')], timeout=900)
        validate_cuda_xml(OUT / 'gpu-preflight.xml', protocol['cuda_expected_case_names'])
        save(OUT / 'stage-status.json', {'status': 'running', 'phase': 'download', 'unix': time.time()})
        from huggingface_hub import HfApi, snapshot_download

        info = HfApi().model_info(MODEL, revision=REVISION, files_metadata=True)
        model_files = [item for item in info.siblings if item.rfilename.endswith('.safetensors')]
        if (info.sha != REVISION or len(model_files) != protocol['model']['weight_shards']
                or sum(item.size for item in model_files) != SOURCE_BYTES):
            raise RuntimeError('Public pinned checkpoint identity or size changed')
        for item in model_files:
            sha = item.lfs.get('sha256') if isinstance(item.lfs, dict) else getattr(item.lfs, 'sha256', None)
            if not isinstance(sha, str) or re.fullmatch('[0-9a-f]{64}', sha) is None:
                raise RuntimeError('Pinned checkpoint shard is missing its public LFS SHA256')
        pinned = {
            'repo_id': MODEL, 'revision': info.sha, 'weights_bytes': SOURCE_BYTES,
            'files': {item.rfilename: {'bytes': item.size, 'lfs': item.lfs}
                      for item in model_files},
        }
        # LFS metadata objects are dataclasses in some Hub releases.
        save(OUT / 'model-pinned.json', json.loads(json.dumps(pinned, default=lambda obj: vars(obj))))
        download_started = time.perf_counter()
        weights = snapshot_download(MODEL, revision=REVISION, local_dir='/data/kanana30b',
                                    allow_patterns=['*.json', '*.safetensors'], max_workers=4)
        for item in model_files:
            path = Path(weights) / item.rfilename
            if path.stat().st_size != item.size:
                raise RuntimeError('Incomplete checkpoint file: ' + item.rfilename)
            sha = item.lfs.get('sha256') if isinstance(item.lfs, dict) else getattr(item.lfs, 'sha256', None)
            if digest(path) != sha:
                raise RuntimeError('Checkpoint LFS SHA mismatch: ' + item.rfilename)
        save(OUT / 'model-download.json', {'seconds': time.perf_counter() - download_started,
                                           'source_bytes': SOURCE_BYTES, 'revision': REVISION})
        command('prepare', [sys.executable, 'benchmarks/harness/two_read_cache.py', 'prepare',
                           '--weights', weights, '--shards', '/data/kanana30b-nf4-experts',
                           '--out', str(OUT / 'prepared'), '--host-cache-gib', '8',
                           '--device-cache-gib', '2', '--max-host-gib', '32',
                           '--seq-len', '512', '--batch-size', '1', '--accumulation', '2',
                           '--accuracy-updates', '2', '--warmup-updates', '2',
                           '--timed-updates', '6', '--rounds', '4',
                           '--host-cache-policy', 'static'], timeout=1200)
        prepared = json.loads((OUT / 'prepared/spec.json').read_text())
        retain_exact_metadata(Path(weights) / 'config.json', OUT / 'model-config.json',
                              prepared['model_fingerprint']['config.json'])
        retain_exact_metadata(Path('/data/kanana30b-nf4-experts/index.json'), OUT / 'cache-index.json',
                              prepared['store_fingerprint']['index.json'])
        command('qualification', [sys.executable, 'benchmarks/harness/two_read_cache.py', 'run',
                                  '--spec', str(OUT / 'prepared/spec.json'),
                                  '--out', str(OUT / 'qualification')], timeout=9000)
        final = {'status': 'completed', 'phase': 'complete', 'unix': time.time()}
    except BaseException as exc:
        final = {'status': 'failed', 'phase': 'failed', 'error': f'{type(exc).__name__}: {exc}',
                 'traceback': traceback.format_exc(), 'unix': time.time()}
        save(OUT / 'failure.json', final)
    finally:
        save(OUT / 'stage-status.json', {**final, 'archive_ready': False})
        export(final)
        save(OUT / 'stage-status.json', {**final, 'archive_ready': True})
    return 0 if final['status'] == 'completed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
