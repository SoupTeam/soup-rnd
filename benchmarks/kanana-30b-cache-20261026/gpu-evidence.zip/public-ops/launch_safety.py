"""Pure local Kanana protocol checks before any root-authorized paid lease."""

from __future__ import annotations

import re

MODEL = "kakaocorp/kanana-2-30b-a3b-base-2601"
REVISION = "0d31365acf656e5f9a593cacc4913e9c0d36cb1c"
KANANA_TEST = "tests/test_two_read_cache_kanana.py::test_real_cuda_nf4_bf16_kanana_worker_trajectories"
NF4_TEST = "tests/test_stream_expert_cache_nf4.py::test_real_cuda_nf4_expert_cache_preserves_complete_optimizer_trajectories"


def validate_protocol(protocol, *, source_commit, stage_id):
    if (not re.fullmatch("[0-9a-f]{40}", source_commit)
            or protocol.get("source_commit") != source_commit
            or protocol.get("stage_id") != stage_id or protocol.get("accuracy_first") is not True):
        raise ValueError("Protocol source/stage identity is unresolved or differs from frozen source")
    model = protocol.get("model", {})
    if (model.get("repo_id") != MODEL or model.get("revision") != REVISION
            or model.get("weight_shards") != 13 or model.get("weights_bytes") != 61343935088):
        raise ValueError("Pinned public Kanana checkpoint identity changed")
    selectors = protocol.get("cuda_test_selectors")
    expected_names = {KANANA_TEST.rsplit("::", 1)[-1], NF4_TEST.rsplit("::", 1)[-1] + "[lru]",
                      NF4_TEST.rsplit("::", 1)[-1] + "[static]"}
    if (not isinstance(selectors, list) or len(selectors) != 2
            or set(selectors) != {KANANA_TEST, NF4_TEST}
            or set(protocol.get("cuda_expected_case_names", [])) != expected_names):
        raise ValueError("Required Kanana and two native NF4 policy CUDA cells changed")
    performance = protocol.get("performance", {})
    expected = {"rounds": 4, "warmup_updates": 2, "timed_updates": 6, "accuracy_updates": 2,
                "accumulation": 2, "host_cache_bytes": 8 * 2**30, "device_cache_bytes": 2 * 2**30,
                "sequence_length": 512, "batch_size": 1}
    if (performance.get("runner") != "benchmarks/harness/two_read_cache.py"
            or performance.get("host_cache_policy") != "static"
            or performance.get("arms") != ["ordinary", "two_read", "cache", "two_read_cache"]
            or any(type(performance.get(key)) is not int or performance[key] != value
                   for key, value in expected.items())):
        raise ValueError("Frozen native four-arm accuracy/timing/cache-ceiling protocol changed")
    if protocol.get("admission_fallback_allowed") is not False:
        raise ValueError("Cache admission must fail closed without a silent smaller-budget fallback")
    financial = protocol.get("financial", {})
    expected_financial = {"maximum_stage_usd": 5.169487974758529, "prior_usd": 0,
                          "maximum_seconds": 14400, "root_provider_gb": 150,
                          "volume_provider_gb": 150, "download_allowance_decimal_gb": 100,
                          "upload_allowance_decimal_gb": 20}
    if financial != expected_financial:
        raise ValueError("Frozen four-hour budget/disk/network boundary changed")
    return {"source_commit": source_commit, "model": MODEL, "revision": REVISION,
            "arms": performance["arms"], "rounds": 4, "cuda_cells": 3}
