# Exact-byte compact evidence

files.json maps every logical original path to a stored ZIP member, byte count, SHA-256 and provenance. Byte-identical originals share one member. Before an alias is accepted its complete source bytes are compared with that member; all logical files are independently hash/size checked after writing. Restore a logical path from its row's member and verify bytes/sha256; no original allowed by the packet selection is dropped. files.json itself is bound by the external archive/index hashes.
