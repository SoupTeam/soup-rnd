"""Public HF metadata only; no authentication, model tensors, GPU or cloud API."""
from __future__ import annotations
import datetime,hashlib,json,pathlib,urllib.request
ROOT=pathlib.Path(__file__).parent
REPO='kakaocorp/kanana-2-30b-a3b-base-2601'

def get(url,limit):
    request=urllib.request.Request(url,headers={'User-Agent':'Soup-model-metadata-preflight/1','Accept-Encoding':'identity'})
    with urllib.request.urlopen(request,timeout=45)as response:
        length=response.headers.get('Content-Length')
        if length is not None and int(length)>limit:raise ValueError('Metadata exceeds bounded read size')
        raw=response.read(limit+1)
        if len(raw)>limit:raise ValueError('Metadata response exceeds read ceiling')
        return raw,{'url':url,'http_status':response.status,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'etag':response.headers.get('ETag')}

def main():
    api='https://huggingface.co/api/models/'+REPO+'?blobs=true'
    raw,identity=get(api,8*2**20);meta=json.loads(raw)
    revision=meta['sha']
    assert len(revision)==40 and meta['gated']is False and meta.get('private')is False
    (ROOT/'hf-api-main.json').write_bytes(raw)
    records={'hf-api-main.json':identity}
    for remote,local,limit in [('config.json','config.json',2**20),('model.safetensors.index.json','index.json',8*2**20),('LICENSE','LICENSE',2**20),('README.md','README.md',2**20)]:
        url='https://huggingface.co/'+REPO+'/resolve/'+revision+'/'+remote
        content,entry=get(url,limit)
        (ROOT/local).write_bytes(content);records[local]=entry
    config=json.loads((ROOT/'config.json').read_bytes());index=json.loads((ROOT/'index.json').read_bytes())
    weights={item['rfilename']:{key:item.get(key)for key in ('size','blobId','lfs')}for item in meta['siblings']if item['rfilename'].endswith('.safetensors')}
    assert set(index['weight_map'].values())==set(weights)
    total=sum(row['size']for row in weights.values())
    result={'schema_version':1,'observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repository':REPO,'revision':revision,'public':meta.get('private')is False,'gated':meta.get('gated'),'anonymous_metadata_access_verified':True,'account_terms_acceptance_performed':False,'authentication_sent':False,'model_tensor_payload_downloaded':False,'weights_file_bytes_including_headers':total,'weight_shards':weights,'weight_shard_count':len(weights),'safetensor_index_total_tensor_bytes':index['metadata']['total_size'],'safetensors_api':meta.get('safetensors'),'documents':records,'configuration':config,'quantization_config_absent':'quantization_config'not in config,'license':{'card_license':meta.get('cardData',{}).get('license'),'license_name':meta.get('cardData',{}).get('license_name'),'local_file':'LICENSE','note':'Public non-gated access does not replace model-license obligations; no account acceptance was performed'},'notes':['Tensor dtypes/counts will be independently verified from bounded public safetensors headers','Architecture/config match alone does not qualify accuracy, RAM or VRAM fit']}
    (ROOT/'model-preflight.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({key:result[key]for key in ('repository','revision','public','gated','weights_file_bytes_including_headers','weight_shard_count','safetensor_index_total_tensor_bytes','safetensors_api','quantization_config_absent')},indent=2))

if __name__=='__main__':main()
