"""Read bounded safetensors header ranges only; never reads tensor payloads."""
from __future__ import annotations
import collections,hashlib,json,math,pathlib,re,struct,time,urllib.request
ROOT=pathlib.Path(__file__).parent

def read_range(url,start,end,total):
    requested=url+'?download=true&metadata_probe='+str(time.time_ns())
    request=urllib.request.Request(requested,headers={'Range':f'bytes={start}-{end}','Accept-Encoding':'identity','User-Agent':'Soup-model-header-preflight/1','Cache-Control':'no-cache'})
    with urllib.request.urlopen(request,timeout=45)as response:
        want=f'bytes {start}-{end}/{total}'
        if response.status!=206 or response.headers.get('Content-Range')!=want:
            raise RuntimeError(f'Bounded range unsupported: status={response.status},range={response.headers.get("Content-Range")}')
        size=end-start+1
        raw=response.read(size+1)
        if len(raw)!=size:raise RuntimeError('Bounded header range length differs')
        return raw

def main():
    result=json.loads((ROOT/'model-preflight.json').read_text())
    index=json.loads((ROOT/'index.json').read_text());where=index['weight_map']
    header_dir=ROOT/'safetensors-headers';header_dir.mkdir(exist_ok=True)
    tensors={};records={};total_network=0
    for filename,info in sorted(result['weight_shards'].items()):
        url='https://huggingface.co/'+result['repository']+'/resolve/'+result['revision']+'/'+filename
        prefix=read_range(url,0,7,info['size']);length=struct.unpack('<Q',prefix)[0]
        if not 1<=length<=2**20:raise ValueError('Header exceeds 1 MiB preflight ceiling')
        raw=read_range(url,8,7+length,info['size']);header=json.loads(raw)
        payload_size=info['size']-8-length
        actual={key for key in header if key!='__metadata__'}
        expected={key for key,file in where.items()if file==filename}
        assert actual==expected,(filename,'header/index tensor names mismatch')
        spans=[]
        for key in actual:
            entry=header[key];lo,hi=entry['data_offsets']
            assert 0<=lo<=hi<=payload_size,(filename,key,'range')
            assert entry['dtype']=='BF16',(key,entry['dtype'])
            assert hi-lo==math.prod(entry['shape'])*2,(key,'dtype/shape/span')
            spans.append((lo,hi));tensors[key]={'dtype':entry['dtype'],'shape':entry['shape'],'bytes':hi-lo,'source_file':filename}
        spans.sort();assert spans[0][0]==0 and spans[-1][1]==payload_size
        assert all(left[1]==right[0]for left,right in zip(spans,spans[1:])),filename
        (header_dir/(filename+'.header.json')).write_bytes(raw)
        records[filename]={'url':url,'header_length_bytes':length,'ranges':[[0,7],[8,7+length]],'header_sha256':hashlib.sha256(raw).hexdigest(),'tensor_count':len(actual),'tensor_payload_bytes':payload_size,'http_range_206_exact':True}
        total_network+=length+8
    assert set(tensors)==set(where)
    tensor_bytes=sum(entry['bytes']for entry in tensors.values());elements=tensor_bytes//2
    assert tensor_bytes==result['safetensor_index_total_tensor_bytes']
    assert elements==result['safetensors_api']['total']
    cfg=result['configuration'];layers=cfg['num_hidden_layers'];first=cfg['first_k_dense_replace'];E=cfg['n_routed_experts'];H=cfg['hidden_size'];I=cfg['moe_intermediate_size']
    targets={target:{}for target in ('q_proj','kv_b_proj','o_proj')};expert_count=0
    for layer in range(layers):
        for target in targets:
            key=f'model.layers.{layer}.self_attn.{target}.weight'
            targets[target][str(layer)]=tensors[key]
        if layer>=first:
            for expert in range(E):
                for part,shape in (('gate_proj',[I,H]),('up_proj',[I,H]),('down_proj',[H,I])):
                    key=f'model.layers.{layer}.mlp.experts.{expert}.{part}.weight'
                    assert tensors[key]['shape']==shape,(key,tensors[key]['shape'])
                expert_count+=1
    def nf4_bytes(n):
        blocks=(n+63)//64
        return (n+1)//2+blocks+((blocks+255)//256)*4+4
    packed=nf4_bytes(2*I*H)+nf4_bytes(H*I);dense=3*I*H*2
    payload_all=expert_count*packed
    budgets={}
    for gpu_gib in (1.5,2):
        gpu_slots=int(gpu_gib*2**30//dense)
        budgets[str(gpu_gib)]={'dense_gpu_budget_bytes':int(gpu_gib*2**30),'dense_experts_fitting_payload_only':gpu_slots,'dense_payload_bytes':gpu_slots*dense,'remaining_packed_experts':expert_count-gpu_slots,'remaining_host_payload_bytes':(expert_count-gpu_slots)*packed,'host_8gib_experts_fitting_payload_only':int(8*2**30//packed),'host_8gib_covers_all_remaining_experts':(expert_count-gpu_slots)*packed<=8*2**30}
    result['header_verification']={'all_source_headers_verified':True,'header_shards':records,'total_header_network_bytes':total_network,'all_stored_tensor_dtypes':['BF16'],'total_stored_tensor_elements':elements,'total_stored_tensor_bytes':tensor_bytes,'total_file_overhead_bytes':result['weights_file_bytes_including_headers']-tensor_bytes,'index_names_match_all_headers':True,'all_dtype_shapes_match_byte_spans':True,'tensor_payload_downloaded_bytes':0}
    result['projection_header_verification']={'targets':targets,'counts':{key:len(value)for key,value in targets.items()},'all_source_layers_verified':True,'embedding':tensors['model.embed_tokens.weight'],'output_head':tensors['lm_head.weight']}
    result['expert_capacity_arithmetic']={'scope':'Payload arithmetic only, not whole-process RAM or VRAM admission, accuracy, or speed proof','routed_expert_count':expert_count,'dense_gate_up_shape':[2*I,H],'dense_down_shape':[H,I],'dense_bf16_bytes_per_expert':dense,'nf4_double_quant_bytes_per_expert':packed,'all_routed_nf4_payload_bytes':payload_all,'candidates':budgets,'requires_real_native_setup_probes':True}
    (ROOT/'model-preflight.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'revision':result['revision'],'tensor_bytes':tensor_bytes,'elements_all_BF16':elements,'header_network_bytes':total_network,'tensor_count':len(tensors),'LoRA_target_counts':{key:len(value)for key,value in targets.items()},'expert_capacity_arithmetic':result['expert_capacity_arithmetic']},indent=2))

if __name__=='__main__':main()
