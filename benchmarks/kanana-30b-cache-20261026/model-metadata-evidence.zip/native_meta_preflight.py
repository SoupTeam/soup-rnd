"""No-network, no-storage meta skeleton inspection of the frozen source config."""
from __future__ import annotations

import hashlib
import importlib.metadata
import inspect
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path(__file__).parent
SOURCE = Path(r"C:\Users\esenb\.codex\worktrees\cache-recompute-20261025\soup-rnd-d2")
DEPS = Path(r"C:\Users\esenb\Documents\SoupResearch\two-read-expert-cache-20261025\.deps")
sys.path[:0] = [str(SOURCE / "src"), str(DEPS)]
os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"


def main():
    import psutil
    import torch
    from transformers.models.deepseek_v3 import modeling_deepseek_v3 as native
    from soup_cli.utils.layer_stream_runtime import build_meta_skeleton

    torch.set_num_threads(1)
    process = psutil.Process()
    before = process.memory_info().rss
    started = time.perf_counter()
    # init_empty_weights alone can allocate a temporary fused expert on CPU.
    # Force bare factories to meta as well, with no source tensor materialization.
    with torch.device("meta"):
        model = build_meta_skeleton(str(ROOT), dtype="bfloat16", quant="nf4")
    elapsed = time.perf_counter() - started
    after = process.memory_info().rss
    params = dict(model.named_parameters())
    buffers = dict(model.named_buffers())
    assert params and all(p.is_meta for p in params.values())
    assert all(b.is_meta for b in buffers.values()), [n for n, b in buffers.items() if not b.is_meta]
    assert model.config.q_lora_rank is None
    assert model.config.rope_interleave is True
    assert model.is_loaded_in_4bit is True
    assert model.is_quantized is True
    result = json.loads((ROOT / "model-preflight.json").read_text())
    cfg = result["configuration"]
    targets = result["projection_header_verification"]["targets"]
    target_classes = {}
    for target, records in targets.items():
        for layer, entry in records.items():
            module = model.get_submodule(f"model.layers.{layer}.self_attn.{target}")
            assert list(module.weight.shape) == entry["shape"]
            assert module.weight.is_meta
            assert module.__class__.__name__ == "Linear4bit"
            target_classes.setdefault(target, set()).add(module.__class__.__name__)
    for i in range(cfg["first_k_dense_replace"], cfg["num_hidden_layers"]):
        experts = model.model.layers[i].mlp.experts
        assert list(experts.gate_up_proj.shape) == [128, 1536, 2048]
        assert list(experts.down_proj.shape) == [128, 2048, 768]
    native_file = Path(inspect.getfile(native))
    lines = native_file.read_text().splitlines()
    interleave_lines = [i + 1 for i, line in enumerate(lines) if "if self.config.rope_interleave" in line]
    assert interleave_lines
    record = {
        "model_class": type(model).__name__,
        "configuration_class": type(model.config).__name__,
        "exact_frozen_config_path": str(ROOT / "config.json"),
        "configuration_modified_for_structure_only": {"use_cache": False, "nf4_markers": True},
        "trust_remote_code": False,
        "hf_offline": True,
        "outer_default_device": "meta",
        "all_parameters_meta": True,
        "all_buffers_meta": True,
        "parameter_tensor_count": len(params),
        "parameter_elements": sum(p.numel() for p in params.values()),
        "buffer_tensor_count": len(buffers),
        "buffer_elements": sum(b.numel() for b in buffers.values()),
        "native_rope_interleave_supported": True,
        "native_source": str(native_file),
        "native_source_sha256": hashlib.sha256(native_file.read_bytes()).hexdigest(),
        "native_rope_interleave_if_lines": interleave_lines,
        "lora_target_module_counts": {target: len(records) for target, records in targets.items()},
        "lora_target_classes": {key: sorted(value) for key, value in target_classes.items()},
        "all_lora_target_shapes_match_source_headers": True,
        "all_47_fused_expert_shapes_match_source_headers": True,
        "quantized_source_checkpoint": False,
        "nf4_skeleton_markers_verified": True,
        "rss_before_skeleton_bytes": before,
        "rss_after_skeleton_bytes": after,
        "elapsed_seconds": elapsed,
        "packages": {name: importlib.metadata.version(name) for name in ("torch", "transformers", "bitsandbytes", "accelerate")},
        "scope": "Structure-only CPU meta check; no numerical, GPU, RAM-fit or VRAM-fit qualification",
        "source_model_weights_loaded": False,
    }
    (ROOT / "native-meta-preflight.json").write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    result["native_meta_preflight"] = record
    result["notes"] = [
        "All source BF16 tensor names, shapes and bytes independently verified from bounded HTTP206 safetensors headers",
        "Native Transformers NF4 meta skeleton validated offline against frozen config and header projection/expert shapes",
        "Architecture/structure/capacity arithmetic does not qualify accuracy, RAM or VRAM fit; actual four-arm GPU gates remain mandatory",
    ]
    (ROOT / "model-preflight.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(record, indent=2))


if __name__ == "__main__":
    main()
