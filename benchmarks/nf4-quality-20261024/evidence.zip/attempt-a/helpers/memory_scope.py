"""Require a real existing <=32 GiB RAM bound and no swap; never alter host settings."""

import argparse
import json
import subprocess
import time
from pathlib import Path

from rich.console import Console

LIMIT_BYTES = 32 * 2**30


def validate(total, hard, swap):
    effective = min(total, hard)
    if not 28 * 2**30 <= effective <= LIMIT_BYTES or swap != 0:
        raise RuntimeError("Require a real physical/cgroup 28..32 GiB RAM bound and zero swap")
    return {
        "limit_enforced": True,
        "requested_ram_upper_bound_bytes": LIMIT_BYTES,
        "effective_ram_upper_bound_bytes": effective,
        "host_mem_total_bytes": total,
        "native_cgroup_limit_bytes": hard,
        "swap_total_bytes": swap,
        "method": "PHYSICAL_32GB_CLASS_NO_SWAP"
        if total <= LIMIT_BYTES
        else "EXISTING_NATIVE_CGROUP_LE_32GIB_NO_SWAP",
        "parent_limits_and_system_settings_unchanged": True,
    }


def observation():
    memory = {
        name.rstrip(":"): int(value) * 1024
        for name, value, unit in (
            line.split()
            for line in Path("/proc/meminfo").read_text().splitlines()
            if line.startswith(("MemTotal:", "SwapTotal:"))
        )
    }
    native = []
    for filename in ("/sys/fs/cgroup/memory.max", "/sys/fs/cgroup/memory/memory.limit_in_bytes"):
        file = Path(filename)
        if file.is_file() and file.read_text().strip() != "max":
            native.append(int(file.read_text()))
    report = validate(memory["MemTotal"], min(native, default=2**63 - 1), memory["SwapTotal"])
    report["proc_self_cgroup"] = Path("/proc/self/cgroup").read_text()
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--probe", action="store_true")
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    report = observation()
    report["started_unix"] = time.time()
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2) + "\n")
    if args.probe:
        Console().print(report)
        return 0
    command = args.command[1:] if args.command[:1] == ["--"] else args.command
    if not command:
        parser.error("a worker command is required")
    child = subprocess.Popen(command)
    report["worker_pid"] = child.pid
    code = child.wait()
    report.update(finished_unix=time.time(), worker_exit_code=code)
    args.report.write_text(json.dumps(report, indent=2) + "\n")
    return code


if __name__ == "__main__":
    raise SystemExit(main())
