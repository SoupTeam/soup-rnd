"""Controls for dataset integrity, real resource bounds and study decision gates."""

import copy
import json
import math
from pathlib import Path

import numpy as np
import pytest
from rich.console import Console

from memory_scope import validate
from prepare_model import configuration, ensure_tokens, write_data
from quality_analysis import compare, score
from timing_analysis import summarize

ROOT = Path(__file__).parent


@pytest.mark.parametrize(
    "total,hard,swap,allowed",
    [
        (31, 64, 0, True),
        (64, 32, 0, True),
        (64, 42, 0, False),
        (31, 64, 1, False),
        (27, 32, 0, False),
        (33, 64, 0, False),
    ],
)
def test_real_bound(total, hard, swap, allowed):
    if allowed:
        assert validate(total * 2**30, hard * 2**30, swap)["limit_enforced"]
    else:
        with pytest.raises(RuntimeError):
            validate(total * 2**30, hard * 2**30, swap)


def test_native_data_path(tmp_path, monkeypatch):
    from soup_cli.config.schema import SoupConfig
    from soup_cli.data.loader import load_dataset
    from soup_cli.trainer.sft import _maybe_load_pretokenized

    (tmp_path / "repo").mkdir()
    monkeypatch.chdir(tmp_path / "repo")
    for name in ("train.jsonl", "data-manifest.json"):
        (tmp_path / name).write_bytes((ROOT / name).read_bytes())
    write_data(tmp_path / "train.jsonl")
    payload = configuration(tmp_path, 32, "nf4", "disk")
    ensure_tokens(tmp_path, payload)
    config = SoupConfig.model_validate(payload)
    loaded = load_dataset(config.data)
    assert len(loaded["train"]) == 128
    train, validation = _maybe_load_pretokenized(
        config.data, config.base, Console(), config.training, task="sft"
    )
    assert len(train) == 128 and validation is None
    expected = [json.loads(line) for line in (ROOT / "train.jsonl").read_text().splitlines()]
    for i, row in enumerate(expected):
        assert train[i] == row
        assert len(row["input_ids"]) == len(row["attention_mask"]) == len(row["labels"]) == 512
        positions = [j for j, value in enumerate(row["labels"]) if value != -100]
        assert len(positions) == 2
        assert row["labels"][positions[0]] in (32, 33)
        assert row["labels"][positions[1]] == 151645
        assert all(row["labels"][j] == row["input_ids"][j] for j in positions)
        assert all(
            mask or label == -100 for mask, label in zip(row["attention_mask"], row["labels"])
        )
    changed = copy.deepcopy(config)
    changed.data.max_length = 256
    with pytest.raises(ValueError, match="cache hash mismatch"):
        _maybe_load_pretokenized(
            changed.data, changed.base, Console(), changed.training, task="sft"
        )
    (tmp_path / "train.jsonl").write_text("altered")
    with pytest.raises(ValueError, match="changed"):
        write_data(tmp_path / "train.jsonl")


def test_metrics_and_refusals():
    rows = [
        {"id": str(i), "choice_ids": [32, 33], "gold_choice": i, "answer": bool(i)}
        for i in range(2)
    ]
    values = np.zeros((2, 151936), dtype=np.float32)
    uniform = score(values, rows)
    assert uniform["answer_nll"] == pytest.approx(math.log(151936), abs=1e-9)
    assert uniform["accuracy"] == 0.5 and uniform["unrestricted_accuracy"] == 0
    values[0, 32], values[1, 33] = 4, 4
    values[:, 100] = 5
    correct = score(values, rows)
    assert correct["accuracy"] == 1 and correct["unrestricted_accuracy"] == 0
    assert compare(uniform, correct)["accuracy_delta_percentage_points"] == 50
    with pytest.raises(ValueError, match="identical"):
        compare(uniform, score(values, rows[::-1]))
    values[0, 0] = np.nan
    with pytest.raises(ValueError, match="finite"):
        score(values, rows)


def timing_pairs():
    orders = [
        ["baseline", "resident"],
        ["resident", "baseline"],
        ["resident", "baseline"],
        ["baseline", "resident"],
    ]
    info = {
        "whole_run_peak_allocated_bytes": 1,
        "whole_run_peak_reserved_bytes": 2,
        "host_memory_at_exit": {"max_rss_bytes": 3},
        "whole_entry_seconds": 20,
        "whole_setup_seconds": 2,
    }
    return [
        {
            "pair": i,
            "order": order,
            "seconds": {"baseline": [10] * 4, "resident": [8] * 4},
            "provenance": {"baseline": info, "resident": info},
        }
        for i, order in enumerate(orders)
    ]


def test_timing_gate_controls():
    pairs = timing_pairs()
    assert summarize(pairs)["practical_speed_gate_passed"]
    pairs[0]["seconds"]["resident"] = [12] * 4
    assert not summarize(pairs)["practical_speed_gate_passed"]
    pairs = timing_pairs()
    pairs[0]["seconds"]["resident"][0] = float("nan")
    with pytest.raises(ValueError, match="finite"):
        summarize(pairs)
    pairs = timing_pairs()
    pairs[1]["order"].reverse()
    with pytest.raises(ValueError, match="order"):
        summarize(pairs)


def test_dataset_split_disjoint():
    rows = [
        [json.loads(line) for line in (ROOT / name).read_text().splitlines()]
        for name in ("boolq-train-selected.jsonl", "boolq-validation-selected.jsonl")
    ]
    assert [len(x) for x in rows] == [128, 256]
    assert not ({x["id"] for x in rows[0]} & {x["id"] for x in rows[1]})
