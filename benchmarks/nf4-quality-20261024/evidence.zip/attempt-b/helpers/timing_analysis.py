"""Original trajectory predicates and prospectively fixed four-pair speed gate."""

import json
import math
import random
import statistics

from replay_cache_core import compare_files


def trajectory(reference, candidate):
    rows = [json.loads((path / "metrics.json").read_bytes()) for path in (reference, candidate)]
    for row in rows:
        if row["warmup"] != 2 or row["steps"] != 4 or row["input_shapes"] != [[1, 512]] * 12:
            raise ValueError("Timing shape/window changed")
        if row["amp"] != {"bf16": True, "fp16": False}:
            raise ValueError("Timing arithmetic precision changed")
    for key in ("initial_adapter_sha256", "data_sha256"):
        if rows[0][key] != rows[1][key]:
            raise ValueError("Timing inputs/init differ")
    losses = [
        [item["loss"] for item in row["training_log_history"] if "loss" in item] for row in rows
    ]
    if any(len(values) != 6 or not all(math.isfinite(x) for x in values) for values in losses):
        raise ValueError("Incomplete six-update trajectory")
    gate = compare_files(
        reference / "adapter/adapter_model.safetensors",
        candidate / "adapter/adapter_model.safetensors",
        trace=False,
    )
    if gate["tensor_count"] != 896:
        raise ValueError("Incomplete adapter set")
    gate["loss_three_decimals"] = all(f"{a:.3f}" == f"{b:.3f}" for a, b in zip(*losses))
    gate["losses_equal"] = losses[0] == losses[1]
    gate["passed"] &= gate["loss_three_decimals"]
    return gate


def summarize(pairs):
    if len(pairs) != 4:
        raise ValueError("Require all four fresh pairs")
    reductions = []
    orders = [
        ["baseline", "resident"],
        ["resident", "baseline"],
        ["resident", "baseline"],
        ["baseline", "resident"],
    ]
    for number, pair in enumerate(pairs):
        if pair["pair"] != number or pair["order"] != orders[number]:
            raise ValueError("Prospective timing pair/order changed")
        if any(len(pair["seconds"][arm]) != 4 for arm in ("baseline", "resident")):
            raise ValueError("Do not omit timing updates")
        if any(
            not math.isfinite(x) or x <= 0
            for arm in ("baseline", "resident")
            for x in pair["seconds"][arm]
        ):
            raise ValueError("Require positive finite timing samples")
        reductions.append(
            100
            * (
                1
                - statistics.median(pair["seconds"]["resident"])
                / statistics.median(pair["seconds"]["baseline"])
            )
        )
    rng = random.Random(792)
    draws = sorted(statistics.median(rng.choices(reductions, k=4)) for _ in range(20000))
    median, lower, upper = statistics.median(reductions), draws[499], draws[19499]
    positive = sum(x > 0 for x in reductions) / 4
    roles = {}
    for arm in ("baseline", "resident"):
        rows = [pair["provenance"][arm] for pair in pairs]
        roles[arm] = {
            "median_step_seconds": statistics.median(
                statistics.median(pair["seconds"][arm]) for pair in pairs
            ),
            "peak_allocated_vram_bytes": max(x["whole_run_peak_allocated_bytes"] for x in rows),
            "peak_reserved_vram_bytes": max(x["whole_run_peak_reserved_bytes"] for x in rows),
            "peak_process_rss_bytes": max(x["host_memory_at_exit"]["max_rss_bytes"] for x in rows),
            "median_whole_entry_seconds": statistics.median(x["whole_entry_seconds"] for x in rows),
            "median_setup_seconds": statistics.median(x["whole_setup_seconds"] for x in rows),
        }
    return {
        "roles": roles,
        "paired_step_time_reductions_percent": reductions,
        "median_paired_step_time_reduction_percent": median,
        "bootstrap95_percent": [lower, upper],
        "positive_pair_fraction": positive,
        "practical_speed_gate_passed": median >= 2 and positive >= 0.75 and lower > 0,
        "resamples": 20000,
        "seed": 792,
    }
