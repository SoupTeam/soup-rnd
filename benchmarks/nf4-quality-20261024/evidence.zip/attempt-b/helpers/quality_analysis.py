"""Task-quality metrics are descriptive; never apply tensor allclose across precisions."""

import hashlib
import json
import math
import random
import statistics
from pathlib import Path


def digest(path):
    hashed = hashlib.sha256()
    with Path(path).open("rb") as source:
        for part in iter(lambda: source.read(4 * 2**20), b""):
            hashed.update(part)
    return hashed.hexdigest()


def score(logits, rows):
    import numpy as np

    values = np.asarray(logits)
    if values.shape != (len(rows), 151936) or not np.isfinite(values).all():
        raise ValueError("Require complete finite final-token vocabulary logits")
    output = []
    for vector, row in zip(values, rows):
        vector = vector.astype(np.float64)
        choices = row["choice_ids"]
        gold = row["gold_choice"]
        target = choices[gold]
        denominator = float(np.logaddexp.reduce(vector))
        predicted = int(np.argmax(vector[choices]))
        output.append(
            {
                "id": row["id"],
                "gold_choice": gold,
                "predicted_choice": predicted,
                "correct": predicted == gold,
                "gold_token": target,
                "unrestricted_token": int(np.argmax(vector)),
                "unrestricted_correct": int(np.argmax(vector)) == target,
                "answer_nll": denominator - float(vector[target]),
                "choice_mass": math.exp(float(np.logaddexp.reduce(vector[choices])) - denominator),
            }
        )
    return {
        "count": len(rows),
        "accuracy": statistics.mean(x["correct"] for x in output),
        "answer_nll": statistics.mean(x["answer_nll"] for x in output),
        "unrestricted_accuracy": statistics.mean(x["unrestricted_correct"] for x in output),
        "mean_choice_probability_mass": statistics.mean(x["choice_mass"] for x in output),
        "majority_yes_baseline": max(
            sum(x["answer"] for x in rows), sum(not x["answer"] for x in rows)
        )
        / len(rows),
        "rows": output,
    }


def compare(first, second):
    if [x["id"] for x in first["rows"]] != [x["id"] for x in second["rows"]]:
        raise ValueError("Quality comparisons must use the identical held-out rows/order")
    changes = [int(b["correct"]) - int(a["correct"]) for a, b in zip(first["rows"], second["rows"])]
    nll = [b["answer_nll"] - a["answer_nll"] for a, b in zip(first["rows"], second["rows"])]
    rng = random.Random(792)
    accuracy_draws = sorted(
        statistics.mean(rng.choices(changes, k=len(changes))) * 100 for _ in range(20000)
    )
    return {
        "count": len(changes),
        "accuracy_delta_percentage_points": statistics.mean(changes) * 100,
        "paired_bootstrap95_accuracy_delta_pp": [accuracy_draws[499], accuracy_draws[19499]],
        "nll_delta": statistics.mean(nll),
        "nf4_only_correct": changes.count(1),
        "bf16_only_correct": changes.count(-1),
        "prediction_disagreements": sum(
            a["predicted_choice"] != b["predicted_choice"]
            for a, b in zip(first["rows"], second["rows"])
        ),
        "resamples": 20000,
        "seed": 792,
        "quality_verdict": "DESCRIPTIVE_PAIRED_COMPARISON_NOT_A_NONINFERIORITY_PROOF",
        "scope": ("One seed, bounded early finetuning, length-eligible BoolQ subset; "
                  "no generation quality claim"),
    }


def replay_run(path, selected):
    import numpy as np
    from safetensors import safe_open

    path = Path(path)
    info = json.loads((path / "quality-provenance.json").read_bytes())
    if info["status"] != "COMPLETED_REQUIRES_INDEPENDENT_REPLAY":
        raise ValueError("Incomplete task training/evaluation")
    states = {}
    for phase in ("initial", "final"):
        state_hash = hashlib.sha256()
        with safe_open(path / (phase + ".safetensors"), framework="numpy") as handle:
            if len(handle.keys()) != 896 or any("lora_" not in name for name in handle.keys()):
                raise ValueError("Incomplete named LoRA state")
            states[phase] = {}
            for name in sorted(handle.keys()):
                value = handle.get_tensor(name)
                if value.dtype != np.float32 or not np.isfinite(value).all():
                    raise ValueError("Nonfinite or non-FP32 task adapter")
                state_hash.update(name.encode())
                state_hash.update(value.tobytes())
                states[phase][name] = value
        if state_hash.hexdigest() != info[phase + "_adapter_sha256"]:
            raise ValueError("Actual task adapter bytes differ from provenance")
    if states["initial"].keys() != states["final"].keys():
        raise ValueError("Named task adapter set changed")
    changed = sum(
        not np.array_equal(value, states["final"][name])
        for name, value in states["initial"].items()
    )
    if changed < 1 or changed != info["changed_adapter_tensors"]:
        raise ValueError("Task adapter updates were not independently verified")
    reports = {}
    for phase in ("before", "after"):
        rows = selected[:32] if phase == "before" else selected[: info["evaluation_examples"]]
        file = path / (phase + "-logits.safetensors")
        if digest(file) != info[phase + "_logits_sha256"]:
            raise ValueError("Retained quality logits changed")
        with safe_open(file, framework="numpy") as handle:
            if list(handle.keys()) != ["logits"]:
                raise ValueError("Unexpected quality tensor set")
            values = handle.get_tensor("logits")
        reports[phase] = score(np.asarray(values), rows)
        recorded = json.loads((path / (phase + "-metrics.json")).read_bytes())
        if len(recorded["rows"]) != len(rows):
            raise ValueError("Incomplete recorded per-example metrics")
        for field in ("count", "accuracy", "unrestricted_accuracy", "majority_yes_baseline"):
            if reports[phase][field] != recorded[field]:
                raise ValueError("Independent discrete quality metrics differ")
        for field in ("answer_nll", "mean_choice_probability_mass"):
            if not math.isclose(
                reports[phase][field], recorded[field], rel_tol=1e-10, abs_tol=1e-10
            ):
                raise ValueError("FP64 quality-metric replay differs beyond preregistered roundoff")
        for actual, saved in zip(reports[phase]["rows"], recorded["rows"]):
            if any(
                actual[key] != saved[key]
                for key in actual
                if key not in ("answer_nll", "choice_mass")
            ):
                raise ValueError("Per-example quality decisions differ")
            if not all(
                math.isclose(actual[key], saved[key], rel_tol=1e-10, abs_tol=1e-10)
                for key in ("answer_nll", "choice_mass")
            ):
                raise ValueError("Per-example FP64 quality replay differs")
    return {"provenance": info, "metrics": reports}
