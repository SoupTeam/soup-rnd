"""Require a real <=32 GiB RAM bound and abort if container swap is used."""

import argparse
import json
import subprocess
import time
from pathlib import Path

LIMIT_BYTES = 32 * 2**30


def validate(total, hard, swap):
    effective = min(total, hard)
    if not 28 * 2**30 <= effective <= LIMIT_BYTES or swap != 0:
        raise RuntimeError("Require physical/cgroup 28..32 GiB RAM and zero container swap use")
    return {
        "limit_enforced": True,
        "requested_ram_upper_bound_bytes": LIMIT_BYTES,
        "effective_ram_upper_bound_bytes": effective,
        "host_mem_total_bytes": total,
        "native_cgroup_limit_bytes": hard,
        "container_swap_current_bytes": swap,
        "method": "PHYSICAL_32GB_CLASS"
        if total <= LIMIT_BYTES
        else "EXISTING_NATIVE_CGROUP_LE_32GIB",
        "parent_limits_and_system_settings_unchanged": True,
    }


def swap_usage():
    current = Path("/sys/fs/cgroup/memory.swap.current")
    if current.is_file():
        return int(current.read_text())
    stats = Path("/sys/fs/cgroup/memory/memory.stat")
    if stats.is_file():
        data = dict(line.split() for line in stats.read_text().splitlines())
        if "total_swap" in data:
            return int(data["total_swap"])
    raise RuntimeError("Container swap accounting is unavailable; no RSS-only substitute")


def observation():
    memory = {
        name.rstrip(":"): int(value) * 1024
        for name, value, unit in (
            line.split()
            for line in Path("/proc/meminfo").read_text().splitlines()
            if line.startswith(("MemTotal:", "SwapTotal:"))
        )
    }
    native = []
    for filename in ("/sys/fs/cgroup/memory.max", "/sys/fs/cgroup/memory/memory.limit_in_bytes"):
        file = Path(filename)
        if file.is_file() and file.read_text().strip() != "max":
            native.append(int(file.read_text()))
    report = validate(memory["MemTotal"], min(native, default=2**63 - 1), swap_usage())
    report["host_swap_total_bytes"] = memory["SwapTotal"]
    report["swap_policy"] = "Enabled host swap is not called disabled; abort on container swap use"
    report["proc_self_cgroup"] = Path("/proc/self/cgroup").read_text()
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--probe", action="store_true")
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    report = observation()
    report["started_unix"] = time.time()
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2) + "\n")
    if args.probe:
        from rich.console import Console

        Console().print(report)
        return 0
    command = args.command[1:] if args.command[:1] == ["--"] else args.command
    if not command:
        parser.error("a worker command is required")
    child = subprocess.Popen(command)
    report["worker_pid"] = child.pid
    samples, peak = 0, 0
    while child.poll() is None:
        used = swap_usage()
        samples += 1
        peak = max(peak, used)
        if used:
            child.kill()
            child.wait()
            raise RuntimeError("Container used swap; invalidate this stage")
        time.sleep(0.25)
    code = child.returncode
    observation()
    report.update(swap_observation_samples=samples, peak_observed_container_swap_bytes=peak,
                  swap_observation_interval_seconds=0.25,
                  swap_disabled_by_kernel=False)
    report.update(finished_unix=time.time(), worker_exit_code=code)
    args.report.write_text(json.dumps(report, indent=2) + "\n")
    return code


if __name__ == "__main__":
    raise SystemExit(main())
