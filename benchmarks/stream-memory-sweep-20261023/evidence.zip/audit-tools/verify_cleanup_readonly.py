"""Fresh read-only account check after the controller has deleted both resources."""

import json
import time
from pathlib import Path

from rich.console import Console

import cloud

root = Path(__file__).parent
if not (root / "vast-finished").is_file():
    raise RuntimeError("Wait for controller cleanup before the independent account check")
rental = json.loads((root / "vast-rental.json").read_bytes())
instances = cloud.rows()
volumes = cloud.volume_rows()
instance_id, volume_id = rental["instance_id"], rental["volume_id"]
report = {
    "unix": time.time(),
    "method": "Fresh paginated instance listing and full owned-volume listing; read-only API",
    "instance_id": instance_id,
    "volume_id": volume_id,
    "instance_verified_absent": all(
        cloud.resource_id(row["id"]) != instance_id for row in instances
    ),
    "volume_verified_absent": all(cloud.resource_id(row["id"]) != volume_id for row in volumes),
    "account_instance_count": len(instances),
    "account_owned_volume_count": len(volumes),
    "account_instance_ids": [cloud.resource_id(row["id"]) for row in instances],
    "account_owned_volume_ids": [cloud.resource_id(row["id"]) for row in volumes],
}
(root / "independent-cleanup-check.json").write_text(
    json.dumps(report, indent=2) + "\n", encoding="utf-8"
)
Console().print(report)
if not (report["instance_verified_absent"] and report["volume_verified_absent"]):
    raise RuntimeError("A paid experiment resource still exists")
