"""Independent replay controls against the original comparator and corrupt evidence."""

from __future__ import annotations

import importlib.util
import json
from pathlib import Path

import pytest

SPEC = importlib.util.spec_from_file_location(
    "sweep_c_replay", Path(__file__).with_name("replay_results.py")
)
assert SPEC is not None and SPEC.loader is not None
REPLAY = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(REPLAY)


def files(tmp_path, first, second, metadata=None):
    from safetensors.torch import save_file

    left, right = tmp_path / "left", tmp_path / "right"
    left.mkdir()
    right.mkdir()
    save_file(first, str(left / "trace.safetensors"))
    save_file(second, str(right / "trace.safetensors"), metadata=metadata)
    return left, right


@pytest.mark.parametrize("kind", ["same", "metadata", "close", "fail", "initial", "loss"])
def test_bounded_replay_matches_original_comparator_without_large_double_arrays(tmp_path, kind):
    import torch

    from benchmarks.harness.liger_streaming_parity import compare

    first = {
        "loss": torch.tensor([1.0, 2.0], dtype=torch.float64),
        "logits/0": torch.arange(1024, dtype=torch.float64).reshape(2, 4, 128),
        "initial/base.lora_B.weight": torch.ones(4, 4),
    }
    second = {name: value.clone() for name, value in first.items()}
    metadata = None
    if kind == "metadata":
        metadata = {"different": "serialization only"}
    elif kind == "close":
        second["logits/0"] *= 1.005
    elif kind == "fail":
        second["logits/0"][1, 3, 127] += 50
    elif kind == "initial":
        second["initial/base.lora_B.weight"][0, 0] += 1e-6
    elif kind == "loss":
        first["loss"][0], second["loss"][0] = 1.0004, 1.0006
    left, right = files(tmp_path, first, second, metadata)
    expected = compare(left, right)
    actual = REPLAY.compare_files(
        left / "trace.safetensors", right / "trace.safetensors", maximum=17
    )
    assert actual["passed"] == expected["passed"]
    assert actual["loss_three_decimals"] == expected["loss_three_decimals"]
    assert actual["groups"] == expected["groups"]
    assert actual["maximum_slice_elements"] <= 17


def test_original_reference_first_relative_scale_is_not_silently_reversed(tmp_path):
    import torch

    first = {"loss": torch.tensor([1.0]), "logits/0": torch.tensor([1.0], dtype=torch.float64)}
    second = {
        "loss": torch.tensor([1.0]),
        "logits/0": torch.tensor([1.010105], dtype=torch.float64),
    }
    left, right = files(tmp_path, first, second)
    assert REPLAY.compare_files(left / "trace.safetensors", right / "trace.safetensors")["passed"]
    assert not REPLAY.compare_files(right / "trace.safetensors", left / "trace.safetensors")[
        "passed"
    ]


@pytest.mark.parametrize("value", [float("nan"), float("inf"), -float("inf")])
def test_identical_nonfinite_serialized_files_never_pass(tmp_path, value):
    import torch

    trace = {"loss": torch.tensor([1.0]), "logits/0": torch.tensor([[1.0, value]])}
    left, right = files(tmp_path, trace, trace)
    actual = REPLAY.compare_files(
        left / "trace.safetensors", right / "trace.safetensors", maximum=1
    )
    assert not actual["passed"]
    assert actual["groups"]["logits"]["failed_tensors"] == 1
    assert actual["maximum_slice_elements"] == 1


@pytest.mark.parametrize("kind", ["keys", "shape", "dtype"])
def test_malformed_pair_is_refused_even_when_broadcast_or_conversion_could_match(tmp_path, kind):
    import torch

    first = {"loss": torch.tensor([1.0]), "logits/0": torch.ones(2, 2)}
    second = {name: value.clone() for name, value in first.items()}
    if kind == "keys":
        second["extra"] = torch.ones(1)
    elif kind == "shape":
        second["logits/0"] = torch.ones(1, 2)
    else:
        second["logits/0"] = torch.ones(2, 2, dtype=torch.float64)
    left, right = files(tmp_path, first, second)
    with pytest.raises(ValueError):
        REPLAY.compare_files(left / "trace.safetensors", right / "trace.safetensors")


def test_conflicting_duplicate_raw_paths_are_rejected(tmp_path):
    roots = [tmp_path / "a", tmp_path / "b"]
    for root in roots:
        root.mkdir()
        (root / "progress.json").write_text(json.dumps({"stages": []}))
        (root / "raw.json").write_text("same")
    evidence = REPLAY.Evidence(roots)
    assert len(evidence.duplicates) == 1
    assert evidence.duplicates[0]["sha256"] == REPLAY.file_identity(roots[0] / "raw.json")["sha256"]
    (roots[1] / "raw.json").write_text("diff")
    with pytest.raises(ValueError, match="Conflicting duplicate"):
        REPLAY.Evidence(roots)


def test_mutable_progress_requires_consistent_completed_stage_history(tmp_path):
    roots = [tmp_path / "a", tmp_path / "b"]
    for root, stages in zip(roots, ([{"name": "one"}], [{"name": "two"}, {"name": "three"}])):
        root.mkdir()
        (root / "progress.json").write_text(json.dumps({"stages": stages}))
    with pytest.raises(ValueError, match="stage history"):
        REPLAY.Evidence(roots)


def test_bootstrap_and_processed_position_throughput_match_frozen_helper():
    import runpy

    original = runpy.run_path(str(Path(__file__).with_name("timing_summary.py")))["summarize"]
    pairs = [
        {"order": order, "baseline": [2 + number / 10] * 8, "auto": [1.9 + number / 10] * 8}
        for number, order in enumerate(REPLAY.PAIR_ORDER)
    ]
    actual = REPLAY.summarize(pairs)
    assert actual == original(pairs)
    pairs[0]["order"] = "BA"
    with pytest.raises(ValueError):
        REPLAY.summarize(pairs)


def test_partial_capture_cannot_become_a_numerical_qualification(tmp_path):
    from types import SimpleNamespace

    def missing(_relative):
        raise FileNotFoundError("partial capture")

    evidence = SimpleNamespace(get=missing)
    model = {"config": {"num_hidden_layers": 36, "vocab_size": 151936}}
    with pytest.raises(FileNotFoundError, match="partial"):
        REPLAY.qualification(evidence, "none-ram", 5, model, "unused", 17)


def test_nvme_read_proof_rejects_page_cache_and_unrelated_mount():
    proof = {
        "actual_tier": "disk",
        "direct_io": True,
        "io_read_bytes_delta": 100,
        "per_update_io": [
            {"step": step, "linux_process_io_delta": {"read_bytes": 100 if step == 7 else 0}}
            for step in range(1, 15)
        ],
        "cache_paths": ["/data/shards/model"],
        "storage_validation": {
            "nvme_verified": True,
            "verified_path": "/data",
            "backing_device": "nvme0n1",
            "mount_source": "/dev/nvme0n1",
            "device_major_minor": "259:0",
            "sysfs_realpath": "/sys/devices/nvme0n1",
        },
    }
    assert REPLAY.nvme_proof(proof)
    proof["direct_io"] = False
    assert not REPLAY.nvme_proof(proof)
    proof["direct_io"] = True
    proof["cache_paths"] = ["/data-other/shards/model"]
    assert not REPLAY.nvme_proof(proof)


@pytest.mark.parametrize("warmup_only", [False, True])
def test_heldout_nvme_flag_requires_measured_reads_without_changing_numeric_gates(
    tmp_path, warmup_only
):
    evidence, model, initial_sha = synthetic_matrix(tmp_path)
    for number in range(4):
        path = evidence.get(
            f"heldout/dense-best/pair-{number}-candidate/residency-sweep-provenance.json"
        )
        info = json.loads(path.read_text())
        info.update(
            actual_tier="disk", direct_io=True, io_read_bytes_delta=4096,
            cache_paths=["/data/shards/model"],
            storage_validation={
                "nvme_verified": True, "verified_path": "/data",
                "backing_device": "nvme0n1", "mount_source": "/dev/nvme0n1",
                "device_major_minor": "259:0", "sysfs_realpath": "/sys/devices/nvme0n1",
            },
            per_update_io=[
                {"step": step, "linux_process_io_delta": {
                    "read_bytes": 4096 if step == (1 if warmup_only else 7) else 0,
                }}
                for step in range(1, 15)
            ],
        )
        info["prepared"]["source"] = "disk"
        assert REPLAY.nvme_proof(info)  # Aggregate reads exist in either case.
        assert REPLAY.nvme_timing_proof(info) is (not warmup_only)
        path.write_text(json.dumps(info))
    result = REPLAY.heldout(
        evidence, "dense-best", "none", "ram", "disk", 4,
        model, "fixture", initial_sha, 17,
    )
    assert result["status"] == "HELDOUT_REPLAYED"
    assert result["nvme_timing_qualified"] is (not warmup_only)
    assert all(row["passed"] and row["tensor_count"] == 504 for row in result["trajectories"])
    assert result["performance"]["median_paired_step_time_reduction_percent"] == pytest.approx(5)


def synthetic_matrix(tmp_path):
    """Small byte fixtures retaining the real 504/2037/1015 tensor counts."""
    import torch
    from safetensors.torch import save_file

    root = tmp_path / "results"
    root.mkdir()
    model = {"revision": "frozen", "config": {"num_hidden_layers": 36, "vocab_size": 2}}
    parameters = {
        f"base.layers.{index}.lora_B.weight": torch.tensor([0.1 + index / 10000])
        for index in range(504)
    }
    initial = {"initial/" + name: value for name, value in parameters.items()}
    primary = {**initial, "loss": torch.tensor([1.0] * 4, dtype=torch.float64)}
    primary.update({"final/" + name: value for name, value in parameters.items()})
    for update in range(2):
        primary.update({f"gradient/{update}/" + name: value for name, value in parameters.items()})
    for batch in range(4):
        for field in ("input_ids", "labels", "attention_mask"):
            primary[f"batch/{batch}/{field}"] = torch.ones(1, 1024, dtype=torch.int64)
        primary[f"batch/{batch}/num_items_in_batch"] = torch.tensor(2048)
        primary[f"logits/{batch}"] = torch.ones(1, 1024, 2)
    semantic = {
        **initial,
        "loss": torch.tensor([1.0], dtype=torch.float64),
        "logits/valid": torch.ones(25, 2),
        "diagnostic/unpadded_logits": torch.ones(1, 9, 2),
    }
    semantic.update({"gradient/" + name: value for name, value in parameters.items()})
    for field in ("input_ids", "attention_mask", "position_ids", "labels"):
        semantic["batch/" + field] = torch.ones(2, 16, dtype=torch.int64)

    def write(folder, name, value):
        folder.mkdir(parents=True, exist_ok=True)
        (folder / name).write_text(json.dumps(value))

    def info(count, pid):
        total = 8222998528
        indices = list(range((36 - count) // 2, (36 - count) // 2 + count))
        return {
            "status": "COMPLETED_NOT_AN_INDEPENDENT_VERDICT",
            "capacity_failure": None,
            "capacity_only": False,
            "entry_sha256": "fixture",
            "arm": "baseline" if count == 0 else f"resident{count}",
            "indices": indices,
            "resident_layers": count,
            "resident_bytes": count * 100,
            "actual_mode": 0,
            "actual_tier": "ram",
            "requested_quant": "none",
            "layer_count": 36,
            "physical_gpu_bytes": total,
            "initial_device_free_bytes": total,
            "initial_reserved_bytes": 0,
            "allocator_budget_bytes": total - 256 * 2**20,
            "device_free_min_bytes": 2**30,
            "pid": pid,
            "prepared": {
                "quant": "none",
                "source": "ram",
                "data_sha256": REPLAY.DATA_SHA256,
                "revision": "frozen",
                "shard_files": {"weights": {"sha256": "same"}},
            },
            "quantization_actual": {"loaded_in_4bit": False},
        }

    for count in (0, 4):
        for phase, tensors in (("capture", primary), ("semantics", semantic)):
            folder = root / "none-ram" / f"{phase}-{count}"
            folder.mkdir(parents=True)
            save_file(
                {name: value.clone() for name, value in tensors.items()},
                str(folder / "trace.safetensors"),
            )
            write(folder, "residency-sweep-provenance.json", info(count, 100 + count))
            write(
                folder,
                "capture.json" if phase == "capture" else "study-provenance.json",
                {
                    "status": "CAPTURED",
                    "adapter_tensors": 504,
                    "amp": {"bf16": True, "fp16": False},
                    "deterministic_algorithms": True,
                    "causal_prefix_exact": True,
                    "masked_padding_isolation_exact": True,
                },
            )
    initial_sha = REPLAY.check_trace_schema(
        root / "none-ram/capture-0/trace.safetensors",
        "primary",
        504,
        2,
    )["initial_adapter_sha256"]
    stages = []
    for number, order in enumerate(REPLAY.PAIR_ORDER):
        for letter in order:
            arm, count = ("baseline", 0) if letter == "A" else ("candidate", 4)
            folder = root / "heldout/dense-best" / f"pair-{number}-{arm}"
            values = [2.0 if count == 0 else 1.9] * 8
            write(
                folder,
                "metrics.json",
                {
                    "status": "TIMING_CAPTURED_NOT_A_CORRECTNESS_OR_QUALITY_VERDICT",
                    "amp": {"bf16": True, "fp16": False},
                    "deterministic_algorithms": True,
                    "warmup": 6,
                    "steps": 8,
                    "seconds": values,
                    "input_shapes": [[1, 1024]] * 28,
                    "initial_adapter_sha256": initial_sha,
                    "data_sha256": REPLAY.DATA_SHA256,
                    "training_log_history": [{"loss": 1.0, "step": step} for step in range(1, 15)],
                    "peak_allocated_bytes": [1000] * 8,
                    "peak_reserved_bytes": [2000] * 8,
                },
            )
            write(
                folder,
                "residency-sweep-provenance.json",
                info(count, 1000 + 2 * number + bool(count)),
            )
            (folder / "adapter").mkdir()
            save_file(parameters, str(folder / "adapter/adapter_model.safetensors"))
            stages.append({"name": f"heldout-dense-best-{number}-{arm}", "exit_code": 0})
    write(root, "progress.json", {"stages": stages, "heldout": {}})
    return REPLAY.Evidence([root]), model, initial_sha


def test_entire_real_count_qualification_and_eight_process_holdout_are_replayed(tmp_path):
    evidence, model, initial_sha = synthetic_matrix(tmp_path)
    qualification = REPLAY.qualification(evidence, "none-ram", 4, model, "fixture", 17)
    assert qualification["passed"]
    assert qualification["gates"]["primary"]["tensor_count"] == 2037
    assert qualification["gates"]["semantics"]["tensor_count"] == 1015
    replayed = REPLAY.heldout(
        evidence,
        "dense-best",
        "none",
        "ram",
        "ram",
        4,
        model,
        "fixture",
        initial_sha,
        17,
    )
    assert replayed["status"] == "HELDOUT_REPLAYED"
    assert all(row["tensor_count"] == 504 for row in replayed["trajectories"])
    assert replayed["performance"]["practical_speed_gate_passed"]
    assert replayed["performance"]["baseline_tokens_per_second"] == 1024


@pytest.mark.parametrize("available", [False, True])
def test_lossy_quantization_diagnostic_is_separate_from_residency_qualification(
    tmp_path, available
):
    import shutil

    from safetensors.torch import load_file, save_file

    evidence, model, _ = synthetic_matrix(tmp_path)
    root = tmp_path / "results"
    if available:
        for prefix in ("capture", "semantics"):
            folder = root / "nf4-ram" / f"{prefix}-0"
            shutil.copytree(root / "none-ram" / f"{prefix}-0", folder)
            path = folder / "residency-sweep-provenance.json"
            info = json.loads(path.read_text())
            info["requested_quant"] = "nf4"
            info["prepared"].update(quant="nf4", double_quant=True, quant_device="cuda")
            info["prepared"]["shard_files"]["weights"]["sha256"] = "packed-different-bytes"
            info["quantization_actual"] = {
                "loaded_in_4bit": True,
                "quantized_layer_specs": [
                    {"idx": index, "count": 7, "nested": True} for index in range(36)
                ],
            }
            path.write_text(json.dumps(info))
        path = root / "nf4-ram/capture-0/trace.safetensors"
        values = load_file(str(path))
        values["logits/0"][0, 0, 0] += 5
        save_file(values, str(path))
        evidence = REPLAY.Evidence([root])
    diagnostic = REPLAY.quantization_diagnostic(evidence, model, "fixture", 17)
    assert diagnostic["kind"] == "quantization_diagnostic"
    assert diagnostic["gating"] is False
    if available:
        assert diagnostic["status"] == "FAIL_ORIGINAL_NUMERIC_GATE"
        assert diagnostic["passes_original_numeric_gate"] is False
        assert diagnostic["gates"]["primary"]["groups"]["logits"]["failed_tensors"] == 1
        assert diagnostic["gates"]["primary"]["groups"]["logits"]["max_abs"] == 5
        assert REPLAY.qualification(evidence, "nf4-ram", 0, model, "fixture", 17)["passed"]
    else:
        assert diagnostic["status"] == "NOT_AVAILABLE"
        assert "passes_original_numeric_gate" not in diagnostic
    assert REPLAY.qualification(evidence, "none-ram", 4, model, "fixture", 17)["passed"]


@pytest.mark.parametrize("field", ["loss", "inputs", "initialization"])
def test_heldout_rejects_corrupted_raw_trajectory_evidence(tmp_path, field):
    evidence, model, initial_sha = synthetic_matrix(tmp_path)
    path = evidence.get("heldout/dense-best/pair-3-candidate/metrics.json")
    metrics = json.loads(path.read_text())
    if field == "loss":
        metrics["training_log_history"][-1]["loss"] += 0.02
    elif field == "inputs":
        metrics["input_shapes"].pop()
    else:
        metrics["initial_adapter_sha256"] = "different"
    path.write_text(json.dumps(metrics))
    with pytest.raises(ValueError):
        REPLAY.heldout(
            evidence,
            "dense-best",
            "none",
            "ram",
            "ram",
            4,
            model,
            "fixture",
            initial_sha,
            17,
        )
