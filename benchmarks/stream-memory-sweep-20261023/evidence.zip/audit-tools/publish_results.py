"""Package exact, reviewed local metadata; never contact a cloud or publish anything."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import tempfile
import zipfile
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath
from typing import Any

from rich.console import Console

MAX_METADATA_BYTES = 64 * 2**20
FROZEN_NAMES = frozenset({
    "archive_ranges.py", "artifacts.py", "bench.py", "check_quote.py", "cloud.py",
    "constraints.txt", "controller.py", "freeze.py", "launch.py", "lossless_results.py",
    "pin_entry.py", "preflight_remote.py", "prepare_model.py",
    "production-newline-normalization.json",
    "protocol.json", "pytest_gpu_entry.py", "remote_guard.py", "remote_ranges.py",
    "remote_retention_probe.py", "retention-donors.json", "setup.sh", "source-manifest.json",
    "source.tar.gz", "telemetry.py", "test_bench.py", "test_cloud.py", "test_control.py",
    "test_worker.py", "timing_summary.py", "transport.py", "worker.py",
})
AUDIT_NAMES = frozenset({
    "publish_results.py", "test_publish.py", "replay_results.py", "test_replay.py",
    "inspect_storage_readonly.py", "verify_cleanup_readonly.py",
    "build_summary.py", "test_summary.py",
    "compact_publication.py",
})
LOCAL_NAMES = frozenset({
    "admission-plan.json", "capacity-preflight.json", "controller-error.json",
    "creation-response.json", "creation-error.json", "final-prospective-quote.json",
    "final-worker-summary.json", "guard-status-latest.json", "independent-replay.json",
    "independent-replay.log", "launch-manifest.json", "lease-greenlight.json", "local-guard.log",
    "local-helper-validation.json", "local-validation.json", "local-validation.log",
    "local-postprocessing-tests.xml", "independent-replay-preliminary.json",
    "independent-cleanup-check.json", "local-postprocessing-tests-before-consumer-fix.xml",
    "offline-validation.json",
    "local-summary-tests.xml", "result-summary.json", "results-tables.md", "paper-readout.md",
    "residency-interpretation-notes.md",
    "host-memory-notes.md",
    "cross-format-dtype-notes.md",
    "ssd-variability-notes.md", "ssd-readonly-observation.json",
    "ssd-variability-raw-window.json",
    "network-preflight.json", "prior-stage-ledger-snapshot.json", "remote-progress.json",
    "remote-setup-failure.log", "retention-policy.json", "ssh-key-attach.json",
    "stage-ledger.json", "storage-validation.json", "summary.json", "vast-allocation-intent.json",
    "vast-cleanup-retry.json", "vast-deletion.json", "vast-local-guard.json", "vast-rental.json",
    "vast-status.json", "vast-volume-deletion.json", "vast-volume-rental.json",
    "gpu-telemetry-last-observed.jsonl", "gpu-telemetry-coverage.json",
    "gpu-telemetry-observation-provenance.json", "telemetry-observer.json",
    "telemetry-observer-last-error.json",
})
LOCAL_PREFIXES = (
    "bundle-", "range-proof-", "range-state-", "streaming-extraction-",
)
RESULT_SUFFIXES = frozenset({
    ".json", ".jsonl", ".log", ".xml", ".txt", ".csv", ".yaml", ".yml", ".toml", ".cfg",
})
SNAPSHOTS = frozenset({"results/progress.json", "results/gpu-telemetry.jsonl"})
RETAINED_METADATA = frozenset({
    "capacity-preflight.json", "storage-validation.json", "retention-policy.json",
    "launch-manifest.json", "policy.json", "worker-retention-observation.json",
})
FORBIDDEN_JSON_KEYS = frozenset({
    "api_key", "apikey", "api-key", "authorization", "access_token", "refresh_token",
    "password", "private_key", "ssh_private_key", "token", "credentials", "cookies",
    "public_ipaddr", "ssh_host", "public_ip", "ip_address",
})
SECRET_TEXT = re.compile(
    rb"-----BEGIN (?:OPENSSH |RSA |EC |DSA |ENCRYPTED )?PRIVATE KEY-----"
    rb"|Bearer[ \t]+[A-Za-z0-9_.\-]{24,}"
)
SHA256 = re.compile(r"[0-9a-f]{64}")


def canonical_json(value: Any) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=True) + "\n").encode()


def within(root: Path, relative: str) -> Path:
    name = PurePosixPath(relative)
    if (not relative or "\\" in relative or ":" in relative or name.is_absolute()
            or any(part in {"..", "."} for part in name.parts)):
        raise ValueError(f"Unsafe original artifact path: {relative}")
    base, final = os.path.realpath(root), os.path.realpath(root / relative)
    if os.path.commonpath([base, final]) != base:
        raise ValueError(f"Artifact escapes its evidence root: {relative}")
    target = root / relative
    current = target
    while current != root:
        if current.is_symlink():
            raise ValueError(f"Symlink evidence is forbidden: {relative}")
        current = current.parent
    return target


def identity(path: Path) -> dict[str, Any]:
    before = path.stat()
    hashed = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(2**20), b""):
            hashed.update(block)
    after = path.stat()
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        raise ValueError(f"Original changed while hashing: {path.name}")
    return {"bytes": after.st_size, "sha256": hashed.hexdigest()}


def check_json(value: Any) -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            if str(key).lower() in FORBIDDEN_JSON_KEYS and child not in (None, "", "[redacted]"):
                raise ValueError("Refuse a credential or private-address field in public evidence")
            check_json(child)
    elif isinstance(value, list):
        for child in value:
            check_json(child)


def review_metadata(path: Path) -> None:
    if path.name == "source.tar.gz":
        return  # This exact immutable source hash is checked against the frozen launch manifest.
    if path.stat().st_size > MAX_METADATA_BYTES:
        raise ValueError(f"Metadata exceeds the explicit publication limit: {path.name}")
    raw = path.read_bytes()
    if SECRET_TEXT.search(raw):
        raise ValueError(f"Credential material detected in allowlisted evidence: {path.name}")
    if path.suffix == ".json":
        check_json(json.loads(raw))
    elif path.suffix == ".jsonl":
        for line in raw.splitlines():
            if line.strip():
                check_json(json.loads(line))


@dataclass
class Entry:
    source: Path
    digest: dict[str, Any]
    origins: list[str] = field(default_factory=list)


class Catalogue:
    def __init__(self):
        self.entries: dict[str, Entry] = {}
        self.raw: list[dict[str, Any]] = []

    def add(self, archive_path: str, source: Path, origin: str,
            expected: dict[str, Any] | None = None) -> None:
        within(Path("."), archive_path)  # Validate archive names independently of filesystem state.
        if not source.is_file() or source.is_symlink():
            raise ValueError(f"Missing regular original: {origin}")
        review_metadata(source)
        found = identity(source)
        if expected is not None and found != {
            "bytes": expected["bytes"], "sha256": expected["sha256"],
        }:
            raise ValueError(f"Original does not match its recorded byte identity: {origin}")
        previous = self.entries.get(archive_path)
        if previous is not None:
            if previous.digest != found:
                raise ValueError(f"Conflicting duplicate immutable original: {archive_path}")
            # Digest equality is followed by exact byte equality, not accepted on hash alone.
            with previous.source.open("rb") as left, source.open("rb") as right:
                while True:
                    a, b = left.read(2**20), right.read(2**20)
                    if a != b:
                        raise ValueError(f"Duplicate bytes differ: {archive_path}")
                    if not a:
                        break
            previous.origins.append(origin)
        else:
            self.entries[archive_path] = Entry(source, found, [origin])


def local_allowed(relative: str) -> bool:
    name = PurePosixPath(relative).name
    return (relative in LOCAL_NAMES or relative in {"local/" + item for item in LOCAL_NAMES}
            or ("/" not in relative and name.endswith(".json")
                and name.startswith(LOCAL_PREFIXES)))


def metadata_result(relative: str) -> bool:
    parts = PurePosixPath(relative).parts
    return (parts[0] == "results" and PurePosixPath(relative).suffix in RESULT_SUFFIXES
            and not any(part.lower() in {"adapters", "adapter", "weights", "checkpoints"}
                        for part in parts))


def verify_cleanup(root: Path) -> None:
    if not within(root, "vast-finished").is_file():
        raise ValueError("Package only after paired instance/volume cleanup is finished")
    receipt = json.loads(within(root, "vast-rental.json").read_bytes())
    deleted = json.loads(within(root, "vast-deletion.json").read_bytes())
    volume = json.loads(within(root, "vast-volume-deletion.json").read_bytes())
    if not (deleted.get("verified_absent") is True
            and deleted.get("volume_verified_absent") is True
            and volume.get("verified_absent") is True):
        raise ValueError("Both independent deletion proofs are required")
    identities = (
        receipt.get("instance_id"), receipt.get("volume_id"),
        deleted.get("instance_id"), deleted.get("volume_id"), volume.get("volume_id"),
    )
    if any(type(value) is not int or value <= 0 for value in identities):
        raise ValueError("Cleanup receipts require exact positive integer resource IDs")
    if (deleted.get("instance_id") != receipt.get("instance_id")
            or deleted.get("volume_id") != receipt.get("volume_id")
            or volume.get("volume_id") != receipt.get("volume_id")):
        raise ValueError("Cleanup receipts refer to different exact resources")
    if not within(root, "independent-replay.json").is_file():
        raise ValueError("Save independent-replay.json before packaging finished evidence")


def collect(root: Path) -> Catalogue:
    verify_cleanup(root)
    result = Catalogue()
    frozen = json.loads(within(root, "launch-manifest.json").read_bytes())
    if not isinstance(frozen, dict) or not frozen or not set(frozen) <= FROZEN_NAMES:
        raise ValueError("Frozen launch manifest contains an unreviewed helper path")
    for name, expected in sorted(frozen.items()):
        result.add("executed/" + name, within(root, name), name, expected)
    result.add("executed/launch-manifest.json", within(root, "launch-manifest.json"),
               "launch-manifest.json")
    for name in sorted(AUDIT_NAMES):
        path = within(root, name)
        if path.is_file():
            result.add("audit-tools/" + name, path, name)
    observer = within(root, "observe.py")
    if observer.is_file():
        result.add("executed-observer/observe.py", observer, "observe.py")
    for path in sorted(root.iterdir()):
        name = path.name
        if path.is_file() and local_allowed(name):
            result.add("local/" + name, within(root, name), name)
    local = within(root, "local")
    if local.is_dir():
        for path in sorted(local.iterdir()):
            name = "local/" + path.name
            if path.is_file() and local_allowed(name):
                result.add(name, within(root, name), name)
    bundles = within(root, "bundles")
    for folder in sorted(bundles.iterdir()):
        if not folder.is_dir():
            continue
        retained = within(root, "bundles/" + folder.name + "/retained")
        if not retained.is_dir():
            raise ValueError(f"Unretained bundle remains: {folder.name}")
        proof_name = "bundle-" + folder.name + "-verified.json"
        proof = json.loads(within(root, proof_name).read_bytes())
        original = within(retained, "original-files.json")
        inventory = json.loads(original.read_bytes())
        if proof.get("all_original_files_verified") != len(inventory["files"]):
            raise ValueError(f"Bundle lacks a complete verified-retention receipt: {folder.name}")
        result.add(f"bundle-manifests/{folder.name}/original-files.json", original,
                   f"bundles/{folder.name}/retained/original-files.json")
        for name in ("index.json", "layout.json"):
            if (folder / name).is_file():
                result.add(f"bundle-manifests/{folder.name}/{name}", within(folder, name),
                           f"bundles/{folder.name}/{name}")
        for path in sorted(folder.glob("*.request.json")):
            result.add(f"bundle-manifests/{folder.name}/{path.name}", within(folder, path.name),
                       f"bundles/{folder.name}/{path.name}")
        for relative, expected in sorted(inventory["files"].items()):
            path = within(retained, relative)
            origin = f"bundles/{folder.name}/retained/{relative}"
            if relative in frozen:
                if expected["bytes"] != frozen[relative]["bytes"] or (
                    expected["sha256"] != frozen[relative]["sha256"]
                ):
                    raise ValueError(f"Retained helper differs from frozen identity: {origin}")
                result.add("executed/" + relative, path, origin, frozen[relative])
            elif relative in RETAINED_METADATA or relative in SNAPSHOTS:
                result.add(f"bundle-snapshots/{folder.name}/{relative}", path, origin, expected)
            elif metadata_result(relative):
                result.add(relative, path, origin, expected)
            elif path.is_file():
                if not SHA256.fullmatch(expected["sha256"]):
                    raise ValueError(f"Invalid recorded raw SHA256: {origin}")
                if path.stat().st_size != expected["bytes"]:
                    raise ValueError(f"Excluded raw artifact has the wrong size: {origin}")
                result.raw.append({
                    "bundle": folder.name, "relative_path": relative,
                    "local_path": str(path.absolute()), "bytes": expected["bytes"],
                    "sha256_as_recorded_by_retention": expected["sha256"],
                    "hashed_again_by_packager": False,
                })
            else:
                raise ValueError(f"Retained original is missing: {origin}")
        archive = within(folder, "results.tar")
        if archive.is_file():
            if archive.stat().st_size != proof["archive_bytes"]:
                raise ValueError(f"Retained encoded archive size changed: {folder.name}")
            result.raw.append({
                "bundle": folder.name, "relative_path": "results.tar",
                "local_path": str(archive.absolute()), "bytes": proof["archive_bytes"],
                "sha256_as_recorded_by_retention": proof["sha256"],
                "hashed_again_by_packager": False,
            })
    if not any(name.startswith("results/") for name in result.entries):
        raise ValueError("No retained process results found")
    return result


def write_zip(path: Path, catalogue: Catalogue) -> None:
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, entry in sorted(catalogue.entries.items()):
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            with entry.source.open("rb") as original, archive.open(info, "w") as packed:
                while block := original.read(2**20):
                    packed.write(block)
            if identity(entry.source) != entry.digest:
                raise ValueError(f"Original changed during ZIP construction: {name}")
    with zipfile.ZipFile(path) as archive:
        if archive.namelist() != sorted(catalogue.entries):
            raise ValueError("ZIP entry list differs from the exact original catalogue")
        for name, entry in sorted(catalogue.entries.items()):
            with archive.open(name) as packed, entry.source.open("rb") as original:
                while True:
                    first, second = packed.read(2**20), original.read(2**20)
                    if first != second:
                        raise ValueError(f"ZIP bytes differ from their original: {name}")
                    if not first:
                        break
            if identity(entry.source) != entry.digest:
                raise ValueError(f"Original changed during ZIP byte verification: {name}")


def build(root: Path, output: Path) -> dict[str, Any]:
    root = Path(os.path.realpath(root))
    catalogue = collect(root)
    output.mkdir(parents=True, exist_ok=True)
    names = ("evidence.zip", "evidence-manifest.json", "local-raw-artifact-index.json")
    if any((output / name).exists() for name in names):
        raise FileExistsError("Refuse overwriting an existing evidence package")
    descriptor, temporary_name = tempfile.mkstemp(prefix="evidence-", suffix=".tmp", dir=output)
    os.close(descriptor)
    temporary = Path(temporary_name)
    try:
        write_zip(temporary, catalogue)
        manifest = {
            "format": "soup-exact-metadata-evidence-v1",
            "archive": {"name": "evidence.zip", **identity(temporary)},
            "original_bytes_preserved": True, "every_zip_entry_byte_verified": True,
            "gpu_telemetry_coverage": "Exact retained snapshots; no continuous completeness claim",
            "raw_artifacts": "Excluded; retained locally and indexed outside this ZIP",
            "files": {
                name: {**entry.digest, "original_locations": sorted(entry.origins)}
                for name, entry in sorted(catalogue.entries.items())
            },
        }
        raw_index = {
            "format": "soup-local-raw-artifact-index-v1", "local_only": True,
            "not_in_evidence_zip": True,
            "verification_scope": "Recorded retention hashes; excluded raw data not rehashed here",
            "artifacts": sorted(
                catalogue.raw, key=lambda row: (row["bundle"], row["relative_path"])
            ),
        }
        (output / "local-raw-artifact-index.json").write_bytes(canonical_json(raw_index))
        temporary.replace(output / "evidence.zip")
        (output / "evidence-manifest.json").write_bytes(canonical_json(manifest))
        return manifest
    finally:
        if temporary.exists():
            temporary.unlink()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).parent)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    manifest = build(args.root, args.output)
    Console().print({"files": len(manifest["files"]), "archive": manifest["archive"]})


if __name__ == "__main__":
    main()
