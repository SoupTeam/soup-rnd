"""Build final tables from independently replayed, retained memory-sweep evidence."""

from __future__ import annotations

import argparse
import json
import math
import statistics
from pathlib import Path
from typing import Any

from rich.console import Console

from replay_results import Evidence, file_identity, nvme_proof, read_json, summarize, timing_metrics

PHASE_FIELDS = {
    "metrics_setup_seconds": ("metrics", "setup_seconds"),
    "training_14_updates_and_save_seconds": (
        "metrics",
        "training_wall_seconds_including_final_save",
    ),
    "stream_setup_seconds": ("provenance", "whole_setup_seconds"),
    "benchmark_entry_seconds": ("provenance", "whole_entry_seconds"),
    "worker_process_stage_seconds": ("stage", "seconds"),
}


def _phase_summary(raw_values: list[Any], source_field: str) -> dict[str, Any]:
    values = [
        float(value) if type(value) in (int, float) and math.isfinite(value) and value > 0 else None
        for value in raw_values
    ]
    available = [value for value in values if value is not None]
    complete = len(available) == 4
    return {
        "source_field": source_field,
        "status": "COMPLETE" if complete else ("PARTIAL" if available else "NOT_AVAILABLE"),
        "available_processes": len(available),
        "expected_processes": 4,
        "per_process_seconds": values,
        "unavailable_or_invalid_processes": [i for i, value in enumerate(values) if value is None],
        "median_seconds": statistics.median(available) if complete else None,
        "range_seconds": [min(available), max(available)] if complete else None,
    }


def _training_wall_pairs(baseline: dict[str, Any], candidate: dict[str, Any]) -> dict[str, Any]:
    name = "training_14_updates_and_save_seconds"
    values = [
        arm["descriptive_timing_phases"]["phases"][name]["per_process_seconds"]
        for arm in (baseline, candidate)
    ]
    reductions = [
        100 * (1 - second / first) if first is not None and second is not None else None
        for first, second in zip(*values, strict=True)
    ]
    available = [value for value in reductions if value is not None]
    complete = len(available) == 4
    return {
        "predeclared": False,
        "gating": False,
        "scope": (
            "Exploratory fourteen-update training loop plus final adapter save; not steady steps"
        ),
        "status": "COMPLETE" if complete else ("PARTIAL" if available else "NOT_AVAILABLE"),
        "available_pairs": len(available),
        "expected_pairs": 4,
        "paired_time_reduction_percent": reductions,
        "median_paired_time_reduction_percent": statistics.median(available) if complete else None,
        "range_paired_time_reduction_percent": [min(available), max(available)]
        if complete
        else None,
    }


def _finite_number(value: Any, name: str, *, nonnegative: bool = True) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"Expected a finite number for {name}")
    result = float(value)
    if not math.isfinite(result) or (nonnegative and result < 0):
        raise ValueError(f"Expected a finite nonnegative number for {name}")
    return result


def cleanup_and_budget(root: Path) -> dict[str, Any]:
    """Require both exact resources absent and retain the aggregate conservative ledger."""
    if not (root / "vast-finished").is_file():
        raise ValueError("Final output requires vast-finished after resource cleanup")
    rental = read_json(root / "vast-rental.json")
    deleted = read_json(root / "vast-deletion.json")
    volume = read_json(root / "vast-volume-deletion.json")
    if not (
        deleted.get("verified_absent") is True
        and deleted.get("volume_verified_absent") is True
        and volume.get("verified_absent") is True
    ):
        raise ValueError("Both instance and volume must be independently verified absent")
    identity, volume_id = rental["instance_id"], rental["volume_id"]
    if any(type(value) is not int or value <= 0 for value in (identity, volume_id)):
        raise ValueError("Final summary requires the exact allocated instance and volume IDs")
    if (
        deleted.get("instance_id") != identity
        or deleted.get("volume_id") != volume_id
        or volume.get("volume_id") != volume_id
    ):
        raise ValueError("Deletion receipts do not identify the exact rented resources")
    ledger = read_json(root / "stage-ledger.json")
    prior = read_json(root / "prior-stage-ledger-snapshot.json")
    if ledger["stage_id"] != prior["stage_id"]:
        raise ValueError("Current and prior budget ledgers have different stage IDs")
    entries = ledger["completed_leases"]
    if len({row["instance_id"] for row in entries}) != len(entries):
        raise ValueError("Aggregate ledger contains duplicate leases")
    for row in entries:
        if row.get("verified_absent") is not True:
            raise ValueError("Aggregate ledger contains an instance not verified absent")
        if row.get("volume_id") is not None and row.get("volume_verified_absent") is not True:
            raise ValueError("Aggregate ledger contains a volume not verified absent")
        _finite_number(row["conservative_usd"], "lease conservative_usd")
    current = [row for row in entries if row["instance_id"] == identity]
    if len(current) != 1 or current[0].get("volume_id") != volume_id:
        raise ValueError("Aggregate ledger lacks the exact current instance/volume pair")
    prior_entries = prior["completed_leases"]
    for row in prior_entries:
        if row not in entries:
            raise ValueError("Previously spent budget was removed or changed")
    prior_usd = sum(row["conservative_usd"] for row in prior_entries)
    if not math.isclose(prior_usd, rental["prior_usd"], rel_tol=0, abs_tol=1e-9):
        raise ValueError("Rental prior spend differs from the retained prior ledger")
    maximum = _finite_number(ledger["maximum_stage_usd"], "maximum_stage_usd")
    if maximum != rental["maximum_usd"] or maximum != prior["maximum_stage_usd"]:
        raise ValueError("Aggregate budget limit changed between receipts")
    total = sum(row["conservative_usd"] for row in entries)
    return {
        "maximum_stage_usd": maximum,
        "prior_leases_usd": prior_usd,
        "current_lease_usd": current[0]["conservative_usd"],
        "aggregate_conservative_usd": total,
        "remaining_to_limit_usd": maximum - total,
        "within_budget": total <= maximum,
        "cost_scope": "Conservative ledger estimate including prior leases; not a provider invoice",
        "completed_leases": entries,
        "cleanup": {
            "instance_id": identity,
            "volume_id": volume_id,
            "instance_verified_absent": True,
            "volume_verified_absent": True,
            "instance_deletion_unix": deleted.get("unix"),
            "volume_deletion_unix": volume.get("unix"),
        },
    }


def retained_evidence(root: Path) -> Evidence:
    roots = [
        path / "retained"
        for path in sorted((root / "bundles").iterdir())
        if (path / "retained" / "results").is_dir()
    ]
    if not roots:
        raise ValueError("No retained bundle result roots")
    return Evidence(roots)


def _optional_json(evidence: Evidence, relative: str) -> Any:
    return evidence.json(relative) if relative in evidence.files else None


def _process_memory(info: dict[str, Any]) -> dict[str, Any]:
    hosts = [info.get(name, {}) for name in ("host_memory_after_setup", "host_memory_at_exit")]
    high_water = [
        row[key]
        for row in hosts
        for key in ("max_rss_bytes", "VmHWM_bytes")
        if row.get(key) is not None
    ]
    rusage = [row["max_rss_bytes"] for row in hosts if row.get("max_rss_bytes") is not None]
    proc_hwm = [row["VmHWM_bytes"] for row in hosts if row.get("VmHWM_bytes") is not None]
    return {
        "whole_run_peak_allocated_bytes": info.get("whole_run_peak_allocated_bytes"),
        "whole_run_peak_reserved_bytes": info.get("whole_run_peak_reserved_bytes"),
        "sampled_device_free_min_bytes": info.get("device_free_min_bytes"),
        "sampled_device_used_peak_bytes": info.get("device_used_peak_bytes"),
        "host_process_high_water_bytes": max(high_water) if high_water else None,
        "getrusage_high_water_bytes": max(rusage) if rusage else None,
        "proc_current_mm_high_water_bytes": max(proc_hwm) if proc_hwm else None,
        "proc_rss_after_setup_bytes": hosts[0].get("VmRSS_bytes"),
        "proc_rss_at_exit_bytes": hosts[1].get("VmRSS_bytes"),
        "host_scope": "Per-process high-water RSS, including setup; not total machine RAM",
    }


def _qualification(replayed: dict[str, Any] | None) -> dict[str, Any]:
    if not replayed:
        return {"status": "NOT_IN_INDEPENDENT_REPLAY", "passed": False}
    result = {"status": replayed["status"], "passed": replayed.get("passed") is True}
    for phase in ("primary", "semantics"):
        gate = replayed.get("gates", {}).get(phase)
        if gate is not None:
            result[phase] = {
                name: gate.get(name)
                for name in ("passed", "bitwise_equal", "tensor_count", "loss_three_decimals")
            }
    if result["passed"] and (
        result["status"] != "QUALIFIED_TENSORS_REPLAYED"
        or any(not result.get(phase, {}).get("passed") for phase in ("primary", "semantics"))
    ):
        raise ValueError("Incomplete independent accuracy record cannot qualify a count")
    return result


def _selection_screen(
    evidence: Evidence, cohort: str, count: int, qualified: bool
) -> dict[str, Any] | None:
    folder = f"{cohort}/selection-screen-{count}"
    metrics = _optional_json(evidence, folder + "/metrics.json")
    info = _optional_json(evidence, folder + "/residency-sweep-provenance.json")
    if metrics is None and info is None:
        return None
    stages = evidence.progress.get("stages", [])
    names = [row["name"] for row in stages]
    capture, semantic, screen = (
        f"capture-{cohort}-{count}",
        f"semantics-{cohort}-{count}",
        f"selection-screen-{cohort}-{count}",
    )
    after_accuracy = qualified and all(name in names for name in (capture, semantic, screen))
    after_accuracy = after_accuracy and max(
        names.index(capture), names.index(semantic)
    ) < names.index(screen)
    result: dict[str, Any] = {
        "selection_only_not_heldout_performance": True,
        "independently_qualified_count": qualified,
        "screen_after_accuracy": after_accuracy,
    }
    values = (metrics or {}).get("seconds", [])
    complete = (
        after_accuracy
        and all(
            stages[names.index(name)].get("exit_code") == 0 for name in (capture, semantic, screen)
        )
        and info is not None
        and info.get("status") == "COMPLETED_NOT_AN_INDEPENDENT_VERDICT"
        and info.get("capacity_failure") is None
        and info.get("requested_resident_layers") == count
        and info.get("device_free_min_bytes", -1) >= 128 * 2**20
        and metrics is not None
        and metrics.get("status") == "TIMING_CAPTURED_NOT_A_CORRECTNESS_OR_QUALITY_VERDICT"
        and metrics.get("warmup") == 2
        and metrics.get("steps") == 3
        and len(values) == 3
        and all(
            type(value) in (int, float) and math.isfinite(value) and value > 0 for value in values
        )
    )
    if not complete:
        return {**result, "status": "FAILED_OR_INCOMPLETE_SELECTION_SCREEN"}
    return {
        **result,
        "status": "VALID_SELECTION_ONLY",
        "warmup": 2,
        "measured_updates": 3,
        "median_seconds": statistics.median(values),
        "seconds": values,
    }


def count_matrix(
    evidence: Evidence, replayed: dict[str, Any], worker: dict[str, Any]
) -> dict[str, Any]:
    result = {}
    keys = set(worker.get("cohorts", {}))
    keys.update(name.split("/", 1)[0] for name in replayed.get("qualifications", {}))
    for key in sorted(keys):
        saved = worker.get("cohorts", {}).get(key, {})
        counts = set(map(int, saved.get("capacity_screens", {})))
        counts.update(map(int, saved.get("accuracy", {})))
        counts.update(saved.get("qualified_counts", []))
        for name in evidence.files:
            parts = name.split("/")
            if (
                len(parts) == 3
                and parts[0] == key
                and parts[2] == "residency-sweep-provenance.json"
            ):
                counts.add(int(parts[1].rsplit("-", 1)[-1]))
        rows = []
        for count in sorted(counts):
            qualification = _qualification(replayed.get("qualifications", {}).get(f"{key}/{count}"))
            row: dict[str, Any] = {"count": count, "accuracy": qualification}
            for phase in ("capacity", "capture", "semantics"):
                folder = f"{key}/{phase}-{count}"
                info = _optional_json(evidence, folder + "/residency-sweep-provenance.json")
                if info is None:
                    continue
                if info.get("requested_resident_layers") != count:
                    raise ValueError("Raw process count differs from its retained path")
                details = {
                    "status": info["status"],
                    "capacity_failure": info.get("capacity_failure"),
                    "actual_indices": info.get("indices"),
                    "actual_resident_bytes": info.get("resident_bytes"),
                    "completed_update_count": len(info.get("all_update_wall_seconds", [])),
                    **_process_memory(info),
                }
                if phase == "capacity":
                    details["capacity_only_not_accuracy_or_performance"] = True
                    details["screen_fit"] = (
                        info.get("capacity_only") is True
                        and info["status"] == "COMPLETED_NOT_AN_INDEPENDENT_VERDICT"
                        and not info.get("capacity_failure")
                        and details["completed_update_count"] == 3
                        and info.get("device_free_min_bytes", -1) >= 128 * 2**20
                    )
                row[phase] = details
            row["selection"] = _selection_screen(evidence, key, count, qualification["passed"])
            rows.append(row)
        fit = [row["count"] for row in rows if row.get("capacity", {}).get("screen_fit")]
        refused = [row["count"] for row in rows if row.get("capacity", {}).get("capacity_failure")]
        result[key] = {
            "worker_cohort_status": saved.get("status"),
            "selected_count": saved.get("selected_count"),
            "largest_successfully_capacity_screened_count": max(fit) if fit else None,
            "refused_capacity_counts": refused,
            "capacity_boundary_scope": (
                "Tested fixed counts and sampled free floor; not a global maximum"
            ),
            "rows": rows,
        }
    return result


def prepared_payloads(evidence: Evidence) -> dict[str, Any]:
    formats: dict[str, Any] = {}
    for name in sorted(evidence.files):
        if not name.endswith(".prepare.json"):
            continue
        item = evidence.json(name)
        if item.get("status") != "PREPARED_CACHE_NOT_A_TRAINING_VERDICT":
            raise ValueError("Preparation inventory did not complete")
        files = item["shard_files"]
        for row in files.values():
            if type(row.get("bytes")) is not int or row["bytes"] < 0 or not row.get("sha256"):
                raise ValueError("Preparation inventory lacks exact shard bytes/SHA256")
        quant = item["quant"]
        identity = {
            path: {key: row[key] for key in ("bytes", "sha256")} for path, row in files.items()
        }
        if quant in formats:
            if identity != formats[quant]["shard_files"]:
                raise ValueError("Matched format/source preparation inventories differ")
            formats[quant]["preparation_manifests"].append(name)
            continue
        layer_files = [row["bytes"] for path, row in files.items() if path.startswith("layer_")]
        formats[quant] = {
            "preparation_manifests": [name],
            "total_cache_payload_and_index_bytes": sum(row["bytes"] for row in files.values()),
            "safetensors_bytes": sum(
                row["bytes"] for path, row in files.items() if path.endswith(".safetensors")
            ),
            "index_bytes": files.get("index.json", {}).get("bytes"),
            "layer_file_bytes_min": min(layer_files) if layer_files else None,
            "layer_file_bytes_max": max(layer_files) if layer_files else None,
            "file_count": len(files),
            "double_quant": item.get("double_quant"),
            "shard_files": identity,
            "scope": (
                "Prepared cache data/sidecars/index file bytes; not training VRAM or process RAM"
            ),
        }
    return formats


def _timing_arm(
    evidence: Evidence, label: str, arm: str, pairs: list[dict[str, Any]], initial_sha: str
) -> dict[str, Any]:
    medians, allocated, reserved, infos, last_reads, last_copies = [], [], [], [], [], []
    last_loads, last_large_loads = [], []
    measured_read_proof = []
    phase_values: dict[str, list[Any]] = {name: [] for name in PHASE_FIELDS}
    for number, pair in enumerate(pairs):
        folder = f"heldout/{label}/pair-{number}-{arm}"
        metrics = timing_metrics(evidence, folder, initial_sha)
        raw_info = evidence.json(folder + "/residency-sweep-provenance.json")
        position = 0 if arm == "baseline" else 1
        values = pair["baseline" if arm == "baseline" else "auto"]
        if metrics["seconds"] != values or pair["provenance"][position] != raw_info:
            raise ValueError("Final replay and raw held-out metrics/provenance disagree")
        peaks = pair["peaks"][position]
        if any(peaks[name] != max(metrics[name]) for name in peaks):
            raise ValueError("Final replay and measured held-out memory peaks disagree")
        stages = [
            row
            for row in evidence.progress.get("stages", [])
            if row["name"] == f"heldout-{label}-{number}-{arm}"
        ]
        stage = stages[0] if len(stages) == 1 and stages[0].get("exit_code") == 0 else {}
        phase_sources = {"metrics": metrics, "provenance": raw_info, "stage": stage}
        for name, (origin, field) in PHASE_FIELDS.items():
            phase_values[name].append(phase_sources[origin].get(field))
        medians.append(statistics.median(values))
        allocated.extend(metrics["peak_allocated_bytes"])
        reserved.extend(metrics["peak_reserved_bytes"])
        infos.append(raw_info)
        io = raw_info.get("per_update_io", [])
        loads = raw_info.get("per_update_loads", [])
        io_window = len(io) == 14 and [row.get("step") for row in io] == list(range(1, 15))
        load_window = len(loads) == 14 and [row.get("step") for row in loads] == list(range(1, 15))
        if io_window:
            last_reads.extend(row["linux_process_io_delta"]["read_bytes"] for row in io[-8:])
        measured_read_proof.append(
            nvme_proof(raw_info)
            and io_window
            and sum(row["linux_process_io_delta"]["read_bytes"] for row in io[-8:]) > 0
        )
        if load_window and all(
            row.get("logical_decoder_copy_bytes") is not None for row in loads[-8:]
        ):
            last_copies.extend(row["logical_decoder_copy_bytes"] for row in loads[-8:])
        if load_window:
            if all(type(row.get("loads")) is int for row in loads[-8:]):
                last_loads.extend(row["loads"] for row in loads[-8:])
            if all(type(row.get("large_loads")) is int for row in loads[-8:]):
                last_large_loads.extend(row["large_loads"] for row in loads[-8:])
    memories = [_process_memory(info) for info in infos]

    def observed(name: str, operation: Any) -> Any:
        values = [row[name] for row in memories if row[name] is not None]
        return operation(values) if values else None

    def counter(values: list[int]) -> dict[str, Any] | None:
        if len(values) != 32:
            return None
        return {"median": statistics.median(values), "range": [min(values), max(values)]}

    return {
        "representative_seconds_per_step": statistics.median(medians),
        "per_process_median_seconds": medians,
        "measured_updates": 32,
        "max_measured_peak_allocated_bytes": max(allocated),
        "max_measured_peak_reserved_bytes": max(reserved),
        "sampled_device_free_min_bytes": observed("sampled_device_free_min_bytes", min),
        "host_process_high_water_bytes": observed("host_process_high_water_bytes", max),
        "getrusage_high_water_bytes": observed("getrusage_high_water_bytes", max),
        "proc_current_mm_high_water_bytes": observed("proc_current_mm_high_water_bytes", max),
        "max_proc_rss_after_setup_bytes": observed("proc_rss_after_setup_bytes", max),
        "max_proc_rss_at_exit_bytes": observed("proc_rss_at_exit_bytes", max),
        "median_measured_step_io_read_bytes": statistics.median(last_reads)
        if len(last_reads) == 32
        else None,
        "median_measured_step_logical_decoder_copy_bytes": (
            statistics.median(last_copies) if len(last_copies) == 32 else None
        ),
        "measured_step_decoder_loads": counter(last_loads),
        "measured_step_large_tensor_loads": counter(last_large_loads),
        "measured_step_logical_decoder_copy_bytes": counter(last_copies),
        "step_io_scope": "Last eight optimizer updates per process; warmup excluded",
        "direct_io_all_processes": all(info.get("direct_io") is True for info in infos),
        "nvme_read_proof_all_processes": all(measured_read_proof),
        "nvme_read_proof_scope": "Positive device reads in each last-eight-update timing window",
        "storage_backing_proofs": [info.get("storage_validation") for info in infos],
        "descriptive_timing_phases": {
            "predeclared": False,
            "gating": False,
            "optimizer_updates_per_process": 14,
            "phases": {
                name: _phase_summary(values, ".".join(PHASE_FIELDS[name]))
                for name, values in phase_values.items()
            },
            "scope": (
                "Cached-model setup, fourteen updates and final save, benchmark entry, and worker "
                "child-process wall time are overlapping windows; never add them together. "
                "Original model download/shard preparation and result transfer are excluded. "
                "Worker stage includes child-process launch/exit; benchmark-entry timing starts "
                "after the initial harness imports."
            ),
        },
    }


def heldout_summary(evidence: Evidence, replayed: dict[str, Any]) -> dict[str, Any]:
    result = {}
    for label, checked in replayed.get("heldout", {}).items():
        if checked.get("status") != "HELDOUT_REPLAYED":
            result[label] = {"status": checked["status"], "performance_verdict_available": False}
            continue
        pairs, trajectories = checked["pairs"], checked["trajectories"]
        if len(trajectories) != 4 or any(
            not row.get("passed")
            or not row.get("loss_three_decimals")
            or row.get("tensor_count") != 504
            for row in trajectories
        ):
            raise ValueError(
                "Held-out result lacks four independently qualified 504-adapter trajectories"
            )
        performance = summarize(pairs)
        if performance != checked["performance"]:
            raise ValueError(
                "Held-out replay performance differs from recomputed four-pair results"
            )
        baseline_info, candidate_info = pairs[0]["provenance"]
        quant = baseline_info["requested_quant"]
        source = candidate_info["actual_tier"]
        count = candidate_info["resident_layers"]
        identifiers = [f"{quant}-ram/0", f"{quant}-{source}/{count}"]
        qualified = [replayed["qualifications"].get(name) for name in identifiers]
        if not all(_qualification(row)["passed"] for row in qualified):
            raise ValueError("Held-out comparison lacks same-format independently qualified arms")
        initial_sha = qualified[0]["initial_adapter_sha256"]
        baseline = _timing_arm(evidence, label, "baseline", pairs, initial_sha)
        candidate = _timing_arm(evidence, label, "candidate", pairs, initial_sha)
        result[label] = {
            "status": "HELDOUT_REPLAYED",
            "performance_verdict_available": True,
            "reference": identifiers[0],
            "candidate": identifiers[1],
            "performance": performance,
            "baseline": baseline,
            "candidate_metrics": candidate,
            "all_final_adapters_bitwise_equal": all(row["bitwise_equal"] for row in trajectories),
            "all_fourteen_update_losses_exact": all(row["losses_equal"] for row in trajectories),
            "exploratory_14_update_training_wall": _training_wall_pairs(baseline, candidate),
        }
        if source == "disk":
            multiplier = statistics.median(
                statistics.median(pair["auto"]) / statistics.median(pair["baseline"])
                for pair in pairs
            )
            if multiplier != checked.get("disk_step_time_multiplier"):
                raise ValueError("Disk multiplier differs from independent paired medians")
            result[label].update(
                disk_step_time_multiplier=multiplier,
                nvme_timing_qualified=candidate["nvme_read_proof_all_processes"],
                storage_claim=(
                    "NVMe-backed direct-I/O training with observed device reads"
                    if candidate["nvme_read_proof_all_processes"]
                    else "Disk-tier result; complete NVMe training-read proof unavailable"
                ),
            )
    return result


def build(root: Path, *, evidence: Evidence | None = None) -> dict[str, Any]:
    budget = cleanup_and_budget(root)
    replayed = read_json(root / "independent-replay.json")
    worker = read_json(root / "final-worker-summary.json")
    if worker.get("status") not in {"COMPLETE_REQUIRES_INDEPENDENT_REPLAY", "PARTIAL", "FAILED"}:
        raise ValueError("Worker summary is not final")
    if replayed.get("status") not in {
        "REPLAY_COMPLETE",
        "PARTIAL_WITH_FAILED_OR_INCOMPLETE_EVIDENCE",
        "ACCURACY_ONLY_OR_PENDING_TIMING",
        "NO_QUALIFIED_EVIDENCE",
    }:
        raise ValueError("Independent replay is not a completed evidence assessment")
    evidence = evidence or retained_evidence(root)
    for field in ("stages", "cohorts", "heldout"):
        if evidence.progress.get(field, {}) != worker.get(field, {}):
            raise ValueError(f"Final worker summary and retained evidence disagree: {field}")
    return {
        "status": "FINAL_EVIDENCE_SUMMARY_RESOURCES_ABSENT",
        "independent_replay_status": replayed["status"],
        "worker_status": worker["status"],
        "count_matrix": count_matrix(evidence, replayed, worker),
        "prepared_cache_payloads": prepared_payloads(evidence),
        "heldout": heldout_summary(evidence, replayed),
        "quantization_diagnostic": replayed.get(
            "cross_format_diagnostic", {"status": "NOT_AVAILABLE"}
        ),
        "budget": budget,
        "input_documents": {
            name: file_identity(root / name)
            for name in (
                "independent-replay.json",
                "final-worker-summary.json",
                "stage-ledger.json",
                "prior-stage-ledger-snapshot.json",
                "vast-deletion.json",
                "vast-volume-deletion.json",
            )
        },
        "limitations": [
            "Fixed model/configuration and research counts; not a general automatic-memory policy.",
            "Capacity/three-update selection screens do not qualify accuracy or held-out speed.",
            "VRAM free minima are sampled at setup/update/completion, not continuous guarantees.",
            "CPU memory is per-process high-water RSS including setup, not machine-wide usage.",
            "getrusage may retain pre-exec HWM; /proc VmHWM covers the current memory map.",
            "Different HWM counters do not establish which earlier code allocated memory.",
            "Semantic tensors replay independently; perturbed causal/padding outputs not retained.",
            "NF4 is lossy; BF16 comparison is diagnostic, never a residency correctness gate.",
        ],
    }


def _gib(value: Any) -> str:
    return "—" if value is None else f"{value / 2**30:.3f}"


def _yes(value: Any) -> str:
    return "—" if value is None else ("yes" if value else "no")


def _counter_text(value: dict[str, Any] | None) -> str:
    if value is None:
        return "—"
    lower, upper = value["range"]
    return f"{value['median']:g} [{lower}, {upper}]"


def _phase_text(phase: dict[str, Any]) -> str:
    if phase["status"] != "COMPLETE":
        return f"— ({phase['available_processes']}/4 available)"
    lower, upper = phase["range_seconds"]
    return f"{phase['median_seconds']:.3f} [{lower:.3f}, {upper:.3f}]"


def markdown(summary: dict[str, Any]) -> str:
    lines = [
        "**Prepared cache footprint (file bytes, not training VRAM)**",
        "",
        "| Format | Complete cache + index GiB | Layer file MiB, min–max | Files | "
        "Double quantization |",
        "| --- | ---: | ---: | ---: | --- |",
    ]
    for quant, item in summary["prepared_cache_payloads"].items():
        lower, upper = item["layer_file_bytes_min"], item["layer_file_bytes_max"]
        layer = "—" if lower is None else f"{lower / 2**20:.3f}–{upper / 2**20:.3f}"
        lines.append(
            f"| {quant} | {_gib(item['total_cache_payload_and_index_bytes'])} | "
            f"{layer} | {item['file_count']} | {_yes(item['double_quant'])} |"
        )
    lines.extend(
        [
            "",
            "Cache bytes include unquantized large tensors and metadata; "
            "they do not imply a corresponding VRAM reduction.",
            "",
        ]
    )
    for key, title in (
        ("none-ram", "BF16 RAM fixed-count sweep"),
        ("nf4-ram", "NF4 RAM capacity sweep"),
    ):
        cohort = summary["count_matrix"].get(key)
        if cohort is None:
            continue
        lines.extend(
            [
                f"**{title}**",
                "",
                "| Layers | Capacity screen | Accuracy | Primary / semantic bitwise | "
                "Capture allocated / reserved GiB | Sampled free min GiB | "
                "Selection only, s/step |",
                "| ---: | --- | --- | --- | ---: | ---: | ---: |",
            ]
        )
        for row in cohort["rows"]:
            capacity, accuracy, capture = (
                row.get("capacity", {}),
                row["accuracy"],
                row.get("capture", {}),
            )
            capacity_text = capacity.get("capacity_failure") or (
                "3 updates fit"
                if capacity.get("screen_fit")
                else capacity.get("status", "not retained")
            )
            selection = row.get("selection")
            screen = "—"
            if selection:
                screen = (
                    f"{selection['median_seconds']:.4f}"
                    if selection["status"] == "VALID_SELECTION_ONLY"
                    else "unavailable"
                )
            bits = " / ".join(
                _yes(accuracy.get(phase, {}).get("bitwise_equal"))
                for phase in ("primary", "semantics")
            )
            lines.append(
                f"| {row['count']} | {capacity_text} | {accuracy['status']} | {bits} | "
                f"{_gib(capture.get('whole_run_peak_allocated_bytes'))} / "
                f"{_gib(capture.get('whole_run_peak_reserved_bytes'))} | "
                f"{_gib(capture.get('sampled_device_free_min_bytes'))} | {screen} |"
            )
        lines.extend(
            ["", "Capacity screens and selection times are not held-out performance evidence.", ""]
        )
    lines.extend(
        [
            "**Independent held-out comparisons**",
            "",
            "| Comparison | Baseline → candidate s/step | Paired time cut, 95% CI | ≥2% gate | "
            "Allocated GiB, baseline → candidate | Reserved GiB, baseline → candidate |",
            "| --- | ---: | --- | --- | ---: | ---: |",
        ]
    )
    for label, row in summary["heldout"].items():
        if not row["performance_verdict_available"]:
            lines.append(f"| {label} | no verdict: {row['status']} | — | — | — | — |")
            continue
        baseline, candidate, performance = (
            row["baseline"],
            row["candidate_metrics"],
            row["performance"],
        )
        lower, upper = performance["bootstrap95_percent"]
        lines.append(
            f"| {label} | {baseline['representative_seconds_per_step']:.4f} → "
            f"{candidate['representative_seconds_per_step']:.4f} | "
            f"{performance['median_paired_step_time_reduction_percent']:.2f}% "
            f"[{lower:.2f}, {upper:.2f}] | {_yes(performance['practical_speed_gate_passed'])} | "
            f"{_gib(baseline['max_measured_peak_allocated_bytes'])} → "
            f"{_gib(candidate['max_measured_peak_allocated_bytes'])} | "
            f"{_gib(baseline['max_measured_peak_reserved_bytes'])} → "
            f"{_gib(candidate['max_measured_peak_reserved_bytes'])} |"
        )
    if not summary["heldout"]:
        lines.append("| No independently replayed held-out comparison | — | — | — | — | — |")
    lines.extend(
        [
            "",
            "Step medians summarize four fresh processes per arm, eight measured updates each. "
            "Time cut is the median of paired reductions; 95% bootstrap resamples whole pairs.",
            "",
            "| Comparison | CPU process HWM GiB, baseline → candidate | "
            "Measured read GiB/step, baseline → candidate | Disk / RAM step multiplier | "
            "NVMe training reads proven |",
            "| --- | ---: | ---: | ---: | --- |",
        ]
    )
    for label, row in summary["heldout"].items():
        if not row["performance_verdict_available"]:
            continue
        baseline, candidate = row["baseline"], row["candidate_metrics"]
        multiplier = row.get("disk_step_time_multiplier")
        lines.append(
            f"| {label} | {_gib(baseline['host_process_high_water_bytes'])} → "
            f"{_gib(candidate['host_process_high_water_bytes'])} | "
            f"{_gib(baseline['median_measured_step_io_read_bytes'])} → "
            f"{_gib(candidate['median_measured_step_io_read_bytes'])} | "
            f"{f'{multiplier:.3f}×' if multiplier is not None else '—'} | "
            f"{_yes(row.get('nvme_timing_qualified'))} |"
        )
    lines.extend(
        [
            "",
            "| Comparison | getrusage HWM GiB, baseline → candidate | "
            "/proc VmHWM GiB, baseline → candidate | /proc VmRSS setup GiB, baseline → candidate | "
            "/proc VmRSS exit GiB, baseline → candidate |",
            "| --- | ---: | ---: | ---: | ---: |",
        ]
    )
    for label, row in summary["heldout"].items():
        if not row["performance_verdict_available"]:
            continue
        baseline, candidate = row["baseline"], row["candidate_metrics"]
        lines.append(
            f"| {label} | {_gib(baseline['getrusage_high_water_bytes'])} → "
            f"{_gib(candidate['getrusage_high_water_bytes'])} | "
            f"{_gib(baseline['proc_current_mm_high_water_bytes'])} → "
            f"{_gib(candidate['proc_current_mm_high_water_bytes'])} | "
            f"{_gib(baseline['max_proc_rss_after_setup_bytes'])} → "
            f"{_gib(candidate['max_proc_rss_after_setup_bytes'])} | "
            f"{_gib(baseline['max_proc_rss_at_exit_bytes'])} → "
            f"{_gib(candidate['max_proc_rss_at_exit_bytes'])} |"
        )
    lines.extend(
        [
            "",
            "CPU columns are per-arm maxima across process snapshots, not whole-machine RAM. "
            "The earlier CPU HWM column retains the conservative maximum of both counters. "
            "getrusage can retain a pre-exec high-water mark; /proc VmHWM describes the current "
            "memory map. Their difference does not establish which earlier code allocated memory.",
            "",
            "| Comparison | Decoder loads/step, median [range], baseline → candidate | "
            "Large-tensor loads/step, median [range], baseline → candidate | "
            "Logical decoder copy GiB/step, baseline → candidate |",
            "| --- | --- | --- | ---: |",
        ]
    )
    for label, row in summary["heldout"].items():
        if not row["performance_verdict_available"]:
            continue
        baseline, candidate = row["baseline"], row["candidate_metrics"]
        lines.append(
            f"| {label} | {_counter_text(baseline['measured_step_decoder_loads'])} → "
            f"{_counter_text(candidate['measured_step_decoder_loads'])} | "
            f"{_counter_text(baseline['measured_step_large_tensor_loads'])} → "
            f"{_counter_text(candidate['measured_step_large_tensor_loads'])} | "
            f"{_gib(baseline['median_measured_step_logical_decoder_copy_bytes'])} → "
            f"{_gib(candidate['median_measured_step_logical_decoder_copy_bytes'])} |"
        )
    lines.extend(
        [
            "",
            "Load/copy counters use only the last eight updates per process. Private resident "
            "layer count alone does not describe additional weights retained in rotating buffers.",
            "",
        ]
    )
    lines.extend(
        [
            "**Descriptive complete-run phases (exploratory, not preregistered or gating)**",
            "",
            "| Comparison | Phase | Baseline seconds, median [range] | "
            "Candidate seconds, median [range] |",
            "| --- | --- | ---: | ---: |",
        ]
    )
    phase_labels = {
        "metrics_setup_seconds": "Dataset/model/trainer setup + adapter initialization/digest",
        "training_14_updates_and_save_seconds": "All 14 optimizer updates + final adapter save",
        "stream_setup_seconds": "Streaming setup + private-slot installation",
        "benchmark_entry_seconds": "Benchmark entry (cached model)",
        "worker_process_stage_seconds": (
            "Worker child-process wall (includes Python launch/imports)"
        ),
    }
    for label, row in summary["heldout"].items():
        if not row["performance_verdict_available"]:
            continue
        arms = [
            row[key]["descriptive_timing_phases"]["phases"]
            for key in ("baseline", "candidate_metrics")
        ]
        for name, description in phase_labels.items():
            lines.append(
                f"| {label} | {description} | {_phase_text(arms[0][name])} | "
                f"{_phase_text(arms[1][name])} |"
            )
        paired = row["exploratory_14_update_training_wall"]
        if paired["status"] == "COMPLETE":
            values = ", ".join(f"{value:.3f}%" for value in paired["paired_time_reduction_percent"])
            lines.append(
                f"| {label} | Descriptive 14-update training+save time cuts by pair | "
                f"{values} | median {paired['median_paired_time_reduction_percent']:.3f}% |"
            )
        else:
            lines.append(
                f"| {label} | Descriptive 14-update training+save time cuts | "
                f"unavailable: {paired['available_pairs']}/4 pairs | — |"
            )
    lines.extend(
        [
            "",
            "These windows overlap and must not be summed. Setup uses an already prepared local "
            "model/cache. The 14-update training window includes six warmup updates, "
            "eight measured updates and the final save; it is not a complete dataset/epoch run. "
            "Worker stage additionally includes Python launch/imports. Original model download, "
            "shard preparation and result transfer are excluded. These descriptive outcomes have "
            "no new winner gate and do not replace the preregistered steady-step ≥2% gate.",
            "",
        ]
    )
    diagnostic = summary["quantization_diagnostic"]
    lines.extend(
        [
            "",
            "**BF16 → NF4 diagnostic (non-gating, lossy format change)**",
            "",
            diagnostic["status"],
            "",
        ]
    )
    if diagnostic.get("gates"):
        lines.extend(
            [
                "| Phase | Original numeric gate | Bitwise equal | Failed tensors | "
                "Largest absolute delta |",
                "| --- | --- | --- | ---: | ---: |",
            ]
        )
        for phase, gate in diagnostic["gates"].items():
            groups = gate["groups"].values()
            lines.append(
                f"| {phase} | {_yes(gate['passed'])} | {_yes(gate['bitwise_equal'])} | "
                f"{sum(group['failed_tensors'] for group in groups)} | "
                f"{max((group['max_abs'] for group in gate['groups'].values()), default=0):.6g} |"
            )
        lines.append("")
    budget = summary["budget"]
    cleanup = budget["cleanup"]
    lines.extend(
        [
            "**Budget and cleanup**",
            "",
            f"Prior leases ${budget['prior_leases_usd']:.6f}; current lease "
            f"${budget['current_lease_usd']:.6f}; aggregate conservative estimate "
            f"${budget['aggregate_conservative_usd']:.6f} / ${budget['maximum_stage_usd']:.2f}; "
            f"remaining ${budget['remaining_to_limit_usd']:.6f}.",
            "",
            f"Instance `{cleanup['instance_id']}` and volume `{cleanup['volume_id']}` "
            "independently verified absent. Cost is a conservative ledger estimate, "
            "not the provider invoice.",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).parent)
    args = parser.parse_args()
    summary = build(args.root)
    (args.root / "result-summary.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8"
    )
    (args.root / "results-tables.md").write_text(markdown(summary), encoding="utf-8")
    Console().print({"status": summary["status"], "report": str(args.root / "result-summary.json")})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
