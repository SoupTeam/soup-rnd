"""Independent bounded-memory CPU replay of retained residency-sweep evidence."""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
import os
import posixpath
import random
import statistics
import tarfile
from pathlib import Path
from typing import Any

from rich.console import Console

RTOL = 0.01
ATOL = 0.00001
DATA_SHA256 = "313d17f90f4b62004a1d8232ba9bc0b19388a65e933c930ddc9aecfe7ffbf0f9"
PAIR_ORDER = ["AB", "BA", "BA", "AB"]


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def file_identity(path: Path) -> dict[str, Any]:
    before = path.stat()
    hashed = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(4 * 2**20), b""):
            hashed.update(block)
    after = path.stat()
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        raise ValueError(f"Retained file changed while hashing: {path}")
    return {"bytes": after.st_size, "sha256": hashed.hexdigest()}


class Evidence:
    """Read originals in place; conflicting duplicate raw paths never use last-wins."""

    def __init__(self, roots: list[Path]):
        self.roots: list[Path] = []
        self.files: dict[str, Path] = {}
        self.duplicates: list[dict[str, Any]] = []
        self.snapshots: list[dict[str, Any]] = []
        for supplied in roots:
            root = supplied / "results" if (supplied / "results").is_dir() else supplied
            if not root.is_dir():
                raise ValueError(f"Missing evidence root: {root}")
            self.roots.append(root)
            progress = root / "progress.json"
            if progress.is_file():
                self.snapshots.append({"path": str(progress), "value": read_json(progress)})
            for path in root.rglob("*"):
                if not path.is_file():
                    continue
                if path.is_symlink():
                    raise ValueError(f"Evidence must not follow symlink files: {path}")
                relative = path.relative_to(root).as_posix()
                if relative in {"progress.json", "gpu-telemetry.jsonl"}:
                    continue  # Mutable snapshots, not immutable tensor/process evidence.
                old = self.files.get(relative)
                if old is not None and not os.path.samefile(path, old):
                    first, second = file_identity(old), file_identity(path)
                    if first != second:
                        raise ValueError(f"Conflicting duplicate retained path: {relative}")
                    self.duplicates.append({"path": relative, **first})
                else:
                    self.files[relative] = path
        if not self.snapshots:
            raise ValueError("No retained worker progress snapshot")
        selected = max(
            enumerate(self.snapshots),
            key=lambda pair: (
                len(pair[1]["value"].get("stages", [])),
                len(pair[1]["value"].get("bundles", [])),
                pair[0],
            ),
        )[1]
        self.progress = selected["value"]
        self.progress_path = selected["path"]
        longest = self.progress.get("stages", [])
        for snapshot in self.snapshots:
            stages = snapshot["value"].get("stages", [])
            if stages != longest[: len(stages)]:
                raise ValueError(
                    "Mutable progress snapshots disagree about completed stage history"
                )

    def get(self, relative: str) -> Path:
        if relative not in self.files:
            raise FileNotFoundError(f"Missing retained original: {relative}")
        return self.files[relative]

    def json(self, relative: str) -> Any:
        return read_json(self.get(relative))


def slices(shape: tuple[int, ...], maximum: int):
    if type(maximum) is not int or maximum < 1 or any(length < 1 for length in shape):
        raise ValueError("Positive slice limit and nonempty tensor dimensions required")
    tile, remaining = [1] * len(shape), maximum
    for axis in reversed(range(len(shape))):
        tile[axis] = min(shape[axis], remaining)
        remaining = max(1, remaining // tile[axis])
    for start in itertools.product(
        *[range(0, length, width) for length, width in zip(shape, tile)]
    ):
        yield tuple(
            slice(offset, min(offset + width, length))
            for offset, width, length in zip(start, tile, shape)
        )


def compare_files(
    reference: Path, candidate: Path, *, maximum: int = 131072, trace: bool = True
) -> dict[str, Any]:
    """Same reference-first torch predicates, evaluated on every bounded slice.

    The original torch.allclose(reference, candidate) is deliberately preserved;
    do not replace it with a formula scaled by abs(reference). PyTorch uses the
    second argument for its relative-error scale.
    """
    import torch
    from safetensors import safe_open

    identities = [file_identity(path) for path in (reference, candidate)]
    snapshots = [(path.stat().st_size, path.stat().st_mtime_ns) for path in (reference, candidate)]
    identical = identities[0] == identities[1]
    groups: dict[str, Any] = {}
    bitwise, loss_match, maximum_slice, elements = True, True, 0, 0
    with (
        safe_open(str(reference), framework="pt", device="cpu") as first,
        safe_open(str(candidate), framework="pt", device="cpu") as second,
    ):
        keys = list(first.keys())
        if set(keys) != set(second.keys()):
            raise ValueError("Retained tensor keys differ")
        if trace and "loss" not in keys:
            raise ValueError("Trace lacks the original comparator's required loss tensor")
        for name in keys:
            left, right = first.get_slice(name), second.get_slice(name)
            shape = tuple(left.get_shape())
            if shape != tuple(right.get_shape()) or left.get_dtype() != right.get_dtype():
                raise ValueError(f"Retained tensor shape/dtype differs: {name}")
            group = name.split("/")[0] if trace else "adapter"
            exact = trace and group in {"batch", "initial"}
            stats = groups.setdefault(
                group,
                {
                    "tensors": 0,
                    "failed_tensors": 0,
                    "max_abs": 0.0,
                    "failures": [],
                },
            )
            stats["tensors"] += 1
            finite, close, tensor_equal, count, nan = True, True, True, 0, False
            for selector in slices(shape, maximum):
                value = left[selector] if shape else first.get_tensor(name)
                other = (
                    value if identical else (right[selector] if shape else second.get_tensor(name))
                )
                size = value.numel()
                if size > maximum:
                    raise ValueError("Bounded comparison exceeded the element limit")
                count += size
                maximum_slice = max(maximum_slice, size)
                good = bool(torch.isfinite(value).all() and torch.isfinite(other).all())
                finite = finite and good
                nan = nan or bool(torch.isnan(value).any() or torch.isnan(other).any())
                equal = bool(torch.equal(value, other))
                tensor_equal = tensor_equal and equal
                close = close and bool(
                    equal
                    if exact
                    else torch.allclose(
                        value,
                        other,
                        rtol=RTOL,
                        atol=ATOL,
                    )
                )
                if not identical and good:
                    difference = float((value.double() - other.double()).abs().max())
                    stats["max_abs"] = max(stats["max_abs"], difference)
                del value, other
            if count != math.prod(shape):
                raise ValueError("Bounded comparison did not cover every tensor element")
            elements += count
            bitwise = bitwise and tensor_equal and not nan
            if not finite or not close:
                stats["failed_tensors"] += 1
                stats["failures"].append(name)
            if trace and name == "loss":
                if len(shape) != 1:
                    raise ValueError("Original comparator requires a one-dimensional loss tensor")
                one, two = first.get_tensor(name).tolist(), second.get_tensor(name).tolist()
                loss_match = all(f"{a:.3f}" == f"{b:.3f}" for a, b in zip(one, two, strict=True))
        tensor_count = len(keys)
    for path, expected in zip((reference, candidate), snapshots):
        stat = path.stat()
        if (stat.st_size, stat.st_mtime_ns) != expected:
            raise ValueError("Retained tensor file changed after hashing/bounded comparison")
    return {
        "passed": loss_match and all(row["failed_tensors"] == 0 for row in groups.values()),
        "groups": groups,
        "loss_three_decimals": loss_match,
        "bitwise_equal": bitwise,
        "tensor_count": tensor_count,
        "rtol": RTOL,
        "atol": ATOL,
        "checked_elements": elements,
        "maximum_slice_elements": maximum_slice,
        "method": "full serialized SHA equality plus finite scan"
        if identical
        else ("bounded reference-first original torch predicates over every element"),
        "serialized_files": identities,
    }


def check_trace_schema(path: Path, phase: str, adapters: int, vocab: int) -> dict[str, Any]:
    import torch
    from safetensors import safe_open

    expected = (
        {
            "batch": 16,
            "loss": 1,
            "initial": adapters,
            "final": adapters,
            "gradient": 2 * adapters,
            "logits": 4,
        }
        if phase == "primary"
        else {
            "batch": 4,
            "loss": 1,
            "initial": adapters,
            "gradient": adapters,
            "logits": 1,
            "diagnostic": 1,
        }
    )
    groups: dict[str, int] = {}
    initial_hash = hashlib.sha256()
    with safe_open(str(path), framework="pt", device="cpu") as handle:
        for key in handle.keys():
            group = key.split("/")[0]
            groups[group] = groups.get(group, 0) + 1
        if groups != expected:
            raise ValueError(f"{phase} tensor groups/counts differ: {groups}")
        for name in sorted(key for key in handle.keys() if key.startswith("initial/")):
            value = handle.get_tensor(name)
            if "lora_" not in name or not bool(torch.count_nonzero(value)):
                raise ValueError("Every initial adapter must be a real nonzero LoRA tensor")
            initial_hash.update(name.removeprefix("initial/").encode())
            initial_hash.update(value.float().numpy().tobytes())
        parameter_names = {
            key.removeprefix("initial/") for key in handle.keys() if key.startswith("initial/")
        }
        if phase == "primary":
            final_names = {
                key.removeprefix("final/") for key in handle.keys() if key.startswith("final/")
            }
            if final_names != parameter_names:
                raise ValueError("Final adapter names differ from initialization")
            for update in range(2):
                prefix = f"gradient/{update}/"
                names = {
                    key.removeprefix(prefix) for key in handle.keys() if key.startswith(prefix)
                }
                if names != parameter_names:
                    raise ValueError("Pre-reset gradient names/counts differ from initialization")
            if handle.get_slice("loss").get_shape() != [4]:
                raise ValueError("Expected four microbatch losses")
            for index in range(4):
                for key in ("input_ids", "labels", "attention_mask"):
                    if handle.get_slice(f"batch/{index}/{key}").get_shape() != [1, 1024]:
                        raise ValueError("Primary batch shape differs from frozen input")
                if handle.get_slice(f"batch/{index}/num_items_in_batch").get_shape() != []:
                    raise ValueError("Primary num_items_in_batch must be scalar")
                if handle.get_slice(f"logits/{index}").get_shape() != [1, 1024, vocab]:
                    raise ValueError("Primary logit shape differs from frozen model/input")
        else:
            names = {
                key.removeprefix("gradient/")
                for key in handle.keys()
                if key.startswith("gradient/")
            }
            if names != parameter_names:
                raise ValueError("Semantic gradient names/counts differ from initialization")
            for key in ("input_ids", "attention_mask", "position_ids", "labels"):
                if handle.get_slice(f"batch/{key}").get_shape() != [2, 16]:
                    raise ValueError("Semantic input shape differs")
            if handle.get_slice("logits/valid").get_shape() != [25, vocab]:
                raise ValueError("Semantic valid-logit shape differs")
            if handle.get_slice("diagnostic/unpadded_logits").get_shape() != [1, 9, vocab]:
                raise ValueError("Semantic unpadded diagnostic shape differs")
            if handle.get_slice("loss").get_shape() != [1]:
                raise ValueError("Semantic loss shape differs")
    return {
        "tensor_count": sum(groups.values()),
        "groups": groups,
        "initial_adapter_sha256": initial_hash.hexdigest(),
    }


def verify_sources(helpers: Path) -> dict[str, Any]:
    launch = read_json(helpers / "launch-manifest.json")
    checked = {}
    for name in (
        "bench.py",
        "prepare_model.py",
        "worker.py",
        "timing_summary.py",
        "protocol.json",
        "source-manifest.json",
        "source.tar.gz",
    ):
        actual = file_identity(helpers / name)
        expected = launch.get(name)
        if not isinstance(expected, dict) or actual["sha256"] != expected.get("sha256"):
            raise ValueError(f"Frozen executed helper/source mismatch: {name}")
        if "bytes" in expected and actual["bytes"] != expected["bytes"]:
            raise ValueError(f"Frozen executed helper size mismatch: {name}")
        checked[name] = actual
    protocol = read_json(helpers / "protocol.json")
    if checked["source.tar.gz"]["sha256"] != protocol["source_sha256"]:
        raise ValueError("Protocol does not bind this production source archive")
    inventory = read_json(helpers / "source-manifest.json")
    target = "benchmarks/harness/liger_streaming_parity.py"
    expected = next(row for row in inventory["files"] if row["path"] == target)
    with tarfile.open(helpers / "source.tar.gz", "r:gz") as archive:
        member = next(item for item in archive.getmembers() if item.name.lstrip("./") == target)
        handle = archive.extractfile(member)
        if handle is None:
            raise ValueError("Original comparator missing from source archive")
        raw = handle.read()
    if len(raw) != expected["bytes"] or hashlib.sha256(raw).hexdigest() != expected["sha256"]:
        raise ValueError("Original comparator differs from its frozen source inventory")
    checked[target] = {"bytes": len(raw), "sha256": expected["sha256"]}
    return checked


def provenance(
    evidence: Evidence,
    folder: str,
    count: int,
    quant: str,
    source: str,
    entry_sha: str,
    layers: int,
) -> dict[str, Any]:
    info = evidence.json(folder + "/residency-sweep-provenance.json")
    expected_arm = "baseline" if count == 0 else f"resident{count}"
    if (
        info.get("status") != "COMPLETED_NOT_AN_INDEPENDENT_VERDICT"
        or info.get("capacity_failure") is not None
        or info.get("capacity_only")
    ):
        raise ValueError("Process did not finish as a non-capacity evidence run")
    if info.get("entry_sha256") != entry_sha or info.get("arm") != expected_arm:
        raise ValueError("Executed benchmark entry or arm differs")
    indices = list(range((layers - count) // 2, (layers - count) // 2 + count))
    if info.get("indices") != indices or info.get("resident_layers") != count:
        raise ValueError("Actual native pool mapping differs from fixed selection")
    if info.get("actual_mode") != 0 or info.get("actual_tier") != source:
        raise ValueError("Ordinary production mode or source differs")
    if info.get("requested_quant") != quant or info.get("layer_count") != layers:
        raise ValueError("Actual quantization or decoder count differs")
    total = info.get("physical_gpu_bytes", 0)
    if not 7.5 * 2**30 <= total <= 8.1 * 2**30:
        raise ValueError("Evidence is not from a real 8 GiB CUDA GPU")
    cap = min(
        total - 256 * 2**20,
        info["initial_device_free_bytes"] + info["initial_reserved_bytes"] - 128 * 2**20,
    )
    if info.get("allocator_budget_bytes") != cap:
        raise ValueError("Actual allocator cap differs from prospective memory policy")
    if info.get("device_free_min_bytes", -1) < 128 * 2**20:
        raise ValueError("Completed evidence violates the observed driver-free floor")
    prepared = info["prepared"]
    if prepared["quant"] != quant or prepared["source"] != source:
        raise ValueError("Prepared format/source differs from execution")
    if prepared.get("data_sha256") != DATA_SHA256:
        raise ValueError("Dataset differs from the frozen cohort-B bytes")
    actual_quant = info["quantization_actual"]
    if quant == "nf4":
        if not (
            prepared.get("double_quant")
            and prepared.get("quant_device") == "cuda"
            and actual_quant.get("loaded_in_4bit")
        ):
            raise ValueError("Actual NF4/cache markers differ")
        rows = actual_quant["quantized_layer_specs"]
        if len(rows) != layers or any(row["count"] != 7 or not row["nested"] for row in rows):
            raise ValueError("Actual NF4 wrapper specs differ")
    elif actual_quant.get("loaded_in_4bit"):
        raise ValueError("Dense cohort unexpectedly quantized its decoder")
    return info


def qualification(
    evidence: Evidence, key: str, count: int, model: dict[str, Any], entry_sha: str, maximum: int
) -> dict[str, Any]:
    quant, source = key.split("-", 1)
    reference_key = f"{quant}-ram" if source == "disk" else key
    layers, vocab = model["config"]["num_hidden_layers"], model["config"]["vocab_size"]
    adapters = layers * 14
    report: dict[str, Any] = {"count": count, "reference": reference_key + "/0", "gates": {}}
    for phase, prefix in (("primary", "capture"), ("semantics", "semantics")):
        folders = [f"{reference_key}/{prefix}-0", f"{key}/{prefix}-{count}"]
        paths = [evidence.get(folder + "/trace.safetensors") for folder in folders]
        infos = [
            provenance(evidence, folder, chosen, quant, tier, entry_sha, layers)
            for folder, chosen, tier in zip(folders, (0, count), ("ram", source))
        ]
        for info in infos:
            if info["prepared"]["revision"] != model["revision"]:
                raise ValueError("Model revision differs from the frozen protocol")
        first_files, second_files = (info["prepared"]["shard_files"] for info in infos)
        if {name: row["sha256"] for name, row in first_files.items()} != {
            name: row["sha256"] for name, row in second_files.items()
        }:
            raise ValueError("Compared arms do not use the same prepared base-weight bytes")
        schemas = [check_trace_schema(path, phase, adapters, vocab) for path in paths]
        if phase == "primary":
            for folder in folders:
                metadata = evidence.json(folder + "/capture.json")
                if (
                    metadata.get("status") != "CAPTURED"
                    or metadata.get("adapter_tensors") != adapters
                    or metadata.get("amp") != {"bf16": True, "fp16": False}
                    or not metadata.get("deterministic_algorithms")
                ):
                    raise ValueError("Primary process precision/completion differs")
            report["initial_adapter_sha256"] = schemas[0]["initial_adapter_sha256"]
        else:
            for folder in folders:
                metadata = evidence.json(folder + "/study-provenance.json")
                if (
                    metadata.get("status") != "CAPTURED"
                    or not metadata.get("causal_prefix_exact")
                    or not metadata.get("masked_padding_isolation_exact")
                ):
                    raise ValueError("Source-enforced causal/padding assertions did not complete")
            report["isolation_replay_limit"] = (
                "Cross-arm semantic tensors replayed independently; in-process causal/padding "
                "assertions checked against frozen source and completion status. Perturbed-output "
                "tensors were not retained, so isolation itself cannot be recomputed on CPU."
            )
        gate = compare_files(*paths, maximum=maximum)
        report["gates"][phase] = gate
    report["passed"] = all(gate["passed"] for gate in report["gates"].values())
    report["status"] = "QUALIFIED_TENSORS_REPLAYED" if report["passed"] else "FAILED_ACCURACY"
    return report


def quantization_diagnostic(
    evidence: Evidence, model: dict[str, Any], entry_sha: str, maximum: int
) -> dict[str, Any]:
    """Describe lossy-format differences without qualifying or disqualifying residency."""
    report: dict[str, Any] = {
        "kind": "quantization_diagnostic",
        "gating": False,
        "reference": "none-ram/0",
        "candidate": "nf4-ram/0",
        "rtol": RTOL,
        "atol": ATOL,
        "interpretation": (
            "NF4 changes the base-weight representation and is lossy. This comparison uses the "
            "original numeric predicates to describe differences; it does not establish BF16 "
            "equivalence, residency correctness, or trained-model quality. Residency and disk "
            "qualification require their own same-format RAM reference."
        ),
        "gates": {},
    }
    required = [
        f"{key}/{prefix}-0/{name}"
        for key in ("none-ram", "nf4-ram")
        for prefix, metadata in (
            ("capture", "capture.json"),
            ("semantics", "study-provenance.json"),
        )
        for name in ("trace.safetensors", "residency-sweep-provenance.json", metadata)
    ]
    missing = [path for path in required if path not in evidence.files]
    if missing:
        return {**report, "status": "NOT_AVAILABLE", "missing": missing}
    layers, vocab = model["config"]["num_hidden_layers"], model["config"]["vocab_size"]
    adapters = layers * 14
    try:
        for phase, prefix in (("primary", "capture"), ("semantics", "semantics")):
            folders = [f"{key}/{prefix}-0" for key in ("none-ram", "nf4-ram")]
            paths = [evidence.get(folder + "/trace.safetensors") for folder in folders]
            for folder, quant, path in zip(folders, ("none", "nf4"), paths):
                info = provenance(evidence, folder, 0, quant, "ram", entry_sha, layers)
                if info["prepared"]["revision"] != model["revision"]:
                    raise ValueError("Model revision differs from the frozen protocol")
                check_trace_schema(path, phase, adapters, vocab)
                if phase == "primary":
                    metadata = evidence.json(folder + "/capture.json")
                    if (
                        metadata.get("status") != "CAPTURED"
                        or metadata.get("adapter_tensors") != adapters
                        or metadata.get("amp") != {"bf16": True, "fp16": False}
                        or not metadata.get("deterministic_algorithms")
                    ):
                        raise ValueError("Primary process precision/completion differs")
                else:
                    metadata = evidence.json(folder + "/study-provenance.json")
                    if (
                        metadata.get("status") != "CAPTURED"
                        or not metadata.get("causal_prefix_exact")
                        or not metadata.get("masked_padding_isolation_exact")
                    ):
                        raise ValueError("Source-enforced causal/padding assertions incomplete")
            # Different shard hashes are expected here: this diagnostic crosses formats.
            # Keep the original reference-first predicates, including exact batches/init.
            report["gates"][phase] = compare_files(*paths, maximum=maximum)
        report["passes_original_numeric_gate"] = all(
            gate["passed"] for gate in report["gates"].values()
        )
        report["status"] = (
            "PASS_ORIGINAL_NUMERIC_GATE"
            if report["passes_original_numeric_gate"]
            else "FAIL_ORIGINAL_NUMERIC_GATE"
        )
        report["isolation_replay_limit"] = (
            "Cross-format semantic tensors replayed independently. Perturbed-output tensors "
            "were not retained; causal/padding isolation uses the frozen source's in-process "
            "assertions and completion status, not independent CPU recomputation."
        )
    except Exception as error:
        report.update(
            status="INVALID_DIAGNOSTIC_EVIDENCE", error=f"{type(error).__name__}: {error}"
        )
    return report


def timing_metrics(evidence: Evidence, folder: str, initial_sha: str) -> dict[str, Any]:
    item = evidence.json(folder + "/metrics.json")
    if item.get("status") != "TIMING_CAPTURED_NOT_A_CORRECTNESS_OR_QUALITY_VERDICT":
        raise ValueError("Timing process did not complete")
    if (
        item.get("amp") != {"bf16": True, "fp16": False}
        or not item.get("deterministic_algorithms")
        or item.get("warmup") != 6
        or item.get("steps") != 8
        or len(item.get("seconds", [])) != 8
    ):
        raise ValueError("Timing precision, determinism or measurement window differs")
    if any(not math.isfinite(value) or value <= 0 for value in item["seconds"]):
        raise ValueError("Timing has nonfinite/nonpositive values")
    if item.get("input_shapes") != [[1, 1024]] * 28:
        raise ValueError("Timing does not contain 28 microbatches of 1024 input positions")
    if item.get("initial_adapter_sha256") != initial_sha or item.get("data_sha256") != DATA_SHA256:
        raise ValueError("Timing initialization or input data differs from qualification")
    losses = [row["loss"] for row in item["training_log_history"] if "loss" in row]
    if len(losses) != 14 or any(not math.isfinite(value) for value in losses):
        raise ValueError("Expected fourteen finite optimizer-update losses")
    for field in ("peak_allocated_bytes", "peak_reserved_bytes"):
        if len(item.get(field, [])) != 8 or any(
            type(value) is not int or value <= 0 for value in item[field]
        ):
            raise ValueError("Timing memory arrays differ")
    return item


def summarize(pairs: list[dict[str, Any]]) -> dict[str, Any]:
    if len(pairs) != 4 or [row["order"] for row in pairs] != PAIR_ORDER:
        raise ValueError("Require exactly the four held-out AB/BA/BA/AB pairs")
    for row in pairs:
        for arm in ("baseline", "auto"):
            if len(row[arm]) != 8 or any(
                not math.isfinite(value) or value <= 0 for value in row[arm]
            ):
                raise ValueError("Each held-out process requires eight positive finite timings")
    reductions = [
        100 * (1 - statistics.median(row["auto"]) / statistics.median(row["baseline"]))
        for row in pairs
    ]
    rng = random.Random(792)
    bootstrap = sorted(statistics.median(rng.choices(reductions, k=4)) for _ in range(20000))
    lower, upper = bootstrap[499], bootstrap[19499]
    median = statistics.median(reductions)
    positive = sum(value > 0 for value in reductions) / 4
    return {
        "paired_step_time_reduction_percent": reductions,
        "median_paired_step_time_reduction_percent": median,
        "bootstrap95_percent": [lower, upper],
        "positive_pair_fraction": positive,
        "practical_speed_gate_passed": median >= 2 and positive >= 0.75 and lower > 0,
        "bootstrap_unit": "entire fresh process pair",
        "resamples": 20000,
        "seed": 792,
        "baseline_tokens_per_second": 2048
        / statistics.median([statistics.median(row["baseline"]) for row in pairs]),
        "auto_tokens_per_second": 2048
        / statistics.median([statistics.median(row["auto"]) for row in pairs]),
    }


def heldout(
    evidence: Evidence,
    label: str,
    quant: str,
    ref_source: str,
    source: str,
    count: int,
    model: dict[str, Any],
    entry_sha: str,
    initial_sha: str,
    maximum: int,
) -> dict[str, Any]:
    pairs, pids, trajectories = [], [], []
    layers = model["config"]["num_hidden_layers"]
    for number, order in enumerate(PAIR_ORDER):
        folders = [f"heldout/{label}/pair-{number}-{arm}" for arm in ("baseline", "candidate")]
        infos = [
            provenance(evidence, folder, chosen, quant, tier, entry_sha, layers)
            for folder, chosen, tier in zip(folders, (0, count), (ref_source, source))
        ]
        pids.extend(info["pid"] for info in infos)
        metrics = [timing_metrics(evidence, folder, initial_sha) for folder in folders]
        trajectory = compare_files(
            *[evidence.get(folder + "/adapter/adapter_model.safetensors") for folder in folders],
            maximum=maximum,
            trace=False,
        )
        if trajectory["tensor_count"] != layers * 14:
            raise ValueError("Final adapter tensor count differs")
        losses = [
            [row["loss"] for row in item["training_log_history"] if "loss" in row]
            for item in metrics
        ]
        loss_close = all(
            f"{left:.3f}" == f"{right:.3f}" for left, right in zip(*losses, strict=True)
        )
        trajectory.update(
            loss_three_decimals=loss_close,
            passed=trajectory["passed"] and loss_close,
            losses_equal=losses[0] == losses[1],
        )
        if not trajectory["passed"]:
            raise ValueError("Held-out fourteen-update trajectory failed unchanged gates")
        trajectories.append(trajectory)
        peaks = [
            {name: max(item[name]) for name in ("peak_allocated_bytes", "peak_reserved_bytes")}
            for item in metrics
        ]
        pairs.append(
            {
                "pair": number,
                "order": order,
                "baseline": metrics[0]["seconds"],
                "auto": metrics[1]["seconds"],
                "provenance": infos,
                "peaks": peaks,
            }
        )
    if len(set(pids)) != 8:
        raise ValueError("Held-out comparison does not have eight distinct fresh process IDs")
    expected = [
        f"heldout-{label}-{number}-{'baseline' if letter == 'A' else 'candidate'}"
        for number, order in enumerate(PAIR_ORDER)
        for letter in order
    ]
    stages = [
        row for row in evidence.progress["stages"] if row["name"].startswith(f"heldout-{label}-")
    ]
    if [row["name"] for row in stages] != expected or any(row["exit_code"] for row in stages):
        raise ValueError("Recorded held-out process order/exit status differs")
    performance = summarize(pairs)
    saved = evidence.progress.get("heldout", {}).get(label, {})
    if saved.get("performance") is not None and saved["performance"] != performance:
        raise ValueError("Worker performance claim differs from independent raw-metrics replay")
    result = {
        "status": "HELDOUT_REPLAYED",
        "performance": performance,
        "pairs": pairs,
        "trajectories": trajectories,
    }
    if source == "disk":
        result["disk_step_time_multiplier"] = statistics.median(
            statistics.median(row["auto"]) / statistics.median(row["baseline"]) for row in pairs
        )
        result["nvme_timing_qualified"] = all(
            nvme_timing_proof(row["provenance"][1]) for row in pairs
        )
    return result


def nvme_timing_proof(info: dict[str, Any]) -> bool:
    """Require device reads in measured updates 7..14, not only the six warmups."""
    updates = info.get("per_update_io", [])
    if not isinstance(updates, list) or len(updates) != 14:
        return False
    if any(not isinstance(row, dict) for row in updates):
        return False
    steps = [row.get("step") for row in updates]
    if any(type(step) is not int for step in steps) or steps != list(range(1, 15)):
        return False
    try:
        reads = [row["linux_process_io_delta"]["read_bytes"] for row in updates]
    except (KeyError, TypeError):
        return False
    if any(type(value) is not int or value < 0 for value in reads):
        return False
    return nvme_proof(info) and sum(reads[-8:]) > 0


def nvme_proof(info: dict[str, Any]) -> bool:
    """Aggregate training-read proof; this alone does not qualify measured timing."""
    proof = info.get("storage_validation", {})
    root = proof.get("verified_path")
    paths = info.get("cache_paths", [])
    return bool(
        info.get("actual_tier") == "disk"
        and info.get("direct_io") is True
        and info.get("io_read_bytes_delta", 0) > 0
        and proof.get("nvme_verified") is True
        and all(
            proof.get(key)
            for key in ("backing_device", "mount_source", "device_major_minor", "sysfs_realpath")
        )
        and root
        and paths
        and all(posixpath.commonpath([root, path]) == posixpath.normpath(root) for path in paths)
    )


def replay(roots: list[Path], helpers: Path, maximum: int = 131072) -> dict[str, Any]:
    verified = verify_sources(helpers)
    protocol = read_json(helpers / "protocol.json")
    if (
        protocol["pair_order"] != PAIR_ORDER
        or protocol["batch"] != 1
        or protocol["accumulation"] != 2
        or protocol["sequence_length"] != 1024
    ):
        raise ValueError("Frozen protocol differs from the independently implemented gates")
    evidence = Evidence(roots)
    model = protocol["models"][0]
    entry_sha = verified["bench.py"]["sha256"]
    report: dict[str, Any] = {
        "status": "STARTED",
        "verified_sources": verified,
        "progress_source": evidence.progress_path,
        "duplicate_raw_checks": evidence.duplicates,
        "qualifications": {},
        "heldout": {},
        "scope": "CPU replay; no GPU/model execution",
        "throughput_definition": "2048 processed input positions per optimizer update",
    }
    initial: dict[str, str] = {}
    cohorts = evidence.progress.get("cohorts", {})
    for key, saved in cohorts.items():
        counts = set(map(int, saved.get("accuracy", {}))) | set(saved.get("qualified_counts", []))
        counts.update(
            int(path.split("/")[1].removeprefix("capture-"))
            for path in evidence.files
            if path.startswith(key + "/capture-") and path.endswith("/trace.safetensors")
        )
        for count in sorted(counts):
            identifier = f"{key}/{count}"
            try:
                checked = qualification(evidence, key, count, model, entry_sha, maximum)
                claimed = saved.get("accuracy", {}).get(str(count), {})
                for phase in ("primary", "semantics"):
                    if (
                        phase in claimed
                        and claimed[phase].get("passed") != checked["gates"][phase]["passed"]
                    ):
                        raise ValueError("Worker numerical claim differs from independent replay")
                report["qualifications"][identifier] = checked
                if checked["passed"]:
                    initial[identifier] = checked["initial_adapter_sha256"]
            except Exception as error:
                report["qualifications"][identifier] = {
                    "status": "FAILED_OR_INCOMPLETE_RAW_NOT_QUALIFIED",
                    "error": f"{type(error).__name__}: {error}",
                }
    # Quantization differences never enter residency qualification or overall replay status.
    report["cross_format_diagnostic"] = quantization_diagnostic(evidence, model, entry_sha, maximum)
    specifications = []
    for key, saved in cohorts.items():
        quant, source = key.split("-", 1)
        if source == "ram" and saved.get("selected_count"):
            label = "dense-best" if quant == "none" else "nf4-maxfit"
            specifications.append((label, quant, "ram", "ram", saved["selected_count"]))
        if source == "disk" and 0 in saved.get("qualified_counts", []):
            specifications.append(("nf4-disk-vs-ram", quant, "ram", "disk", 0))
    dense = cohorts.get("none-ram", {})
    if 4 in dense.get("qualified_counts", []) and dense.get("selected_count") != 4:
        specifications.append(("dense-four-reference", "none", "ram", "ram", 4))
    expected_labels = {row[0] for row in specifications}
    for unexpected in set(evidence.progress.get("heldout", {})) - expected_labels:
        report["heldout"][unexpected] = {
            "status": "FAILED_UNRECOGNIZED_REPORTED_COMPARISON",
            "error": "No independently identified format/source/count for reported held-out label",
        }
    for label, quant, ref, source, count in specifications:
        if not any(path.startswith(f"heldout/{label}/") for path in evidence.files):
            report["heldout"][label] = {"status": "NOT_RUN_NO_PERFORMANCE_VERDICT"}
            continue
        try:
            if f"{quant}-{ref}/0" not in initial or f"{quant}-{source}/{count}" not in initial:
                raise ValueError("Held-out arm lacks independently replayed qualification")
            checked = heldout(
                evidence,
                label,
                quant,
                ref,
                source,
                count,
                model,
                entry_sha,
                initial[f"{quant}-{ref}/0"],
                maximum,
            )
            report["heldout"][label] = checked
        except Exception as error:
            report["heldout"][label] = {
                "status": "FAILED_OR_INCOMPLETE_TIMING_NO_PERFORMANCE_VERDICT",
                "error": f"{type(error).__name__}: {error}",
            }
    failed = any(
        row["status"].startswith("FAILED")
        for group in ("qualifications", "heldout")
        for row in report[group].values()
    )
    report["status"] = "PARTIAL_WITH_FAILED_OR_INCOMPLETE_EVIDENCE" if failed else "REPLAY_COMPLETE"
    if not initial:
        report["status"] = "NO_QUALIFIED_EVIDENCE"
    elif not failed and not any(
        row["status"] == "HELDOUT_REPLAYED" for row in report["heldout"].values()
    ):
        report["status"] = "ACCURACY_ONLY_OR_PENDING_TIMING"
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", action="append", type=Path, required=True)
    parser.add_argument("--helpers", type=Path, default=Path(__file__).parent)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--max-slice-elements", type=int, default=131072)
    args = parser.parse_args()
    try:
        report = replay(args.root, args.helpers, args.max_slice_elements)
    except Exception as error:
        report = {"status": "FAILED", "error": f"{type(error).__name__}: {error}"}
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    Console().print({"status": report["status"], "report": str(args.output)})
    return 0 if report["status"] == "REPLAY_COMPLETE" else 1


if __name__ == "__main__":
    raise SystemExit(main())
