"""Derive compact companions from a finished metadata package without changing its ZIP."""

from __future__ import annotations

import argparse
import copy
import gzip
import hashlib
import json
import os
import re
import shutil
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any

from rich.console import Console

from publish_results import MAX_METADATA_BYTES, SHA256, check_json, identity, within

PRIVATE_PATH = re.compile(r"(?i)[a-z]:[\\/]|\\\\[^\\]+\\|/(?:Users|home|root)/")
ARM_FIELDS = (
    "representative_seconds_per_step",
    "measured_updates",
    "max_measured_peak_allocated_bytes",
    "max_measured_peak_reserved_bytes",
    "sampled_device_free_min_bytes",
    "host_process_high_water_bytes",
    "getrusage_high_water_bytes",
    "proc_current_mm_high_water_bytes",
    "max_proc_rss_after_setup_bytes",
    "max_proc_rss_at_exit_bytes",
    "median_measured_step_io_read_bytes",
    "median_measured_step_logical_decoder_copy_bytes",
    "measured_step_decoder_loads",
    "measured_step_large_tensor_loads",
    "measured_step_logical_decoder_copy_bytes",
    "step_io_scope",
    "direct_io_all_processes",
    "nvme_read_proof_all_processes",
    "nvme_read_proof_scope",
)


def canonical(value: Any) -> bytes:
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True) + "\n").encode()


def readable_summary(value: Any) -> bytes:
    """Pretty JSON with short leaf objects/ranges inline; no statistical transformations."""

    def short(item: Any) -> bool:
        return not isinstance(item, (dict, list)) or (
            isinstance(item, list)
            and len(item) <= 8
            and all(not isinstance(child, (dict, list)) for child in item)
        )

    def render(item: Any, depth: int = 0) -> str:
        flat = json.dumps(item, sort_keys=True, ensure_ascii=True)
        leaf = (
            all(short(child) for child in item.values()) if isinstance(item, dict) else short(item)
        )
        if not isinstance(item, (dict, list)) or (leaf and len(flat) + depth * 2 <= 100):
            return flat
        pad, child_pad = "  " * depth, "  " * (depth + 1)
        if isinstance(item, dict):
            rows = [
                f"{child_pad}{json.dumps(key)}: {render(item[key], depth + 1)}"
                for key in sorted(item)
            ]
            return "{\n" + ",\n".join(rows) + "\n" + pad + "}"
        rows = [child_pad + render(child, depth + 1) for child in item]
        return "[\n" + ",\n".join(rows) + "\n" + pad + "]"

    return (render(value) + "\n").encode()


def digest(raw: bytes) -> dict[str, Any]:
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def private_check(value: Any) -> None:
    """Check derived public JSON, not the intentionally unchanged original evidence archive."""
    check_json(value)
    if isinstance(value, dict):
        for key, child in value.items():
            private_check(str(key))
            private_check(child)
    elif isinstance(value, list):
        for child in value:
            private_check(child)
    elif isinstance(value, str) and PRIVATE_PATH.search(value):
        raise ValueError("Absolute private path in derived public metadata")


def relative(value: Any, *, basename: bool = False) -> str:
    if not isinstance(value, str) or not value or ":" in value or "\\" in value:
        raise ValueError("Expected a relative POSIX artifact path")
    path = PurePosixPath(value)
    if path.is_absolute() or any(part in {".", ".."} for part in path.parts):
        raise ValueError("Artifact path escapes its bundle")
    if basename and len(path.parts) != 1:
        raise ValueError("Bundle identity must be a single directory name")
    return value


def sanitized_raw_index(original: dict[str, Any]) -> dict[str, Any]:
    if original.get("format") != "soup-local-raw-artifact-index-v1":
        raise ValueError("Unknown local raw-index format")
    records = []
    seen = set()
    for row in original["artifacts"]:
        bundle = relative(row["bundle"], basename=True)
        path = relative(row["relative_path"])
        size, hashed = row["bytes"], row["sha256_as_recorded_by_retention"]
        if (
            type(size) is not int
            or size < 0
            or not isinstance(hashed, str)
            or not SHA256.fullmatch(hashed)
        ):
            raise ValueError("Raw-index identity lacks valid retained byte count/SHA256")
        if (bundle, path) in seen:
            raise ValueError("Duplicate bundle/path identity in raw index")
        seen.add((bundle, path))
        # Whitelist only these four fields: local_path and any future private fields never copy.
        records.append(
            {
                "bundle": bundle,
                "relative_path": path,
                "bytes": size,
                "sha256_as_recorded_by_retention": hashed,
            }
        )
    result = {
        "format": "soup-public-relative-raw-artifact-index-v1",
        "not_in_evidence_zip": True,
        "verification_scope": "Copied retention identities; raw tensors not read or rehashed here",
        "artifacts": sorted(records, key=lambda row: (row["bundle"], row["relative_path"])),
    }
    private_check(result)
    return result


def selected(value: dict[str, Any], names: tuple[str, ...]) -> dict[str, Any]:
    return {name: copy.deepcopy(value[name]) for name in names if name in value}


def projection(summary: dict[str, Any]) -> dict[str, Any]:
    """Explicit copied views only: do not recalculate a number or classify a result."""
    result = selected(
        summary,
        (
            "status",
            "independent_replay_status",
            "worker_status",
            "budget",
            "input_documents",
            "limitations",
        ),
    )
    result["count_matrix"] = {}
    for name, cohort in summary.get("count_matrix", {}).items():
        view = selected(
            cohort,
            (
                "worker_cohort_status",
                "selected_count",
                "largest_successfully_capacity_screened_count",
                "refused_capacity_counts",
                "capacity_boundary_scope",
            ),
        )
        view["rows"] = []
        for row in cohort["rows"]:
            item = selected(row, ("count",))
            item["accuracy"] = selected(row["accuracy"], ("status", "passed"))
            for phase in ("primary", "semantics"):
                if phase in row["accuracy"]:
                    item["accuracy"][phase] = selected(
                        row["accuracy"][phase], ("passed", "bitwise_equal")
                    )
            if "capacity" in row:
                item["capacity"] = selected(row["capacity"], ("screen_fit", "capacity_failure"))
            if "capture" in row:
                item["capture"] = selected(
                    row["capture"],
                    (
                        "whole_run_peak_allocated_bytes",
                        "whole_run_peak_reserved_bytes",
                        "sampled_device_free_min_bytes",
                    ),
                )
            view["rows"].append(item)
        result["count_matrix"][name] = view
    result["prepared_cache_payloads"] = {
        name: selected(
            item,
            (
                "total_cache_payload_and_index_bytes",
                "safetensors_bytes",
                "index_bytes",
                "layer_file_bytes_min",
                "layer_file_bytes_max",
                "file_count",
                "double_quant",
                "scope",
            ),
        )
        for name, item in summary.get("prepared_cache_payloads", {}).items()
    }
    result["heldout"] = {}
    for name, comparison in summary.get("heldout", {}).items():
        view = selected(
            comparison,
            (
                "status",
                "performance_verdict_available",
                "reference",
                "candidate",
                "performance",
                "all_final_adapters_bitwise_equal",
                "all_fourteen_update_losses_exact",
                "disk_step_time_multiplier",
                "nvme_timing_qualified",
                "storage_claim",
            ),
        )
        for arm in ("baseline", "candidate_metrics"):
            if arm in comparison:
                view[arm] = selected(comparison[arm], ARM_FIELDS)
        if "exploratory_14_update_training_wall" in comparison:
            view["exploratory_14_update_training_wall"] = selected(
                comparison["exploratory_14_update_training_wall"],
                (
                    "predeclared",
                    "gating",
                    "scope",
                    "status",
                    "available_pairs",
                    "expected_pairs",
                    "median_paired_time_reduction_percent",
                    "range_paired_time_reduction_percent",
                ),
            )
        result["heldout"][name] = view
    if "quantization_diagnostic" in summary:
        result["quantization_diagnostic"] = selected(
            summary["quantization_diagnostic"],
            (
                "kind",
                "gating",
                "reference",
                "candidate",
                "rtol",
                "atol",
                "status",
                "passes_original_numeric_gate",
                "error",
                "interpretation",
            ),
        )
    return result


def member_bytes(archive: zipfile.ZipFile, manifest: dict[str, Any], name: str) -> bytes:
    expected = manifest["files"][name]
    member = archive.getinfo(name)
    if member.file_size > MAX_METADATA_BYTES:
        raise ValueError("Metadata member exceeds explicit read limit")
    raw = archive.read(name)
    if digest(raw) != {key: expected[key] for key in ("bytes", "sha256")}:
        raise ValueError(f"Original ZIP member differs from full manifest: {name}")
    return raw


def finished_summary(archive: zipfile.ZipFile, manifest: dict[str, Any]) -> tuple[dict, dict]:
    member = "local/result-summary.json"
    raw = member_bytes(archive, manifest, member)
    summary = json.loads(raw)
    if summary.get("status") != "FINAL_EVIDENCE_SUMMARY_RESOURCES_ABSENT":
        raise ValueError("Compact publication requires the finished final summary")
    cleanup = summary["budget"]["cleanup"]
    if not (
        cleanup.get("instance_verified_absent") is True
        and cleanup.get("volume_verified_absent") is True
    ):
        raise ValueError("Finished summary does not prove both resources absent")
    receipts = {
        name: json.loads(member_bytes(archive, manifest, "local/" + name))
        for name in ("vast-rental.json", "vast-deletion.json", "vast-volume-deletion.json")
    }
    rental, deleted, volume = (
        receipts[name]
        for name in ("vast-rental.json", "vast-deletion.json", "vast-volume-deletion.json")
    )
    identities = (
        cleanup.get("instance_id"),
        cleanup.get("volume_id"),
        rental.get("instance_id"),
        rental.get("volume_id"),
        deleted.get("instance_id"),
        deleted.get("volume_id"),
        volume.get("volume_id"),
    )
    if not (
        deleted.get("verified_absent") is True
        and deleted.get("volume_verified_absent") is True
        and volume.get("verified_absent") is True
        and cleanup.get("instance_id") == deleted.get("instance_id") == rental.get("instance_id")
        and cleanup.get("volume_id") == deleted.get("volume_id") == rental.get("volume_id")
        and volume.get("volume_id") == rental.get("volume_id")
        and all(type(value) is int and value > 0 for value in identities)
    ):
        raise ValueError("Original ZIP cleanup receipts do not identify the same absent resources")
    return summary, {"zip_member": member, **digest(raw)}


def gzip_verified(raw: bytes, output: Path) -> dict[str, Any]:
    with output.open("xb") as destination:
        # Empty filename prevents a path-dependent header; zero mtime makes repeats deterministic.
        with gzip.GzipFile(
            filename="", mode="wb", fileobj=destination, mtime=0, compresslevel=9
        ) as packed:
            packed.write(raw)
    with gzip.open(output, "rb") as packed:
        if packed.read() != raw:
            raise ValueError("Gzip round trip did not preserve the exact original bytes")
    return {"name": output.name, **identity(output), "uncompressed": digest(raw)}


def check_output(source: Path, output: Path) -> None:
    first, second = os.path.realpath(source), os.path.realpath(output)
    try:
        common = os.path.commonpath([first, second])
    except ValueError:
        # Different Windows drives have no common path and are already separate.
        common = None
    if common in {first, second}:
        raise ValueError("Source and output must be separate, non-nested directories")
    if output.exists():
        raise FileExistsError("Refuse overwriting any existing compact-output directory")
    for ancestor in (output, *output.parents):
        if (ancestor / ".git").exists():
            raise ValueError("Never write a compact package directly into a Git-managed directory")


def build(source: Path, output: Path) -> dict[str, Any]:
    source, output = Path(os.path.realpath(source)), Path(os.path.realpath(output))
    check_output(source, output)
    manifest_path = within(source, "evidence-manifest.json")
    raw_path = within(source, "local-raw-artifact-index.json")
    for path in (manifest_path, raw_path):
        if path.stat().st_size > MAX_METADATA_BYTES:
            raise ValueError("Input metadata exceeds explicit read limit")
    manifest_raw, raw_index_raw = manifest_path.read_bytes(), raw_path.read_bytes()
    manifest = json.loads(manifest_raw)
    if not (
        manifest.get("format") == "soup-exact-metadata-evidence-v1"
        and manifest.get("original_bytes_preserved") is True
        and manifest.get("every_zip_entry_byte_verified") is True
        and manifest.get("archive", {}).get("name") == "evidence.zip"
    ):
        raise ValueError("Source is not the completed exact metadata publication package")
    private_check(manifest)
    original_zip = within(source, "evidence.zip")
    original_identity = identity(original_zip)
    if original_identity != {key: manifest["archive"][key] for key in ("bytes", "sha256")}:
        raise ValueError("Original evidence ZIP differs from its full manifest")
    with zipfile.ZipFile(original_zip) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)) or set(names) != set(manifest["files"]):
            raise ValueError("Original ZIP entries differ from full manifest")
        summary, summary_identity = finished_summary(archive, manifest)
    public_index = sanitized_raw_index(json.loads(raw_index_raw))
    compact = projection(summary)
    compact["compact_publication"] = {
        "format": "soup-summary-projection-v1",
        "source": summary_identity,
        "source_archive": {"name": "evidence.zip", **original_identity},
        "policy": "Copied existing statistics/statuses only; no recomputation or new decision",
        "projection_schema": (
            "Explicit count/accuracy/capacity/capture view, cache aggregates, held-out statistics "
            "and memory/counter summaries. Per-process/phase arrays and inventories remain in "
            "the original ZIP summary and results tables."
        ),
    }
    private_check(compact)
    output.mkdir(parents=True, exist_ok=False)
    copied_zip = output / "evidence.zip"
    with original_zip.open("rb") as original, copied_zip.open("xb") as destination:
        shutil.copyfileobj(original, destination, length=2**20)
    with original_zip.open("rb") as original, copied_zip.open("rb") as copied:
        while True:
            first, second = original.read(2**20), copied.read(2**20)
            if first != second:
                raise ValueError("Copied evidence ZIP is not byte-equal to its original")
            if not first:
                break
    if identity(original_zip) != original_identity or identity(copied_zip) != original_identity:
        raise ValueError("Original or copied evidence ZIP changed during compaction")
    full_manifest = gzip_verified(manifest_raw, output / "evidence-manifest.full.json.gz")
    public_raw = gzip_verified(canonical(public_index), output / "raw-artifact-index.json.gz")
    compact_bytes = readable_summary(compact)
    (output / "result-summary.json").write_bytes(compact_bytes)
    short = {
        "format": "soup-compact-publication-v1",
        "archive": {"name": "evidence.zip", **original_identity},
        "full_manifest": full_manifest,
        "public_relative_raw_index": public_raw,
        "source_private_raw_index": digest(raw_index_raw),
        "full_original_result_summary": summary_identity,
        "compact_result_summary": {"name": "result-summary.json", **digest(compact_bytes)},
        "scope": (
            "Full evidence.zip preserved exactly; original manifest preserved by byte-equal gzip "
            "round trip. New raw index omits absolute local paths. Compact statistics are copied, "
            "not recomputed. The unchanged ZIP is not redacted by this helper."
        ),
    }
    private_check(short)
    (output / "evidence-manifest.json").write_bytes(canonical(short))
    return short


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build(args.source, args.output)
    Console().print({"output": str(args.output), "archive": report["archive"]})


if __name__ == "__main__":
    main()
