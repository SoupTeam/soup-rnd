"""Final-report controls: no paid actions or large tensor fixtures."""

import importlib.util
import json
from pathlib import Path

import pytest

SPEC = importlib.util.spec_from_file_location(
    "local_build_summary", Path(__file__).with_name("build_summary.py")
)
SUMMARY = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(SUMMARY)


def write(root, name, value):
    (root / name).write_text(json.dumps(value), encoding="utf-8")


def finalized(tmp_path):
    fixture_spec = importlib.util.spec_from_file_location(
        "summary_replay_fixture", Path(__file__).with_name("test_replay.py")
    )
    fixture = importlib.util.module_from_spec(fixture_spec)
    fixture_spec.loader.exec_module(fixture)
    evidence, model, initial_sha = fixture.synthetic_matrix(tmp_path)
    replay = fixture.REPLAY
    stages = []
    for count in (0, 4):
        for phase, stage in (("capture", "capture"), ("semantics", "semantics")):
            relative = f"none-ram/{phase}-{count}/residency-sweep-provenance.json"
            path = evidence.get(relative)
            info = json.loads(path.read_text())
            info.update(
                requested_resident_layers=count,
                whole_run_peak_allocated_bytes=1000 + count,
                whole_run_peak_reserved_bytes=2000 + count,
            )
            path.write_text(json.dumps(info))
            stages.append({"name": f"{stage}-none-ram-{count}", "exit_code": 0})
        folder = tmp_path / "results" / "none-ram" / f"selection-screen-{count}"
        folder.mkdir()
        write(
            folder,
            "metrics.json",
            {
                "status": "TIMING_CAPTURED_NOT_A_CORRECTNESS_OR_QUALITY_VERDICT",
                "warmup": 2,
                "steps": 3,
                "seconds": [1.0 if count else 2.0] * 3,
            },
        )
        write(folder, "residency-sweep-provenance.json", info)
        stages.append({"name": f"selection-screen-none-ram-{count}", "exit_code": 0})
    boundary = tmp_path / "results/none-ram/capacity-7"
    boundary.mkdir()
    write(
        boundary,
        "residency-sweep-provenance.json",
        {
            "status": "CAPACITY_REFUSED",
            "capacity_failure": "cap_refusal",
            "requested_resident_layers": 7,
            "capacity_only": True,
            "all_update_wall_seconds": [],
            "device_free_min_bytes": 100 * 2**20,
        },
    )
    stages.extend(evidence.progress["stages"])
    progress = {
        "status": "COMPLETE_REQUIRES_INDEPENDENT_REPLAY",
        "stages": stages,
        "heldout": {},
        "cohorts": {"none-ram": {"qualified_counts": [0, 4], "selected_count": 4}},
    }
    write(tmp_path / "results", "progress.json", progress)
    write(
        tmp_path / "results",
        "model-8-none-ram.prepare.json",
        {
            "status": "PREPARED_CACHE_NOT_A_TRAINING_VERDICT",
            "quant": "none",
            "double_quant": False,
            "shard_files": {
                "layer_000.safetensors": {"bytes": 1234, "sha256": "a"},
                "index.json": {"bytes": 8, "sha256": "b"},
            },
        },
    )
    evidence = replay.Evidence([tmp_path / "results"])
    # Add fourteen recorded updates per timing process. Only the final eight belong to timing.
    for number in range(4):
        for arm in ("baseline", "candidate"):
            path = evidence.get(
                f"heldout/dense-best/pair-{number}-{arm}/residency-sweep-provenance.json"
            )
            info = json.loads(path.read_text())
            info["host_memory_at_exit"] = {"VmHWM_bytes": 10_000 + number}
            info["per_update_io"] = [
                {
                    "step": step,
                    "linux_process_io_delta": {"read_bytes": 10000 if step <= 6 else step},
                }
                for step in range(1, 15)
            ]
            loads = 120 if arm == "baseline" else 96
            info["per_update_loads"] = [
                {
                    "step": step,
                    "loads": 10000 if step <= 6 else loads,
                    "large_loads": 4,
                    "logical_decoder_copy_bytes": (10000 if step <= 6 else loads) * 100,
                }
                for step in range(1, 15)
            ]
            path.write_text(json.dumps(info))
    evidence = replay.Evidence([tmp_path / "results"])
    qualifications = {
        f"none-ram/{count}": replay.qualification(
            evidence, "none-ram", count, model, "fixture", 131072
        )
        for count in (0, 4)
    }
    checked = replay.heldout(
        evidence, "dense-best", "none", "ram", "ram", 4, model, "fixture", initial_sha, 131072
    )
    write(
        tmp_path,
        "independent-replay.json",
        {
            "status": "REPLAY_COMPLETE",
            "qualifications": qualifications,
            "heldout": {
                "dense-best": checked,
                "pending-control": {"status": "NOT_RUN_NO_PERFORMANCE_VERDICT"},
            },
            "cross_format_diagnostic": {"status": "FAIL_ORIGINAL_NUMERIC_GATE", "gating": False},
        },
    )
    write(tmp_path, "final-worker-summary.json", progress)
    write(
        tmp_path,
        "vast-rental.json",
        {"instance_id": 22, "volume_id": 33, "prior_usd": 1, "maximum_usd": 10},
    )
    write(
        tmp_path,
        "vast-deletion.json",
        {
            "instance_id": 22,
            "volume_id": 33,
            "verified_absent": True,
            "volume_verified_absent": True,
        },
    )
    write(tmp_path, "vast-volume-deletion.json", {"volume_id": 33, "verified_absent": True})
    (tmp_path / "vast-finished").touch()
    previous = {"instance_id": 11, "verified_absent": True, "conservative_usd": 1}
    current = {
        "instance_id": 22,
        "volume_id": 33,
        "verified_absent": True,
        "volume_verified_absent": True,
        "conservative_usd": 2,
    }
    write(
        tmp_path,
        "stage-ledger.json",
        {"stage_id": "stage", "maximum_stage_usd": 10, "completed_leases": [previous, current]},
    )
    write(
        tmp_path,
        "prior-stage-ledger-snapshot.json",
        {"stage_id": "stage", "maximum_stage_usd": 10, "completed_leases": [previous]},
    )
    return evidence


def test_final_report_uses_raw_pairs_and_keeps_selection_capacity_and_lossy_diagnostic_separate(
    tmp_path,
):
    evidence = finalized(tmp_path)
    result = SUMMARY.build(tmp_path, evidence=evidence)
    assert result["status"] == "FINAL_EVIDENCE_SUMMARY_RESOURCES_ABSENT"
    assert result["budget"]["aggregate_conservative_usd"] == 3
    assert result["budget"]["remaining_to_limit_usd"] == 7
    rows = result["count_matrix"]["none-ram"]["rows"]
    assert [row["count"] for row in rows] == [0, 4, 7]
    assert rows[1]["capture"]["whole_run_peak_allocated_bytes"] == 1004
    assert rows[1]["selection"]["screen_after_accuracy"] is True
    assert rows[1]["selection"]["median_seconds"] == 1
    assert rows[2]["capacity"]["screen_fit"] is False
    assert rows[2]["accuracy"]["passed"] is False
    assert result["prepared_cache_payloads"]["none"]["total_cache_payload_and_index_bytes"] == 1242
    heldout = result["heldout"]["dense-best"]
    assert heldout["baseline"]["representative_seconds_per_step"] == 2
    assert heldout["candidate_metrics"]["representative_seconds_per_step"] == 1.9
    assert heldout["performance"]["median_paired_step_time_reduction_percent"] == pytest.approx(5)
    assert heldout["baseline"]["median_measured_step_io_read_bytes"] == 10.5
    assert heldout["baseline"]["measured_step_decoder_loads"] == {
        "median": 120,
        "range": [120, 120],
    }
    assert heldout["candidate_metrics"]["measured_step_decoder_loads"]["median"] == 96
    assert heldout["candidate_metrics"]["measured_step_logical_decoder_copy_bytes"] == {
        "median": 9600,
        "range": [9600, 9600],
    }
    assert heldout["candidate_metrics"]["host_process_high_water_bytes"] == 10003
    assert heldout["candidate_metrics"]["max_measured_peak_allocated_bytes"] == 1000
    assert result["heldout"]["pending-control"] == {
        "status": "NOT_RUN_NO_PERFORMANCE_VERDICT",
        "performance_verdict_available": False,
    }
    assert result["quantization_diagnostic"]["status"] == "FAIL_ORIGINAL_NUMERIC_GATE"
    text = SUMMARY.markdown(result)
    assert "3 updates" not in text  # The only retained capacity evidence is a refusal.
    assert "Selection only" in text and "not training VRAM" in text
    assert "no verdict: NOT_RUN_NO_PERFORMANCE_VERDICT" in text
    assert "5.00%" in text and "50.00%" not in text  # Selection is not the held-out speed.


@pytest.mark.parametrize(
    "failure",
    [
        "volume-live",
        "wrong-id",
        "no-marker",
        "missing-current-ledger",
        "lost-prior-spend",
        "unfinished-worker",
        "raw-timing-changed",
        "unqualified-heldout",
    ],
)
def test_final_builder_refuses_incomplete_cleanup_or_unverified_performance(tmp_path, failure):
    evidence = finalized(tmp_path)
    if failure == "volume-live":
        path = tmp_path / "vast-volume-deletion.json"
        value = json.loads(path.read_text())
        value["verified_absent"] = False
    elif failure == "wrong-id":
        path = tmp_path / "vast-deletion.json"
        value = json.loads(path.read_text())
        value["volume_id"] = 999
    elif failure == "no-marker":
        (tmp_path / "vast-finished").unlink()
        path, value = None, None
    elif failure in ("missing-current-ledger", "lost-prior-spend"):
        path = tmp_path / "stage-ledger.json"
        value = json.loads(path.read_text())
        value["completed_leases"].pop(1 if failure == "missing-current-ledger" else 0)
    elif failure == "unfinished-worker":
        path = tmp_path / "final-worker-summary.json"
        value = json.loads(path.read_text())
        value["status"] = "STARTED"
    elif failure == "raw-timing-changed":
        path = evidence.get("heldout/dense-best/pair-0-candidate/metrics.json")
        value = json.loads(path.read_text())
        value["seconds"][0] = 100
    else:
        path = tmp_path / "independent-replay.json"
        value = json.loads(path.read_text())
        value["qualifications"]["none-ram/4"]["passed"] = False
    if path:
        path.write_text(json.dumps(value))
    with pytest.raises(ValueError):
        SUMMARY.build(tmp_path, evidence=evidence)


def test_prepared_payload_is_file_footprint_and_rejects_mismatched_same_format(tmp_path):
    evidence = finalized(tmp_path)
    source = evidence.json("model-8-none-ram.prepare.json")
    source["shard_files"]["layer_000.safetensors"]["bytes"] += 1
    write(tmp_path / "results", "model-8-none-disk.prepare.json", source)
    evidence = SUMMARY.Evidence([tmp_path / "results"])
    with pytest.raises(ValueError, match="inventories differ"):
        SUMMARY.prepared_payloads(evidence)


def test_partial_final_with_failed_speed_gate_retains_accuracy_and_has_no_false_speed_claim(
    tmp_path,
):
    evidence = finalized(tmp_path)
    path = tmp_path / "independent-replay.json"
    replayed = json.loads(path.read_text())
    checked = replayed["heldout"]["dense-best"]
    for number, pair in enumerate(checked["pairs"]):
        metrics_path = evidence.get(f"heldout/dense-best/pair-{number}-candidate/metrics.json")
        metrics = json.loads(metrics_path.read_text())
        metrics["seconds"] = [2.01] * 8
        metrics_path.write_text(json.dumps(metrics))
        pair["auto"] = metrics["seconds"]
    checked["performance"] = SUMMARY.summarize(checked["pairs"])
    replayed["status"] = "PARTIAL_WITH_FAILED_OR_INCOMPLETE_EVIDENCE"
    replayed["heldout"]["failed-control"] = {
        "status": "FAILED_OR_INCOMPLETE_TIMING_NO_PERFORMANCE_VERDICT",
        "error": "capture missing",
    }
    path.write_text(json.dumps(replayed))
    path = tmp_path / "final-worker-summary.json"
    worker = json.loads(path.read_text())
    worker["status"] = "PARTIAL"
    path.write_text(json.dumps(worker))
    result = SUMMARY.build(tmp_path, evidence=evidence)
    assert result["count_matrix"]["none-ram"]["rows"][1]["accuracy"]["passed"]
    heldout = result["heldout"]["dense-best"]
    assert heldout["performance_verdict_available"]
    assert heldout["performance"]["practical_speed_gate_passed"] is False
    assert heldout["performance"]["median_paired_step_time_reduction_percent"] == pytest.approx(
        -0.5
    )
    assert result["heldout"]["failed-control"]["performance_verdict_available"] is False
    assert "-0.50%" in SUMMARY.markdown(result)


def test_metrics_saved_before_final_free_floor_refusal_do_not_become_a_selection_result(tmp_path):
    evidence = finalized(tmp_path)
    path = evidence.get("none-ram/selection-screen-4/residency-sweep-provenance.json")
    info = json.loads(path.read_text())
    info.update(status="CAPACITY_REFUSED", capacity_failure="cap_refusal")
    path.write_text(json.dumps(info))
    result = SUMMARY.build(tmp_path, evidence=evidence)
    row = result["count_matrix"]["none-ram"]["rows"][1]
    assert row["accuracy"]["passed"]
    assert row["selection"]["status"] == "FAILED_OR_INCOMPLETE_SELECTION_SCREEN"
    assert "median_seconds" not in row["selection"]
    assert "unavailable" in SUMMARY.markdown(result)


@pytest.mark.parametrize("measured_reads", [0, 1])
def test_nvme_timing_label_requires_measured_window_reads_not_only_warmup(tmp_path, measured_reads):
    evidence = finalized(tmp_path)
    replayed = json.loads((tmp_path / "independent-replay.json").read_text())
    pairs = replayed["heldout"]["dense-best"]["pairs"]
    for number, pair in enumerate(pairs):
        path = evidence.get(
            f"heldout/dense-best/pair-{number}-candidate/residency-sweep-provenance.json"
        )
        info = json.loads(path.read_text())
        info.update(
            actual_tier="disk",
            direct_io=True,
            io_read_bytes_delta=60000,
            cache_paths=["/data/cache"],
            storage_validation={
                "nvme_verified": True,
                "verified_path": "/data",
                "backing_device": "nvme",
                "mount_source": "/dev/nvme",
                "device_major_minor": "259:3",
                "sysfs_realpath": "/sys/nvme",
            },
        )
        for row in info["per_update_io"][6:]:
            row["linux_process_io_delta"]["read_bytes"] = measured_reads
        assert SUMMARY.nvme_proof(info)  # The process-wide total includes warmup reads.
        path.write_text(json.dumps(info))
        pair["provenance"][1] = info
    arm = SUMMARY._timing_arm(
        evidence,
        "dense-best",
        "candidate",
        pairs,
        replayed["qualifications"]["none-ram/0"]["initial_adapter_sha256"],
    )
    assert arm["nvme_read_proof_all_processes"] is bool(measured_reads)
    assert arm["median_measured_step_io_read_bytes"] == measured_reads


def test_getrusage_and_current_mm_proc_memory_remain_distinct_in_output_and_tables(tmp_path):
    evidence = finalized(tmp_path)
    path = tmp_path / "independent-replay.json"
    replayed = json.loads(path.read_text())
    for number, pair in enumerate(replayed["heldout"]["dense-best"]["pairs"]):
        info_path = evidence.get(
            f"heldout/dense-best/pair-{number}-candidate/residency-sweep-provenance.json"
        )
        info = json.loads(info_path.read_text())
        info["host_memory_after_setup"] = {
            "max_rss_bytes": 9000 + 100 * number,
            "VmHWM_bytes": 5000 + 100 * number,
            "VmRSS_bytes": 4000 + 100 * number,
        }
        info["host_memory_at_exit"] = {
            "max_rss_bytes": 9100 + 100 * number,
            "VmHWM_bytes": 5100 + 100 * number,
            "VmRSS_bytes": 3000 + 100 * number,
        }
        info_path.write_text(json.dumps(info))
        pair["provenance"][1] = info
    path.write_text(json.dumps(replayed))
    result = SUMMARY.build(tmp_path, evidence=evidence)
    candidate = result["heldout"]["dense-best"]["candidate_metrics"]
    assert candidate["host_process_high_water_bytes"] == 9400  # Existing conservative field.
    assert candidate["getrusage_high_water_bytes"] == 9400
    assert candidate["proc_current_mm_high_water_bytes"] == 5400
    assert candidate["max_proc_rss_after_setup_bytes"] == 4300
    assert candidate["max_proc_rss_at_exit_bytes"] == 3300
    baseline = result["heldout"]["dense-best"]["baseline"]
    assert baseline["getrusage_high_water_bytes"] is None  # No substitution from /proc.
    assert baseline["proc_current_mm_high_water_bytes"] == 10003
    rusage_only = SUMMARY._process_memory({"host_memory_at_exit": {"max_rss_bytes": 55}})
    assert rusage_only["getrusage_high_water_bytes"] == 55
    assert rusage_only["proc_current_mm_high_water_bytes"] is None
    text = SUMMARY.markdown(result)
    assert "getrusage HWM GiB" in text and "/proc VmHWM GiB" in text
    assert "/proc VmRSS setup GiB" in text and "/proc VmRSS exit GiB" in text
    assert "not whole-machine RAM" in text


@pytest.mark.parametrize("missing", [False, True])
def test_complete_run_phase_durations_are_exploratory_and_missing_is_not_zero(tmp_path, missing):
    evidence = finalized(tmp_path)
    path = tmp_path / "independent-replay.json"
    replayed = json.loads(path.read_text())
    for number, pair in enumerate(replayed["heldout"]["dense-best"]["pairs"]):
        for index, arm in enumerate(("baseline", "candidate")):
            folder = f"heldout/dense-best/pair-{number}-{arm}"
            metrics_path = evidence.get(folder + "/metrics.json")
            metrics = json.loads(metrics_path.read_text())
            metrics["setup_seconds"] = (36 if arm == "baseline" else 33) + number
            metrics["training_wall_seconds_including_final_save"] = (60 + number) * (
                1 if arm == "baseline" else 0.9
            )
            if missing and arm == "candidate":
                if number == 1:
                    metrics.pop("setup_seconds")
                if number == 2:
                    metrics.pop("training_wall_seconds_including_final_save")
            metrics_path.write_text(json.dumps(metrics))
            info_path = evidence.get(folder + "/residency-sweep-provenance.json")
            info = json.loads(info_path.read_text())
            info["whole_setup_seconds"] = (31 if arm == "baseline" else 29) + number
            if not missing or arm == "baseline":
                info["whole_entry_seconds"] = (100 if arm == "baseline" else 90) + number
            info_path.write_text(json.dumps(info))
            pair["provenance"][index] = info
            stage_name = f"heldout-dense-best-{number}-{arm}"
            stage = next(row for row in evidence.progress["stages"] if row["name"] == stage_name)
            stage["seconds"] = (113 if arm == "baseline" else 111) + number
    path.write_text(json.dumps(replayed))
    write(tmp_path, "final-worker-summary.json", evidence.progress)
    result = SUMMARY.build(tmp_path, evidence=evidence)
    heldout = result["heldout"]["dense-best"]
    assert heldout["performance"]["practical_speed_gate_passed"] is True
    assert heldout["performance"]["median_paired_step_time_reduction_percent"] == pytest.approx(5)
    arms = [heldout[key]["descriptive_timing_phases"] for key in ("baseline", "candidate_metrics")]
    assert all(arm["gating"] is False and arm["predeclared"] is False for arm in arms)
    baseline, candidate = [arm["phases"] for arm in arms]
    assert baseline["metrics_setup_seconds"]["median_seconds"] == 37.5
    assert baseline["metrics_setup_seconds"]["range_seconds"] == [36, 39]
    assert baseline["stream_setup_seconds"]["median_seconds"] == 32.5
    assert baseline["benchmark_entry_seconds"]["median_seconds"] == 101.5
    assert baseline["worker_process_stage_seconds"]["median_seconds"] == 114.5
    exploratory = heldout["exploratory_14_update_training_wall"]
    assert exploratory["gating"] is False and exploratory["predeclared"] is False
    if missing:
        assert candidate["metrics_setup_seconds"]["status"] == "PARTIAL"
        assert candidate["metrics_setup_seconds"]["available_processes"] == 3
        assert candidate["metrics_setup_seconds"]["median_seconds"] is None
        assert candidate["benchmark_entry_seconds"]["status"] == "NOT_AVAILABLE"
        assert candidate["benchmark_entry_seconds"]["range_seconds"] is None
        assert exploratory["available_pairs"] == 3
        assert exploratory["paired_time_reduction_percent"][2] is None
        assert exploratory["median_paired_time_reduction_percent"] is None
        assert "3/4 available" in SUMMARY.markdown(result)
    else:
        assert candidate["metrics_setup_seconds"]["median_seconds"] == 34.5
        assert exploratory["status"] == "COMPLETE"
        assert exploratory["median_paired_time_reduction_percent"] == pytest.approx(10)
        assert all(
            value == pytest.approx(10) for value in exploratory["paired_time_reduction_percent"]
        )
    assert "not preregistered or gating" in SUMMARY.markdown(result)
