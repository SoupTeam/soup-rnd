"""Read-only Linux storage provenance probe. No cloud calls and no benchmark writes."""

import argparse
import json
import os
import subprocess
from pathlib import Path

from rich.console import Console


def command(argv):
    result = subprocess.run(argv, capture_output=True, text=True, check=False, timeout=15)
    return {"argv": argv, "returncode": result.returncode,
            "stdout": result.stdout, "stderr": result.stderr}


def inspect(path):
    absolute = os.path.realpath(path)
    metadata = os.stat(absolute)
    identity = f"{os.major(metadata.st_dev)}:{os.minor(metadata.st_dev)}"
    sysfs = Path("/sys/dev/block") / identity
    output = {
        "path": absolute,
        "device_major_minor": identity,
        "sysfs_exists": sysfs.exists(),
        "sysfs_realpath": os.path.realpath(sysfs) if sysfs.exists() else None,
        "findmnt": command(["findmnt", "--json", "-T", absolute,
                            "-o", "TARGET,SOURCE,FSTYPE,MAJ:MIN,OPTIONS"]),
        "df": command(["df", "-B1", "-T", absolute]),
    }
    if sysfs.exists():
        resolved = Path(os.path.realpath(sysfs))
        candidates = [resolved, *list(resolved.parents)[:3]]
        details = []
        for candidate in candidates:
            item = {"path": str(candidate)}
            for relative in ("device/model", "queue/rotational",
                             "partition", "stat", "dm/name"):
                target = candidate / relative
                if target.is_file():
                    try:
                        item[relative] = target.read_text().strip()
                    except OSError as error:
                        item[relative] = type(error).__name__
            slaves = candidate / "slaves"
            if slaves.is_dir():
                item["slaves"] = [os.path.realpath(child) for child in slaves.iterdir()]
            details.append(item)
        output["block_ancestry"] = details
    output["decision"] = "Evidence only; do not infer NVMe from disk model or speed alone"
    return output


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("paths", nargs="+", help="Existing model/shard mount paths")
    args = parser.parse_args()
    result = {
        "read_only": True,
        "lsblk": command(["lsblk", "--json", "-b", "-o",
                          "NAME,KNAME,TYPE,FSTYPE,SIZE,MODEL,TRAN,PKNAME,MAJ:MIN,MOUNTPOINTS"]),
        "paths": [inspect(path) for path in args.paths],
    }
    Console().print_json(json.dumps(result, ensure_ascii=True))


if __name__ == "__main__":
    main()
