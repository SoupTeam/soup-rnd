"""Exercise exact-byte publication without a cloud account or real tensor payloads."""

import hashlib
import json
import zipfile

import pytest

import publish_results as publication


def write(root, relative, raw):
    path = root / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)
    return path


def document(root, relative, value):
    return write(root, relative, publication.canonical_json(value))


def add_bundle(root, name, files):
    folder = root / "bundles" / name
    retained = folder / "retained"
    inventory = {}
    for relative, raw in files.items():
        path = write(retained, relative, raw)
        inventory[relative] = publication.identity(path)
    document(retained, "original-files.json", {"files": inventory})
    archive = write(folder, "results.tar", b"opaque encoded original bundle")
    document(folder, "index.json", {
        "name": name, "sha256": publication.identity(archive)["sha256"],
    })
    document(root, f"bundle-{name}-verified.json", {
        "name": name, "archive_bytes": archive.stat().st_size,
        "sha256": publication.identity(archive)["sha256"],
        "all_original_files_verified": len(inventory),
    })
    return retained


@pytest.fixture
def fixture_root(tmp_path):
    root = tmp_path / "run"
    root.mkdir()
    source = write(root, "source.tar.gz", b"frozen compressed source\x00\xff")
    worker = write(root, "worker.py", b'"""Executed worker."""\r\nvalue = 1\r\n')
    document(root, "launch-manifest.json", {
        "source.tar.gz": publication.identity(source), "worker.py": publication.identity(worker),
    })
    (root / "vast-finished").touch()
    document(root, "vast-rental.json", {"instance_id": 1, "volume_id": 2})
    document(root, "vast-deletion.json", {
        "instance_id": 1, "volume_id": 2, "verified_absent": True,
        "volume_verified_absent": True,
    })
    document(root, "vast-volume-deletion.json", {"volume_id": 2, "verified_absent": True})
    document(root, "independent-replay.json", {"status": "REPLAY_COMPLETE"})
    add_bundle(root, "first", {
        "source.tar.gz": source.read_bytes(), "worker.py": worker.read_bytes(),
        "results/run/metrics.json": b'{\r\n    "loss": 1.25\r\n}\r\n',
        "results/run/train.log": b"step one\r\nstep two\r\n",
        "results/scoped-regressions.xml": b'<?xml version="1.0"?><testsuite tests="92"/>\r\n',
        "results/progress.json": b'{"stages": [1]}\n',
        "results/gpu-telemetry.jsonl": b'{"gpu_util": 99}\n',
        "results/run/trace.safetensors": b"raw tensor excluded",
        "results/run/final-adapter/model.safetensors": b"adapter excluded",
    })
    return root


def test_original_bytes_and_source_are_retained_and_raw_stays_local(fixture_root, tmp_path):
    output = tmp_path / "publication"
    manifest = publication.build(fixture_root, output)
    with zipfile.ZipFile(output / "evidence.zip") as archive:
        assert archive.read("results/run/metrics.json") == b'{\r\n    "loss": 1.25\r\n}\r\n'
        assert archive.read("results/run/train.log") == b"step one\r\nstep two\r\n"
        assert archive.read("results/scoped-regressions.xml").endswith(b"/>\r\n")
        assert archive.read("executed/worker.py") == (fixture_root / "worker.py").read_bytes()
        assert archive.read("executed/source.tar.gz") == (
            fixture_root / "source.tar.gz"
        ).read_bytes()
        assert not any(name.endswith((".safetensors", "results.tar"))
                       for name in archive.namelist())
        assert "local-raw-artifact-index.json" not in archive.namelist()
    index = json.loads((output / "local-raw-artifact-index.json").read_bytes())
    assert len(index["artifacts"]) == 3
    assert all(not row["hashed_again_by_packager"] for row in index["artifacts"])
    assert manifest["every_zip_entry_byte_verified"]
    assert "no continuous completeness claim" in manifest["gpu_telemetry_coverage"]


def test_deterministic_zip_and_manifests_ignore_file_mtimes(fixture_root, tmp_path):
    first, second = tmp_path / "first-output", tmp_path / "second-output"
    publication.build(fixture_root, first)
    publication.build(fixture_root, second)
    for name in ("evidence.zip", "evidence-manifest.json", "local-raw-artifact-index.json"):
        assert (first / name).read_bytes() == (second / name).read_bytes()
    manifest = json.loads((first / "evidence-manifest.json").read_bytes())
    packed_sha = hashlib.sha256((first / "evidence.zip").read_bytes()).hexdigest()
    assert manifest["archive"]["sha256"] == packed_sha


def test_identical_duplicates_aggregate_with_namespaced_mutable_snapshots(fixture_root, tmp_path):
    add_bundle(fixture_root, "second", {
        "results/run/metrics.json": b'{\r\n    "loss": 1.25\r\n}\r\n',
        "results/progress.json": b'{"stages": [1, 2]}\n',
        "results/gpu-telemetry.jsonl": b'{"gpu_util": 10}\n',
    })
    manifest = publication.build(fixture_root, tmp_path / "output")
    assert len(manifest["files"]["results/run/metrics.json"]["original_locations"]) == 2
    with zipfile.ZipFile(tmp_path / "output" / "evidence.zip") as archive:
        assert archive.read("bundle-snapshots/first/results/progress.json") != archive.read(
            "bundle-snapshots/second/results/progress.json")
        assert archive.read("bundle-snapshots/first/results/gpu-telemetry.jsonl") != archive.read(
            "bundle-snapshots/second/results/gpu-telemetry.jsonl")


def test_conflicting_immutable_duplicates_are_rejected(fixture_root, tmp_path):
    add_bundle(fixture_root, "second", {"results/run/metrics.json": b'{"loss": 99}\n'})
    with pytest.raises(ValueError, match="Conflicting duplicate"):
        publication.build(fixture_root, tmp_path / "output")
    assert not (tmp_path / "output" / "evidence.zip").exists()


def test_changed_retained_metadata_or_frozen_helper_is_rejected(fixture_root, tmp_path):
    write(fixture_root, "bundles/first/retained/results/run/train.log", b"changed after retention")
    with pytest.raises(ValueError, match="recorded byte identity"):
        publication.build(fixture_root, tmp_path / "output")


def test_credentials_and_connection_api_response_are_not_auto_included(fixture_root, tmp_path):
    write(fixture_root, "private-key", b"this must stay outside the public package")
    document(fixture_root, "vast-connection.json", {
        "host": "private endpoint", "api_key": "secret",
    })
    document(fixture_root, "vast-selected-offer.json", {"token": "private api response"})
    manifest = publication.build(fixture_root, tmp_path / "output")
    assert not any("connection" in name or "private-key" in name or "selected-offer" in name
                   for name in manifest["files"])


@pytest.mark.parametrize("kind", ["json-key", "pem", "private-address"])
def test_sensitive_content_in_allowlisted_metadata_blocks_publication(fixture_root, tmp_path, kind):
    if kind == "json-key":
        document(fixture_root, "summary.json", {"api_key": "do not publish"})
    elif kind == "pem":
        write(fixture_root, "independent-replay.log", b"-----BEGIN " + b"OPENSSH PRIVATE KEY-----")
    else:
        document(fixture_root, "summary.json", {"public_ipaddr": "private endpoint"})
    with pytest.raises(ValueError, match="credential|Credential"):
        publication.build(fixture_root, tmp_path / "output")


def test_cleanup_and_replay_are_required(fixture_root, tmp_path):
    document(fixture_root, "vast-volume-deletion.json", {"volume_id": 2, "verified_absent": False})
    with pytest.raises(ValueError, match="deletion proofs"):
        publication.build(fixture_root, tmp_path / "output")


@pytest.mark.parametrize("flag", ["false", "true", 1, None])
@pytest.mark.parametrize("name,field", [
    ("vast-deletion.json", "verified_absent"),
    ("vast-deletion.json", "volume_verified_absent"),
    ("vast-volume-deletion.json", "verified_absent"),
])
def test_cleanup_requires_json_true_not_merely_truthy(fixture_root, name, field, flag):
    path = fixture_root / name
    value = json.loads(path.read_bytes())
    value[field] = flag
    document(fixture_root, name, value)
    with pytest.raises(ValueError, match="deletion proofs"):
        publication.verify_cleanup(fixture_root)


@pytest.mark.parametrize("identity", [None, 0, -1, True, "1"])
def test_matching_invalid_ids_cannot_prove_exact_cleanup(fixture_root, identity):
    for name in ("vast-rental.json", "vast-deletion.json", "vast-volume-deletion.json"):
        value = json.loads((fixture_root / name).read_bytes())
        for key in ("instance_id", "volume_id"):
            if key in value:
                value[key] = identity
        document(fixture_root, name, value)
    with pytest.raises(ValueError, match="positive integer"):
        publication.verify_cleanup(fixture_root)


@pytest.mark.parametrize("name,field", [
    ("vast-deletion.json", "instance_id"),
    ("vast-deletion.json", "volume_id"),
    ("vast-volume-deletion.json", "volume_id"),
])
def test_boolean_deletion_id_does_not_equal_integer_rental_id(fixture_root, name, field):
    for current in ("vast-rental.json", "vast-deletion.json", "vast-volume-deletion.json"):
        value = json.loads((fixture_root / current).read_bytes())
        for key in ("instance_id", "volume_id"):
            if key in value:
                value[key] = 1
        if current == name:
            value[field] = True
        document(fixture_root, current, value)
    with pytest.raises(ValueError, match="positive integer"):
        publication.verify_cleanup(fixture_root)


def test_unreviewed_frozen_file_cannot_smuggle_credentials(fixture_root, tmp_path):
    document(fixture_root, "launch-manifest.json", {
        "private-key": {"sha256": "a" * 64, "bytes": 1},
    })
    with pytest.raises(ValueError, match="unreviewed helper"):
        publication.build(fixture_root, tmp_path / "output")


def test_parent_traversal_in_retention_manifest_is_rejected(fixture_root, tmp_path):
    add_bundle(fixture_root, "second", {"results/../../escape.json": b"{}"})
    with pytest.raises(ValueError, match="Unsafe original"):
        publication.build(fixture_root, tmp_path / "output")


def test_observer_and_coverage_are_exact_and_not_mislabeled_as_frozen(fixture_root, tmp_path):
    write(fixture_root, "observe.py", b'"""Read-only observer."""\r\n')
    write(fixture_root, "gpu-telemetry-last-observed.jsonl", b'{"samples": 12}\r\n')
    document(fixture_root, "telemetry-observer.json", {"coverage": "last sample may be missing"})
    manifest = publication.build(fixture_root, tmp_path / "output")
    assert "executed-observer/observe.py" in manifest["files"]
    assert "executed/observe.py" not in manifest["files"]
    assert "local/telemetry-observer.json" in manifest["files"]


def test_refuse_overwrite_but_preserve_user_readme(fixture_root, tmp_path):
    output = tmp_path / "output"
    write(output, "README.md", b"User-authored summary")
    publication.build(fixture_root, output)
    assert (output / "README.md").read_bytes() == b"User-authored summary"
    with pytest.raises(FileExistsError, match="Refuse overwriting"):
        publication.build(fixture_root, output)
