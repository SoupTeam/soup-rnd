"""Whole-pair bootstrap and practical gate; no cross-model/hardware pooling."""

import random
import statistics


def summarize(pairs):
    if len(pairs) != 4 or sorted(pair["order"] for pair in pairs) != ["AB", "AB", "BA", "BA"]:
        raise ValueError("Require four fresh AB/BA/BA/AB pairs")
    reductions = []
    for pair in pairs:
        native, auto = pair["baseline"], pair["auto"]
        if len(native) != 8 or len(auto) != 8 or any(value <= 0 for value in native + auto):
            raise ValueError("Each fresh process must retain eight positive measured step times")
        reductions.append(100 * (1 - statistics.median(auto) / statistics.median(native)))
    rng = random.Random(792)
    bootstrap = sorted(statistics.median(rng.choices(reductions, k=4)) for _ in range(20000))
    lower, upper = bootstrap[499], bootstrap[19499]
    median = statistics.median(reductions)
    positive = sum(value > 0 for value in reductions) / 4
    return {
        "paired_step_time_reduction_percent": reductions,
        "median_paired_step_time_reduction_percent": median,
        "bootstrap95_percent": [lower, upper],
        "positive_pair_fraction": positive,
        "practical_speed_gate_passed": median >= 2 and positive >= 0.75 and lower > 0,
        "bootstrap_unit": "entire fresh process pair",
        "resamples": 20000,
        "seed": 792,
        "baseline_tokens_per_second": 2048
        / statistics.median([statistics.median(pair["baseline"]) for pair in pairs]),
        "auto_tokens_per_second": 2048
        / statistics.median([statistics.median(pair["auto"]) for pair in pairs]),
    }
