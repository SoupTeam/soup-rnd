"""Prepare pinned, identical data and immutable dense/NF4 cache before a cohort."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import time
from pathlib import Path
from typing import Any

from rich.console import Console

FROZEN_DATA_SHA256 = "313d17f90f4b62004a1d8232ba9bc0b19388a65e933c930ddc9aecfe7ffbf0f9"


def digest(path: Path) -> str:
    hashed = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(8 * 2**20), b""):
            hashed.update(chunk)
    return hashed.hexdigest()


def write_data(path: Path) -> None:
    """Exactly the cohort-B byte serialization, ordering and prompt contents."""
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for number in range(32):
            handle.write(
                json.dumps({
                    "messages": [
                        {"role": "user", "content": f"Calculate {number} + 1 and explain briefly."},
                        {"role": "assistant", "content": (
                            f"{number} + 1 = {number + 1}. Add one to the number. " * 160
                        )},
                    ],
                }) + "\n"
            )


def configuration(root: Path, size: int, quant: str, source: str) -> dict[str, Any]:
    if quant not in {"none", "nf4"} or source not in {"ram", "disk"}:
        raise ValueError("unsupported preparation format or source")
    training: dict[str, Any] = {
        "seed": 792,
        "batch_size": 1,
        "gradient_accumulation_steps": 2,
        "epochs": 1,
        "lr": 0.00002,
        "warmup_ratio": 0,
        "quantization": "4bit" if quant == "nf4" else "none",
        "stream_layers": True,
        "stream_source": source,
        "stream_buffers": 2,
        "stream_read_ahead": 2,
        "stream_pin": True,
        "stream_vram_probe": False,
        "stream_resident_layers": 0,
        "gradient_checkpointing": True,
        "fast_lora": False,
        "use_liger": False,
        "use_flash_attn": False,
        "lora": {
            "r": 4, "alpha": 4, "dropout": 0,
            "target_modules": [
                "q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj",
            ],
        },
    }
    if quant == "nf4":
        training["bnb_4bit_use_double_quant"] = True
    return {
        "base": str(root / f"model-{size}"),
        "task": "sft",
        "backend": "transformers",
        "data": {
            "train": str(root / "train.jsonl"), "format": "chatml", "chat_template": "chatml",
            "val_split": 0, "max_length": 1024,
        },
        "training": training,
    }


def inventory(paths: list[Path], root: Path) -> dict[str, Any]:
    result = {}
    for path in sorted(paths):
        stat = path.stat()
        result[str(path.relative_to(root))] = {
            "bytes": stat.st_size, "mtime_ns": stat.st_mtime_ns, "sha256": digest(path),
        }
    return result


def prepare(root: Path, size: int, quant: str, source: str) -> dict[str, Any]:
    import torch
    import yaml
    from huggingface_hub import snapshot_download
    from soup_cli.config.loader import load_config
    from soup_cli.data.loader import load_dataset
    from soup_cli.trainer.sft import SFTTrainerWrapper
    from soup_cli.utils.layer_shard import read_shard_index, resolve_shard_dir

    from bench import configure_device_budget

    started = time.perf_counter()
    protocol = json.loads((root / "protocol.json").read_text(encoding="utf-8"))
    model = next(row for row in protocol["models"] if row["size_b"] == size)
    base = root / f"model-{size}"
    # Keep the dense upper bound for both formats; NF4 must first download BF16
    # source, and metadata estimates are not permission to overrun the lease disk.
    required = model["weight_bytes"] * 2 + 8 * 2**30
    existing = sum(path.stat().st_size for path in base.glob("*") if path.is_file())
    if shutil.disk_usage(root).free + existing < required:
        raise RuntimeError("Insufficient disk for pinned source, cache and preparation reserve")
    snapshot_download(
        model["model_id"], revision=model["revision"], local_dir=str(base),
        allow_patterns=["*.json", "*.model", "*.txt", "*.jinja"]
        + model.get("weight_files", ["model-*.safetensors"]),
    )
    results = root / "results"
    results.mkdir(parents=True, exist_ok=True)
    snapshot = {
        "model_id": model["model_id"], "revision": model["revision"],
        "files": inventory([path for path in base.iterdir() if path.is_file()], base),
    }
    snapshot_path = results / f"model-{size}-manifest.json"
    snapshot_path.write_text(json.dumps(snapshot, indent=2) + "\n", encoding="utf-8")
    data = root / "train.jsonl"
    write_data(data)
    if digest(data) != FROZEN_DATA_SHA256:
        raise ValueError("Dataset serialization differs from the frozen cohort-B input")
    (results / "train.jsonl").write_bytes(data.read_bytes())
    payload = configuration(root, size, quant, source)
    config_path = root / f"model-{size}-{quant}-{source}.yaml"
    encoded = yaml.safe_dump(payload)
    config_path.write_text(encoded, encoding="utf-8")
    (results / config_path.name).write_text(encoded, encoding="utf-8")
    # Soup has one index per cache directory. Distinct roots prevent a later
    # NF4 setup from invalidating the dense cohort's already-hashed shards.
    cache_base = Path(os.environ.get("SOUP_STUDY_CACHE_BASE", "/data/soup"))
    cache_root = Path(f"{cache_base}-shards-{quant}")
    cache_root.mkdir(parents=True, exist_ok=True)
    os.environ["SOUP_LAYER_STREAM_CACHE_DIR"] = str(cache_root)
    if os.environ.get("SOUP_LAYER_STREAM_STRIPE_DIRS"):
        raise ValueError("This single-storage control does not permit extra stripe roots")
    shard_dir = Path(resolve_shard_dir(str(base)))
    if os.path.commonpath([os.path.realpath(shard_dir), os.path.realpath(cache_root)]) != (
        os.path.realpath(cache_root)
    ):
        raise ValueError("Soup rejected the declared cache root; set TMPDIR before Python starts")
    budget = configure_device_budget()
    wrapper = SFTTrainerWrapper(load_config(str(config_path)), device="cuda", report_to="none")
    try:
        wrapper.setup(load_dataset(wrapper.config.data))
        runtime = wrapper._stream_runtime
        if runtime.tier != source or runtime.pool.resident_slots:
            raise ValueError("Preparation did not use the declared baseline source")
        index = read_shard_index(str(shard_dir))
        if index.quant != quant:
            raise ValueError("Prepared shard quantization does not match the cohort")
        if quant == "nf4" and (not index.double_quant or index.quant_device != "cuda"):
            raise ValueError("NF4 requires a CUDA-quantized double-quantized cache")
        source_info = {
            "class": type(runtime.source).__name__, "tier": runtime.tier,
            "direct_io": getattr(runtime.source, "direct_io", None),
            "direct_io_roots": dict(getattr(runtime.source, "direct_io_roots", {})),
        }
        torch.cuda.synchronize()
        report = {
            "status": "PREPARED_CACHE_NOT_A_TRAINING_VERDICT",
            "model_id": model["model_id"], "revision": model["revision"], "size_b": size,
            "base_path": str(base),
            "quant": quant, "source": source, "cache_root": str(cache_root),
            "shard_dir": str(shard_dir), "config_sha256": digest(config_path),
            "data_sha256": digest(data), "data_path": str(data),
            "snapshot_manifest_sha256": digest(snapshot_path),
            "shard_quantization": index.quant, "double_quant": index.double_quant,
            "quant_device": index.quant_device, "quant_specs": json.loads(
                (shard_dir / "index.json").read_text(encoding="utf-8")
            ).get("quant_specs", {}),
            "device_budget": budget, "source_info": source_info,
            "preparation_peak_allocated_bytes": torch.cuda.max_memory_allocated(),
            "preparation_peak_reserved_bytes": torch.cuda.max_memory_reserved(),
        }
    finally:
        wrapper._close_stream_runtime()
    # Includes exact packed data, all sidecars and the authoritative index.
    # Matched training processes check these immutable files' stat identities
    # and index SHA; they do not hash all weights and warm the disk every time.
    files = list(shard_dir.glob("*.safetensors")) + [shard_dir / "index.json"]
    report["shard_files"] = inventory(files, shard_dir)
    report["preparation_seconds"] = time.perf_counter() - started
    manifest_path = config_path.with_suffix(".prepare.json")
    manifest_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    (results / manifest_path.name).write_bytes(manifest_path.read_bytes())
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("size", type=int)
    parser.add_argument("--quant", choices=["none", "nf4"], required=True)
    parser.add_argument("--source", choices=["ram", "disk"], required=True)
    parser.add_argument("--root", type=Path, default=Path(__file__).parent)
    args = parser.parse_args()
    report = prepare(args.root, args.size, args.quant, args.source)
    Console().print({
        "status": report["status"], "model": report["model_id"], "quant": args.quant,
        "source": args.source, "shard_files": len(report["shard_files"]),
    })


if __name__ == "__main__":
    main()
