"""Research fixed residency counts using unchanged pretrained numerical gates."""

from __future__ import annotations

import argparse
import contextlib
import hashlib
import importlib.metadata
import json
import os
import time
from pathlib import Path
from typing import Any

DEVICE_RESERVE_BYTES = 256 * 2**20
MIN_DEVICE_FREE_BYTES = 128 * 2**20


class CapacityRefusalError(ValueError):
    """A measured memory refusal, distinct from a broken execution path."""


def count_from_arm(arm: str) -> int:
    if arm == "baseline":
        return 0
    if arm.startswith("resident") and arm[8:].isdigit() and int(arm[8:]) > 0:
        return int(arm[8:])
    raise ValueError("arm must be 'baseline' or 'residentN' for positive integer N")


def device_budget(total: int, free: int, reserved: int) -> int:
    if not 7.5 * 2**30 <= total <= 8.1 * 2**30:
        raise ValueError("Require an actual physical 8 GiB CUDA GPU")
    cap = min(total - DEVICE_RESERVE_BYTES, free + reserved - MIN_DEVICE_FREE_BYTES)
    if cap <= 0:
        raise CapacityRefusalError("No positive allocator budget after device headroom")
    return cap


def configure_device_budget() -> dict[str, int]:
    import torch

    if not torch.cuda.is_available() or torch.cuda.device_count() != 1:
        raise ValueError("Require exactly one physical CUDA GPU")
    torch.cuda.synchronize()
    total = int(torch.cuda.get_device_properties(0).total_memory)
    free = int(torch.cuda.mem_get_info(0)[0])
    reserved = int(torch.cuda.memory_reserved(0))
    cap = device_budget(total, free, reserved)
    torch.cuda.set_per_process_memory_fraction(cap / total, device=0)
    return {
        "physical_gpu_bytes": total, "initial_device_free_bytes": free,
        "initial_reserved_bytes": reserved, "allocator_budget_bytes": cap,
        "device_reserve_bytes": DEVICE_RESERVE_BYTES,
        "minimum_device_free_bytes": MIN_DEVICE_FREE_BYTES,
    }


def host_memory() -> dict[str, int]:
    import resource

    report = {"max_rss_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024}
    for line in Path("/proc/self/status").read_text().splitlines():
        name, _, value = line.partition(":")
        if name in {"VmRSS", "VmHWM", "VmLck", "VmPin"}:
            report[name + "_bytes"] = int(value.split()[0]) * 1024
    return report


def process_io() -> dict[str, int]:
    """Linux process counters include its reader threads; read_bytes is storage I/O."""
    return {
        name: int(value) for name, value in (
            line.split(":", 1) for line in Path("/proc/self/io").read_text().splitlines()
        )
    }


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_preparation(config_path: Path) -> dict[str, Any]:
    manifest_path = config_path.with_suffix(".prepare.json")
    report = json.loads(manifest_path.read_text(encoding="utf-8"))
    if report.get("status") != "PREPARED_CACHE_NOT_A_TRAINING_VERDICT":
        raise ValueError("A completed immutable cache preparation is required")
    if sha256(config_path) != report["config_sha256"]:
        raise ValueError("Configuration differs from the prepared immutable cohort")
    if sha256(Path(report["data_path"])) != report["data_sha256"]:
        raise ValueError("Prepared dataset bytes changed")
    shard_dir = Path(report["shard_dir"])
    for name, expected in report["shard_files"].items():
        path = shard_dir / name
        if os.path.commonpath([os.path.realpath(shard_dir), os.path.realpath(path)]) != (
            os.path.realpath(shard_dir)
        ):
            raise ValueError("Shard manifest path escapes its cache directory")
        stat = path.stat()
        if stat.st_size != expected["bytes"] or stat.st_mtime_ns != expected["mtime_ns"]:
            raise ValueError(f"Immutable prepared shard identity changed: {name}")
        if name == "index.json" and sha256(path) != expected["sha256"]:
            raise ValueError("Prepared quantization index bytes changed")
    report["manifest_sha256"] = sha256(manifest_path)
    os.environ["SOUP_LAYER_STREAM_CACHE_DIR"] = report["cache_root"]
    from soup_cli.utils.layer_shard import resolve_shard_dir

    if os.path.realpath(resolve_shard_dir(report["base_path"])) != os.path.realpath(shard_dir):
        raise ValueError("Soup rejected the prepared cache root; set TMPDIR before Python starts")
    return report


def semantic_config(config: Any, arm: str) -> Any:
    """Only widen the historical semantics adapter to frozen NF4 baseline configs."""
    from soup_cli.config.schema import SoupConfig

    if arm != "baseline":
        raise ValueError("Semantics adapter only supports the baseline computation")
    if config.training.use_liger or config.training.fast_lora:
        raise ValueError("Require use_liger=false and fast_lora=false")
    if not config.training.stream_layers or config.training.quantization not in {"none", "4bit"}:
        raise ValueError("Require dense or NF4 layer streaming")
    payload = config.model_dump()
    payload["training"]["use_flash_attn"] = False
    return SoupConfig.model_validate(payload)


def install_fixed_residency(model: Any, runtime: Any, count: int) -> list[int]:
    from soup_cli.utils.layer_stream_runtime import clear_stream_substitution_cache
    from soup_cli.utils.stream_residency import centered_layer_indices

    if runtime.pool.resident_slots:
        raise ValueError("Ordinary setup unexpectedly installed private decoder weights")
    if count == 0:
        return []
    if runtime.tier != "ram":
        raise ValueError("Fixed residency is RAM-only; disk is a baseline control")
    indices = list(centered_layer_indices(runtime.n_layers, count))
    clear_stream_substitution_cache(model)
    runtime.pool.reserve_layers(indices, runtime.source, runtime.prefetcher.stream)
    if sorted(runtime.pool.resident_slots) != indices:
        raise ValueError("Actual private pool mapping differs from the requested fixed count")
    return indices


def sample_memory(provenance: dict[str, Any], where: str) -> dict[str, int]:
    import torch

    torch.cuda.synchronize()
    free = int(torch.cuda.mem_get_info(0)[0])
    used = max(0, provenance["physical_gpu_bytes"] - free)
    provenance["device_free_min_bytes"] = min(provenance.get("device_free_min_bytes", free), free)
    provenance["device_used_peak_bytes"] = max(provenance.get("device_used_peak_bytes", 0), used)
    sample = {
        "device_free_bytes": free, "device_used_bytes": used,
        "peak_allocated_bytes": int(torch.cuda.max_memory_allocated()),
        "peak_reserved_bytes": int(torch.cuda.max_memory_reserved()),
    }
    if free < MIN_DEVICE_FREE_BYTES:
        raise CapacityRefusalError(f"Less than 128 MiB driver-free VRAM at {where}")
    if sample["peak_reserved_bytes"] > provenance["allocator_budget_bytes"]:
        raise CapacityRefusalError(
            f"Allocator reserved peak exceeded the prospective cap at {where}"
        )
    return sample


def storage_classification(
    proof: dict[str, Any], cache_paths: list[str], direct_io: bool, read_bytes: int,
) -> dict[str, Any]:
    """Keep a disk-tier result separate from a proven NVMe read result."""
    verified = proof.get("verified_path")
    identity = proof.get("deviceproof", proof)
    device_proof = (
        isinstance(identity, dict) and bool(identity.get("device_major_minor"))
        and bool(identity.get("sysfs_realpath"))
    )
    contained = bool(verified) and all(
        os.path.commonpath([os.path.realpath(path), os.path.realpath(verified)]) == (
            os.path.realpath(verified)
        ) for path in cache_paths
    )
    established = bool(
        proof.get("nvme_verified") is True and proof.get("backing_device")
        and proof.get("mount_source") and device_proof and contained
    )
    qualified = established and direct_io is True and read_bytes > 0
    return {
        "nvme_backing_verified": established,
        "nvme_timing_qualified": qualified,
        "nvme_read_control_qualified": qualified,
        "source_backing_claim": (
            "verified NVMe path with direct I/O and observed process storage reads"
            if qualified else "disk-tier control only; NVMe read qualification not established"
        ),
        "observed_process_storage_read_bytes": read_bytes,
    }


def quantization_provenance(model: Any, runtime: Any, expected_quant: str) -> dict[str, Any]:
    """Check actual pooled bytes and wrapper specs, not only the YAML label."""
    pending, seen, specs = [model], set(), []
    while pending:
        module = pending.pop()
        if id(module) in seen:
            continue
        seen.add(id(module))
        pending.extend(child for child in module._modules.values() if child is not None)
        if hasattr(module, "idx") and vars(module).get("pool") is runtime.pool:
            quant_specs = vars(module).get("quant_specs", {})
            specs.append({"idx": module.idx, "count": len(quant_specs), "nested": all(
                spec.nested for spec in quant_specs.values()
            )})
    buffers = runtime.pool.buffers[0]
    dtypes = {name: str(value.dtype) for name, value in buffers.items()}
    loaded_4bit = bool(getattr(model, "is_loaded_in_4bit", False))
    if expected_quant == "nf4":
        if not loaded_4bit or len(specs) != runtime.n_layers:
            raise ValueError("NF4 model marker or streamed wrapper count differs")
        if any(row["count"] != 7 or not row["nested"] for row in specs):
            raise ValueError("Expected seven double-quantized NF4 decoder linears per layer")
        if "torch.uint8" not in dtypes.values():
            raise ValueError("NF4 pool contains no packed byte tensors")
    elif loaded_4bit or any(row["count"] for row in specs):
        raise ValueError("Dense baseline unexpectedly contains quantized decoder weights")
    return {
        "loaded_in_4bit": loaded_4bit,
        "quantized_layer_specs": sorted(specs, key=lambda x: x["idx"]),
        "rotating_slot_dtypes": dtypes,
        "bitsandbytes": importlib.metadata.version("bitsandbytes"),
    }


@contextlib.contextmanager
def observe_feature(count: int, prepared: dict[str, Any], provenance: dict[str, Any]):
    import soup_cli.trainer.sft as sft
    import torch
    from transformers import TrainerCallback

    original = sft.SFTTrainerWrapper

    class ObservedWrapper(original):
        def setup(self, *args: Any, **kwargs: Any) -> Any:
            started = time.perf_counter()
            result = super().setup(*args, **kwargs)
            training = self.config.training
            if training.use_liger or training.fast_lora or training.stream_resident_layers != 0:
                raise ValueError("Require unchanged ordinary PEFT streaming setup")
            if not hasattr(self, "_streaming_liger_patches"):
                self._streaming_liger_patches = {}
            runtime = self._stream_runtime
            if runtime.tier != prepared["source"] or self._streaming_liger_patches:
                raise ValueError("Actual source or arithmetic patches differ from the cohort")
            expected = "4bit" if prepared["quant"] == "nf4" else "none"
            if training.quantization != expected:
                raise ValueError("Actual quantization differs from the prepared cohort")
            indices = install_fixed_residency(self.model, runtime, count)
            provenance.update(
                whole_setup_seconds=time.perf_counter() - started, indices=indices,
                resident_layers=len(indices), resident_bytes=runtime.pool.resident_bytes,
                layer_count=runtime.n_layers, actual_mode=0, actual_tier=runtime.tier,
                per_layer_bytes=[
                    runtime.pool.resident_slot_bytes(i) for i in range(runtime.n_layers)
                ],
                attention_backend=self.model.get_base_model().config._attn_implementation,
                host_memory_after_setup=host_memory(),
                quantization_actual=quantization_provenance(self.model, runtime, prepared["quant"]),
                all_update_wall_seconds=[], all_update_peak_allocated_bytes=[],
                all_update_peak_reserved_bytes=[], per_update_loads=[], per_update_io=[],
                source_class=type(runtime.source).__name__,
                direct_io=getattr(runtime.source, "direct_io", None),
                direct_io_roots=dict(getattr(runtime.source, "direct_io_roots", {})),
                source_backing_claim=(
                    "RAM-tier stream; no NVMe performance claim" if runtime.tier == "ram"
                    else "disk tier only; physical backing requires separate proof"
                ),
                cache_root=prepared["cache_root"], cache_paths=[prepared["shard_dir"]],
            )
            provenance["io_after_setup"] = process_io()
            memory = sample_memory(provenance, "setup")
            provenance["setup_peak_allocated_bytes"] = memory["peak_allocated_bytes"]
            provenance["setup_peak_reserved_bytes"] = memory["peak_reserved_bytes"]
            sizes = provenance["per_layer_bytes"]
            uniform_bytes = sizes[0] if len(set(sizes)) == 1 else None

            class Observe(TrainerCallback):
                def on_step_begin(self, _args: Any, _state: Any, _control: Any, **_kw: Any) -> None:
                    sample_memory(provenance, "step begin")
                    self.loads = runtime.pool.loads
                    self.large_loads = getattr(runtime.large_pool, "loads", 0)
                    self.io = process_io()
                    self.started = time.perf_counter()

                def on_step_end(self, _args: Any, state: Any, _control: Any, **_kw: Any) -> None:
                    memory = sample_memory(provenance, "step end")
                    elapsed = time.perf_counter() - self.started
                    io = process_io()
                    provenance["all_update_wall_seconds"].append(elapsed)
                    provenance["all_update_peak_allocated_bytes"].append(memory["peak_allocated_bytes"])
                    provenance["all_update_peak_reserved_bytes"].append(memory["peak_reserved_bytes"])
                    loads = runtime.pool.loads - self.loads
                    provenance["per_update_loads"].append({
                        "step": state.global_step, "loads": loads,
                        "large_loads": getattr(runtime.large_pool, "loads", 0) - self.large_loads,
                        "logical_decoder_copy_bytes": (
                            loads * uniform_bytes if uniform_bytes else None
                        ),
                    })
                    provenance["per_update_io"].append({
                        "step": state.global_step,
                        "linux_process_io_delta": {key: io[key] - self.io[key] for key in io},
                    })

            self.trainer.add_callback(Observe())
            return result

    sft.SFTTrainerWrapper = ObservedWrapper
    try:
        yield
    finally:
        try:
            provenance["host_memory_at_exit"] = host_memory()
            provenance["whole_run_peak_allocated_bytes"] = max(
                [torch.cuda.max_memory_allocated(), provenance.get("setup_peak_allocated_bytes", 0)]
                + provenance.get("all_update_peak_allocated_bytes", [])
            )
            provenance["whole_run_peak_reserved_bytes"] = max(
                [torch.cuda.max_memory_reserved(), provenance.get("setup_peak_reserved_bytes", 0)]
                + provenance.get("all_update_peak_reserved_bytes", [])
            )
            end_io = process_io()
            initial_io = provenance.get("io_after_setup", end_io)
            provenance["process_io_after_training_delta"] = {
                key: end_io[key] - initial_io[key] for key in end_io
            }
            updates = provenance.get("per_update_io", [])
            provenance["io_read_bytes_delta"] = (
                sum(row["linux_process_io_delta"]["read_bytes"] for row in updates)
                if updates else provenance["process_io_after_training_delta"].get("read_bytes", 0)
            )
            if provenance.get("actual_tier") == "disk":
                provenance.update(storage_classification(
                    provenance.get("storage_validation", {}), provenance.get("cache_paths", []),
                    provenance.get("direct_io") is True, provenance["io_read_bytes_delta"],
                ))
        finally:
            sft.SFTTrainerWrapper = original


def main() -> None:
    import torch
    from benchmarks.harness import liger_streaming_bench, liger_streaming_parity
    from soup_cli.config.loader import load_config
    from soup_cli.utils.layer_stream_runtime import _is_out_of_memory

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--arm", required=True)
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument("--capture", action="store_true")
    modes.add_argument("--semantics", action="store_true")
    modes.add_argument("--capacity", action="store_true")
    parser.add_argument("--warmup", type=int, default=6)
    parser.add_argument("--steps", type=int, default=8)
    args = parser.parse_args()
    count = count_from_arm(args.arm)
    provenance: dict[str, Any] = {
        "status": "STARTED", "arm": args.arm, "capacity_only": args.capacity,
        "capacity_failure": None, "requested_resident_layers": count,
        "entry_sha256": sha256(Path(__file__)), "pid": os.getpid(),
        "torch": torch.__version__, "affinity": sorted(os.sched_getaffinity(0)),
    }
    started = time.perf_counter()
    try:
        prepared = load_preparation(args.config)
        if prepared["source"] == "disk" and count:
            raise ValueError("Disk is a baseline-only control, not private-weight residency")
        provenance.update(config_sha256=sha256(args.config), prepared=prepared)
        proof_path = args.config.parent / "storage-validation.json"
        if proof_path.is_file():
            provenance["storage_validation"] = json.loads(proof_path.read_text(encoding="utf-8"))
            provenance["storage_validation_sha256"] = sha256(proof_path)
        provenance.update(
            requested_quant=prepared["quant"],
            quantization="4bit" if prepared["quant"] == "nf4" else "none",
            shard_quantization=prepared["shard_quantization"],
            source=prepared["source"], **configure_device_budget(),
        )
        if args.semantics:
            from benchmarks.harness import streaming_optimization_bench as semantics

            original_config, original_wrapper = semantics.study_config, semantics.study_wrapper
            try:
                semantics.study_config = semantic_config
                semantics.study_wrapper = lambda _arm, _info: observe_feature(
                    count, prepared, provenance
                )
                semantics.attention_semantics(str(args.config), "baseline", args.output)
            finally:
                semantics.study_config, semantics.study_wrapper = original_config, original_wrapper
        else:
            with observe_feature(count, prepared, provenance):
                if args.capture:
                    liger_streaming_parity.capture(str(args.config), "baseline", args.output)
                else:
                    liger_streaming_bench.run(
                        load_config(str(args.config)), arm="baseline",
                        warmup=1 if args.capacity else args.warmup,
                        steps=2 if args.capacity else args.steps, output=args.output,
                    )
        sample_memory(provenance, "process completion")
        provenance["status"] = "COMPLETED_NOT_AN_INDEPENDENT_VERDICT"
    except BaseException as error:
        failure = "cap_refusal" if isinstance(error, CapacityRefusalError) else None
        if _is_out_of_memory(error):
            failure = "OOM"
        provenance.update(
            status="CAPACITY_REFUSED" if failure else "FAILED", capacity_failure=failure,
            error=f"{type(error).__name__}: {error}",
        )
        raise
    finally:
        provenance["whole_entry_seconds"] = time.perf_counter() - started
        provenance["capacity_admissibility"] = (
            "capacity only; no numerical or performance qualification" if args.capacity
            else "requires independent unchanged numerical gates and prospective timing analysis"
        )
        args.output.mkdir(parents=True, exist_ok=True)
        (args.output / "residency-sweep-provenance.json").write_text(
            json.dumps(provenance, indent=2) + "\n", encoding="utf-8"
        )


if __name__ == "__main__":
    main()
