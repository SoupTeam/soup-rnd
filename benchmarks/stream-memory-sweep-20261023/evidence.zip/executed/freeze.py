"""Freeze the reviewed source, execution helpers and numerical protocol before rental."""

import hashlib
import json
import zipfile

import cloud
import controller

FEATURE = "e0d47e0dfb76a932e436a7034d2f655b46d86788"
PREVIOUS = (
    r"C:\Users\esenb\.codex\worktrees\stream-memory-auto-20261023\soup-rnd-d2"
    r"\benchmarks\stream-memory-auto-20261023\evidence.zip"
)


def main():
    expected = "5c07843889dc79ef58d6864b4882394f9520fe797ebd0f5d54b124090b688a69"
    if cloud.digest(PREVIOUS) != expected:
        raise RuntimeError("Previous published source identity evidence archive changed")
    with zipfile.ZipFile(PREVIOUS) as archive:
        raw = archive.read("executed/production-newline-normalization.json")
    (cloud.ROOT / "production-newline-normalization.json").write_bytes(raw)
    protocol = json.loads((cloud.ROOT / "protocol.json").read_text())
    protocol["production_feature_commit"] = FEATURE
    protocol["source_identity_note"] = (
        "Reuse exact cohort B source archive. Production feature files match the committed "
        "feature after the explicitly recorded CRLF/LF normalization; not a Git tree archive."
    )
    protocol["retention_forecast_note"] = (
        "Preregistered prospective 17.6 GB encoded matrix, 24 GB quoted upload allowance. "
        "Actual full archive spans and SHA256, never a forecast, govern retention ACKs."
    )
    cloud.save("protocol.json", protocol)
    names = set(controller.REQUIRED) | {
        "controller.py", "cloud.py", "launch.py", "remote_guard.py", "transport.py",
        "archive_ranges.py", "retention-donors.json", "production-newline-normalization.json",
        "test_bench.py", "test_worker.py", "test_cloud.py", "test_control.py",
        "check_quote.py", "freeze.py",
    }
    manifest = {
        name: {"sha256": hashlib.sha256((cloud.ROOT / name).read_bytes()).hexdigest(),
               "bytes": (cloud.ROOT / name).stat().st_size}
        for name in sorted(names)
    }
    cloud.save("launch-manifest.json", manifest)
    controller.freeze_check()


if __name__ == "__main__":
    main()
