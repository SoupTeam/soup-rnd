"""Cheap policy controls; no cloud calls, tensors, subprocesses or real training."""

from __future__ import annotations

import json
import runpy
from pathlib import Path

import pytest


@pytest.fixture
def module():
    return runpy.run_path(str(Path(__file__).with_name("worker.py")))


@pytest.fixture
def worker(tmp_path, module):
    policy = {
        "created_unix": 0, "maximum_seconds": 28800, "maximum_usd": 10,
        "hourly_usd": 0.2, "up_usd_per_gb": 0.01, "down_usd_per_gb": 0.01,
        "cleanup_reserve_usd": 1, "prior_usd": 0.7651583321813147,
    }
    protocol = {"models": [{"config": {"num_hidden_layers": 8}, "weight_bytes": 100}],
                "pair_order": ["AB", "BA", "BA", "AB"],
                "observed_device_free_floor_bytes": 128 * 2**20}
    (tmp_path / "policy.json").write_text(json.dumps(policy))
    (tmp_path / "protocol.json").write_text(json.dumps(protocol))
    (tmp_path / "retention-policy.json").write_text(json.dumps({
        "encoded_bytes_per_second": 2 * 2**20, "local_free_bytes": 100 * 2**30,
    }))
    return module["Worker"](tmp_path)


def test_admission_guard_includes_prior_without_double_counting(worker, module):
    result = module["admission"](
        worker.policy, {"conservative_usd": 1},
        {"encoded_bytes_per_second": 2 * 2**20, "local_free_bytes": 100 * 2**30},
        now=0, seconds=60, encoded_bytes=2 * 2**20,
    )
    expected = 1 + 361 * 0.2 / 3600 + 2 * 2**20 / 1e9 * 0.01 + 1
    assert result["estimated_total_usd"] == expected
    assert result["admitted"]
    assert not result["donor_savings_assumed"]


@pytest.mark.parametrize("limit", ["money", "time", "local"])
def test_admission_refuses_resources_independently(worker, module, limit):
    guard = {"conservative_usd": 1 if limit != "money" else 9.99}
    retention = {"encoded_bytes_per_second": 2 * 2**20,
                 "local_free_bytes": 100 * 2**30 if limit != "local" else 1}
    result = module["admission"](
        worker.policy, guard, retention, now=28700 if limit == "time" else 0,
        seconds=60, encoded_bytes=2 * 2**20,
    )
    assert not result["admitted"]


def fake_matrix(worker, monkeypatch, capacity):
    events = []
    monkeypatch.setattr(worker, "prepare", lambda quant, source: events.append(("prepare", quant)))

    def screen_capacity(cohort, quant, source, count):
        events.append(("capacity", count))
        return capacity(count)

    def qualify(cohort, quant, source, count, reference=None):
        events.append(("accuracy", count))
        cohort.setdefault("qualified_counts", []).append(count)
        return worker.out / f"{quant}-{source}"

    def screen(cohort, quant, source, count):
        assert count in cohort["qualified_counts"]
        events.append(("speed", count))
        cohort.setdefault("selection_screens", {})[str(count)] = {"median_seconds": 10 - count}
        return 10 - count

    monkeypatch.setattr(worker, "capacity", screen_capacity)
    monkeypatch.setattr(worker, "qualify", qualify)
    monkeypatch.setattr(worker, "screen", screen)
    monkeypatch.setattr(worker, "bundle", lambda label: events.append(("ack", label)))
    return events


def test_dense_stops_at_first_capacity_failure_and_reuses_one_baseline(worker, monkeypatch):
    events = fake_matrix(worker, monkeypatch, lambda count: count <= 5)
    worker.dense()
    assert [count for action, count in events if action == "capacity"] == [0, 4, 5, 6]
    assert [count for action, count in events if action == "accuracy"] == [0, 4, 5]
    assert worker.summary["cohorts"]["none-ram"]["selected_count"] == 5
    first_speed = next(index for index, event in enumerate(events) if event[0] == "speed")
    assert all(event[0] != "accuracy" for event in events[first_speed:])


def test_nf4_capacity_refinement_does_not_capture_every_layer(worker, monkeypatch):
    worker.protocol["models"][0]["config"]["num_hidden_layers"] = 16
    events = fake_matrix(worker, monkeypatch, lambda count: count <= 10)
    worker.nf4()
    assert [count for action, count in events if action == "capacity"] == [0, 4, 8, 12, 9, 10, 11]
    assert [count for action, count in events if action == "accuracy"] == [0, 10]
    assert worker.summary["cohorts"]["nf4-ram"]["largest_screened_fit_count"] == 10


@pytest.mark.parametrize("failure", ["OOM", "cap_refusal", "free"])
def test_actual_capacity_classification_retains_before_stop(worker, monkeypatch, failure):
    events = []
    monkeypatch.setattr(worker, "stage", lambda *args, **kwargs: 0 if failure == "free" else 1)
    monkeypatch.setattr(worker, "info", lambda target: {
        "status": "COMPLETED_NOT_AN_INDEPENDENT_VERDICT",
        "capacity_failure": None if failure == "free" else failure,
        "device_free_min_bytes": 127 * 2**20,
    })
    monkeypatch.setattr(worker, "bundle", lambda label: events.append(label))
    cohort = {}
    assert not worker.capacity(cohort, "none", "ram", 6)
    assert events
    assert cohort["capacity_stop"]["count"] == 6


def test_noncapacity_error_never_becomes_a_fit_boundary(worker, monkeypatch, module):
    monkeypatch.setattr(worker, "stage", lambda *args, **kwargs: 1)
    monkeypatch.setattr(worker, "info", lambda target: {"status": "FAILED"})
    with pytest.raises(module["CohortError"], match="non-capacity"):
        worker.capacity({}, "none", "ram", 6)


def test_capture_ack_precedes_semantics_and_accuracy_bundle(worker, monkeypatch, module):
    events = []
    monkeypatch.setattr(worker, "stage", lambda name, *args, **kwargs: events.append(name) or 0)
    monkeypatch.setattr(worker, "bundle", lambda label: events.append("ACK:" + label) or {
        "archive_bytes": 100,
    })
    monkeypatch.setattr(worker, "info", lambda target: {})
    monkeypatch.setitem(module["Worker"].qualify.__globals__, "compare",
                        lambda *args: {"passed": True})
    cohort = {}
    worker.qualify(cohort, "none", "ram", 0)
    assert events == [
        "capture-none-ram-0", "ACK:capture-none-ram-0", "semantics-none-ram-0",
        "ACK:accuracy-none-ram-0",
    ]
    assert cohort["qualified_counts"] == [0]


def test_nf4_and_disk_are_not_gated_by_dense_speed(worker, monkeypatch):
    events = []
    monkeypatch.setattr(worker, "dense", lambda: events.append("dense-no-speed-gain"))
    monkeypatch.setattr(worker, "nf4", lambda: events.append("nf4"))
    monkeypatch.setattr(worker, "disk", lambda: events.append("disk"))
    monkeypatch.setattr(worker, "requested_heldout", lambda: [])
    worker.run()
    assert events == ["dense-no-speed-gain", "nf4", "disk"]
