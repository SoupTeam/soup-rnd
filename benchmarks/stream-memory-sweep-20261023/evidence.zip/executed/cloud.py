"""One live lease at a time, with an aggregate USD10 stage budget and exact ownership."""

import argparse
import base64
import hashlib
import http.client
import json
import math
import os
import re
import subprocess
import sys
import time
import urllib.error
import urllib.request
from contextlib import contextmanager
from pathlib import Path

from rich.console import Console

ROOT = Path(__file__).parent
STAGE = "soup-memory-impact-20261023"
LABEL = STAGE + "-c"
SSH_KEY = Path(r"C:\Users\esenb\.codex\tmp\soup-d2-vast-20261012\d2-ssh-20261012")
KEY_FILE = Path(r"C:\Users\esenb\.config\vastai\vast_api_key")
MAXIMUM_USD = 10.0
RESERVE_USD = 1.0
DISK_GB = 120
VOLUME_GB = 40
VOLUME_LABEL = "soup_memory_impact_20261023_c"
UNKNOWN_SETTLE_SECONDS = 120
QUERY = {
    "num_gpus": {"eq": 1},
    "gpu_ram": {"gte": 7900, "lte": 8300},
    "cpu_ram": {"gte": 64000},
    "disk_space": {"gte": DISK_GB},
    "rentable": {"eq": True},
    "rented": {"eq": False},
    "gpu_display_active": {"eq": False},
    "reliability": {"gte": 0.98},
    "cuda_max_good": {"gte": 12.8},
    "compute_cap": {"gte": 800},
    "type": "on-demand",
    "order": [["dph_total", "asc"]],
    "allocated_storage": DISK_GB,
    "limit": 100,
}


def save(name, value):
    target = ROOT / name
    temporary = target.with_name(f"{target.name}.{os.getpid()}.{time.time_ns()}.tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
    temporary.replace(target)


def digest(path):
    hashed = hashlib.sha256()
    with Path(path).open("rb") as source:
        for block in iter(lambda: source.read(8 * 2**20), b""):
            hashed.update(block)
    return hashed.hexdigest()


def api(path, method="GET", payload=None):
    readonly = method == "GET" or (method == "POST" and path in (
        "/api/v0/bundles/", "/api/v0/volumes/search/",
    ))
    key = KEY_FILE.read_text().strip()
    request = urllib.request.Request(
        "https://console.vast.ai" + path,
        method=method,
        data=json.dumps(payload).encode() if payload is not None else None,
        headers={"Authorization": "Bearer " + key, "Content-Type": "application/json"},
    )
    for attempt in range(3 if readonly else 1):
        try:
            with urllib.request.urlopen(request, timeout=30) as response:
                return json.load(response)
        except urllib.error.HTTPError as error:
            message = error.read().decode(errors="replace").replace(key, "[redacted]")[:500]
            if not readonly or error.code not in (429, 500, 502, 503, 504) or attempt == 2:
                raise RuntimeError(f"Vast HTTP status {error.code}: {message}") from None
        except (
            TimeoutError, urllib.error.URLError, http.client.IncompleteRead,
            ConnectionError, json.JSONDecodeError,
        ):
            if not readonly or attempt == 2:
                raise
        time.sleep(2**attempt)


def rows():
    import urllib.parse

    result, token = [], None
    while True:
        path = "/api/v1/instances/?limit=100"
        if token:
            path += "&after_token=" + urllib.parse.quote(token)
        reply = api(path)
        result.extend(reply["instances"])
        token = reply.get("next_token")
        if not token:
            return result


def offers():
    return api("/api/v0/bundles/", "POST", QUERY)["offers"]


def volume_rows():
    return api("/api/v0/volumes?owner=me&type=all_volume")["volumes"]


def volume_offers(machine_id):
    query = {
        "verified": {"eq": True}, "external": {"eq": False},
        "machine_id": {"eq": machine_id}, "disk_space": {"gte": VOLUME_GB},
        "allocated_storage": VOLUME_GB, "order": [["storage_cost", "asc"]], "limit": 100,
    }
    return api("/api/v0/volumes/search/", "POST", query)["offers"]


def resource_id(value):
    if isinstance(value, bool):
        raise TypeError("Boolean is not a resource ID")
    matched = re.fullmatch(r"(?:V\.)?([1-9][0-9]*)", str(value))
    if not matched:
        raise ValueError("Missing or invalid exact resource ID")
    return int(matched[1])


def volume_belongs(row, policy):
    if int(row.get("machine_id", -1)) != int(policy["machine_id"]):
        return False
    names = [row.get(key) for key in ("name", "label", "volume_label")]
    if any(name == VOLUME_LABEL for name in names):
        return True
    instances = row.get("instances") or []
    for instance in instances:
        identity = (instance.get("id", instance.get("instance_id"))
                    if isinstance(instance, dict) else instance)
        if str(identity) == str(policy.get("instance_id")) and identity is not None:
            return True
    return False


def reconcile(policy):
    """Adopt only the exact labelled instance and its proven associated volume."""
    all_instances, all_volumes = rows(), volume_rows()
    matched = [row for row in all_instances if row.get("label") == LABEL]
    if policy.get("instance_id") is None and len(matched) == 1:
        if int(matched[0].get("machine_id", -1)) != int(policy["machine_id"]):
            raise RuntimeError("Labelled instance is on an unexpected machine")
        policy["instance_id"] = resource_id(matched[0]["id"])
    elif policy.get("instance_id") is None and len(matched) > 1:
        raise RuntimeError("Ambiguous labelled instances; never guess ownership")
    matched_volumes = [row for row in all_volumes if volume_belongs(row, policy)]
    if policy.get("volume_id") is None and len(matched_volumes) == 1:
        policy["volume_id"] = resource_id(matched_volumes[0]["id"])
    elif policy.get("volume_id") is None and len(matched_volumes) > 1:
        raise RuntimeError("Ambiguous associated volumes; never guess ownership")
    save("vast-rental.json", policy)
    if policy.get("volume_id") is not None:
        save("vast-volume-rental.json", {
            "stage_id": STAGE, "label": VOLUME_LABEL, "volume_id": policy["volume_id"],
            "volume_ask_id": policy["volume_ask_id"], "machine_id": policy["machine_id"],
            "size_gb": VOLUME_GB, "created_unix": policy["created_unix"],
            "hourly_usd": policy["volume_hourly_usd"],
        })
    return policy, all_instances, all_volumes


def own_volume(policy=None):
    policy = policy or receipt()
    if policy.get("volume_id") is None:
        raise RuntimeError("Exact volume identity is not reconciled")
    row = next((item for item in volume_rows()
                if resource_id(item["id"]) == resource_id(policy["volume_id"])), None)
    if row is not None and int(row.get("machine_id", -1)) != int(policy["machine_id"]):
        raise RuntimeError("Exact volume identity has an unexpected machine")
    return row


def receipt():
    return json.loads((ROOT / "vast-rental.json").read_text())


def own():
    identity = receipt()["instance_id"]
    if identity is None:
        raise RuntimeError("Exact instance identity is not reconciled")
    row = next((item for item in rows() if resource_id(item["id"]) == resource_id(identity)), None)
    if row is not None and row.get("label") != LABEL:
        raise RuntimeError("Instance label differs from exact stage lease")
    return row


def ssh_args():
    connection = json.loads((ROOT / "vast-connection.json").read_text())
    return [
        "ssh", "-T", "-i", str(SSH_KEY), "-o", "BatchMode=yes", "-o",
        "StrictHostKeyChecking=accept-new", "-o", "ConnectTimeout=12", "-o",
        "ServerAliveInterval=15", "-o", "LogLevel=ERROR", "-p",
        str(connection["port"]), "root@" + connection["host"],
    ]


def ssh(command, timeout=40, stdin=None):
    return subprocess.run(
        ssh_args() + [command], stdin=stdin or subprocess.DEVNULL,
        capture_output=True, check=False, timeout=timeout,
    )


def quote(offer, seconds=28800, prior_usd=0.0, download_gb=100.0, upload_gb=24.0,
          volume_offer=None, volume_gb=VOLUME_GB):
    """Root dph_total includes root disk; a separate volume is added exactly once."""
    if seconds <= 0 or seconds > 8 * 3600:
        raise ValueError("Lease deadline must be >0 and <=8h")
    if not volume_offer or volume_gb != VOLUME_GB:
        raise ValueError("This stage requires an explicit matched 40 GB local-volume offer")
    if int(volume_offer["machine_id"]) != int(offer["machine_id"]):
        raise ValueError("Local volume must be on the exact GPU machine")
    if float(volume_offer["disk_space"]) < volume_gb:
        raise ValueError("Insufficient advertised local-volume space")
    expected = float(offer["dph_base"]) + DISK_GB * float(offer["storage_cost"]) / 720
    root_hourly = float(offer["dph_total"])
    if not math.isclose(root_hourly, expected, rel_tol=1e-6, abs_tol=1e-6):
        raise ValueError("Offer total/storage decomposition differs; refuse silent accounting")
    volume_hourly = volume_gb * float(volume_offer["storage_cost"]) / 720
    hourly = root_hourly + volume_hourly
    if not all(math.isfinite(value) and value >= 0 for value in (
        root_hourly, volume_hourly, prior_usd, download_gb, upload_gb,
        float(offer["inet_down_cost"]), float(offer["inet_up_cost"]),
    )):
        raise ValueError("Nonfinite or negative quote input")
    compute_disk = (seconds + 180) * hourly / 3600
    network = download_gb * offer["inet_down_cost"] + upload_gb * offer["inet_up_cost"]
    return {
        "hourly_including_requested_disk_usd": hourly,
        "instance_hourly_including_root_disk_usd": root_hourly,
        "volume_hourly_usd": volume_hourly,
        "local_volume_ask_id": resource_id(volume_offer["id"]),
        "local_volume_gb": volume_gb,
        "storage_already_included": True,
        "allocated_disk_gb": DISK_GB,
        "maximum_seconds": seconds,
        "prior_stage_usd": prior_usd,
        "time_storage_allowance_usd": compute_disk,
        "network_allowance_usd": network,
        "download_allowance_decimal_gb": download_gb,
        "upload_allowance_decimal_gb": upload_gb,
        "cleanup_transfer_reserve_usd": RESERVE_USD,
        "unobserved_network_reserve_usd": 0.25,
        "total_stage_admission_usd": prior_usd + compute_disk + network + RESERVE_USD + 0.25,
        "maximum_stage_usd": MAXIMUM_USD,
    }


def status():
    row = own()
    if row and row.get("ports", {}).get("22/tcp"):
        save("vast-connection.json", {
            "host": row["public_ipaddr"], "port": row["ports"]["22/tcp"][0]["HostPort"],
        })
    safe = {k: row.get(k) for k in (
        "id", "label", "actual_status", "status_msg", "gpu_name", "dph_total",
        "start_date", "disk_space", "cpu_ram",
    )} if row else {"absent": True}
    safe["ssh_port_ready"] = bool(row and row.get("ports", {}).get("22/tcp"))
    save("vast-status.json", safe)
    return safe


def prior_stage_cost():
    ledger = ROOT / "stage-ledger.json"
    if not ledger.exists():
        return 0.0
    data = json.loads(ledger.read_text())
    if data["stage_id"] != STAGE or data["maximum_stage_usd"] != MAXIMUM_USD:
        raise RuntimeError("Stage ledger identity/cap mismatch")
    if any(not entry["verified_absent"] for entry in data["completed_leases"]):
        raise RuntimeError("Earlier lease deletion is not verified")
    if any(entry.get("volume_id") is not None and not entry.get("volume_verified_absent")
           for entry in data["completed_leases"]):
        raise RuntimeError("Earlier persistent volume deletion is not verified")
    return sum(float(entry["conservative_usd"]) for entry in data["completed_leases"])


def allocate(args):
    if args.seconds <= 0 or args.seconds > 8 * 3600:
        raise ValueError("This prospective run requires a deadline >0 and <=8h")
    if (ROOT / "vast-rental.json").exists():
        raise RuntimeError("Existing receipt: never rerun allocation or overwrite receipts")
    if rows() or volume_rows():
        raise RuntimeError("Account must have no instances or owned volumes before allocation")
    # A root-created explicit approval marker prevents accidental execution during preflight.
    approval = ROOT / "lease-greenlight.json"
    if not approval.exists():
        raise RuntimeError("Missing root lease greenlight; preflight does not authorize allocation")
    approved = json.loads(approval.read_text())
    expected_approval = {
        "stage_id": STAGE, "offer_id": args.offer_id,
        "volume_ask_id": args.volume_ask_id, "volume_gb": VOLUME_GB,
        "maximum_stage_usd": MAXIMUM_USD,
    }
    if approved != expected_approval:
        raise RuntimeError("Lease greenlight must match stage, GPU ask, volume ask, size and cap")
    offer = next((item for item in offers() if item["id"] == args.offer_id), None)
    if offer is None:
        raise RuntimeError("Chosen offer is no longer rentable with the requested resources")
    volume_offer = next((item for item in volume_offers(offer["machine_id"])
                         if resource_id(item["id"]) == args.volume_ask_id), None)
    if volume_offer is None:
        raise RuntimeError("Explicit local-volume ask is no longer available on this GPU machine")
    prior = prior_stage_cost()
    plan = quote(offer, seconds=args.seconds, prior_usd=prior, volume_offer=volume_offer)
    credit = float(api("/api/v0/users/current/")["credit"])
    if plan["total_stage_admission_usd"] > min(MAXIMUM_USD, credit):
        raise RuntimeError("Lease and complete setup/network/recovery allowance exceed stage cap")
    for name in ("source.tar.gz", "remote_guard.py", "preflight_remote.py", "setup.sh"):
        if not (ROOT / name).is_file():
            raise RuntimeError("Root must prepare/verify exact source and setup before rental")
    policy = {
        "stage_id": STAGE, "label": LABEL, "maximum_usd": MAXIMUM_USD,
        "prior_usd": prior, "cleanup_reserve_usd": RESERVE_USD,
        "unobserved_network_reserve_usd": 0.25,
        "maximum_seconds": args.seconds, "created_unix": time.time(),
        "hourly_usd": plan["hourly_including_requested_disk_usd"],
        "down_usd_per_gb": offer["inet_down_cost"],
        "up_usd_per_gb": offer["inet_up_cost"],
        "source_sha256": digest(ROOT / "source.tar.gz"),
        "allocated_disk_gb": DISK_GB,
        "machine_id": resource_id(offer["machine_id"]),
        "instance_offer_id": resource_id(offer["id"]),
        "instance_hourly_usd": plan["instance_hourly_including_root_disk_usd"],
        "volume_ask_id": resource_id(volume_offer["id"]), "volume_size_gb": VOLUME_GB,
        "volume_hourly_usd": plan["volume_hourly_usd"],
        "volume_mount_path": "/data", "volume_label": VOLUME_LABEL,
        "instance_id": None, "volume_id": None, "creation_state": "pending",
    }
    encoded = base64.b64encode(json.dumps(policy).encode()).decode()
    guard = base64.b64encode((ROOT / "remote_guard.py").read_bytes()).decode()
    onstart = (
        "mkdir -p /root/liger/results\necho " + encoded
        + " | base64 -d > /root/liger/policy.json\necho " + guard
        + " | base64 -d > /root/liger/remote_guard.py\n"
        + "nohup python3 /root/liger/remote_guard.py > /root/liger/guard.log 2>&1 < /dev/null &\n"
        + "entrypoint.sh"
    )
    save("vast-selected-offer.json", offer)
    save("admission-plan.json", plan)
    save("vast-allocation-intent.json", policy)
    # A pending receipt prevents blind retries even after a timeout or controller crash.
    save("vast-rental.json", policy)
    start_local_guard()
    try:
        response = api(f"/api/v0/asks/{offer['id']}/", "PUT", {
            "client_id": "me", "image": "vastai/base-image:cuda-12.9-mini-py312-2026-09-07",
            "disk": DISK_GB, "runtype": "ssh_direc ssh_proxy", "cancel_unavail": True,
            "label": LABEL, "onstart": onstart, "env": {}, "price": None,
            "force": False, "template_hash_id": None,
            "volume_info": {
                "mount_path": "/data", "create_new": True,
                "volume_id": policy["volume_ask_id"], "size": VOLUME_GB,
                "name": VOLUME_LABEL,
            },
        })
        save("creation-response.json", {
            k: response[k] for k in ("success", "new_contract", "msg", "error") if k in response
        })
        if not response.get("success") or not response.get("new_contract"):
            raise RuntimeError("Creation not confirmed")
        policy["instance_id"] = resource_id(response["new_contract"])
        policy["creation_state"] = "confirmed"
    except Exception as error:  # noqa: BLE001 -- Any uncertain create must retain its receipt/guardian.
        save("creation-error.json", {"error": str(error), "unix": time.time()})
        policy["creation_state"] = "unknown"
    policy["creation_request_finished_unix"] = time.time()
    save("vast-rental.json", policy)
    for _ in range(12):
        policy, _, _ = reconcile(policy)
        if policy.get("instance_id") is not None and policy.get("volume_id") is not None:
            policy["creation_state"] = "reconciled"
            save("vast-rental.json", policy)
            Console().print(policy)
            return
        time.sleep(2)
    raise RuntimeError(
        "Creation pair not reconciled; no retry or training. Exact pending receipt and guard remain"
    )


def start_local_guard():
    with (ROOT / "local-guard.log").open("w") as log:
        guard_process = subprocess.Popen(
            [sys.executable, str(__file__), "guard"],
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
        )
    save("vast-local-guard.json", {"pid": guard_process.pid})


@contextmanager
def cleanup_lock():
    """Serialize independent controller/guardian cleanup; OS unlocks on process death."""
    with (ROOT / "cleanup.lock").open("a+b") as handle:
        if handle.tell() == 0:
            handle.write(b"0")
            handle.flush()
        if os.name == "nt":
            import msvcrt

            def acquire():
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)

            def release():
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl

            def acquire():
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)

            def release():
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        while True:
            try:
                acquire()
                break
            except OSError:
                time.sleep(1)
        try:
            yield
        finally:
            release()


def finalize_deletion(policy, reason):
    """Called only after independent list queries prove BOTH resources absent."""
    identity, volume_identity = policy["instance_id"], policy.get("volume_id")
    if (ROOT / "vast-finished").exists():
        return
    elapsed = max(0.0, time.time() - policy["created_unix"])
    recorded = ROOT / "guard-status-latest.json"
    conservative = policy["prior_usd"] + (elapsed + 180) * policy["hourly_usd"] / 3600
    conservative += policy["unobserved_network_reserve_usd"]
    if recorded.exists():
        telemetry = json.loads(recorded.read_text())
        if str(telemetry.get("instance_id")) != str(identity):
            raise RuntimeError("Final guard telemetry has a different instance ID")
        conservative += telemetry["rx_bytes"] / 1e9 * policy["down_usd_per_gb"]
        conservative += telemetry["tx_bytes"] / 1e9 * policy["up_usd_per_gb"]
    else:
        # Missing runtime telemetry retains the full prospective traffic allowance.
        plan = json.loads((ROOT / "admission-plan.json").read_text())
        conservative += plan["network_allowance_usd"]
    entry = {
        "instance_id": identity, "volume_id": volume_identity, "label": LABEL,
        "verified_absent": True, "volume_verified_absent": True,
        "conservative_usd": conservative - policy["prior_usd"],
        "elapsed_seconds": elapsed, "actual_network_telemetry_retained": recorded.exists(),
    }
    ledger = ROOT / "stage-ledger.json"
    entries = json.loads(ledger.read_text())["completed_leases"] if ledger.exists() else []
    previous = next((item for item in entries if item["instance_id"] == identity
                     and (identity is not None or item.get("label") == LABEL)), None)
    if previous is None:
        entries.append(entry)
    elif entry["conservative_usd"] > previous["conservative_usd"]:
        entries[entries.index(previous)] = entry
    save("stage-ledger.json", {
        "stage_id": STAGE, "maximum_stage_usd": MAXIMUM_USD, "completed_leases": entries,
    })
    save("vast-deletion.json", {
        "instance_id": identity, "volume_id": volume_identity,
        "verified_absent": True, "volume_verified_absent": True,
        "volume_absence_scope": "exact ID" if volume_identity else "no account-owned volumes",
        "unix": time.time(), "reason": reason,
    })
    save("vast-volume-deletion.json", {
        "volume_id": volume_identity, "verified_absent": True, "unix": time.time(),
    })
    (ROOT / "vast-finished").touch()


def destroy(reason):
    with cleanup_lock():
        return destroy_locked(reason)


def destroy_locked(reason):
    policy = receipt()
    last = ""
    for attempt in range(30):
        try:
            policy, instances, volumes = reconcile(policy)
            identity, volume_identity = policy.get("instance_id"), policy.get("volume_id")
            volume = next((row for row in volumes if volume_identity is not None
                           and resource_id(row["id"]) == resource_id(volume_identity)), None)
            if identity is None:
                if volume is not None:
                    if int(volume.get("machine_id", -1)) != int(policy["machine_id"]):
                        raise RuntimeError("Exact orphan volume is on a different machine")
                    if volume.get("instances") != []:
                        raise RuntimeError("Orphan volume still has an instance association")
                    api("/api/v0/volumes", "DELETE", {"id": resource_id(volume_identity)})
                    policy.pop("unknown_empty_since_unix", None)
                    policy["unknown_empty_confirmations"] = 0
                    save("vast-rental.json", policy)
                    time.sleep(5)
                    continue
                if instances or volumes:
                    policy.pop("unknown_empty_since_unix", None)
                    policy["unknown_empty_confirmations"] = 0
                    save("vast-rental.json", policy)
                    raise RuntimeError("Unknown creation has account resources; refuse guessing")
                now = time.time()
                policy.setdefault("unknown_empty_since_unix", now)
                policy["unknown_empty_confirmations"] = (
                    policy.get("unknown_empty_confirmations", 0) + 1
                )
                save("vast-rental.json", policy)
                request_end = policy.get("creation_request_finished_unix", policy["created_unix"])
                if (now - request_end >= UNKNOWN_SETTLE_SECONDS
                        and now - policy["unknown_empty_since_unix"] >= 10
                        and policy["unknown_empty_confirmations"] >= 3):
                    finalize_deletion(policy, reason + "; empty unknown outcome settled")
                    return
                raise RuntimeError("Unknown empty outcome; waiting for fresh settled listings")
            instance = next((row for row in instances
                             if resource_id(row["id"]) == resource_id(identity)), None)
            if instance is not None:
                if instance.get("label") != LABEL:
                    raise RuntimeError("Instance label differs; refuse deleting a foreign resource")
                if int(instance.get("machine_id", -1)) != int(policy["machine_id"]):
                    raise RuntimeError("Exact instance is on a different machine")
                api(f"/api/v0/instances/{identity}/", "DELETE", {})
            else:
                # A volume can only be removed AFTER a fresh query proves instance absence.
                if volume_identity is None and volumes:
                    raise RuntimeError("Volume identity unresolved; owned volumes still present")
                if volume is not None:
                    if int(volume.get("machine_id", -1)) != int(policy["machine_id"]):
                        raise RuntimeError("Exact volume is on a different machine")
                    api("/api/v0/volumes", "DELETE", {"id": resource_id(volume_identity)})
                else:
                    finalize_deletion(policy, reason)
                    return
        except Exception as error:  # noqa: BLE001 -- Cleanup failures must not disable the guardian.
            last = str(error)
            save("vast-cleanup-retry.json", {"attempt": attempt, "error": last})
        time.sleep(5)
    raise RuntimeError("Pair deletion unverified; exact resource guardian remains active: " + last)


def guard():
    while not (ROOT / "vast-finished").exists():
        try:
            policy = receipt()
            elapsed = time.time() - policy["created_unix"]
            if policy.get("creation_state") == "pending" and elapsed < 300:
                time.sleep(5)
                continue
            if elapsed >= policy["maximum_seconds"]:
                destroy("independent local maximum lease time, including persistent volume")
                return
            if policy.get("creation_state") in ("pending", "unknown"):
                destroy("independent guardian reconciles an uncertain creation outcome")
                return
            # Recover the persistent volume promptly when the remote guard deletes its container.
            if own() is None:
                destroy("independent local cleanup after remote instance disappearance")
                return
            plan = json.loads((ROOT / "admission-plan.json").read_text())
            cost = policy["prior_usd"] + (elapsed + 180) * policy["hourly_usd"] / 3600
            cost += policy["unobserved_network_reserve_usd"]
            network = plan["network_allowance_usd"]
            telemetry = ROOT / "guard-status-latest.json"
            if telemetry.exists():
                row = json.loads(telemetry.read_text())
                if str(row.get("instance_id")) == str(policy["instance_id"]):
                    observed = row["rx_bytes"] / 1e9 * policy["down_usd_per_gb"]
                    observed += row["tx_bytes"] / 1e9 * policy["up_usd_per_gb"]
                    network = max(network, observed)
            if cost + network >= MAXIMUM_USD - RESERVE_USD:
                destroy("independent local aggregate money boundary, including persistent volume")
                return
        except Exception as error:  # noqa: BLE001 -- Independent guardian must survive telemetry errors.
            save("local-guard-retry.json", {"error": str(error), "unix": time.time()})
        time.sleep(5)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="action", required=True)
    sub.add_parser("preflight")
    sub.add_parser("status")
    sub.add_parser("guard")
    sub.add_parser("delete")
    lease = sub.add_parser("allocate")
    lease.add_argument("--offer-id", type=int, required=True)
    lease.add_argument("--volume-ask-id", type=int, required=True)
    lease.add_argument("--seconds", type=int, default=28800)
    remote = sub.add_parser("ssh")
    remote.add_argument("command")
    remote.add_argument("--timeout", type=int, default=40)
    args = parser.parse_args()
    if args.action == "preflight":
        keys = (
            "id", "gpu_name", "gpu_ram", "cpu_ram", "disk_name", "disk_bw", "disk_space",
            "dph_base", "dph_total", "storage_cost", "storage_total_cost", "inet_down_cost",
            "inet_up_cost", "reliability", "verification", "gpu_display_active", "cuda_max_good",
            "machine_id", "avail_vol_ask_id", "avail_vol_dph", "avail_vol_size", "vms_enabled",
        )
        safe_offers = [{k: row.get(k) for k in keys} for row in offers()]
        result = {
            "stage_id": STAGE, "unix": time.time(), "maximum_stage_usd": MAXIMUM_USD,
            "credit_usd": api("/api/v0/users/current/")["credit"],
            "account_instances": [
                {k: row.get(k) for k in ("id", "label", "actual_status", "gpu_name")}
                for row in rows()
            ],
            "owned_volumes": [
                {k: row.get(k) for k in ("id", "machine_id", "name", "label", "disk_space")}
                for row in volume_rows()
            ],
            "allocated_storage_gb": DISK_GB, "offers": safe_offers,
            "local_disk_free_gib": __import__("shutil").disk_usage(ROOT).free / 2**30,
            "rental_started": False,
        }
        save("read-only-preflight.json", result)
        Console().print(result)
    elif args.action == "allocate":
        if args.seconds <= 0 or args.seconds > 8 * 3600:
            raise ValueError("Explicit lease deadline must be >0 and <=8h")
        allocate(args)
    elif args.action == "status":
        Console().print(status())
    elif args.action == "guard":
        guard()
    elif args.action == "delete":
        destroy("operator cleanup after verified result retention")
    elif args.action == "ssh":
        result = ssh(args.command, args.timeout)
        Console().print(result.stdout.decode(errors="replace"), end="", markup=False)
        if result.stderr:
            Console(stderr=True).print(result.stderr.decode(errors="replace"), end="", markup=False)
        raise SystemExit(result.returncode)


if __name__ == "__main__":
    main()
