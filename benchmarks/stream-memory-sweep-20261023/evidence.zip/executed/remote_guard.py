"""Self-delete exact container with its instance-scoped credential, no account key."""

import json
import os
import time
import urllib.request
from pathlib import Path

ROOT = Path("/root/liger")
POLICY = json.loads((ROOT / "policy.json").read_text())
IDENTITY = os.environ["CONTAINER_ID"]
INSTANCE_KEY = os.environ["CONTAINER_API_KEY"]


def network_bytes():
    received, transmitted = 0, 0
    for line in Path("/proc/net/dev").read_text().splitlines():
        if ":" in line and line.split(":")[0].strip() != "lo":
            fields = line.split(":")[1].split()
            received += int(fields[0])
            transmitted += int(fields[8])
    return received, transmitted


def main():
    reason = "guard telemetry failure"
    try:
        while True:
            elapsed = time.time() - POLICY["created_unix"]
            received, transmitted = network_bytes()
            cost = POLICY["prior_usd"] + (elapsed + 180) * POLICY["hourly_usd"] / 3600
            cost += POLICY["unobserved_network_reserve_usd"]
            cost += received / 1e9 * POLICY["down_usd_per_gb"]
            cost += transmitted / 1e9 * POLICY["up_usd_per_gb"]
            row = {
                "instance_id": IDENTITY, "elapsed_seconds": elapsed,
                "conservative_usd": cost, "rx_bytes": received,
                "tx_bytes": transmitted, "unix": time.time(),
            }
            temporary = ROOT / "guard-status.tmp"
            temporary.write_text(json.dumps(row))
            temporary.replace(ROOT / "guard-status.json")
            if elapsed >= POLICY["maximum_seconds"]:
                reason = "lease time boundary"
                break
            if cost >= POLICY["maximum_usd"] - POLICY["cleanup_reserve_usd"]:
                reason = "aggregate stage dollar boundary, cleanup reserve preserved"
                break
            if (ROOT / "delete-now").exists():
                reason = "operator exact-container deletion request"
                break
            time.sleep(5)
    except Exception:
        pass
    (ROOT / "guard-deletion.json").write_text(json.dumps({"reason": reason}))
    request = urllib.request.Request(
        f"https://console.vast.ai/api/v0/instances/{IDENTITY}/", method="DELETE", data=b"{}",
        headers={"Authorization": "Bearer " + INSTANCE_KEY, "Content-Type": "application/json"},
    )
    for _ in range(24):
        try:
            with urllib.request.urlopen(request, timeout=15) as response:
                if json.load(response).get("success"):
                    return
        except Exception:
            pass
        time.sleep(5)


if __name__ == "__main__":
    main()
