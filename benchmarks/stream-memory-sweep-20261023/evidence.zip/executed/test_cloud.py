"""No-network acceptance tests for paired instance/local-volume lifecycle."""

import json
from types import SimpleNamespace

import pytest

import cloud


@pytest.fixture(autouse=True)
def isolated(monkeypatch, tmp_path):
    monkeypatch.setattr(cloud, "ROOT", tmp_path)
    monkeypatch.setattr(cloud.time, "time", lambda: 1000.0)
    monkeypatch.setattr(cloud.time, "sleep", lambda _: None)

    def unexpected(*args, **kwargs):
        raise AssertionError("A test attempted an unmocked cloud call")

    monkeypatch.setattr(cloud, "api", unexpected)


@pytest.fixture
def offer():
    return {
        "id": 11, "machine_id": 7, "dph_base": 0.14666666666666667,
        "storage_cost": 1 / 3, "dph_total": 0.20222222222222222,
        "inet_down_cost": 0.0390625, "inet_up_cost": 0.0390625,
    }


@pytest.fixture
def volume_offer():
    return {"id": 22, "machine_id": 7, "disk_space": 495, "storage_cost": 0.2}


@pytest.fixture
def policy():
    return {
        "stage_id": cloud.STAGE, "label": cloud.LABEL, "instance_id": 101,
        "volume_id": 201, "volume_ask_id": 22, "machine_id": 7,
        "volume_hourly_usd": 1 / 90, "instance_hourly_usd": 0.20222222222222222,
        "hourly_usd": 0.21333333333333332, "created_unix": 900,
        "maximum_seconds": 28800, "prior_usd": 0.7651583321813147,
        "unobserved_network_reserve_usd": 0.25, "down_usd_per_gb": 0.0390625,
        "up_usd_per_gb": 0.0390625, "creation_state": "reconciled",
    }


class FakeCloud:
    def __init__(self, offer, volume_offer):
        self.offer, self.volume_offer = offer, volume_offer
        self.instances, self.volumes, self.calls = [], [], []
        self.create_timeout = False
        self.volume_delete_error = False
        self.create_resources = True
        self.duplicate_volume = False

    def create(self):
        self.instances = [{"id": 101, "label": cloud.LABEL, "machine_id": 7}]
        self.volumes = [{"id": 201, "machine_id": 7, "instances": [{"id": 101}]}]
        if self.duplicate_volume:
            self.volumes.append({"id": 202, "machine_id": 7, "name": cloud.VOLUME_LABEL})

    def __call__(self, path, method="GET", payload=None):
        self.calls.append((path, method, payload))
        if path.startswith("/api/v1/instances/"):
            return {"instances": list(self.instances)}
        if path.startswith("/api/v0/volumes?owner="):
            return {"volumes": list(self.volumes)}
        if path == "/api/v0/bundles/" and method == "POST":
            return {"offers": [self.offer]}
        if path == "/api/v0/volumes/search/" and method == "POST":
            return {"offers": [self.volume_offer] if self.volume_offer else []}
        if path == "/api/v0/users/current/":
            return {"credit": 20}
        if path == "/api/v0/asks/11/" and method == "PUT":
            assert (cloud.ROOT / "vast-rental.json").exists()
            assert (cloud.ROOT / "guard-started-test").exists()
            if self.create_resources:
                self.create()
            if self.create_timeout:
                raise TimeoutError("Ambiguous provider timeout")
            return {"success": True, "new_contract": 101}
        if path == "/api/v0/instances/101/" and method == "DELETE":
            self.instances.clear()
            return {"success": True}
        if path == "/api/v0/volumes" and method == "DELETE":
            assert not self.instances, "Volume DELETE preceded confirmed instance absence"
            assert payload == {"id": 201}
            if self.volume_delete_error:
                raise RuntimeError("Provider volume delete failure")
            self.volumes.clear()
            return {"success": True}
        raise AssertionError(f"Unexpected mocked request: {method} {path}")


@pytest.fixture
def fake(monkeypatch, offer, volume_offer):
    provider = FakeCloud(offer, volume_offer)
    monkeypatch.setattr(cloud, "api", provider)
    return provider


def prepare_allocate(monkeypatch):
    for name in ("source.tar.gz", "remote_guard.py", "preflight_remote.py", "setup.sh"):
        (cloud.ROOT / name).write_bytes(b"frozen source")
    cloud.save("lease-greenlight.json", {
        "stage_id": cloud.STAGE, "offer_id": 11, "volume_ask_id": 22,
        "volume_gb": 40, "maximum_stage_usd": 10,
    })
    cloud.save("stage-ledger.json", {
        "stage_id": cloud.STAGE, "maximum_stage_usd": 10,
        "completed_leases": [{"instance_id": 1, "verified_absent": True,
                              "conservative_usd": 0.7651583321813147}],
    })

    def start_guard():
        pending = cloud.receipt()
        assert pending["instance_id"] is None
        assert pending["volume_id"] is None
        assert pending["creation_state"] == "pending"
        (cloud.ROOT / "guard-started-test").touch()

    monkeypatch.setattr(cloud, "start_local_guard", start_guard)
    return SimpleNamespace(offer_id=11, volume_ask_id=22, seconds=28800)


def prepare_cleanup(policy):
    cloud.save("vast-rental.json", policy)
    cloud.save("admission-plan.json", {"network_allowance_usd": 4.375})


def test_quote_adds_separate_volume_once_and_keeps_prior_and_reserves(offer, volume_offer):
    plan = cloud.quote(offer, prior_usd=0.7651583321813147, volume_offer=volume_offer)
    assert plan["instance_hourly_including_root_disk_usd"] == pytest.approx(0.20222222222222222)
    assert plan["volume_hourly_usd"] == pytest.approx(40 * 0.2 / 720)
    assert plan["hourly_including_requested_disk_usd"] == pytest.approx(0.21333333333333332)
    assert plan["total_stage_admission_usd"] == pytest.approx(8.576241665514647)
    assert plan["upload_allowance_decimal_gb"] == 24
    assert plan["cleanup_transfer_reserve_usd"] == 1


@pytest.mark.parametrize("mutation", ["machine", "size", "negative", "nan", "root_total"])
def test_quote_refuses_invalid_or_inconsistent_accounting(offer, volume_offer, mutation):
    if mutation == "machine":
        volume_offer["machine_id"] = 8
    elif mutation == "size":
        volume_offer["disk_space"] = 39
    elif mutation == "negative":
        volume_offer["storage_cost"] = -0.1
    elif mutation == "nan":
        offer["inet_down_cost"] = float("nan")
    else:
        offer["dph_total"] += 0.1
    with pytest.raises(ValueError):
        cloud.quote(offer, volume_offer=volume_offer)


def test_quote_requires_explicit_volume_offer(offer):
    with pytest.raises(ValueError, match="explicit matched"):
        cloud.quote(offer)


def test_allocate_atomically_receipts_and_guards_both_resources(monkeypatch, fake):
    args = prepare_allocate(monkeypatch)
    cloud.allocate(args)
    receipt = cloud.receipt()
    assert (receipt["instance_id"], receipt["volume_id"]) == (101, 201)
    assert receipt["hourly_usd"] == pytest.approx(0.21333333333333332)
    assert receipt["creation_state"] == "reconciled"
    request = next(payload for path, method, payload in fake.calls
                   if path == "/api/v0/asks/11/" and method == "PUT")
    assert request["volume_info"] == {
        "mount_path": "/data", "create_new": True, "volume_id": 22,
        "size": 40, "name": cloud.VOLUME_LABEL,
    }
    assert json.loads((cloud.ROOT / "vast-volume-rental.json").read_text())["volume_id"] == 201
    assert "Bearer" not in request["onstart"]


def test_ambiguous_timeout_reconciles_once_without_second_creation(monkeypatch, fake):
    args = prepare_allocate(monkeypatch)
    fake.create_timeout = True
    cloud.allocate(args)
    assert cloud.receipt()["volume_id"] == 201
    assert sum(method == "PUT" for _, method, _ in fake.calls) == 1


def test_unknown_outcome_retains_receipt_without_retry_or_false_finished(monkeypatch, fake):
    args = prepare_allocate(monkeypatch)
    fake.create_timeout, fake.create_resources = True, False
    with pytest.raises(RuntimeError, match="not reconciled"):
        cloud.allocate(args)
    assert cloud.receipt()["creation_state"] == "unknown"
    assert sum(method == "PUT" for _, method, _ in fake.calls) == 1
    assert not (cloud.ROOT / "vast-finished").exists()
    with pytest.raises(RuntimeError, match="Existing receipt"):
        cloud.allocate(args)


def test_ambiguous_volume_candidates_are_not_adopted(monkeypatch, fake):
    args = prepare_allocate(monkeypatch)
    fake.duplicate_volume = True
    with pytest.raises(RuntimeError, match="Ambiguous associated"):
        cloud.allocate(args)
    assert cloud.receipt()["volume_id"] is None
    assert not (cloud.ROOT / "vast-finished").exists()


def test_missing_fresh_volume_ask_prevents_any_creation(monkeypatch, fake):
    args = prepare_allocate(monkeypatch)
    fake.volume_offer = None
    with pytest.raises(RuntimeError, match="no longer available"):
        cloud.allocate(args)
    assert not any(method == "PUT" for _, method, _ in fake.calls)


@pytest.mark.parametrize("existing", ["instance", "volume"])
def test_existing_account_resource_blocks_new_lease(monkeypatch, fake, existing):
    args = prepare_allocate(monkeypatch)
    if existing == "instance":
        fake.instances = [{"id": 999}]
    else:
        fake.volumes = [{"id": 999}]
    with pytest.raises(RuntimeError, match="no instances or owned volumes"):
        cloud.allocate(args)
    assert not any(method == "PUT" for _, method, _ in fake.calls)


def test_greenlight_requires_exact_volume_ask_and_size(monkeypatch, fake):
    args = prepare_allocate(monkeypatch)
    approval = json.loads((cloud.ROOT / "lease-greenlight.json").read_text())
    approval["volume_ask_id"] = 999
    cloud.save("lease-greenlight.json", approval)
    with pytest.raises(RuntimeError, match="greenlight must match"):
        cloud.allocate(args)
    assert not any(method == "PUT" for _, method, _ in fake.calls)


def test_cleanup_deletes_in_order_and_proves_both_absent_before_finished(fake, policy):
    fake.create()
    prepare_cleanup(policy)
    cloud.destroy("test")
    deletes = [(path, payload) for path, method, payload in fake.calls if method == "DELETE"]
    assert deletes == [("/api/v0/instances/101/", {}), ("/api/v0/volumes", {"id": 201})]
    assert not fake.instances and not fake.volumes
    entry = json.loads((cloud.ROOT / "stage-ledger.json").read_text())["completed_leases"][0]
    assert entry["volume_id"] == 201 and entry["volume_verified_absent"]
    assert (cloud.ROOT / "vast-finished").exists()
    before = (cloud.ROOT / "stage-ledger.json").read_bytes()
    cloud.destroy("idempotent")
    assert (cloud.ROOT / "stage-ledger.json").read_bytes() == before


def test_remote_self_deletion_does_not_leave_persistent_volume(fake, policy):
    fake.create()
    fake.instances.clear()
    prepare_cleanup(policy)
    cloud.guard()
    assert not fake.volumes
    assert (cloud.ROOT / "vast-finished").exists()
    assert not any(path.startswith("/api/v0/instances/") and method == "DELETE"
                   for path, method, _ in fake.calls)


def test_volume_delete_failure_never_marks_finished_or_ledger(fake, policy):
    fake.create()
    fake.volume_delete_error = True
    prepare_cleanup(policy)
    with pytest.raises(RuntimeError, match="Pair deletion unverified"):
        cloud.destroy("test")
    assert not fake.instances and fake.volumes
    assert not (cloud.ROOT / "vast-finished").exists()
    assert not (cloud.ROOT / "stage-ledger.json").exists()


@pytest.mark.parametrize("foreign", ["instance_label", "volume_machine"])
def test_cleanup_refuses_foreign_resource_identity(fake, policy, foreign):
    fake.create()
    if foreign == "instance_label":
        fake.instances[0]["label"] = "foreign"
    else:
        fake.instances.clear()
        fake.volumes[0]["machine_id"] = 8
    prepare_cleanup(policy)
    with pytest.raises(RuntimeError, match="Pair deletion unverified"):
        cloud.destroy("test")
    assert not any(method == "DELETE" for _, method, _ in fake.calls)
    assert not (cloud.ROOT / "vast-finished").exists()


def test_missing_telemetry_keeps_full_network_allowance(fake, policy):
    fake.create()
    fake.instances.clear()
    fake.volumes.clear()
    prepare_cleanup(policy)
    cloud.destroy("test")
    entry = json.loads((cloud.ROOT / "stage-ledger.json").read_text())["completed_leases"][0]
    expected = 280 * policy["hourly_usd"] / 3600 + 0.25 + 4.375
    assert entry["conservative_usd"] == pytest.approx(expected)


def test_resource_id_is_exact_and_rejects_ambiguous_forms():
    assert cloud.resource_id("V.201") == 201
    for invalid in (None, True, "V.201/", "-1", "0", "201.0"):
        with pytest.raises((ValueError, TypeError)):
            cloud.resource_id(invalid)


def test_prefixed_live_volume_is_deleted_before_finalizing(fake, policy):
    fake.create()
    fake.instances.clear()
    fake.volumes[0]["id"] = "V.201"
    prepare_cleanup(policy)
    cloud.destroy("prefix regression")
    assert not fake.volumes
    assert any(path == "/api/v0/volumes" and method == "DELETE"
               for path, method, _ in fake.calls)
    assert (cloud.ROOT / "vast-finished").exists()


def ticking_clock(monkeypatch):
    current = {"now": 1000.0}
    monkeypatch.setattr(cloud.time, "time", lambda: current["now"])
    monkeypatch.setattr(cloud.time, "sleep", lambda seconds: current.update(
        now=current["now"] + seconds))
    return current


def test_known_unattached_orphan_volume_is_removed_then_unknown_settles(
        monkeypatch, fake, policy):
    current = ticking_clock(monkeypatch)
    policy.update(instance_id=None, creation_state="unknown", creation_request_finished_unix=1000)
    fake.volumes = [{"id": "V.201", "machine_id": 7, "name": cloud.VOLUME_LABEL,
                     "instances": []}]
    prepare_cleanup(policy)
    cloud.destroy("partial atomic failure")
    assert not fake.volumes
    assert current["now"] >= 1000 + cloud.UNKNOWN_SETTLE_SECONDS
    assert (cloud.ROOT / "vast-finished").exists()


def test_empty_unknown_creation_settles_only_after_multiple_fresh_listings(
        monkeypatch, fake, policy):
    current = ticking_clock(monkeypatch)
    policy.update(instance_id=None, volume_id=None, creation_state="unknown",
                  creation_request_finished_unix=1000)
    prepare_cleanup(policy)
    cloud.destroy("timeout with no resources")
    assert current["now"] >= 1000 + cloud.UNKNOWN_SETTLE_SECONDS
    assert len([path for path, method, _ in fake.calls
                if path.startswith("/api/v0/volumes?owner=") and method == "GET"]) >= 3
    assert not any(method in ("PUT", "DELETE") for _, method, _ in fake.calls)
    assert (cloud.ROOT / "vast-finished").exists()


def test_orphan_with_unknown_attachment_is_never_deleted(fake, policy):
    policy.update(instance_id=None, creation_state="unknown", creation_request_finished_unix=1000)
    fake.volumes = [{"id": 201, "machine_id": 7, "instances": [{"id": 999}]}]
    prepare_cleanup(policy)
    with pytest.raises(RuntimeError, match="Pair deletion unverified"):
        cloud.destroy("association unknown")
    assert not any(method == "DELETE" for _, method, _ in fake.calls)
    assert not (cloud.ROOT / "vast-finished").exists()
