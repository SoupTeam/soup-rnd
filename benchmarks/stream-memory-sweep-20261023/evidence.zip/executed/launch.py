"""Root-only explicit lease launch with outer unconditional exact-instance cleanup."""

import argparse

import cloud
import controller


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--offer-id", type=int, required=True)
    parser.add_argument("--volume-ask-id", type=int, required=True)
    parser.add_argument("--seconds", type=int, default=28800)
    args = parser.parse_args()
    controller.freeze_check()
    try:
        cloud.allocate(args)
        controller.main()
    finally:
        if (cloud.ROOT / "vast-rental.json").exists():
            cloud.destroy("Outer launch finally: exact-owned instance and volume cleanup")


if __name__ == "__main__":
    main()
