"""Own exactly one new-stage lease, lossless retention, unconditional verified cleanup."""

import hashlib
import json
import os
import shutil
import time
from pathlib import Path

import cloud
import transport

ROOT = Path(__file__).parent
REQUIRED = [
    "source.tar.gz",
    "setup.sh",
    "worker.py",
    "prepare_model.py",
    "artifacts.py",
    "telemetry.py",
    "protocol.json",
    "source-manifest.json",
    "pytest_gpu_entry.py",
    "constraints.txt",
    "pin_entry.py",
    "lossless_results.py",
    "remote_retention_probe.py",
    "bench.py",
    "remote_ranges.py",
    "timing_summary.py",
    "preflight_remote.py",
]


def compact_verified():
    """Hardlink only byte-verified large duplicates; preserve all original paths."""
    known = {}
    for retained in sorted((ROOT / "bundles").glob("*/retained")):
        for path in retained.rglob("*.safetensors"):
            if path.stat().st_size < 2**20:
                continue
            key = (path.stat().st_size, transport.digest(path))
            if key not in known:
                known[key] = path
            elif not os.path.samefile(path, known[key]):
                if transport.digest(path) != transport.digest(known[key]):
                    raise RuntimeError("Duplicate evidence hash changed before hardlink")
                path.unlink()
                os.link(known[key], path)


def freeze_check():
    manifest = json.loads((ROOT / "launch-manifest.json").read_text())
    mandatory = set(REQUIRED) | {
        "controller.py",
        "cloud.py",
        "remote_guard.py",
        "transport.py",
        "archive_ranges.py",
    }
    if not mandatory <= set(manifest):
        raise RuntimeError("Frozen launch manifest omits executable/source dependencies")
    for name, row in manifest.items():
        if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != row["sha256"]:
            raise RuntimeError("Frozen launch file hash changed: " + name)
    source = transport.digest(ROOT / "source.tar.gz")
    if json.loads((ROOT / "protocol.json").read_text())["source_sha256"] != source:
        raise RuntimeError("Protocol does not identify this exact source archive")
    return source


def refresh_guard():
    reply = transport.ssh_retry("cat /root/liger/guard-status.json", 20, attempts=2)
    guard = json.loads(reply.stdout)
    if str(guard["instance_id"]) != str(cloud.receipt()["instance_id"]):
        raise RuntimeError("Remote guard belongs to a different lease")
    cloud.save("guard-status-latest.json", guard)
    return guard


def initial_retention_plan(calibration, policy, protocol):
    rate = calibration["encoded_mib_per_second"] * 2**20
    first = protocol["expected_8b_baseline_encoded_bytes"]
    remaining = policy["created_unix"] + policy["maximum_seconds"] - time.time()
    expected = protocol.get("expected_whole_matrix_encoded_bytes", first * 16)
    cohort_transfer = (expected + 256 * 2**20) / rate
    # Reserve the complete requested dense/NF4/disk matrix before model download.
    # Stage-by-stage admission still uses observed costs and actual archive sizes.
    cohort_seconds = cohort_transfer * 1.15 + 7200 + 300
    if cohort_seconds > remaining:
        raise RuntimeError("Measured retention throughput cannot fit the requested full matrix")
    free = shutil.disk_usage(ROOT).free
    if free < 45 * 2**30:
        raise RuntimeError("Insufficient local space to retain complete matrix raw evidence")
    return {
        "encoded_bytes_per_second": rate,
        "initial_raw_reserve_seconds": (first * 1.5 + 64 * 2**20) / rate,
        "expected_first_new_encoded_bytes": first,
        "first_cohort_retention_seconds": cohort_transfer,
        "first_cohort_admission_seconds": cohort_seconds,
        "whole_matrix_encoded_bytes_forecast": expected,
        "admission_basis": "no assumed donor reuse; actual archive spans/hashes govern",
        "local_free_bytes": free,
    }


def main():
    frozen_source = freeze_check()
    policy = cloud.receipt()
    if policy["label"] != cloud.LABEL or policy["maximum_usd"] != 10:
        raise RuntimeError("Wrong label or new-stage aggregate budget")
    if policy["source_sha256"] != frozen_source:
        raise RuntimeError("Lease source identity differs from frozen source")
    try:
        identity = policy["instance_id"]
        reply = cloud.api(
            f"/api/v0/instances/{identity}/ssh/",
            "POST",
            {
                "ssh_key": cloud.SSH_KEY.with_suffix(".pub").read_text().strip(),
            },
        )
        cloud.save(
            "ssh-key-attach.json",
            {name: reply[name] for name in ("success", "msg", "error") if name in reply},
        )
        boot = time.time()
        while time.time() - boot < 420:
            cloud.status()
            if (ROOT / "vast-connection.json").exists():
                try:
                    if cloud.ssh("true", 15).returncode == 0:
                        break
                except Exception:
                    pass
            time.sleep(3)
        else:
            raise RuntimeError("SSH boot deadline")
        refresh_guard()
        transport.upload("preflight_remote.py")
        transport.ssh_retry("python3 /root/liger/preflight_remote.py", 60, attempts=2)
        physical = json.loads(
            transport.ssh_retry("cat /root/liger/capacity-preflight.json", 20).stdout
        )
        cloud.save("capacity-preflight.json", physical)
        storage = json.loads(
            transport.ssh_retry("cat /root/liger/storage-validation.json", 20).stdout
        )
        cloud.save("storage-validation.json", storage)
        if not storage.get("nvme_verified"):
            raise RuntimeError("Attached cache path lacks verified NVMe backing; no model download")
        transport.network_preflight()
        calibration = json.loads((ROOT / "network-preflight.json").read_text())
        protocol = json.loads((ROOT / "protocol.json").read_text())
        plan = initial_retention_plan(calibration, policy, protocol)
        cloud.save("retention-policy.json", plan)
        transport.upload("retention-policy.json")
        for name in REQUIRED:
            transport.upload(name)
        transport.upload("launch-manifest.json")
        transport.ssh_retry(
            "nohup bash /root/liger/setup.sh > /root/liger/setup.log 2>&1 < /dev/null &", 30
        )
        finished, last = set(), None
        while True:
            if time.time() > policy["created_unix"] + policy["maximum_seconds"] - 180:
                raise RuntimeError("Collection/time budget deadline")
            refresh_guard()
            try:
                raw = transport.get("progress.json", 30).decode()
            except Exception:
                reply = transport.ssh_retry(
                    "if test -f /root/liger/results/progress.json; then "
                    "cat /root/liger/results/progress.json; "
                    "elif test -f /root/liger/setup.exited; then echo SETUP_FAILED; "
                    "tail -n12 /root/liger/setup.log; else echo SETUP; "
                    "tail -n4 /root/liger/setup.log; fi",
                    30,
                    attempts=2,
                )
                raw = reply.stdout.decode(errors="replace")
            if raw.startswith("SETUP_FAILED"):
                detail = transport.ssh_retry("tail -n200 /root/liger/setup.log", 30, attempts=2)
                (ROOT / "remote-setup-failure.log").write_bytes(detail.stdout)
                raise RuntimeError(raw)
            if raw.startswith("{"):
                state = json.loads(raw)
                cloud.save("remote-progress.json", state)
                marker = state["status"], state.get("current_stage"), len(state["stages"])
                if marker != last:
                    transport.log({"status": marker[0], "stage": marker[1], "completed": marker[2]})
                    last = marker
                for item in state["bundles"]:
                    name = item["name"]
                    if name not in finished:
                        transport.download(name)
                        compact_verified()
                        finished.add(name)
                        retained = json.loads((ROOT / "retention-policy.json").read_text())
                        retained["local_free_bytes"] = shutil.disk_usage(ROOT).free
                        cloud.save("retention-policy.json", retained)
                        transport.upload("retention-policy.json")
                if state.get("export_error"):
                    raise RuntimeError(state["export_error"])
                if "final" in finished:
                    cloud.save("final-worker-summary.json", state)
                    return
            elif raw[-500:] != last:
                transport.log(raw[-500:])
                last = raw[-500:]
            time.sleep(8)
    finally:
        try:
            refresh_guard()
        except Exception:
            pass
        cloud.destroy("New memory-impact stage stopped; verified bundle receipts retained")


if __name__ == "__main__":
    try:
        main()
    except BaseException as error:
        cloud.save(
            "controller-error.json",
            {
                "error": f"{type(error).__name__}: {error}",
                "unix": time.time(),
            },
        )
        raise
