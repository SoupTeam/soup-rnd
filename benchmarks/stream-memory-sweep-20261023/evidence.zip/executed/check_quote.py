"""Read-only final prospective quote; never allocate resources."""

from rich.console import Console

import cloud


def main():
    candidates = cloud.offers()
    gpu = next((row for row in candidates if row["id"] == 50375418), None)
    if gpu is None:
        raise RuntimeError("Reviewed 3070 offer disappeared; choose and revalidate a new offer")
    volume = next((row for row in cloud.volume_offers(gpu["machine_id"])
                   if int(row["id"]) == 50375420), None)
    if volume is None:
        raise RuntimeError("Reviewed matching local volume disappeared")
    plan = cloud.quote(gpu, prior_usd=cloud.prior_stage_cost(), volume_offer=volume)
    instances, volumes = cloud.rows(), cloud.volume_rows()
    credit = float(cloud.api("/api/v0/users/current/")["credit"])
    result = {
        "read_only": True, "rental_started": False,
        "offer_id": gpu["id"], "volume_ask_id": volume["id"],
        "gpu_name": gpu["gpu_name"], "gpu_ram_mb": gpu["gpu_ram"],
        "host_ram_mb": gpu["cpu_ram"], "machine_id": gpu["machine_id"],
        "plan": plan, "credit_covers_admission": credit >= plan["total_stage_admission_usd"],
        "account_instances": len(instances), "account_volumes": len(volumes),
    }
    cloud.save("final-prospective-quote.json", result)
    Console(force_terminal=False, legacy_windows=False).print(result)


if __name__ == "__main__":
    main()
