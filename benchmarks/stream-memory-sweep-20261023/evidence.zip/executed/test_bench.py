"""CPU controls for research adapter behavior, not a GPU fit/speed verdict."""

import hashlib
import json
from pathlib import Path

import pytest

from bench import (
    MIN_DEVICE_FREE_BYTES,
    CapacityRefusalError,
    count_from_arm,
    device_budget,
    install_fixed_residency,
    load_preparation,
    quantization_provenance,
    sample_memory,
    semantic_config,
    storage_classification,
)
from prepare_model import FROZEN_DATA_SHA256, configuration, write_data


@pytest.mark.parametrize(("arm", "count"), [("baseline", 0), ("resident4", 4), ("resident36", 36)])
def test_explicit_arm_counts(arm, count):
    assert count_from_arm(arm) == count


@pytest.mark.parametrize("arm", ["auto", "resident0", "resident-1", "resident4x", "4"])
def test_bad_arms_never_become_baseline(arm):
    with pytest.raises(ValueError):
        count_from_arm(arm)


def test_device_budget_uses_real_free_space_without_old_seven_gib_limit():
    total = 8222998528
    assert device_budget(total, total, 0) == total - 256 * 2**20
    assert device_budget(total, 6 * 2**30, 0) == 6 * 2**30 - MIN_DEVICE_FREE_BYTES
    with pytest.raises(ValueError, match="physical"):
        device_budget(16 * 2**30, 16 * 2**30, 0)
    with pytest.raises(CapacityRefusalError):
        device_budget(total, MIN_DEVICE_FREE_BYTES, 0)


@pytest.mark.parametrize("quant", ["none", "nf4"])
@pytest.mark.parametrize("source", ["ram", "disk"])
def test_prepared_config_keeps_fixed_inputs_and_production_residency_off(quant, source):
    from soup_cli.config.schema import SoupConfig

    payload = configuration(Path("/root/liger"), 8, quant, source)
    config = SoupConfig.model_validate(payload)
    assert config.training.stream_resident_layers == 0
    assert config.training.stream_source == source
    assert config.training.quantization == ("4bit" if quant == "nf4" else "none")
    assert config.training.double_quant_on
    assert config.training.batch_size == 1
    assert config.training.gradient_accumulation_steps == 2
    assert config.data.max_length == 1024
    adapted = semantic_config(config, "baseline")
    assert adapted.model_dump() == config.model_dump()


def test_data_serialization_remains_the_same_as_frozen_b(tmp_path):
    path = tmp_path / "train.jsonl"
    write_data(path)
    # Independently extracted from B's exact retained gpu/train.jsonl.
    assert hashlib.sha256(path.read_bytes()).hexdigest() == FROZEN_DATA_SHA256
    assert path.stat().st_size == 185206


def test_native_fixed_adapter_preserves_real_checkpointed_trajectory():
    import torch
    from tests.test_streaming_residency_candidate import fixture, trajectory

    reference, ordinary = fixture()
    candidate, runtime = fixture()
    assert install_fixed_residency(reference, ordinary, 0) == []
    assert install_fixed_residency(candidate, runtime, 2) == [2, 3]
    expected, actual = trajectory(reference, ordinary), trajectory(candidate, runtime)
    assert all(torch.equal(first, second) for first, second in zip(expected, actual))
    assert sorted(runtime.pool.resident_slots) == [2, 3]
    runtime.tier = "disk"
    with pytest.raises(ValueError):
        install_fixed_residency(candidate, runtime, 1)


def test_prepared_manifest_identity_cannot_silently_change(tmp_path, monkeypatch):
    import soup_cli.utils.layer_shard as shards

    config = tmp_path / "model-8-nf4-ram.yaml"
    config.write_text("base: local\n")
    shard = tmp_path / "shard"
    shard.mkdir()
    index = shard / "index.json"
    index.write_text("{}")
    manifest = {
        "status": "PREPARED_CACHE_NOT_A_TRAINING_VERDICT",
        "config_sha256": hashlib.sha256(config.read_bytes()).hexdigest(),
        "data_path": str(config), "data_sha256": hashlib.sha256(config.read_bytes()).hexdigest(),
        "base_path": "model",
        "shard_dir": str(shard), "cache_root": str(shard), "shard_files": {
            "index.json": {"bytes": 2, "mtime_ns": index.stat().st_mtime_ns,
                           "sha256": hashlib.sha256(index.read_bytes()).hexdigest()},
        },
    }
    config.with_suffix(".prepare.json").write_text(json.dumps(manifest))
    monkeypatch.delenv("SOUP_LAYER_STREAM_CACHE_DIR", raising=False)
    monkeypatch.setattr(shards, "resolve_shard_dir", lambda _base: str(shard))
    assert load_preparation(config)["cache_root"] == str(shard)
    index.write_text("[]")
    with pytest.raises(ValueError, match="changed"):
        load_preparation(config)


def test_nf4_provenance_inspects_actual_packed_wrappers(tmp_path):
    pytest.importorskip("bitsandbytes")
    pytest.importorskip("peft")
    from tests.test_v07202 import _nf4_stream

    model, runtime, *_unused = _nf4_stream(tmp_path, n_layers=4)
    proof = quantization_provenance(model, runtime, "nf4")
    assert proof["loaded_in_4bit"]
    assert len(proof["quantized_layer_specs"]) == 4
    assert "torch.uint8" in proof["rotating_slot_dtypes"].values()
    with pytest.raises(ValueError, match="Dense baseline"):
        quantization_provenance(model, runtime, "none")
    runtime.close()


def test_free_memory_guard_is_a_capacity_failure_and_records_the_sample(monkeypatch):
    import torch

    monkeypatch.setattr(torch.cuda, "synchronize", lambda: None)
    monkeypatch.setattr(torch.cuda, "mem_get_info", lambda _device: (100 * 2**20, 8 * 2**30))
    monkeypatch.setattr(torch.cuda, "max_memory_allocated", lambda: 1)
    monkeypatch.setattr(torch.cuda, "max_memory_reserved", lambda: 1)
    proof = {"physical_gpu_bytes": 8 * 2**30, "allocator_budget_bytes": 7 * 2**30}
    with pytest.raises(CapacityRefusalError, match="128 MiB"):
        sample_memory(proof, "test")
    assert proof["device_free_min_bytes"] == 100 * 2**20


def test_nvme_claim_requires_backing_identity_direct_io_and_actual_reads():
    proof = {
        "nvme_verified": True, "verified_path": "/data", "backing_device": "/dev/nvme1n1",
        "mount_source": "/dev/nvme1n1", "device_major_minor": "259:1",
        "sysfs_realpath": "/sys/devices/pci/nvme/nvme1/nvme1n1",
    }
    assert storage_classification(proof, ["/data/soup-shards-none/model"], True, 100)[
        "nvme_read_control_qualified"
    ]
    for direct, reads, path in [(False, 100, "/data/a"), (True, 0, "/data/a"),
                                (True, 100, "/root/a")]:
        assert not storage_classification(proof, [path], direct, reads)["nvme_timing_qualified"]
    proof.pop("sysfs_realpath")
    assert not storage_classification(proof, ["/data/a"], True, 100)["nvme_timing_qualified"]
