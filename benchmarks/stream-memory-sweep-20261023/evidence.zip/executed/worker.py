"""Budgeted independent RAM-residency and same-format disk cohorts; accuracy first."""

from __future__ import annotations

import json
import math
import os
import shutil
import signal
import statistics
import subprocess
import sys
import time
import traceback
from pathlib import Path
from typing import Any


class AdmissionError(RuntimeError):
    """The next stage cannot retain its complete evidence within the budget."""


class CohortError(RuntimeError):
    """A numerical/instrument failure; never reinterpret it as a capacity limit."""


class CapacityStopError(CohortError):
    """An explicitly classified capacity stop after preserving the failed capture."""


def admission(
    policy: dict, guard: dict, retention: dict, *, now: float, seconds: float,
    encoded_bytes: int = 0, download_bytes: int = 0, raw_bytes: int = 0,
) -> dict:
    """Conservative prospective admission; guard cost already includes all prior attempts."""
    rate = float(retention.get("encoded_bytes_per_second", 0))
    if rate <= 0:
        raise AdmissionError("missing measured exact-byte retention throughput")
    reserve = float(policy.get("cleanup_reserve_usd", 1))
    deadline = policy["created_unix"] + min(28800, policy["maximum_seconds"])
    transfer = encoded_bytes / rate
    required_seconds = seconds + transfer + 300
    estimated_usd = (
        guard["conservative_usd"]
        + required_seconds * policy["hourly_usd"] / 3600
        + encoded_bytes / 1e9 * policy["up_usd_per_gb"]
        + download_bytes / 1e9 * policy["down_usd_per_gb"] + reserve
    )
    local_free = int(retention.get("local_free_bytes", 0))
    return {
        "admitted": (now + required_seconds <= deadline
                     and estimated_usd <= policy["maximum_usd"]
                     and local_free >= raw_bytes + encoded_bytes + 2 * 2**30),
        "estimated_total_usd": estimated_usd,
        "remaining_seconds": deadline - now,
        "required_seconds": required_seconds,
        "encoded_bytes_forecast": encoded_bytes,
        "raw_bytes_forecast": raw_bytes,
        "local_free_bytes": local_free,
        "donor_savings_assumed": False,
    }


class Worker:
    def __init__(self, root: Path):
        self.root = root
        self.repo = root / "repo"
        self.out = root / "results"
        self.out.mkdir(exist_ok=True)
        self.policy = self.read(root / "policy.json")
        self.protocol = self.read(root / "protocol.json")
        self.published: set[str] = set()
        self.summary: dict[str, Any] = {
            "status": "STARTED", "cohorts": {}, "stages": [], "bundles": [],
            "funding": "one aggregate USD10 stage; guard includes prior A/B costs",
        }

    @staticmethod
    def read(path: Path) -> Any:
        return json.loads(path.read_text())

    def save(self) -> None:
        temporary = self.out / "progress.tmp"
        temporary.write_text(json.dumps(self.summary, indent=2))
        temporary.replace(self.out / "progress.json")

    def admit(self, *, seconds: float, capture: bool = False, download_bytes: int = 0) -> dict:
        guard = self.read(self.root / "guard-status.json")
        retention = self.read(self.root / "retention-policy.json")
        encoded = int(retention.get("actual_baseline_encoded_bytes", 1100000000) * 1.5)
        checked = admission(
            self.policy, guard, retention, now=time.time(), seconds=seconds,
            encoded_bytes=encoded if capture else 16 * 2**20,
            raw_bytes=3 * 2**30 if capture else 32 * 2**20,
            download_bytes=download_bytes,
        )
        checked["remote_free_bytes"] = shutil.disk_usage(self.root).free
        checked["admitted"] = checked["admitted"] and (
            checked["remote_free_bytes"] >= checked["raw_bytes_forecast"]
            + checked["encoded_bytes_forecast"] + 2 * 2**30
        )
        self.summary["last_admission"] = checked
        self.save()
        if not checked["admitted"]:
            raise AdmissionError("prospective compute/retention/budget admission refused")
        return checked

    def stage(self, name: str, args: list[str], *, maximum: int = 1200,
              capture: bool = False, download_bytes: int = 0) -> int:
        self.admit(seconds=maximum, capture=capture, download_bytes=download_bytes)
        self.summary["current_stage"] = name
        self.save()
        started = time.time()
        with (self.out / f"{name}.log").open("w") as log:
            child = subprocess.Popen(
                args, cwd=self.repo, stdout=log, stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            try:
                code = child.wait(timeout=maximum)
            except BaseException:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
                raise
        self.summary["stages"].append({
            "name": name, "exit_code": code, "seconds": time.time() - started,
            "started_unix": started,
        })
        self.save()
        telemetry = self.out / "gpu-telemetry.jsonl"
        if telemetry.exists():
            for line in telemetry.read_text().splitlines():
                sample = json.loads(line)
                if started <= sample["unix"] <= time.time():
                    peers = [row for row in sample.get("processes", "").splitlines()
                             if row.strip() and row.lstrip()[0].isdigit()]
                    if len(peers) > 1:
                        raise CohortError("external GPU peers invalidate this stage")
        return code

    def bundle(self, label: str) -> dict:
        from artifacts import pack

        selection = {str(path.relative_to(self.root))
                     for path in self.out.rglob("*") if path.is_file()} - self.published
        selection.add("results/progress.json")
        helpers = [
            "source.tar.gz", "source-manifest.json", "setup.sh", "worker.py", "bench.py",
            "prepare_model.py", "timing_summary.py", "pin_entry.py", "pytest_gpu_entry.py",
            "constraints.txt", "protocol.json", "launch-manifest.json", "artifacts.py",
            "lossless_results.py", "remote_ranges.py", "retention-policy.json",
            "capacity-preflight.json", "storage-validation.json",
        ]
        selection.update(name for name in helpers
                         if name not in self.published and (self.root / name).is_file())
        identifier = "final" if label == "final" else "sweep-" + label
        index = pack(identifier, sorted(selection))
        self.published.update(selection)
        self.summary["bundles"].append({"name": identifier, "bytes": index["archive_bytes"]})
        self.save()
        deadline = self.policy["created_unix"] + min(28800, self.policy["maximum_seconds"])
        while not (self.root / ("ack-" + identifier)).is_file():
            if time.time() > deadline - 180:
                raise AdmissionError("complete raw retention ACK deadline")
            time.sleep(2)
        return index

    def invoke(self, quant: str, source: str, count: int, target: Path,
               *extra: str) -> list[str]:
        return [
            sys.executable, str(self.root / "bench.py"), "--config",
            str(self.root / f"model-8-{quant}-{source}.yaml"), "--arm",
            "baseline" if count == 0 else f"resident{count}", "--output", str(target), *extra,
        ]

    def prepare(self, quant: str, source: str) -> None:
        retained = sum(
            path.stat().st_size for path in (self.root / "model-8").glob("*.safetensors")
        )
        download = max(0, self.protocol["models"][0]["weight_bytes"] - retained)
        code = self.stage(
            f"prepare-{quant}-{source}",
            [sys.executable, str(self.root / "prepare_model.py"), "8", "--quant", quant,
             "--source", source], maximum=2400, download_bytes=download,
        )
        if code:
            raise CohortError("model preparation failed")

    def info(self, target: Path) -> dict:
        path = target / "residency-sweep-provenance.json"
        return self.read(path) if path.is_file() else {}

    def capacity(self, cohort: dict, quant: str, source: str, count: int) -> bool:
        key = f"{quant}-{source}"
        target = self.out / key / f"capacity-{count}"
        code = self.stage(
            f"capacity-{key}-{count}", self.invoke(quant, source, count, target, "--capacity"),
            maximum=600,
        )
        info = self.info(target)
        cohort.setdefault("capacity_screens", {})[str(count)] = info
        self.save()
        if code:
            if info.get("capacity_failure") in {"OOM", "cap_refusal"}:
                cohort["capacity_stop"] = {"count": count, "reason": info["capacity_failure"]}
                self.bundle(f"capacity-stop-{key}-{count}")
                return False
            raise CohortError(f"non-capacity error in capacity screen {key}/{count}")
        if info.get("status") != "COMPLETED_NOT_AN_INDEPENDENT_VERDICT":
            raise CohortError("capacity screen lacks completed provenance")
        free = info.get("device_free_min_bytes")
        if not isinstance(free, int):
            raise CohortError("capacity screen lacks observed device free memory")
        if free < self.protocol["observed_device_free_floor_bytes"]:
            cohort["capacity_stop"] = {"count": count, "reason": "observed_free_below_floor"}
            self.bundle(f"capacity-free-stop-{key}-{count}")
            return False
        return True

    def qualify(self, cohort: dict, quant: str, source: str, count: int,
                reference: Path | None = None) -> Path:
        key = f"{quant}-{source}"
        folder = self.out / key
        primary, semantic = folder / f"capture-{count}", folder / f"semantics-{count}"
        code = self.stage(
            f"capture-{key}-{count}", self.invoke(quant, source, count, primary, "--capture"),
            maximum=1500, capture=True,
        )
        if code:
            self.bundle(f"failed-capture-{key}-{count}")
            info = self.info(primary)
            if info.get("capacity_failure") in {"OOM", "cap_refusal"}:
                cohort["capacity_stop"] = {"count": count, "reason": info["capacity_failure"]}
                raise CapacityStopError(f"full accuracy capture exceeded capacity: {key}/{count}")
            raise CohortError(f"full accuracy capture failed: {key}/{count}")
        index = self.bundle(f"capture-{key}-{count}")
        if count == 0 and reference is None:
            retention = self.read(self.root / "retention-policy.json")
            retention["actual_baseline_encoded_bytes"] = index["archive_bytes"]
            temporary = self.root / "worker-retention-observation.json"
            temporary.write_text(json.dumps(retention, indent=2))
        code = self.stage(
            f"semantics-{key}-{count}",
            self.invoke(quant, source, count, semantic, "--semantics"), maximum=1200,
        )
        if code:
            self.bundle(f"failed-semantics-{key}-{count}")
            raise CohortError(f"causal/padding capture failed: {key}/{count}")
        baseline = reference or folder
        base_count = 0
        gates = {
            "primary": compare(baseline / f"capture-{base_count}", primary),
            "semantics": compare(baseline / f"semantics-{base_count}", semantic),
        }
        cohort.setdefault("accuracy", {})[str(count)] = gates
        cohort.setdefault("actual_selections", {})[str(count)] = self.info(primary)
        self.save()
        self.bundle(f"accuracy-{key}-{count}")
        if not all(gate["passed"] for gate in gates.values()):
            raise CohortError(f"unchanged numerical gate failed: {key}/{count}")
        cohort.setdefault("qualified_counts", []).append(count)
        self.save()
        return folder

    def screen(self, cohort: dict, quant: str, source: str, count: int) -> float:
        if count not in cohort.get("qualified_counts", []):
            raise CohortError("preliminary speed screen before accuracy qualification")
        key = f"{quant}-{source}"
        target = self.out / key / f"selection-screen-{count}"
        code = self.stage(
            f"selection-screen-{key}-{count}",
            self.invoke(quant, source, count, target, "--warmup", "2", "--steps", "3"),
            maximum=900,
        )
        if code:
            raise CohortError("preliminary selection screen failed")
        metrics = self.read(target / "metrics.json")
        values = metrics["seconds"]
        if len(values) != 3 or any(not math.isfinite(value) or value <= 0 for value in values):
            raise CohortError("preliminary screen has invalid timing values")
        median = statistics.median(values)
        cohort.setdefault("selection_screens", {})[str(count)] = {
            "median_seconds": median, "selection_only_not_heldout_performance": True,
        }
        self.save()
        return median

    def dense(self) -> None:
        key, quant, source = "none-ram", "none", "ram"
        cohort = self.summary["cohorts"].setdefault(key, {"status": "STARTED"})
        self.prepare(quant, source)
        if not self.capacity(cohort, quant, source, 0):
            cohort["status"] = "BASELINE_CAPACITY_REFUSED"
            return
        self.qualify(cohort, quant, source, 0)
        layers = self.protocol["models"][0]["config"]["num_hidden_layers"]
        for count in range(4, layers + 1):
            if not self.capacity(cohort, quant, source, count):
                break
            try:
                self.qualify(cohort, quant, source, count)
            except CapacityStopError:
                break
        eligible = [count for count in cohort.get("qualified_counts", []) if count]
        for count in [0] + eligible:
            self.screen(cohort, quant, source, count)
        if eligible:
            cohort["selected_count"] = min(
                eligible,
                key=lambda count: cohort["selection_screens"][str(count)]["median_seconds"],
            )
        cohort["status"] = "ACCURACY_AND_SELECTION_COMPLETE_HELDOUT_PENDING"
        self.save()
        self.bundle("dense-selection")

    def nf4(self) -> None:
        key, quant, source = "nf4-ram", "nf4", "ram"
        cohort = self.summary["cohorts"].setdefault(key, {"status": "STARTED"})
        self.prepare(quant, source)
        if not self.capacity(cohort, quant, source, 0):
            cohort["status"] = "BASELINE_CAPACITY_REFUSED"
            return
        self.qualify(cohort, quant, source, 0)
        layers = self.protocol["models"][0]["config"]["num_hidden_layers"]
        fit = 0
        for count in range(4, layers + 4, 4):
            count = min(count, layers)
            if self.capacity(cohort, quant, source, count):
                fit = count
                if count == layers:
                    break
                continue
            for smaller in range(fit + 1, count):
                if not self.capacity(cohort, quant, source, smaller):
                    break
                fit = smaller
            break
        cohort["largest_screened_fit_count"] = fit
        if fit:
            self.qualify(cohort, quant, source, fit)
            self.screen(cohort, quant, source, 0)
            self.screen(cohort, quant, source, fit)
            cohort["selected_count"] = fit
        cohort["status"] = "ACCURACY_AND_SELECTION_COMPLETE_HELDOUT_PENDING"
        self.save()
        self.bundle("nf4-selection")

    def disk(self) -> None:
        key = "nf4-disk"
        cohort = self.summary["cohorts"].setdefault(key, {"status": "STARTED"})
        ram = self.summary["cohorts"].get("nf4-ram", {})
        if 0 not in ram.get("qualified_counts", []):
            cohort["status"] = "NOT_STAGED_NO_MATCHED_NF4_RAM_BASELINE"
            return
        self.prepare("nf4", "disk")
        if not self.capacity(cohort, "nf4", "disk", 0):
            cohort["status"] = "BASELINE_CAPACITY_REFUSED"
            return
        self.qualify(cohort, "nf4", "disk", 0, reference=self.out / "nf4-ram")
        proof = self.root / "storage-validation.json"
        cohort["storage_validation"] = self.read(proof) if proof.is_file() else {}
        observed = cohort["actual_selections"]["0"]
        verified = cohort["storage_validation"].get("nvme_verified") is True
        backing = cohort["storage_validation"]
        paths = observed.get("cache_paths", [])
        root = os.path.realpath(backing.get("verified_path", "/missing-proof-root"))
        try:
            verified = (verified and bool(paths) and all(
                os.path.commonpath([root, os.path.realpath(path)]) == root for path in paths
            ) and all(backing.get(name) for name in (
                "backing_device", "mount_source", "device_major_minor", "sysfs_realpath",
            )))
        except ValueError:
            verified = False
        cohort["nvme_path_verified"] = bool(verified)
        cohort["capture_device_read_qualified"] = bool(
            verified and observed.get("nvme_timing_qualified") is True
            and observed.get("io_read_bytes_delta", 0) > 0
        )
        cohort["storage_claim"] = (
            "NVMe-backed path; device-read qualification checked per process" if verified
            else "disk tier; NVMe backing unverified"
        )
        cohort["status"] = "MATCHED_NF4_ACCURACY_COMPLETE_HELDOUT_PENDING"
        self.save()
        self.bundle("nf4-disk-accuracy")

    def heldout(self, label: str, reference_source: str, candidate_source: str,
                quant: str, count: int) -> None:
        from timing_summary import summarize

        candidate_cohort = self.summary["cohorts"][f"{quant}-{candidate_source}"]
        reference_cohort = self.summary["cohorts"][f"{quant}-{reference_source}"]
        if (0 not in reference_cohort.get("qualified_counts", [])
                or count not in candidate_cohort.get("qualified_counts", [])):
            raise CohortError("heldout timing before both arms qualified")
        record = self.summary.setdefault("heldout", {}).setdefault(label, {"pairs": []})
        adapters = self.protocol["models"][0]["config"]["num_hidden_layers"] * 14
        for number, order in enumerate(self.protocol["pair_order"]):
            paths = {}
            for letter in order:
                arm = "baseline" if letter == "A" else "candidate"
                source = reference_source if letter == "A" else candidate_source
                selected = 0 if letter == "A" else count
                target = self.out / "heldout" / label / f"pair-{number}-{arm}"
                code = self.stage(
                    f"heldout-{label}-{number}-{arm}",
                    self.invoke(quant, source, selected, target, "--warmup", "6", "--steps", "8"),
                    maximum=1500,
                )
                if code:
                    raise CohortError("heldout timing process failed")
                paths[arm] = target
            checked = trajectory(paths["baseline"], paths["candidate"], adapters)
            if not checked["passed"]:
                raise CohortError("heldout fourteen-update trajectory failed")
            pair = {"pair": number, "order": order, "trajectory": checked}
            for arm in ("baseline", "candidate"):
                metrics = self.read(paths[arm] / "metrics.json")
                pair["baseline" if arm == "baseline" else "auto"] = metrics["seconds"]
                pair[arm + "_provenance"] = self.info(paths[arm])
                pair[arm + "_measured_peak_allocated_bytes"] = max(metrics["peak_allocated_bytes"])
                pair[arm + "_measured_peak_reserved_bytes"] = max(metrics["peak_reserved_bytes"])
            record["pairs"].append(pair)
            self.save()
            self.bundle(f"heldout-{label}-{number}")
        record["performance"] = summarize(record["pairs"])
        if candidate_source == "disk":
            record["disk_step_time_multiplier"] = statistics.median(
                statistics.median(pair["auto"]) / statistics.median(pair["baseline"])
                for pair in record["pairs"]
            )
            record["nvme_timing_qualified"] = bool(
                candidate_cohort.get("nvme_path_verified") and all(
                    pair["candidate_provenance"].get("nvme_timing_qualified") is True
                    and pair["candidate_provenance"].get("io_read_bytes_delta", 0) > 0
                    for pair in record["pairs"]
                )
            )
        record["status"] = "COMPLETE_REQUIRES_INDEPENDENT_REPLAY"
        self.save()

    def independent_phase(self, name: str, action: Any) -> None:
        try:
            action()
        except AdmissionError as error:
            self.summary.setdefault("not_completed", {})[name] = str(error)
        except CapacityStopError as error:
            self.summary.setdefault("not_completed", {})[name] = str(error)
        except Exception as error:
            self.summary.setdefault("failed", {})[name] = f"{type(error).__name__}: {error}"
            self.bundle(f"failed-{name}")
        self.save()

    def run(self) -> None:
        if self.protocol.get("test_paths"):
            code = self.stage(
                "scoped-regressions", [sys.executable, str(self.root / "pytest_gpu_entry.py"),
                                       *self.protocol["test_paths"], "--no-cov", "-q",
                                       "--tb=short", "--junitxml="
                                       + str(self.out / "scoped-regressions.xml")], maximum=600,
            )
            if code:
                raise CohortError("scoped CPU/GPU regressions failed before training")
            self.bundle("regressions")
        # Independent format/source cohorts are admitted by budget/retention,
        # never by whether a different cohort crossed a speed threshold.
        self.independent_phase("dense", self.dense)
        self.independent_phase("nf4", self.nf4)
        self.independent_phase("disk", self.disk)
        for label, quant, reference, candidate, count in self.requested_heldout():
            self.independent_phase(
                label, lambda label=label, quant=quant, reference=reference,
                candidate=candidate, count=count:
                self.heldout(label, reference, candidate, quant, count),
            )
        self.summary["status"] = (
            "PARTIAL" if self.summary.get("failed") or self.summary.get("not_completed")
            else "COMPLETE_REQUIRES_INDEPENDENT_REPLAY"
        )
        self.save()

    def requested_heldout(self) -> list[tuple[str, str, str, str, int]]:
        result = []
        dense = self.summary["cohorts"].get("none-ram", {})
        if dense.get("selected_count"):
            result.append(("dense-best", "none", "ram", "ram", dense["selected_count"]))
        disk = self.summary["cohorts"].get("nf4-disk", {})
        if 0 in disk.get("qualified_counts", []):
            result.append(("nf4-disk-vs-ram", "nf4", "ram", "disk", 0))
        nf4 = self.summary["cohorts"].get("nf4-ram", {})
        if nf4.get("selected_count"):
            result.append(("nf4-maxfit", "nf4", "ram", "ram", nf4["selected_count"]))
        if 4 in dense.get("qualified_counts", []) and dense.get("selected_count") != 4:
            result.append(("dense-four-reference", "none", "ram", "ram", 4))
        return result


def compare(reference, candidate):
    import torch  # noqa: I001 -- original unchanged reference comparator imports
    from benchmarks.harness.liger_streaming_parity import compare as original_compare
    from safetensors.torch import load_file

    verdict = original_compare(reference, candidate)
    first = load_file(str(reference / "trace.safetensors"))
    second = load_file(str(candidate / "trace.safetensors"))
    verdict["bitwise_equal"] = all(
        torch.equal(value, second[name]) for name, value in first.items()
    )
    verdict["tensor_count"] = len(first)
    return verdict

def trajectory(reference, candidate, expected_tensors):
    import torch
    from safetensors.torch import load_file

    first = load_file(str(reference / "adapter/adapter_model.safetensors"))
    second = load_file(str(candidate / "adapter/adapter_model.safetensors"))
    if set(first) != set(second) or len(first) != expected_tensors:
        raise RuntimeError("Final adapter keys/count changed")
    finite_close = all(
        torch.isfinite(value).all()
        and torch.isfinite(second[name]).all()
        and torch.allclose(value, second[name], rtol=0.01, atol=0.00001)
        for name, value in first.items()
    )
    metrics = [
        json.loads((folder / "metrics.json").read_text()) for folder in (reference, candidate)
    ]
    losses = [
        [row["loss"] for row in item["training_log_history"] if "loss" in row] for item in metrics
    ]
    if any(len(values) != 14 for values in losses):
        raise RuntimeError("Expected fourteen complete optimizer updates")
    loss_close = all(f"{a:.3f}" == f"{b:.3f}" for a, b in zip(*losses, strict=True))
    if metrics[0]["initial_adapter_sha256"] != metrics[1]["initial_adapter_sha256"]:
        raise RuntimeError("Timing pair did not start from exact same nonzero adapters")
    if metrics[0]["data_sha256"] != metrics[1]["data_sha256"]:
        raise RuntimeError("Timing pair data changed")
    for item in metrics:
        if item["amp"] != {"bf16": True, "fp16": False} or len(item["seconds"]) != 8:
            raise RuntimeError("Timing precision/window changed")
        if len(item["input_shapes"]) != 28 or any(
            shape != [1, 1024] for shape in item["input_shapes"]
        ):
            raise RuntimeError("Timing batch/context/microbatch count changed")
    return {
        "passed": bool(finite_close and loss_close),
        "loss_three_decimals": loss_close,
        "bitwise_equal": all(torch.equal(value, second[name]) for name, value in first.items()),
        "losses_equal": losses[0] == losses[1],
        "adapter_tensors": len(first),
    }


def main() -> None:
    from rich.console import Console

    root = Path("/root/liger")
    sys.path[:0] = [str(root), str(root / "repo"), str(root / "repo/src")]
    worker = Worker(root)
    worker.save()
    try:
        worker.run()
    except BaseException as error:
        worker.summary.update(status="FAILED", error=f"{type(error).__name__}: {error}")
        (worker.out / "error.log").write_text(traceback.format_exc())
        worker.save()
    finally:
        try:
            worker.bundle("final")
        except BaseException as error:
            worker.summary["export_error"] = f"{type(error).__name__}: {error}"
            worker.save()
        (root / "worker.exited").touch()
    Console().print({"status": worker.summary["status"], "report": "results/progress.json"})


if __name__ == "__main__":
    main()
