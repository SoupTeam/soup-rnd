"""Refuse slow retention and unrelated visible NVMe hardware before paid training."""

import json
from types import SimpleNamespace

import pytest

import controller
import preflight_remote


def test_whole_matrix_transport_admission(monkeypatch):
    monkeypatch.setattr(controller.time, "time", lambda: 0)
    monkeypatch.setattr(
        controller.shutil, "disk_usage", lambda _: SimpleNamespace(free=100 * 2**30),
    )
    policy = {"created_unix": 0, "maximum_seconds": 28800}
    protocol = {"expected_8b_baseline_encoded_bytes": 1100000000}
    result = controller.initial_retention_plan(
        {"encoded_mib_per_second": 2}, policy, protocol,
    )
    assert result["whole_matrix_encoded_bytes_forecast"] == 17600000000
    with pytest.raises(RuntimeError, match="full matrix"):
        controller.initial_retention_plan(
            {"encoded_mib_per_second": 0.5}, policy, protocol,
        )


def test_overlay_is_not_proof_even_with_visible_nvme(monkeypatch, tmp_path):
    monkeypatch.setattr(preflight_remote, "os", SimpleNamespace(
        path=SimpleNamespace(realpath=lambda value: str(value)),
        stat=lambda _: SimpleNamespace(st_dev=0), major=lambda _: 0, minor=lambda _: 0,
    ))
    monkeypatch.setattr(preflight_remote.Path, "exists", lambda _: False)
    monkeypatch.setattr(preflight_remote, "output", lambda _: json.dumps({
        "filesystems": [{"source": "overlay", "maj:min": "0:0"}],
    }))
    monkeypatch.setattr(
        preflight_remote.shutil, "disk_usage", lambda _: SimpleNamespace(free=2**40),
    )
    saved = []
    monkeypatch.setattr(preflight_remote.Path, "write_text", lambda _, value: saved.append(value))
    assert not preflight_remote.storage_proof(str(tmp_path))["nvme_verified"]
    assert json.loads(saved[0])["mount_source"] == "overlay"
