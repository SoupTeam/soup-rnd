"""Small lossless encoded roundtrip fixture; never a model-quality benchmark."""
import json
import os
import time
from pathlib import Path

import lossless_results

root = Path('/root/liger')
fixture = root / 'retention-probe'
payload = bytearray(32 * 1024 * 1024)
random = os.urandom(len(payload) // 2)
payload[2::4] = random[::2]
payload[3::4] = random[1::2]
changed = bytearray(payload)
changed[100] ^= 1
changed[-6] ^= 128
names = []
for name, data in [('baseline', payload), ('identical', payload), ('sparse', changed)]:
    folder = fixture / name
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / 'trace.safetensors'
    path.write_bytes(data)
    names.append(name + '/trace.safetensors')
started = time.perf_counter()
index = lossless_results.pack(fixture, names, root / 'retention-probe.tar')
index['pack_seconds'] = time.perf_counter() - started
index['synthetic_only'] = True
(root / 'retention-probe.json').write_text(json.dumps(index, indent=2))
