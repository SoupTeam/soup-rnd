"""Read actual physical GPU/cgroup RAM/disk/device before any model download."""

import json
import os
import re
import shutil
import subprocess
import time
from pathlib import Path


def output(command):
    return subprocess.check_output(command, text=True).strip()


def storage_proof(path="/data"):
    """Tie the actual cache mount's st_dev to its kernel NVMe block ancestry."""
    absolute = os.path.realpath(path)
    metadata = os.stat(absolute)
    identity = f"{os.major(metadata.st_dev)}:{os.minor(metadata.st_dev)}"
    mounted = json.loads(output([
        "findmnt", "--json", "-T", absolute,
        "-o", "TARGET,SOURCE,FSTYPE,MAJ:MIN,OPTIONS",
    ]))["filesystems"][0]
    sysfs = Path("/sys/dev/block") / identity
    ancestry = os.path.realpath(sysfs) if sysfs.exists() else ""
    # An unrelated /sys/block/nvme device does not establish this path's backing.
    is_nvme = bool(re.search(r"/nvme/nvme\d+/nvme\d+n\d+(?:/|$)", ancestry))
    same = mounted.get("maj:min") == identity
    proof = {
        "nvme_verified": is_nvme and same,
        "verified_path": absolute,
        "backing_device": str(sysfs) if sysfs.exists() else None,
        "mount_source": mounted.get("source"),
        "device_major_minor": identity,
        "sysfs_realpath": ancestry,
        "raw_evidence": mounted,
        "free_bytes": shutil.disk_usage(absolute).free,
        "interpretation": (
            "Path backing only. Direct-I/O and physical read counters must be "
            "established by each actual disk training process."
        ),
    }
    Path("/root/liger/storage-validation.json").write_text(json.dumps(proof, indent=2))
    return proof


def main():
    storage = storage_proof()
    if storage["free_bytes"] < 29 * 2**30:
        raise RuntimeError("Insufficient separate cache volume for dense and NF4 caches")
    samples = []
    for index in range(3):
        gpu = output([
            "nvidia-smi", "--query-gpu=name,memory.total,uuid,utilization.gpu,memory.used",
            "--format=csv,noheader,nounits",
        ])
        rows = gpu.splitlines()
        if len(rows) != 1:
            raise RuntimeError("Require one physical GPU, not a larger GPU with an allocator cap")
        fields = [part.strip() for part in rows[0].split(",")]
        if not 7900 <= int(fields[1]) <= 8300:
            raise RuntimeError("GPU is not a physical 8GiB device")
        apps = output([
            "nvidia-smi", "--query-compute-apps=gpu_uuid,pid,used_memory",
            "--format=csv,noheader,nounits",
        ])
        if apps or int(fields[3]) > 10 or int(fields[4]) > 256:
            raise RuntimeError("GPU has pre-existing work or unexplained memory pressure")
        samples.append({"gpu": gpu, "compute_apps": apps, "unix": time.time()})
        if index < 2:
            time.sleep(5)
    available = next(
        int(line.split()[1]) * 1024 for line in Path("/proc/meminfo").read_text().splitlines()
        if line.startswith("MemAvailable:")
    )
    limits = {"host_mem_available_bytes": available}
    for filename in (
        "/sys/fs/cgroup/memory.max", "/sys/fs/cgroup/memory/memory.limit_in_bytes",
    ):
        path = Path(filename)
        if path.exists() and path.read_text().strip() != "max":
            limit = int(path.read_text())
            usage = path.with_name(
                "memory.current" if path.name == "memory.max" else "memory.usage_in_bytes"
            )
            if usage.exists():
                limits[filename] = limit - int(usage.read_text())
    usable = min(limits.values())
    if usable < 52 * 2**30:
        raise RuntimeError("Require at least52GiB genuinely available RAM before download")
    free = shutil.disk_usage("/root/liger").free
    if free < 85 * 2**30:
        raise RuntimeError("Insufficient staging/results disk; no model download")
    row = {
        "passed": True, "gpu_idle_samples": samples, "available_ram_limits": limits,
        "usable_ram_lower_bound_bytes": usable, "disk_free_bytes": free,
        "filesystem": output(["findmnt", "-T", "/root/liger", "-o", "SOURCE,FSTYPE,TARGET"]),
        "devices": output(["lsblk", "-d", "-o", "NAME,MODEL,ROTA,TRAN,SIZE"]),
        "nvme_verified": storage["nvme_verified"],
        "nvme_note": (
            "Refers to the separate cache path, not the root filesystem; see cache_storage."
        ),
        "cache_storage": storage,
    }
    Path("/root/liger/capacity-preflight.json").write_text(json.dumps(row, indent=2))


if __name__ == "__main__":
    main()
