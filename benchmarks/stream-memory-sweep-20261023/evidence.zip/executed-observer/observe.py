"""Read-only external telemetry retention; never alters the frozen GPU experiment."""

import json
import time

import cloud
import transport


def main():
    policy = cloud.receipt()
    started = time.time()
    target = cloud.ROOT / "gpu-telemetry-last-observed.jsonl"
    while not (cloud.ROOT / "vast-finished").exists():
        try:
            raw = transport.ssh_retry(
                "cat /root/liger/results/gpu-telemetry.jsonl", 20, attempts=1,
            ).stdout
            # Retain complete original lines only; a writer may be appending its last line.
            raw = raw[:raw.rfind(b"\n") + 1]
            rows = [json.loads(line) for line in raw.splitlines()]
            if rows:
                temporary = target.with_suffix(".tmp")
                temporary.write_bytes(raw)
                temporary.replace(target)
                cloud.save("telemetry-observer.json", {
                    "instance_id": policy["instance_id"], "started_unix": started,
                    "last_pull_unix": time.time(), "samples": len(rows),
                    "first_sample_unix": rows[0]["unix"], "last_sample_unix": rows[-1]["unix"],
                    "original_bytes": len(raw), "sha256": cloud.digest(target),
                    "observer_sha256": cloud.digest(__file__),
                    "coverage": "Observed exact prefix; may omit final samples before deletion",
                })
        except Exception as error:
            cloud.save("telemetry-observer-last-error.json", {
                "unix": time.time(), "error": f"{type(error).__name__}: {error}",
            })
        time.sleep(20)


if __name__ == "__main__":
    main()
