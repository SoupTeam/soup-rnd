# Host-memory counters: Linux lifetime and reporting scope

Read-only interpretation prepared 2026-10-23. No experiment, kernel setting, cloud resource,
or frozen helper was changed. Kernel code links below are pinned to Linux v6.12; this is
an implementation reference, not an attestation of the remote host's exact kernel build.

## Why the two recorded peaks can differ

`bench.py:59-67` records two separate Linux counters: `getrusage(RUSAGE_SELF).ru_maxrss`
converted from KiB to bytes, then `/proc/self/status` fields converted to bytes. The calls
are sequential, not one atomic snapshot. Preserve both original values and names.

The Linux manual defines `RUSAGE_SELF` for the calling process, including its threads;
`ru_maxrss` is maximum resident set size in KiB. Resource-usage accounting survives
`execve`. It is not an isolated training-window counter. See
[getrusage(2), DESCRIPTION and NOTES](https://www.man7.org/linux/man-pages/man2/getrusage.2.html).

The kernel explains the lifetime difference directly:

- During executable replacement, `exec_mmap` saves the old address space's RSS high-water
  in the process signal accounting before releasing that address space. See
  [fs/exec.c, exec_mmap](https://github.com/torvalds/linux/blob/v6.12/fs/exec.c#L952-L957).
- `getrusage(RUSAGE_SELF)` takes the greater of that saved process peak and the current
  address space's high-water, then converts pages to KiB. See
  [kernel/sys.c, getrusage](https://github.com/torvalds/linux/blob/v6.12/kernel/sys.c#L1695-L1774)
  and [include/linux/mm.h, high-water helpers](https://github.com/torvalds/linux/blob/v6.12/include/linux/mm.h#L2458-L2498).
- `/proc/PID/status` derives `VmHWM` from the current `mm_struct`'s resident counters and
  high-water; it does not consult the saved signal-accounting peak. See
  [fs/proc/task_mmu.c, task_mem](https://github.com/torvalds/linux/blob/v6.12/fs/proc/task_mmu.c#L32-L63).

Therefore a process can truthfully retain a larger pre-exec `ru_maxrss` while its new
executable's `VmHWM` remains smaller. The queried observation, approximately 8.9731 GiB
versus 5.8093 GiB for one NF4-disk held-out process, is consistent with those different
lifetimes. Equality around 10.4322 GiB in another RAM process does not prove equal
lifetime scopes; its new address space may simply have reached the greater peak.
These are individual observations, not completed-cohort aggregates.

## Fork is a separate nuance

Do not say that ordinary `fork` blindly copies the parent's historical `ru_maxrss`.
The manual states that child resource accounting is reset, while its initial memory
contents are inherited. See [fork(2), DESCRIPTION](https://www.man7.org/linux/man-pages/man2/fork.2.html).
The implementation zero-initializes a new process's signal structure and sets a duplicated
address space's high-water to its inherited current RSS. A `CLONE_VM` path instead shares
the existing address space until replacement. See
[kernel/fork.c, dup_mm and copy_mm](https://github.com/torvalds/linux/blob/v6.12/kernel/fork.c#L1565-L1633)
and [copy_signal](https://github.com/torvalds/linux/blob/v6.12/kernel/fork.c#L1731-L1740).

Consequently, residency present before the child's exec can enter the child's saved
high-water even if its new Python image never allocates that much. Shared inherited
pages are not evidence that this much additional physical RAM was duplicated.

Here `worker.py:115-118` launches benchmark children through `subprocess.Popen` and the
same worker performs full-trace comparisons (`worker.py:499-510`). That makes launcher
residency a plausible explanation. The retained counters do not identify the exact
fork/vfork/posix_spawn syscall path, the parent's RSS at that instant, or which comparison
allocations remained resident. Those details are not proven by the numerical discrepancy.

## Labels and limits for the final results

Report `ru_maxrss` as **process resource-usage peak, potentially including pre-exec RSS**,
and `VmHWM` as **current executable/address-space RSS high-water at the observation**.
Neither is peak RAM of only the eight timed updates: current-program imports, model setup,
and warmup can contribute. No subtraction of the two counters isolates a training peak.

`VmHWM`/`VmRSS` are also approximate kernel RSS counters. Their manual explicitly warns
about accuracy; snapshots can race with allocation/free activity. See
[proc_pid_status(5), VmHWM and VmRSS](https://www.man7.org/linux/man-pages/man5/proc_pid_status.5.html).

Neither counter proves a whole-machine RAM requirement, available-memory minimum, or
successful operation under a smaller RAM limit. It omits other processes and does not
measure all filesystem-cache/kernel overhead. Adding independent process maxima would
mix different times and can double-count shared pages. For a future whole-job claim,
isolate the complete job in a known cgroup and retain its scoped peak and component
accounting, including preparation and the launcher. Linux documents `memory.peak` as a
cgroup-and-descendants peak and `memory.stat` as the component breakdown; that still is
not an entire-machine measurement. See
[cgroup v2 memory interface](https://docs.kernel.org/admin-guide/cgroup-v2.html#memory-interface-files).

Do not replace, reset, or reinterpret away either raw counter in the present evidence.
