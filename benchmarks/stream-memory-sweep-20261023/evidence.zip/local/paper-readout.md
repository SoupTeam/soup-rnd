# 10Cache: первоисточник и сопоставление с проверенным кодом Soup

Проверено 2026-10-23. Это подготовка источников для обсуждения после текущих замеров C.
Код статьи не запускался; облачных/GPU-вызовов и изменений Soup при подготовке нет.

## Что действительно описывает статья

Название: **10Cache: Heterogeneous Resource-Aware Tensor Caching and Migration for LLM Training**.
Авторское написание — `10Cache`, с цифрами 1 и 0. Версия: [arXiv v1](https://arxiv.org/abs/2511.14124v1).
Ниже указаны физические страницы PDF, отсчёт с первой страницы.

- DeepSpeed/ZeRO-Infinity: FP16-параметры, FP32-состояния оптимизатора; обновления выполняются на CPU.
  [§2.1, стр. 2](https://arxiv.org/pdf/2511.14124v1#page=2),
  [§3.4, стр. 6](https://arxiv.org/pdf/2511.14124v1#page=6).
- Dry-run профилирует порядок и размеры тензоров. Prefetch запускается хуками исполнения,
  без зависимости от настенных таймеров.
  [§3.2, стр. 4](https://arxiv.org/pdf/2511.14124v1#page=4),
  [§3.4, стр. 6](https://arxiv.org/pdf/2511.14124v1#page=6).
- Размерные классы переиспользуемых GPU/pinned-CPU буферов; ближайшие обращения приоритетны.
  Если VRAM+RAM хватает, NVMe не используется. Иначе CPU-кеш взаимодействует с NVMe;
  предзагрузка идёт асинхронно NVMe→CPU→GPU.
  [§3.3, стр. 4–5](https://arxiv.org/pdf/2511.14124v1#page=5),
  [§3.4.1–3.4.2, стр. 6–7](https://arxiv.org/pdf/2511.14124v1#page=7).
- Ограничения: регулярный граф; L40S/A40 48 GB, A100 40 GB, RAM 200–256 GB,
  default batch 16, PyTorch 2.3.0/DeepSpeed 0.14.2. CPU-GPU серия ограничивает VRAM 24 GB
  (§4.2.1, стр. 8). Физические 8 GB, LoRA/NF4
  этим экспериментом не подтверждены.
  [§2.3, стр. 3](https://arxiv.org/pdf/2511.14124v1#page=3),
  [§4.1, стр. 8](https://arxiv.org/pdf/2511.14124v1#page=8).

## Что подтверждает авторский код

Связанный самой статьёй [репозиторий автора](https://github.com/Sabiha1225/10cache)
проверен на commit `8c8ee772e72c20c7178d533e647e6f4d770559a5`.

В [примере OPT-6.7B](https://github.com/Sabiha1225/10cache/blob/8c8ee772e72c20c7178d533e647e6f4d770559a5/examples/10cache_opt_6_7b_cpu_gpu.py#L40)
загружается `AutoModelForSequenceClassification`; PEFT/LoRA и замораживания базы в этом скрипте нет.
Все `requires_grad` параметры передаются DeepSpeed
([строки 199–212](https://github.com/Sabiha1225/10cache/blob/8c8ee772e72c20c7178d533e647e6f4d770559a5/examples/10cache_opt_6_7b_cpu_gpu.py#L199)).
Это подтверждает full-parameter fine-tuning для опубликованного примера, а не adapter-only обучение.
После warmup вызываются `set_prefetch_table_warmup()` и `preallocate_memory()`
([строки 249–250](https://github.com/Sabiha1225/10cache/blob/8c8ee772e72c20c7178d533e647e6f4d770559a5/examples/10cache_opt_6_7b_cpu_gpu.py#L249)).
Название файла `cpu_gpu` само по себе не доказывает отсутствие SSD: его config
указывает `device: nvme` для параметров и optimizer states
([строки 159–173](https://github.com/Sabiha1225/10cache/blob/8c8ee772e72c20c7178d533e647e6f4d770559a5/examples/10cache_opt_6_7b_cpu_gpu.py#L159)).

В [OPT-13B примере](https://github.com/Sabiha1225/10cache/blob/8c8ee772e72c20c7178d533e647e6f4d770559a5/examples/10cache_opt_13b_cpu_gpu_nvme.py#L40)
тоже используется sequence classification, а не causal-LM loss Soup; trainable параметры
передаются DeepSpeed через `filter(requires_grad)`
([строка 201](https://github.com/Sabiha1225/10cache/blob/8c8ee772e72c20c7178d533e647e6f4d770559a5/examples/10cache_opt_13b_cpu_gpu_nvme.py#L201)).
Его NVMe config выставляет `max_in_cpu: 0`
([строки 159–174](https://github.com/Sabiha1225/10cache/blob/8c8ee772e72c20c7178d533e647e6f4d770559a5/examples/10cache_opt_13b_cpu_gpu_nvme.py#L159)).

В [модифицированном Stage 3](https://github.com/Sabiha1225/10cache/blob/8c8ee772e72c20c7178d533e647e6f4d770559a5/deepspeed/runtime/zero/stage3.py#L498)
есть распределение размерных классов, отдельные GPU/CPU cache allocation и
optimizer-state cache. Перед размещением очищаются старые структуры, выделяются буферы,
затем параметры получают `current_location`/`final_location`
([preallocate_memory, строка 629](https://github.com/Sabiha1225/10cache/blob/8c8ee772e72c20c7178d533e647e6f4d770559a5/deepspeed/runtime/zero/stage3.py#L629)).
Проверены исходники; их совместимость с текущим стеком Soup и воспроизводимость не проверялись.

## Что уже есть в проверенной ветке Soup

Аудит относится к чистому dedicated worktree `koko/stream-memory-auto-20261023`,
HEAD `e0d47e0dfb76a932e436a7034d2f655b46d86788` (PR #5).
Это не новая проверка свежести upstream `main`.
Источник текущего эксперимента C закреплён отдельно SHA-256 архива
`adfc15617878f3592f3bd49c37fd69ef7b94f8e4e2d5b177e409a2e42f7e1bb7`.

| Область | Подтверждённое поведение Soup | Точный источник |
|---|---|---|
| Что обучается | База замораживается через `requires_grad=False`, затем устанавливается PEFT/LoRA. Значит, миграция optimizer states всей базы не является тем же workload. | [layer_stream_runtime.py:3613](https://github.com/SoupTeam/soup-rnd/blob/e0d47e0dfb76a932e436a7034d2f655b46d86788/src/soup_cli/utils/layer_stream_runtime.py#L3613) |
| Выбор RAM/SSD | Если весь host store плюс extras укладывается в RAM с запасом, выбирается RAM; иначе проверяется допустимость disk tier. | [layer_stream.py:744](https://github.com/SoupTeam/soup-rnd/blob/e0d47e0dfb76a932e436a7034d2f655b46d86788/src/soup_cli/utils/layer_stream.py#L744) |
| RAM tier | `RamSource` единожды размещает всю базу в host RAM; pinned-вариант использует арены и views. | [layer_stream_runtime.py:615](https://github.com/SoupTeam/soup-rnd/blob/e0d47e0dfb76a932e436a7034d2f655b46d86788/src/soup_cli/utils/layer_stream_runtime.py#L615) |
| Disk tier | `AsyncDiskSource` создаёт ограниченное число переиспользуемых staging-слотов на группу форм. `read_ahead` ограничивает окно; pinning и direct I/O — разные свойства. Direct I/O выбирается по каждому диску, иначе явно используется buffered/page-cache путь. | [async_disk_source.py:518](https://github.com/SoupTeam/soup-rnd/blob/e0d47e0dfb76a932e436a7034d2f655b46d86788/src/soup_cli/utils/async_disk_source.py#L518), [factory:3434](https://github.com/SoupTeam/soup-rnd/blob/e0d47e0dfb76a932e436a7034d2f655b46d86788/src/soup_cli/utils/layer_stream_runtime.py#L3434) |
| Host reuse уже существует | Staging выбирает свободные слоты с учётом направления прохода и ближайших потребностей; нельзя говорить, что у Soup вообще нет RAM-кеша/предзагрузки. Это ограниченное rolling-окно, а не произвольный постоянный hot-set под всю свободную RAM. | [async_disk_source.py:812](https://github.com/SoupTeam/soup-rnd/blob/e0d47e0dfb76a932e436a7034d2f655b46d86788/src/soup_cli/utils/async_disk_source.py#L812), [очередь:924](https://github.com/SoupTeam/soup-rnd/blob/e0d47e0dfb76a932e436a7034d2f655b46d86788/src/soup_cli/utils/async_disk_source.py#L924) |
| GPU prefetch уже существует | `StreamPrefetcher.advance()` определяет направление forward/backward и рассматривает соседний decoder-слой; также есть отдельная предзагрузка больших embedding/head. | [layer_stream_runtime.py:1362](https://github.com/SoupTeam/soup-rnd/blob/e0d47e0dfb76a932e436a7034d2f655b46d86788/src/soup_cli/utils/layer_stream_runtime.py#L1362), [advance:1433](https://github.com/SoupTeam/soup-rnd/blob/e0d47e0dfb76a932e436a7034d2f655b46d86788/src/soup_cli/utils/layer_stream_runtime.py#L1433) |
| Добавленное residency | Выделяются приватные GPU-слоты для выбранных полных decoder-слоёв. `auto` измеряет peak, оставляет reserve и проверяет candidate; это capacity policy, не оптимизатор времени шага. Публичный `configure_stream_residency` сейчас допускает только RAM tier. | [pool.reserve_layers:1090](https://github.com/SoupTeam/soup-rnd/blob/e0d47e0dfb76a932e436a7034d2f655b46d86788/src/soup_cli/utils/layer_stream_runtime.py#L1090), [stream_residency.py:245](https://github.com/SoupTeam/soup-rnd/blob/e0d47e0dfb76a932e436a7034d2f655b46d86788/src/soup_cli/utils/stream_residency.py#L245) |
| NF4 | Packed bytes и quantization state сохраняются отдельно от compute; NF4 имеет свой checkpoint-visible autograd путь. Это ещё одна причина не переносить политику FP16 model-state offload буквально. | [layer_stream_runtime.py:111](https://github.com/SoupTeam/soup-rnd/blob/e0d47e0dfb76a932e436a7034d2f655b46d86788/src/soup_cli/utils/layer_stream_runtime.py#L111), [NF4 forward:181](https://github.com/SoupTeam/soup-rnd/blob/e0d47e0dfb76a932e436a7034d2f655b46d86788/src/soup_cli/utils/layer_stream_runtime.py#L181) |

## Граница выводов для следующего обсуждения

Сопоставление выше устанавливает существующие механизмы и различия workload, а не выигрыш скорости.
Оно не доказывает, что надо заполнять память до 100%, что увеличение числа закреплённых слоёв
монотонно ускоряет шаг или что отсутствующий функционал автоматически полезен.

После завершения C следует сопоставить точность и реальные времена/память/I/O каждого процесса,
отделить setup от повторяемого шага и только затем выбирать между изменениями GPU-residency,
bounded read-ahead, отдельным host hot-set либо отсутствием новой фичи.
Это возможные направления проверки, не выбранная реализация и не обещание ускорения.

Новых экспериментов, интеграции авторского DeepSpeed fork или изменения численных допусков
эта заметка не выполняет и не санкционирует.
