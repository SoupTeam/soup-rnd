# NF4 SSD timing: nonstationary updates, cause not established

Read-only audit, 2026-10-24 local date. The frozen experiment and its timing/accuracy gates
were not changed. No extra training, disk benchmark, installation, GPU query, cloud API
request, remote write, or resource-lifecycle operation was performed.

## Direct retained evidence

`ssd-variability-raw-window.json` extracts all 14 original update durations and the eight
measured update I/O deltas for each of four matched RAM/disk pairs. It names the original
retained metadata paths and freshly hashes those small provenance files. No update was
discarded, substituted, or retrospectively moved into warmup.

The disk candidates start near four seconds per update and then change markedly inside
the predetermined measured window. Examples from the provenance observer's timer,
seconds per measured update:

```text
pair 0: 4.024 4.026 4.254 4.028 4.056 4.581 17.318 17.591
pair 1: 4.085 5.770 17.719 17.227 16.984 17.062 17.630 17.778
pair 2: 4.022 4.013 4.233 4.366 17.374 17.389 18.010 17.855
pair 3: 6.535 21.587 17.962 17.811 17.718 18.651 17.162 17.448
```

Each of all 32 measured disk updates reports exactly **13,539,246,080 process read_bytes**;
all corresponding measured RAM updates report zero. Thus the fast/slow split is not
explained by those fast updates reporting fewer storage-read bytes. This does not measure
NAND-media reads or establish constant device service time. The existing proof of direct
I/O and `/data` NVMe backing is retained separately in `storage-validation.json`.

The protocol estimator uses a separate retained timer: `metrics.json.seconds`.
Re-evaluating the exact frozen `timing_summary.py` on those four pairs gives the following
canonical figures:

| Pair | RAM protocol median, s | Disk protocol median, s | Disk/RAM step-time ratio |
| --- | ---: | ---: | ---: |
| 0 | 4.025840 | 4.155162 | 1.032123 |
| 1 | 4.021325 | 17.144647 | 4.263433 |
| 2 | 4.030261 | 10.870020 | 2.697101 |
| 3 | 4.031985 | 17.764485 | 4.405890 |

The median of those four protocol ratios is **3.4802665514165434**. Equivalently, the
frozen estimator reports median paired step-time reduction **-248.02665514165435%**,
bootstrap interval **[-340.58904365470727%, -3.212307523899538%]**, and no positive pairs.
It describes this exact experiment's
predeclared mixed-regime windows. It is not a universal SSD penalty or a measured
steady-state rate. Pair 2's median falls between its fast and slow clusters; it does not
represent a stable observed update duration. Six warmup updates did not ensure a stable
subsequent regime. Preserve the original windows and uncertainty in the final report.

### Why the descriptive observer ratio differs slightly

`ssd-variability-raw-window.json` preserves the provenance callback's
`all_update_wall_seconds[-8:]`, not the protocol callback's `metrics.json.seconds`.
The same median-of-paired-ratios calculation on that descriptive series gives
**3.4803796359593253**, the value in the first version of this note. This is a timer-source
difference, not an estimator, rounding, pair-order, or selected-window change.

The extra provenance observer is installed during wrapper setup (`bench.py:286-314`).
The original benchmark's `Measure` callback is appended afterward and records its own
synchronized boundaries (`benchmarks/harness/liger_streaming_bench.py:127-143` in the
frozen production archive). Callback execution and I/O/memory accounting lie between
the two sets of timestamps. In these 64 measured observations, protocol durations exceed
the corresponding provenance durations by approximately **0.100-0.296 ms**. Do not treat
the two timing arrays as interchangeable.

`worker.py:419-420` selects `metrics.json.seconds`; `timing_summary.py` calculates
`100 * (1 - median(candidate) / median(baseline))` per whole pair, then its median and
predeclared whole-pair bootstrap. The helper SHA256 is
`dc3b773fb4ac23e0329e5ad218b5b853c7a760b408419914b52299220bbdbb28`.
The canonical result above reproduces the remote summary exactly. No raw record, timing
window, comparison predicate, bootstrap setting, or practical gate was changed.

## Current, bounded remote snapshot

`ssd-readonly-observation.json` preserves one small container-visible snapshot at
**2026-10-23 19:12:54 UTC**, during `heldout-nf4-maxfit-1-candidate`, after the SSD pairs.
It cannot reconstruct configuration, temperature or contention during earlier SSD updates.
It was collected through the existing SSH transport, using only read-only Python/sysfs,
procfs and cgroup-file reads; the remote probe source hash is recorded.

- Visible cgroup v2 reports `0::/`; only its mounted root was visible. `io.max` is empty,
  `io.weight` is `default 910`. No explicit BPS/IOPS cap is shown at this visible level.
  `io.cost.model` and `io.cost.qos` were absent. Invisible ancestors and host-side policy
  were not inspected and cannot be ruled out.
- Cgroup `io.stat` records cumulative reads on device `259:0`; those totals span the
  workload history, not only SSD training. `io.pressure` at the snapshot reports
  `some avg300=9.66`, `full avg300=9.14`, with near-zero recent avg10. These aggregate
  values are not a time-aligned diagnosis of any particular update.
- The live NVMe controller is `KINGSTON SFYRD2000G`, PCIe, state `live`. The separately
  verified cache path is `/data` on partition `259:3` of `nvme0n1`; the whole namespace
  is `259:0`. Its queue has scheduler `none`, maximum request size 128 KiB and read-ahead
  128 KiB. Configuration alone does not prove the reason for the timing change.
- Composite temperature is **52.85 C**, its exposed maximum threshold **83.85 C**, critical
  threshold **88.85 C**, alarm **0**. A separate `Sensor 2` reports **80.85 C**, with no
  max/critical threshold exposed for that sensor in this snapshot. Do not compare that
  separate sensor directly with the composite threshold or label it confirmed throttling.

Linux defines `io.max` as BPS/IOPS limits, `io.weight` as relative resource sharing,
`io.stat` as device accounting and `io.pressure` as I/O stall information. A visible empty
limit file is not proof that the complete host path is unrestricted. See the primary
[cgroup v2 I/O interface documentation](https://docs.kernel.org/admin-guide/cgroup-v2.html#io-interface-files).
The NVMe driver reports separate composite and sensor temperatures in millicelsius and
exposes a SMART critical-warning alarm; none is a historical throttling timeline. See
the [version-pinned Linux NVMe hwmon implementation](https://github.com/torvalds/linux/blob/v6.12/drivers/nvme/host/hwmon.c).

## Advertised storage versus an actual guarantee

The pre-rental saved offer `50375418`, machine `45882`, advertises `disk_bw` of
**4141.317128388442** and disk model `KINGSTON SFYRD2000G`. Local volume offer `50375420`
is on that same machine. This value is offer metadata, not our sustained-read benchmark
and not evidence of a per-instance reservation.

Vast's official [volume guide](https://docs.vast.ai/guides/instances/storage/volumes)
establishes machine-local storage and mounting. Its official
[CLI source](https://github.com/vast-ai/vast-cli/blob/master/vast.py) exposes `disk_bw` as
the disk-bandwidth offer field. The reviewed primary volume/storage pages did not specify
a contractual sustained rate or a local-volume burst/throttle formula. No specific Vast
throttle mechanism was verified. Documentation for the unrelated company VAST Data does
not describe Vast.ai's rented local volumes and is not used as evidence here.

## Interpretation boundary

This run demonstrates a large within-process timing change with unchanged recorded bytes
read per update. It does not identify its cause. Host contention, unseen bandwidth policy,
thermal behavior, or changing I/O/computation overlap are hypotheses, not findings.
No time-aligned storage service-time/profile trace or past throttle-status history was
retained to distinguish them. The current snapshot does not fill that gap.

For a future stationary-rate claim, pre-register longer observation and stationarity
criteria plus time-aligned I/O/configuration/temperature telemetry. That is a separate
experiment; do not retroactively select only the slow or fast updates from this one.
