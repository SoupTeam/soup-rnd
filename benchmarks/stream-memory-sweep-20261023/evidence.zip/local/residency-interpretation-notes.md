# Interpreting NF4 count 34 with two rotating slots

This is source analysis, not a speed result or an independently measured slot-owner snapshot.

## Frozen source identity

- Source archive SHA256: `adfc15617878f3592f3bd49c37fd69ef7b94f8e4e2d5b177e409a2e42f7e1bb7`.
- `src/soup_cli/utils/layer_stream_runtime.py` SHA256, checked against the archive and its inventory:
  `5f770b012278ac12e95948aae76b3922804a37d3fcda1b42cd01071dbcd27ede`.
- `src/soup_cli/utils/stream_residency.py` SHA256, checked the same way:
  `48dc4770de2eb85db3270cf1b68daf7ec62569b6dd334ebf668339c1e0fd0936`.
- The executed `bench.py` and `prepare_model.py` are bound by `launch-manifest.json`.
  Line references below refer to these exact archived/source helper files.

## All 36 decoder payloads can have stable GPU slots, with an important refill caveat

`prepare_model.py:54-61` requests streaming, two rotating buffers, and production residency mode 0.
The research wrapper subsequently installs private slots: `bench.py:128-143` calls
`centered_layer_indices()` and verifies the resulting resident mapping.
The centered rule is `(n_layers - count) // 2`, then a contiguous block
(`stream_residency.py:85-90`). With 36 layers and count 34, private indices are **1 through 34**.

The two remaining layers are **0 and 35**. `LayerBufferPool.slot_for()` maps a non-private layer
to `idx % self.n` (`layer_stream_runtime.py:1075-1076`), hence:

| Decoder layers | GPU storage |
| --- | --- |
| 1–34 | 34 separate private slots, appended after the rotating slots |
| 0 | Rotating slot 0 |
| 35 | Rotating slot 1 |

Private slots are appended without changing `self.n`
(`layer_stream_runtime.py:1160-1174`). No other non-private decoder uses either rotating slot.
After both remaining layers have been loaded, these decoder payloads need not evict each other.
This permits all 36 decoder payloads to remain physically allocated on the GPU; **34 private
resident layers does not mean that only 34 decoder payloads are held by the GPU**.

It does **not** imply zero decoder copies. `StreamPrefetcher.prime()` unconditionally calls
`pool.load_async(0)` at the start of every forward (`layer_stream_runtime.py:1424-1431`).
Only private layers have an early return in `load_async`; the dynamic path copies even when its
slot already has the same owner (`layer_stream_runtime.py:1225-1239`). The next-layer prefetch
does check ownership before loading (`layer_stream_runtime.py:1443-1445`). Thus the source
predicts a redundant layer-0 refill on each microbatch, while repeated layer-35 prefetches can
skip copying. With accumulation 2, **two decoder loads per optimizer update** is the expected
steady pattern, rather than zero. This is a source prediction to check in the retained counters.

For comparison, count 35 would select private layers 0–34 and leave only layer 35 dynamic;
that different mapping could remove the unconditional dynamic-layer-0 refill. This observation
does not establish that count 35 fits or passes any memory/accuracy gate.

## RAM copies are retained

`RamSource` preallocates CPU tensors for every requested source layer and stores them for the run
(`layer_stream_runtime.py:615-706`); `get()` returns those stored tensors (`826-827`). The source
contains all decoder specifications plus the large embedding/head specifications
(`layer_stream_runtime.py:3089-3105`). The copy-release contract explicitly says `RamSource`
holds every layer for the whole run and has no `release()` method (`1015-1034`). Reserving private
GPU slots copies from that source; it does not delete or shrink its CPU store
(`layer_stream_runtime.py:1137-1139`, `1203-1223`).

Therefore private residency duplicates selected weight payloads into VRAM. It does not turn the
RAM cohort into a CPU-memory-saving placement policy. Process high-water RSS is a separate
measurement and includes setup/allocator effects.

## Embedding and output head still alternate through one large GPU buffer

The pinned Qwen3-8B config has untied embeddings (`protocol.json`: `tie_word_embeddings=false`).
Its `embed_tokens` and `lm_head` are excluded from decoder residency. NF4 replacement excludes the
output head (`layer_stream_runtime.py:2546-2555`); untied boundary tensors remain on meta until
the large wrappers are installed (`2603-2612`). `LargeLayerBufferPool` holds **one** reusable
allocation sized for the larger boundary matrix (`1290-1322`), and changes its owner when it
copies the other boundary weight (`1330-1349`). Output-head prefetch and backward embedding
prefetch remain wired (`3121-3138`, `1483-1490`).

Consequently “all decoder payloads have slots” is not “the whole model is GPU resident.”
Large boundary copies can remain. The source predicts roughly four large loads per steady
optimizer update at accumulation 2 (cold start can add a load), subject to actual counters.
NF4 code tables and small non-streamed extras are separate resident allocations (`2603-2637`).

## Required evidence before interpreting the measured arm

Check the actual count-34 capture and all held-out process provenance, not only the requested arm:

1. `indices == [1, ..., 34]`, `resident_layers == 34`, actual NF4 markers and 36 quantized decoder
   specs, `actual_tier == "ram"`, `source_class == "RamSource"`.
2. Last eight of fourteen `per_update_loads` entries in each timing process:
   decoder `loads` median and range, `large_loads` median and range, and
   `logical_decoder_copy_bytes` when available. Counters are recorded at `bench.py:287-313`.
   A steady decoder count of two is consistent with the unconditional layer-0 refills above;
   it must not be described as zero-copy streaming. Aggregate counters do not record individual
   slot owners or copied layer IDs.
3. Measured allocated/reserved VRAM, sampled driver-free minimum, and process high-water RSS.
   Private payload bytes, complete cache file bytes, and training memory are different quantities.
4. Accuracy still uses the matched NF4 RAM baseline. BF16-versus-NF4 remains a separate lossy
   quantization diagnostic. No speed conclusion follows from slot count or reduced copies alone.
