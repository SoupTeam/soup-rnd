# Cross-format dtype finding: native dense versus NF4 training

Read-only audit, 2026-10-24. This note preserves the recorded
`INVALID_DIAGNOSTIC_EVIDENCE` result. No tensors were cast, no comparator was rerun with
different rules, and no frozen source, helper, cloud resource, or GPU process was changed.

## Direct raw-header evidence

The four retained safetensors headers were read directly using their length-prefixed JSON
headers, without loading tensor payloads. Corresponding dense/NF4 traces have identical
key sets and shapes, but different adapter/gradient dtypes:

| Phase/group | Tensor count per arm | Dense RAM/0 | NF4 RAM/0 |
| --- | ---: | --- | --- |
| Primary initial adapters | 504 | F32 | BF16 |
| Primary final adapters | 504 | F32 | BF16 |
| Primary gradients | 1,008 | F32 | BF16 |
| Primary logits | 4 | F32 | F32 |
| Primary batches / loss | 16 / 1 | I64 / F64 | I64 / F64 |
| Semantic initial adapters | 504 | F32 | BF16 |
| Semantic gradients | 504 | F32 | BF16 |
| Semantic logits / unpadded diagnostic | 1 / 1 | BF16 / BF16 | BF16 / BF16 |
| Semantic batch / loss | 4 / 1 | I64 / F64 | I64 / F64 |

There are 2,037 primary tensors per arm, including 2,016 dtype mismatches, and 1,015
semantic tensors per arm, including 1,008 dtype mismatches. Primary logit shapes are
`[1, 1024, 151936]`. Matching logit dtypes do not establish matching training precision.

Trace identities below are the SHA256 values recorded by the verified-retention
`original-files.json` inventories; this header-only audit did not rehash multi-GB payloads.
Each trace is under `bundles/<bundle>/retained/results/<format>/<phase>-0/trace.safetensors`.

| Bundle / results phase | Bytes | Retention-recorded trace SHA256 |
| --- | ---: | --- |
| `sweep-capture-none-ram-0` / `none-ram/capture` | 2664310056 | `c3b0a837b8b60fcd4269696deee94bc63d4b296831d8d476b1dc62b30c88810a` |
| `sweep-capture-nf4-ram-0` / `nf4-ram/capture` | 2577024696 | `a352d9b701b03ef3d4374668db160e709b7b6cb2d549a739d01ff84706c8f1bc` |
| `sweep-accuracy-none-ram-0` / `none-ram/semantics` | 97777000 | `d18a209a8615a006ea28f7a6138d607744203a2c6274b04c4b7c8c0bf80110ba` |
| `sweep-accuracy-nf4-ram-0` / `nf4-ram/semantics` | 54130944 | `7c985f7967249988d9dec15a85655c2842644020e3dcecd94ce25892e12cab19` |

Fresh SHA256 of the exact padded header JSON bytes, in the same row order:

```text
ab26db529a7fb4b2df824ee042671c8d1486ea0e7bcbc2bd5917a26d1d536ab5
1c1f34d312f8248445fee7744969ef87ce04790ff1e6f17b4320b6e996326e0c
05271cbb1532ba195bd0553ef409784a772b45ada5a83eb4031039b87d9cf0eb
6bef2820bc1460cc9f4dd18aeed09f9602f80ba382fe856062a3330093f4d2fb
```

## Verified native code path

The executed production archive SHA256 was freshly verified as
`adfc15617878f3592f3bd49c37fd69ef7b94f8e4e2d5b177e409a2e42f7e1bb7`.
Selected source members were read from that archive and matched to `source-manifest.json`.

1. Soup's `layer_stream_runtime.py:2499,2565` stamps the NF4 model with
   `is_loaded_in_4bit=True`. Its `build_streamed_model` wraps LoRA, then materializes meta
   adapters (`3619-3620`). `materialize_meta_adapters:2694-2701` explicitly creates FP32
   storage for missing LoRA tensors. See the
   [pinned Soup source](https://github.com/SoupTeam/soup-rnd/blob/e0d47e0dfb76a932e436a7034d2f655b46d86788/src/soup_cli/utils/layer_stream_runtime.py#L2673-L2703).
   This source member SHA256 is
   `5f770b012278ac12e95948aae76b3922804a37d3fcda1b42cd01071dbcd27ede`.
2. The ordinary Soup setup invokes TRL `SFTTrainer` at `trainer/sft.py:1234`; that archive
   member SHA256 is `139def2a7de226bbb0ee71a93e2675c95d2aae95cc83fbaf9123cfd53e9b44d9`.
   The frozen constraints pin TRL 0.29.1, PEFT 0.20.0, Transformers 5.17.0 and Torch
   2.8.0+cu128. The constraints file SHA256 is
   `e287a240d988272fe7d8365a9d166c8f275fb9f591d6203a843c36525b9ae606`.
3. **TRL 0.29.1 `SFTTrainer.__init__:782-785` explicitly converts every trainable
   parameter to BF16 when the model has a 4-bit or 8-bit load marker.** The dense model
   does not enter this branch. This conditional is independent of whether the caller
   supplied a new PEFT config. See the
   [version-pinned TRL implementation](https://github.com/huggingface/trl/blob/v0.29.1/trl/trainer/sft_trainer.py#L777-L785).
   The primary raw source was fetched directly; full file SHA256:
   `0c3a1a67e479a2b7037010844882b3170af3e8df856fe37ec1b9942e4e3c6544`.
4. The frozen capture initializer writes random values into existing parameters using
   `copy_`, preserving their destination dtype (`liger_streaming_parity.py:25-35`).
   Consequently, common seeds and shapes do not produce a dtype-identical cross-format
   initial state. That archive member SHA256 is
   `5408fef27888db2f4608ab14e3e11ea98746f846e38192ab7dbeb5dfb432960b`.

The code explains the observed native dtype split. This audit did not retain a separate
before/after execution trace inside TRL initialization; the direct evidence is the final
raw dtype inventories plus the version-pinned conditional source path.

## What these results establish

`independent-replay-midflight.json` rejects the cross-format diagnostic at the first final
adapter's shape/dtype guard. It records neither a numeric-gate failure nor a numeric-gate
pass for BF16 versus NF4. Keep that result unchanged.

The seven same-format qualification rows each record bitwise-equal primary and semantic
replays: dense RAM counts 0/4/5/6, NF4 RAM counts 0/34, and NF4 disk count 0 against its
NF4 RAM reference. The two RAM count-0 rows are self-reference controls. These results
still support the tested within-format residency/storage correctness; they do not prove
general model quality or cross-format equivalence.

Dense-to-NF4 memory/timing differences describe two native training configurations.
They cannot isolate the contribution of base-weight quantization alone, because adapter,
gradient and potentially optimizer-state precision also differ. No matched-precision
BF16-to-NF4 quality claim follows. A future controlled precision study would be a new
experiment; silently casting retained evidence is not a repair of this one.

## Older model is also a different workload

The exact primary [OpenLLaMA-7B-v2 config at revision
e5961def23172a2384543940e773ab676033c963](https://huggingface.co/openlm-research/open_llama_7b_v2/blob/e5961def23172a2384543940e773ab676033c963/config.json)
was fetched directly: vocabulary 32,000, 32 layers, hidden width 4,096; config SHA256
`a184b02448fd8164d686a73262846759a86862b8ee0d1ef141d6289aacb892e2`.
The current Qwen3-8B traces have output width 151,936, about 4.748 times larger. This is
an additional workload difference, not a profiled explanation for old-versus-new speedups.
No causal operator profile or universal scaling claim is established here.
