"""Rebind unchanged prepared bytes after reboot; controls only, no model execution."""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

source = Path('/root/d3-public-trainer-development-r2')
sys.path[:0] = [str(source), str(source / 'src'), str(source / 'benchmarks/harness')]
out = Path('/root/d3-public-trainer-preparation-01/actual-shard-controls-after-restart-01')
if len(sys.argv) > 1 and sys.argv[1] == 'foreign':
    from d3_f1_controls import foreign
    foreign(out / 'controls')
    raise SystemExit()

from d3_f1_controls import watch
from d3_f1_mapping_probe import discover_guest
from benchmarks.harness.d3_trainer_series import verify_host
from soup_cli.utils.layer_shard import expert_paths, read_shard_index

out.mkdir(exist_ok=False)
original = Path('/root/d3-public-trainer-preparation-01/prepared-02/prepared-final.json')
prepared = json.loads(original.read_text())
rule = json.loads(Path('/root/d3-public-trainer-rule-r2-readiness.json').read_text())
verify_host(rule, prepared)
seen = {}
new_files = {}
for name, expected in prepared['files'].items():
    path = Path(name)
    info = path.stat()
    key = (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns)
    if key not in seen:
        digest = hashlib.sha256()
        with path.open('rb') as stream:
            for block in iter(lambda: stream.read(8 * 2**20), b''):
                digest.update(block)
        seen[key] = digest.hexdigest()
    assert seen[key] == expected['sha256'], name
    new_files[name] = dict(sha256=seen[key], bytes=info.st_size, st_dev=info.st_dev,
                           inode=info.st_ino, mtime_ns=info.st_mtime_ns)
paths = []
for row in prepared['codecs'].values():
    paths += [Path(path) for path in expert_paths(row['shards'], read_shard_index(row['shards'])).values()]
assert len(paths) == 48
mapping = discover_guest(paths)
(out / 'mapping.json').write_text(json.dumps(mapping, indent=2) + '\n')
subprocess.run(['systemd-run', '--unit=d3-public-trainer-foreign-restart-control-01',
                '--property=Type=exec', '/root/d3-trainer-venv/bin/python',
                '/root/d3-public-trainer-restart-controls.py', 'foreign'], check=True)
report = watch(out / 'mapping.json', out / 'controls')
assert report['status'] == 'controls_passed'
for name, expected in new_files.items():
    info = Path(name).stat()
    assert (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns) == (
        expected['st_dev'], expected['inode'], expected['bytes'], expected['mtime_ns']), name
old_boot = prepared['boot_id']
prepared['boot_id'] = Path('/proc/sys/kernel/random/boot_id').read_text().strip()
prepared['files'] = new_files
prepared['restart_revalidation'] = dict(
    original_manifest=str(original), original_manifest_sha256=hashlib.sha256(original.read_bytes()).hexdigest(),
    previous_boot=old_boot, current_boot=prepared['boot_id'], unchanged_input_hashes=len(new_files),
    controls=str(out / 'controls/report.json'), new_model_execution=False,
    prior_failed_session_and_marker_preserved=True)
new_path = original.with_name('prepared-after-restart-r2.json')
assert not new_path.exists()
new_path.write_text(json.dumps(prepared, indent=2) + '\n')
(out / new_path.name).write_bytes(new_path.read_bytes())
(out / 'revalidation.json').write_text(json.dumps(prepared['restart_revalidation'], indent=2) + '\n')
print(json.dumps(dict(status='revalidated_after_restart', files=len(new_files), shards=48,
                     boot=prepared['boot_id'], controls=[row['observed'] for row in report['controls']])), flush=True)
