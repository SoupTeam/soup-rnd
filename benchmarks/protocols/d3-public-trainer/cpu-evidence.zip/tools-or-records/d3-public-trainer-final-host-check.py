import sys,json,hashlib,subprocess
from pathlib import Path
source=Path('/root/d3-public-trainer-development-01')
sys.path[:0]=[str(source),str(source/'src')]
from benchmarks.harness.d3_trainer_series import verify_prepared,verify_host
rule=json.loads(Path('/root/d3-public-trainer-rule-bound-20261029.json').read_text())
path=Path('/root/d3-public-trainer-preparation-01/prepared-02/prepared-final.json')
prepared=verify_prepared(path,rule)
verify_host(rule,prepared)
result=dict(status='prepared_data_and_host_identities_verified',formal_execution_started=False,
 pretrained_model_executed=False,prepared_files=len(prepared['files']),
 prepared_manifest=str(path),prepared_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
 boot_id=prepared['boot_id'],gpu=prepared['gpu'],software=prepared['software'],
 memory_info=Path('/proc/meminfo').read_text(),
 disk_free=subprocess.check_output(['df','-B1','/root'],text=True))
Path('/root/d3-public-trainer-final-host-check.json').write_text(json.dumps(result,indent=2)+'\n')
print(result['status'],flush=True)
