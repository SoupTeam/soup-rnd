"""Collect setup and synthetic launcher evidence; never execute a pretrained model."""
import hashlib,json,sys,zipfile
from pathlib import Path

base=Path('/root/d3-public-trainer-preparation-01')
source=Path('/root/d3-public-trainer-development-01')
final=Path('/root/d3-public-trainer-launcher-selftest-03/status.json')
state=json.loads(final.read_text())
if state['status']!='synthetic_launcher_checks_passed' or state['numerical_count']!=36 or state['profile_count']!=18:
    raise RuntimeError('final synthetic launcher has not completed all declared controls/profiles')
original=base/'prepared-02/prepared.json'
prepared=json.loads(original.read_text())
path=Path(prepared['rows_path']);st=path.stat()
prepared['files'][str(path)]=dict(sha256=hashlib.sha256(path.read_bytes()).hexdigest(),bytes=st.st_size,
    st_dev=st.st_dev,inode=st.st_ino,mtime_ns=st.st_mtime_ns)
prepared['status']='prepared_actual_shard_controls_passed'
prepared['metadata_enrichment']='Add immutable input-row JSON identity; original preparation manifest retained. No weights/datasets/factors were regenerated.'
manifest=original.with_name('prepared-final.json')
with manifest.open('x') as f: json.dump(prepared,f,indent=2);f.write('\n')
entries={}
natives={}
def add(path,name):
    path=Path(path)
    if path.is_file():
        if '/positive/oracle/' in name and path.suffix=='.safetensors':
            natives[name]=path
            return
        if name in entries: raise RuntimeError('duplicate archive path '+name)
        entries[name]=path

for path in base.rglob('*'):
    if not path.is_file() or '.cache' in path.parts: continue
    rel=path.relative_to(base)
    if 'checkpoint' in path.parts: continue
    if path.suffix=='.safetensors' and path.name!='initial-adapters.safetensors': continue
    add(path,'preparation/'+rel.as_posix())
for number in ('01','02','03'):
    root=Path('/root/d3-public-trainer-launcher-selftest-'+number)
    for path in root.rglob('*'):
        if not path.is_file() or 'checkpoint' in path.parts or '__pycache__' in path.parts: continue
        add(path,'synthetic-'+number+'/'+path.relative_to(root).as_posix())
    add(str(root)+'.log','logs/'+root.name+'.log')
for name in ('d3-public-trainer-download-01.log','d3-public-trainer-prepare-01.log',
             'd3-public-trainer-prepare-02.log','d3-public-trainer-controls-01.log',
             'd3-public-trainer-download-58145733.py','d3-public-trainer-controls-58145733.py',
             'd3-loss-diagnostic.py','d3-public-trainer-selftest-58145733.py',
             'd3-public-trainer-selftest-02.py','d3-trainer-cuda-development-58145733.py',
             'd3-public-trainer-engine-development-02.zip',
             'd3-public-trainer-engine-development-03.zip',
             'd3-public-trainer-engine-development-04.zip'):
    add('/root/'+name,'tools-or-logs/'+name)
for folder in ('src','benchmarks/harness'):
    for path in (source/folder).rglob('*.py'):
        add(path,'source/'+path.relative_to(source).as_posix())
for path in (source/'benchmarks/protocols/d3-public-trainer').glob('*.json'):
    add(path,'source/'+path.relative_to(source).as_posix())
weights=Path('/root/d3-trainer-development-01/synthetic-checkpoint')
for path in weights.iterdir():
    if path.suffix!='.safetensors': add(path,'synthetic-fixture/'+path.name)
meta=base/'synthetic-weights-identity.json'
meta.write_text(json.dumps(dict(
 sha256='716a43a33905f83daa4c79681a18a4e772ce5df00b2a7ed7cd06940873697a39',
 bytes=(weights/'model.safetensors').stat().st_size,
 checkpoint_included=False, pretrained=False,
 reproduction='Retained original random-weight generator: tools-or-logs/d3-trainer-cuda-development-58145733.py, seed 71, exact pinned environment.'),indent=2)+'\n')
add(meta,'synthetic-fixture/weights-identity.json')
supplement=Path('/root/d3-public-trainer-native-supplement-20261029.zip')
native_hashes={}
with zipfile.ZipFile(supplement,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for name,path in natives.items():
        data=path.read_bytes()
        native_hashes[name]=hashlib.sha256(data).hexdigest()
        archive.writestr(name,data)
    archive.writestr('MANIFEST.json',json.dumps(native_hashes,indent=2)+'\n')
receipt=base/'native-supplement.json'
receipt.write_text(json.dumps(dict(filename=supplement.name,bytes=supplement.stat().st_size,
    sha256=hashlib.sha256(supplement.read_bytes()).hexdigest(),files=native_hashes,
    scope='Synthetic launcher development native tensors; not pretrained experiment results.',
    payload_in_main_setup_archive=False,retention='Download and verify locally before removing host; not claimed as Git-published tensor payloads.'),indent=2)+'\n')
add(receipt,'native-supplement.json')
output=Path('/root/d3-public-trainer-setup-evidence-20261029.zip')
hashes={}
with zipfile.ZipFile(output,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for name,path in entries.items():
        digest=hashlib.sha256()
        with path.open('rb') as inp,archive.open(name,'w',force_zip64=True) as out:
            while chunk:=inp.read(8*2**20): digest.update(chunk);out.write(chunk)
        hashes[name]=digest.hexdigest()
    archive.writestr('MANIFEST.json',json.dumps(hashes,indent=2)+'\n')
print(json.dumps(dict(path=str(output),files=len(hashes),bytes=output.stat().st_size,
 sha256=hashlib.sha256(output.read_bytes()).hexdigest(),pretrained_model_executed=False),indent=2))
