import os
import subprocess
import zipfile
from pathlib import Path

target = Path('/root/d3-ci-pip')
target.mkdir(exist_ok=False)
with zipfile.ZipFile('/root/d3-ci-pip.zip') as archive:
    for name in archive.namelist():
        destination = target / name
        assert os.path.commonpath([str(destination.resolve()), str(target.resolve())]) == str(target)
    archive.extractall(target)
environment = dict(os.environ, PYTHONPATH=str(target))
python = '/root/d3-trainer-venv/bin/python'
subprocess.run([python, '-m', 'pip', 'install', '--no-deps', '--target', '/root/d3-ci-libraries',
                '--index-url', 'https://download.pytorch.org/whl/cpu', 'torch==2.15.0+cpu'], env=environment, check=True)
subprocess.run([python, '-m', 'pip', 'install', '--no-deps', '--target', '/root/d3-ci-libraries',
                'transformers==5.21.0', 'peft==0.21.2'], env=environment, check=True)
environment.update(PYTHONPATH='/root/d3-ci-libraries:/root/d3-ci-linux-tests-01/src',
                   OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', CUDA_VISIBLE_DEVICES='',
                   HF_HUB_OFFLINE='1', HF_DATASETS_OFFLINE='1')
root = Path('/root/d3-ci-linux-tests-01')
with (root / 'ci-version-tests.log').open('w') as log:
    result = subprocess.run([python, '-m', 'pytest',
        'tests/test_d3_trainer_integration.py::test_public_builder_loss_gradients_updates_and_close',
        'tests/test_issue820_windows_symlink_open_nofollow.py', '-q', '--no-cov', '--tb=long',
        '--junitxml=ci-version-tests.xml'], cwd=root, env=environment, stdout=log, stderr=subprocess.STDOUT)
print('CPU CI-version tests exit:', result.returncode, flush=True)
print((root / 'ci-version-tests.log').read_text()[-25000:], flush=True)
