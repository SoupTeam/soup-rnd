import hashlib
import json
import os
import subprocess
import zipfile
from pathlib import Path

root = Path('/root/d3-ci-linux-tests-01')
root.mkdir(exist_ok=False)
with zipfile.ZipFile('/root/d3-ci-linux-tests.zip') as archive:
    manifest = json.loads(archive.read('MANIFEST.json'))
    assert set(archive.namelist()) == set(manifest) | {'MANIFEST.json'}
    for name, expected in manifest.items():
        target = root / name
        assert os.path.commonpath([str(target.resolve()), str(root.resolve())]) == str(root.resolve())
        data = archive.read(name)
        assert hashlib.sha256(data).hexdigest() == expected, name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
environment = dict(os.environ, OMP_NUM_THREADS='1', MKL_NUM_THREADS='1',
                   CUDA_VISIBLE_DEVICES='', HF_HUB_OFFLINE='1', HF_DATASETS_OFFLINE='1',
                   PYTHONPATH=str(root / 'src'))
command = ['/root/d3-trainer-venv/bin/python', '-m', 'pytest',
           'tests/test_d3_trainer_integration.py::test_public_builder_loss_gradients_updates_and_close',
           'tests/test_issue820_windows_symlink_open_nofollow.py',
           '-q', '--no-cov', '--tb=long', '--junitxml=linux-results.xml']
with (root / 'linux-tests.log').open('w') as log:
    process = subprocess.run(command, cwd=root, env=environment, stdout=log, stderr=subprocess.STDOUT)
print(json.dumps({'exit': process.returncode, 'root': str(root), 'kind': 'synthetic CPU CI reproduction; no pretrained run'}), flush=True)
print((root / 'linux-tests.log').read_text()[-20000:], flush=True)
