import hashlib
import json
import zipfile
from pathlib import Path
from xml.etree import ElementTree

root = Path('C:/ml/soup/soup-rnd-d3')
work = Path('C:/ml/soup/work')
folder = root / 'benchmarks/protocols/d3-public-trainer'
report = work / 'd3-r2-final-cpu.xml'
suite = ElementTree.parse(report).getroot()
cases = suite.findall('.//testcase')
assert len(cases) == 74, len(cases)
assert not suite.findall('.//failure') and not suite.findall('.//error')
assert (work / 'd3-r2-final-ruff.log').read_text().strip() == 'All checks passed!'

requirements_path = folder / 'requirements.json'
requirements = json.loads(requirements_path.read_text(encoding='utf-8'))
dependencies = requirements['dependencies']
dependencies['snapshot_context'] = 'working_head and pending_main_merge describe the retained pre-operator-commit snapshot'
dependencies['completed_merge_head'] = 'cd6515ac503b15a111050b35db5c33768d506a9b'
dependencies['current_note'] = 'The operator completed the merge, including A3. The first formal session failed; only corrective benchmark/control code and evidence now await another commit. B1.3 acceptance is not inferred.'
requirements['open_full_task_items'][0] = json.loads((folder / 'protocol-draft.json').read_text())['separate_full_task_items'][0]
requirements_path.write_text(json.dumps(requirements, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')

files = {}
for pattern in ('d3-meta-eval*.log', 'd3-meta-eval*.xml', 'd3-r2-final*.log', 'd3-r2-final*.xml'):
    for path in work.glob(pattern):
        files['logs/' + path.name] = path.read_bytes()
names = [
    'benchmarks/harness/d3_trainer_gate.py',
    'benchmarks/harness/d3_trainer_protocol.py',
    'benchmarks/harness/d3_trainer_selftest.py',
    'benchmarks/harness/d3_trainer_series.py',
    'benchmarks/harness/d3_trainer_analysis.py',
    'tests/test_d3_trainer_gate.py',
    'tests/test_d3_trainer_protocol.py',
    'tests/test_d3_trainer_analysis.py',
    'benchmarks/protocols/d3-public-trainer/verify_evidence.py',
]
for name in names:
    files['source/' + name] = (root / name).read_bytes()
for name in [
    'd3-create-untied-fixture.py', 'd3-collect-untied-r2.py',
    'd3-package-untied-r2.py', 'd3-public-trainer-r2-host-check.py',
    'd3-finalize-r2-metadata.py', 'd3-package-r2-cpu.py',
]:
    files['operations/' + name] = (work / name).read_bytes()
files['receipts/final-host-check.json'] = (folder / 'final-host-check.json').read_bytes()
files['receipts/protocol-draft.json'] = (folder / 'protocol-draft.json').read_bytes()
files['receipts/untied-fixture.json'] = (folder / 'untied-fixture.json').read_bytes()
files['receipts/previous-attempt.json'] = (folder / 'previous-attempt.json').read_bytes()
hashes = {name: hashlib.sha256(data).hexdigest() for name, data in files.items()}
with zipfile.ZipFile(folder / 'r2-cpu-evidence.zip', 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name, data in sorted(files.items()):
        archive.writestr(name, data)
    archive.writestr('MANIFEST.json', json.dumps(hashes, indent=2) + '\n')

verification = {
    'kind': 'corrective revision 2 prospective preparation verification; not an accepted pretrained comparison',
    'protocol_revision': 2,
    'previous_formal_execution_started': True,
    'previous_pretrained_model_executed': True,
    'previous_formal_source': 'cd6515ac503b15a111050b35db5c33768d506a9b',
    'previous_formal_status': 'fail',
    'previous_formal_started_cells': 1,
    'previous_formal_accepted_cells': 0,
    'revision_2_formal_execution_started': False,
    'revision_2_pretrained_model_executed': False,
    'full_task_accepted': False,
    'preparation_bindings': 8,
    'prepared_input_files': 157,
    'actual_expert_shards_mapped': 48,
    'actual_shard_controls': ['ok', 'ok', 'void'],
    'corrective_synthetic': {
        'kind': 'four-layer untied random-weight OLMoE; not pretrained',
        'numerical_cells_passed': 36,
        'cuda_profiles_passed': 18,
        'streamed_embedding_meta': True,
        'streamed_large_boundaries': 2,
        'prototype_rule': 'tested-r2-numerical-recipe.json',
        'note': 'The developmental run used the retained revision-1 numerical recipe with the corrected gate/self-test. Revision-2 planner/readiness changes are pure CPU controls, separately tested. All production sources and executed numerical helpers match the new receipt.',
    },
    'corrective_cpu': {
        'tests_passed': 74,
        'junit_cases': len(cases),
        'cpu_archive_payloads': len(files),
        'full_repository_ruff': 'passed for src/soup_cli, scripts, tests; selected new harness/verifier also clean',
        'prior_regression': 'untied meta-input guard fails before correction and passes after',
    },
    'historical_cpu': {
        'broad_passed': 999, 'broad_skipped': 8, 'gpu_deselected': 116,
        'rerun_after_correction': False,
        'production_src_files_changed_by_correction': 0,
    },
    'published_archives': {
        'unchanged_setup_payloads': 6731, 'setup_nested_crcs': 3,
        'unchanged_cpu_payloads': 621,
        'corrective_untied_payloads': 3568,
        'corrective_cpu_payloads': len(files),
        'retained_full_untied_payloads_checked': 3867,
        'retained_full_failed_attempt_payloads_checked': 26,
    },
    'actual_host_and_prepared_full_hash_check': 'passed after the corrective synthetic preflight; no active CUDA workload',
    'remaining_launch_blockers': [
        'operator commits and pushes corrective source/rule/evidence',
        'canonical committed source export/freeze from the new clean checkout',
    ],
    'project_commit_or_push_performed': False,
    'scope': 'No current-head full repository pytest/CI, accepted pretrained trainer comparison, production default or final D3 acceptance is claimed.',
}
(folder / 'verification.json').write_text(json.dumps(verification, indent=2) + '\n', encoding='utf-8', newline='\n')
for directory in [folder, root / 'benchmarks/results/d3-public-trainer-attempt-01-cd6515ac']:
    manifest = {
        path.name: hashlib.sha256(path.read_bytes()).hexdigest()
        for path in sorted(directory.iterdir())
        if path.is_file() and path.name not in ('SHA256SUMS.json', '.gitattributes')
    }
    # Attributes are included too: publication bytes and their normalization policy are both pinned.
    manifest['.gitattributes'] = hashlib.sha256((directory / '.gitattributes').read_bytes()).hexdigest()
    (directory / 'SHA256SUMS.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'cpu_tests': len(cases), 'cpu_payloads': len(files), 'protocol_hashes': len(json.loads((folder / 'SHA256SUMS.json').read_text()))}, indent=2))
