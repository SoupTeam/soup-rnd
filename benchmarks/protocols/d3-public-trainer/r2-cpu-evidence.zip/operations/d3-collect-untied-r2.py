"""Retain all corrective synthetic records; no pretrained model execution."""
import hashlib,json,zipfile
from pathlib import Path
root=Path('/root/d3-public-trainer-untied-selftest-01')
source=Path('/root/d3-public-trainer-development-r2')
state=json.loads((root/'status.json').read_text())
if state['status']!='synthetic_launcher_checks_passed' or (state['numerical_count'],state['profile_count'])!=(36,18):
 raise ValueError('untied launcher not complete')
expected='541a84fa8513d02da3381a8c2fbc83efe4e3ff89975d958f0cc3505dc91b550d'
if state['fixture']!=dict(layers=4,experts=4,vocab=64,tie_word_embeddings=False,weight_sha256=expected):
 raise ValueError('wrong fixture')
entries={}
for path in root.rglob('*'):
 if path.is_file() and 'checkpoint' not in path.parts and '__pycache__' not in path.parts:
  entries['evidence/'+path.relative_to(root).as_posix()]=path
for group in ('src','benchmarks/harness'):
 for path in (source/group).rglob('*.py'):
  entries['tested-source/'+path.relative_to(source).as_posix()]=path
entries['tested-numerical-recipe.json']=source/'benchmarks/protocols/d3-public-trainer/protocol-draft.json'
for name in ('d3-create-untied-fixture.py','d3-create-untied-fixture.log','d3-public-trainer-untied-selftest-01.log','d3-meta-eval-development-r2.zip','d3-meta-eval-extract-r2.py'):
 entries['tools-or-logs/'+name]=Path('/root')/name
for path in Path('/root/d3-public-trainer-untied-fixture-01').iterdir():
 if path.is_file() and path.suffix!='.safetensors':entries['fixture/'+path.name]=path
output=Path('/root/d3-public-trainer-untied-full-r2.zip');hashes={}
with zipfile.ZipFile(output,'x',zipfile.ZIP_DEFLATED,compresslevel=4) as z:
 for name,path in entries.items():
  digest=hashlib.sha256()
  with path.open('rb') as inp,z.open(name,'w',force_zip64=True) as out:
   while chunk:=inp.read(8*2**20):digest.update(chunk);out.write(chunk)
  hashes[name]=digest.hexdigest()
 z.writestr('MANIFEST.json',json.dumps(hashes,indent=2)+'\n')
digest=hashlib.sha256()
with output.open('rb') as stream:
 for block in iter(lambda:stream.read(8*2**20),b''):digest.update(block)
receipt=dict(path=str(output),filename=output.name,bytes=output.stat().st_size,
 sha256=digest.hexdigest(),payloads=len(hashes),formal_execution=False,
 pretrained_model_executed=False,numerical_cells=36,profiles=18,fixture=state['fixture'])
Path('/root/d3-public-trainer-untied-collection-r2.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2),flush=True)
