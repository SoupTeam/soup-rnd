import hashlib,json,zipfile
from pathlib import Path
work=Path('C:/ml/soup/work');folder=Path('C:/ml/soup/soup-rnd-d3/benchmarks/protocols/d3-public-trainer')
receipt=json.loads((work/'d3-public-trainer-untied-collection-r2.json').read_text())
path=work/receipt['filename'];digest=hashlib.sha256()
with path.open('rb') as stream:
 for block in iter(lambda:stream.read(8*2**20),b''):digest.update(block)
assert digest.hexdigest()==receipt['sha256'] and path.stat().st_size==receipt['bytes']
with zipfile.ZipFile(path) as archive,zipfile.ZipFile(folder/'untied-preflight.zip','x',zipfile.ZIP_DEFLATED) as out:
 manifest=json.loads(archive.read('MANIFEST.json'));published={};omitted={}
 for name,expected in manifest.items():
  skip=name.endswith('.safetensors') and not (name.endswith('initial-adapters.safetensors') or name.endswith('/positive/adapter/adapter_model.safetensors'))
  h=hashlib.sha256()
  if skip:
   with archive.open(name) as stream:
    for block in iter(lambda:stream.read(8*2**20),b''):h.update(block)
  else:
   data=archive.read(name);h.update(data)
  assert h.hexdigest()==expected,name
  if skip:omitted[name]=expected
  else:out.writestr(name,data);published[name]=expected
 archive_receipt=dict(filename=receipt['filename'],bytes=receipt['bytes'],sha256=receipt['sha256'],full_payloads=len(manifest),payload_in_git=False,omitted_payloads=omitted,
   scope='Uncommitted four-layer untied synthetic launcher correction; not pretrained results.')
 data=(json.dumps(archive_receipt,indent=2)+'\n').encode()
 out.writestr('FULL-ARCHIVE-RETENTION.json',data);published['FULL-ARCHIVE-RETENTION.json']=hashlib.sha256(data).hexdigest()
 out.writestr('MANIFEST.json',json.dumps(published,indent=2)+'\n')
 (folder/'launcher-self-test.json').write_bytes(archive.read('evidence/status.json'))
 (folder/'untied-fixture.json').write_bytes(archive.read('fixture/fixture-identity.json'))
 (folder/'untied-full-archive.json').write_text(json.dumps(archive_receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
 (folder/'tested-r2-numerical-recipe.json').write_bytes(archive.read('tested-numerical-recipe.json'))
print(json.dumps(dict(published_payloads=len(published),full_payloads_verified=len(manifest),published_bytes=(folder/'untied-preflight.zip').stat().st_size,full_archive_sha256=receipt['sha256']),indent=2))
