import sys, json, hashlib, subprocess
from pathlib import Path

source = Path('/root/d3-public-trainer-development-r2')
sys.path[:0] = [str(source), str(source / 'src')]
from benchmarks.harness.d3_trainer_series import verify_prepared, verify_host

rule = json.loads(Path('/root/d3-public-trainer-rule-r2-readiness.json').read_text())
path = Path('/root/d3-public-trainer-preparation-01/prepared-02/prepared-final.json')
prepared = verify_prepared(path, rule)
verify_host(rule, prepared)
result = dict(
    status='prepared_data_and_host_identities_verified',
    protocol_revision=2,
    revision_2_formal_execution_started=False,
    previous_formal_source='cd6515ac503b15a111050b35db5c33768d506a9b',
    previous_formal_status='fail',
    previous_formal_accepted_cells=0,
    operation='read-only file/software/hardware identity check; no model forward or training',
    prepared_files=len(prepared['files']),
    prepared_manifest=str(path),
    prepared_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
    boot_id=prepared['boot_id'], gpu=prepared['gpu'], software=prepared['software'],
    memory_info=Path('/proc/meminfo').read_text(),
    disk_free=subprocess.check_output(['df', '-B1', '/root'], text=True),
    cuda_processes=subprocess.check_output([
        'nvidia-smi', '--query-compute-apps=pid,process_name,used_gpu_memory',
        '--format=csv,noheader'], text=True),
)
assert not result['cuda_processes'].strip(), result['cuda_processes']
Path('/root/d3-public-trainer-r2-host-check.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': result['status'], 'prepared_files': result['prepared_files'],
                  'active_cuda_workloads': 0}), flush=True)
