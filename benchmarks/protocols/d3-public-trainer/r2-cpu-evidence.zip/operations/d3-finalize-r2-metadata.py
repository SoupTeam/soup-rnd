import hashlib
import json
import shutil
from pathlib import Path

root = Path('C:/ml/soup/soup-rnd-d3')
folder = root / 'benchmarks/protocols/d3-public-trainer'
rule_path = folder / 'protocol-draft.json'
rule = json.loads(rule_path.read_text())
receipt = folder / 'launcher-self-test.json'
status = json.loads(receipt.read_text())
assert status['fixture'] == rule['required_launcher_fixture']
assert status['status'] == 'synthetic_launcher_checks_passed'
assert (status['numerical_count'], status['profile_count']) == (36, 18)
rule['preparation']['launcher_self_test'] = {
    'path': receipt.relative_to(root).as_posix(),
    'sha256': hashlib.sha256(receipt.read_bytes()).hexdigest(),
}
rule['status'] = 'revision_2_prepared_for_operator_commit_after_failed_first_session'
rule['execution_enabled'] = True
rule['promotion'] = (
    'Revision 2 has all eight preparation bindings, the corrected numerical runtime '
    'and passing untied four-layer synthetic controls. The first cd6515ac session '
    'failed and remains retained. This switch alone cannot launch: the operator '
    'must commit/push the corrective rule/source/evidence and export canonical '
    'Git blobs from a clean checkout. A new formal session requires that new '
    'source receipt and unchanged bound data/software/GPU/boot identities. '
    'No corrected-revision formal session has run.'
)
rule['separate_full_task_items'][0] = (
    'The public SFT/L2L integration is committed in cd6515ac; its first formal '
    'session failed the evaluation control. The corrective revision requires '
    'a new committed source freeze and an accepted pretrained trainer comparison.'
)
rule_path.write_text(json.dumps(rule, indent=2) + '\n', encoding='utf-8', newline='\n')
shutil.copyfile(
    root / 'benchmarks/results/d3-public-trainer-attempt-01-cd6515ac/failure.json',
    folder / 'previous-attempt.json',
)
if not (folder / 'revision-1-host-check.json').exists():
    shutil.copyfile(folder / 'final-host-check.json', folder / 'revision-1-host-check.json')
print(json.dumps({'status': rule['status'], 'launcher_hash': rule['preparation']['launcher_self_test']['sha256']}))
