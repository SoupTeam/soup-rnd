"""Create random untied four-layer weights; never loads/executes a pretrained model."""
import hashlib,json,gc
from pathlib import Path
import torch
from transformers import OlmoeConfig,OlmoeForCausalLM,PreTrainedTokenizerFast
from tokenizers import Tokenizer
from tokenizers.models import WordLevel
from tokenizers.pre_tokenizers import Whitespace

torch.set_num_threads(1);torch.manual_seed(71)
root=Path('/root/d3-public-trainer-untied-fixture-01');root.mkdir(exist_ok=False)
config=OlmoeConfig(hidden_size=2048,intermediate_size=1024,num_hidden_layers=4,
 num_attention_heads=16,num_key_value_heads=16,num_experts=4,num_experts_per_tok=2,
 vocab_size=64,max_position_embeddings=1024,output_router_logits=False,
 attention_dropout=0.0,tie_word_embeddings=False,eos_token_id=1,bos_token_id=2,pad_token_id=0)
model=OlmoeForCausalLM(config).to(dtype=torch.bfloat16);model.save_pretrained(root)
raw=Tokenizer(WordLevel({str(i):i for i in range(64)},unk_token='0'));raw.pre_tokenizer=Whitespace()
tokenizer=PreTrainedTokenizerFast(tokenizer_object=raw,pad_token='0',eos_token='1')
tokenizer.chat_template="{% for message in messages %}{{ message['content'] }}{% endfor %}"
tokenizer.save_pretrained(root)
del model;gc.collect()
path=root/'model.safetensors';digest=hashlib.sha256()
with path.open('rb') as stream:
 for block in iter(lambda:stream.read(8*2**20),b''):digest.update(block)
record=dict(kind='synthetic random-weight fixture, not pretrained',seed=71,
 layers=4,experts=4,hidden=2048,intermediate=1024,vocab=64,tie_word_embeddings=False,
 model_forward_executed=False,pretrained_model_loaded=False,
 weight_sha256=digest.hexdigest(),weight_bytes=path.stat().st_size,
 generator_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 config_sha256=hashlib.sha256((root/'config.json').read_bytes()).hexdigest())
(root/'fixture-identity.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2),flush=True)
