from __future__ import annotations
import gc, json, sys, traceback
from pathlib import Path

sys.path.insert(0, '/workspace/d3-precommit-check/src')
sys.path.insert(0, '/workspace/d3-precommit-check/benchmarks/harness')
from d3_training_model import open_training_model
from d3_cublas_grouped_probe import reference_policy
from d3_full_model import file_hash
import torch

root=Path('/workspace/d3-olmoe-training-prep-20261022/prepared')
library=Path('/workspace/d3-dev-venv/lib/python3.12/site-packages/nvidia/cu13/lib/libcublas.so.13')
report={'kind':'pre-commit OLMoE execution smoke; not formal D3 cells or performance evidence', 'status':'running','gpu':torch.cuda.get_device_name(0),'uuid':'GPU-46abdddd-2f6a-a368-5b31-a7d0c0a4a9ef','cublas_sha256':file_hash(library),'codecs':[],'formal_result':False}
out=Path('/workspace/d3-olmoe-training-prep-20261022/precommit-smoke.json')
def save(): out.write_text(json.dumps(report,indent=2)+'\n')
try:
 torch.backends.cuda.matmul.allow_tf32=False
 for codec in ('dense','nf4','nf4-dq'):
  folder=root/codec
  cfg=json.loads((folder/'config.json').read_text())
  ids=torch.randint(2,cfg['vocab_size'],(1,512),generator=torch.Generator().manual_seed(1234)).cuda()
  frames={}; peaks={}
  for mode in ('native','triton'):
   with reference_policy('cublaslt-no-splitk'):
    run=open_training_model(folder,mode=mode,device='cuda',library=library,retain_derivatives=True,seed=25,rank=4,lr=.5,native_rows_max=128)
    try:
     torch.cuda.reset_peak_memory_stats()
     outputs=run.step(ids); torch.cuda.synchronize()
     frame=run.frame(outputs); del outputs
     dispatch=run.check_dispatch()
     frames[mode]=frame
     peaks[mode]={'allocated':torch.cuda.max_memory_allocated(),'reserved':torch.cuda.max_memory_reserved(),'current':torch.cuda.memory_allocated()}
     if mode=='triton' and run.owner.gemm.stats()['grouped_matrices']<1: raise RuntimeError('Triton full-model smoke missed grouped GEMM')
     report['codecs'].append({'codec':codec,'mode':mode,'status':'step_ok','layers':dispatch['layers'],'peak':peaks[mode]})
     save()
    finally:
     run.close(); del run; gc.collect(); torch.cuda.empty_cache()
  if set(frames['native']) != set(frames['triton']) or any(not torch.equal(frames['native'][k],frames['triton'][k]) for k in frames['native']):
   raise RuntimeError(f'{codec}: native vs Triton one-step tensor mismatch')
  report['codecs'].append({'codec':codec,'comparison':'native_and_triton_all_captured_tensors_exact','status':'pass'})
  save(); del frames, ids; gc.collect(); torch.cuda.empty_cache()
 report['status']='smoke_passed_not_formal_measurement'
except BaseException:
 report['status']='smoke_failed_or_no_verdict'; report['traceback']=traceback.format_exc()
finally: save()
print(json.dumps(report,indent=2))
sys.exit(0 if report['status']=='smoke_passed_not_formal_measurement' else 1)

