# OLMoE trained-step preparation evidence

No formal D3 training measurement was run during preparation. The preserved initial bundle-preparation attempt failed because the generic mapper correctly rejected a container-visible overlay loop device after all three 16-layer bundles were made. The mapping was then repeated with the explicit overlay-loop opt-in; direct-read counter changes were observed on loop0 and not on the host NVMe counter. F1 baseline/own/foreign controls passed as baseline=ok, own=ok, foreign=void. The evidence does not certify physical-host disk isolation or identify the underlying SSD.

The runtime inventory pins the actual venv, CUDA wheel, driver, library versions and cuBLAS digest. The checkpoint is pinned to the immutable Hub revision and exact SHA-256s in download.json. Each bundle manifest and config are included; expert data hashes remain in the remote bundle manifests and are checked again on the server before each formal cell.
