"""Discover actual prepared shards and test F1; no model forward or timing."""
import json
from pathlib import Path
import subprocess
import sys
import traceback

ROOT=Path('/root/d3-vm-preflight/source')
OUT=Path('/root/d3-vm-model-instruments')
PREPARED=Path('/root/d3-prepared-57244283')
OUT.mkdir(exist_ok=False)
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'benchmarks/harness')]
from d3_f1_mapping_probe import MappingFailureError, discover_guest
from d3_f1_controls import watch

state={'status':'preparing','formal_execution':False}
try:
    status=json.loads(Path('/root/d3-vm-weights-02/status.json').read_text())
    assert status['status']=='bundles_prepared_mapping_and_full_shard_controls_still_required'
    paths=[path for codec in ('dense','nf4','nf4-dq')
           for path in sorted((PREPARED/codec).glob('experts_*.safetensors'))]
    assert len(paths)==48
    mapping=discover_guest(paths)
    (OUT/'mapping.json').write_text(json.dumps(mapping,indent=2)+'\n')
    foreign=OUT/'controls'
    subprocess.run(['systemd-run','--unit=d3-vm-model-foreign','--property=Type=exec',
                    '--setenv=PYTHONPATH='+str(ROOT/'benchmarks/harness'),sys.executable,
                    str(ROOT/'benchmarks/harness/d3_f1_controls.py'),'foreign',
                    '--session',str(foreign)],check=True)
    controls=watch(OUT/'mapping.json',foreign)
    assert controls['status']=='controls_passed', controls.get('traceback')
    expected=sum(path.stat().st_size//4096*4096 for path in paths)
    assert controls['controls'][1]['direct_bytes']==expected
    assert expected>16*2**30
    for name,path in [('mapping.json',OUT/'mapping.json'),('controls.json',foreign/'report.json')]:
        (PREPARED/name).write_bytes(path.read_bytes())
    state.update(status='actual_shard_controls_passed',mapped_files=len(paths),
                 complete_shard_read_bytes=expected)
except BaseException as exc:
    state.update(status='failed',traceback=traceback.format_exc())
    if isinstance(exc,MappingFailureError):
        state['mapping_failure_evidence']=exc.evidence
finally:
    (OUT/'status.json').write_text(json.dumps(state,indent=2)+'\n')
