"""Prepare pinned dependencies only; never starts a formal model measurement."""
import json
import os
from pathlib import Path
import subprocess
import traceback

ROOT = Path('/root/d3-vm-environment')
ROOT.mkdir(exist_ok=False)
UV = '/root/.local/bin/uv'
PYTHON = '/root/d3-venv/bin/python'
state = {'status': 'preparing', 'formal_run_started': False}

def run(name, args):
    state['phase'] = name
    (ROOT / 'status.json').write_text(json.dumps(state, indent=2)+'\n')
    with (ROOT / (name+'.log')).open('x') as log:
        subprocess.run(args, env=dict(os.environ, UV_NO_CACHE='1'), stdout=log,
                       stderr=subprocess.STDOUT, check=True, timeout=1800)

try:
    run('python', [UV, 'venv', '--python', '3.12.15', '/root/d3-venv'])
    run('dependencies', [UV, 'pip', 'install', '--python', PYTHON,
         'torch==2.14.1', 'triton==3.8.0', 'transformers==5.19.0',
         'bitsandbytes==0.50.2', 'safetensors==0.8.0',
         'pytest', 'rich', 'numpy', 'psutil', 'accelerate', 'ruff'])
    run('pip-freeze', [UV, 'pip', 'freeze', '--python', PYTHON])
    state['status'] = 'environment_installed_cuda_smoke_still_required'
except BaseException:
    state['status'] = 'failed'
    state['traceback'] = traceback.format_exc()
finally:
    (ROOT / 'status.json').write_text(json.dumps(state, indent=2)+'\n')
