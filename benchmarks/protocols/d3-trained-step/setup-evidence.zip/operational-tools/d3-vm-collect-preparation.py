"""Archive instrument/development evidence only; omit model weights and private files."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

BASE=Path('/root')
SOURCE=BASE/'d3-vm-preflight/source'
PREPARED=BASE/'d3-prepared-57244283'
OUT=BASE/'d3-vm-preparation-evidence-57244283.zip'
evidence={}
def add(path,name):
    evidence[name]=path.read_bytes()

for name in ('mapping.json','controls.json'):
    add(PREPARED/name,name)
for folder in ('d3-vm-environment','d3-vm-smoke','d3-vm-smoke-02',
               'd3-vm-gemm-diagnostic','d3-vm-preflight-update-tests',
               'd3-vm-weights','d3-vm-weights-02','d3-vm-model-instruments'):
    for path in sorted((BASE/folder).rglob('*')):
        if path.is_file() and path.suffix in ('.json','.log','.xml'):
            add(path,str(path.relative_to(BASE)))
for path in sorted((BASE/'d3-vm-preflight').iterdir()):
    if path.is_file() and path.suffix=='.json':
        add(path,'fixture-control/'+path.name)
for name in ('d3-vm-instrument-preflight.py','d3-vm-prepare-environment.py',
             'd3-vm-smoke.py','d3-vm-smoke-02.py','d3-vm-prepare-weights.py',
             'd3-vm-prepare-weights-02.py','d3-vm-gemm-diagnostic.py',
             'd3-vm-model-instruments.py','d3-vm-collect-preparation.py',
             'd3-vm-smoke-support.zip','d3-vm-development-update-01.zip',
             'd3-vm-development-update-02.zip','d3-vm-development-update-03.zip'):
    add(BASE/name,'operational-tools/'+name)
add(SOURCE/'FROZEN-D3-SOURCE.json','initial-source/FROZEN-D3-SOURCE.json')
for name in ('SMOKE-SUPPORT-SHA256.json','DEVELOPMENT-UPDATE-SHA256.json',
             'DEVELOPMENT-UPDATE-02-SHA256.json','DEVELOPMENT-UPDATE-03-SHA256.json'):
    add(SOURCE/name,'initial-source/'+name)
for name,command in {
    'virtualization':['systemd-detect-virt'],
    'nvidia-smi':['nvidia-smi'],
    'lsblk':['lsblk','-o','NAME,MAJ:MIN,SIZE,TYPE,MOUNTPOINTS'],
    'kernel':['uname','-a'],
}.items():
    evidence['guest/'+name+'.txt']=subprocess.check_output(command)
for name,path in {'mountinfo':'/proc/self/mountinfo','cgroup':'/proc/self/cgroup',
                  'meminfo':'/proc/meminfo','diskstats':'/proc/diskstats',
                  'cgroup_io.stat':'/sys/fs/cgroup/io.stat'}.items():
    add(Path(path),'guest/'+name+'.txt')
manifest={name:hashlib.sha256(data).hexdigest() for name,data in evidence.items()}
with zipfile.ZipFile(OUT,'x',compression=zipfile.ZIP_DEFLATED) as archive:
    for name,data in evidence.items():archive.writestr(name,data)
    archive.writestr('SHA256SUMS.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(OUT) as archive:
    assert archive.testzip() is None
receipt={'path':str(OUT),'bytes':OUT.stat().st_size,'sha256':hashlib.sha256(OUT.read_bytes()).hexdigest(),
         'entries':len(manifest)+1,'kind':'preparation only; no trained-model session'}
(BASE/'d3-vm-preparation-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
