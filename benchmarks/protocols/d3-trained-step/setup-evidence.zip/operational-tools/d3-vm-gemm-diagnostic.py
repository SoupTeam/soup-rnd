"""Synthetic exhaustive GEMM mismatch localization; no model timing or verdict."""
import hashlib
import json
import os
from pathlib import Path
import sys
import traceback

ROOT=Path('/root/d3-vm-preflight/source')
OUT=Path('/root/d3-vm-gemm-diagnostic')
OUT.mkdir(exist_ok=False)
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'benchmarks/harness')]
from d3_cublas_grouped_probe import reference_policy
from soup_cli.utils.expert_group_gemm import GroupedGemm
import torch
library=Path(torch.__file__).parent.parent/'nvidia/cu13/lib/libcublas.so.13'
result={'kind':'synthetic GEMM correctness diagnostic; not formal model evidence',
        'status':'running','shape_cases':[]}
try:
    with reference_policy('cublaslt-no-splitk'), torch.no_grad():
        for inner in (1024,2048):
            for seed in (11,29):
                row={'inner':inner,'seed':seed,'mismatched_rows':[],'mismatch_details':[]}
                result['shape_cases'].append(row)
                gen=torch.Generator().manual_seed(seed)
                weights=[(torch.randn(2048,inner,generator=gen)*.2).cuda().bfloat16() for _ in range(4)]
                gemm=GroupedGemm(library,call_budget_bytes=64*2**20,native_olmoe_rows_max=128)
                try:
                    for start in range(0,513,4):
                        xs=[(torch.randn(n,inner,generator=gen)*.2).cuda().bfloat16()
                            for n in range(start,min(513,start+4))]
                        expected=[torch.nn.functional.linear(x,w) for x,w in zip(xs,weights)]
                        actual=gemm.linear(xs,weights[:len(xs)])
                        for n,want,got in zip(range(start,min(513,start+4)),expected,actual):
                            if not torch.equal(want,got):
                                row['mismatched_rows'].append(n)
                                row['mismatch_details'].append({'rows':n,'unequal':int((want!=got).sum()),
                                    'max_absolute':float((want.float()-got.float()).abs().max())})
                finally:
                    gemm.close()
                (OUT/'progress.json').write_text(json.dumps(result,indent=2)+'\n')
        result['status']='complete'
except BaseException:
    result.update(status='failed',traceback=traceback.format_exc())
finally:
    (OUT/'report.json').write_text(json.dumps(result,indent=2)+'\n')
