"""Prepare pinned OLMoE bundles after synthetic tests; no trained model execution."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import traceback

ROOT = Path('/root/d3-vm-preflight/source')
OUT = Path('/root/d3-vm-weights-02')
OUT.mkdir(exist_ok=False)
MODEL = Path('/root/d3-olmoe-pinned')
PREPARED = Path('/root/d3-prepared-57244283')
state = {'status':'waiting_for_smoke', 'formal_execution':False}

def save():
    (OUT/'status.json').write_text(json.dumps(state,indent=2)+'\n')

def digest(path):
    result=hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda:handle.read(8*2**20),b''):
            result.update(block)
    return result.hexdigest()

try:
    save()
    started=time.monotonic()
    while True:
        path=Path('/root/d3-vm-smoke-02/status.json')
        if path.exists():
            smoke=json.loads(path.read_text())
            if smoke['status']=='failed':
                raise RuntimeError('synthetic regression failed; no weight preparation')
            if smoke['status']=='synthetic_regressions_passed':
                break
        if time.monotonic()-started>1800:
            raise TimeoutError('smoke completion')
        time.sleep(5)
    os.environ['HF_HUB_DISABLE_XET']='1'
    from huggingface_hub import snapshot_download
    rule=json.loads((ROOT/'benchmarks/protocols/d3-trained-step/protocol.json').read_text())
    state.update(status='preparing',phase='download',model_id=rule['model_id'],
                 model_revision=rule['model_revision'])
    save()
    snapshot_download(repo_id=rule['model_id'],revision=rule['model_revision'],
                      local_dir=MODEL,allow_patterns=list(rule['checkpoint_files']),max_workers=3)
    state['phase']='hash-checkpoint'
    save()
    state['checkpoint_sha256']={name:digest(MODEL/name) for name in rule['checkpoint_files']}
    if state['checkpoint_sha256'] != rule['checkpoint_files']:
        raise RuntimeError('pinned checkpoint hash mismatch')
    sys.path[:0]=[str(ROOT/'src'),str(ROOT/'benchmarks/harness')]
    from d3_full_model_gate import prepare
    state['bundle_sha256']={}
    for codec in ('dense','nf4','nf4-dq'):
        state['phase']='prepare-'+codec
        save()
        prepare(argparse.Namespace(model_dir=MODEL,prepared=PREPARED,codec=codec,device='cuda'),{})
        state['bundle_sha256'][codec]=digest(PREPARED/codec/'bundle.json')
        save()
    state.update(status='bundles_prepared_mapping_and_full_shard_controls_still_required',
                 prepared=str(PREPARED))
except BaseException:
    state.update(status='failed',traceback=traceback.format_exc())
finally:
    save()
