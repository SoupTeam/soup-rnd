"""Run small synthetic regressions; no trained-model measurement or formal session."""
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import traceback
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path('/root/d3-vm-preflight/source')
OUT = Path('/root/d3-vm-smoke-02')
OUT.mkdir(exist_ok=False)
state = {'status':'running', 'formal_execution':False}

try:
    with zipfile.ZipFile('/root/d3-vm-smoke-support.zip') as archive:
        for name in archive.namelist():
            assert os.path.commonpath((str(ROOT),os.path.realpath(ROOT/name))) == str(ROOT)
        archive.extractall(ROOT)
    for name,digest in json.loads((ROOT/'SMOKE-SUPPORT-SHA256.json').read_text()).items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest() == digest
    with zipfile.ZipFile('/root/d3-vm-development-update-01.zip') as update:
        for name in update.namelist():
            assert os.path.commonpath((str(ROOT),os.path.realpath(ROOT/name))) == str(ROOT)
        update.extractall(ROOT)
    state['development_update_sha256']=json.loads((ROOT/'DEVELOPMENT-UPDATE-SHA256.json').read_text())
    for name,digest in state['development_update_sha256'].items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest() == digest
    import torch
    state['software'] = {'python':platform.python_version(), 'torch':torch.__version__,
                         'cuda':torch.version.cuda}
    state['software'].update({name:importlib.metadata.version(name) for name in
                             ('transformers','triton','bitsandbytes','safetensors')})
    state['gpu'] = subprocess.check_output(['nvidia-smi','--query-gpu=name,uuid,driver_version',
                                         '--format=csv,noheader'],text=True).strip()
    assert torch.cuda.is_bf16_supported(including_emulation=False)
    assert torch.cuda.get_device_properties(0).total_memory >= 23 * 2**30
    library = Path(torch.__file__).parent.parent/'nvidia/cu13/lib/libcublas.so.13'
    assert library.is_file()
    state['library'] = str(library)
    state['cublas_sha256'] = hashlib.sha256(library.read_bytes()).hexdigest()
    env = dict(os.environ, PYTHONPATH=os.pathsep.join((str(ROOT/'src'),str(ROOT/'benchmarks/harness'),str(ROOT))),
               D3_CUBLAS_LIBRARY=str(library),CUDA_VISIBLE_DEVICES='0')
    files = ['test_d3_expert_activation.py','test_d3_expert_derivatives.py',
             'test_d3_training_model.py','test_d3_grouped_compute.py',
             'test_d3_grouped_expert.py','test_d3_full_model.py',
             'test_f1_arm_validity.py','test_d3_f1_mapping.py',
             'test_d3_training_protocol.py','test_d3_training_analysis.py']
    state['test_source_sha256'] = {name:hashlib.sha256((ROOT/'tests'/name).read_bytes()).hexdigest()
                                  for name in files}
    (OUT/'status.json').write_text(json.dumps(state,indent=2)+'\n')
    with (OUT/'pytest.log').open('x') as log:
        run = subprocess.run([sys.executable,'-m','pytest',*['tests/'+name for name in files],
                    '-o','addopts=','-q','--tb=short','--junitxml='+str(OUT/'pytest.xml')],
                    cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1800)
    state['returncode'] = run.returncode
    if (OUT/'pytest.xml').exists():
        cases = list(ET.parse(OUT/'pytest.xml').iter('testcase'))
        state['cases'] = len(cases)
        state['passed'] = sum(not any(case.find(tag) is not None for tag in
                                     ('skipped','failure','error')) for case in cases)
        state['skipped'] = [{'name':case.attrib.get('name'), 'reason':case.find('skipped').attrib}
                           for case in cases if case.find('skipped') is not None]
    if run.returncode:
        raise RuntimeError('synthetic smoke regressions failed; formal session not started')
    state['status'] = 'synthetic_regressions_passed'
except BaseException:
    state['status']='failed'
    state['traceback']=traceback.format_exc()
finally:
    (OUT/'status.json').write_text(json.dumps(state,indent=2)+'\n')
