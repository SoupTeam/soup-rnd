"""Guest-disk diagnostic only; no D3 model result or formal session."""
import hashlib
import json
import mmap
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback
import zipfile

ROOT = Path('/root/d3-vm-preflight')
SOURCE = ROOT / 'source'
FIXTURE = ROOT / 'instrument-fixture.bin'
SIZE = 16 * 2**30
CHUNK = 4 * 2**20

def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + '\n')

def wait(name, seconds=300):
    started = time.monotonic()
    while not (ROOT / name).exists():
        if time.monotonic() - started > seconds:
            raise TimeoutError(name)
        time.sleep(.05)

def read_direct(count):
    fd = os.open(FIXTURE, os.O_RDONLY | os.O_DIRECT)
    try:
        with mmap.mmap(-1, CHUNK) as buf:
            for offset in range(0, count, CHUNK):
                if offset % SIZE == 0:
                    os.lseek(fd, 0, os.SEEK_SET)
                got = os.readv(fd, [buf])
                if got != CHUNK:
                    raise RuntimeError('short direct read')
    finally:
        os.close(fd)
    return count

def prepare():
    ROOT.mkdir(exist_ok=False)
    packet = Path('/root/d3-trained-step-6f9252a9.zip')
    digest = hashlib.sha256(packet.read_bytes()).hexdigest()
    assert digest == 'e12544899a77c6a627a9d23fc822e399b7edaff6ca0e5e85d7d32d3a9ebebdb0'
    SOURCE.mkdir()
    with zipfile.ZipFile(packet) as archive:
        for name in archive.namelist():
            assert os.path.commonpath((str(SOURCE), os.path.realpath(SOURCE / name))) == str(SOURCE)
        archive.extractall(SOURCE)
    block = os.urandom(CHUNK)
    with FIXTURE.open('xb', buffering=0) as handle:
        os.posix_fallocate(handle.fileno(), 0, SIZE)
        for offset in range(0, SIZE, CHUNK):
            handle.write(block)
        os.fsync(handle.fileno())
    subprocess.run(['sync'], check=True)
    save('fixture.json', {'bytes': SIZE, 'block_sha256': hashlib.sha256(block).hexdigest(),
                         'kind': 'synthetic instrument fixture, not model data',
                         'source_packet_sha256': digest})
    print('fixture_prepared', flush=True)

def foreign():
    save('foreign-ready.json', {'pid': os.getpid(), 'ppid': os.getppid()})
    wait('foreign-go')
    count = read_direct(4 * 2**30)
    save('foreign-done.json', {'pid': os.getpid(), 'ppid': os.getppid(), 'bytes': count})
    wait('foreign-release')

def watch():
    sys.path.insert(0, str(SOURCE / 'benchmarks/harness'))
    from arm_validity import ArmWatch, disk_device, disk_reads, other_disk_reads
    device = disk_device(str(FIXTURE))
    assert device == 'vda', device
    result = {'kind': 'VM instrument preflight; no model measurements', 'status': 'failed',
              'counter_scope': 'all guest-visible disks using unchanged F1 default sensors',
              'physical_host_isolation_certified': False,
              'device': device, 'pid': os.getpid(), 'ppid': os.getppid(), 'controls': []}
    save('before.json', {'diskstats': Path('/proc/diskstats').read_text(),
                         'cgroup_io_stat': Path('/sys/fs/cgroup/io.stat').read_text(),
                         'mountinfo': Path('/proc/self/mountinfo').read_text()})
    try:
        for index, (case, expected) in enumerate([('baseline','ok'), ('own_full_extent','ok'), ('foreign','void')]):
            if case == 'foreign':
                wait('foreign-ready.json')
            before = {'watched': disk_reads(device), 'other': other_disk_reads(device)}
            with ArmWatch(arm=case, round=0, run=index, model_path=str(FIXTURE)) as monitor:
                if case == 'baseline':
                    time.sleep(2)
                    count = 0
                elif case == 'own_full_extent':
                    count = read_direct(2 * SIZE)
                else:
                    (ROOT / 'foreign-go').touch(exist_ok=False)
                    wait('foreign-done.json')
                    count = json.loads((ROOT / 'foreign-done.json').read_text())['bytes']
            after = {'watched': disk_reads(device), 'other': other_disk_reads(device)}
            result['controls'].append({'case':case, 'expected':expected,
                'observed':monitor.record['outcome'], 'direct_bytes':count,
                'disk_before':before, 'disk_after':after, 'F1':monitor.record})
            save('progress.json', result)
            print(case, monitor.record['outcome'], flush=True)
            if monitor.record['outcome'] != expected:
                raise RuntimeError(f'{case} did not return {expected}')
        result['status'] = 'controls_passed'
    except BaseException:
        result['traceback'] = traceback.format_exc()
        raise
    finally:
        (ROOT / 'foreign-release').touch(exist_ok=True)
        save('report.json',result)
        save('after.json',{'diskstats':Path('/proc/diskstats').read_text(),
                          'cgroup_io_stat':Path('/sys/fs/cgroup/io.stat').read_text()})

if __name__ == '__main__':
    {'prepare':prepare,'watch':watch,'foreign':foreign}[sys.argv[1]]()
