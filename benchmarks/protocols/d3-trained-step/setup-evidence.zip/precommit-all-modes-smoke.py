from __future__ import annotations
import gc, json, sys, traceback
from pathlib import Path
sys.path.insert(0, '/workspace/d3-precommit-check/src')
sys.path.insert(0, '/workspace/d3-precommit-check/benchmarks/harness')
from d3_training_model import MODES, open_training_model
from d3_cublas_grouped_probe import reference_policy
from d3_full_model import file_hash
import torch
root=Path('/workspace/d3-olmoe-training-prep-20261022/prepared/nf4-dq')
library=Path('/workspace/d3-dev-venv/lib/python3.12/site-packages/nvidia/cu13/lib/libcublas.so.13')
out=Path('/workspace/d3-olmoe-training-prep-20261022/precommit-all-modes-smoke.json')
config=json.loads((root/'config.json').read_text())
ids=torch.randint(2,config['vocab_size'],(1,512),generator=torch.Generator().manual_seed(1234)).cuda()
report={'kind':'pre-commit full-model optimizer-step mode smoke; not formal D3 cells or performance evidence','status':'running','gpu':'NVIDIA GeForce RTX 3090','codec':'nf4-dq','source_revision':'6d84c48581ece794365f2b8e9cfb043c68ade9c5','cublas_sha256':file_hash(library),'modes':[],'formal_result':False}
def save(): out.write_text(json.dumps(report,indent=2)+'\n')
try:
 torch.backends.cuda.matmul.allow_tf32=False
 oracle=None
 for mode in MODES:
  with reference_policy('cublaslt-no-splitk'):
   run=open_training_model(root,mode=mode,device='cuda',library=library,retain_derivatives=True,seed=25,rank=4,lr=.5,native_rows_max=128)
   try:
    torch.cuda.reset_peak_memory_stats(); outputs=run.step(ids); torch.cuda.synchronize(); frame=run.frame(outputs); del outputs
    dispatch=run.check_dispatch()
    if mode=='native': oracle=frame
    elif set(frame)!=set(oracle) or any(not torch.equal(oracle[k],frame[k]) for k in oracle): raise RuntimeError(f'{mode}: full tensor mismatch against native oracle')
    report['modes'].append({'mode':mode,'status':'step_and_exactness_pass','layers':dispatch['layers'],'peak_allocated':torch.cuda.max_memory_allocated(),'peak_reserved':torch.cuda.max_memory_reserved(),'grouped_gemm':dispatch['gemm'] is not None})
    save(); del frame; gc.collect(); torch.cuda.empty_cache()
   finally: run.close(); del run; gc.collect(); torch.cuda.empty_cache()
 report['status']='smoke_passed_not_formal_measurement'
except BaseException:
 report['status']='smoke_failed_or_no_verdict'; report['traceback']=traceback.format_exc()
finally: save()
print(json.dumps(report,indent=2))
sys.exit(0 if report['status']=='smoke_passed_not_formal_measurement' else 1)
