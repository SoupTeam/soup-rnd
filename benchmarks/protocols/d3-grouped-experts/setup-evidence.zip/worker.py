from pathlib import Path
import subprocess,json,os,time
base=Path(__file__).resolve().parent
root=Path('/workspace/d3-compute-integration-20261020-02/checkout')
cmd=['/workspace/b12-env/bin/python',str(root/'benchmarks/harness/d3_grouped_restore_check.py'),'--model-dir','/workspace/b12-olmoe-pinned','--out',str(base/'prepared'),'--layers','7','--tokens','512','--compute-library','/workspace/b12-env/lib/python3.12/site-packages/nvidia/cu13/lib/libcublas.so.13']
r={'command':cmd,'started':time.time()}
try:
 with (base/'process.log').open('w') as log:p=subprocess.run(cmd,cwd=root,env=dict(os.environ,PYTHONPATH=str(root/'src')),stdout=log,stderr=subprocess.STDOUT,timeout=1200)
 r['returncode']=p.returncode
except BaseException as e:r['error']=str(e)
finally:r['finished']=time.time();(base/'exit.json').write_text(json.dumps(r,indent=2)+'\n')
