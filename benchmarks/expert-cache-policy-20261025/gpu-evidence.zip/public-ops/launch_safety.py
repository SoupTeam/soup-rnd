"""Pure local protocol checks; unresolved source/trace identity cannot authorize a lease."""

from __future__ import annotations

import hashlib
import re
from pathlib import Path


def validate_protocol(protocol, *, source_commit, route_path, stage_id):
    if (not re.fullmatch("[0-9a-f]{40}", source_commit)
            or protocol.get("source_commit") != source_commit
            or protocol.get("stage_id") != stage_id or protocol.get("accuracy_first") is not True):
        raise ValueError("Protocol source/stage identity is unresolved or differs from frozen source")
    cpu = protocol["cpu_probe"]
    digest = hashlib.sha256(Path(route_path).read_bytes()).hexdigest()
    if cpu.get("route_sha256") != digest:
        raise ValueError("Canonical CPU routing trace differs from the frozen protocol")
    for key, expected in (("trace_repeats", 3), ("budget_bytes", 2 * 2**30),
                          ("modeled_device_hotset_bytes", 2**28), ("hidden", 2048),
                          ("intermediate", 1408)):
        if type(cpu.get(key)) is not int or cpu[key] != expected:
            raise ValueError("CPU probe boundary changed: " + key)
    maximum = cpu.get("profile_max_visits")
    if maximum is not None and (type(maximum) is not int or not 1 <= maximum <= 2048):
        raise ValueError("Optional profiler needs a bounded max-visits <=2048")
    expected_selectors = {
        "tests/test_stream_expert_cache_nf4.py::"
        "test_real_cuda_nf4_expert_cache_preserves_complete_optimizer_trajectories",
        "tests/test_two_read_cache_full_query.py::"
        "test_real_cuda_nf4_full_rank_query_bf16_worker_trajectories",
    }
    selectors = protocol.get("cuda_test_selectors")
    if not isinstance(selectors, list) or len(selectors) != 2 or set(selectors) != expected_selectors:
        raise ValueError("Frozen four-cell CUDA preflight selection changed")
    performance = protocol["performance"]
    large = performance.get("large_device_cache_gib")
    if large not in (None, 1.5):
        raise ValueError("Optional large GPU hotset must use the explicit 1.5 GiB candidate")
    arms = ["two_read", "two_read_lru", "two_read_static"]
    if large is not None:
        arms.append("two_read_static_large_gpu")
    expected = {"rounds": 4 if large is not None else 6,
                "warmup_updates": 2, "timed_updates": 6, "accuracy_updates": 2,
                "accumulation": 2, "host_cache_bytes": 2 * 2**30,
                "small_device_cache_bytes": 2**28, "sequence_length": 512, "batch_size": 1}
    if performance.get("arms") != arms or any(
        type(performance.get(key)) is not int or performance[key] != value
        for key, value in expected.items()
    ):
        raise ValueError("Frozen paired accuracy/timing/memory protocol changed")
    return {"source_commit": source_commit, "route_sha256": digest,
            "arms": arms, "rounds": expected["rounds"], "cuda_cells": 4}
