"""Isolated CPU allocation probe; optional allocator diagnostics run after measured work."""

from __future__ import annotations

import argparse
import ctypes
import gc
import json
import os
import platform
from pathlib import Path


def allocator_snapshot():
    result = {"pid": os.getpid(), "libc": platform.libc_ver()}
    path = Path("/proc/self/smaps_rollup")
    result["smaps_rollup"] = path.read_text() if path.is_file() else None
    try:
        class Mallinfo2(ctypes.Structure):
            _fields_ = [(name, ctypes.c_size_t) for name in (
                "arena", "ordblks", "smblks", "hblks", "hblkhd", "usmblks", "fsmblks",
                "uordblks", "fordblks", "keepcost",
            )]
        function = ctypes.CDLL(None).mallinfo2
        function.argtypes, function.restype = [], Mallinfo2
        row = function()
        result["mallinfo2"] = {name: getattr(row, name) for name, _ in Mallinfo2._fields_}
    except (AttributeError, OSError):
        result["mallinfo2"] = None
    return result


def run(args):
    if platform.system() != "Linux":
        raise ValueError("Native allocator/smaps qualification requires Linux")
    if args.mode == "profile" and (args.max_visits is None or not 1 <= args.max_visits <= 2048):
        raise ValueError("Profiler mode requires an explicit bounded max-visits <=2048")
    from benchmarks.harness.expert_cache_cpu_profile import run_experiment

    result = run_experiment(
        args.route, args.out, policy=args.policy, mode=args.mode,
        budget_bytes=args.budget_bytes, device_hotset_bytes=args.device_hotset_bytes,
        hidden=args.hidden, intermediate=args.intermediate,
        repeats=args.repeats, max_visits=args.max_visits,
    )
    diagnostic = {"after_probe_cleanup": allocator_snapshot(),
                  "allocator_trim_requested": args.malloc_trim_diagnostic,
                  "note": "Separate CPU process only, after timing/clear/GC; glibc heap stats are "
                          "not live tensor bytes. No training allocator or settings changed."}
    gc.collect()
    diagnostic["after_additional_gc"] = allocator_snapshot()
    if args.malloc_trim_diagnostic:
        try:
            trim = ctypes.CDLL(None).malloc_trim
            trim.argtypes, trim.restype = [ctypes.c_size_t], ctypes.c_int
            diagnostic["malloc_trim_result"] = int(trim(0))
        except (AttributeError, OSError):
            diagnostic["malloc_trim_result"] = None
        diagnostic["after_optional_trim"] = allocator_snapshot()
    target = args.out / "postrun-allocator-diagnostic.json"
    temporary = target.with_suffix(".incoming")
    temporary.write_text(json.dumps(diagnostic, indent=2, allow_nan=False) + "\n")
    os.replace(temporary, target)
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--route", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--policy", choices=("lru", "static"), required=True)
    parser.add_argument("--mode", choices=("timing", "profile"), default="timing")
    parser.add_argument("--budget-bytes", type=int, default=2 * 2**30)
    parser.add_argument("--device-hotset-bytes", type=int, default=2**28)
    parser.add_argument("--hidden", type=int, default=2048)
    parser.add_argument("--intermediate", type=int, default=1408)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--max-visits", type=int)
    parser.add_argument("--malloc-trim-diagnostic", action="store_true")
    return run(parser.parse_args(argv))


if __name__ == "__main__":
    main()
