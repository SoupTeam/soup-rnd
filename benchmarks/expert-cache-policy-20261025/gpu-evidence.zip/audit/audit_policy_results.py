"""Independent retained-file audit of the frozen expert-cache policy experiment.

Nothing runs on import. No cloud, GPU, network or instance-management operation
is performed. The source checkout is read only, and its original numerical
comparator is accepted only after its file hash matches the retained source
manifest. Checkpoints/stores were deliberately not retained: their remote
fingerprints can be cross-checked, not independently rehashed locally.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import itertools
import json
import math
import os
import random
import statistics
import traceback
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any

GIB = 2**30
BASE_ARMS = ("two_read", "two_read_lru", "two_read_static")
LARGE_ARM = "two_read_static_large_gpu"
SOURCE_COMMIT = "70392afb78dde4098c73843a224aa8bab17d7df3"
MODEL_REVISION = "476b36a473d4467f94469414bef6cee75c9c8172"


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 2**20), b""):
            value.update(chunk)
    return value.hexdigest()


def finite_number(value: Any) -> bool:
    return type(value) in (int, float) and math.isfinite(value)


def loss_gate(reference: list[float], candidate: list[float]) -> dict[str, Any]:
    """Original reference-relative pointwise and three-decimal scalar loss gates."""
    if not reference or len(reference) != len(candidate):
        raise ValueError("recorded loss sequences differ in length or are empty")
    failures = []
    for index, (expected, actual) in enumerate(zip(reference, candidate)):
        if (not finite_number(expected) or not finite_number(actual)
                or abs(actual - expected) > 1e-5 + .01 * abs(expected)
                or f"{actual:.3f}" != f"{expected:.3f}"):
            failures.append({"update": index, "reference": expected, "candidate": actual})
    return {"passed": not failures, "checks": len(reference), "failures": failures,
            "bitwise_scalar_values": reference == candidate}


def paired_result(values: list[tuple[float, float]]) -> dict[str, Any]:
    """Independent geometric ratio calculation and paired-round bootstrap."""
    if not values or any(not finite_number(a) or not finite_number(b) or min(a, b) <= 0
                         for a, b in values):
        raise ValueError("invalid paired timing values")
    logs = [math.log(candidate / reference) for reference, candidate in values]
    rng = random.Random(29)
    draws = sorted(
        100 * (1 - math.exp(math.fsum(rng.choices(logs, k=len(logs))) / len(logs)))
        for _ in range(5000)
    )
    return {"step_time_reduction_percent": 100 * (1 - math.exp(math.fsum(logs) / len(logs))),
            "paired_bootstrap_95_percent": [draws[124], draws[4874]],
            "passes_practical_2_percent_gate": draws[124] >= 2., "paired_rounds": len(logs)}


def counter_delta(before: dict, after: dict, arm: str, device_bytes: int) -> dict:
    row = {}
    for key in ("logical_fetches", "storage_reads", "storage_bytes_read", "materializations"):
        row[key] = after[key] - before[key]
        if type(row[key]) is not int or row[key] < 0:
            raise ValueError("invalid expert counter delta")
    for tier in ("host", "device"):
        row[tier + "_hits"] = after[tier]["hits"] - before[tier]["hits"]
        if type(row[tier + "_hits"]) is not int or row[tier + "_hits"] < 0:
            raise ValueError("invalid cache-hit delta")
        budget = 0 if arm == "two_read" else (2 * GIB if tier == "host" else device_bytes)
        for snapshot in (before, after):
            data = snapshot[tier]
            if (data["budget_bytes"] != budget or type(data["payload_bytes"]) is not int
                    or not 0 <= data["payload_bytes"] <= budget):
                raise ValueError("cache payload/ceiling differs from the frozen arm")
    if (row["logical_fetches"] <= 0 or row["storage_reads"] <= 0 or
            row["storage_bytes_read"] <= 0 or
            row["storage_reads"] + row["host_hits"] + row["device_hits"] !=
            row["logical_fetches"] or
            row["materializations"] != row["logical_fetches"] - row["device_hits"]):
        raise ValueError("logical/read/hit/materialization counters disagree")
    if arm == "two_read":
        if row["host_hits"] or row["device_hits"]:
            raise ValueError("the uncached baseline used a cache")
    else:
        policy = "static" if arm.startswith("two_read_static") else "lru"
        if (before.get("host_cache_policy") != policy or
                after.get("host_cache_policy") != policy or
                min(row["host_hits"], row["device_hits"]) <= 0):
            raise ValueError("requested cache policy/tiers were not actually exercised")
        if policy == "static" and after["host"]["evictions"] != before["host"]["evictions"]:
            raise ValueError("a static cache evicted admitted entries")
    return row


def allocator_classification(data: dict) -> dict[str, Any]:
    def smaps_rss(item: dict) -> int | None:
        for line in (item.get("smaps_rollup") or "").splitlines():
            if line.startswith("Rss:"):
                return int(line.split()[1]) * 1024
        return None

    before = data.get("after_additional_gc", {})
    after = data.get("after_optional_trim", {})
    first, last = smaps_rss(before), smaps_rss(after)
    delta = first - last if first is not None and last is not None else None
    classification = "NO VERDICT: native trim/RSS diagnostic unavailable"
    if delta is not None:
        classification = (
            "RSS fell after isolated post-run trim, consistent with allocator-retained pages; "
            "this does not identify all prior RSS as live/free tensors or prove a training leak"
            if delta > 0 else
            "No RSS decrease observed after isolated post-run trim; no memory-leak verdict"
        )
    return {"libc": before.get("libc"), "rss_after_gc_bytes": first,
            "rss_after_optional_trim_bytes": last, "rss_reduction_after_trim_bytes": delta,
            "malloc_trim_result": data.get("malloc_trim_result"),
            "mallinfo2_after_gc": before.get("mallinfo2"),
            "mallinfo2_after_trim": after.get("mallinfo2"), "classification": classification,
            "scope": "CPU synthetic replay, post-timing diagnostics; not training allocator policy"}


class Audit:
    def __init__(self, retained: Path, source: Path) -> None:
        self.root, self.source = retained, source
        self.report: dict[str, Any] = {"status": "running", "checks": [], "files": {},
                                       "accuracy": {}, "workers": {}, "comparisons": {}}

    def check(self, condition: Any, message: str) -> None:
        self.report["checks"].append({"passed": bool(condition), "check": message})
        if not condition:
            raise AssertionError(message)

    def file(self, relative: str) -> Path:
        path = self.root / relative
        self.check(path.is_file(), "retained file exists: " + relative)
        self.report["files"][relative] = {"bytes": path.stat().st_size, "sha256": digest(path)}
        return path

    def read(self, relative: str) -> Any:
        return json.loads(self.file(relative).read_text(encoding="utf-8"))

    def resource_stage(self, stage: dict, label: str) -> None:
        resources = stage["resources"]
        self.check(type(resources["sampled_peak_rss_bytes"]) is int and
                   resources["sampled_peak_rss_bytes"] <= 32 * GIB, label + ": sampled RSS cap")
        self.check(resources["sampled_peak_process_swap_bytes"] == 0 and
                   resources.get("sampled_peak_cgroup_swap_bytes") in (0, None),
                   label + ": no process/cgroup swap observed")
        for point in (resources["before"], resources["after"]):
            physical = point["host_memory"]["MemTotal"]
            hard = [item.get("memory.max") for item in point["cgroup"]["constraints"]
                    if type(item.get("memory.max")) is int]
            self.check(28 * GIB <= min([physical, *hard]) <= 32 * GIB,
                       label + ": actual physical/cgroup RAM ceiling")
            self.check(point["process_swap_bytes"] == 0, label + ": boundary process swap zero")
            self.check(point["host_memory"].get("SwapTotal", 0) == 0 or any(
                item.get("memory.swap.max") == 0 for item in point["cgroup"]["constraints"]
            ), label + ": swap capacity unavailable to this workload")
            for item in point["cgroup"]["constraints"]:
                self.check(item.get("memory.swap.current") in (0, None),
                           label + ": boundary cgroup swap zero")
        for field in ("cuda", "cuda_including_diagnostics"):
            if field not in stage:
                continue
            self.check(all(type(stage[field][name]) is int and
                           0 <= stage[field][name] <= 8 * GIB for name in (
                               "peak_allocated_bytes", "peak_reserved_bytes")),
                       label + ": VRAM cap " + field)

    def worker(self, directory: str, arm: str, phase: str, spec: dict, identity: str) -> dict:
        raw = self.read(directory + "/result.json")
        control = self.read(directory + "/controller-result.json")
        self.check(all(control.get(key) == value for key, value in raw.items()),
                   directory + ": controller copy matches raw worker")
        expected_arm = "two_read" if arm == "two_read" else "two_read_cache"
        self.check(raw["status"] == "passed" and raw["phase"] == phase and
                   raw["arm"] == expected_arm and raw["spec_sha256"] == identity,
                   directory + ": status/phase/arm/spec identity")
        self.check(type(raw["pid"]) is int and raw["pid"] > 0,
                   directory + ": process identity recorded")
        self.check(raw["environment"]["gpu_total_bytes"] == spec["hardware"]["physical_vram_bytes"]
                   and 7.5 * GIB <= raw["environment"]["gpu_total_bytes"] <= 8.5 * GIB
                   and raw["environment"]["compute_capability"][0] >= 8,
                   directory + ": physical 8 GiB BF16 GPU")
        self.check(raw["environment"]["gpu_name"] == spec["hardware"]["name"],
                   directory + ": same GPU model")
        for package, version in raw["environment"]["versions"].items():
            if package in spec["environment"]["packages"]:
                self.check(spec["environment"]["packages"][package] == version,
                           directory + ": fixed dependency " + package)
        self.resource_stage(raw["setup"], directory + "/setup")
        if arm == "two_read":
            self.check(raw["setup"]["cache_plan"] is None, directory + ": no cache admission")
        else:
            plan = raw["setup"]["cache_plan"]
            self.check(all(plan[key] == spec[key] for key in (
                "host_cache_policy", "host_cache_bytes", "device_cache_bytes")),
                directory + ": exact policy admission")
        for stage in (("accuracy",) if phase == "accuracy" else ("warmup", "timing")):
            self.resource_stage(raw[stage], directory + "/" + stage)
            if stage != "accuracy":
                expected = spec[stage + "_updates" if stage == "warmup" else "timed_updates"]
                self.check(raw[stage]["complete"] is True and
                           raw[stage]["finite_state_checks_per_update"] is True and
                           raw[stage]["updates_complete"] == expected and
                           len(raw[stage]["losses"]) == expected and
                           len(raw[stage]["update_seconds"]) == expected,
                           directory + "/" + stage + ": all finite-checked updates recorded")
                self.check(all(finite_number(value) and value > 0
                               for value in raw[stage]["update_seconds"]),
                           directory + "/" + stage + ": finite positive durations")
        self.check(finite_number(control["fresh_process_wall_seconds"]) and
                   control["fresh_process_wall_seconds"] >= raw["total_worker_seconds"],
                   directory + ": whole-entry time includes worker time")
        self.report["workers"][directory] = {
            "pid": raw["pid"], "whole_entry_seconds": control["fresh_process_wall_seconds"],
            "setup_seconds": raw["setup"]["seconds"],
            "process_lifetime_peak_rss_bytes": raw["resources_after"][
                "process_lifetime_peak_rss_bytes"],
        }
        return control

    def execute(self) -> dict:
        import torch

        torch.set_num_threads(1)
        source = self.read("source-manifest.json")
        protocol = self.read("protocol.json")
        self.check(source["source_commit"] == protocol["source_commit"] == SOURCE_COMMIT,
                   "frozen source commit matches the independently selected cohort")
        name = "benchmarks/harness/two_read_cache_common.py"
        self.check(digest(self.source / name) == source["files"][name]["sha256"],
                   "executed original comparator matches retained source bytes")
        loader = importlib.util.spec_from_file_location(
            "frozen_numerical_gates", self.source / name,
        )
        common = importlib.util.module_from_spec(loader)
        loader.loader.exec_module(common)
        capacity = self.read("results/capacity-preflight.json")
        self.check(capacity["passed"] is True and
                   28 * GIB <= capacity["native_ram_limit_bytes"] <= 32 * GIB and
                   7900 <= capacity["gpu_memory_mib"] <= 8300,
                   "native startup resource preflight passed")
        pinned = self.read("results/model-pinned.json")
        self.check(pinned["revision"] == MODEL_REVISION and
                   pinned["weights_bytes"] == 31920879456 and len(pinned["files"]) == 27 and
                   sum(item["bytes"] for item in pinned["files"].values()) == 31920879456,
                   "pinned public model identity and complete 27-shard size")
        spec = self.read("results/prepared/spec.json")
        self.check(spec["git_head"] == SOURCE_COMMIT, "prepared source Git HEAD")
        self.check(spec["dtype"] == "bfloat16" and spec["quant"] == "nf4" and
                   spec["seq_len"] == 512 and spec["batch_size"] == 1 and
                   spec["accumulation"] == 2 and spec["accuracy_updates"] == 2 and
                   spec["warmup_updates"] == 2 and spec["timed_updates"] == 6 and
                   spec["lora_r"] == 4 and spec["lora_alpha"] == 8 and
                   spec["lora_targets"] == ["q_proj", "kv_b_proj", "o_proj"] and
                   spec["host_cache_bytes"] == 2 * GIB and
                   spec["device_cache_bytes"] == GIB // 4,
                   "frozen Moonlight NF4/BF16 LoRA recipe")
        for path, identity in spec["source_fingerprint"].items():
            self.check(source["files"][path]["sha256"] == identity,
                       "executed source fingerprint: " + path)
        for path, metadata in pinned["files"].items():
            self.check(spec["model_fingerprint"][path] == metadata["lfs"]["sha256"] and
                       spec["model_stat"][path][0] == metadata["bytes"],
                       "remote model fingerprint matches public LFS object: " + path)
        input_path = self.file("results/prepared/inputs.pt")
        self.check(digest(input_path) == spec["training_data_sha256"], "frozen token bytes")
        inputs = torch.load(input_path, map_location="cpu", weights_only=True)
        performance = protocol["performance"]
        arms, rounds = tuple(performance["arms"]), performance["rounds"]
        self.check(arms in (BASE_ARMS, (*BASE_ARMS, LARGE_ARM)), "three/four-arm cohort identified")
        orders = tuple(itertools.permutations(arms)) if len(arms) == 3 else tuple(
            arms[index:] + arms[:index] for index in range(4)
        )
        self.check(type(rounds) is int and rounds >= len(orders) and rounds % len(orders) == 0,
                   "complete independently reconstructed balanced schedule")
        report = self.read("results/qualification/run.json")
        self.check(report["status"] == "completed" and report["accuracy_passed"] is True,
                   "controller recorded a complete qualified experiment")
        child_specs, spec_hashes, accuracy, reference = {}, {}, {}, None
        accuracy_warmup_losses = {}
        for arm in arms:
            relative = "results/qualification/specs/" + arm + ".json"
            child = self.read(relative)
            identity = self.report["files"][relative]["sha256"]
            expected = dict(spec, host_cache_policy="static" if arm.startswith(
                "two_read_static") else "lru")
            if arm == LARGE_ARM:
                expected["device_cache_bytes"] = int(1.5 * GIB)
            self.check(child == expected, arm + ": only the declared policy/device ceiling changed")
            child_specs[arm], spec_hashes[arm] = child, identity
            directory = "results/qualification/accuracy/" + arm
            worker = self.worker(directory, arm, "accuracy", child, identity)
            capture_path = self.file(directory + "/capture.pt")
            capture_hash = self.report["files"][directory + "/capture.pt"]["sha256"]
            self.check(capture_hash == worker["accuracy"]["capture_sha256"],
                       arm + ": complete capture hash bound to its worker")
            capture = torch.load(capture_path, map_location="cpu", weights_only=True)
            self.check(len(capture["initial_adapters"]) == 162 and
                       len(capture["updates"]) == 2 and len(capture["microbatches"]) == 4,
                       arm + ": all 162 adapters and complete accumulated updates captured")
            self.check(all(torch.equal(batch["input_ids"], inputs[index])
                           for index, batch in enumerate(capture["microbatches"])),
                       arm + ": actual token inputs equal frozen inputs")
            initial, final = capture["initial_adapters"], capture["updates"][-1]["adapters"]
            self.check(all(torch.count_nonzero(value).item() > 0 and
                           torch.count_nonzero(final[name]).item() > 0 and
                           not torch.equal(value, final[name]) for name, value in initial.items()),
                       arm + ": every adapter is nonzero and actually changed")
            self.check(all(any(torch.count_nonzero(batch["gradients"][name]).item() > 0
                                   for batch in capture["microbatches"]) for name in initial),
                       arm + ": every adapter received a nonzero gradient")
            accuracy_warmup_losses[arm] = [
                float(capture["microbatches"][index]["loss"].item()) for index in (1, 3)
            ]
            if reference is None:
                reference = capture
                gate = common.validate_capture(reference)
            else:
                gate = common.compare_captures(reference, capture)
            self.report["accuracy"][arm] = gate
            self.check(gate["passed"], arm + ": original unchanged full-trajectory gates passed")
            self.check(digest(capture_path) == capture_hash, arm + ": capture stable during audit")
            before = worker["accuracy"]["runtime_before"]["expert_cache"]
            after = worker["accuracy"]["runtime_after"]["expert_cache"]
            accuracy[arm] = counter_delta(before, after, arm, child["device_cache_bytes"])
            if arm != "two_read":
                del capture
        del reference
        self.check(len({row["logical_fetches"] for row in accuracy.values()}) == 1,
                   "all accuracy arms execute identical two-read expert visits")
        self.report["accuracy_counter_deltas"] = accuracy
        blocks = {number: {} for number in range(rounds)}
        for number in range(rounds):
            for position, arm in enumerate(orders[number % len(orders)]):
                directory = f"results/qualification/timing/round-{number:02d}/{arm}"
                result = self.worker(directory, arm, "timing", child_specs[arm], spec_hashes[arm])
                blocks[number][arm] = result
                gate = loss_gate(accuracy_warmup_losses[arm], result["warmup"]["losses"])
                self.check(gate["passed"], directory + ": warmup matches accuracy entry state")
                self.check(any(row["round"] == number and row["position"] == position and
                               row["arm"] == arm and row["result"] == result
                               for row in report["timing_blocks"]),
                           directory + ": raw worker belongs to the recorded balanced matrix")
        self.check(len(report["timing_blocks"]) == len(arms) * rounds,
                   "no missing/extra/duplicate timing workers")
        pids = [item["pid"] for item in self.report["workers"].values()]
        self.check(len(pids) == len(set(pids)), "every accuracy/timing worker has a fresh process")
        recorded_loss_gates = {}
        for number, row in blocks.items():
            for arm in arms[1:]:
                for stage in ("warmup", "timing"):
                    gate = loss_gate(row["two_read"][stage]["losses"], row[arm][stage]["losses"])
                    recorded_loss_gates[f"round-{number}/{arm}/{stage}"] = gate
                    self.check(gate["passed"],
                               f"{number}/{arm}/{stage}: recorded loss sequence parity")
        self.report["recorded_unprofiled_loss_gates"] = recorded_loss_gates
        comparisons = [(arm + "_vs_two_read", "two_read", arm) for arm in arms[1:]]
        comparisons.append(("static_vs_lru", "two_read_lru", "two_read_static"))
        if LARGE_ARM in arms:
            comparisons.append(("large_device_vs_static", "two_read_static", LARGE_ARM))
        for key, baseline, arm in comparisons:
            pairs = [(statistics.median(row[baseline]["timing"]["update_seconds"]),
                      statistics.median(row[arm]["timing"]["update_seconds"]))
                     for row in blocks.values()]
            independent = paired_result(pairs)
            summary = report["timing_summary"]
            published = (summary["comparisons"][key] if key.endswith("_vs_two_read")
                         else summary[key])
            self.check(abs(published["step_time_reduction_percent"] - independent[
                "step_time_reduction_percent"]) < 1e-9 and all(abs(a - b) < 1e-9 for a, b in zip(
                    published["paired_bootstrap_95_percent"], independent[
                        "paired_bootstrap_95_percent"])) and
                published["passes_practical_2_percent_gate"] == independent[
                    "passes_practical_2_percent_gate"],
                key + ": independent paired bootstrap agrees")
            self.report["comparisons"][key] = independent
        self.report["absolute"] = {}
        for arm in arms:
            rows = [block[arm] for block in blocks.values()]
            self.report["absolute"][arm] = {
                "median_step_seconds": statistics.median([
                    value for row in rows for value in row["timing"]["update_seconds"]
                ]),
                "median_setup_seconds": statistics.median(row["setup"]["seconds"] for row in rows),
                "median_whole_entry_seconds": statistics.median(
                    row["fresh_process_wall_seconds"] for row in rows),
                "max_step_allocated_bytes": max(row["timing"]["cuda"]["peak_allocated_bytes"]
                                                for row in rows),
                "max_step_reserved_bytes": max(row["timing"]["cuda"]["peak_reserved_bytes"]
                                               for row in rows),
                "max_sampled_timing_rss_bytes": max(
                    row["timing"]["resources"]["sampled_peak_rss_bytes"] for row in rows),
                "max_process_lifetime_peak_rss_bytes": max(row["resources_after"][
                    "process_lifetime_peak_rss_bytes"] for row in rows),
                "max_observed_host_payload_bytes": max(row["timing"]["runtime_after"][
                    "expert_cache"]["host"]["payload_bytes"] for row in rows),
                "max_observed_device_payload_bytes": max(row["timing"]["runtime_after"][
                    "expert_cache"]["device"]["payload_bytes"] for row in rows),
            }
        baseline = self.report["absolute"]["two_read"]
        self.report["setup_amortization_estimates"] = {}
        for arm in arms[1:]:
            candidate = self.report["absolute"][arm]
            saved_step = baseline["median_step_seconds"] - candidate["median_step_seconds"]
            extra_setup = candidate["median_setup_seconds"] - baseline["median_setup_seconds"]
            self.report["setup_amortization_estimates"][arm] = {
                "extra_median_setup_seconds": extra_setup,
                "median_seconds_saved_per_update": saved_step,
                "updates_to_amortize_setup": max(0, extra_setup) / saved_step if saved_step > 0
                else None,
                "scope": "Fixed measured recipe; excludes shared download/sharding; descriptive "
                "estimate, not a full-training forecast or confidence bound",
            }
        self.report["cpu_allocation_diagnosis"] = {}
        cpu_route = self.file("cpu-route.json")
        self.check(digest(cpu_route) == protocol["cpu_probe"]["route_sha256"],
                   "isolated CPU diagnostic uses the frozen routing bytes")
        for policy in ("lru", "static"):
            probe = self.read(f"results/cpu-{policy}-timing/result.json")
            diagnostic = self.read(f"results/cpu-{policy}-timing/postrun-allocator-diagnostic.json")
            self.check(probe["status"] == "passed" and probe["mode"] == "timing" and
                       probe["route_sha256"] == protocol["cpu_probe"]["route_sha256"] and
                       probe["fixed_trace_repeats"] == 3 and probe["budget_bytes"] == 2 * GIB,
                       policy + ": isolated CPU trace diagnosis identity")
            self.resource_stage(probe, "isolated CPU " + policy)
            self.check(probe["modeled_device_hotset_bytes"] == GIB // 4 and
                       probe["payload_bytes_per_expert"] == 4462664 and
                       probe["tensors_per_expert"] == 8 and
                       probe["cloned_payload_bytes_derived"] ==
                       probe["counts"]["admissions"] * 4462664 and
                       probe["clone_calls_derived"] == probe["counts"]["admissions"] * 8 and
                       probe["immutable_after_staging_mutation"] is True,
                       policy + ": complete CPU payload/clone/ownership controls")
            for remote_path, identity in probe["source_fingerprint"].items():
                relative = remote_path.replace("\\", "/").partition("/repo/")[2]
                self.check(relative in source["files"] and
                           source["files"][relative]["sha256"] == identity,
                           policy + ": executed CPU probe source fingerprint")
            if policy == "static":
                self.check(probe["cache_stats"]["evictions"] == 0 and
                           probe["cache_stats"]["copied_bytes"] ==
                           probe["cloned_payload_bytes_derived"],
                           "static CPU store actual copied-byte accounting")
            self.report["cpu_allocation_diagnosis"][policy] = {
                "cache_operation_wall_seconds": probe["cache_operation_wall_seconds"],
                "cloned_payload_bytes_derived": probe["cloned_payload_bytes_derived"],
                "cache_stats": probe["cache_stats"],
                "cleanup_resources": probe["cleanup_resources"],
                "allocator": allocator_classification(diagnostic),
            }
        xml = self.file("results/gpu-preflight.xml")
        cases = ET.parse(xml).findall(".//testcase")
        expected_names = {selector.rsplit("::", 1)[-1] + "[" + policy + "]"
                          for selector in protocol["cuda_test_selectors"]
                          for policy in ("lru", "static")}
        failed_or_skipped = any(case.find("skipped") is not None or
                                case.find("failure") is not None or case.find("error") is not None
                                for case in cases)
        self.check(len(cases) == 4 and not failed_or_skipped and
                   {case.attrib["name"] for case in cases} == expected_names,
                   "all four cheap native CUDA policy cells actually passed")
        self.report["recording_limits"] = {
            "unprofiled_loss_scope": "Only last microbatch loss per update was persisted. "
            "All saved warmup/timed losses were compared; first timed microbatch: NO VERDICT. "
            "Complete numerical trajectories cover the separate four-microbatch accuracy phase.",
            "checkpoint_store_scope": "Remote fingerprints cross-checked against pinned LFS/source "
            "metadata; model/store files are absent locally and were not independently rehashed.",
            "cpu_scope": "Synthetic CPU allocation replay and optional post-run trim; no claim "
            "that CPU operator speedup equals GPU training speedup or a production memory leak.",
            "memory_scope": "Cache payload, sampled stage RSS, lifetime RSS and allocator VRAM "
            "are different quantities; sampled RSS may miss short peaks.",
        }
        self.report["status"] = "passed_with_recording_limits"
        return self.report


def main() -> int:
    from rich.console import Console

    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    parser.add_argument("--retained", required=True, type=Path)
    parser.add_argument("--source-root", type=Path, default=Path.cwd())
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    audit = Audit(args.retained, args.source_root)
    audit.report["audit_script_sha256"] = digest(Path(__file__))
    code = 0
    try:
        audit.execute()
    except BaseException as exc:
        audit.report.update(status="failed", error=repr(exc), traceback=traceback.format_exc())
        code = 1
    args.out.parent.mkdir(parents=True, exist_ok=True)
    temporary = args.out.with_suffix(".incoming")
    temporary.write_text(json.dumps(audit.report, indent=2, allow_nan=False) + "\n",
                         encoding="utf-8")
    os.replace(temporary, args.out)
    Console().print({"status": audit.report["status"], "checks": len(audit.report["checks"]),
                     "out": str(args.out)})
    return code


if __name__ == "__main__":
    raise SystemExit(main())
