"""Retain actual CPU controls, requiring real NF4 cells to execute."""

import importlib.metadata as metadata
import json
import os
import platform
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from pathlib import Path

from rich.console import Console

ROOT = Path(r"C:\Users\esenb\.codex\worktrees\cache-recompute-20261025\soup-rnd-d2")
OUT = Path(__file__).parent
FILES = (
    "test_expert_stream", "test_expert_stream_two_read_contract",
    "test_stream_expert_cache_store", "test_stream_expert_cache_fetcher",
    "test_stream_expert_cache_accuracy", "test_stream_expert_cache_nf4",
    "test_stream_expert_cache_planner", "test_stream_ram_cache",
    "test_stream_ram_cache_memory", "test_stream_ram_cache_config",
    "test_stream_residency_pool", "test_stream_residency_planner",
    "test_stream_residency_config", "test_stream_joint_cache",
    "test_stream_cache_recompute", "test_stream_recompute", "test_stream_recompute_config",
    "test_stream_expert_layout", "test_issue487_changelog_fragments",
    "test_no_foreign_license_headers", "test_cli_startup_is_light",
)


def main():
    env = dict(os.environ, PYTHONPATH=str(ROOT / "src") + os.pathsep + str(OUT / ".deps"),
               OMP_NUM_THREADS="1", MKL_NUM_THREADS="1", PYTHONIOENCODING="utf-8")
    started = time.time()
    commands = (
        [sys.executable, "-m", "ruff", "check", "src/soup_cli/", "scripts/", "tests/", "benchmarks/"],
        [sys.executable, "-m", "pytest", *("tests/" + name + ".py" for name in FILES),
         "-q", "-o", "addopts=", "--tb=short", "--junitxml=" + str(OUT / "cpu-final.xml")],
    )
    for name, command in zip(("ruff", "cpu-final"), commands):
        Console().print({"running": name})
        with (OUT / (name + ".log")).open("wb") as log:
            subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT,
                           check=True, timeout=600)
        Console().print({"passed": name})
    root = ET.parse(OUT / "cpu-final.xml")
    cases = root.findall(".//testcase")
    for prefix, count in (
        ("test_real_cpu_nf4_expert_cache_preserves_complete_optimizer_trajectories", 1),
        ("test_real_cpu_nf4_cache_preserves_complete_nested_quantization_state", 3),
        ("test_nf4_dequant_dtype_changes_cannot_hit_an_old_dense_entry", 1),
        ("test_expert_cache_preserves_accumulated_optimizer_trajectory", 12),
    ):
        matched = [row for row in cases if row.attrib["name"].startswith(prefix)]
        if len(matched) != count or any(len(row) for row in matched):
            raise ValueError("Required accuracy cell was skipped or did not pass: " + prefix)
    result = {
        "passed": True, "python": platform.python_version(), "cpu_only": True,
        "packages": {name: metadata.version(name) for name in
                     ("torch", "transformers", "peft", "bitsandbytes", "trl", "pytest", "ruff")},
        "tests": len(cases), "skipped": sum(row.find("skipped") is not None for row in cases),
        "required_cpu_nf4_and_all_dense_precision_cells_executed": True,
        "seconds": time.time() - started, "full_repository_suite": False,
        "commands": commands, "gpu_rented": False, "new_spend_usd": 0,
    }
    (OUT / "verification.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    Console().print(result)


if __name__ == "__main__":
    main()
