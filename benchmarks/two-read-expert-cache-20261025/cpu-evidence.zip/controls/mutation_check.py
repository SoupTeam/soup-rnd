"""Kill ownership/identity/cap regressions and restore exact source bytes."""

import hashlib
import json
import os
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

from rich.console import Console

ROOT = Path(r"C:\Users\esenb\.codex\worktrees\cache-recompute-20261025\soup-rnd-d2")
OUT = Path(__file__).parent
CASES = [
    ("host-staging-alias", "src/soup_cli/utils/expert_cache.py",
     "tensor.detach().clone()", "tensor.detach()",
     "tests/test_stream_expert_cache_fetcher.py",
     "test_cache_hit_skips_real_read_and_preserves_staging_ownership"),
    ("reader-key-collision", "src/soup_cli/utils/expert_stream.py",
     "return reader, reader._identity, expert, self.device, self.dtype, specs, tuple(codes)",
     'return "reader", "identity", expert, self.device, self.dtype, specs, tuple(codes)',
     "tests/test_stream_expert_cache_fetcher.py",
     "test_equal_expert_ids_from_different_layers_never_share_weights"),
    ("missing-nf4-dtype", "src/soup_cli/utils/expert_stream.py",
     "tuple(spec.shape), str(spec.dtype), spec.blocksize", "tuple(spec.shape), spec.blocksize",
     "tests/test_stream_expert_cache_fetcher.py",
     "test_nf4_dequant_dtype_changes_cannot_hit_an_old_dense_entry"),
    ("stale-active-file", "src/soup_cli/utils/expert_stream.py",
     "reader.validate_identity()", "reader._open()",
     "tests/test_stream_expert_cache_fetcher.py",
     "test_in_place_rewrite_is_refused_with_an_open_reader_and_warm_cache"),
    ("spent-lazy-gpu-ceiling", "src/soup_cli/utils/stream_residency.py",
     "reserve_bytes += expert_device_reserve_bytes(runtime)", "reserve_bytes += 0",
     "tests/test_stream_residency_planner.py",
     "test_lazy_expert_cache_ceiling_is_held_back_from_decoder_residency"),
]


def main():
    env = dict(os.environ)
    env.update(PYTHONPATH=str(ROOT / "src") + os.pathsep + str(OUT / ".deps"),
               OMP_NUM_THREADS="1", MKL_NUM_THREADS="1")
    records = []
    for name, relative, needle, bad, testfile, selector in CASES:
        path = ROOT / relative
        original = path.read_bytes()
        source = original.decode("utf-8")
        if source.count(needle) != 1:
            raise ValueError("Mutation target is not unique: " + name)
        xml = OUT / (name + ".xml")
        try:
            path.write_bytes(source.replace(needle, bad).encode("utf-8"))
            result = subprocess.run(
                [sys.executable, "-m", "pytest", testfile, "-k", selector, "-q",
                 "-o", "addopts=", "--tb=short", "--junitxml=" + str(xml)],
                cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                timeout=180,
            )
            (OUT / (name + ".log")).write_bytes(result.stdout)
            tree = ET.parse(xml)
            failures = tree.findall(".//testcase[failure]")
            errors = tree.findall(".//testcase[error]")
            killed = (result.returncode == 1 and failures and not errors
                      and all(selector in case.attrib["name"] for case in failures)
                      and all("AssertionError" in (case.find("failure").text or "")
                              or "Failed: DID NOT RAISE" in (case.find("failure").text or "")
                              or case.find("failure").attrib.get("message", "").startswith("assert ")
                              for case in failures))
            if not killed:
                raise AssertionError("Mutation survived or failed for another reason: " + name)
        finally:
            path.write_bytes(original)
            if path.read_bytes() != original:
                raise AssertionError("Original source not restored")
        records.append({"name": name, "target": relative, "test": selector,
                        "killed": True, "failed_cases": len(failures),
                        "original_sha256": hashlib.sha256(original).hexdigest(),
                        "exact_source_bytes_restored": True})
        Console().print({"mutation": name, "killed": True, "failed_cases": len(failures)})
    (OUT / "mutations.json").write_text(
        json.dumps({"all_killed": True, "cases": records}, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
