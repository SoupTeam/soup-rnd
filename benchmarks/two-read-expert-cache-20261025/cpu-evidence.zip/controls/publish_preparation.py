"""Publish compact CPU preparation evidence, preserving exact executed bytes."""

import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

from rich.console import Console

ROOT = Path(r"C:\Users\esenb\.codex\worktrees\cache-recompute-20261025\soup-rnd-d2")
OUT = Path(__file__).parent
PUB = Path(r"C:\Users\esenb\.codex\worktrees\stream-memory-auto-20261023\soup-rnd-d2")
TARGET = PUB / "benchmarks/two-read-expert-cache-20261025"


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT)


def identity(raw):
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def main():
    verification = json.loads((OUT / "verification.json").read_bytes())
    mutations = json.loads((OUT / "mutations.json").read_bytes())
    if not verification["passed"] or not mutations["all_killed"]:
        raise ValueError("CPU and negative controls are required")
    if git("status", "--porcelain").strip():
        raise ValueError("Commit the exact verified integration source first")
    for row in mutations["cases"]:
        if identity((ROOT / row["target"]).read_bytes())["sha256"] != row["original_sha256"]:
            raise ValueError("Mutation source changed after controls")
    head = git("rev-parse", "HEAD").decode().strip()
    TARGET.mkdir(parents=True, exist_ok=True)
    patch = git("diff", "--binary", "c22e5f90", head)
    paths = git("diff", "--name-only", "c22e5f90", head).decode().splitlines()
    members = {"combined.patch": patch}
    members.update({"executed/" + path: (ROOT / path).read_bytes()
                    for path in paths if (ROOT / path).is_file()})
    members.update({"controls/" + path.name: path.read_bytes() for path in OUT.iterdir()
                    if path.is_file() and path.suffix in {".json", ".xml", ".log", ".py"}})
    records = {name: identity(raw) for name, raw in sorted(members.items())}
    packet = TARGET / "cpu-evidence.zip"
    with zipfile.ZipFile(packet, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, raw in members.items():
            archive.writestr(name, raw)
        archive.writestr("files.json", json.dumps(records, indent=2) + "\n")
    with zipfile.ZipFile(packet) as archive:
        assert archive.testzip() is None
        assert all(identity(archive.read(name)) == record for name, record in records.items())
    summary = {
        "status": "CPU_PREPARATION_PASSED_CUDA_QUALIFICATION_PENDING",
        "source_head": head, "source_branch": "koko/two-read-cache-20261025",
        "cache_base": "c22e5f904e4e34c89f9b0f71c1b9d96ca66e212b",
        "two_read_head": "f2599ddc35a459bf3378735a7c4e8b995720e221",
        "passed": verification["tests"] - verification["skipped"],
        "skipped": verification["skipped"], "mutations_killed": len(mutations["cases"]),
        "packages": verification["packages"], "python": verification["python"],
        "cpu_nf4_cells_executed": verification[
            "required_cpu_nf4_and_all_dense_precision_cells_executed"],
        "full_repository_suite": False, "gpu_rented": False, "new_spend_usd": 0,
        "evidence": identity(packet.read_bytes()), "evidence_index": "files.json",
        "combined_patch": identity(patch), "raw_results_directory": str(OUT),
    }
    (TARGET / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    report = f"""# Two-read expert cache integration: CPU preparation

Status: CPU correctness controls passed; CUDA memory, real-model quality and speed are unqualified.

Source [{head[:8]}](https://github.com/SoupTeam/soup-rnd/tree/{head}) on
`koko/two-read-cache-20261025` merges the exact upstream PR #2158 head `f2599ddc`
with cache candidate `c22e5f90`, then adds expert-level cache ownership and admission.
Upstream two-read commits and authorship are preserved. This report does not replace
the older production source in PR #5. The combined patch against `c22e5f90`, exact
executed changed files, controls and logs are in [cpu-evidence.zip](cpu-evidence.zip),
with internal byte/SHA-256 index `files.json`; [summary.json](summary.json) binds the packet.

## Implemented

- Shared `ExpertFetcher`: bounded host LRU of owned packed tensors and complete NF4
  sidecars; first-fit immutable dense device hotset. Entries use reader/file, expert,
  dtype, quantization and code-table identities. Device entries do not duplicate host entries.
- Warm hits validate open-file identity too. Entries never alias reusable staging;
  runtime cleanup releases caches/staging even if another source fails to close.
- Setup API `configure_stream_expert_cache`: complete baseline/candidate F/B probes,
  state preservation, host headroom, shared device cap and setup/optimizer reserves.
  Later decoder/activation planners hold the full lazy device ceiling; later SSD
  hotset rebuilds hold the full lazy host ceiling. Warm capacity can be deliberately
  charged twice. This is conservative admission, not optimal or speed-aware placement.
- No CLI/config/default change. Direct low-level ceilings count owned tensor payload,
  not total allocator/RSS/VRAM. Use the setup helper before training; re-admit after
  source, budget, shape or adapter changes. Existing two-read architecture, hook and
  routed-expert-adapter refusals are retained.

## Validation

{summary['passed']} passed, {summary['skipped']} CUDA skips in the retained focused
regression selection; Ruff passes. The full repository suite was not run.
All required CPU NF4 cells actually executed. Real tiny DeepSeek-V3 models cover
resident/default/two-read, FP32/BF16/autocast, host/device/both/disabled caches,
two accumulated AdamW updates, loss/logits/dX/router and every LoRA gradient,
all final adapters and optimizer moments. All adapters actually change.
The same frozen NF4 base also passes all default/two-read cache trajectories.

CPU equality is bitwise and additionally checks unchanged reference-relative
`rtol=.01, atol=1e-5`, finiteness and three-decimal loss gates. CPU device caching
is a semantic control, not evidence of CUDA copies, allocation or acceleration.
Five deliberate ownership/identity/precision/reservation mutations are killed;
each source file is restored byte-for-byte. A real CUDA NF4 trajectory test is
prepared and skipped on this CPU build.

Earlier setup controls exposed a host-availability-dependent tiny positive fixture
and a changelog baseline/reference mismatch; the fixture now fixes only synthetic
host availability while production refusal controls remain. An isolated run lacked
TRL; its failed report is retained as `before-trl.*`. Final dependencies and commands
are recorded in the packet. No numerical threshold was weakened.

## Next GPU qualification

Compare ordinary three-read, two-read, expert cache, and two-read plus expert cache
on the same supported real MoE checkpoint, adapter/input state and physical GPU.
Qualify full numerical captures before unprofiled speed/RAM/VRAM measurements.
Record real physical reads separately from logical expert visits and include setup
costs. Retained activations already remove checkpoint recompute, so the 3-to-2 saving
must not be counted twice. This preparation rented no GPU and spent no GPU budget.
"""
    (TARGET / "README.md").write_text(report, encoding="utf-8", newline="\n")
    Console().print({"source": head, "report": str(TARGET), "verified_files": len(records),
                     "packet_bytes": packet.stat().st_size})


if __name__ == "__main__":
    main()
