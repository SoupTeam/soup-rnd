"""Retain local preparation evidence; this never executes the GPU benchmark."""

from __future__ import annotations

import argparse
import importlib.metadata
import json
import os
import platform
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from pathlib import Path

from rich.console import Console


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("--deps", required=True, type=Path)
    parser.add_argument("--collect-existing", action="store_true")
    args = parser.parse_args()
    root, out = args.root.absolute(), Path(__file__).parent
    sys.path.insert(0, str(args.deps))
    env = dict(os.environ, PYTHONPATH=str(root / "src") + os.pathsep + str(args.deps),
               OMP_NUM_THREADS="1", MKL_NUM_THREADS="1", PYTHONIOENCODING="utf-8")
    commands = {
        "ruff": [sys.executable, "-m", "ruff", "check", "src/soup_cli/", "scripts/",
                 "tests/", "benchmarks/"],
        "cpu-tests": [sys.executable, "-m", "pytest",
                      "tests/test_two_read_cache_evidence.py",
                      "tests/test_two_read_cache_runner.py",
                      "tests/test_two_read_cache_worker.py",
                      "tests/test_two_read_cache_preflight.py",
                      "tests/test_stream_expert_cache_accuracy.py",
                      "tests/test_stream_expert_cache_nf4.py",
                      "tests/test_expert_stream_two_read_contract.py",
                      "-q", "-o", "addopts=", "--tb=short",
                      "--junitxml=" + str(out / "cpu-tests.xml")],
        "help": [sys.executable, "benchmarks/harness/two_read_cache.py", "--help"],
    }
    started = time.perf_counter()
    if args.collect_existing:
        if "All checks passed!" not in (out / "ruff.log").read_text():
            raise ValueError("Existing Ruff output is not a passing report")
        if "usage:" not in (out / "help.log").read_text():
            raise ValueError("Existing help output is not complete")
    else:
        for name, command in commands.items():
            Console().print("Checking", name)
            with (out / (name + ".log")).open("wb") as log:
                subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT,
                               timeout=600, check=True)
    cases = ET.parse(out / "cpu-tests.xml").findall(".//testcase")
    if any(case.find("failure") is not None or case.find("error") is not None for case in cases):
        raise ValueError("Existing test report contains a failure or error")
    for name, expected in (("test_worker_capture_qualifies_all_four_cpu_semantic_arms", 2),
                           ("test_worker_capture_qualifies_real_nf4_four_arm_cpu_trajectories", 1),
                           ("test_real_cpu_nf4_expert_cache_preserves_complete_optimizer_trajectories",
                            1)):
        selected = [case for case in cases if case.attrib["name"].startswith(name)]
        if len(selected) != expected or any(len(case) for case in selected):
            raise ValueError("Required actual CPU trajectory did not execute: " + name)
    for case in cases:
        if "two_read_cache" in case.attrib["classname"] and len(case):
            raise ValueError("A new runner control was skipped or failed")
    result = {
        "status": "passed", "cpu_only": True, "gpu_rented": False, "new_spend_usd": 0,
        "tests": len(cases), "skipped": sum(case.find("skipped") is not None for case in cases),
        "passed": sum(not len(case) for case in cases), "full_repository_suite": False,
        "hosted_ci_verified": False, "commands": commands,
        "collected_from_completed_reports": args.collect_existing,
        "collection_note": "Parent dependency path fixed after successful commands; XML/logs retained",
        "seconds": time.perf_counter() - started, "python": platform.python_version(),
        "packages": {name: importlib.metadata.version(name) for name in (
            "torch", "transformers", "peft", "bitsandbytes", "trl", "pytest", "ruff")},
    }
    (out / "verification.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    Console().print(result)


if __name__ == "__main__":
    main()
