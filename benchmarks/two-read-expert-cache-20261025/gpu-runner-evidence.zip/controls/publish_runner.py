"""Preserve tested runner source and CPU evidence in the PR #5 research record."""

import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

from rich.console import Console

ROOT = Path(r"C:\Users\esenb\.codex\worktrees\cache-recompute-20261025\soup-rnd-d2")
PUBLICATION = Path(r"C:\Users\esenb\.codex\worktrees\stream-memory-auto-20261023\soup-rnd-d2")
HERE = Path(__file__).parent
DESTINATION = PUBLICATION / "benchmarks/two-read-expert-cache-20261025"


def main():
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
    relative = subprocess.check_output(
        ["git", "diff", "--name-only", "b9d32144", revision], cwd=ROOT, text=True,
    ).splitlines()
    if len(relative) != 8 or not all("two_read_cache" in path for path in relative):
        raise ValueError("Unexpected source scope in the runner commit")
    tests = ET.parse(HERE / "cpu-tests.xml")
    verification = json.loads((HERE / "verification.json").read_text())
    verification["test_seconds"] = sum(
        float(suite.attrib["time"]) for suite in tests.findall(".//testsuite")
    )
    verification["pre_commit_passed"] = True
    verification["source_commit"] = revision
    (HERE / "verification.json").write_text(json.dumps(verification, indent=2) + "\n")
    payload = {}
    for path in relative:
        data = (ROOT / path).read_bytes()
        if subprocess.check_output(["git", "show", revision + ":" + path], cwd=ROOT) != data:
            raise ValueError("Working source bytes differ from the committed tested source")
        payload["source/" + path] = data
    for name in ("verification.json", "cpu-tests.xml", "cpu-tests.log", "ruff.log",
                 "help.log", "pre-commit.log", "verify_runner.py", "publish_runner.py"):
        payload["controls/" + name] = (HERE / name).read_bytes()
    payload["runner.patch"] = subprocess.check_output(
        ["git", "diff", "--binary", "b9d32144", revision], cwd=ROOT,
    )
    digest = lambda data: hashlib.sha256(data).hexdigest()
    index = {name: {"bytes": len(data), "sha256": digest(data)}
             for name, data in payload.items()}
    payload["files.json"] = (json.dumps(index, indent=2) + "\n").encode()
    archive = DESTINATION / "gpu-runner-evidence.zip"
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for name, data in payload.items():
            bundle.writestr(name, data)
    with zipfile.ZipFile(archive) as bundle:
        for name, data in payload.items():
            if bundle.read(name) != data:
                raise ValueError("Archive verification failed: " + name)
    summary = {
        "source_commit": revision, "source_branch": "koko/two-read-cache-20261025",
        "preparation_only": True, "cpu_passed": verification["passed"],
        "cuda_skipped": verification["skipped"], "full_repository_suite": False,
        "ruff_passed": True, "pre_commit_passed": True, "gpu_qualified": False,
        "gpu_rented": False, "new_spend_usd": 0,
        "archive": {"path": archive.name, "bytes": archive.stat().st_size,
                    "sha256": digest(archive.read_bytes()), "verified_entries": len(payload)},
    }
    (DESTINATION / "gpu-runner-summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    source = "https://github.com/SoupTeam/soup-rnd/blob/" + revision
    report = f'''# GPU runner preparation: no rental or speed result

The four-arm runner is committed at [{revision[:8]}]({source}/benchmarks/harness/two_read_cache.py)
on `koko/two-read-cache-20261025`. The integration source and prior CPU report remain
separate from PR #5's older production diff. No runtime/config/default was changed
in this runner-only follow-up.

The [complete protocol and commands]({source}/benchmarks/harness/two_read_cache.md)
cover ordinary streaming, two-read, expert RAM/GPU caches and the combined arm.
Real-model CUDA numerical captures must pass before any speed block is launched.
Initial adapters/inputs/top-k indices are exact, floating gates remain reference-relative
`rtol=.01, atol=1e-5`, finite and three-decimal loss, and actual AdamW updates are required.

Physical 8 GiB GPU identity, native BF16, at most 32 GiB real RAM and disabled swap
are preflight gates. All arms share one frozen local checkpoint/token fixture and
identical cache ceilings; changed source/inputs/store/environment are refused.
Four balanced timing rounds use fresh processes, separate setup and warmup from
steps, record RSS/VRAM/read counters, and compare the combined arm with two-read
separately. Fixed-token numerical parity is not downstream model quality.

Local verification: **{verification['passed']} passed, {verification['skipped']} CUDA skipped**
in a focused seven-file selection ({verification['test_seconds']:.2f} s).
All new runner controls executed. The new capture pipeline passed real tiny-DeepSeek
FP32, BF16 and actual CPU NF4 four-arm trajectories bitwise, with both cache tiers
actually hit. Controller regressions reject mismatched inputs/adapters/gradients,
truncated trajectories, missing cache coverage, changed hashes and invalid timing.
Full-repository Ruff and applicable staged pre-commit passed. The full repository
test suite and hosted CI were not run. This adds runner controls to the older
598-pass integration record; it does not replace or reclassify that record.

The evidence collector initially lacked the isolated dependency directory in its
parent metadata path after the commands had passed. Its path was fixed and the
completed XML/logs were re-collected, without silently rerunning or replacing them.

[Portable patch, exact executed source, logs, XML and verification scripts](gpu-runner-evidence.zip)
are byte-checked against the internal `files.json`; [compact summary](gpu-runner-summary.json)
records the outer SHA-256. Package directories are excluded.

**GPU rental/spend: $0. No CUDA speed, memory, SSD throughput or real-checkpoint
quality result is claimed.** Existing GPU-rental prohibition remains in effect.
'''
    (DESTINATION / "GPU-RUNNER.md").write_text(report, encoding="utf-8")
    readme = DESTINATION / "README.md"
    text = readme.read_text(encoding="utf-8")
    marker = "## Reproducible GPU runner prepared"
    if marker not in text:
        readme.write_text(text + "\n" + marker + "\n\n"
                          "[Runner, commands and retained CPU verification](GPU-RUNNER.md): "
                          f"{verification['passed']} passed, {verification['skipped']} CUDA skip, "
                          "Ruff/pre-commit clean. This is preparation only; no GPU rental or speed result.\n",
                          encoding="utf-8")
    Console().print({"source_commit": revision, "publication": str(DESTINATION), **summary})


if __name__ == "__main__":
    main()
