"""Publish compact complete metrics; original large tensor captures remain hash-indexed locally."""

import hashlib
import json
import zipfile
from pathlib import Path

from rich.console import Console

ROOT = Path(__file__).parent
PUBLICATION = Path(r'C:\Users\esenb\.codex\worktrees\stream-memory-auto-20261023\soup-rnd-d2')
DEST = PUBLICATION / 'benchmarks/two-read-expert-cache-20261025'
GIB = 2**30


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    result = json.loads((ROOT / 'independent-results.json').read_text())
    assert result['status'] == 'passed' and result['owned_resource_absence']['verified_absent']
    result['raw_evidence_publication_scope'] = (
        'All original files retained and byte-verified locally; public packet contains full '
        'JSON/XML/log metrics, exact inputs, tiny CUDA captures and original raw-file hashes. '
        'Large real-model capture.pt tensors and model weights are not embedded in Git.'
    )
    native = ROOT / 'retained/results'
    payload = {}
    for path in native.rglob('*'):
        if not path.is_file():
            continue
        include = path.suffix in ('.json', '.xml', '.log', '.txt')
        include = include or path.name == 'inputs.pt'
        include = include or ('gpu-evidence' in path.parts and path.suffix == '.pt')
        if include and path.stat().st_size < 5 * 2**20:
            payload['results/' + path.relative_to(native).as_posix()] = path.read_bytes()
    public_operations = (
        'source-manifest.json', 'launch-manifest.json', 'archive-manifest.json',
        'bundle-verified.json', 'stage-ledger.json', 'independent-vast-absence.json',
        'network-preflight.json', 'capacity-preflight.json', 'compact-accuracy-audit.json',
        'local-prelaunch.xml', 'controller-tests.xml', 'preflight_remote.py',
        'remote_run.py', 'setup.sh', 'constraints.txt', 'remote_guard.py', 'cloud.py',
        'controller.py', 'launch.py', 'transport.py', 'lossless_results.py',
        'test_controller.py', 'review_results.py', 'publish_results.py',
        'range_recover.py', 'range-retention-recovery.json', 'manual-retention-complete.json',
        'controller-failure.json', 'collection-failure.json',
    )
    for name in public_operations:
        path = ROOT / name
        if path.is_file():
            payload['controls/' + name] = path.read_bytes()
    for label in ('a', 'b'):
        attempt = ROOT.with_name('two-read-gpu-20261025-' + label)
        for name in ('vast-deletion.json', 'independent-vast-absence.json',
                     'controller-failure.json', 'collection-failure.json'):
            path = attempt / name
            if path.is_file():
                payload[f'earlier-attempts/{label}/{name}'] = path.read_bytes()
    payload['independent-results.json'] = (json.dumps(result, indent=2) + '\n').encode()
    index = {name: {'bytes': len(data), 'sha256': digest(data)} for name, data in payload.items()}
    payload['files.json'] = (json.dumps(index, indent=2) + '\n').encode()
    archive = DEST / 'gpu-results-evidence.zip'
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for name, data in sorted(payload.items()):
            bundle.writestr(name, data)
    with zipfile.ZipFile(archive) as bundle:
        assert all(bundle.read(name) == data for name, data in payload.items())
    if archive.stat().st_size > 5 * 2**20:
        raise ValueError('Compact public record exceeds repository file-size policy')
    result['public_archive'] = {
        'path': archive.name, 'bytes': archive.stat().st_size,
        'sha256': digest(archive.read_bytes()), 'entries': len(payload),
    }
    (DEST / 'gpu-results-summary.json').write_text(json.dumps(result, indent=2) + '\n')
    labels = {'ordinary': 'Ordinary streaming', 'two_read': 'Two-read',
              'cache': 'RAM/GPU caches', 'two_read_cache': 'Two-read + caches'}
    table = []
    for arm in labels:
        row = result['rows'][arm]
        table.append(f"| {labels[arm]} | {row['median_update_seconds']:.4f} | "
                     f"{row['tokens_per_second']:.2f} | "
                     f"{row['max_step_allocated_bytes']/GIB:.4f} | "
                     f"{row['max_step_reserved_bytes']/GIB:.4f} | "
                     f"{row['peak_process_lifetime_rss_bytes']/GIB:.4f} | "
                     f"{row['median_setup_seconds']:.3f} | "
                     f"{row['median_fresh_entry_seconds']:.3f} |")
    timings = result['timing']
    comparison_lines = []
    for key, comparison in {**timings['comparisons'], **timings['incremental_comparisons']}.items():
        low, high = comparison['paired_bootstrap_95_percent']
        comparison_lines.append(
            f"- `{key}` vs `{comparison['reference']}`: paired step-time reduction "
            f"**{comparison['step_time_reduction_percent']:.3f}%**, 95% interval "
            f"[{low:.3f}, {high:.3f}]%; >=2% gate: "
            f"**{'PASS' if comparison['passes_practical_2_percent_gate'] else 'FAIL'}**."
        )
    combined = timings['incremental_comparisons']['two_read_cache_vs_two_read']
    delta = combined['step_time_reduction_percent']
    verdict = (f'The current caches slow two-read by **{-delta:.3f}%** in this workload; '
               'there is no incremental speed benefit.') if delta < 0 else (
               f'The current caches reduce two-read step time by **{delta:.3f}%**; '
               f"practical gate: {'PASS' if combined['passes_practical_2_percent_gate'] else 'FAIL'}.")
    behavior = result['cache_behavior']['expert_counter_deltas']
    counter_table = '\n'.join(
        f"| {labels[arm]} | {row['logical_fetches']} | {row['storage_reads']} | "
        f"{row['host_hits']} | {row['device_hits']} |"
        for arm, row in behavior.items()
    )
    report = f'''# Moonlight-16B: two-read with expert RAM/GPU caches

{verdict}
All four short numerical captures pass the original gates and independently
recompare **bitwise** after lossless transfer. A negative speed result is retained.

## Fixed experiment

- Source [`{result['source_commit'][:8]}`](https://github.com/SoupTeam/soup-rnd/tree/{result['source_commit']});
  upstream two-read PR [#2158](https://github.com/MakazhanAlpamys/Soup/pull/2158)
  at `f2599ddc` is preserved by merge, with its authorship. The integration and runner
  remain on the companion branch; PR #5's older production diff is separate.
  The executed archive/per-file hashes are retained; the provenance audit records
  the CRLF/LF normalization bridge between archive bytes and the Git source.
- Real `moonshotai/Moonlight-16B-A3B`, revision `{result['model_revision']}`.
  Frozen NF4 base, BF16 compute, native FP32 attention LoRA rank 4 / alpha 8 on
  `q_proj`, `kv_b_proj`, `o_proj`; 162 trainable adapter tensors.
- Physical RTX 4060 Ti: 8188 MiB VRAM; native RAM ceiling **29.756 GiB**,
  `memory.swap.max=0`, no observed process/container swap. Disk tier, two decoder
  buffers, decoder recompute on, no retained activations or compilation.
- Batch 1, context 512, accumulation 2: **1024 processed tokens per optimizer update**.
  Identical frozen random IDs and adapter initialization in every arm.
  Cache arms both request **2 GiB packed RAM + .25 GiB dense GPU** ceilings.
  This is an explicit placement test, not a policy that fills all free memory.

## Speed and memory

| Arm | Median step, s | Tokens/s | Peak allocated VRAM, GiB | Peak reserved VRAM, GiB | Peak process RSS, GiB | Median setup, s | Fresh process wall, s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
{chr(10).join(table)}

Four balanced rounds, **16 fresh processes**, two warmup plus six measured updates
each: **96 timed + 32 warmup updates**. No times or processes were excluded.
RSS is the native process lifetime high-water mark; step allocator peaks come
from unprofiled measured updates. Setup/warmup, scalar/state checks and file writes
are retained separately. Fresh process wall includes interpreter/build/setup costs.

{chr(10).join(comparison_lines)}

Intervals use the frozen 5,000-sample paired round bootstrap of block medians.
These are small-sample, fixed-model/host/input results. Independent improvements
are never added, and percentages refer to step time, not a full training job.

## Accuracy and mechanism

Two actual CUDA preflight trajectory tests passed, without skips, before downloading
the real weights. Then each real-model arm completed two AdamW updates with four
accumulated microbatches. Initial adapters/IDs/top-k indices are exact, floating
values retain reference-relative `rtol=.01, atol=1e-5`, finiteness and three-decimal
loss gates. The controller compared full loss/logits/differentiable-input gradients,
router logits/weights and gradients, every LoRA gradient, final adapters and AdamW
moments. All 162 adapters actually changed and baseline gradients are nonzero.

All four original captures were reconstructed byte-for-byte and independently
compared again locally; every candidate is **bitwise** equal to ordinary. All
retained unprofiled loss sequences also match their paired ordinary controls.
This is short **same-NF4 numerical parity**, not BF16-vs-NF4 quality equivalence,
downstream task quality, convergence or full-model fine-tuning.

Accuracy-phase counter deltas, excluding setup probes:

| Arm | Logical expert visits | Expert file reads | RAM hits | GPU hits |
| --- | ---: | ---: | ---: | ---: |
{counter_table}

The 3:2 visit ratio is exact and both cache tiers actually hit. Expert file counters
count tensor payload, not physical SSD traffic. Linux process read-byte counters
and direct-I/O status are retained separately; the container uses loopback-backed
storage and **physical NVMe backing is unverified**.

The mechanisms overlap: cache-only and combined already perform nearly the same
number of file reads. A RAM hit still transfers/dequantizes the expert; a miss
adds owned CPU clones and LRU eviction/allocation. This source inspection offers
a plausible overhead explanation, not a causal profile or a proven speed ceiling.
A static immutable RAM hotset is a prospective next A/B, **not implemented or
measured by this result**. Async/pinned transfer changes need separate lifetime tests.

## Retention, cost and cleanup

Complete source/model/spec hashes, raw timings, allocator/RSS/swap/I/O snapshots,
gate reports, logs and the exact input fixture are in the
[compact public record](gpu-results-evidence.zip), indexed by its internal `files.json`.
The [summary](gpu-results-summary.json) includes the original full-file hashes.
All large original result tensors and the self-contained lossless archive remain locally
retained; large real-model `capture.pt` files and base weights are not embedded in Git.
Base weights remain reproducibly identified by their public revision and full hashes;
they were removed with the rented disk rather than copied to the local result record.
The decoder verified every encoded chunk, reconstructed chunk and original file,
followed by independent outer-manifest SHA checks. Compression changes no tensor bytes.

The large-file SFTP collector slowed after its small transport control. An
authenticated four-connection SSH range fallback recovered the **same immutable
archive**, with exact range lengths and final whole-archive SHA, before decoding
and verifying all originals. Resources were removed only after that retention
proof; any interrupted original SFTP-controller trace is retained separately and
is not treated as a failed training/timing arm.

Conservative aggregate accounting, **including both earlier failed attempts**:
**${result['budget']['conservative_usd']:.6f}** from the ${result['budget']['initial_usd']:.6f}
remaining allowance; **${result['budget']['remaining_usd']:.6f} remains**. This is an
upper accounting estimate with network/time reserves, not an invoice.

Earlier attempt A stopped before setup due to a controller-file freeze race;
attempt B stopped before installing/downloading the model because plain full-raw
retention could not fit the transport deadline. Both are retained and accounted for,
not included as timing arms. Immutable handoff and the existing lossless codec
were qualified before attempt C. The Moonlight full-rank-query target fix passed
81 local tests with one expected CUDA skip; two real CUDA controls later passed.

Every owned instance and persistent volume from all three attempts was deleted
and fresh exact-ID/label listings confirmed absence. Unrelated group resources
were untouched. Hosted CI was not awaited or counted as GPU verification.
'''
    (DEST / 'GPU-RESULTS.md').write_text(report, encoding='utf-8')
    readme = DEST / 'README.md'
    text = readme.read_text(encoding='utf-8')
    latest = '**Latest GPU result:** [Moonlight four-arm qualification](GPU-RESULTS.md).'
    if latest not in text:
        heading, remainder = text.split('\n', 1)
        text = heading + '\n\n' + latest + '\n' + remainder
        text = text.replace('Status: CPU correctness controls passed;',
                            'Original preparation status: CPU correctness controls passed;', 1)
    marker = '## Real Moonlight GPU qualification completed'
    if marker not in text:
        text += '\n' + marker + '\n\n[Four-arm results, exact gates, memory and cleanup](GPU-RESULTS.md).\n'
        readme.write_text(text, encoding='utf-8')
    elif latest in text:
        readme.write_text(text, encoding='utf-8')
    Console().print({'record': str(DEST / 'GPU-RESULTS.md'), 'public_files': len(payload),
                     'public_archive_bytes': archive.stat().st_size, 'verdict': verdict})


if __name__ == '__main__':
    main()
