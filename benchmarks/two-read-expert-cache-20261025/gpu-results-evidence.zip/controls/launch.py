"""Explicit root launch with unconditional exact-instance/volume cleanup."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT / ".deps"))

import cloud  # noqa: E402
import controller  # noqa: E402


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--offer-id", required=True, type=int)
    parser.add_argument("--volume-ask-id", required=True, type=int)
    parser.add_argument("--seconds", default=10800, type=int)
    args = parser.parse_args(argv)
    controller.freeze_check()
    try:
        cloud.allocate(args)
        return controller.main()
    finally:
        if (cloud.ROOT / "vast-rental.json").is_file():
            try:
                cloud.destroy("Outer launch finally: exact-owned instance and volume cleanup")
            finally:
                controller.verify_absence()


if __name__ == "__main__":
    main()
