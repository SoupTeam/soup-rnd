"""Recheck retained CPU tensors and every raw timing block after GPU cleanup."""

from __future__ import annotations

import gc
import json
import math
import statistics
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

from rich.console import Console

ROOT = Path(__file__).parent
REPO = Path(r'C:\Users\esenb\.codex\worktrees\cache-recompute-20261025\soup-rnd-d2')
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / 'src'))
sys.path.insert(0, str(ROOT / '.deps'))


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def main():
    import torch

    from benchmarks.harness.two_read_cache import ARMS, timing_summary, validate_cache_behavior
    from benchmarks.harness.two_read_cache_common import (
        atomic_json,
        compare_captures,
        sha256_file,
        validate_capture,
    )

    torch.set_num_threads(1)
    bundle = read(ROOT / 'bundle-verified.json')
    assert bundle['all_manifested_raw_files_retained']
    absence = read(ROOT / 'independent-vast-absence.json')
    assert absence['verified_absent']
    out = ROOT / 'retained/results'
    report = read(out / 'qualification/run.json')
    spec_path = out / 'prepared/spec.json'
    spec = read(spec_path)
    spec_sha = sha256_file(spec_path)
    assert report['status'] == 'completed' and report['accuracy_passed']
    assert len(report['timing_blocks']) == 16 and report['spec_sha256'] == spec_sha
    assert spec['batch_size'] == 1 and spec['seq_len'] == 512 and spec['accumulation'] == 2
    assert spec['host_cache_bytes'] == 2 * 2**30 and spec['device_cache_bytes'] == 2**28
    capture_dir = out / 'qualification/accuracy'
    reference = torch.load(capture_dir / 'ordinary/capture.pt', map_location='cpu', weights_only=True)
    gates = {'ordinary': validate_capture(reference)}
    adapters = len(reference['initial_adapters'])
    assert adapters == 162
    inputs = torch.load(out / 'prepared/inputs.pt', map_location='cpu', weights_only=True)
    assert all(torch.equal(micro['input_ids'], inputs[index])
               for index, micro in enumerate(reference['microbatches']))
    assert all(torch.count_nonzero(value).item() > 0
               for micro in reference['microbatches'] for value in micro['gradients'].values())
    for arm in ARMS:
        worker = report['accuracy'][arm]['worker']
        assert worker['status'] == 'passed' and worker['spec_sha256'] == spec_sha
        assert sha256_file(capture_dir / arm / 'capture.pt') == worker['accuracy']['capture_sha256']
        if arm == 'ordinary':
            continue
        Console().print('Rechecking full retained capture:', arm)
        candidate = torch.load(capture_dir / arm / 'capture.pt', map_location='cpu', weights_only=True)
        gates[arm] = compare_captures(reference, candidate)
        assert gates[arm]['passed'] and gates[arm]['bitwise']
        assert len(candidate['updates']) == 2 and len(candidate['microbatches']) == 4
        del candidate
        gc.collect()
    assert gates['ordinary']['passed']
    del reference
    gc.collect()
    behavior = validate_cache_behavior(report['accuracy'])
    independent_timing = timing_summary(report['timing_blocks'])
    rows = {}
    for arm in ARMS:
        blocks = [row['result'] for row in report['timing_blocks'] if row['arm'] == arm]
        assert len(blocks) == 4
        for block in blocks:
            assert block['status'] == 'passed' and block['spec_sha256'] == spec_sha
            for stage, count in (('warmup', 2), ('timing', 6)):
                row = block[stage]
                assert len(row['update_seconds']) == count and row['complete']
                assert row['finite_state_checks_per_update']
                assert all(math.isfinite(loss) for loss in row['losses'])
                assert row['resources']['sampled_peak_process_swap_bytes'] == 0
                assert row['resources'].get('sampled_peak_cgroup_swap_bytes', 0) == 0
            assert block['timing']['cuda']['peak_reserved_bytes'] <= spec['device_cap_bytes']
        absolute = independent_timing['arms'][arm]
        rows[arm] = {
            **absolute,
            'peak_process_lifetime_rss_bytes': max(
                block['resources_after']['process_lifetime_peak_rss_bytes'] for block in blocks
            ),
            'median_setup_seconds': statistics.median(block['setup']['seconds'] for block in blocks),
            'median_fresh_entry_seconds': statistics.median(
                block['fresh_process_wall_seconds'] for block in blocks
            ),
            'mean_expert_storage_reads_per_timed_update': statistics.mean(
                block['timing']['runtime_delta']['expert_cache']['storage_reads'] / 6
                for block in blocks
            ),
            'mean_expert_payload_bytes_per_timed_update': statistics.mean(
                block['timing']['runtime_delta']['expert_cache']['storage_bytes_read'] / 6
                for block in blocks
            ),
            'mean_kernel_physical_read_bytes_per_timed_update': statistics.mean(
                block['timing']['resources']['process_io_delta']['read_bytes'] / 6
                for block in blocks
            ),
        }
    native = report['timing_summary']
    for number in range(4):
        paired = {row['arm']: row['result'] for row in report['timing_blocks']
                  if row['round'] == number}
        for arm in ARMS[1:]:
            for stage in ('warmup', 'timing'):
                reference_losses = paired['ordinary'][stage]['losses']
                actual_losses = paired[arm][stage]['losses']
                assert len(reference_losses) == len(actual_losses)
                assert all(f'{reference:.3f}' == f'{actual:.3f}' and
                           abs(actual - reference) <= 1e-5 + .01 * abs(reference)
                           for reference, actual in zip(reference_losses, actual_losses))
    for key in ('comparisons', 'incremental_comparisons'):
        for name, comparison in independent_timing[key].items():
            assert math.isclose(comparison['step_time_reduction_percent'],
                                native[key][name]['step_time_reduction_percent'], abs_tol=1e-10)
            assert comparison['passes_practical_2_percent_gate'] == (
                native[key][name]['passes_practical_2_percent_gate']
            )
    cases = ET.parse(out / 'gpu-preflight.xml').findall('.//testcase')
    assert len(cases) == 2 and all(case.find('skipped') is None and
                                case.find('failure') is None and case.find('error') is None
                                for case in cases)
    ledger = read(ROOT / 'stage-ledger.json')
    total = sum(float(row['conservative_usd']) for row in ledger['completed_leases'])
    assert total <= ledger['maximum_stage_usd'] and all(
        row['verified_absent'] and row['volume_verified_absent'] for row in ledger['completed_leases']
    )
    result = {
        'status': 'passed', 'source_commit': read(ROOT / 'source-manifest.json')['source_commit'],
        'model': 'moonshotai/Moonlight-16B-A3B', 'model_revision':
        '476b36a473d4467f94469414bef6cee75c9c8172',
        'same_nf4_base_numerical_qualification_only': True, 'task_quality_or_convergence': False,
        'spec_sha256': spec_sha, 'gpu': spec['hardware'], 'environment': spec['environment'],
        'ram_boundary': spec['host_boundary'], 'accuracy': gates, 'adapters': adapters,
        'accuracy_updates_per_arm': 2, 'accumulated_microbatches_per_arm': 4,
        'all_baseline_gradient_tensors_nonzero': True,
        'cache_behavior': behavior, 'timing': independent_timing, 'rows': rows,
        'fresh_processes': 16, 'timed_updates': 96, 'warmup_updates': 32,
        'budget': {'initial_usd': ledger['maximum_stage_usd'], 'conservative_usd': total,
                   'remaining_usd': ledger['maximum_stage_usd'] - total, 'invoice': False},
        'owned_resource_absence': absence, 'all_attempts': ledger['completed_leases'],
        'all_raw_retained_locally': True,
        'raw_archive': read(ROOT / 'archive-manifest.json'),
        'native_timing_recomputed_from_all_raw_arrays': True,
        'all_four_full_captures_independently_recompared_after_transport': True,
        'all_retained_unprofiled_loss_sequences_match_their_paired_baselines': True,
    }
    atomic_json(ROOT / 'independent-results.json', result)
    Console().print({'status': 'passed', 'rows': rows, 'comparisons': independent_timing['comparisons'],
                     'incremental': independent_timing['incremental_comparisons'], 'budget': result['budget']})


if __name__ == '__main__':
    main()
