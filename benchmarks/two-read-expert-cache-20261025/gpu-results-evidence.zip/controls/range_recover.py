"""Recover one immutable completed archive through authenticated bounded SSH ranges."""

from __future__ import annotations

import concurrent.futures
import hashlib
import io
import json
import os
import shlex
import sys
import time
from pathlib import Path

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT / '.deps'))
import cloud
import controller
import transport
from rich.console import Console

CHUNK = 4 * 2**20
REMOTE = '/root/liger/exports/result.lossless.tar'


def main():
    manifest = json.loads((ROOT / 'archive-manifest.json').read_text())
    policy = cloud.receipt()
    total = manifest['archive_bytes']
    expected = manifest['sha256']
    parts = ROOT / 'verified-range-parts'
    parts.mkdir(exist_ok=True)
    started = time.monotonic()
    prefix = ROOT / 'result.lossless.tar.incoming'
    prefix_blocks = min(prefix.stat().st_size // CHUNK, total // CHUNK) if prefix.exists() else 0
    if prefix_blocks:
        with prefix.open('rb') as source:
            for index in range(prefix_blocks):
                target = parts / f'{index:05d}.part'
                data = source.read(CHUNK)
                assert len(data) == CHUNK
                if not target.exists():
                    target.write_bytes(data)
    count = (total + CHUNK - 1) // CHUNK

    def download(index):
        offset = index * CHUNK
        size = min(CHUNK, total - offset)
        target = parts / f'{index:05d}.part'
        if target.exists() and target.stat().st_size == size:
            return index, size, 'reused'
        program = ('import sys; f=open(' + repr(REMOTE) + ',"rb"); '
                   f'f.seek({offset}); sys.stdout.buffer.write(f.read({size}))')
        last = None
        for attempt in range(3):
            if time.time() >= policy['created_unix'] + policy['maximum_seconds'] - 180:
                raise TimeoutError('Preserve resource-cleanup time')
            try:
                sink = io.BytesIO()
                actual = transport.stream('python3 -c ' + shlex.quote(program), sink, timeout=90)
                data = sink.getvalue()
                if actual != size or len(data) != size:
                    raise EOFError('Short successful SSH response is not a complete range')
                temporary = target.with_suffix('.incoming')
                temporary.write_bytes(data)
                os.replace(temporary, target)
                return index, size, 'downloaded'
            except Exception as exc:
                last = exc
                if attempt < 2:
                    time.sleep(2)
        raise RuntimeError(f'Range {index} failed: {last}')

    done = 0
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        futures = [pool.submit(download, index) for index in range(count)]
        for future in concurrent.futures.as_completed(futures):
            index, size, mode = future.result()
            done += size
            if done % (32 * 2**20) < CHUNK or done == total:
                Console().print({'range_bytes_complete': done, 'total_bytes': total,
                                 'elapsed_seconds': round(time.monotonic() - started, 1)})
    target = ROOT / 'result.lossless.tar'
    temporary = ROOT / 'result-range-complete.incoming'
    digest = hashlib.sha256()
    with temporary.open('wb') as sink:
        for index in range(count):
            data = (parts / f'{index:05d}.part').read_bytes()
            digest.update(data)
            sink.write(data)
    if temporary.stat().st_size != total or digest.hexdigest() != expected:
        raise ValueError('Complete range reconstruction failed the frozen archive SHA256')
    os.replace(temporary, target)
    cloud.save('range-retention-recovery.json', {
        'archive_bytes': total, 'archive_sha256': expected, 'all_ranges_exact_length': True,
        'whole_archive_verified': True, 'prefix_reused_bytes': prefix_blocks * CHUNK,
        'ranges': count, 'range_bytes': CHUNK, 'concurrent_connections': 4,
        'seconds': time.monotonic() - started,
        'route': 'authenticated SSH ranges; unchanged frozen remote archive',
    })
    # The original SFTP collector can complete normally in parallel. Prefer its receipt.
    for _ in range(30):
        if (ROOT / 'bundle-verified.json').exists():
            break
        if not (ROOT / 'retained').exists():
            break
        time.sleep(2)
    if not (ROOT / 'bundle-verified.json').exists():
        controller.collect_archive(policy)
    proof = json.loads((ROOT / 'bundle-verified.json').read_text())
    if not proof['all_manifested_raw_files_retained']:
        raise ValueError('Raw files have not all been independently reconstructed and verified')
    cloud.save('manual-retention-complete.json', {
        'all_manifested_raw_files_retained': True, 'archive_sha256': expected,
        'verified_files': len(manifest['files']), 'unix': time.time(),
    })
    cloud.destroy('All raw results independently retained through hash-verified SSH ranges')
    controller.verify_absence()
    Console().print({'raw_retention': 'verified', 'instance_and_volume': 'deleted'})


if __name__ == '__main__':
    main()
