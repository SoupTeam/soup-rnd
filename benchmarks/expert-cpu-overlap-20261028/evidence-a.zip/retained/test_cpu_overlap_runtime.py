"""Behavioral integration controls for the private thread-injection wrapper."""

from __future__ import annotations

import contextlib
import json
import os
import sys
from types import SimpleNamespace

import pytest

import cpu_overlap_probe as probe


class TorchControl:
    def __init__(self, events):
        self.threads, self.events = 1, events

    def get_num_threads(self):
        return self.threads

    def get_num_interop_threads(self):
        return 2

    def set_num_threads(self, count):
        self.events.append(("set_threads", count))
        self.threads = count


def wrapper_fixture(tmp_path, monkeypatch, *, failure=False, drift=False):
    events = []
    torch = TorchControl(events)
    monkeypatch.setitem(sys.modules, "torch", torch)
    spec = {"git_head": probe.COMMIT, "dtype": "bfloat16", "quant": "nf4",
            "accuracy_updates": 2, "accumulation": 2, "warmup_updates": 2,
            "timed_updates": 6, "seq_len": 512, "batch_size": 1,
            "host_cache_bytes": 8 * 2**30, "device_cache_bytes": 2 * 2**30,
            "host_cache_policy": "static"}
    spec_path, protocol_path = tmp_path / "spec.json", tmp_path / "protocol.json"
    probe.save(spec_path, spec)
    probe.save(protocol_path, {"execution_plan": probe.CONTRACT})

    def build(*_args, **_kwargs):
        events.extend([("build", torch.threads), ("initialize", torch.threads)])
        return "model", "runtime", "plan"

    worker = SimpleNamespace(_build=build)

    def run_worker(spec_file, arm, phase, out):
        assert worker._build(spec, arm) == ("model", "runtime", "plan")
        events.append(("train", torch.threads))
        if failure:
            raise RuntimeError("controlled native failure")
        if drift:
            torch.set_num_threads(8)
        probe.save(out / "result.json", {"status": "passed", "arm": arm, "phase": phase,
                                         "pid": os.getpid(),
                                         "spec_sha256": probe.digest(spec_file)})
        return 0

    worker.run_worker = run_worker

    @contextlib.contextmanager
    def dispatch(_module, variant):
        assert variant == "grouped"
        value = {"restored": False}
        try:
            yield value
        finally:
            value["restored"] = True

    def validate_dispatch(value, variant):
        assert variant == "grouped" and value["restored"] is True

    qualified = SimpleNamespace(
        project=lambda *_args: (SimpleNamespace(verify_spec=lambda *_a, **_k: None),
                                worker, None, object(), {"source_commit": probe.COMMIT}),
        dispatch=dispatch, validate_dispatch_evidence=validate_dispatch,
        validate_native_routes=lambda *_args: None)
    monkeypatch.setattr(probe, "modules", lambda _root: qualified)
    args = SimpleNamespace(source_root=tmp_path, spec=spec_path, protocol=protocol_path,
                           out=tmp_path / "out", policy="t4", phase="accuracy")
    return args, worker, build, events


def test_thread_override_happens_after_identical_native_initialization(tmp_path, monkeypatch):
    args, worker, original, events = wrapper_fixture(tmp_path, monkeypatch)
    assert probe.worker_main(args) == 0
    assert events == [("build", 1), ("initialize", 1), ("set_threads", 4), ("train", 4)]
    assert worker._build is original
    raw = json.loads((args.out / "cpu-envelope.json").read_text())
    assert raw["status"] == "passed"
    assert raw["thread_control"]["before"]["intraop"] == 1
    assert raw["thread_control"]["after"]["intraop"] == 4


@pytest.mark.parametrize("failure,drift", [(True, False), (False, True)])
def test_native_failure_or_thread_drift_retains_failure_and_restores_build(
    tmp_path, monkeypatch, failure, drift,
):
    args, worker, original, _events = wrapper_fixture(
        tmp_path, monkeypatch, failure=failure, drift=drift)
    assert probe.worker_main(args) == 1
    assert worker._build is original
    assert json.loads((args.out / "cpu-envelope.json").read_text())["status"] == "failed"


def test_native_policy_does_not_set_cpu_thread_count(tmp_path, monkeypatch):
    args, _worker, _original, events = wrapper_fixture(tmp_path, monkeypatch)
    args.policy = "native"
    assert probe.worker_main(args) == 0
    assert events == [("build", 1), ("initialize", 1), ("train", 1)]


def test_profile_lifecycle_restores_fetcher_even_if_stop_fails(monkeypatch):
    calls = []

    class Fetcher:
        def fetch(self):
            return self

    original = Fetcher.fetch
    monkeypatch.setitem(sys.modules, "soup_cli.utils.expert_stream",
                        SimpleNamespace(ExpertFetcher=Fetcher))

    def stop():
        calls.append("stop")
        raise RuntimeError("controlled profiler stop failure")

    profiler = SimpleNamespace(start=lambda: calls.append("start"), stop=stop)
    torch = SimpleNamespace(cuda=SimpleNamespace(synchronize=lambda: None))
    window = probe.FetchWindow(profiler, torch)
    fetcher = Fetcher()
    with pytest.raises(RuntimeError, match="stop failure"), window.installed():
        window.enabled = True
        for _ in range(1040):
            assert fetcher.fetch() is fetcher
    assert Fetcher.fetch is original
    assert window.evidence["restored"] is True
    assert window.evidence["stopped"] is False
    assert calls == ["start", "stop"]
