"""Independent, data-free controls for the preregistered CPU-thread study."""

from __future__ import annotations

import copy
import gzip
import importlib.util
import json
import math
import sys
from pathlib import Path
from types import ModuleType, SimpleNamespace

import pytest

ROOT = Path(__file__).parent
SPEC = importlib.util.spec_from_file_location(
    "independent_cpu_overlap", ROOT / "cpu_overlap_probe.py")
PROBE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(PROBE)
TIMELINE_SPEC = importlib.util.spec_from_file_location(
    "independent_profile_timeline", ROOT / "profile_timeline.py")
TIMELINE = importlib.util.module_from_spec(TIMELINE_SPEC)
TIMELINE_SPEC.loader.exec_module(TIMELINE)
COMMON = SimpleNamespace(RTOL=.01, ATOL=1e-5)


class FakeTorch:
    def __init__(self, count=1):
        self.count = count
        self.interop = 2
        self.calls = []

    def get_num_threads(self):
        return self.count

    def get_num_interop_threads(self):
        return self.interop

    def set_num_threads(self, value):
        self.calls.append(value)
        self.count = value


@pytest.mark.parametrize("count", [None, 1, 2, 4, 8])
def test_threads_exact_policy_without_environment_or_interop_changes(count):
    torch = FakeTorch()
    control = PROBE.apply_threads(torch, count)
    assert control["applied_after_build"] is True
    assert control["requested"] == count
    assert control["after"]["intraop"] == (1 if count is None else count)
    assert torch.calls == ([] if count is None else [count])
    for key in ("interop", "affinity", "env"):
        assert control["before"][key] == control["after"][key]


@pytest.mark.parametrize("count", [True, False, 0, -1, 3, 16, 2., "2"])
def test_threads_reject_unregistered_values_before_setting(count):
    torch = FakeTorch()
    with pytest.raises(ValueError):
        PROBE.apply_threads(torch, count)
    assert not torch.calls


def test_threads_reject_silent_failure_to_apply():
    torch = FakeTorch()
    torch.set_num_threads = lambda _value: None
    with pytest.raises(ValueError, match="did not take effect"):
        PROBE.apply_threads(torch, 8)


def test_threads_reject_interop_drift():
    torch = FakeTorch()

    def change(value):
        torch.count, torch.interop = value, 8

    torch.set_num_threads = change
    with pytest.raises(ValueError, match="interop"):
        PROBE.apply_threads(torch, 8)


def profile_fixture():
    summary = {"event_count": 100, "cuda_event_count": 30,
               "cuda_kernel_event_count": 20, "cuda_h2d_event_count": 10}
    window = {"skip_fetches": 1024, "requested_fetches": 16, "profiled_fetches": 16,
              "started": True, "stopped": True, "restored": True,
              "microbatch": 0, "phase": "forward"}
    window["cache_before"] = {"logical_fetches": 1024, "storage_reads": 0,
                              "storage_bytes_read": 0, "materializations": 1024,
                              "host": {"hits": 1024}, "device": {"hits": 0}}
    window["cache_after"] = {"logical_fetches": 1040, "storage_reads": 0,
                             "storage_bytes_read": 0, "materializations": 1040,
                             "host": {"hits": 1040}, "device": {"hits": 0}}
    window["cache_delta"] = {"logical_fetches": 16, "storage_reads": 0,
                             "storage_bytes_read": 0, "materializations": 16,
                             "host_hits": 16, "device_hits": 0}
    return summary, window


def test_profile_requires_bounded_actual_cpu_kernel_and_h2d_window():
    PROBE.validate_profile(*profile_fixture())


@pytest.mark.parametrize("key,value", [
    ("skip_fetches", 0), ("requested_fetches", 128), ("profiled_fetches", 15),
    ("profiled_fetches", 17), ("started", False), ("stopped", False),
    ("restored", False), ("microbatch", 1), ("phase", "backward"),
])
def test_profile_reject_incomplete_or_scope_drift(key, value):
    summary, window = profile_fixture()
    window[key] = value
    with pytest.raises(ValueError):
        PROBE.validate_profile(summary, window)


@pytest.mark.parametrize("key,value", [
    ("cuda_event_count", 100), ("cuda_kernel_event_count", 0),
    ("cuda_h2d_event_count", 0), ("event_count", 0),
])
def test_profile_reject_cpu_only_or_missing_transfer(key, value):
    summary, window = profile_fixture()
    summary[key] = value
    with pytest.raises(ValueError):
        PROBE.validate_profile(summary, window)


def install_fake_fetcher(monkeypatch, fail_at=None):
    events = []

    class Fetcher:
        def __init__(self):
            self.calls = 0

        def fetch(self):
            self.calls += 1
            events.append(("fetch", self.calls))
            if self.calls == fail_at:
                raise RuntimeError("controlled fetch failure")
            return self.calls

        def cache_stats(self):
            return {"logical_fetches": self.calls, "storage_reads": 0,
                    "storage_bytes_read": 0, "materializations": self.calls,
                    "host": {"hits": self.calls}, "device": {"hits": 0}}

    monkeypatch.setitem(sys.modules, "soup_cli.utils.expert_stream",
                        SimpleNamespace(ExpertFetcher=Fetcher))
    profiler = SimpleNamespace(start=lambda: events.append(("start", 0)),
                               stop=lambda: events.append(("stop", 0)))
    torch = SimpleNamespace(cuda=SimpleNamespace(
        synchronize=lambda: events.append(("sync", 0))))
    return Fetcher, events, profiler, torch


def test_fetch_window_counts_exact_actual_calls_and_restores_original(monkeypatch):
    cls, events, profiler, torch = install_fake_fetcher(monkeypatch)
    original = cls.fetch
    window, fetcher = PROBE.FetchWindow(profiler, torch), cls()
    with window.installed():
        window.enabled = True
        for _ in range(1050):
            fetcher.fetch()
        window.enabled = False
        fetcher.fetch()
    assert window.calls == 1050
    assert window.evidence["profiled_fetches"] == 16
    assert events.index(("start", 0)) < events.index(("fetch", 1025))
    assert events.index(("stop", 0)) > events.index(("fetch", 1040))
    assert events.count(("start", 0)) == events.count(("stop", 0)) == 1
    assert cls.fetch is original and window.evidence["restored"] is True
    assert window.evidence["cache_after"]["host"]["hits"] - window.evidence[
        "cache_before"]["host"]["hits"] == 16
    PROBE.validate_profile(profile_fixture()[0], window.evidence)


def test_fetch_window_failure_stops_profiler_and_restores_original(monkeypatch):
    cls, events, profiler, torch = install_fake_fetcher(monkeypatch, fail_at=1026)
    original = cls.fetch
    window, fetcher = PROBE.FetchWindow(profiler, torch), cls()
    with pytest.raises(RuntimeError, match="controlled fetch failure"), window.installed():
        window.enabled = True
        for _ in range(1050):
            fetcher.fetch()
    assert cls.fetch is original and window.evidence["restored"] is True
    assert events.count(("stop", 0)) == 1
    with pytest.raises(ValueError):
        PROBE.validate_profile(profile_fixture()[0], window.evidence)


def test_fetch_window_never_profiles_disabled_backward_calls(monkeypatch):
    cls, events, profiler, torch = install_fake_fetcher(monkeypatch)
    window, fetcher = PROBE.FetchWindow(profiler, torch), cls()
    with window.installed():
        for _ in range(300):
            fetcher.fetch()
    assert window.calls == 0
    assert not any(event[0] in {"start", "stop"} for event in events)
    assert window.evidence["restored"] is True


def test_actual_trace_gpu_categories_exclude_cpu_api_names_and_union_overlapping_times(tmp_path):
    events = [
        {"name": "cudaMemcpyAsync HtoD", "cat": "cuda_runtime", "ph": "X",
         "ts": 0, "dur": 100},
        {"name": "dequant_nf4", "cat": "kernel", "ph": "X", "ts": 10, "dur": 10,
         "args": {"device": 0}},
        {"name": "Memcpy HtoD", "cat": "gpu_memcpy", "ph": "X", "ts": 15, "dur": 10,
         "args": {"device": 0}},
    ]
    path = tmp_path / "trace.json.gz"
    with gzip.open(path, "wt", encoding="utf-8") as target:
        json.dump({"traceEvents": events}, target)
    result = TIMELINE.analyze_trace(path)
    assert result["status"] == "parsed"
    assert result["gpu_complete_events"] == 2
    assert result["devices"]["0"]["union_us_by_kind"]["h2d"] == 10
    assert result["devices"]["0"]["busy_union_us"] == 15
    assert result["devices"]["0"]["event_span_us"] == 15


def test_actual_trace_cpu_only_cuda_api_names_cannot_substitute_gpu_activity(tmp_path):
    path = tmp_path / "trace.json.gz"
    with gzip.open(path, "wt", encoding="utf-8") as target:
        json.dump({"traceEvents": [{"name": "cudaMemcpyAsync HtoD", "cat": "cuda_runtime",
                                    "ph": "X", "ts": 0, "dur": 100}]}, target)
    result = TIMELINE.analyze_trace(path)
    assert result["status"] == "parsed"
    assert result["gpu_complete_events"] == 0
    assert not result["devices"]


def parser_fixture(tmp_path):
    path = tmp_path / "profile_timeline.py"
    path.write_text("VALUE = 7\n", encoding="utf-8")
    manifest = {"files": {path.name: {"bytes": path.stat().st_size,
                                    "sha256": PROBE.digest(path)}}}
    PROBE.save(tmp_path / "launch-manifest.json", manifest)
    return path


def test_parser_binds_actual_frozen_file_ignoring_shadow_module(tmp_path, monkeypatch):
    path = parser_fixture(tmp_path)
    monkeypatch.setitem(sys.modules, "profile_timeline", SimpleNamespace(VALUE=999))
    module, binding = PROBE.load_timeline_parser(tmp_path)
    assert module.VALUE == 7
    assert Path(module.__file__) == path
    assert binding["sha256"] == PROBE.digest(path)
    assert binding["launch_manifest_sha256"] == PROBE.digest(tmp_path / "launch-manifest.json")


@pytest.mark.parametrize("mutation", ["same_size_sha", "size", "missing_manifest"])
def test_parser_reject_changed_bytes_before_import(tmp_path, mutation):
    path = parser_fixture(tmp_path)
    if mutation == "same_size_sha":
        path.write_text("VALUE = 8\n", encoding="utf-8")
    elif mutation == "size":
        path.write_text("raise AssertionError('must not execute unbound bytes')\n",
                        encoding="utf-8")
    else:
        (tmp_path / "launch-manifest.json").unlink()
    with pytest.raises((ValueError, FileNotFoundError)):
        PROBE.load_timeline_parser(tmp_path)


def test_parser_reject_actual_path_escape_before_import(tmp_path, monkeypatch):
    root = tmp_path / "frozen"
    root.mkdir()
    expected = parser_fixture(root)
    foreign = tmp_path / "foreign.py"
    foreign.write_text("raise AssertionError('must not import foreign helper')\n", encoding="utf-8")
    original = PROBE.os.path.realpath

    def controlled(path):
        return str(foreign) if str(path) == str(expected) else original(path)

    monkeypatch.setattr(PROBE.os.path, "realpath", controlled)
    with pytest.raises(ValueError, match="escaped"):
        PROBE.load_timeline_parser(root)


def exploration(times=None, native=1):
    times = times or {"native": 10, "t1": 1, "t2": 9, "t4": 8, "t8": 12}
    return [{"policy": key, "actual_threads": native if key == "native" else PROBE.POLICIES[key],
             "step_seconds": [times[key]] * 6, "worker": {}}
            for key in PROBE.EXPLORATION_ORDER]


def test_duplicate_native_policy_cannot_win_even_with_best_exploratory_timing():
    result = PROBE.select_candidate(exploration())
    assert result["candidate"] == "t4"
    assert result["duplicate_controls"] == ["t1"]
    assert result["exploratory_only"] is True
    assert result["not_a_confirmatory_speed_estimate"] is True


def test_no_distinct_positive_candidate_has_no_confirmed_win():
    result = PROBE.select_candidate(exploration({key: 10 for key in PROBE.POLICIES}))
    assert result["status"] == "NO_CONFIRMED_WIN"
    assert result["candidate"] is None


@pytest.mark.parametrize("value", [math.nan, math.inf, -1, 0, True, "1"])
def test_selection_reject_nonfinite_or_nonphysical_timing(value):
    rows = exploration()
    rows[0]["step_seconds"][0] = value
    with pytest.raises((ValueError, TypeError)):
        PROBE.select_candidate(rows)


def test_selection_reject_changed_order_and_policy_count():
    rows = exploration()
    with pytest.raises(ValueError):
        PROBE.select_candidate(list(reversed(rows)))
    rows[0]["actual_threads"] = 2
    with pytest.raises(ValueError, match="relabelled"):
        PROBE.select_candidate(rows)


def blocks(candidate="t2", ratio=.9):
    rows = []
    pair = ("native", candidate)
    for number, order in enumerate((pair, tuple(reversed(pair))) * 2):
        for position, policy in enumerate(order):
            count = 1 if policy == "native" else PROBE.POLICIES[policy]
            control = PROBE.apply_threads(FakeTorch(), None if policy == "native" else count)
            raw = {"pid": 100 + 2 * number + position, "thread_control": control}
            for stage, updates in (("warmup", 2), ("timing", 6)):
                raw[stage] = {"complete": True, "updates_complete": updates,
                              "finite_state_checks_per_update": True,
                              "update_seconds": [10 if policy == "native" else 10 * ratio]
                              * updates, "losses": [2.] * updates}
            rows.append({"round": number, "position": position, "policy": policy,
                         "result": raw, "envelope": {}, "directory": f"{number}/{policy}",
                         "fresh_process_wall_seconds": 90})
    return rows


def test_confirmatory_estimate_uses_only_new_balanced_cohort():
    result = PROBE.confirm_summary(blocks(), "native", "t2", COMMON)
    assert result["step_time_reduction_percent"] == pytest.approx(10)
    assert result["throughput_increase_percent"] == pytest.approx(100 / 9)
    assert result["paired_bootstrap_95_percent"] == pytest.approx([10, 10])
    assert result["passes_practical_2_percent_gate"] is True
    assert result["independent_of_exploratory_selection_samples"] is True


@pytest.mark.parametrize("mutation", ["order", "pid", "loss", "warmup", "timing", "same_count"])
def test_confirmation_reject_unbalanced_reused_incomplete_or_inaccurate_evidence(mutation):
    rows = blocks()
    if mutation == "order":
        rows[0]["position"] = 1
    elif mutation == "pid":
        rows[1]["result"]["pid"] = rows[0]["result"]["pid"]
    elif mutation == "loss":
        rows[1]["result"]["timing"]["losses"][0] = 2.001
    elif mutation in ("warmup", "timing"):
        rows[1]["result"][mutation]["complete"] = False
    else:
        rows[1]["result"]["thread_control"]["after"]["intraop"] = 1
    with pytest.raises(ValueError):
        PROBE.confirm_summary(rows, "native", "t2", COMMON)


@pytest.mark.parametrize("changed", [("RTOL", .1), ("ATOL", 1e-4)])
def test_original_confirmation_tolerances_cannot_change(changed):
    common = copy.copy(COMMON)
    setattr(common, *changed)
    with pytest.raises(ValueError):
        PROBE.confirm_summary(blocks(), "native", "t2", common)


@pytest.mark.parametrize("mutation", ["candidate_count", "native_drift", "negative_pid",
                                    "boolean_pid", "boolean_time"])
def test_confirmation_reject_identity_drift_and_boolean_numeric_values(mutation):
    rows = blocks()
    if mutation == "candidate_count":
        for row in rows:
            if row["policy"] == "t2":
                row["result"]["thread_control"]["after"]["intraop"] = 8
    elif mutation == "native_drift":
        rows[2]["result"]["thread_control"]["before"]["intraop"] = 4
        rows[2]["result"]["thread_control"]["after"]["intraop"] = 4
    elif mutation == "negative_pid":
        rows[0]["result"]["pid"] = -1
    elif mutation == "boolean_pid":
        rows[0]["result"]["pid"] = True
    else:
        rows[1]["result"]["timing"]["update_seconds"][0] = True
    with pytest.raises(ValueError):
        PROBE.confirm_summary(rows, "native", "t2", COMMON)


def structural_study(tmp_path, monkeypatch):
    """Use synthetic already-qualified workers to isolate outer/raw identity checks."""
    harness = ModuleType("benchmarks.harness")
    harness.expert_cache_dispatch_qualification = SimpleNamespace(
        validate_dispatch_evidence=lambda *_args: None,
        validate_native_routes=lambda *_args: None,
        expected_routes=lambda *_args: {str(index): True for index in range(1, 48)},
        cache_delta=lambda *_args, **_kwargs: {"logical_fetches": 4})
    harness.two_read_cache_worker = SimpleNamespace(_enforce_stage_limits=lambda *_args: None)
    package = ModuleType("benchmarks")
    package.harness = harness
    monkeypatch.setitem(sys.modules, "benchmarks", package)
    monkeypatch.setitem(sys.modules, "benchmarks.harness", harness)
    monkeypatch.setattr(PROBE, "validate_resource_boundary", lambda *_args: None)
    spec = {"git_head": PROBE.COMMIT, "dtype": "bfloat16", "quant": "nf4",
            "accuracy_updates": 2, "accumulation": 2, "warmup_updates": 2,
            "timed_updates": 6, "seq_len": 512, "batch_size": 1,
            "host_cache_bytes": 8 * 2**30, "device_cache_bytes": 2 * 2**30,
            "host_cache_policy": "static"}
    protocol = {"execution_plan": copy.deepcopy(PROBE.CONTRACT)}
    report = {"status": "completed", "accuracy_passed": True,
              "execution_plan": copy.deepcopy(PROBE.CONTRACT),
              "identity": {"source_commit": PROBE.COMMIT},
              "probe_sha256": PROBE.digest(ROOT / "cpu_overlap_probe.py"),
              "spec_sha256": "a" * 64, "protocol_sha256": "b" * 64,
              "accuracy": {}, "exploration": [], "confirmation": []}
    next_pid = 200

    def worker(policy, phase, directory):
        nonlocal next_pid
        next_pid += 1
        child = tmp_path / directory
        child.mkdir(parents=True)
        raw = {"pid": next_pid, "spec_sha256": report["spec_sha256"],
               "status": "passed", "arm": "two_read_cache",
               "environment": {"deterministic_algorithms": True, "allow_tf32": False},
               "setup": {}, "phase": phase}
        if phase == "profile":
            summary, window = profile_fixture()
            PROBE.save(child / "key-averages.json", summary)
            PROBE.save(child / "timeline.json", {"status": "parsed"})
            (child / "trace.json.gz").write_bytes(b"synthetic qualified trace")
            raw.update(window=window, timeline_sha256=PROBE.digest(child / "timeline.json"),
                       trace={"within_bound": True,
                              "sha256": PROBE.digest(child / "trace.json.gz")},
                       warmup={}, context={}, profile_update={}, lifecycle={})
            for stage in ("warmup", "context", "profile_update"):
                raw[stage].update({point: {"expert_grouped_routes": {
                    str(index): True for index in range(1, 48)}}
                    for point in ("runtime_before", "runtime_after")})
        elif phase == "accuracy":
            (child / "capture.pt").write_bytes(b"synthetic already-qualified capture")
            raw["accuracy"] = {"capture_sha256": PROBE.digest(child / "capture.pt")}
        else:
            raw.update(copy.deepcopy(blocks()[0]["result"]))
            raw["pid"] = next_pid
            raw.pop("thread_control")
        control = PROBE.apply_threads(FakeTorch(), PROBE.POLICIES[policy])
        proof = {"status": "passed", "source": copy.deepcopy(report["identity"]),
                 "probe_sha256": report["probe_sha256"],
                 "protocol_sha256": report["protocol_sha256"],
                 "spec_sha256": report["spec_sha256"], "phase": phase,
                 "policy": policy, "pid": next_pid, "thread_control": control,
                 "threads_after_worker": control["after"], "dispatch": {}}
        raw_name = "profile-result.json" if phase == "profile" else "result.json"
        PROBE.save(child / raw_name, raw)
        proof["raw_sha256"] = PROBE.digest(child / raw_name)
        PROBE.save(child / "cpu-envelope.json", proof)
        return {"policy": policy, "phase": phase, "directory": directory,
                "result": dict(raw, thread_control=control), "envelope": proof,
                "fresh_process_wall_seconds": 1}

    for policy in PROBE.POLICIES:
        report["accuracy"][policy] = {
            "worker": worker(policy, "accuracy", f"accuracy/{policy}"),
            "controls": {"passed": True}, "versus_native": {"passed": True}}
    report["profile"] = worker("native", "profile", "profile/native")
    for row in exploration({key: 10 for key in PROBE.POLICIES}):
        row["worker"] = worker(row["policy"], "timing", "exploration/" + row["policy"])
        report["exploration"].append(row)
    report["selection"] = PROBE.select_candidate(report["exploration"])
    PROBE.save(tmp_path / "run.json", report)
    return spec, protocol, report


def test_structural_raw_fixture_is_valid_when_outer_metadata_matches(tmp_path, monkeypatch):
    spec, protocol, _report = structural_study(tmp_path, monkeypatch)
    assert PROBE.validate_result(tmp_path, spec, protocol)["status"] == (
        "passed_structural_probe_validation")


@pytest.mark.parametrize("mutation", ["accuracy_role", "exploration_role", "exploration_time",
                                    "profile_role"])
def test_structural_validator_reject_outer_metadata_drift_from_retained_raw(
        tmp_path, monkeypatch, mutation):
    spec, protocol, report = structural_study(tmp_path, monkeypatch)
    if mutation == "accuracy_role":
        left, right = report["accuracy"]["t2"], report["accuracy"]["t4"]
        left["worker"], right["worker"] = right["worker"], left["worker"]
    elif mutation == "exploration_role":
        rows = report["exploration"]
        rows[0]["worker"], rows[2]["worker"] = rows[2]["worker"], rows[0]["worker"]
    elif mutation == "exploration_time":
        report["exploration"][0]["step_seconds"] = [11] * 6
    else:
        native = next(row for row in report["exploration"] if row["policy"] == "native")
        report["profile"], native["worker"] = native["worker"], report["profile"]
    report["selection"] = PROBE.select_candidate(report["exploration"])
    PROBE.save(tmp_path / "run.json", report)
    with pytest.raises(ValueError):
        PROBE.validate_result(tmp_path, spec, protocol)


def native_boundary_fixture():
    limit = 30 * 2**30
    spec = {"hardware": {"physical_vram_bytes": 8 * 2**30},
            "host_boundary": {"effective_limit_bytes": limit, "swap_disabled": True}}
    point = {"process_swap_bytes": 0,
             "host_memory": {"MemTotal": 32 * 2**30, "SwapTotal": 8 * 2**30},
             "cgroup": {"constraints": [{"memory.max": limit, "memory.swap.max": 0,
                                          "memory.swap.current": 0}]}}
    resource = {"sampled_peak_cgroup_swap_bytes": 0, "sampled_peak_process_swap_bytes": 0,
                "sampled_peak_rss_bytes": 12 * 2**30,
                "before": copy.deepcopy(point), "after": copy.deepcopy(point)}
    raw = {"environment": {"gpu_total_bytes": 8 * 2**30},
           "resources_before": copy.deepcopy(point), "resources_after": copy.deepcopy(point),
           "setup": {"resources": copy.deepcopy(resource)},
           "lifecycle": {"resources": copy.deepcopy(resource)}}
    return raw, spec


def test_native_boundary_accepts_actual_8gb_and_native_30gib_noswap_scope():
    PROBE.validate_resource_boundary(*native_boundary_fixture())


@pytest.mark.parametrize("mutation", [
    "gpu4", "gpu16", "native_ram_too_high", "swap_not_disabled", "process_swap",
    "cgroup_swap", "swap_limit_unbounded", "sampled_process_swap", "sampled_cgroup_swap",
    "changed_limit", "parent_limit_lower", "physical_ram_lower",
])
def test_native_boundary_reject_scope_drift_and_swap_in_any_phase(mutation):
    raw, spec = native_boundary_fixture()
    if mutation in ("gpu4", "gpu16"):
        size = (4 if mutation == "gpu4" else 16) * 2**30
        raw["environment"]["gpu_total_bytes"] = size
        spec["hardware"]["physical_vram_bytes"] = size
    elif mutation == "native_ram_too_high":
        spec["host_boundary"]["effective_limit_bytes"] = 40 * 2**30
    elif mutation == "swap_not_disabled":
        spec["host_boundary"]["swap_disabled"] = False
    elif mutation == "process_swap":
        raw["resources_after"]["process_swap_bytes"] = 4096
    elif mutation == "cgroup_swap":
        raw["lifecycle"]["resources"]["after"]["cgroup"]["constraints"][0][
            "memory.swap.current"] = 51142656
    elif mutation == "swap_limit_unbounded":
        raw["resources_after"]["cgroup"]["constraints"][0]["memory.swap.max"] = "max"
    elif mutation == "sampled_process_swap":
        raw["setup"]["resources"]["sampled_peak_process_swap_bytes"] = 4096
    elif mutation == "sampled_cgroup_swap":
        raw["lifecycle"]["resources"]["sampled_peak_cgroup_swap_bytes"] = 51175424
    elif mutation == "changed_limit":
        raw["resources_after"]["cgroup"]["constraints"][0]["memory.max"] = 31 * 2**30
    elif mutation == "parent_limit_lower":
        raw["resources_after"]["cgroup"]["constraints"].append({
            "memory.max": 2**30, "memory.swap.current": 0, "memory.swap.max": 0})
    else:
        raw["resources_after"]["host_memory"]["MemTotal"] = 2**30
    with pytest.raises(ValueError):
        PROBE.validate_resource_boundary(raw, spec)
