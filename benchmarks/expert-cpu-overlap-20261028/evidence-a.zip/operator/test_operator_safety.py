"""New operator safety controls; no live cloud, SSH, model or GPU work."""

import copy
import hashlib
import json
import math
from pathlib import Path
from types import SimpleNamespace

import cloud
import controller
import launch
import prepare_freeze
import pytest
import remote_run
import transport
from launch_safety import validate_protocol

ROOT = Path(__file__).parent
PRIOR = ROOT.with_name("kanana-30b-final-gpu-20261026-f15")


@pytest.fixture(autouse=True)
def no_live_resources(monkeypatch):
    monkeypatch.setattr(cloud, "api", lambda *_a, **_kw: pytest.fail("Live API forbidden"))
    monkeypatch.setattr(cloud, "ssh", lambda *_a, **_kw: pytest.fail("Live SSH forbidden"))


def test_frozen_production_input_and_transport_sources_are_unchanged():
    for name in ("source.tar.gz", "source-manifest.json", "constraints.txt", "setup.sh",
                 "preflight_remote.py", "checkpoint_integrity.py", "api_rate_limit.py",
                 "api_transport.py", "remote_guard.py", "lossless_results.py"):
        assert (ROOT / name).read_bytes() == (PRIOR / name).read_bytes(), name
    assert hashlib.sha256((ROOT / "source.tar.gz").read_bytes()).hexdigest() == (
        "0062717d0c9512649a9971c41a3918c9323f41516cdef47e21220f32e485bd71")


def test_science_input_resource_and_retention_boundaries_unchanged():
    current = json.loads((ROOT / "protocol.json").read_text())
    previous = json.loads((PRIOR / "protocol.json").read_text())
    for field in ("source_commit", "model", "cuda_test_selectors", "cuda_expected_case_names",
                  "native_boundary", "retention", "checkpoint_input_integrity",
                  "storage_capacity_plan", "transport", "admission_fallback_allowed"):
        assert current[field] == previous[field], field
    assert current["stage_id"] != previous["stage_id"]
    assert current["financial"] == {"maximum_stage_usd": 6., "prior_usd": 0,
        "maximum_seconds": 10800, "root_provider_gb": 32, "volume_provider_gb": 112,
        "download_allowance_decimal_gb": 90, "upload_allowance_decimal_gb": 2}


def test_3hour_quote_accounts_for_both_filesystems_and_all_reserves():
    offer = {"machine_id": 122165, "dph_base": .14666666666666667,
             "storage_cost": .5333333333333332,
             "dph_total": .14666666666666667 + 32 * .5333333333333332 / 720,
             "inet_down_cost": .0026041666666666665, "inet_up_cost": .00390625}
    volume = {"id": 56801565, "machine_id": 122165, "disk_space": 146,
              "storage_cost": .1333333333333333}
    result = cloud.quote(offer, volume_offer=volume)
    hourly = offer["dph_total"] + 112 * volume["storage_cost"] / 720
    expected = hourly * (10800 + 180) / 3600 + 90 * offer["inet_down_cost"]
    expected += 2 * offer["inet_up_cost"] + .75 + .25
    assert math.isclose(result["total_stage_admission_usd"], expected, abs_tol=1e-12)
    assert result["allocated_disk_gb"] == 32 and result["local_volume_gb"] == 112
    assert result["maximum_seconds"] == 10800 and result["maximum_stage_usd"] == 6.
    assert result["prior_stage_usd"] == 0


def test_previous_cost_deducted_once_and_no_sibling_budget_reserved():
    row = json.loads((ROOT / "prior-budget-context.json").read_text())
    old = json.loads((PRIOR / "prior-budget-context.json").read_text())
    assert row["completed_f15_cost_usd"] == .6010583969610324
    assert math.isclose(old["aggregate_remaining_before_f15_usd"]
                        - row["completed_f15_cost_usd"] + row["cpu_overlap_additional_authorized_usd"],
                        row["aggregate_remaining_before_cpu_overlap_usd"], abs_tol=1e-12)
    assert row["new_stage_cap_usd"] == 6. < row["aggregate_remaining_before_cpu_overlap_usd"]
    assert row["active_sibling_reservation_usd"] == 0.


def test_mismatched_lease_duration_refuses_before_allocation(tmp_path, monkeypatch):
    (tmp_path / "protocol.json").write_text(json.dumps({
        "financial": {"maximum_seconds": 10800}}))
    monkeypatch.setattr(launch, "ROOT", tmp_path)
    monkeypatch.setattr(cloud, "ROOT", tmp_path)
    monkeypatch.setattr(controller, "freeze_check", lambda: None)
    monkeypatch.setattr(cloud, "allocate", lambda *_: pytest.fail("Allocation reached"))
    with pytest.raises(ValueError, match="3-hour"):
        launch.main(["--offer-id", "1", "--volume-ask-id", "2", "--seconds", "14400"])


def test_explicit_new_root_greenlight_required_before_create(tmp_path, monkeypatch):
    monkeypatch.setattr(cloud, "ROOT", tmp_path)
    monkeypatch.setattr(cloud, "rows", lambda: [])
    monkeypatch.setattr(cloud, "volume_rows", lambda: [])
    monkeypatch.setattr(cloud, "prior_owned_ids", lambda: (set(), set()))
    with pytest.raises(RuntimeError, match="Missing root lease greenlight"):
        cloud.allocate(SimpleNamespace(seconds=10800, offer_id=1, volume_ask_id=2))


@pytest.mark.parametrize("seconds", [0, 3600, 14400, 43200])
def test_direct_allocate_cannot_bypass_frozen_three_hour_deadline(seconds, monkeypatch):
    monkeypatch.setattr(cloud, "rows", lambda: pytest.fail("Inventory reached before refusal"))
    with pytest.raises(ValueError, match="exact frozen 3-hour"):
        cloud.allocate(SimpleNamespace(seconds=seconds, offer_id=1, volume_ask_id=2))


def test_new_runner_deployment_allowlist_excludes_old_f15_claim_and_credentials():
    assert "cpu_overlap_probe.py" in controller.REQUIRED
    assert set(controller.REQUIRED) <= transport.UPLOAD_ALLOWLIST
    assert "final_comparison.py" not in controller.REQUIRED
    for name in ("cloud.py", "controller.py", "ssh-key", "vast_api_key"):
        assert name not in transport.UPLOAD_ALLOWLIST
    text = (ROOT / "remote_run.py").read_text()
    assert "'cpu_overlap_probe.py'" in text
    assert "final_comparison" not in text and "validate_dispatch_outputs" not in text


@pytest.mark.parametrize("field,value", [("disk_space", 143), ("gpu_ram", 16000),
                                        ("num_gpus", 2), ("gpu_frac", .5)])
def test_native_physical_gpu_and_combined_disk_admission_unchanged(field, value):
    offer = {"num_gpus": 1, "gpu_frac": 1., "gpu_ram": 8188,
             "cpu_ram": 31741, "compute_cap": 890, "disk_space": 146}
    offer[field] = value
    with pytest.raises(ValueError):
        cloud.validate_full_host(offer)


@pytest.mark.parametrize("section,path,value", [
    ("execution_plan", ("accuracy_updates",), 1),
    ("execution_plan", ("accumulation",), 1),
    ("execution_plan", ("policies", "t8"), 16),
    ("execution_plan", ("rtol",), .1),
    ("execution_plan", ("atol",), 1e-4),
    ("execution_plan", ("confirmation_pairs",), 1),
    ("execution_plan", ("profile", "fetches"), 128),
    ("execution_plan", ("profile", "skip_fetches"), 0),
    ("execution_plan", ("profile", "skip_fetches"), 128),
    ("execution_plan", ("profile", "maximum_encoded_trace_bytes"), 2**30),
    ("execution_plan", ("all_features", "grouped_expert_routes"), False),
    ("performance", ("host_cache_bytes",), 4 * 2**30),
    ("performance", ("sequence_length",), 1024),
    ("financial", ("maximum_seconds",), 14400),
    ("native_boundary", ("swap_must_be_disabled",), False),
])
def test_preregistered_cpu_and_accuracy_gates_cannot_be_silently_changed(section, path, value):
    protocol = json.loads((ROOT / "protocol.json").read_text())
    validate_protocol(protocol, source_commit=protocol["source_commit"], stage_id=cloud.STAGE)
    candidate = copy.deepcopy(protocol)
    target = candidate[section]
    for field in path[:-1]:
        target = target[field]
    target[path[-1]] = value
    with pytest.raises(ValueError):
        validate_protocol(candidate, source_commit=candidate["source_commit"], stage_id=cloud.STAGE)


def fake_probe(tmp_path, monkeypatch, body):
    monkeypatch.setattr(remote_run, "ROOT", tmp_path)
    monkeypatch.setattr(remote_run, "OUT", tmp_path)
    path = tmp_path / "cpu_overlap_probe.py"
    path.write_text(body)
    (tmp_path / "launch-manifest.json").write_text(json.dumps({"files": {
        path.name: {"sha256": hashlib.sha256(path.read_bytes()).hexdigest()}}}))
    spec = tmp_path / "spec.json"
    spec.write_text('{"test_spec": true}')
    return path, spec


def test_bound_new_validator_receives_loaded_spec_and_requires_its_passed_status(
        tmp_path, monkeypatch):
    body = ("def validate_result(directory, spec, protocol):\n"
            "    assert isinstance(spec, dict) and spec['test_spec'] is True\n"
            "    return {'status': 'passed_structural_probe_validation'}\n")
    _path, spec = fake_probe(tmp_path, monkeypatch, body)
    assert remote_run.validate_cpu_overlap_outputs(tmp_path, spec, {})["status"] == (
        "passed_structural_probe_validation")
    assert (tmp_path / "cpu-overlap-validation.json").is_file()


@pytest.mark.parametrize("returned", ["None", "{}", "{'status': 'failed'}"])
def test_new_validator_cannot_promote_empty_or_failed_proof(tmp_path, monkeypatch, returned):
    _path, spec = fake_probe(tmp_path, monkeypatch,
                            "def validate_result(*args):\n    return " + returned + "\n")
    with pytest.raises(RuntimeError, match="required passed proof status"):
        remote_run.validate_cpu_overlap_outputs(tmp_path, spec, {})
    assert not (tmp_path / "cpu-overlap-validation.json").exists()


def test_new_validator_hash_drift_is_refused_before_module_execution(tmp_path, monkeypatch):
    path, spec = fake_probe(tmp_path, monkeypatch, "raise AssertionError('Executed wrong file')\n")
    path.write_text(path.read_text() + "# unapproved source drift\n")
    with pytest.raises(RuntimeError, match="source changed before validation"):
        remote_run.validate_cpu_overlap_outputs(tmp_path, spec, {})


def independent_review_fixture(tmp_path, monkeypatch):
    monkeypatch.setattr(prepare_freeze, "ROOT", tmp_path)
    names = ("cpu_overlap_probe.py", "profile_timeline.py", "protocol-contract.json",
             "test_cpu_overlap_independent.py", "check_boundary_compatibility.py")
    for name in names:
        (tmp_path / name).write_text("# independently reviewed fixture\n")
    xml = "<testsuite>" + "<testcase/>" * 55 + "</testsuite>"
    (tmp_path / "cpu-overlap-independent.xml").write_text(xml)
    actual = {"runner_sha256": hashlib.sha256((tmp_path / names[0]).read_bytes()).hexdigest(),
              "f14_actual_swap_failure_rejected": True,
              "f15_actual_workers_passed": [{}] * 11}
    (tmp_path / "cpu-overlap-actual-boundary-compatibility.json").write_text(json.dumps(actual))
    paths = [tmp_path / name for name in (*names, "cpu-overlap-independent.xml",
                                         "cpu-overlap-actual-boundary-compatibility.json")]
    review = {"status": "passed_independent_offline_runner_design_review",
              "source_commit": "43cf0b34afe0d8850d76bf86d60663ab5c85cdb2",
              "independent_cpu_controls": {"passed": 55, "failed": 0, "skipped": 0},
              "private_files": {path.name: {"bytes": path.stat().st_size,
                  "sha256": hashlib.sha256(path.read_bytes()).hexdigest()} for path in paths}}
    (tmp_path / "cpu-overlap-independent-review.json").write_text(json.dumps(review))
    return review


def test_freezer_accepts_only_matching_completed_independent_review(tmp_path, monkeypatch):
    review = independent_review_fixture(tmp_path, monkeypatch)
    assert prepare_freeze.verify_independent_review() == review


@pytest.mark.parametrize("changed", ["cpu_overlap_probe.py", "profile_timeline.py"])
def test_freezer_refuses_old_review_after_source_format_or_semantic_edit(
        tmp_path, monkeypatch, changed):
    independent_review_fixture(tmp_path, monkeypatch)
    (tmp_path / changed).write_text("# later unreviewed bytes\n")
    with pytest.raises(ValueError, match="review binding is stale"):
        prepare_freeze.verify_independent_review()
