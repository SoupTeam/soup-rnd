"""Atomic local operation evidence; never receives credentials or modifies cloud state."""

from __future__ import annotations

import json
import os
import threading
import time
import traceback
import uuid
from contextlib import contextmanager
from pathlib import Path

ROOT = Path(__file__).parent
_RECORD_LOCK = threading.Lock()


def _save(path, value):
    temporary = path.with_name(path.name + '.' + uuid.uuid4().hex + '.incoming')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    os.replace(temporary, path)


def record(operation, event, identifier, **context):
    # Both route probes run concurrently. Windows cannot replace the same target
    # from two writers reliably, even when their temporary filenames are unique.
    with _RECORD_LOCK:
        folder = ROOT / 'operation-events'
        folder.mkdir(exist_ok=True)
        value = {'operation': operation, 'event': event, 'id': identifier,
                 'unix': time.time(), **context}
        _save(folder / (identifier + '-' + event + '.json'), value)
        _save(ROOT / 'operation-latest.json', value)
    return value


@contextmanager
def step(operation, **context):
    identifier = str(time.time_ns()) + '-' + uuid.uuid4().hex[:8]
    record(operation, 'started', identifier, **context)
    try:
        yield
    except BaseException as exc:
        record(operation, 'failed', identifier, error_type=type(exc).__name__,
               error=str(exc), traceback=traceback.format_exc(), **context)
        raise
    else:
        record(operation, 'completed', identifier, **context)
