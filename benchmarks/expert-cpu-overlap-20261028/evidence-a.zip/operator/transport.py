"""Bounded native OpenSSH bytes transport with exact atomic upload acknowledgements."""

from __future__ import annotations

import hashlib
import json
import os
import re
import shlex
import subprocess
import time
import uuid
from pathlib import Path

import cloud
from diagnostics import step

ROOT = Path(__file__).parent
UPLOAD_ALLOWLIST = frozenset(('source.tar.gz', 'source-manifest.json', 'constraints.txt',
    'preflight_remote.py', 'setup.sh', 'remote_run.py', 'remote_guard.py',
    'lossless_results.py', 'protocol.json', 'launch-manifest.json', 'upload-probe.bin',
    'cpu_overlap_probe.py', 'profile_timeline.py', 'protocol-contract.json',
    'test_cpu_overlap_independent.py', 'cpu-overlap-independent.xml',
    'cpu-overlap-independent-review.json',
    'test_cpu_overlap_runtime.py', 'cpu-overlap-controls.xml', 'checkpoint_integrity.py', 'storage-capacity-plan.json'))
MAX_REPLY_BYTES = 8 * 2**20


class NativeSSHFailure(ConnectionError):
    """Transient native command/transport error, eligible for bounded retry."""


class HostKeyRefused(RuntimeError):
    """Permanent refusal; never replace known-host policy or accept a changed key."""


class UploadIntegrityError(ValueError):
    """Remote byte/identity/name refusal; never retry as a network failure."""


REMOTE_UPLOAD_PROGRAM = r'''
import hashlib,json,os,re,sys
from pathlib import Path
name=META['name']; temporary=None
try:
 if name not in ALLOWED or not re.fullmatch(r'[a-zA-Z0-9_.-]+',name):raise ValueError('upload name refused')
 if str(os.environ.get('CONTAINER_ID',''))!=str(META['instance_id']):raise ValueError('actual container identity mismatch')
 if type(META['bytes']) is not int or META['bytes']<0 or not re.fullmatch('[0-9a-f]{64}',META['sha256']):raise ValueError('upload declaration refused')
 root=Path('/root/liger');root.mkdir(parents=True,exist_ok=True)
 target=root/name
 if os.path.commonpath((os.path.realpath(root),os.path.realpath(target)))!=os.path.realpath(root):raise ValueError('upload target escaped root')
 if target.is_symlink() or (target.exists() and not target.is_file()):raise ValueError('upload target is not an ordinary file')
 temporary=root/('.'+name+'.upload-'+META['nonce'])
 count=0; value=hashlib.sha256()
 with temporary.open('xb') as output:
  while True:
   block=sys.stdin.buffer.read(min(8*2**20,META['bytes']-count+1))
   if not block:break
   count+=len(block)
   if count>META['bytes']:raise ValueError('stdin longer than declared byte count')
   output.write(block);value.update(block)
  output.flush();os.fsync(output.fileno())
 if count!=META['bytes'] or value.hexdigest()!=META['sha256']:raise ValueError('stdin byte count or SHA mismatch')
 if target.is_symlink():raise ValueError('upload target changed to symlink')
 os.replace(temporary,target);temporary=None
 print(json.dumps({'native_binary_upload':True,'name':name,'bytes':count,'sha256':value.hexdigest(),'container_id':str(os.environ['CONTAINER_ID']),'file_fsynced':True,'atomic_rename':True}))
except ValueError as exc:
 print(json.dumps({'upload_rejected':str(exc),'name':name}),file=sys.stderr)
 raise SystemExit(65)
finally:
 if temporary is not None:temporary.unlink(missing_ok=True)
'''


def digest(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for chunk in iter(lambda: handle.read(8 * 2**20), b''):
            value.update(chunk)
    return value.hexdigest()


def _accepted(result):
    stderr = result.stderr.decode(errors='replace') if result.stderr else ''
    if result.returncode:
        if any(text in stderr.lower() for text in ('host key verification failed',
            'remote host identification has changed', 'offending key')):
            raise HostKeyRefused('Native SSH refused its known-host identity')
        if result.returncode == 65:
            raise UploadIntegrityError('Remote upload validation refused: ' + stderr[-400:])
        raise NativeSSHFailure(f'Native SSH command exit {result.returncode}: ' + stderr[-400:])
    if len(result.stdout) > MAX_REPLY_BYTES:
        raise ValueError('Native SSH reply exceeds its bounded command/range size')
    return result.stdout


def stream(command, target, timeout=60):
    if not 0 < timeout <= 14400:
        raise ValueError('Native SSH timeout must be positive and bounded')
    with step('native-ssh-command', timeout=timeout,
              command_sha256=hashlib.sha256(command.encode()).hexdigest()):
        output = _accepted(cloud.ssh(command, timeout=timeout))
        target.write(output)
    return len(output)


def ssh_retry(command, timeout=60, attempts=3):
    import io

    if type(attempts) is not int or not 1 <= attempts <= 3:
        raise ValueError('Native SSH attempts must be within 1..3')
    for attempt in range(attempts):
        try:
            with step('native-ssh-attempt', attempt=attempt + 1, maximum_attempts=attempts,
                      timeout=timeout, command_sha256=hashlib.sha256(command.encode()).hexdigest()):
                sink = io.BytesIO()
                stream(command, sink, timeout)
                return subprocess.CompletedProcess(command, 0, sink.getvalue(), b'')
        except (OSError, EOFError, subprocess.TimeoutExpired):
            if attempt == attempts - 1:
                raise
        time.sleep(2)


def upload(name, timeout=120):
    if not 0 < timeout <= 300:
        raise ValueError('Native upload timeout must be within 0..300 seconds')
    if name not in UPLOAD_ALLOWLIST or not re.fullmatch(r'[a-zA-Z0-9_.-]+', name):
        raise ValueError('Upload is outside the frozen public-file allowlist')
    path = ROOT / name
    if path.is_symlink() or not path.is_file():
        raise ValueError('Upload source must be an ordinary file')
    base = os.path.realpath(ROOT)
    if os.path.commonpath((base, os.path.realpath(path))) != base:
        raise ValueError('Upload source escaped local root')
    policy = cloud.receipt()
    identity = cloud.resource_id(policy['instance_id'])
    expected = {'name': name, 'bytes': path.stat().st_size, 'sha256': digest(path),
                'instance_id': identity, 'nonce': uuid.uuid4().hex}
    program = 'ALLOWED=' + repr(tuple(sorted(UPLOAD_ALLOWLIST))) + '\nMETA=' + repr(expected) + '\n' + REMOTE_UPLOAD_PROGRAM
    with step('native-binary-upload', file=name, bytes=expected['bytes'],
              sha256=expected['sha256'], timeout=timeout, instance_id=identity):
        with path.open('rb') as source:
            result = cloud.ssh('python3 -c ' + shlex.quote(program), timeout=timeout, stdin=source)
        raw = _accepted(result)
        try:
            ack = json.loads(raw)
        except (ValueError, UnicodeError) as exc:
            raise UploadIntegrityError('Native upload did not return a complete JSON acknowledgement') from exc
        if (ack.get('name') != name or ack.get('bytes') != expected['bytes']
                or ack.get('sha256') != expected['sha256']
                or str(ack.get('container_id')) != str(identity)
                or any(ack.get(key) is not True for key in ('native_binary_upload','file_fsynced','atomic_rename'))
                or path.stat().st_size != expected['bytes'] or digest(path) != expected['sha256']):
            raise UploadIntegrityError('Native upload acknowledgement/source identity differs')
    return ack
