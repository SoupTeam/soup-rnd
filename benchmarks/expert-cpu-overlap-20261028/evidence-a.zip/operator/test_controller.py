"""Offline controls: no provider call or SSH operation can reach a real resource."""

from __future__ import annotations

import hashlib
import io
import json
import tarfile
import time
from pathlib import Path
from types import SimpleNamespace

import cloud
import controller
import diagnostics
import launch
import pytest


@pytest.fixture(autouse=True)
def isolated(tmp_path, monkeypatch):
    monkeypatch.setattr(controller, "ROOT", tmp_path)
    monkeypatch.setattr(diagnostics, "ROOT", tmp_path)
    monkeypatch.setattr(cloud, "ROOT", tmp_path)
    monkeypatch.setattr(cloud, "SSH_KEY", tmp_path / "ssh-key")
    monkeypatch.setattr(launch, "ROOT", tmp_path)
    (tmp_path / "protocol.json").write_text(json.dumps({"financial": {"maximum_seconds": 10800}}))
    monkeypatch.setattr(cloud, "api", lambda *_args, **_kw: pytest.fail("Unmocked provider API"))
    monkeypatch.setattr(controller.transport.cloud, "ssh", lambda *_a, **_k: pytest.fail("Unmocked native SSH"))
    yield


def digest(data):
    return hashlib.sha256(data).hexdigest()


def archive(path, entries):
    manifest = {}
    with tarfile.open(path, "w:gz") as handle:
        for name, data in entries:
            info = tarfile.TarInfo(name)
            info.size = len(data)
            handle.addfile(info, io.BytesIO(data))
            manifest[name] = {"bytes": len(data), "sha256": digest(data)}
    return manifest


def policy():
    return {"instance_id": 1, "volume_id": 2, "label": cloud.LABEL,
            "stage_id": cloud.STAGE,
            "maximum_usd": cloud.MAXIMUM_USD, "created_unix": time.time(),
            "maximum_seconds": 10800}


def test_safe_archive_verifies_every_file_and_extracts_exact_bytes(tmp_path):
    path = tmp_path / "artifact.tar.gz"
    files = archive(path, [("results/capture.pt", b"actual tensor payload"), ("setup.log", b"logs")])
    destination = tmp_path / "retained"
    destination.mkdir()
    proof = controller._validate_tar(path, files, destination)
    assert proof["verified_files"] == 2
    assert (destination / "results/capture.pt").read_bytes() == b"actual tensor payload"
    assert (destination / "setup.log").read_bytes() == b"logs"


def test_lossless_roundtrip_keeps_nested_bf16_pt_and_original_sha(tmp_path):
    import shutil

    import lossless_results
    import torch

    root = tmp_path / "capture-source"
    paths = [root / f"arm-{index}/capture.pt" for index in range(4)]
    for path in paths:
        path.parent.mkdir(parents=True)
    value = {"logits": torch.randn(128, 128, dtype=torch.bfloat16), "router": {
        "gradients": torch.randn(32, dtype=torch.bfloat16), "indices": torch.arange(32),
    }}
    torch.save(value, paths[0])
    for path in paths[1:]:
        shutil.copyfile(paths[0], path)
    names = [path.relative_to(root).as_posix() for path in paths]
    packed = tmp_path / "capture.lossless.tar"
    proof = lossless_results.pack(root, names, packed)
    files = {name: {"bytes": (root / name).stat().st_size, "sha256": cloud.digest(root / name)}
             for name in names}
    target = tmp_path / "decoded"
    decoded = controller._unpack_lossless(packed, target, files)
    assert decoded["verified_files"] == 4
    assert proof["archive_bytes"] < proof["original_bytes"]
    restored = torch.load(target / names[3], weights_only=True)
    assert torch.equal(restored["logits"], value["logits"])
    assert torch.equal(restored["router"]["gradients"], value["router"]["gradients"])
    assert all(cloud.digest(target / name) == files[name]["sha256"] for name in names)


def test_lossless_inner_outer_corruption_and_aliases_are_refused(tmp_path):
    import lossless_results

    root = tmp_path / "source"
    root.mkdir()
    (root / "capture.pt").write_bytes(b"complete opaque tensor bytes" * 100)
    packed = tmp_path / "capture.lossless.tar"
    lossless_results.pack(root, ["capture.pt"], packed)
    files = {"capture.pt": {"bytes": (root / "capture.pt").stat().st_size, "sha256": "0" * 64}}
    with pytest.raises(ValueError, match="inner/outer original hash"):
        controller._unpack_lossless(packed, tmp_path / "decoded", files)
    files["CAPTURE.pt"] = files["capture.pt"]
    with pytest.raises(ValueError, match="Windows aliases"):
        controller._unpack_lossless(packed, tmp_path / "decoded", files)


@pytest.mark.parametrize("name", [
    "../escape", "/absolute", "nested/../escape", "nested\\escape", "C:/escape",
    "nested/./escape", "nested//escape", "trailing.", "trailing ",
])
def test_archive_path_escape_and_windows_aliases_are_refused(tmp_path, name):
    path = tmp_path / "artifact.tar.gz"
    files = archive(path, [(name, b"unsafe")])
    with pytest.raises(ValueError):
        controller._validate_tar(path, files, tmp_path / "retained")
    assert not (tmp_path.parent / "escape").exists()


@pytest.mark.parametrize("kind", [tarfile.SYMTYPE, tarfile.LNKTYPE, tarfile.CHRTYPE])
def test_archive_links_and_devices_are_refused(tmp_path, kind):
    path = tmp_path / "artifact.tar.gz"
    with tarfile.open(path, "w:gz") as handle:
        info = tarfile.TarInfo("results/link")
        info.type = kind
        info.linkname = "../../outside"
        handle.addfile(info)
    with pytest.raises(ValueError):
        controller._validate_tar(path, {"results/link": {"bytes": 0, "sha256": digest(b"")}})


@pytest.mark.parametrize("corruption", ["hash", "size", "omitted", "unmanifested", "duplicate"])
def test_archive_partial_or_corrupt_evidence_never_qualifies(tmp_path, corruption):
    path = tmp_path / "artifact.tar.gz"
    entries = [("results/value", b"actual")]
    if corruption == "duplicate":
        entries.append(entries[0])
    files = archive(path, entries)
    if corruption == "hash":
        files["results/value"]["sha256"] = "0" * 64
    elif corruption == "size":
        files["results/value"]["bytes"] += 1
    elif corruption == "omitted":
        files["missing"] = {"bytes": 0, "sha256": digest(b"")}
    elif corruption == "unmanifested":
        files = {"other": {"bytes": 0, "sha256": digest(b"")}}
    with pytest.raises(ValueError):
        controller._validate_tar(path, files)


def _frozen_inputs(tmp_path):
    files = archive(tmp_path / "source.tar.gz", [("src/runtime.py", b"runtime source")])
    source = {"source_commit": "a" * 40, "archive_sha256": cloud.digest(tmp_path / "source.tar.gz"),
              "files": files}
    cloud.save("source-manifest.json", source)
    for name in (*controller.REQUIRED, "controller.py", "launch.py", "cloud.py", "transport.py",
                 "range_transport.py", "launch_safety.py", "diagnostics.py",
                 "api_rate_limit.py", "api_transport.py"):
        path = tmp_path / name
        if not path.exists():
            path.write_bytes(b"frozen public input")
    protocol = json.loads((Path(__file__).parent / "protocol.json").read_text())
    protocol["source_commit"] = "a" * 40
    cloud.save("protocol.json", protocol)
    rows = {
        path.name: {"bytes": path.stat().st_size, "sha256": cloud.digest(path)}
        for path in tmp_path.iterdir() if path.is_file()
    }
    cloud.save("launch-manifest.json", {"files": rows})


@pytest.mark.parametrize("changed", ["controller.py", "source.tar.gz", "setup.sh",
                                     "api_rate_limit.py", "api_transport.py"])
def test_frozen_execution_source_and_inputs_cannot_drift(tmp_path, changed):
    _frozen_inputs(tmp_path)
    assert controller.freeze_check()["files"]
    (tmp_path / changed).write_bytes(b"mutated after freezing")
    with pytest.raises(ValueError, match="Frozen launch input changed"):
        controller.freeze_check()


class _Context:
    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False


def test_binary_collection_uses_the_range_route_from_first_byte(tmp_path, monkeypatch):
    import range_transport

    target = tmp_path / "archive.bin"
    captured = {}

    def download(remote, destination, size, expected, **kwargs):
        captured.update(remote=remote, destination=destination, size=size, expected=expected, **kwargs)
        return {"bytes": size, "sha256": expected, "whole_archive_verified": True}

    monkeypatch.setattr(range_transport, "download", download)
    proof = controller._download_file("/fixed/archive", target, 4, digest(b"real"), policy())
    assert proof["whole_archive_verified"]
    assert captured["remote"] == "/fixed/archive" and captured["size"] == 4
    assert captured["refresh"] is controller.refresh_guard
    assert callable(captured["reader"]) and captured["remaining"]() > 180


def test_existing_unverified_artifact_is_not_overwritten(tmp_path):
    target = tmp_path / "archive.bin"
    target.write_bytes(b"wrong evidence")
    with pytest.raises(ValueError, match="Existing destination"):
        controller._download_file("/fixed/archive", target, 4, digest(b"real"), policy())
    assert target.read_bytes() == b"wrong evidence"


def test_collection_requires_bound_source_then_retains_exact_complete_files(tmp_path, monkeypatch):
    incoming = tmp_path / "remote.tar.gz"
    files = archive(incoming, [("results/run.json", b"complete raw result"), ("setup.log", b"logs")])
    payload = incoming.read_bytes()
    cloud.save("source-manifest.json", {"source_commit": "a" * 40})
    declared = {"archive_bytes": len(payload), "sha256": digest(payload), "files": files,
                "source_commit": "a" * 40, "stage_status": {"status": "completed"}}
    monkeypatch.setattr(controller, "_remote", lambda *_args, **_kw: json.dumps(declared).encode())

    def download(_remote, target, size, expected, _policy, **_kw):
        assert size == len(payload) and expected == digest(payload)
        target.write_bytes(payload)
        return {"bytes": size, "sha256": expected}

    monkeypatch.setattr(controller, "_download_file", download)
    proof = controller.collect_archive(policy())
    assert proof["verified_files"] == 2 and proof["all_manifested_raw_files_retained"]
    assert proof["expected_source_commit"] == proof["export_source_commit"] == "a" * 40
    assert (tmp_path / "retained/results/run.json").read_bytes() == b"complete raw result"


@pytest.mark.parametrize("commit", [None, "b" * 40])
def test_normal_export_cannot_omit_or_change_frozen_source_identity(tmp_path, monkeypatch, commit):
    cloud.save("source-manifest.json", {"source_commit": "a" * 40})
    declared = {"source_commit": commit, "stage_status": {"status": "completed"}}
    monkeypatch.setattr(controller, "_remote", lambda *_args, **_kw: json.dumps(declared).encode())
    monkeypatch.setattr(controller, "_download_file", lambda *_args, **_kw: pytest.fail("download reached"))
    with pytest.raises(ValueError, match="different frozen source"):
        controller.collect_archive(policy())


def test_recovery_reserve_is_measured_and_at_least_600_seconds(tmp_path, monkeypatch):
    expected = {"archive_bytes": 32 * 2**20, "archive_sha256": digest(b"fixture"),
                "format": "soup-lossless-results-v1", "original_file_count": 4,
                "original_bytes": 256 * 2**20, "files": {}}
    monkeypatch.setattr(controller, "_remote", lambda *_args, **_kw: json.dumps(expected).encode())
    monkeypatch.setattr(controller, "_download_file", lambda *_args, **_kw: {"verified": True})
    monkeypatch.setattr(controller, "_unpack_lossless", lambda *_args: {
        "verified_files": 4, "original_bytes": 256 * 2**20,
    })
    monkeypatch.setattr(controller.shutil, "disk_usage", lambda _: SimpleNamespace(free=100 * 2**30))
    clock = iter([10.0, 12.0, 12.0])
    monkeypatch.setattr(controller.time, "monotonic", lambda: next(clock))
    proof = controller.retention_preflight(policy(), {"retention_estimate_bytes": 4 * 2**30})
    assert proof["bytes_per_second"] == 16 * 2**20
    assert proof["recovery_reserve_seconds"] >= 600 and proof["verified"]


def test_retention_refuses_inadequate_local_disk_before_upload(tmp_path, monkeypatch):
    monkeypatch.setattr(controller.shutil, "disk_usage", lambda _: SimpleNamespace(free=2**30))
    monkeypatch.setattr(controller, "_remote", lambda *_args, **_kw: pytest.fail("SSH started"))
    with pytest.raises(RuntimeError, match="Insufficient local space"):
        controller.retention_preflight(policy(), {})


@pytest.mark.parametrize("failure", ["controller", "allocate"])
def test_launch_finally_destroys_only_receipted_pair_even_on_failure(tmp_path, monkeypatch, failure):
    events = []
    monkeypatch.setattr(launch.controller, "freeze_check", lambda: events.append("freeze"))

    def allocate(_args):
        events.append("allocate")
        cloud.save("vast-rental.json", policy())
        if failure == "allocate":
            raise RuntimeError("uncertain allocation result")

    def run():
        events.append("controller")
        raise RuntimeError("simulated controller failure")

    monkeypatch.setattr(launch.cloud, "allocate", allocate)
    monkeypatch.setattr(launch.controller, "main", run)
    monkeypatch.setattr(launch.cloud, "destroy", lambda _reason: events.append("destroy exact pair"))
    monkeypatch.setattr(launch.controller, "verify_absence", lambda: events.append("fresh absence"))
    with pytest.raises(RuntimeError):
        launch.main(["--offer-id", "11", "--volume-ask-id", "12"])
    assert events[0:2] == ["freeze", "allocate"]
    assert events[-2:] == ["destroy exact pair", "fresh absence"]


def test_failed_freeze_never_reaches_allocation(tmp_path, monkeypatch):
    def fail_freeze():
        raise ValueError("source drift")

    monkeypatch.setattr(launch.controller, "freeze_check", fail_freeze)
    monkeypatch.setattr(launch.cloud, "allocate", lambda *_: pytest.fail("allocation reached"))
    with pytest.raises(ValueError, match="source drift"):
        launch.main(["--offer-id", "11", "--volume-ask-id", "12"])


def test_fresh_absence_ignores_colleague_resources_but_rejects_owned_label(tmp_path, monkeypatch):
    cloud.save("vast-rental.json", policy())
    instances = [{"id": 999, "label": "colleague-work"}]
    volumes = [{"id": "V.888", "name": "colleague-volume"}]
    monkeypatch.setattr(cloud, "rows", lambda: instances)
    monkeypatch.setattr(cloud, "volume_rows", lambda: volumes)
    assert controller.verify_absence()["verified_absent"]
    instances.append({"id": 777, "label": cloud.LABEL})
    with pytest.raises(RuntimeError, match="absence"):
        controller.verify_absence()


@pytest.mark.parametrize("terminal", ["completed", "failed"])
def test_controller_preflights_retention_before_setup_and_collects_error_exports(
    tmp_path, monkeypatch, terminal,
):
    (tmp_path / "source.tar.gz").write_bytes(b"source")
    (tmp_path / "ssh-key.pub").write_text("ssh-ed25519 test-only")
    current = policy()
    current["source_sha256"] = cloud.digest(tmp_path / "source.tar.gz")
    cloud.save("vast-rental.json", current)
    events = []
    public = tmp_path / "ssh-key.pub"
    monkeypatch.setattr(controller, "freeze_check", lambda: {"files": {"ssh-key.pub": {
        "bytes": public.stat().st_size, "sha256": cloud.digest(public)}}})
    monkeypatch.setattr(cloud, "api", lambda *_args, **_kw: {"success": True})
    monkeypatch.setattr(cloud, "status", lambda: (tmp_path / "vast-connection.json").write_text("{}"))
    monkeypatch.setattr(controller, "probe_ssh_routes", lambda _policy: True)
    monkeypatch.setattr(cloud, "ssh", lambda *_args, **_kw: SimpleNamespace(returncode=0))
    monkeypatch.setattr(controller, "refresh_guard", lambda: None)
    monkeypatch.setattr(controller, "_native_gate", lambda: events.append("native gate"))
    monkeypatch.setattr(controller, "retention_preflight", lambda *_args: (
        events.append("retention probe") or {"recovery_reserve_seconds": 600}
    ))
    monkeypatch.setattr(controller, "_upload", lambda name: events.append("upload " + name))
    monkeypatch.setattr(controller, "_collect_logs", lambda: None)
    monkeypatch.setattr(controller, "collect_archive", lambda _policy: events.append("collect"))
    monkeypatch.setattr(controller, "emergency_archive", lambda: pytest.fail("unexpected emergency"))

    def remote(command, **_kw):
        if command.startswith("nohup"):
            events.append("setup")
        if "stage-status.json" in command:
            return json.dumps({"status": terminal, "phase": "export", "archive_ready": True}).encode()
        return b""

    monkeypatch.setattr(controller, "_remote", remote)
    if terminal == "completed":
        assert controller.main()["status"] == "completed"
    else:
        with pytest.raises(RuntimeError, match="complete raw export was retained"):
            controller.main()
    assert events.index("upload source.tar.gz") < events.index("native gate") < events.index("retention probe")
    assert events.index("upload remote_guard.py") < events.index("setup") < events.index("collect")
    assert not any("ssh-key" in event or "cloud.py" in event for event in events)


@pytest.mark.parametrize('available,admitted', [(6000, False), (10800, True)])
def test_measured_retention_proof_is_saved_before_unchanged_deadline_guard(
    tmp_path, monkeypatch, available, admitted,
):
    expected = {'format': 'soup-lossless-results-v1', 'original_file_count': 4,
                'original_bytes': 256 * controller.MIB, 'archive_bytes': 32 * controller.MIB,
                'archive_sha256': 'a' * 64, 'files': {'all': {'bytes': 256 * controller.MIB, 'sha256': 'b' * 64}}}
    replies = iter([b'', json.dumps(expected).encode()])
    monkeypatch.setattr(controller, '_remote', lambda *_a, **_k: next(replies))
    monkeypatch.setattr(controller, '_download_file', lambda *_a, **_k: {'whole_archive_verified': True})
    monkeypatch.setattr(controller, '_unpack_lossless', lambda *_a, **_k: {'verified_files': 4, 'original_bytes': 256 * controller.MIB})
    monkeypatch.setattr(controller.shutil, 'disk_usage', lambda *_: SimpleNamespace(free=100 * controller.GIB))
    ticks = iter([0., 100., 101.4])
    monkeypatch.setattr(controller.time, 'monotonic', lambda: next(ticks))
    monkeypatch.setattr(controller, '_remaining', lambda *_: available)
    manifest = {'retention_estimate_bytes': 1500000000, 'raw_estimate_bytes': 8 * controller.GIB}
    if admitted:
        controller.retention_preflight(policy(), manifest)
    else:
        with pytest.raises(RuntimeError, match='Measured retention cannot fit'):
            controller.retention_preflight(policy(), manifest)
    proof = json.loads((tmp_path / 'network-preflight.json').read_text())
    rate = expected['archive_bytes'] / 101.4
    reserve = max(600, __import__('math').ceil(1500000000 / rate * 1.5 + 180))
    assert proof['verified'] and proof['bytes_per_second'] == rate
    assert proof['recovery_reserve_seconds'] == reserve
    assert proof['remaining_seconds_at_retention_check'] == available
    assert proof['recovery_window_admitted'] is admitted
    if not admitted:
        assert 'cannot fit' in proof['rejection_reason']
