"""Pure preregistered safety gates for a NEW CPU-overlap study, not F15 qualification."""

import re

EXPECTED_COMMON = {'model': {'repo_id': 'kakaocorp/kanana-2-30b-a3b-base-2601',
           'revision': '0d31365acf656e5f9a593cacc4913e9c0d36cb1c',
           'weight_shards': 13,
           'weights_bytes': 61343935088,
           'index_total_tensor_bytes': 61341630208,
           'parameter_count': 30670809088,
           'base_dtype': 'BF16',
           'gated': False,
           'stored_tensor_elements': 30670815104,
           'router_bias_buffer_elements': 6016},
 'cuda_test_selectors': ['tests/test_two_read_cache_kanana.py::test_real_cuda_nf4_bf16_kanana_worker_trajectories',
                         'tests/test_stream_expert_cache_nf4.py::test_real_cuda_nf4_expert_cache_preserves_complete_optimizer_trajectories',
                         'tests/test_expert_grouped_routes.py::test_real_cuda_nf4_bf16_grouped_route_worker_trajectories'],
 'cuda_expected_case_names': ['test_real_cuda_nf4_bf16_kanana_worker_trajectories',
                              'test_real_cuda_nf4_expert_cache_preserves_complete_optimizer_trajectories[lru]',
                              'test_real_cuda_nf4_expert_cache_preserves_complete_optimizer_trajectories[static]',
                              'test_real_cuda_nf4_bf16_grouped_route_worker_trajectories'],
 'admission_fallback_allowed': False,
 'native_boundary': {'physical_gpu_gib_class': 8,
                     'max_ram_bytes': 34359738368,
                     'swap_must_be_disabled': True,
                     'minimum_data_free_bytes': 107374182400,
                     'minimum_root_free_bytes': 17179869184},
 'retention': {'format': 'soup-lossless-results-v1',
               'transport': 'authenticated bounded SSH ranges from first byte',
               'encoded_estimate_bytes': 1500000000,
               'raw_estimate_bytes': 12884901888,
               'actual_encoded_export_size_is_authoritative': True},
 'financial': {'maximum_stage_usd': 6.0,
               'prior_usd': 0,
               'maximum_seconds': 10800,
               'root_provider_gb': 32,
               'volume_provider_gb': 112,
               'download_allowance_decimal_gb': 90,
               'upload_allowance_decimal_gb': 2},
 'transport': {'implementation': 'native OpenSSH binary stdin/stdout',
               'upload': 'atomic byte/SHA verified and fsynced before rename',
               'probe_bytes': 262144,
               'raw_python_tcp_or_sftp_allowed': False,
               'route_selection': 'API-supplied proxy and direct only; actual owned container '
                                  'identity before selecting verified route; no host-key '
                                  'bypass'},
 'checkpoint_input_integrity': {'helper': 'checkpoint_integrity.py',
                                'official_shards': 13,
                                'official_sha256_required': True,
                                'fresh_bad_shard_redownload_global_limit': 2,
                                'expected_metadata_immutable': True,
                                'full_final_recheck_required': True,
                                'prepared_model_fingerprint_must_match_official_shas': True,
                                'hub_version': '1.33.0',
                                'force_download': True,
                                'failed_f13_sha_gate': 'FAILED and retained separately; no '
                                                       'acceptance relaxation'},
 'storage_capacity_plan': {'schema_version': 1,
                           'root_provider_gb': 32,
                           'volume_provider_gb': 112,
                           'advertised_combined_pool_required': 144,
                           'minimum_pre_download_root_free_bytes': 17179869184,
                           'minimum_pre_download_data_free_bytes': 107374182400,
                           'data_components_bytes': {'official_bf16_weights': 61343935088,
                                                     'observed_nf4_store': 16624721373,
                                                     'conservative_uv_cache': 7763013632,
                                                     'one_fresh_bad_shard_temporary': 4999552848},
                           'data_worst_case_bytes': 90731222941,
                           'minimum_pre_prepare_data_free_bytes': 29387287853,
                           'actual_statvfs_is_authoritative': True,
                           'provider_gb_to_gib_conversion_assumed': False,
                           'root_setup_evidence': {'f8/capacity-preflight.json': {'bytes': 2379,
                                                                                  'sha256': '5b03bb271bfeb76bb7f63ee557aa6e9bd393f08c924d19b05fb6a4cb1e55ba73'},
                                                   'f8/pre-download-disk.json': {'bytes': 195,
                                                                                 'sha256': 'ef7270e8fe4c4f10e5d79607a08a52457c2e80236befa25dda9e5b77fd13bf9d'},
                                                   'f14/capacity-preflight.json': {'bytes': 2622,
                                                                                   'sha256': '9cfae4c4712bbe9dbd24463dff6be94efbcdd3dbdf1bac8c4a86e1d243508176'},
                                                   'f14/pre-download-disk.json': {'bytes': 195,
                                                                                  'sha256': '4a62a752bb3ddef7911dae9189b66058c0cb85223c8805fa9174dd3d0cdb60be'}},
                           'raw_outputs_reserve_is_unchanged': True,
                           'full_bad_bf16_input_payload_retained': False,
                           'root_components_bytes': {'raw_outputs_reserve': 12884901888,
                                                     'encoded_archive_reserve': 1500000000,
                                                     'transfer_probe': 100000000,
                                                     'scratch': 2147483648},
                           'root_worst_case_output_bytes': 16632385536,
                           'output_filesystem': 'root',
                           'model_and_uv_cache_filesystem': 'data',
                           'minimum_pre_prepare_root_free_bytes': 17179869184,
                           'conservative_root_setup_allowance_bytes': 7763013632,
                           'actual_root_setup_max_observed_bytes': 7460089856}}

EXPECTED_PROBE_CONTRACT = {'accuracy_runner': 'benchmarks/harness/two_read_cache_worker.py',
 'profile_runner': 'benchmarks/harness/expert_cache_profile.py',
 'profile_warmup_updates': 2,
 'profile_optimizer_updates': 1,
 'profile_first_microbatch_only': True,
 'max_trace_bytes': 134217728,
 'host_cache_policy': 'static',
 'host_cache_bytes': 8589934592,
 'device_cache_bytes': 2147483648,
 'accuracy_updates': 2,
 'accumulation': 2,
 'sequence_length': 512,
 'batch_size': 1,
 'prepare_native_timing_fields': {'rounds': 4, 'warmup_updates': 2, 'timed_updates': 6},
 'profiled_times_are_diagnostic_only': True,
 'unprofiled_context_updates': 1}
EXPECTED_EXECUTION_PLAN = {'schema_version': 1,
 'purpose': 'cpu_thread_scaling_and_bounded_expert_fetch_profile',
 'policies': {'native': None, 't1': 1, 't2': 2, 't4': 4, 't8': 8},
 'accuracy_order': ['native', 't1', 't2', 't4', 't8'],
 'thread_override': 'after_native_build_and_initialization_before_first_training_microbatch',
 'accuracy_updates': 2,
 'accumulation': 2,
 'exploration_order': ['t4', 'native', 't8', 't2', 't1'],
 'warmup_updates': 2,
 'timed_updates': 6,
 'selection': 'fastest_distinct_actual_count_strictly_better_than_new_native_median',
 'confirmation_pairs': 4,
 'confirmation_order': 'AB_BA_AB_BA',
 'confirmation_only_after_positive_exploratory_selection': True,
 'practical_lower_bound_percent': 2.0,
 'bootstrap_samples': 5000,
 'bootstrap_seed': 29,
 'profile': {'policy': 'native',
             'warmup_updates': 2,
             'context_updates': 1,
             'microbatch': 0,
             'phase': 'forward',
             'skip_fetches': 1024,
             'fetches': 16,
             'maximum_encoded_trace_bytes': 134217728,
             'scope': 'diagnostic_forward_fetch_window_not_backward_or_whole_step'},
 'all_features': {'native_arm': 'two_read_cache',
                  'grouped_expert_routes': True,
                  'host_cache_bytes': 8589934592,
                  'device_cache_bytes': 2147483648,
                  'host_cache_policy': 'static'},
 'rtol': 0.01,
 'atol': 1e-05,
 'three_decimal_loss_gate': True}
EXPECTED_PURPOSE = 'cpu_thread_scaling_and_bounded_expert_fetch_profile'


def validate_protocol(protocol, *, source_commit, stage_id):
    if (not re.fullmatch('[0-9a-f]{40}', source_commit)
            or protocol.get('source_commit') != source_commit
            or protocol.get('stage_id') != stage_id
            or protocol.get('accuracy_first') is not True
            or protocol.get('purpose') != EXPECTED_PURPOSE):
        raise ValueError('New CPU-overlap study identity differs')
    for name, expected in EXPECTED_COMMON.items():
        if protocol.get(name) != expected:
            raise ValueError('Unchanged source/input/resource/budget boundary differs: ' + name)
    if EXPECTED_PROBE_CONTRACT is None or EXPECTED_EXECUTION_PLAN is None:
        raise ValueError('New probe contract is pending; do not allocate or freeze')
    if (protocol.get('performance') != EXPECTED_PROBE_CONTRACT
            or protocol.get('execution_plan') != EXPECTED_EXECUTION_PLAN):
        raise ValueError('Preregistered CPU/accuracy/profile/exploration/confirmation contract differs')
    if 'dispatch_qualification' in protocol.get('performance', {}):
        raise ValueError('An F15 qualification claim is not valid for this new study')
    return {'source_commit': source_commit, 'new_cpu_overlap_study': True,
            'f15_qualification_claim_allowed': False, 'cuda_cells': 4}
