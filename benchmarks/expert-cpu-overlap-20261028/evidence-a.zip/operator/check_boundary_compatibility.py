"""Read-only compatibility check against retained real resource metadata."""

import importlib.util
from pathlib import Path

from rich.console import Console

PREP = Path(__file__).parent
BASE = PREP.parent
SPEC = importlib.util.spec_from_file_location(
    "cpu_probe_boundary_check", PREP / "cpu_overlap_probe.py")
PROBE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(PROBE)


def main():
    before = PROBE.digest(PREP / "cpu_overlap_probe.py")
    stage = BASE / "kanana-30b-final-gpu-20261026-f15"
    spec_path = stage / "retained/results/prepared/spec.json"
    prepared = PROBE.read(spec_path)
    evidence = []
    for path in sorted((stage / "retained/results/dispatch-qualification").rglob("result.json")):
        raw = PROBE.read(path)
        PROBE.require(raw["status"] == "passed", "Unexpected historical failed worker")
        PROBE.validate_resource_boundary(raw, prepared)
        evidence.append({"relative_path": path.relative_to(stage).as_posix(),
                         "sha256": PROBE.digest(path), "status": "passed_native_boundary"})
    PROBE.require(len(evidence) == 11, "Expected exactly eleven actual F15 workers")
    failed_stage = BASE / "kanana-30b-final-gpu-20261026-f14"
    failed_spec = failed_stage / "retained/results/prepared/spec.json"
    failed_raws = list((failed_stage / "retained/results/dispatch-qualification").rglob(
        "result.json"))
    PROBE.require(len(failed_raws) == 1, "Expected one actual F14 ordinary capture")
    rejected = False
    try:
        PROBE.validate_resource_boundary(PROBE.read(failed_raws[0]), PROBE.read(failed_spec))
    except ValueError:
        rejected = True
    PROBE.require(rejected, "Historical F14 swap boundary must still fail")
    PROBE.require(before == PROBE.digest(PREP / "cpu_overlap_probe.py"),
                  "Runner changed during the compatibility check")
    value = {"status": "passed_actual_retained_boundary_compatibility",
             "runner_sha256": before, "f15_spec_sha256": PROBE.digest(spec_path),
             "f15_actual_workers_passed": evidence,
             "f14_actual_swap_failure_rejected": True,
             "f14_raw_sha256": PROBE.digest(failed_raws[0]),
             "scope": "actual retained metadata only; no new GPU, speed or numerical claim"}
    PROBE.save(PREP / "cpu-overlap-actual-boundary-compatibility.json", value)
    Console().print(value["status"])


if __name__ == "__main__":
    main()
