# CPU parallelism and expert forward-window probe

Offline scaffold only. No rental or freeze until parent runner, exact new protocol, CPU controls, independent review and fresh specific quote. Source43cf/archive0062717, official13 input hashes and bounded repair, GPU8/nativeRAM<=32GiB/noSwap, root32/data112 with actual free floors16/100GiB remain fixed. New cap6USD/3h/90GB+2GB within remaining6.1857075442141882USD. Accuracy first for actual CPU1/2/4/8 configurations; bounded16-expert diagnostic CUDA/H2D profile next, exploratory timings separately. Never claim this is F15 qualification or infer speed from profiler data. Native setup OMP/MKL defaults are1 and must be observed explicitly by runner. Full raw retention and exact owned instance+volume cleanup mandatory; colleague assets untouched.

Explicit extraUSD3 authorization does not authorize a rental without the final root greenlight, fresh exact quote and sufficient actual account credit.
