"""Posthoc retention/cleanup proof for failed A; never a successful model experiment."""

from __future__ import annotations

import gzip
import hashlib
import importlib.util
import json
from pathlib import Path

from rich.console import Console

ROOT = Path(__file__).parent
STAGE = ROOT.parent/"expert-cpu-overlap-gpu-20261028-a"
CORE = ROOT/"audit-versions/a-core/audit_cpu_overlap.py"
CORE_SHA = "b10aeef5913dae7ac3441133814f385f71f85305852d5690bb205a1c8f5a611c"


def main():
    if hashlib.sha256(CORE.read_bytes()).hexdigest() != CORE_SHA:
        raise ValueError("Historical A independent audit core changed")
    spec = importlib.util.spec_from_file_location("failed_audit_core", CORE)
    audit = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(audit)
    foundation = audit.module("audit_cpu_foundation", audit.FOUNDATION)
    parser = audit.module("profile_timeline", audit.TIMELINE)
    originals = audit.Originals(STAGE)
    audit.require(audit.sha(STAGE/"launch-manifest.json") == audit.LAUNCH
                  and originals.read("launch-manifest.json") == audit.read(STAGE/"launch-manifest.json"),
                  "Failed A launch differs from the preregistered A manifest")
    rental = audit.read(STAGE/"vast-rental.json")
    audit.require(rental["stage_id"] == audit.STUDY and rental["maximum_usd"] == 6
                  and rental["maximum_seconds"] == 10800, "Failed A lease scope changed")
    capacity = originals.read("results/capacity-preflight.json")
    foundation.capacity(capacity, rental)
    foundation.cuda_xml(originals.file("results/gpu-preflight.xml"))
    audit.require(originals.read("results/gpu-preflight-exit.json")["returncode"] == 0
                  and originals.read("results/profiler-preflight-exit.json")["returncode"] != 0,
                  "Actual numerical readiness/profiler failure exit status differs")
    prefix = "results/profiler-preflight/"
    proof = originals.read(prefix+"proof.json")
    summary = originals.read(prefix+"key-averages.json")
    audit.require(proof["status"] == "failed" and proof["model_downloaded"] is False
                  and proof["fetcher_restored"] is True
                  and summary["event_count"] > 0 and summary["cuda_event_count"] == 0
                  and summary["cuda_kernel_event_count"] == summary["cuda_h2d_event_count"] == 0,
                  "Failed A did not retain actual CPU-only profiler failure evidence")
    window = proof["window"]
    audit.require(window["skip_fetches"] == 1024 and window["requested_fetches"]
                  == window["profiled_fetches"] == 16
                  and all(window[key] is True for key in ("started", "stopped", "restored")),
                  "Failed diagnostic did not execute and restore its exact dynamic window")
    binding = proof["timeline_parser_binding"]
    audit.require(binding["sha256"] == audit.TIMELINE
                  and binding["launch_manifest_sha256"] == audit.LAUNCH
                  and binding["actual_path"] == "/root/liger/profile_timeline.py",
                  "Failed profiler used an unbound trace parser")
    trace_path = originals.file(prefix+"trace.json.gz")
    retention = originals.read(prefix+"trace-retention.json")
    hashed, count = hashlib.sha256(), 0
    with gzip.open(trace_path, "rb") as source:
        for data in iter(lambda: source.read(audit.CHUNK), b""):
            hashed.update(data)
            count += len(data)
    audit.require(proof["trace"] == retention and audit.sha(trace_path) == retention["sha256"]
                  and hashed.hexdigest() == retention["decoded_sha256"]
                  and count == retention["decoded_bytes"] and retention["within_bound"] is True,
                  "Failed diagnostic trace was not retained losslessly")
    timeline = parser.analyze_trace(trace_path)
    audit.require(timeline == originals.read(prefix+"timeline.json")
                  and timeline["status"] == "parsed" and timeline["gpu_complete_events"] == 0,
                  "Actual failed trace contains undisclosed GPU activity or differs")
    log = originals.file("results/profiler-preflight.log").read_text(encoding="utf-8", errors="replace")
    audit.require("CUPTI_ERROR_INVALID_DEVICE" in log, "Exact recorded CUPTI failure absent")
    for name in ("results/model-pinned.json", "results/model-download.json",
                 "results/prepared/spec.json", "results/cpu-overlap/run.json"):
        audit.require(name not in originals.outer["files"], "A unexpectedly reached large-model work")
    status = originals.read("results/stage-status.json")
    audit.require(status["status"] == originals.outer["stage_status"]["status"]
                  == originals.bundle["stage_status"]["status"] == "failed",
                  "Failed A was relabelled as a successful study")
    foundation.cleanup(rental, audit.read(STAGE/"vast-deletion.json"),
                       audit.read(STAGE/"vast-volume-deletion.json"),
                       audit.read(STAGE/"independent-vast-absence.json"), originals.bundle)
    ledger = audit.read(STAGE/"stage-ledger.json")
    costs = [row for row in ledger["completed_leases"] if row["instance_id"] == rental["instance_id"]
             and row["volume_id"] == rental["volume_id"]]
    audit.require(len(costs) == 1 and costs[0]["verified_absent"] is True
                  and costs[0]["volume_verified_absent"] is True
                  and audit.finite(costs[0]["conservative_usd"])
                  and 0 <= costs[0]["conservative_usd"] <= 6, "Failed A cost/cleanup ledger differs")
    value = {"status": "passed_independent_failed_preflight_retention_cleanup_audit",
             "scientific_status": "FAILED_PROFILER_PREFLIGHT_NO_30B_VERDICT",
             "source_commit": audit.SOURCE, "stage_id": audit.STUDY,
             "audit_script_sha256": audit.sha(Path(__file__)), "frozen_audit_core_sha256": CORE_SHA,
             "archive_manifest_sha256": audit.sha(STAGE/"archive-manifest.json"),
             "bundle_verified_sha256": audit.sha(STAGE/"bundle-verified.json"),
             "launch_manifest_sha256": audit.LAUNCH, "retention": originals.summary,
             "numerical_readiness_cases_passed": 4, "full_30b_accuracy_runs": 0,
             "full_30b_timing_runs": 0, "large_model_download_reached": False,
             "profiler": {"status": "failed", "actual_cuda_events": 0,
                 "actual_cuda_kernel_events": 0, "actual_h2d_events": 0,
                 "actual_cpu_and_metadata_events": summary["event_count"],
                 "recorded_error": "CUPTI_ERROR_INVALID_DEVICE", "window": window,
                 "trace_gpu_complete_events": timeline["gpu_complete_events"]},
             "hardware": {key: capacity[key] for key in (
                 "gpu_name", "gpu_memory_mib", "gpu_uuid", "native_ram_limit_bytes")},
             "cleanup": audit.read(STAGE/"independent-vast-absence.json"),
             "budget": {"conservative_stage_usd": costs[0]["conservative_usd"],
                 "remaining_task_usd": 6.1857075442141882-costs[0]["conservative_usd"],
                 "provider_invoice_verified": False},
             "scope": "Posthoc infrastructure/failure evidence only; no accuracy or speed gain claim"}
    (ROOT/"cpu-overlap-a-failed-independent-audit.json").write_text(json.dumps(value, indent=2)+"\n")
    Console().print({"status": value["status"], "scientific_status": value["scientific_status"],
                     "retained_originals": originals.summary["verified_files"], "cost": value["budget"]})


if __name__ == "__main__":
    main()
