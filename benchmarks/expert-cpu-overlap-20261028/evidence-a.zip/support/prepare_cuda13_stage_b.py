"""Prepare an unpaid, distinct CUDA13 compatibility cohort after retained A failure."""

import hashlib
import json
import re
from pathlib import Path

from rich.console import Console

PREP = Path(__file__).parent
BASE = PREP.parent
OLD = BASE / "expert-cpu-overlap-gpu-20261028-a"
NEW = BASE / "expert-cpu-overlap-gpu-20261028-b"


def main():
    assert json.loads((OLD / "independent-vast-absence.json").read_text())["verified_absent"]
    retained = json.loads((OLD / "bundle-verified.json").read_text())
    assert retained["all_manifested_raw_files_retained"]
    cost = sum(row["conservative_usd"] for row in json.loads(
        (OLD / "stage-ledger.json").read_text())["completed_leases"])
    assert cost == .507217201476755
    manifest = json.loads((OLD / "launch-manifest.json").read_text())
    NEW.mkdir(exist_ok=False)
    omitted = {"ssh-key.pub", "key-control.json", "key-dacl-control.json", "operator-tests.xml"}
    immutable = {"source.tar.gz", "source-manifest.json", "cpu_overlap_probe.py",
                 "profile_timeline.py", "protocol-contract.json", "checkpoint_integrity.py",
                 "preflight_remote.py", "remote_guard.py", "lossless_results.py", "api_rate_limit.py",
                 "api_transport.py", "range_transport.py", "diagnostics.py",
                 "test_cpu_overlap_independent.py", "cpu-overlap-independent.xml",
                 "cpu-overlap-independent-review.json", "test_cpu_overlap_runtime.py",
                 "cpu-overlap-controls.xml", "cpu-overlap-independent-combined.xml",
                 "check_boundary_compatibility.py", "cpu-overlap-actual-boundary-compatibility.json",
                 "storage-capacity-plan.json"}
    for name in sorted((set(manifest["files"]) | {"WORKPLAN.md"}) - omitted):
        payload = (OLD / name).read_bytes()
        if name not in immutable and name.endswith((".py", ".json", ".md")):
            text = payload.decode().replace("20261028-a", "20261028-b")
            text = text.replace("20261028_a", "20261028_b")
            if name in {"cloud.py", "launch.py", "test_controller.py", "test_operator_safety.py"}:
                text = text.replace("10800", "9000").replace("3-hour", "2.5-hour")
            if name == "cloud.py":
                text = text.replace("MAXIMUM_USD = 6.0", "MAXIMUM_USD = 5.60")
                text = text.replace("USD6 subcap within USD6.1857075442141882",
                                    "USD5.60 subcap within USD5.678490342737433")
                text = text.replace('"cuda_max_good": {"gte": 12.8}',
                                    '"cuda_max_good": {"gte": 13.0}')
            if name == "test_operator_safety.py":
                text = text.replace('"constraints.txt", "setup.sh",', '')
                text = text.replace('"maximum_stage_usd": 6.', '"maximum_stage_usd": 5.60')
                text = text.replace('result["maximum_stage_usd"] == 6.',
                                    'result["maximum_stage_usd"] == 5.60')
                text = text.replace('row["new_stage_cap_usd"] == 6.',
                                    'row["new_stage_cap_usd"] == 5.60')
                text = text.replace('+ row["cpu_overlap_additional_authorized_usd"],',
                                    '+ row["cpu_overlap_additional_authorized_usd"] '
                                    '- row["failed_cpu_overlap_a_cost_usd"],')
            payload = text.replace("\r\n", "\n").encode()
        (NEW / name).write_bytes(payload)
    metadata = json.loads((PREP / "cuda13-stack-metadata.json").read_text())
    extra = json.loads((PREP / "cuda13-transitive-metadata.json").read_text())
    versions = {"torch": "2.10.0+cu130", "bitsandbytes": "0.50.2"}
    for line in metadata["torch_dependencies"]:
        match = re.match(r"Requires-Dist: ([A-Za-z0-9_-]+)==([^; ]+)", line)
        if match:
            versions[match[1]] = match[2]
    versions["cuda-pathfinder"] = extra["cuda-pathfinder"]["version"]
    assert versions["triton"] == "3.6.0" and versions["cuda-bindings"] == "13.0.3"
    original = (OLD / "constraints.txt").read_text().splitlines()
    kept = [line for line in original if not line.startswith(("nvidia-", "torch==", "triton=="))]
    kept = [line for line in kept if line.partition("==")[0] not in versions]
    pins = kept + [name + "==" + version for name, version in versions.items()]
    (NEW / "constraints.txt").write_text("\n".join(sorted(pins, key=str.lower)) + "\n")
    torch_url = metadata["torch_wheel"]["href"]
    bnb = metadata["bnb_wheel"]
    bnb_url = bnb["url"] + "#sha256=" + bnb["digests"]["sha256"]
    setup = (OLD / "setup.sh").read_text().replace("/whl/cu128", "/whl/cu130")
    setup = setup.replace("'torch==2.8.0'", "'" + torch_url + "'")
    setup = setup.replace("'bitsandbytes==0.50.2'", "'" + bnb_url + "'")
    (NEW / "setup.sh").write_bytes(setup.replace("\r\n", "\n").encode())
    cohort = {"schema_version": 1, "name": "torch210_cu130_compatibility_retry",
              "torch_version": "2.10.0+cu130", "torch_cuda_version": "13.0",
              "required_cuda_major": 13, "required_versions": versions,
              "torch_wheel_url_with_sha256": torch_url,
              "bitsandbytes_wheel_url_with_sha256": bnb_url,
              "bitsandbytes_required_native_library": "libbitsandbytes_cuda130.so",
              "metadata_sha256": hashlib.sha256((PREP / "cuda13-stack-metadata.json").read_bytes())
                  .hexdigest(),
              "transitive_metadata_sha256": hashlib.sha256(
                  (PREP / "cuda13-transitive-metadata.json").read_bytes()).hexdigest(),
              "gpu_proof_from_metadata": False,
              "old_f15_or_stage_a_timing_denominator_allowed": False}
    protocol = json.loads((NEW / "protocol.json").read_text())
    protocol["financial"].update(maximum_stage_usd=5.60, maximum_seconds=9000)
    protocol["software_cohort"] = cohort
    (NEW / "protocol.json").write_text(json.dumps(protocol, indent=2) + "\n")
    (NEW / "software-cohort.json").write_text(json.dumps(cohort, indent=2) + "\n")
    for name in ("cuda13-stack-metadata.json", "cuda13-transitive-metadata.json"):
        (NEW / name).write_bytes((PREP / name).read_bytes())
    context = json.loads((NEW / "prior-budget-context.json").read_text())
    context["cpu_overlap_a_remaining_before_usd"] = context[
        "aggregate_remaining_before_cpu_overlap_usd"]
    context["failed_cpu_overlap_a_cost_usd"] = cost
    context["aggregate_remaining_before_cpu_overlap_usd"] = 5.678490342737433
    context["new_stage_cap_usd"] = 5.60
    context["compatibility_retry"] = "One separately reviewed CUDA13 cohort; no automatic paid retry"
    (NEW / "prior-budget-context.json").write_text(json.dumps(context, indent=2) + "\n")
    proof = json.loads((OLD / "retained/results/profiler-preflight/proof.json").read_text())
    compact = {"stage_id": "soup-expert-cpu-overlap-20261028-a",
               "status": "FAILED actual profiler preflight; no 30B numerical/speed data",
               "profiler_error": proof["error"], "runtime_log_error": "CUPTI_ERROR_INVALID_DEVICE(2)",
               "four_numerical_cuda_tests_passed": True, "model_downloaded": False,
               "conservative_cost_usd": cost, "all_raw_originals_retained": True,
               "original_files": retained["verified_files"], "original_bytes": retained["original_bytes"],
               "archive_bytes": retained["bytes"], "archive_sha256": retained["sha256"],
               "exact_instance_and_volume_absence": json.loads(
                   (OLD / "independent-vast-absence.json").read_text())}
    (NEW / "prior-attempt-a.json").write_text(json.dumps(compact, indent=2) + "\n")
    (NEW / "WORKPLAN.md").write_text(
        "# New CUDA13 experimental software cohort\n\n"
        "Unpaid stageB; no CREATE before root final review/approval. PriorA actual CUPTI "
        "INVALID_DEVICE failure and raw/cost remain unchanged. Official torch2.10cu130 "
        "and coupled CUDA13/Triton3.6 pins; bitsandbytes0.50.2 actual CUDA130 backend required. "
        "Source43cf/probe f4/contract/profile1024+16/tolerances/cache/native8GB/RAM/noSwap "
        "unchanged. Runtime stack gate BEFORE all4 CUDA numerical controls and actual dynamic "
        "CUDA/H2D proof, all BEFORE61GB model. Fresh baseline on this GPU/software only; "
        "F15 and A are not timing denominators. Cap5.60USD/9000s/90GB+2GB unchanged reserves "
        "within remaining5.678490342737433USD. Fullraw/failed receipts/instance+disk cleanup.\n")
    Console().print({"new_stage": str(NEW), "new_software_cohort": cohort["name"],
                     "coupled_pins": versions, "rental_started": False})


if __name__ == "__main__":
    main()
