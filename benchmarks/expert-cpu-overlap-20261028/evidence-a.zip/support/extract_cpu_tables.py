"""Descriptive tables from retained originals; not a replacement for the auditor."""

from __future__ import annotations

import json
import statistics
from pathlib import Path

from rich.console import Console

PREP = Path(__file__).parent
STAGE = PREP.parent / "expert-cpu-overlap-gpu-20261028-b"
GIB = 2**30


def read(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> None:
    base = STAGE / "retained/results/cpu-overlap"
    run = read(base / "run.json")
    by_policy = {row["policy"]: row for row in run["exploration"]}
    reference = statistics.median(by_policy["native"]["step_seconds"])
    rows = []
    for policy in ("native", "t1", "t2", "t4", "t8"):
        source = by_policy[policy]
        raw, envelope = source["worker"]["result"], source["worker"]["envelope"]
        timing = raw["timing"]
        median = statistics.median(source["step_seconds"])
        rows.append({
            "policy": policy, "actual_intraop_threads": source["actual_threads"],
            "steps_seconds": source["step_seconds"], "median_step_seconds": median,
            "exploratory_difference_percent": 100 * (median / reference - 1),
            "setup_seconds": raw["setup"]["seconds"],
            "native_build_seconds": envelope["native_build_seconds_before_thread_override"],
            "configuration_seconds": envelope["thread_control"][
                "configuration_seconds_included_in_native_setup"],
            "inner_native_worker_seconds": raw["total_worker_seconds"],
            "whole_eight_update_entry_seconds": source["worker"]["fresh_process_wall_seconds"],
            "peak_allocated_vram_gib": timing["cuda"]["peak_allocated_bytes"] / GIB,
            "peak_reserved_vram_gib": timing["cuda"]["peak_reserved_bytes"] / GIB,
            "sampled_timed_peak_rss_gib": timing["resources"]["sampled_peak_rss_bytes"] / GIB,
            "sampled_timed_process_swap_bytes": timing["resources"][
                "sampled_peak_process_swap_bytes"],
            "sampled_timed_cgroup_swap_bytes": timing["resources"][
                "sampled_peak_cgroup_swap_bytes"],
            "thread_control": envelope["thread_control"],
        })
    profile = run["profile"]["result"]
    timeline = read(base / "profile/native/timeline.json")
    averages = profile["profile_summary"]["key_averages"]
    cpu = sorted((row for row in averages if row["device_type"] == "DeviceType.CPU"),
                 key=lambda row: row["self_cpu_time_total_us"], reverse=True)[:10]
    dequant = [row for row in averages if row["device_type"] == "DeviceType.CUDA"
               and "kDequantizeBlockwise" in row["name"]]
    result = {
        "status": "descriptive_retained_original_tables_not_independent_verdict",
        "source_commit": run["identity"]["source_commit"],
        "timing": rows, "selection": run["selection"],
        "accuracy": {
            policy: {"controls": value["controls"], "versus_native": value["versus_native"]}
            for policy, value in run["accuracy"].items()
        },
        "profile": {
            "scope": "native forward window only, not a full-step causal split",
            "window": profile["window"], "actual_gpu_trace_events": timeline[
                "event_category_counts"], "devices": timeline["devices"],
            "cpu_self_time_ranking": cpu, "direct_dequant_kernel_events": dequant,
            "direct_dequant_kernel_duration_sum_us": sum(
                row["self_device_time_total_us"] for row in dequant),
            "duration_interpretation": "Nested/concurrent durations are not additive; "
                                       "profiler time is not unprofiled speed",
        },
        "financial": {
            "attempt_a_usd": .507217201476755,
            "attempt_b_usd": .769376338256434,
            "total_current_check_usd": .507217201476755 + .769376338256434,
            "remaining_usd": 4.909114004480999,
            "provider_invoice_verified": False,
        },
    }
    out = PREP / "cpu-overlap-b-tables.json"
    out.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    Console().print({"saved": str(out), "policies": len(rows), "confirmation": False})


if __name__ == "__main__":
    main()
