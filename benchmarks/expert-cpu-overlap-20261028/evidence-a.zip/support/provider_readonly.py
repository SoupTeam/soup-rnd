"""Fresh read-only admission check; never allocate or modify cloud resources."""

from __future__ import annotations

import json
import sys
import time
import urllib.request
from pathlib import Path

BASE = Path(__file__).parent
OLD = BASE.parent / "kanana-30b-final-gpu-20261026-f15"
sys.path[:0] = [str(OLD), str(OLD / ".deps")]

import cloud  # noqa: E402
from api_transport import request_json  # noqa: E402
from rich.console import Console  # noqa: E402

REMAINING = 3.1857075442141882


def read_api(path: str, payload: dict | None = None) -> dict:
    secret = cloud.KEY_FILE.read_text().strip()
    if not secret:
        raise ValueError("Missing provider credential")
    request = urllib.request.Request(
        "https://console.vast.ai" + path,
        method="GET" if payload is None else "POST",
        data=None if payload is None else json.dumps(payload).encode(),
        headers={"Authorization": "Bearer " + secret, "Content-Type": "application/json"},
    )
    return request_json(request, readonly=True, secret=secret, deadline=time.monotonic() + 180)


def main() -> None:
    query = dict(cloud.QUERY, limit=100)
    offers = read_api("/api/v0/bundles/", query)["offers"]
    known = read_api("/api/v0/bundles/", dict(query, machine_id={"eq": 122165}))["offers"]
    choices = {int(row["id"]): row for row in [*known, *offers]}
    ordered = sorted(choices.values(), key=lambda row: (
        int(row["machine_id"]) != 122165, float(row["dph_total"])))
    candidates, failures = [], []
    for offer in ordered[:5]:
        try:
            cloud.validate_full_host(offer)
            volume_query = {
                "external": {"eq": False}, "machine_id": {"eq": offer["machine_id"]},
                "disk_space": {"gte": 112}, "allocated_storage": 112,
                "order": [["storage_cost", "asc"]], "limit": 100,
            }
            volumes = read_api("/api/v0/volumes/search/", volume_query)["offers"]
            for volume in volumes[:1]:
                quote = cloud.quote(offer, seconds=10800, download_gb=90., volume_offer=volume)
                candidates.append({"offer": offer, "volume": volume, "quote": quote,
                                   "within_task_budget": quote[
                                       "total_stage_admission_usd"] <= min(3., REMAINING)})
        except (ValueError, KeyError, TypeError) as error:
            failures.append({"offer_id": offer["id"], "error_type": type(error).__name__})
    instances, token = [], None
    while True:
        import urllib.parse

        route = "/api/v1/instances/?limit=100"
        if token:
            route += "&after_token=" + urllib.parse.quote(token)
        reply = read_api(route)
        instances.extend(reply["instances"])
        token = reply.get("next_token")
        if not token:
            break
    volumes = read_api("/api/v0/volumes?owner=me&type=all_volume")["volumes"]
    old_ids = {57813461, 57816217, 57818600, 57821738, 57829751, 57839215}
    old_volume_ids = {57813460, 57816216, 57818598, 57821736, 57829750, 57839213}
    owned_absent = not any(cloud.resource_id(row["id"]) in old_ids for row in instances)
    owned_absent &= not any(cloud.resource_id(row["id"]) in old_volume_ids for row in volumes)
    report = {"unix": time.time(), "rental_started": False, "read_only": True,
              "task_remaining_usd": REMAINING, "candidates": candidates,
              "failures": failures, "old_owned_resources_absent": bool(owned_absent),
              "unrelated_resources_untouched": True}
    (BASE / "provider-readonly.json").write_text(json.dumps(report, indent=2) + "\n")
    Console().print({"candidates": [{"machine": row["offer"]["machine_id"],
                                    "gpu": row["offer"]["gpu_name"],
                                    "quote_usd": row["quote"]["total_stage_admission_usd"],
                                    "fits": row["within_task_budget"]} for row in candidates],
                     "remaining_usd": REMAINING, "old_owned_absent": bool(owned_absent),
                     "rental_started": False})


if __name__ == "__main__":
    main()
