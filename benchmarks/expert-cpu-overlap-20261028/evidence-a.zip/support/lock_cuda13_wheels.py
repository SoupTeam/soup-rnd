"""Pin official Linux/cp312-compatible coupled CUDA13 wheels without downloading binaries."""

import hashlib
import json
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from packaging.utils import parse_wheel_filename
from rich.console import Console

PREP = Path(__file__).parent
STAGE = PREP.parent / "expert-cpu-overlap-gpu-20261028-b"


def wheel(name, version):
    url = f"https://pypi.org/pypi/{name}/{version}/json"
    with urllib.request.urlopen(url, timeout=30) as response:
        payload = response.read()
    metadata = json.loads(payload)
    choices = []
    for row in metadata["urls"]:
        if not row["filename"].endswith(".whl"):
            continue
        _name, _version, _build, tags = parse_wheel_filename(row["filename"])
        compatible = any(
            (tag.interpreter == "cp312" or tag.interpreter == "py3")
            and (tag.platform == "any" or (tag.platform.startswith("manylinux")
                                          and tag.platform.endswith("x86_64"))) for tag in tags)
        if compatible:
            choices.append(row)
    if len(choices) != 1:
        raise ValueError(f"Exact unambiguous Linux/cp312 wheel not found: {name}=={version}")
    row = choices[0]
    return name, {"version": version, "filename": row["filename"], "url": row["url"],
                  "bytes": row["size"], "sha256": row["digests"]["sha256"],
                  "metadata_url": url, "metadata_sha256": hashlib.sha256(payload).hexdigest(),
                  "requires_python": metadata["info"].get("requires_python"),
                  "requires_dist": metadata["info"].get("requires_dist")}


def main():
    cohort = json.loads((STAGE / "software-cohort.json").read_text())
    versions = cohort["required_versions"]
    with ThreadPoolExecutor(max_workers=4) as pool:
        records = dict(pool.map(lambda item: wheel(*item), (
            (name, version) for name, version in versions.items() if name != "torch")))
    official = json.loads((PREP / "cuda13-stack-metadata.json").read_text())
    url, _sep, sha = official["torch_wheel"]["href"].partition("#sha256=")
    with urllib.request.urlopen(urllib.request.Request(url, method="HEAD"), timeout=30) as response:
        length = int(response.headers["Content-Length"])
    records["torch"] = {"version": "2.10.0+cu130", "url": url, "sha256": sha,
                        "filename": url.rsplit("/", 1)[-1], "bytes": length,
                        "metadata_sha256": official["torch_metadata_sha256"],
                        "source": "official PyTorch CUDA13 index wheel and hashed core metadata"}
    lock = {"schema_version": 1, "target": "Linux x86_64 CPython3.12",
            "source_scope": "official immutable wheel URLs/digests; no binary download/execution",
            "wheels": records, "total_compressed_bytes": sum(row["bytes"] for row in records.values())}
    payload = (json.dumps(lock, indent=2) + "\n").encode()
    (STAGE / "runtime-wheel-lock.json").write_bytes(payload)
    (PREP / "cuda13-runtime-wheel-lock.json").write_bytes(payload)
    lines = [row["url"] + "#sha256=" + row["sha256"] for _name, row in sorted(records.items())]
    (STAGE / "runtime-wheel-requirements.txt").write_text("\n".join(lines) + "\n")
    cohort["wheel_lock_sha256"] = hashlib.sha256(payload).hexdigest()
    (STAGE / "software-cohort.json").write_text(json.dumps(cohort, indent=2) + "\n")
    protocol = json.loads((STAGE / "protocol.json").read_text())
    protocol["software_cohort"] = cohort
    (STAGE / "protocol.json").write_text(json.dumps(protocol, indent=2) + "\n")
    Console().print({"official_wheels_pinned": len(records),
                     "compressed_bytes": lock["total_compressed_bytes"],
                     "wheel_lock_sha256": cohort["wheel_lock_sha256"],
                     "binary_downloaded_or_executed": False, "rental_started": False})


if __name__ == "__main__":
    main()
