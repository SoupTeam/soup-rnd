"""Read-only wider offer inventory, preserving physical8GB and RAM maximum32GiB."""

from __future__ import annotations

import json
import time

from rich.console import Console

from provider_readonly import BASE, REMAINING, cloud, read_api


def main() -> None:
    query = dict(cloud.QUERY, cpu_ram={"gte": 20000, "lte": 32768},
                 reliability={"gte": .90}, limit=500)
    offers = read_api("/api/v0/bundles/", query)["offers"]
    offers.sort(key=lambda row: (row["machine_id"] in {58086, 55801, 145818},
                                 -int(row["cpu_ram"]), float(row["dph_total"])))
    candidates = []
    for offer in offers[:10]:
        if offer["machine_id"] in {58086, 55801, 145818}:
            continue
        if (offer["num_gpus"] != 1 or offer["gpu_frac"] != 1.
                or not 7900 <= offer["gpu_ram"] <= 8300):
            continue
        volume_query = {"external": {"eq": False},
                        "machine_id": {"eq": offer["machine_id"]},
                        "disk_space": {"gte": 112}, "allocated_storage": 112,
                        "order": [["storage_cost", "asc"]], "limit": 100}
        volumes = read_api("/api/v0/volumes/search/", volume_query)["offers"]
        for volume in volumes[:1]:
            quote = cloud.quote(offer, seconds=10800, download_gb=90., volume_offer=volume)
            candidates.append({"offer": offer, "volume": volume, "quote": quote,
                               "within_task_budget": quote["total_stage_admission_usd"]
                               <= min(3., REMAINING),
                               "original_minimum_ram_metadata_met": offer["cpu_ram"] >= 28000})
    report = {"unix": time.time(), "query": query, "rental_started": False,
              "read_only": True, "task_remaining_usd": REMAINING,
              "candidates": candidates, "offers_found": len(offers)}
    (BASE / "provider-wide-readonly.json").write_text(json.dumps(report, indent=2) + "\n")
    Console().print({"offers_found": len(offers), "rental_started": False,
                     "candidates": [{"machine": row["offer"]["machine_id"],
                                     "ram_mib": row["offer"]["cpu_ram"],
                                     "gpu": row["offer"]["gpu_name"],
                                     "quote_usd": row["quote"]["total_stage_admission_usd"],
                                     "fits": row["within_task_budget"]} for row in candidates]})


if __name__ == "__main__":
    main()
