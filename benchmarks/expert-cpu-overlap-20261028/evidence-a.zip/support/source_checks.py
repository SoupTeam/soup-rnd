"""Local CPU-only ownership/pinning checks; no GPU or training speed claim."""

from __future__ import annotations

import ast
import hashlib
import inspect
import json
import sys
import textwrap
from pathlib import Path
from types import SimpleNamespace

BASE = Path(__file__).parent
REPO = Path(r"C:\Users\esenb\.codex\worktrees\expert-dispatch-opt-20261026\soup-rnd-d2")
DEPS = BASE.parent / "kanana-30b-final-gpu-20261026-f15/.deps"
sys.path[:0] = [str(DEPS), str(REPO / "src")]


def main() -> None:
    import torch
    from rich.console import Console

    from soup_cli.utils.expert_cache import TensorHotset
    from soup_cli.utils.expert_stream import ExpertFetcher

    owner = object.__new__(ExpertFetcher)
    owner._staging = owner._staging_owner = None
    reader = SimpleNamespace(max_span=2**20)
    first = owner._staging_for(reader)
    first.fill_(53)
    cache = TensorHotset(2**20, copy_on_insert=True)
    assert cache.put("control", {"packed": first})
    second = owner._staging_for(reader)
    cached = cache.get("control")["packed"]
    second.fill_(127)
    assert first.data_ptr() == second.data_ptr()
    assert first.data_ptr() != cached.data_ptr()
    assert torch.equal(cached, torch.full_like(cached, 53))
    tree = ast.parse(textwrap.dedent(inspect.getsource(ExpertFetcher.fetch)))
    copies = [{"line_in_function": call.lineno,
               "non_blocking_explicit": any(item.arg == "non_blocking" for item in call.keywords)}
              for call in ast.walk(tree)
              if isinstance(call, ast.Call) and isinstance(call.func, ast.Attribute)
              and call.func.attr == "to"]
    source_path = Path(inspect.getsourcefile(ExpertFetcher))
    report = {"scope": "LOCAL_CPU_ONLY; no CUDA/H2D/step speed measured",
              "torch_version": torch.__version__,
              "source_commit": "43cf0b34afe0d8850d76bf86d60663ab5c85cdb2",
              "expert_source_sha256": hashlib.sha256(source_path.read_bytes()).hexdigest(),
              "shared_staging_is_reused": first.data_ptr() == second.data_ptr(),
              "cpu_staging_is_pinned": first.is_pinned(),
              "cpu_host_cache_is_pinned": cached.is_pinned(),
              "host_cache_does_not_alias_staging": first.data_ptr() != cached.data_ptr(),
              "host_cache_survives_staging_reuse_exactly": True,
              "fetch_to_calls": copies,
              "interpretation": "Current CPU staging and cloned hotset are pageable."
              " Fetch does not explicitly request asynchronous Tensor.to copies."
              " True overlap needs a separate bounded ownership/event protocol;"
              " unsafe reuse of the one mutable staging arena can corrupt transfers."}
    (BASE / "source-checks.json").write_text(json.dumps(report, indent=2) + "\n")
    Console().print(report)


if __name__ == "__main__":
    main()
