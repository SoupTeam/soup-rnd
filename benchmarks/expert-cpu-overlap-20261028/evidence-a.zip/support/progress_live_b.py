"""Read-only CPU JSON/XML/filesystem observation; no provider API or GPU queries."""

import json
import shlex
import sys
import time
from pathlib import Path

STAGE = Path(__file__).parent.parent / "expert-cpu-overlap-gpu-20261028-b"
sys.path[:0] = [str(STAGE), str(STAGE / ".deps")]

import cloud  # noqa: E402
from rich.console import Console  # noqa: E402

PROGRAM = '''import json,sys,time,xml.etree.ElementTree as ET
from pathlib import Path
root=Path('/root/liger');out=root/'results';data=Path('/data/kanana30b')
def read(name):
 p=out/name
 return json.loads(p.read_text()) if p.exists() else {}
cuda=[];p=out/'gpu-preflight.xml'
if p.exists():
 for case in ET.parse(p).findall('.//testcase'):
  cuda.append({'name':case.get('name'),'passed':all(case.find(tag) is None for tag in ('failure','error','skipped'))})
files=[]
if data.exists():
 for p in data.rglob('*'):
  if p.is_file() and p.name.endswith(('.safetensors','.incomplete')):
   s=p.stat();files.append({'name':p.name,'bytes':s.st_size,'mtime':s.st_mtime})
raw=read('cpu-overlap/run.json');integ=read('checkpoint-integrity.json')
events=integ.get('events',[]);tiny=read('profiler-preflight/proof.json')
profile=raw.get('profile',{})
summary={'status':raw.get('status'),'accuracy_passed':raw.get('accuracy_passed'),
 'error':raw.get('error'),'accuracy_policies_complete':list(raw.get('accuracy',{})),
 'profile_complete':bool(profile),'exploratory_workers_complete':len(raw.get('exploration',[])),
 'selection':raw.get('selection'),'confirmatory_workers_complete':len(raw.get('confirmation',[]))}
workers=[];workerroot=out/'cpu-overlap'
if workerroot.exists():
 for p in workerroot.rglob('result.json'):
  try:
   r=json.loads(p.read_text());capture=p.parent/'capture.pt'
   workers.append({'path':str(p.relative_to(workerroot)),'status':r.get('status'),
    'phase':r.get('phase'),'setup_seconds':r.get('setup',{}).get('seconds'),
    'capture_bytes':capture.stat().st_size if capture.exists() else 0})
  except (OSError,ValueError):pass
summary['workers']=workers
result={'unix':time.time(),'status':read('stage-status.json'),'cuda_controls':cuda,
 'profiler_preflight':{k:tiny.get(k) for k in ('status','model_downloaded','error','window','fetcher_restored')},
 'downloaded_weight_bytes':sum(r['bytes'] for r in files),'weight_shards_complete':sum(r['name'].endswith('.safetensors') for r in files),
 'integrity':{k:integ.get(k) for k in ('status','forced_redownloads_used','all_shards_verified','error_category')},
 'hashes_completed':sum(e.get('event')=='hash_completed' for e in events),
 'prepared_integrity':read('prepared-integrity.json'),'run':summary}
sys.stdout.write(json.dumps(result))
'''


def main():
    result = cloud.ssh("python3 -c " + shlex.quote(PROGRAM), timeout=30)
    if result.returncode:
        raise RuntimeError("Exact-owned CPU progress observation failed")
    row = json.loads(result.stdout)
    row["local_observation_unix"] = time.time()
    row["observation_scope"] = "Read-only CPU files/JSON/XML; no provider API or GPU queries"
    cloud.save("progress-readonly.json", row)
    Console().print({"phase": row["status"], "cuda_passed": sum(
        r["passed"] for r in row["cuda_controls"]),
        "tiny_profiler": row["profiler_preflight"].get("status"),
        "downloaded_bytes": row["downloaded_weight_bytes"],
        "weight_shards_complete": row["weight_shards_complete"],
        "integrity": row["integrity"], "hashes_completed": row["hashes_completed"],
        "run": row["run"]})


if __name__ == "__main__":
    main()
