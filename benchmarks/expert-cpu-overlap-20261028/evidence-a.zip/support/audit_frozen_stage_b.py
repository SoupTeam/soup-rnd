"""Independent final offline manifest, protocol and owner-key check; no cloud calls."""

from __future__ import annotations

import base64
import hashlib
import importlib.util
import json
import math
import os
import struct
import subprocess
import sys
import urllib.request
import xml.etree.ElementTree as ET
from pathlib import Path

from rich.console import Console

PREP = Path(__file__).parent
STAGE = PREP.parent / "expert-cpu-overlap-gpu-20261028-b"
F15 = PREP.parent / "kanana-30b-final-gpu-20261026-f15"
MANIFEST_SHA = "f2c4afa213b4af4b500ceec04c64071a59f3ac380a7d1ec1db6952657ba66884"
RUNNER_SHA = "f4eabf7867a0908249a78e83054d6f5e139afe54f4d8eca93cc38eeb031726b3"
REVIEW_SHA = "b439923d21672e217c3ef570467b91750c3b26fcedf9a8529662767899a4067a"


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def main():
    urllib.request.urlopen = lambda *_a, **_k: (_ for _ in ()).throw(
        AssertionError("Network is forbidden in this offline review"))
    manifest_path = STAGE / "launch-manifest.json"
    require(digest(manifest_path) == MANIFEST_SHA, "Unexpected frozen manifest")
    manifest = read(manifest_path)
    rows = manifest["files"]
    require(len(rows) == 57, "Expected fifty-seven frozen inputs")
    for name, row in rows.items():
        path = Path(os.path.realpath(STAGE / name))
        require(os.path.commonpath((os.path.realpath(STAGE), str(path))) ==
                os.path.realpath(STAGE), "Frozen input escaped its stage")
        require(path.is_file() and path.stat().st_size == row["bytes"]
                and digest(path) == row["sha256"], "Frozen input drift: " + name)
    sys.path[:0] = [str(STAGE), str(STAGE / ".deps")]
    import controller

    require(Path(controller.__file__) == STAGE / "controller.py", "Wrong controller import")
    require(controller.freeze_check() == manifest, "Actual frozen controller gate differs")
    require(digest(STAGE / "cpu_overlap_probe.py") == RUNNER_SHA, "Wrong private runner")
    require(digest(STAGE / "cpu-overlap-independent-review.json") == REVIEW_SHA,
            "Wrong independent runner review")
    for name in ("source.tar.gz", "source-manifest.json",
                 "checkpoint_integrity.py", "preflight_remote.py",
                 "remote_guard.py", "api_transport.py", "api_rate_limit.py",
                 "lossless_results.py", "storage-capacity-plan.json"):
        require((STAGE / name).read_bytes() == (F15 / name).read_bytes(),
                "Original source/input/resource helper changed: " + name)
    spec = importlib.util.spec_from_file_location("frozen_cpu_probe_review",
                                                 STAGE / "cpu_overlap_probe.py")
    probe = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(probe)
    protocol = read(STAGE / "protocol.json")
    require(protocol["execution_plan"] == probe.CONTRACT == read(STAGE / "protocol-contract.json"),
            "Canonical execution contract differs")
    financial = protocol["financial"]
    require(financial["maximum_stage_usd"] == 5.6 and financial["maximum_seconds"] == 9000
            and financial["root_provider_gb"] == 32 and financial["volume_provider_gb"] == 112
            and financial["download_allowance_decimal_gb"] == 90
            and financial["upload_allowance_decimal_gb"] == 2, "Financial/storage cap drift")
    context = read(STAGE / "prior-budget-context.json")
    expected_remaining = context["prior_remaining_usd"] + context["new_authorized_usd"] - sum(
        context[key] for key in ("failed_f10_cost_usd", "failed_f11_cost_usd",
                                "failed_f12_cost_usd", "failed_f13_cost_usd",
                                "failed_f14_cost_usd", "completed_f15_cost_usd"))
    expected_remaining += context["cpu_overlap_additional_authorized_usd"]
    expected_remaining -= context["failed_cpu_overlap_a_cost_usd"]
    require(context["cpu_overlap_additional_authorized_usd"] == 3
            and math.isclose(expected_remaining, 5.678490342737433, abs_tol=1e-12)
            and financial["maximum_stage_usd"] < expected_remaining, "Prior budget differs")
    cases = ET.parse(STAGE / "operator-tests.xml").findall(".//testcase")
    require(len(cases) == 203 and not any(case.find(tag) is not None for case in cases
                                        for tag in ("failure", "error", "skipped")),
            "All 203 local stage controls must pass without skips")
    key = STAGE / "ssh-key"
    acl_script = "$ErrorActionPreference='Stop';$a=Get-Acl -LiteralPath '" + str(key) + "';" + (
        "$o=$a.GetOwner([System.Security.Principal.SecurityIdentifier]).Value;"
        "$r=@($a.GetAccessRules($true,$true,[System.Security.Principal.SecurityIdentifier])|"
        "ForEach-Object{@{sid=$_.IdentityReference.Value;rights=[string]$_.FileSystemRights;"
        "type=[string]$_.AccessControlType;inherited=$_.IsInherited}});"
        "@{owner_sid=$o;protected=$a.AreAccessRulesProtected;rules=$r}|ConvertTo-Json -Depth 5")
    actual_acl = json.loads(subprocess.check_output(
        ["pwsh", "-NoProfile", "-Command", acl_script], text=True))
    recorded_acl = read(STAGE / "key-dacl-control.json")
    require(actual_acl["protected"] is True
            and actual_acl["owner_sid"] == recorded_acl["owner_sid"]
            and len(actual_acl["rules"]) == 1, "Private key owner/protected DACL differs")
    rule = actual_acl["rules"][0]
    require(rule == {"sid": actual_acl["owner_sid"], "rights": "FullControl",
                     "type": "Allow", "inherited": False}, "Private key has foreign ACE")
    private = base64.b64decode(b"".join(key.read_bytes().splitlines()[1:-1]))
    require(private.startswith(b"openssh-key-v1\0")
            and private[19:19 + struct.unpack(">I", private[15:19])[0]] == b"none",
            "Private key is not the expected unencrypted OpenSSH form")
    decoded = subprocess.run(["ssh-keygen", "-y", "-f", str(key)], stdin=subprocess.DEVNULL,
                             capture_output=True, timeout=10, check=True).stdout
    public = (STAGE / "ssh-key.pub").read_bytes()
    require(decoded.split()[:2] == public.split()[:2], "Actual OpenSSH key pair differs")
    require(digest(STAGE / "ssh-key.pub") == read(STAGE / "key-control.json")["public_sha256"],
            "Public key receipt differs")
    require(not (STAGE / "vast-rental.json").exists(), "Unexpected lease receipt")
    require(digest(manifest_path) == MANIFEST_SHA, "Manifest changed during the review")
    value = {"status": "passed_independent_offline_frozen_stage_review",
             "stage_id": protocol["stage_id"], "launch_manifest_sha256": MANIFEST_SHA,
             "manifested_inputs": 57, "input_drifts": 0, "private_runner_sha256": RUNNER_SHA,
             "independent_runner_review_sha256": REVIEW_SHA,
             "actual_controller_freeze_check": "passed", "canonical_contract": "matched",
             "source_and_input_resource_helpers_byte_identical_f15": True,
             "source_commit": protocol["source_commit"], "local_stage_tests_passed": len(cases),
             "actual_owner_only_protected_key_dacl": "passed",
             "actual_openssh_private_public_pair": "passed", "key_payload_emitted": False,
             "financial_cap_usd": 5.6, "maximum_seconds": 9000,
             "remaining_conservative_task_budget_usd": expected_remaining,
             "network_or_cloud_calls": 0, "lease_started": False,
             "authorization": "independent offline readiness PASS; parent owns exact rental authorization",
             "remaining_gates": ["fresh exact full quote immediately before allocation",
                                 "exact owned identity, retention and cleanup"]}
    require(digest(STAGE / "runtime_stack.py") == "875cb67d59076e037c6a595179bba2cf2f7f1f6b14fa17bef341af06ea0b0da3", "Runtime helper mismatch")
    require(digest(STAGE / "cpu-overlap-cuda13-independent-review.json") == "70d11ff97b39a0eab02d3043e70e8bdfa359e9bb56faf4280cdbe147b08555b6", "Runtime review mismatch")
    for item in STAGE.glob("*cuda13*xml"):
        extra = ET.parse(item).findall(".//testcase")
        require(len(extra) == 18 and not any(case.find(tag) is not None for case in extra for tag in ("failure", "error", "skipped")), "Independent runtime controls failed")
        value["independent_runtime_tests_passed"] = len(extra)
    require(value.get("independent_runtime_tests_passed") == 18, "Missing independent runtime controls")
    quote = read(STAGE / "fresh-quote.json")
    import cloud

    recomputed_quote = cloud.quote(quote["offer"], seconds=9000, prior_usd=0.,
                                   download_gb=90., upload_gb=2., volume_offer=quote["volume"],
                                   volume_gb=112)
    require(recomputed_quote == quote["quote"], "Independent pure quote differs")
    require(quote["offer"]["id"] == 56771475 and quote["volume"]["id"] == 56801565
            and quote["offer"]["machine_id"] == quote["volume"]["machine_id"] == 122165,
            "Exact quoted machine/instance/volume offer differs")
    total = recomputed_quote["total_stage_admission_usd"]
    require(quote["read_only"] is True and quote["rental_started"] is False
            and quote["within_credit_cap_and_budget"] is True
            and quote["all_old_owned_pairs_absent"] is True
            and total <= 5.6 <= expected_remaining
            and total <= quote["account_credit_usd"],
            "Quote exceeds the authorized budget or prior ownership evidence differs")
    value["additional_user_authorized_usd"] = 3.
    value["fresh_quote_file_sha256"] = digest(STAGE / "fresh-quote.json")
    value["independently_recomputed_full_quote_usd"] = total
    value["retained_quote_credit_usd"] = quote["account_credit_usd"]
    value["quoted_machine_id"] = 122165
    value["quoted_offer_id"] = 56771475
    value["quoted_volume_ask_id"] = 56801565
    value["quote_scope"] = "Retained fresh read-only receipt; allocator must still revalidate live"
    target = PREP / "cpu-overlap-b-independent-freeze-review.json"
    value["success_auditor_sha256"] = digest(PREP / "audit_cpu_overlap.py")
    auditor_spec = importlib.util.spec_from_file_location("final_b_success_auditor", PREP / "audit_cpu_overlap.py")
    auditor = importlib.util.module_from_spec(auditor_spec)
    auditor_spec.loader.exec_module(auditor)
    require(auditor.cohort_spec("b")["launch_manifest_sha256"] == MANIFEST_SHA, "B posthoc registry not pinned")
    value["success_auditor_b_registry_pinned_before_gpu_data"] = True
    value["actual_gpu_runtime_proof"] = "not yet available; mandatory before checkpoint download"
    target.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
    Console().print({"status": value["status"], "drifts": 0, "key_control": "passed",
                     "review_sha256": digest(target)})


if __name__ == "__main__":
    main()


