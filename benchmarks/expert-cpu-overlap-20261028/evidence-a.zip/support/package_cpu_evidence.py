"""Package audited CPU-overlap evidence without cloud, Git, or publication actions.

Large tensor captures, model files and traces remain locally retained and are
explicitly hash-indexed. A packet is evidence transport, never a scientific gate.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import zipfile
from pathlib import Path
from typing import Any

SOURCE = "43cf0b34afe0d8850d76bf86d60663ab5c85cdb2"
MAX_ZIP = 5000 * 1024
MAX_PUBLIC_FILE = 1024 * 1024
PREP = Path(__file__).parent
SKIP_ROOT = {
    "ssh-key", "ssh-key.pub", "ssh-key-attach.json", "cleanup.lock", "upload-probe.bin",
    "result.lossless.tar", "retention-probe.lossless.tar", "source.tar.gz",
}
PRIVATE_FIELDS = {
    "api_key", "apikey", "container_api_key", "authorization", "password",
    "access_token", "refresh_token", "hf_token", "private_key", "jupyter_token",
}


def require(value: Any, message: str) -> None:
    if not value:
        raise ValueError(message)


def read(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def encode(value: Any) -> bytes:
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 2**20), b""):
            digest.update(block)
    return digest.hexdigest()


def contained(root: Path, name: str) -> Path:
    base = os.path.realpath(root)
    path = Path(os.path.realpath(os.path.join(base, name)))
    require(os.path.normcase(os.path.commonpath((base, path))) == os.path.normcase(base),
            "Evidence escapes retained root")
    require(path.is_file() and not (root / name).is_symlink(), "Nonordinary evidence file")
    return path


def privacy(raw: bytes, secrets: tuple[bytes, ...]) -> None:
    require(not any(value and value in raw for value in secrets),
            "Exact private credential appears in publication input")
    require(re.search(rb"-----BEGIN [A-Z ]*PRIVATE KEY-----", raw) is None,
            "Private key appears in publication input")
    try:
        parsed = json.loads(raw)
    except (ValueError, UnicodeDecodeError):
        return

    def visit(value: Any) -> None:
        if isinstance(value, dict):
            for key, child in value.items():
                if str(key).lower() in PRIVATE_FIELDS:
                    readiness_text = (str(key).lower() == "authorization" and child ==
                                      "independent offline readiness PASS; "
                                      "parent owns exact rental authorization")
                    require(readiness_text or child in (None, "", "[redacted]", "REDACTED"),
                            "Nonempty credential field in publication JSON")
                visit(child)
        elif isinstance(value, list):
            for child in value:
                visit(child)

    visit(parsed)


def verify_stage(stage: Path, audit_path: Path) -> tuple[dict, dict]:
    audit = read(audit_path)
    require(audit["source_commit"] == SOURCE, "Unexpected source commit")
    expected = {
        "passed_independent_cpu_overlap_audit": "audit_cpu_overlap.py",
        "passed_independent_failed_preflight_retention_cleanup_audit":
            "audit_failed_cpu_preflight.py",
    }
    require(audit["status"] in expected, "Independent audit has not passed")
    script = PREP / expected_auditor(audit)
    require(sha(script) == audit["audit_script_sha256"], "Independent auditor changed")
    for name, field in (
        ("archive-manifest.json", "archive_manifest_sha256"),
        ("bundle-verified.json", "bundle_verified_sha256"),
        ("launch-manifest.json", "launch_manifest_sha256"),
    ):
        require(sha(stage / name) == audit[field], "Audit is bound to different evidence")
    require(audit["cleanup"]["verified_absent"] is True
            and audit["cleanup"]["instance_verified_absent"] is True
            and audit["cleanup"]["volume_verified_absent"] is True,
            "Exact owned resources are not confirmed absent")
    archive = read(stage / "archive-manifest.json")
    require(sha(stage / "result.lossless.tar") == archive["sha256"],
            "Full retained lossless archive differs")
    for name, row in archive["files"].items():
        path = contained(stage / "retained", name)
        require(path.stat().st_size == row["bytes"] and sha(path) == row["sha256"],
                "Retained original differs")
    return audit, archive


def package(stage: Path, audit_path: Path, out: Path, secrets: tuple[bytes, ...]) -> dict:
    audit, archive = verify_stage(stage, audit_path)
    require(not out.exists(), "Output already exists; preserve previous packet")
    out.mkdir(parents=True)
    entries: dict[str, bytes] = {}
    index: dict[str, Any] = {"schema_version": 1, "source_commit": SOURCE,
                             "stage_id": audit["stage_id"], "files": {}}

    def add(name: str, path: Path, *, force: bool = False) -> None:
        require(name not in index["files"], "Duplicate logical evidence name")
        row = {"bytes": path.stat().st_size, "sha256": sha(path),
               "retained_local_path": str(path)}
        tensor = path.suffix.lower() in {".pt", ".pth", ".safetensors", ".bin"}
        if force or (row["bytes"] <= MAX_PUBLIC_FILE and not tensor):
            raw = path.read_bytes()
            privacy(raw, secrets)
            entries[name] = raw
            row["publication"] = "exact_original_in_packet"
        else:
            row["publication"] = "hash_index_only_full_original_retained_locally"
        index["files"][name] = row

    for name in sorted(archive["files"]):
        add("retained/" + name, contained(stage / "retained", name))
    for path in sorted(stage.iterdir()):
        if path.is_file() and path.name not in SKIP_ROOT:
            incident = path.name.startswith("operation-latest-observed-")
            add("operator/" + path.name, path, force=incident and path.stat().st_size < 4096)
    for name in ("source.tar.gz", "result.lossless.tar"):
        path = contained(stage, name)
        index["files"]["local-only/" + name] = {
            "bytes": path.stat().st_size, "sha256": sha(path),
            "retained_local_path": str(path),
            "publication": "hash_index_only_full_original_retained_locally",
        }
    add("audit/independent-audit.json", audit_path, force=True)
    add("audit/" + (PREP / expected_auditor(audit)).name,
        PREP / expected_auditor(audit), force=True)
    for path in sorted(PREP.glob("*.py")):
        add("support/" + path.name, path)
    for path in sorted(PREP.glob("*.xml")):
        add("support/" + path.name, path)
    for path in sorted((PREP / "audit-versions").rglob("*")):
        if path.is_file() and path.suffix in {".py", ".json", ".xml"}:
            name = os.path.relpath(path, PREP).replace("\\", "/")
            add("support/" + name, path)
    for path in sorted((PREP / "local-incidents").glob("*")):
        if path.is_file():
            add("support/local-incidents/" + path.name, path,
                force=path.stat().st_size < 4096)
    for name in ("protocol-contract.json", "source-checks.json", "cuda13-stack-metadata.json",
                 "cuda13-transitive-metadata.json", "audit-cpu-overlap-mutations.json",
                 "cpu-overlap-independent-review.json", "audit-cuda13-fixture.json",
                 "cuda13-runtime-wheel-lock.json", "cpu-overlap-b-independent-freeze-review.json",
                 "cpu-overlap-cuda13-independent-review.json",
                 "cpu-overlap-actual-boundary-compatibility.json",
                 "pipfreeze-v2-parser-review.json",
                 "cpu-overlap-b-independent-audit-a0-failed-preserved.json",
                 "pipfreeze-v2-exact.diff"):
        if (PREP / name).is_file():
            add("support/" + name, PREP / name)
    entries["evidence-index.json"] = encode(index)
    privacy(entries["evidence-index.json"], secrets)
    packet = out / "evidence.zip"
    canonical: dict[tuple[int, str], tuple[str, bytes]] = {}
    aliases: dict[str, str] = {}
    with zipfile.ZipFile(packet, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
        for name, raw in entries.items():
            fingerprint = len(raw), hashlib.sha256(raw).hexdigest()
            if fingerprint in canonical:
                member, original = canonical[fingerprint]
                require(raw == original, "Hash alias differs in complete bytes")
            else:
                member = name
                canonical[fingerprint] = (name, raw)
                info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                zipped.writestr(info, raw, compresslevel=9)
            aliases[name] = member
        zipped.writestr("aliases.json", encode(aliases))
    require(packet.stat().st_size <= MAX_ZIP, "Packet exceeds repository file-size gate")
    with zipfile.ZipFile(packet) as zipped:
        require(len(zipped.namelist()) == len(set(zipped.namelist())), "Duplicate ZIP members")
        require(json.loads(zipped.read("aliases.json")) == aliases, "Alias manifest differs")
        for name, raw in entries.items():
            restored = zipped.read(aliases[name])
            require(restored == raw, "Restored logical original differs in complete bytes")
            privacy(restored, secrets)
    summary = {"status": "verified_exact_byte_publication_packet",
               "scientific_status": audit.get("scientific_status", audit["speed_verdict"]
                                               if "speed_verdict" in audit else audit["status"]),
               "stage_id": audit["stage_id"], "source_commit": SOURCE,
               "audit_sha256": sha(audit_path), "bytes": packet.stat().st_size,
               "sha256": sha(packet), "logical_public_files": len(entries),
               "stored_members": len(canonical), "retained_originals": len(archive["files"]),
               "all_raw_files_byte_and_sha_verified": True,
               "all_public_aliases_restored_and_byte_compared": True,
               "exact_api_and_private_key_material_scan_passed": True,
               "omission_policy": "All raw originals retained locally; large tensors/model/trace "
                                  "files explicitly hash-indexed, not silently dropped."}
    (out / "evidence-index.json").write_bytes(encode(index))
    (out / "packet-verification.json").write_bytes(encode(summary))
    return summary


def expected_auditor(audit: dict) -> str:
    if audit["status"] != "passed_independent_cpu_overlap_audit":
        return "audit_failed_cpu_preflight.py"
    name = audit.get("audit_script_filename", "audit_cpu_overlap.py")
    require(name in {"audit_cpu_overlap.py", "audit_cpu_overlap_pipfreeze_v2.py"},
            "Unexpected independent auditor filename")
    if name == "audit_cpu_overlap_pipfreeze_v2.py":
        require(audit.get("pre_data_auditor_sha256") ==
                "a0b434b3b7f894bcaf07af3b4cfa36e8208d91de090118cd241ed4866e63b54c",
                "Parser correction lost the immutable pre-data auditor binding")
    return name


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", type=Path, required=True)
    parser.add_argument("--audit", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    key_path = Path(os.environ["USERPROFILE"]) / ".config/vastai/vast_api_key"
    secrets = (key_path.read_bytes().strip(), (args.stage / "ssh-key").read_bytes().strip())
    result = package(args.stage, args.audit, args.out, secrets)
    from rich.console import Console

    Console().print(result)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
