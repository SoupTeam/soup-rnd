"""Apply explicit extra USD3 to an unpaid stage; preserve the previous frozen evidence."""

import hashlib
import json
import time
from pathlib import Path

from rich.console import Console

PREP = Path(__file__).parent
STAGE = PREP.parent / "expert-cpu-overlap-gpu-20261028-a"
OLD_MANIFEST = "1cce9592475fdc2b911dfcc97adcdba1c6ff2f3bc0dd344320408f5af44c2f84"


def main():
    assert not (STAGE / "vast-rental.json").exists()
    assert not (STAGE / "lease-greenlight.json").exists()
    assert hashlib.sha256((STAGE / "launch-manifest.json").read_bytes()).hexdigest() == OLD_MANIFEST
    assert hashlib.sha256((STAGE / "cpu_overlap_probe.py").read_bytes()).hexdigest() == (
        "f4eabf7867a0908249a78e83054d6f5e139afe54f4d8eca93cc38eeb031726b3")
    snapshot = PREP / "pre-extra3-offline-freeze"
    snapshot.mkdir(exist_ok=False)
    rows = {}
    for name in ("launch-manifest.json", "offline-freeze-verification.json", "cloud.py",
                 "protocol.json", "launch_safety.py", "prior-budget-context.json",
                 "test_operator_safety.py", "operator-tests.xml", "WORKPLAN.md"):
        data = (STAGE / name).read_bytes()
        (snapshot / name).write_bytes(data)
        rows[name] = {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
    change = {"unix": time.time(), "explicit_user_approval": "Добавить $3 и проверить на GPU",
              "old_manifest_sha256": OLD_MANIFEST, "old_remaining_usd": 3.1857075442141882,
              "additional_authorized_usd": 3., "new_remaining_usd": 6.1857075442141882,
              "old_stage_cap_usd": 3., "new_stage_cap_usd": 6., "maximum_seconds": 10800,
              "preserved_files": rows, "old_frozen_unmodified_inputs_available_by_same_hash": True,
              "paid_lease_exists": False, "does_not_authorize_automatic_group_account_topup": True}
    (snapshot / "authorization-provenance.json").write_text(json.dumps(change, indent=2) + "\n")
    path = STAGE / "cloud.py"
    text = path.read_text().replace("USD3 subcap within USD3.1857075442141882",
                                   "USD6 subcap within USD6.1857075442141882")
    assert "MAXIMUM_USD = 3.0" in text
    path.write_text(text.replace("MAXIMUM_USD = 3.0", "MAXIMUM_USD = 6.0"))
    path = STAGE / "protocol.json"
    protocol = json.loads(path.read_text())
    protocol["financial"]["maximum_stage_usd"] = 6.
    path.write_text(json.dumps(protocol, indent=2) + "\n")
    path = STAGE / "launch_safety.py"
    text = path.read_text()
    assert "'financial': {'maximum_stage_usd': 3.0," in text
    path.write_text(text.replace("'financial': {'maximum_stage_usd': 3.0,",
                                "'financial': {'maximum_stage_usd': 6.0,"))
    path = STAGE / "prior-budget-context.json"
    context = json.loads(path.read_text())
    context["cpu_overlap_pre_extra_remaining_usd"] = context[
        "aggregate_remaining_before_cpu_overlap_usd"]
    context["cpu_overlap_additional_authorized_usd"] = 3.
    context["aggregate_remaining_before_cpu_overlap_usd"] = 6.1857075442141882
    context["new_stage_cap_usd"] = 6.
    context["semantics"] += (
        " 2026-10-28 human explicitly approved extraUSD3 for GPU check. New study cap6USD "
        "within remaining6.1857075442141882; same3h/90GB+2GB/reserves. Account credit must "
        "be checked independently; authorization is not a group-account balance topup.")
    path.write_text(json.dumps(context, indent=2) + "\n")
    path = STAGE / "test_operator_safety.py"
    text = path.read_text().replace('{"maximum_stage_usd": 3., "prior_usd": 0,',
                                   '{"maximum_stage_usd": 6., "prior_usd": 0,')
    text = text.replace('result["maximum_stage_usd"] == 3.', 'result["maximum_stage_usd"] == 6.')
    text = text.replace('- row["completed_f15_cost_usd"],',
                        '- row["completed_f15_cost_usd"] + row["cpu_overlap_additional_authorized_usd"],')
    text = text.replace('row["new_stage_cap_usd"] == 3.', 'row["new_stage_cap_usd"] == 6.')
    path.write_text(text)
    path = STAGE / "WORKPLAN.md"
    text = path.read_text().replace("New cap3USD/3h", "New cap6USD/3h")
    text = text.replace("remaining3.1857075442141882USD", "remaining6.1857075442141882USD")
    path.write_text(text + "\nExplicit extraUSD3 authorization does not authorize a rental without "
                    "the final root greenlight, fresh exact quote and sufficient actual account credit.\n")
    old = json.loads((snapshot / "protocol.json").read_text())
    for field in protocol:
        if field != "financial":
            assert protocol[field] == old[field], field
    Console().print({"financial_only_update": True, "extra_authorized_usd": 3.,
                     "stage_cap_usd": 6., "remaining_usd": 6.1857075442141882,
                     "old_freeze_preserved": str(snapshot), "rental_started": False})


if __name__ == "__main__":
    main()
