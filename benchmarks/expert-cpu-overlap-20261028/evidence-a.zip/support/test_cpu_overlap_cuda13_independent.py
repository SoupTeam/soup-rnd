"""Independent software-cohort admission controls using fake modules, never a GPU."""

from __future__ import annotations

import base64
import importlib.util
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

ROOT = Path(__file__).parent
SPEC = importlib.util.spec_from_file_location(
    "independent_runtime_stack", ROOT / "runtime_stack.py"
)
STACK = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(STACK)
FIXTURE = json.loads((ROOT / "audit-cuda13-fixture.json").read_text())
COHORT = json.loads(base64.b64decode(FIXTURE["software-cohort.json"]))


def modules(tmp_path):
    package = tmp_path / "venv/bitsandbytes"
    package.mkdir(parents=True)
    library = package / "libbitsandbytes_cuda130.so"
    library.write_bytes(b"synthetic native-library path control; never dlopen")
    torch = SimpleNamespace(
        __version__="2.10.0+cu130",
        __file__=str(tmp_path / "venv/torch/__init__.py"),
        version=SimpleNamespace(cuda="13.0"),
        cuda=SimpleNamespace(is_available=lambda: True, device_count=lambda: 1),
    )
    extension = SimpleNamespace(
        lib=SimpleNamespace(compiled_with_cuda=True, _lib=SimpleNamespace(_name=str(library)))
    )
    bnb = SimpleNamespace(
        __version__="0.50.2", __file__=str(package / "__init__.py"), cextension=extension
    )
    return torch, bnb, extension


def test_exact_coupled_versions_accept_and_reject_foreign_cuda_override(monkeypatch):
    monkeypatch.delenv("BNB_CUDA_VERSION", raising=False)
    STACK.validate_versions(
        COHORT, dict(COHORT["required_versions"]), list(COHORT["required_versions"])
    )
    monkeypatch.setenv("BNB_CUDA_VERSION", "128")
    with pytest.raises(RuntimeError, match="override"):
        STACK.validate_versions(COHORT, dict(COHORT["required_versions"]), [])


@pytest.mark.parametrize("mutation", ["torch", "triton", "cupti", "missing", "cuda12_package"])
def test_all_twenty_coupled_versions_must_match_without_cuda12_packages(mutation, monkeypatch):
    monkeypatch.delenv("BNB_CUDA_VERSION", raising=False)
    actual, installed = dict(COHORT["required_versions"]), list(COHORT["required_versions"])
    if mutation == "missing":
        actual.pop("nvidia-nvjitlink")
    elif mutation == "cuda12_package":
        installed.append("nvidia-cuda-cupti-cu12")
    else:
        actual[{"torch": "torch", "triton": "triton", "cupti": "nvidia-cuda-cupti"}[mutation]] = (
            "old"
        )
    with pytest.raises(RuntimeError):
        STACK.validate_versions(COHORT, actual, installed)


def test_loaded_backend_records_actual_contained_cuda130_file_and_hash(tmp_path):
    torch, bnb, extension = modules(tmp_path)
    result = STACK.validate_loaded(COHORT, torch, bnb, extension)
    assert result["torch_cuda_version"] == "13.0"
    assert result["cuda_visible_device_count"] == 1
    assert result["bitsandbytes_actual_library_sha256"] == STACK.digest(
        Path(extension.lib._lib._name)
    )


@pytest.mark.parametrize(
    "mutation",
    [
        "torch",
        "cuda",
        "unavailable",
        "two_devices",
        "bnb",
        "cpu_fallback",
        "wrong_library",
        "foreign_library",
        "no_path",
    ],
)
def test_loaded_backend_cannot_be_an_old_or_foreign_or_cpu_fallback(tmp_path, mutation):
    torch, bnb, extension = modules(tmp_path)
    if mutation == "torch":
        torch.__version__ = "2.8.0+cu128"
    elif mutation == "cuda":
        torch.version.cuda = "12.8"
    elif mutation == "unavailable":
        torch.cuda.is_available = lambda: False
    elif mutation == "two_devices":
        torch.cuda.device_count = lambda: 2
    elif mutation == "bnb":
        bnb.__version__ = "0.49.2"
    elif mutation == "cpu_fallback":
        extension.lib.compiled_with_cuda = False
    elif mutation in ("wrong_library", "foreign_library"):
        new = tmp_path / (
            "libbitsandbytes_cuda130.so"
            if mutation == "foreign_library"
            else "venv/bitsandbytes/libbitsandbytes_cuda128.so"
        )
        new.write_bytes(b"foreign fake library")
        extension.lib._lib._name = str(new)
    else:
        extension.lib._lib._name = None
    with pytest.raises(RuntimeError):
        STACK.validate_loaded(COHORT, torch, bnb, extension)


@pytest.mark.parametrize("fail", [False, True])
def test_main_preserves_atomic_admission_or_failure_without_real_binary_import(
    tmp_path, monkeypatch, fail
):
    monkeypatch.delenv("BNB_CUDA_VERSION", raising=False)
    torch, bnb, _extension = modules(tmp_path)
    monkeypatch.setitem(sys.modules, "torch", torch)
    monkeypatch.setitem(sys.modules, "bitsandbytes", bnb)
    versions = dict(COHORT["required_versions"])
    if fail:
        versions["nvidia-cuda-cupti"] = "12.8.90"
    monkeypatch.setattr(STACK.metadata, "version", lambda name: versions[name])
    monkeypatch.setattr(
        STACK.metadata,
        "distributions",
        lambda: [SimpleNamespace(metadata={"Name": name}) for name in versions],
    )
    cohort, lock, out = tmp_path / "cohort.json", tmp_path / "lock.json", tmp_path / "proof.json"
    cohort.write_bytes(base64.b64decode(FIXTURE["software-cohort.json"]))
    lock.write_bytes(base64.b64decode(FIXTURE["runtime-wheel-lock.json"]))
    assert STACK.main(
        ["--cohort", str(cohort), "--wheel-lock", str(lock), "--out", str(out)]
    ) == int(fail)
    proof = json.loads(out.read_text())
    assert proof["status"] == ("failed" if fail else "passed_runtime_stack_admission")
    assert proof["helper_sha256"] == STACK.digest(ROOT / "runtime_stack.py")
    assert proof["cohort_sha256"] == STACK.digest(cohort)
    assert proof["wheel_lock_sha256"] == STACK.digest(lock)
    assert proof["unix_started"] <= proof["unix_completed"]
    assert not out.with_suffix(".json.incoming").exists()
