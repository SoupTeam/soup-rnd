"""Explain known-host unavailability without allocating anything."""

from __future__ import annotations

import json
import time

from rich.console import Console

from provider_readonly import BASE, cloud, read_api


def main() -> None:
    query = dict(cloud.QUERY, machine_id={"eq": 122165}, disk_space={"gte": 32}, limit=100)
    query.pop("rented", None)
    query.pop("cpu_ram", None)
    offers = read_api("/api/v0/bundles/", query)["offers"]
    (BASE / "known-host-readonly.json").write_text(json.dumps({
        "unix": time.time(), "read_only": True, "rental_started": False,
        "query": query, "offers": offers}, indent=2) + "\n")
    Console().print([{key: row.get(key) for key in (
        "id", "machine_id", "rented", "rentable", "disk_space", "gpu_name", "cpu_ram",
        "dph_total", "inet_down_cost")} for row in offers])


if __name__ == "__main__":
    main()
