"""Freeze the independent offline review after its controls have passed."""

from __future__ import annotations

import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

from rich.console import Console

PREP = Path(__file__).parent
REPO = Path(r"C:\Users\esenb\.codex\worktrees\expert-dispatch-opt-20261026\soup-rnd-d2")
COMMIT = "43cf0b34afe0d8850d76bf86d60663ab5c85cdb2"


def fingerprint(path):
    return {"bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def main():
    actual = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO, text=True).strip()
    dirty = subprocess.check_output(["git", "status", "--porcelain", "--untracked-files=no"],
                                    cwd=REPO, text=True).strip()
    if actual != COMMIT or dirty:
        raise ValueError("Production source changed")
    root = ET.parse(PREP / "cpu-overlap-independent.xml").getroot()
    cases = root.findall(".//testcase")
    if len(cases) != 80 or any(case.find(tag) is not None
                               for case in cases for tag in ("failure", "error", "skipped")):
        raise ValueError("All eighty independent controls must pass without skips")
    combined = ET.parse(PREP / "cpu-overlap-independent-combined.xml").getroot()
    combined_cases = combined.findall(".//testcase")
    if len(combined_cases) != 85 or any(case.find(tag) is not None
                                       for case in combined_cases
                                       for tag in ("failure", "error", "skipped")):
        raise ValueError("All eighty-five combined behavioral controls must pass")
    compatibility = json.loads(
        (PREP / "cpu-overlap-actual-boundary-compatibility.json").read_text())
    runner = fingerprint(PREP / "cpu_overlap_probe.py")
    if compatibility["runner_sha256"] != runner["sha256"]:
        raise ValueError("Compatibility proof belongs to another runner version")
    contract = json.loads((PREP / "protocol-contract.json").read_text())
    if contract["profile"]["skip_fetches"] != 1024 or contract["profile"]["fetches"] != 16:
        raise ValueError("Final pre-data window contract differs")
    value = {
        "schema_version": 1,
        "status": "passed_independent_offline_runner_design_review",
        "source_commit": actual,
        "production_tracked_source_clean": True,
        "private_files": {name: fingerprint(PREP / name) for name in (
            "cpu_overlap_probe.py", "profile_timeline.py", "protocol-contract.json",
            "test_cpu_overlap_independent.py", "cpu-overlap-independent.xml",
            "test_cpu_overlap_runtime.py", "cpu-overlap-independent-combined.xml",
            "check_boundary_compatibility.py", "cpu-overlap-actual-boundary-compatibility.json")},
        "independent_cpu_controls": {"passed": len(cases), "failed": 0, "skipped": 0,
                                     "combined_with_five_behavioral_runtime_controls": 85,
                                     "ruff_E_F_I_N_W_line_length_100": "passed",
                                     "ruff_known_first_party": ["benchmarks", "soup_cli",
                                         "cpu_overlap_probe", "profile_timeline",
                                         "provider_readonly"]},
        "actual_retained_schema_controls": {
            "f15_real_workers_accepted": 11, "f14_actual_swap_failure_rejected": True,
            "scope": "prior raw metadata compatibility; no new numerical or speed evidence"},
        "reviewed_design": {
            "baseline": "grouped routes plus two-read plus static RAM8GiB/GPU2GiB caches",
            "policies": contract["policies"],
            "thread_override": "after identical native build, admission and LoRA initialization",
            "recorded_scheduling": "actual intra/inter-op, affinity, env and CPU count",
            "full_accuracy": "five policies, two AdamW updates/four micros each versus native",
            "accuracy_gates": "unchanged RTOL.01/ATOL1e-5, finite, exact inputs, 3-decimal loss",
            "selection": "fixed exploratory order, warm2/timed6; distinct actual count only",
            "duplicate_native_count": "retained control, never eligible as a new winner",
            "confirmation": "fresh independent four AB/BA pairs, warm2/timed6, original 2% CI gate",
            "no_positive_exploration": "NO_CONFIRMED_WIN; not proof of zero effect",
            "profile": "pre-data skip1024, sixteen actual forward expert-fetch calls",
            "profile_presence": "actual CUDA kernels and H2D plus lossless bounded trace",
            "profile_path": "cache snapshots identify tiers; skip index alone does not",
            "profile_parser": "contained actual file, frozen size/SHA checked before/after import",
            "resources": "physical8GB/native28..32GiB, unchanged no-swap and allocator gates",
            "retention": "complete original worker, capture, timing, trace and failure evidence",
            "production_feature": "none implemented by this study"},
        "limitations": [
            "No new GPU execution has occurred in this independent review.",
            "This review confers neither allocation permission nor successful GPU qualification.",
            "Operator manifest, quote, budget, identity and cleanup remain separate gates.",
            "Forward window includes expert work and cannot prove full-step/backward causality.",
            "Overlapping diagnostic profiler durations are not additive speed estimates.",
            "Short random-token trajectory parity does not establish task quality or convergence.",
            "Actual data require independent raw/numerical/infrastructure audits after cleanup."],
        "mutations_performed_by_reviewer": "local controls only; no cloud/Git/production changes",
    }
    target = PREP / "cpu-overlap-independent-review.json"
    target.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
    Console().print({"status": value["status"], "runner_sha256": runner["sha256"],
                     "review_sha256": fingerprint(target)["sha256"]})


if __name__ == "__main__":
    main()
