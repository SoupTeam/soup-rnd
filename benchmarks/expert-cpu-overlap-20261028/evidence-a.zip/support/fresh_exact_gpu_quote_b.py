"""Read-only exact CPU-overlap offer/volume/credit/history admission evidence."""

import json
import math
import sys
import time
from pathlib import Path

PREP = Path(__file__).parent
BASE = PREP.parent
STAGE = BASE / "expert-cpu-overlap-gpu-20261028-b"
sys.path[:0] = [str(STAGE), str(STAGE / ".deps")]

import cloud  # noqa: E402
from rich.console import Console  # noqa: E402


def main():
    assert not (STAGE / "vast-rental.json").exists()
    assert not (STAGE / "lease-greenlight.json").exists()
    query = dict(cloud.QUERY, machine_id={"eq": 122165}, limit=500)
    reply = cloud.api("/api/v0/bundles/", "POST", query)
    candidates = [row for row in reply["offers"] if cloud.resource_id(row["id"]) == 56771475]
    if len(candidates) != 1:
        raise ValueError("Fresh exact GPU ask unavailable; no rental or blind retry")
    offer = candidates[0]
    cloud.validate_full_host(offer)
    assert offer["machine_id"] == 122165 and offer["gpu_name"] == "RTX 4060 Ti"
    volumes = [row for row in cloud.volume_offers(122165)
               if cloud.resource_id(row["id"]) == 56801565]
    if len(volumes) != 1:
        raise ValueError("Fresh exact local-volume ask unavailable; do not allocate")
    volume = volumes[0]
    quote = cloud.quote(offer, seconds=9000, download_gb=90., upload_gb=2., volume_offer=volume)
    credit = float(cloud.api("/api/v0/users/current/")["credit"])
    assert math.isfinite(credit) and credit >= 0
    instances, owned_volumes = cloud.rows(), cloud.volume_rows()
    history = {}
    for directory in sorted(BASE.glob("kanana-30b-*-gpu-20261026-f*")):
        path = directory / "vast-rental.json"
        if path.is_file():
            row = json.loads(path.read_text())
            if row.get("instance_id") is not None or row.get("volume_id") is not None:
                history[directory.name] = {name: row.get(name) for name in (
                    "stage_id", "label", "instance_id", "volume_id")}
    prior_a = BASE / 'expert-cpu-overlap-gpu-20261028-a/vast-rental.json'
    a_receipt = json.loads(prior_a.read_text())
    history['expert-cpu-overlap-gpu-20261028-a'] = {name: a_receipt.get(name) for name in (
        'stage_id', 'label', 'instance_id', 'volume_id')}
    old_instances = {cloud.resource_id(row["instance_id"]) for row in history.values()
                     if row.get("instance_id") is not None}
    old_volumes = {cloud.resource_id(row["volume_id"]) for row in history.values()
                   if row.get("volume_id") is not None}
    absent = not any(cloud.resource_id(row["id"]) in old_instances
                     or row.get("label") == cloud.LABEL for row in instances)
    absent = absent and not any(cloud.resource_id(row["id"]) in old_volumes
                               for row in owned_volumes)
    context = json.loads((STAGE / "prior-budget-context.json").read_text())
    remaining = (context["cpu_overlap_pre_extra_remaining_usd"]
                 + context["cpu_overlap_additional_authorized_usd"]
                 - context["failed_cpu_overlap_a_cost_usd"])
    assert math.isclose(remaining, 5.678490342737433, abs_tol=1e-12)
    assert context["new_stage_cap_usd"] == cloud.MAXIMUM_USD == 5.60
    price = quote["total_stage_admission_usd"]
    fits = price <= min(5.60, remaining, credit)
    metadata = {key: value for key, value in offer.items() if key.startswith((
        "cpu", "gpu", "cuda", "driver", "disk", "pci", "mobo", "motherboard", "ram"))
        or key in ("machine_id", "host_id", "hostname", "num_gpus", "geolocation",
                   "reliability", "verification", "os_version")}
    row = {"unix": time.time(), "read_only": True, "query": query, "offer": offer,
           "volume": volume, "quote": quote, "account_credit_usd": credit,
           "remaining_task_usd": remaining, "within_credit_cap_and_budget": fits,
           "complete_cpu_gpu_host_metadata": metadata,
           "old_owned_pairs_checked": history, "all_old_owned_pairs_absent": absent,
           "unrelated_instance_ids_excluded": [item["id"] for item in instances],
           "unrelated_volume_ids_excluded": [item["id"] for item in owned_volumes],
           "source_of_original_selection": "stageB/alternatives-readonly.json",
           "new_gpu_requires_own_baseline_and_all_actual_cuda_gates": True,
           "rental_started": False}
    cloud.save("fresh-quote.json", row)
    if not absent:
        raise ValueError("An exact historic owned resource or duplicate stage label is still present")
    if not fits:
        raise ValueError("Exact quote exceeds stage cap, task remaining or actual group-account credit")
    fields = ("cpu_name", "cpu_arch", "cpu_cores", "cpu_cores_effective", "cpu_ram",
              "cpu_ghz", "mobo_name", "gpu_name", "gpu_ram", "num_gpus", "gpu_frac",
              "cuda_max_good", "compute_cap", "driver_version", "disk_space",
              "reliability", "verification", "geolocation")
    Console().print({"quote_usd": price, "stage_cap_usd": 5.60, "remaining_usd": remaining,
        "credit_usd": credit, "hourly_usd": quote["hourly_including_requested_disk_usd"],
        "exact_offer_id": offer["id"], "volume_ask_id": volume["id"],
        "metadata": {key: offer.get(key) for key in fields},
        "old_owned_pairs_checked": len(history), "all_old_owned_pairs_absent": absent,
        "rental_started": False})


if __name__ == "__main__":
    main()
