"""Independent post-retention CPU-thread/profile audit; no provider or GPU operations.

Replays numerical, cache, selection and confirmation evidence from originals.
The private runner's reported validation is not accepted as a scientific gate.
"""

from __future__ import annotations

import argparse
import functools
import gc
import hashlib
import importlib.util
import json
import math
import os
import random
import re
import statistics
import subprocess
import sys
import tarfile
import traceback
import zlib
from pathlib import Path, PurePosixPath
from typing import Any
from urllib.parse import unquote

SOURCE = "43cf0b34afe0d8850d76bf86d60663ab5c85cdb2"
STUDY = "soup-expert-cpu-overlap-20261028-a"
LAUNCH = "0f43e43aa544fdb902dd73845edec2b0afd913b4d165e5fa67d5a38518e5cedf"
RUNNER = "f4eabf7867a0908249a78e83054d6f5e139afe54f4d8eca93cc38eeb031726b3"
CONTRACT_SHA = "8a13e721571ea101d1e3aaac338ee5bf12f6d9d5ada47222a7e4f5945d4d96f5"
FOUNDATION = "6c2eed12596fd76e49bca74ba214d506032339138915d17e88195640bc783bf6"
NUMERIC = "15d64f4289d3763801d9a296bbd96a7482b9eb8073676a48a1a615e5e15f38d5"
TIMELINE = "16c3f1b55e9e5b7e7f20aad80d6c101a3b9bcc81091b4838e1d26cb21a72a9a6"
POLICIES = {"native": None, "t1": 1, "t2": 2, "t4": 4, "t8": 8}
EXPLORATION = ("t4", "native", "t8", "t2", "t1")
GIB, CHUNK = 2**30, 4 * 2**20
PREFIX = "results/cpu-overlap/"
COHORTS = {
    "a": {
        "stage_id": STUDY,
        "launch_manifest_sha256": LAUNCH,
        "maximum_stage_usd": 6.0,
        "maximum_seconds": 10800,
        "remaining_before_usd": 6.1857075442141882,
        "torch": "2.8.0+cu128",
        "torch_cuda": "12.8",
        "triton": "3.4.0",
    },
    "b": {
        "stage_id": "soup-expert-cpu-overlap-20261028-b",
        "launch_manifest_sha256": (
            "f2c4afa213b4af4b500ceec04c64071a59f3ac380a7d1ec1db6952657ba66884"
        ),
        "maximum_stage_usd": 5.6,
        "maximum_seconds": 9000,
        "remaining_before_usd": 5.678490342737433,
        "torch": "2.10.0+cu130",
        "torch_cuda": "13.0",
        "triton": "3.6.0",
    },
}


def require(value: Any, message: str) -> None:
    if not value:
        raise ValueError(message)


def finite(value: Any) -> bool:
    return type(value) in (int, float) and math.isfinite(value)


def sha(path: Path) -> str:
    result = hashlib.sha256()
    with path.open("rb") as source:
        for data in iter(lambda: source.read(8 * 2**20), b""):
            result.update(data)
    return result.hexdigest()


def read(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def cohort_spec(name: str) -> dict:
    require(name in COHORTS, "Unregistered runtime cohort")
    value = json.loads(json.dumps(COHORTS[name]))
    require(
        isinstance(value["launch_manifest_sha256"], str)
        and re.fullmatch("[0-9a-f]{64}", value["launch_manifest_sha256"]),
        "Runtime cohort is not frozen before data",
    )
    return value


def contained(root: Path, name: str) -> Path:
    part = PurePosixPath(name)
    require(
        isinstance(name, str)
        and name
        and "\\" not in name
        and ":" not in name
        and not part.is_absolute()
        and part.as_posix() == name
        and all(value not in ("", ".", "..") for value in name.split("/")),
        "Noncanonical original artifact path",
    )
    base, target = os.path.realpath(root), os.path.realpath(root / name)
    require(
        os.path.normcase(os.path.commonpath((base, target))) == os.path.normcase(base),
        "Artifact escaped its evidence root",
    )
    return Path(target)


def module(name: str, expected: str) -> Any:
    path = Path(__file__).with_name(name + ".py")
    require(sha(path) == expected, "Independent foundation changed: " + name)
    spec = importlib.util.spec_from_file_location("cpu_audit_" + name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def loss_gate(left: list[float], right: list[float]) -> None:
    require(
        left
        and len(left) == len(right)
        and all(
            finite(a)
            and finite(b)
            and abs(b - a) <= 1e-5 + 0.01 * abs(a)
            and f"{a:.3f}" == f"{b:.3f}"
            for a, b in zip(left, right)
        ),
        "Original finite/RTOL/ATOL/three-decimal scalar loss gate failed",
    )


def thread_control(control: dict, policy: str) -> dict:
    require(
        policy in POLICIES
        and control["applied_after_build"] is True
        and type(control["requested"]) is type(POLICIES[policy])
        and control["requested"] == POLICIES[policy],
        "Thread policy identity changed",
    )
    before, after = control["before"], control["after"]
    for point in (before, after):
        require(
            all(
                type(point[key]) is int and point[key] > 0
                for key in ("intraop", "interop", "cpu_count")
            ),
            "Invalid CPU thread getter",
        )
        require(
            isinstance(point["affinity"], list)
            and point["affinity"]
            and point["affinity"] == sorted(set(point["affinity"]))
            and all(type(value) is int and value >= 0 for value in point["affinity"]),
            "Actual Linux CPU affinity was not retained",
        )
        require(
            set(point["env"])
            == {
                "OMP_NUM_THREADS",
                "MKL_NUM_THREADS",
                "OPENBLAS_NUM_THREADS",
                "NUMEXPR_NUM_THREADS",
                "TOKENIZERS_PARALLELISM",
            },
            "CPU scheduling environment is incomplete",
        )
    require(
        after["intraop"]
        == (before["intraop"] if policy == "native" else POLICIES[policy])
        and all(
            before[key] == after[key]
            for key in ("interop", "cpu_count", "affinity", "env")
        ),
        "Actual CPU policy or unrelated scheduling metadata changed",
    )
    require(
        finite(control["configuration_seconds_included_in_native_setup"])
        and control["configuration_seconds_included_in_native_setup"] >= 0,
        "CPU configuration cost was not honestly included in setup",
    )
    return before


def resource_point(point: dict, limit: int) -> None:
    require(
        type(point["process_swap_bytes"]) is int and point["process_swap_bytes"] == 0,
        "Worker process swap was used/unavailable",
    )
    rows, host = point["cgroup"]["constraints"], point["host_memory"]
    require(
        rows and type(host["MemTotal"]) is int and host["MemTotal"] > 0,
        "Native host/cgroup resource scope absent",
    )
    limits = [host["MemTotal"]] + [
        row["memory.max"] for row in rows if type(row["memory.max"]) is int
    ]
    require(
        all(value > 0 for value in limits) and min(limits) == limit,
        "Effective native RAM minimum changed",
    )
    require(
        all(
            type(row["memory.swap.current"]) is int and row["memory.swap.current"] == 0
            for row in rows
        )
        and (
            host.get("SwapTotal", 0) == 0
            or any(row["memory.swap.max"] == 0 for row in rows)
        ),
        "Cgroup swap was used or no longer disabled",
    )


def resources(stage: dict, spec: dict) -> None:
    data = stage["resources"]
    require(
        type(data["samples"]) is int
        and data["samples"] >= 2
        and data["sample_interval_seconds"] == 0.05
        and type(data["sampled_peak_rss_bytes"]) is int
        and 0 < data["sampled_peak_rss_bytes"] <= spec["max_host_bytes"]
        and data["sampled_peak_process_swap_bytes"] == 0
        and data["sampled_peak_cgroup_swap_bytes"] == 0,
        "Phase RSS, sampling or process/cgroup no-swap gate failed",
    )
    for point in (data["before"], data["after"]):
        resource_point(point, spec["host_boundary"]["effective_limit_bytes"])
    for field in ("cuda", "cuda_including_diagnostics"):
        if field in stage:
            require(
                all(
                    type(stage[field][key]) is int
                    and 0 <= stage[field][key] <= spec["device_cap_bytes"]
                    for key in ("peak_allocated_bytes", "peak_reserved_bytes")
                ),
                "Phase exceeded the original allocator VRAM cap",
            )


def timing_phase(raw: dict, phase: str, updates: int) -> None:
    value = raw[phase]
    require(
        value["complete"] is True
        and value["updates_complete"] == updates
        and value["finite_state_checks_per_update"] is True
        and len(value["update_seconds"]) == len(value["losses"]) == updates
        and all(finite(item) and item > 0 for item in value["update_seconds"])
        and all(finite(item) for item in value["losses"]),
        "Incomplete finite training phase",
    )


def selection(rows: list[dict]) -> dict:
    require(
        [row["policy"] for row in rows] == list(EXPLORATION),
        "Exploratory fixed schedule changed",
    )
    by_policy = {}
    for row in rows:
        policy = row["policy"]
        require(
            type(row["actual_threads"]) is int
            and row["actual_threads"] > 0
            and (policy == "native" or row["actual_threads"] == POLICIES[policy])
            and len(row["step_seconds"]) == 6
            and all(finite(value) and value > 0 for value in row["step_seconds"]),
            "Exploratory timing/count metadata changed",
        )
        by_policy[policy] = row
    native = by_policy["native"]
    eligible = [
        row for row in rows if row["actual_threads"] != native["actual_threads"]
    ]
    best = min(
        eligible, key=lambda row: statistics.median(row["step_seconds"]), default=None
    )
    positive = best is not None and statistics.median(
        best["step_seconds"]
    ) < statistics.median(native["step_seconds"])
    return {
        "status": "selected_for_confirmation" if positive else "NO_CONFIRMED_WIN",
        "candidate": best["policy"] if positive else None,
        "native_actual_threads": native["actual_threads"],
        "duplicate_controls": [
            row["policy"]
            for row in rows
            if row["policy"] != "native"
            and row["actual_threads"] == native["actual_threads"]
        ],
        "exploratory_only": True,
        "not_a_confirmatory_speed_estimate": True,
    }


def confirmation(blocks: list[dict], candidate: str) -> dict:
    require(
        candidate in POLICIES and candidate != "native" and len(blocks) == 8,
        "Exactly eight independent confirmation workers required",
    )
    pair = ("native", candidate)
    orders = (pair, tuple(reversed(pair))) * 2
    pids, seen, pairs, configurations = set(), set(), {}, []
    for block in blocks:
        number, position, policy = block["round"], block["position"], block["policy"]
        require(
            type(number) is int
            and 0 <= number < 4
            and type(position) is int
            and 0 <= position < 2
            and orders[number][position] == policy
            and (number, policy) not in seen,
            "Confirmation is not fresh balanced AB/BA",
        )
        seen.add((number, policy))
        raw = block["result"]
        require(
            type(raw["pid"]) is int and raw["pid"] > 0 and raw["pid"] not in pids,
            "Confirmation reused an invalid worker process",
        )
        pids.add(raw["pid"])
        configurations.append(thread_control(raw["thread_control"], policy))
        for phase, count in (("warmup", 2), ("timing", 6)):
            timing_phase(raw, phase, count)
        pairs.setdefault(number, {})[policy] = block
    require(
        all(value == configurations[0] for value in configurations),
        "Native thread state drift",
    )
    logs, gates = [], []
    for number in range(4):
        left, right = (pairs[number][policy]["result"] for policy in pair)
        require(
            left["thread_control"]["after"]["intraop"]
            != right["thread_control"]["after"]["intraop"],
            "Duplicate native policy selected",
        )
        for phase in ("warmup", "timing"):
            loss_gate(left[phase]["losses"], right[phase]["losses"])
            gates.append(
                {
                    "round": number,
                    "stage": phase,
                    "bitwise": left[phase]["losses"] == right[phase]["losses"],
                }
            )
        logs.append(
            math.log(
                statistics.median(right["timing"]["update_seconds"])
                / statistics.median(left["timing"]["update_seconds"])
            )
        )
    rng = random.Random(29)
    draws = sorted(
        100 * (1 - math.exp(statistics.mean(rng.choices(logs, k=4))))
        for _ in range(5000)
    )
    result = {
        "reference": "native",
        "candidate": candidate,
        "paired_rounds": 4,
        "step_time_reduction_percent": 100 * (1 - math.exp(statistics.mean(logs))),
        "throughput_increase_percent": 100 * (math.exp(-statistics.mean(logs)) - 1),
        "paired_bootstrap_95_percent": [draws[124], draws[4874]],
        "passes_practical_2_percent_gate": draws[124] >= 2.0,
        "recorded_loss_gates": gates,
        "independent_of_exploratory_selection_samples": True,
    }
    return result


def window_cache(window: dict) -> dict:
    require(
        window["skip_fetches"] == 1024
        and window["requested_fetches"] == 16
        and window["profiled_fetches"] == 16
        and window["microbatch"] == 0
        and window["phase"] == "forward"
        and all(window[key] is True for key in ("started", "stopped", "restored")),
        "Profile window scope changed",
    )
    before, after = window["cache_before"], window["cache_after"]
    delta = {
        key: after[key] - before[key]
        for key in (
            "logical_fetches",
            "storage_reads",
            "storage_bytes_read",
            "materializations",
        )
    }
    delta.update(
        {
            tier + "_hits": after[tier]["hits"] - before[tier]["hits"]
            for tier in ("host", "device")
        }
    )
    require(
        delta == window["cache_delta"]
        and all(type(value) is int and value >= 0 for value in delta.values())
        and delta["logical_fetches"] == delta["materializations"] == 16
        and delta["device_hits"] == 0
        and delta["host_hits"] > 0
        and delta["storage_reads"] + delta["host_hits"] == 16,
        "Actual bounded profile did not exercise the declared non-device cache path",
    )
    return delta


def tensor_index(tensors: dict) -> dict:
    import torch

    rows = {}
    for name, value in sorted(tensors.items()):
        copied = value.detach().to("cpu", copy=True).contiguous()
        raw = copied.reshape(-1).view(torch.uint8).numpy().tobytes()
        rows[name] = {
            "dtype": str(copied.dtype),
            "shape": list(copied.shape),
            "bytes": len(raw),
            "sha256": hashlib.sha256(raw).hexdigest(),
        }
    return {
        "tensors": rows,
        "canonical_index_sha256": hashlib.sha256(
            json.dumps(rows, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest(),
    }


def profile_training_manifests(raw: dict, initial: dict) -> None:
    require(
        raw["initial_adapters"] == initial and len(initial["tensors"]) == 288,
        "Profile did not initialize the same complete attention-LoRA tensors",
    )
    names = set(initial["tensors"])
    expected = {prefix + name for prefix in ("adapter/", "gradient/") for name in names}
    expected |= {
        f"adamw/{name}/{field}"
        for name in names
        for field in ("step", "exp_avg", "exp_avg_sq")
    }
    for key in ("state_before", "state_after"):
        value = raw[key]
        rows = value["tensors"]
        require(
            set(rows) == expected
            and value["canonical_index_sha256"]
            == hashlib.sha256(
                json.dumps(rows, sort_keys=True, separators=(",", ":")).encode()
            ).hexdigest(),
            "Incomplete or changed diagnostic optimizer/gradient manifest",
        )
        require(
            all(
                row["dtype"] == "torch.float32"
                and type(row["bytes"]) is int
                and row["bytes"] > 0
                and re.fullmatch("[0-9a-f]{64}", row["sha256"])
                for row in rows.values()
            ),
            "Malformed diagnostic tensor hashes",
        )
    require(
        all(
            raw["state_before"]["tensors"][f"adamw/{name}/step"]["sha256"]
            != raw["state_after"]["tensors"][f"adamw/{name}/step"]["sha256"]
            for name in names
        ),
        "Diagnostic profile did not advance every AdamW state",
    )


def software_admission(originals: Any, registered: dict, launch: dict) -> dict:
    """Check the new CUDA13 cohort independently of its private passed status."""
    software = originals.read("software-cohort.json")
    lock = originals.read("runtime-wheel-lock.json")
    proof = originals.read("results/runtime-stack.json")
    require(
        software["torch_version"] == registered["torch"] == "2.10.0+cu130"
        and software["torch_cuda_version"] == registered["torch_cuda"] == "13.0"
        and software["required_versions"]["triton"] == registered["triton"] == "3.6.0"
        and software["required_versions"]["bitsandbytes"] == "0.50.2"
        and software["required_cuda_major"] == 13
        and software["gpu_proof_from_metadata"] is False
        and software["old_f15_or_stage_a_timing_denominator_allowed"] is False,
        "Registered CUDA13 runtime cohort or within-cohort denominator changed",
    )
    required = software["required_versions"]
    require(
        len(required) == 20
        and {name: row["version"] for name, row in lock["wheels"].items()} == required
        and software["wheel_lock_sha256"]
        == sha(originals.file("runtime-wheel-lock.json"))
        and software["metadata_sha256"]
        == sha(originals.file("cuda13-stack-metadata.json"))
        and software["transitive_metadata_sha256"]
        == sha(originals.file("cuda13-transitive-metadata.json")),
        "Official coupled wheel metadata/lock changed",
    )
    constraints = {}
    for line in originals.file("constraints.txt").read_text().splitlines():
        found = re.fullmatch(r"([A-Za-z0-9_.-]+)==([^ ;]+)", line.strip())
        if found:
            constraints[found[1].lower().replace("_", "-")] = found[2]
    require(
        all(constraints.get(name) == version for name, version in required.items()),
        "CUDA13 constraints differ from exact official wheel versions",
    )
    expected_urls = {
        name: unquote(row["url"]) + "#sha256=" + row["sha256"]
        for name, row in lock["wheels"].items()
    }
    url_names = {url: name for name, url in expected_urls.items()}
    requirements = {}
    for line in (
        originals.file("runtime-wheel-requirements.txt").read_text().splitlines()
    ):
        if not line.strip() or line.startswith("#"):
            continue
        found = re.fullmatch(r"([A-Za-z0-9_.-]+)\s*@\s*(\S+)", line.strip())
        if found:
            name, url = found[1].lower().replace("_", "-"), unquote(found[2])
        else:
            url = unquote(line.strip())
            require(
                url in url_names,
                "Runtime wheel requirement is not a fixed official URL",
            )
            name = url_names[url]
        require(name not in requirements, "Duplicate runtime wheel requirement")
        requirements[name] = url
    require(
        requirements == expected_urls,
        "Runtime installation did not hash-lock every wheel URL",
    )
    frozen = {}
    for line in originals.file("results/pip-freeze.txt").read_text().splitlines():
        exact = re.fullmatch(r"([A-Za-z0-9_.-]+)==([^ ;]+)", line.strip())
        direct = re.fullmatch(r"([A-Za-z0-9_.-]+)\s*@\s*(\S+)", line.strip())
        if exact or direct:
            found = exact or direct
            name = found[1].lower().replace("_", "-")
            require(name not in frozen, "Duplicate installed package identity")
            frozen[name] = ("version" if exact else "url", unquote(found[2]))
    require(
        not any(
            name.startswith("nvidia-") and name.endswith("-cu12") for name in frozen
        ),
        "CUDA12 Python packages leaked into the separate CUDA13 environment",
    )
    for name, version in required.items():
        require(
            name in frozen
            and frozen[name]
            in (
                ("version", version),
                ("url", expected_urls[name]),
                ("url", expected_urls[name].split("#", 1)[0]),
            ),
            "Actual pip-freeze package differs from the registered runtime: " + name,
        )
    require(
        proof["schema_version"] == 1
        and proof["status"] == "passed_runtime_stack_admission"
        and proof["actual_versions"] == required
        and proof["torch_actual_version"] == registered["torch"]
        and proof["torch_cuda_version"] == registered["torch_cuda"]
        and proof["bitsandbytes_actual_version"] == "0.50.2"
        and proof["cuda_available"] is True
        and type(proof["cuda_visible_device_count"]) is int
        and proof["cuda_visible_device_count"] == 1
        and proof["bitsandbytes_compiled_with_cuda"] is True,
        "Actual installed/imported runtime admission failed or was relabelled",
    )
    require(
        proof["helper_path"] == "/root/liger/runtime_stack.py"
        and proof["helper_sha256"]
        == launch["files"]["runtime_stack.py"]["sha256"]
        == sha(originals.file("runtime_stack.py"))
        and proof["cohort_sha256"] == sha(originals.file("software-cohort.json"))
        and proof["wheel_lock_sha256"]
        == sha(originals.file("runtime-wheel-lock.json")),
        "Actual runtime helper/cohort/wheel-lock provenance differs",
    )
    bnb = PurePosixPath(proof["bitsandbytes_module_path"])
    library = PurePosixPath(proof["bitsandbytes_actual_library_path"])
    require(
        library.parent == bnb.parent
        and library.name
        == software["bitsandbytes_required_native_library"]
        == "libbitsandbytes_cuda130.so"
        and str(bnb).startswith("/root/liger/venv/")
        and proof["torch_module_path"].startswith("/root/liger/venv/")
        and re.fullmatch("[0-9a-f]{64}", proof["bitsandbytes_actual_library_sha256"])
        and finite(proof["unix_started"])
        and finite(proof["unix_completed"])
        and proof["unix_started"] <= proof["unix_completed"],
        "bitsandbytes loaded a foreign/CPU backend or runtime scope is incomplete",
    )
    return {
        "actual_admission": proof,
        "registered": software,
        "wheel_lock_sha256": software["wheel_lock_sha256"],
        "constraints_sha256": sha(originals.file("constraints.txt")),
        "scope": "Separate CUDA13 runtime; every speed denominator uses its own native arm",
    }


class Originals:
    def __init__(self, stage: Path):
        self.stage, self.root = stage, stage / "retained"
        self.outer = read(stage / "archive-manifest.json")
        self.bundle = read(stage / "bundle-verified.json")
        outer, bundle = self.outer, self.bundle
        require(
            outer["source_commit"] == SOURCE
            and bundle["expected_source_commit"]
            == bundle["export_source_commit"]
            == SOURCE
            and bundle["all_manifested_raw_files_retained"] is True
            and bundle["whole_archive_verified"] is True
            and bundle["per_range_hashes_verified"] is True,
            "Incomplete raw retention",
        )
        path = stage / "result.lossless.tar"
        require(
            path.stat().st_size == outer["archive_bytes"] == bundle["bytes"]
            and sha(path) == outer["sha256"] == bundle["sha256"],
            "Encoded archive hash failed",
        )
        with tarfile.open(path, "r:") as archive:
            members = archive.getmembers()
            require(
                len({row.name for row in members}) == len(members)
                and all(row.isfile() for row in members),
                "Archive contains special/duplicate files",
            )
            meta = archive.getmember("original-files.json")
            require(0 < meta.size < 64 * 2**20, "Lossless manifest is unbounded")
            self.inner = json.load(archive.extractfile(meta))
            inner = self.inner
            require(
                inner["format"]
                == outer["format"]
                == bundle["format"]
                == "soup-lossless-results-v1"
                and inner["chunk_bytes"] == CHUNK,
                "Lossless archive format changed",
            )
            require(
                {
                    key: {name: row[name] for name in ("bytes", "sha256")}
                    for key, row in inner["files"].items()
                }
                == outer["files"],
                "Inner/outer original manifests differ",
            )
            objects = inner["objects"]
            require(
                {row.name for row in members}
                == {"original-files.json"}
                | {"objects/" + identity for identity in objects},
                "Unexpected lossless payload member",
            )
            active = set()

            @functools.lru_cache(maxsize=8)
            def decode(identity):
                require(
                    identity not in active
                    and len(active) < 32
                    and re.fullmatch("[0-9a-f]{64}", identity),
                    "Cyclic/noncanonical chunk",
                )
                active.add(identity)
                try:
                    row = objects[identity]
                    require(
                        type(row["bytes"]) is int
                        and 0 < row["bytes"] <= CHUNK
                        and 0 < row["encoded_bytes"] <= CHUNK,
                        "Unbounded encoded chunk",
                    )
                    member = archive.getmember("objects/" + identity)
                    require(
                        member.size == row["encoded_bytes"],
                        "Encoded chunk size mismatch",
                    )
                    payload = archive.extractfile(member).read()
                    require(
                        hashlib.sha256(payload).hexdigest() == row["encoded_sha256"],
                        "Encoded chunk SHA mismatch",
                    )
                    if row["codec"] == "zlib":
                        decoder = zlib.decompressobj()
                        data = decoder.decompress(payload, row["bytes"] + 1)
                        require(
                            decoder.eof
                            and not decoder.unused_data
                            and not decoder.unconsumed_tail,
                            "Incomplete/oversized zlib chunk",
                        )
                    else:
                        require(
                            row["codec"] == "raw" and row["width"] == 1,
                            "Unknown lossless codec",
                        )
                        data = payload
                    require(
                        len(data) == row["bytes"] and row["width"] in (1, 4),
                        "Decoded chunk size/plane mismatch",
                    )
                    if row["width"] == 4:
                        require(len(data) % 4 == 0, "Misaligned byte planes")
                        reordered, size = bytearray(len(data)), len(data) // 4
                        for index in range(4):
                            reordered[index::4] = data[
                                index * size : (index + 1) * size
                            ]
                        data = bytes(reordered)
                    if "reference" in row:
                        reference = decode(row["reference"])
                        require(
                            len(reference) == len(data), "XOR reference length differs"
                        )
                        data = (
                            int.from_bytes(data, "little")
                            ^ int.from_bytes(reference, "little")
                        ).to_bytes(len(data), "little")
                    require(
                        hashlib.sha256(data).hexdigest() == identity,
                        "Decoded chunk SHA failed",
                    )
                    return data
                finally:
                    active.remove(identity)

            for identity in objects:
                decode(identity)
            verified_bytes = 0
            for name, expected in inner["files"].items():
                file = contained(self.root, name)
                hashed, chunks, count = hashlib.sha256(), [], 0
                with file.open("rb") as stream:
                    for data in iter(lambda: stream.read(CHUNK), b""):
                        hashed.update(data)
                        chunks.append(hashlib.sha256(data).hexdigest())
                        count += len(data)
                require(
                    count == expected["bytes"]
                    and hashed.hexdigest() == expected["sha256"]
                    and chunks == expected["chunks"]
                    and all(identity in objects for identity in chunks),
                    "Complete retained original/chunk hash failed: " + name,
                )
                verified_bytes += count
        require(
            len(outer["files"]) == bundle["verified_files"]
            and verified_bytes == outer["original_bytes"] == bundle["original_bytes"],
            "Raw retention totals differ",
        )
        self.summary = {
            "verified_files": len(outer["files"]),
            "original_bytes": verified_bytes,
            "archive_bytes": path.stat().st_size,
            "archive_sha256": sha(path),
            "decoded_unique_chunks_verified": len(objects),
            "inner_manifest_sha256": hashlib.sha256(archive_bytes(inner)).hexdigest(),
        }

    def file(self, name: str) -> Path:
        require(name in self.outer["files"], "Required original absent: " + name)
        path = contained(self.root, name)
        expected = self.outer["files"][name]
        require(
            path.stat().st_size == expected["bytes"]
            and sha(path) == expected["sha256"],
            "Original changed after retention verification: " + name,
        )
        return path

    def read(self, name: str) -> Any:
        return read(self.file(name))


def archive_bytes(value: Any) -> bytes:
    return (json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n").encode()


def trace(
    originals: Originals,
    directory: str,
    parser: Any,
    *,
    tiny=False,
    expected_launch=LAUNCH,
) -> dict:
    prefix = directory.rstrip("/") + "/"
    raw = originals.read(prefix + ("proof.json" if tiny else "profile-result.json"))
    require(raw["status"] == "passed", "Diagnostic profile failed")
    summary = originals.read(prefix + "key-averages.json")
    require(
        summary["event_count"] > summary["cuda_event_count"]
        and summary["cuda_kernel_event_count"] > 0
        and summary["cuda_h2d_event_count"] > 0,
        "Actual CPU, CUDA kernel and H2D events are required",
    )
    window = raw["window"]
    require(
        window["skip_fetches"] == 1024
        and window["profiled_fetches"] == window["requested_fetches"] == 16
        and window["microbatch"] == 0
        and window["phase"] == "forward"
        and all(window[key] is True for key in ("started", "stopped", "restored")),
        "Diagnostic window changed",
    )
    retention = originals.read(prefix + "trace-retention.json")
    path = originals.file(prefix + "trace.json.gz")
    require(
        raw["trace"] == retention
        and retention["decoded_verified"] is True
        and retention["within_bound"] is True
        and retention["maximum_encoded_bytes"] == 128 * 2**20
        and retention["bytes"] == path.stat().st_size <= 128 * 2**20
        and retention["sha256"] == sha(path),
        "Lossless bounded trace identity differs",
    )
    import gzip

    decoded, size = hashlib.sha256(), 0
    with gzip.open(path, "rb") as stream:
        for data in iter(lambda: stream.read(CHUNK), b""):
            decoded.update(data)
            size += len(data)
    require(
        decoded.hexdigest() == retention["decoded_sha256"]
        and size == retention["decoded_bytes"],
        "Decoded trace byte hash differs",
    )
    timeline = parser.analyze_trace(path)
    require(
        timeline == originals.read(prefix + "timeline.json")
        and timeline["status"] == "parsed"
        and timeline["event_category_counts"].get("kernel", 0) > 0
        and timeline["event_category_counts"].get("gpu_memcpy", 0) > 0
        and any(
            row["union_us_by_kind"]["h2d"] > 0 for row in timeline["devices"].values()
        ),
        "Actual trace lacks CUDA kernels/H2D or its independent interval replay differs",
    )
    binding = raw["timeline_parser_binding"]
    require(
        binding["actual_path"] == "/root/liger/profile_timeline.py"
        and binding["sha256"] == TIMELINE
        and binding["launch_manifest_sha256"] == expected_launch,
        "Actual trace parser differs from the frozen uploaded file",
    )
    if tiny:
        require(
            raw["model_downloaded"] is False and raw["fetcher_restored"] is True,
            "Tiny profiler control downloaded model/failed restoration",
        )
    else:
        require(
            raw["timeline_sha256"] == sha(originals.file(prefix + "timeline.json"))
            and raw["timeline_parser_sha256"] == TIMELINE,
            "Profile timeline binding failed",
        )
    return {
        "window": window,
        "trace": retention,
        "timeline": timeline,
        "scope": "bounded forward window with intervening work; not a full-step causal split",
    }


def audit(stage: Path, source_root: Path, cohort: str = "a") -> dict:
    import torch

    registered = cohort_spec(cohort)
    launch_sha = registered["launch_manifest_sha256"]
    infrastructure = module("audit_cpu_foundation", FOUNDATION)
    numeric = module("audit_cpu_numeric_foundation", NUMERIC)
    parser = module("profile_timeline", TIMELINE)
    require(
        subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=source_root, text=True
        ).strip()
        == SOURCE
        and not subprocess.check_output(
            ["git", "status", "--porcelain", "--untracked-files=no"], cwd=source_root
        ).strip(),
        "Local comparator source changed",
    )
    sys.path[:0] = [str(source_root / "src"), str(source_root)]
    from benchmarks.harness import expert_cache_dispatch_qualification as q
    from benchmarks.harness import two_read_cache_common as common

    require(
        common.RTOL == 0.01 and common.ATOL == 1e-5,
        "Canonical numerical tolerances changed",
    )
    originals = Originals(stage)
    launch = originals.read("launch-manifest.json")
    require(
        launch == read(stage / "launch-manifest.json")
        and sha(stage / "launch-manifest.json") == launch_sha,
        "Executed launch manifest differs from preregistration",
    )
    for name, row in launch["files"].items():
        path = contained(stage, name)
        require(
            path.stat().st_size == row["bytes"] and sha(path) == row["sha256"],
            "Frozen local execution input changed: " + name,
        )
        if name in originals.outer["files"]:
            require(
                originals.outer["files"][name] == row,
                "Uploaded execution input changed",
            )
    require(
        sha(originals.file("cpu_overlap_probe.py")) == RUNNER
        and sha(originals.file("profile_timeline.py")) == TIMELINE
        and sha(originals.file("protocol-contract.json")) == CONTRACT_SHA,
        "Scientific runner, parser or contract changed",
    )
    source = originals.read("source-manifest.json")
    require(
        source["source_commit"] == SOURCE
        and sha(stage / "source.tar.gz") == source["archive_sha256"],
        "Production archive changed",
    )
    for name in (
        "benchmarks/harness/two_read_cache_common.py",
        "benchmarks/harness/expert_cache_dispatch_qualification.py",
    ):
        require(
            sha(source_root / name) == source["files"][name]["sha256"],
            "Comparator bytes changed",
        )
    protocol = originals.read("protocol.json")
    contract = originals.read("protocol-contract.json")
    require(
        protocol["execution_plan"] == contract
        and protocol["source_commit"] == SOURCE
        and protocol["accuracy_first"] is True
        and protocol["admission_fallback_allowed"] is False,
        "Source, accuracy-first order or no-fallback recipe changed",
    )
    require(
        protocol["financial"]["maximum_stage_usd"] == registered["maximum_stage_usd"]
        and protocol["financial"]["maximum_seconds"] == registered["maximum_seconds"],
        "Paid time/money cap changed",
    )
    rental = read(stage / "vast-rental.json")
    require(
        rental["stage_id"] == registered["stage_id"]
        and rental["maximum_usd"] == registered["maximum_stage_usd"]
        and rental["maximum_seconds"] == registered["maximum_seconds"]
        and rental["allocated_disk_gb"] == 32
        and rental["volume_size_gb"] == 112,
        "Actual lease differs from cap/disk plan",
    )
    capacity = originals.read("results/capacity-preflight.json")
    infrastructure.capacity(capacity, rental)
    infrastructure.cuda_xml(originals.file("results/gpu-preflight.xml"))
    runtime_admission = None
    if cohort == "b":
        require(
            originals.read("results/runtime-stack-preflight-exit.json")["returncode"]
            == 0,
            "New runtime-stack admission did not pass",
        )
        runtime_admission = software_admission(originals, registered, launch)
        admitted = runtime_admission["actual_admission"]
        require(
            capacity["unix"]
            < admitted["unix_started"]
            <= admitted["unix_completed"]
            <= originals.read("results/runtime-stack-preflight-exit.json")["unix"]
            < originals.read("results/gpu-preflight-exit.json")["unix"],
            "Actual software admission did not precede numerical CUDA readiness",
        )
    for name in ("gpu-preflight", "profiler-preflight", "prepare", "cpu-overlap-probe"):
        require(
            originals.read("results/" + name + "-exit.json")["returncode"] == 0,
            "Remote execution phase failed: " + name,
        )
    tiny = trace(
        originals,
        "results/profiler-preflight",
        parser,
        tiny=True,
        expected_launch=launch_sha,
    )
    spec_path = originals.file("results/prepared/spec.json")
    spec = read(spec_path)
    q.validate_protocol(spec)
    require(
        spec["environment"]["packages"]["torch"] == registered["torch"],
        "Prepared checkpoint belongs to another Torch runtime cohort",
    )
    require(
        spec["host_boundary"]["effective_limit_bytes"]
        == capacity["native_ram_limit_bytes"]
        and spec["host_boundary"]["swap_disabled"] is True,
        "Prepared native RAM scope changed",
    )
    inputs_path = originals.file("results/prepared/inputs.pt")
    require(
        sha(inputs_path) == spec["training_data_sha256"],
        "Frozen input tensor SHA changed",
    )
    inputs = torch.load(inputs_path, map_location="cpu", weights_only=True)
    require(
        inputs.dtype == torch.long and tuple(inputs.shape) == (4, 1, 512),
        "Fixed input shape changed",
    )
    pinned = originals.read("results/model-pinned.json")
    downloaded = originals.read("results/model-download.json")
    infrastructure.model_pin(pinned, downloaded)
    integrity_path = originals.file("results/checkpoint-integrity.json")
    integrity = read(integrity_path)
    prepared = originals.read("results/prepared-integrity.json")
    helper_sha = sha(originals.file("checkpoint_integrity.py"))
    checkpoint = infrastructure.checkpoint_input_integrity(
        integrity,
        pinned,
        spec,
        originals.read("results/hub-force-download-control.json"),
        prepared,
        helper_sha,
    )
    start = originals.read("results/prepare-start.json")
    require(
        start["all_thirteen_official_shards_verified"] is True
        and start["checkpoint_integrity_status"] == "passed"
        and start["helper_sha256"] == prepared["helper_sha256"] == helper_sha
        and start["checkpoint_integrity_receipt_sha256"]
        == downloaded["checkpoint_integrity_receipt_sha256"]
        == prepared["checkpoint_integrity_receipt_sha256"]
        == sha(integrity_path)
        and prepared["prepared_spec_sha256"] == sha(spec_path),
        "Before-NF4 input binding failed",
    )
    disk = infrastructure.storage_capacity(
        protocol["storage_capacity_plan"],
        originals.read("results/pre-download-disk.json"),
        originals.read("results/pre-prepare-disk.json"),
    )
    phases = originals.read("results/phase-order.json")
    records = phases["records"]
    require(
        phases["source_commit"] == SOURCE
        and phases["spec_sha256"] == sha(spec_path)
        and [(row["phase"], row["status"]) for row in records]
        == [("cpu_overlap_probe", "started"), ("cpu_overlap_probe", "completed")]
        and records[0]["command"][1:3] == ["/root/liger/cpu_overlap_probe.py", "run"]
        and records[0]["unix"] < records[1]["unix"],
        "Execution phase order changed",
    )
    require(
        capacity["unix"]
        < originals.read("results/gpu-preflight-exit.json")["unix"]
        < originals.read("results/profiler-preflight-exit.json")["unix"]
        < min(row["timestamp"] for row in integrity["events"])
        <= integrity["passed_unix"]
        <= start["unix"]
        <= originals.read("results/prepare-exit.json")["unix"]
        <= prepared["unix"]
        <= records[0]["unix"],
        "CUDA/profile/input/preparation chronology differs",
    )
    run_path = originals.file(PREFIX + "run.json")
    run = read(run_path)
    require(
        run["status"] == "completed"
        and run["accuracy_passed"] is True
        and run["execution_plan"] == contract
        and run["probe_sha256"] == RUNNER
        and run["spec_sha256"] == sha(spec_path)
        and run["protocol_sha256"] == sha(originals.file("protocol.json")),
        "Incomplete study",
    )
    _native, _worker, _common, _runtime, identity = q.project(source_root, SOURCE)
    require(
        run["identity"] == identity, "Native executed source/module identity differs"
    )
    pids, configurations, environments, work = set(), [], set(), {}

    def worker(row, policy, phase):
        require(
            row["policy"] == policy and row["phase"] == phase,
            "Outer worker role changed",
        )
        directory = PREFIX + row["directory"]
        stored = originals.read(directory + "/controller-result.json")
        require(
            stored
            == {
                key: value
                for key, value in row.items()
                if key not in ("round", "position")
            },
            "Controller-result original differs from embedded result",
        )
        proof = originals.read(directory + "/cpu-envelope.json")
        raw_path = originals.file(
            directory
            + ("/profile-result.json" if phase == "profile" else "/result.json")
        )
        raw = read(raw_path)
        require(
            row["envelope"] == proof
            and proof["source"] == identity
            and proof["status"] == raw["status"] == "passed"
            and proof["policy"] == policy
            and proof["phase"] == raw["phase"] == phase
            and proof["probe_sha256"] == RUNNER
            and proof["protocol_sha256"] == run["protocol_sha256"]
            and proof["spec_sha256"] == raw["spec_sha256"] == sha(spec_path)
            and proof["raw_sha256"] == sha(raw_path)
            and proof["pid"] == raw["pid"]
            and type(raw["pid"]) is int
            and raw["pid"] > 0
            and raw["pid"] not in pids,
            "Raw worker/provenance binding failed",
        )
        pids.add(raw["pid"])
        require(
            dict(raw, thread_control=proof["thread_control"]) == row["result"]
            and proof["threads_after_worker"] == proof["thread_control"]["after"],
            "Raw result or final scheduling state changed",
        )
        configurations.append(thread_control(proof["thread_control"], policy))
        q.validate_dispatch_evidence(proof["dispatch"], "grouped")
        q.validate_native_routes(raw, "grouped")
        require(
            raw["arm"] == "two_read_cache",
            "Baseline lost grouped/two-read/cache features",
        )
        environment = raw["environment"]
        require(
            environment["gpu_name"] == capacity["gpu_name"]
            and environment["gpu_total_bytes"]
            == spec["hardware"]["physical_vram_bytes"]
            and 7 * GIB <= environment["gpu_total_bytes"] <= 8 * GIB
            and environment["deterministic_algorithms"] is True
            and environment["allow_tf32"] is False
            and environment["versions"]["torch"] == registered["torch"]
            and environment["torch_cuda"] == registered["torch_cuda"],
            "GPU/numerical environment changed",
        )
        environments.add(json.dumps(environment, sort_keys=True))
        require(
            all(
                name not in spec["environment"]["packages"]
                or version == spec["environment"]["packages"][name]
                for name, version in environment["versions"].items()
            ),
            "Worker dependency versions differ from native preparation",
        )
        resource_point(raw["resources_before"], capacity["native_ram_limit_bytes"])
        resource_point(raw["resources_after"], capacity["native_ram_limit_bytes"])
        for name in (
            "setup",
            "accuracy",
            "warmup",
            "timing",
            "context",
            "profile_update",
            "lifecycle",
        ):
            if name in raw:
                resources(raw[name], spec)
        if phase == "profile":
            for name, updates in (("warmup", 2), ("context", 1)):
                timing_phase(raw, name, updates)
                numeric.counters(raw, name, True)
            numeric.counters(raw, "profile_update", True)
        else:
            phases = ("accuracy",) if phase == "accuracy" else ("warmup", "timing")
            for name in phases:
                counters = numeric.counters(raw, name, True)
                require(
                    name not in work or work[name] == counters,
                    "CPU policies changed cache work",
                )
                work[name] = counters
            if phase == "timing":
                timing_phase(raw, "warmup", 2)
                timing_phase(raw, "timing", 6)
        return raw, directory

    require(
        set(run["accuracy"]) == set(POLICIES),
        "Five full numerical policies are required",
    )
    native_capture, numerical, losses, profile_initial = None, {}, {}, None
    for policy in POLICIES:
        cell = run["accuracy"][policy]
        raw, directory = worker(cell["worker"], policy, "accuracy")
        capture_path = originals.file(directory + "/capture.pt")
        require(
            sha(capture_path) == raw["accuracy"]["capture_sha256"],
            "Capture SHA changed",
        )
        capture = torch.load(capture_path, map_location="cpu", weights_only=True)
        controls = q.full_capture_controls(capture, inputs, common)
        require(
            controls == cell["controls"], "Independent full structural controls differ"
        )
        if native_capture is None:
            native_capture = capture
            profile_initial = tensor_index(capture["initial_adapters"])
        comparison = common.compare_captures(native_capture, capture)
        require(
            comparison["passed"] is True and comparison == cell["versus_native"],
            "Original full optimizer/routing/gradient numerical comparison failed",
        )
        losses[policy] = controls["full_microbatch_losses"]
        numerical[policy] = comparison
        if policy != "native":
            del capture
            gc.collect()
    del native_capture
    gc.collect()
    raw_profile, profile_directory = worker(run["profile"], "native", "profile")
    profile = trace(originals, profile_directory, parser, expected_launch=launch_sha)
    profile["actual_window_cache_delta"] = window_cache(raw_profile["window"])
    require(
        raw_profile["input_sha256"] == spec["training_data_sha256"],
        "Profile used different frozen input tokens",
    )
    profile_training_manifests(raw_profile, profile_initial)
    require(
        raw_profile["profile_update"]["updates"] == 1
        and raw_profile["profile_update"]["microbatches"] == 2
        and len(raw_profile["profile_update"]["losses"]) == 2
        and all(finite(value) for value in raw_profile["profile_update"]["losses"]),
        "Diagnostic update incomplete/nonfinite",
    )
    require(
        [row["policy"] for row in run["exploration"]] == list(EXPLORATION),
        "Exploration order changed",
    )
    exploration_raw, exploratory_absolute = {}, {}
    for cell in run["exploration"]:
        policy = cell["policy"]
        raw, _directory = worker(cell["worker"], policy, "timing")
        require(
            cell["actual_threads"]
            == cell["worker"]["envelope"]["thread_control"]["after"]["intraop"]
            and cell["step_seconds"] == raw["timing"]["update_seconds"],
            "Exploratory selection metadata differs from original times",
        )
        loss_gate(losses[policy][1::2], raw["warmup"]["losses"])
        exploration_raw[policy] = raw
        exploratory_absolute[policy] = {
            "exploratory_only": True,
            "actual_intraop": cell["actual_threads"],
            "update_seconds": raw["timing"]["update_seconds"],
            "median_step_seconds": statistics.median(raw["timing"]["update_seconds"]),
            "setup_seconds": raw["setup"]["seconds"],
            "whole_entry_seconds": cell["worker"]["fresh_process_wall_seconds"],
            "peak_step_allocated_bytes": raw["timing"]["cuda"]["peak_allocated_bytes"],
            "peak_step_reserved_bytes": raw["timing"]["cuda"]["peak_reserved_bytes"],
            "peak_sampled_rss_bytes": raw["timing"]["resources"][
                "sampled_peak_rss_bytes"
            ],
        }
    for raw in exploration_raw.values():
        for phase in ("warmup", "timing"):
            loss_gate(exploration_raw["native"][phase]["losses"], raw[phase]["losses"])
    selected = selection(run["exploration"])
    require(
        selected == run["selection"],
        "Exploratory winner was changed after observing confirmation",
    )
    confirmed, absolute = None, {}
    if selected["candidate"] is None:
        require(
            not run["confirmation"] and "confirmation_summary" not in run,
            "Unselected exploratory policy received confirmation",
        )
    else:
        for block in run["confirmation"]:
            raw, _directory = worker(block, block["policy"], "timing")
            loss_gate(losses[block["policy"]][1::2], raw["warmup"]["losses"])
        confirmed = confirmation(run["confirmation"], selected["candidate"])
        require(
            confirmed == run["confirmation_summary"],
            "Independent confirmation estimate differs",
        )
        for policy in ("native", selected["candidate"]):
            rows = [row for row in run["confirmation"] if row["policy"] == policy]
            absolute[policy] = {
                "median_step_seconds": statistics.median(
                    value
                    for row in rows
                    for value in row["result"]["timing"]["update_seconds"]
                ),
                "median_setup_seconds": statistics.median(
                    row["result"]["setup"]["seconds"] for row in rows
                ),
                "median_whole_entry_seconds": statistics.median(
                    row["fresh_process_wall_seconds"] for row in rows
                ),
                "max_step_allocated_bytes": max(
                    row["result"]["timing"]["cuda"]["peak_allocated_bytes"]
                    for row in rows
                ),
                "max_step_reserved_bytes": max(
                    row["result"]["timing"]["cuda"]["peak_reserved_bytes"]
                    for row in rows
                ),
                "max_sampled_timing_rss_bytes": max(
                    row["result"]["timing"]["resources"]["sampled_peak_rss_bytes"]
                    for row in rows
                ),
            }
    require(
        len(pids) == (19 if confirmed else 11)
        and len(environments) == 1
        and all(value == configurations[0] for value in configurations),
        "Fresh process count, environment or native scheduling drifted",
    )
    infrastructure.cleanup(
        rental,
        read(stage / "vast-deletion.json"),
        read(stage / "vast-volume-deletion.json"),
        read(stage / "independent-vast-absence.json"),
        originals.bundle,
    )
    ledger = read(stage / "stage-ledger.json")
    costs = [
        row
        for row in ledger["completed_leases"]
        if row["instance_id"] == rental["instance_id"]
        and row["volume_id"] == rental["volume_id"]
    ]
    require(
        len(costs) == 1
        and costs[0]["verified_absent"] is True
        and costs[0]["volume_verified_absent"] is True
        and finite(costs[0]["conservative_usd"])
        and 0 <= costs[0]["conservative_usd"] <= registered["maximum_stage_usd"],
        "Actual conservative cost exceeded the cap or cleanup is absent",
    )
    context = read(stage / "prior-budget-context.json")
    require(
        context["cpu_overlap_additional_authorized_usd"] == 3
        and math.isclose(
            context["aggregate_remaining_before_cpu_overlap_usd"],
            registered["remaining_before_usd"],
            abs_tol=1e-12,
        ),
        "Authorized remaining budget changed",
    )
    status = originals.read("results/stage-status.json")
    require(
        status["status"] == originals.bundle["stage_status"]["status"] == "completed"
        and status["unix"] >= records[-1]["unix"],
        "Study did not fully complete",
    )
    return {
        "schema_version": 1,
        "status": "passed_independent_cpu_overlap_audit",
        "source_commit": SOURCE,
        "stage_id": registered["stage_id"],
        "runtime_cohort": {
            "name": cohort,
            "preregistered": registered,
            "actual_worker_environment": json.loads(next(iter(environments))),
            "software_admission": runtime_admission,
            "old_cohort_timing_denominator_allowed": False,
        },
        "audit_script_sha256": sha(Path(__file__)),
        "audit_script_filename": Path(__file__).name,
        "pre_data_auditor_sha256": (
            "a0b434b3b7f894bcaf07af3b4cfa36e8208d91de090118cd241ed4866e63b54c"
        ),
        "posthoc_change": {
            "scope": "pip-freeze URL representation only; scientific gates unchanged",
            "normalization": "exact registered wheel URL may omit the hash fragment",
            "installation_requirements": "all twenty official URL/hash locks remain mandatory",
            "timing": "post-retention metadata parser correction; not preregistered code",
        },
        "archive_manifest_sha256": sha(stage / "archive-manifest.json"),
        "bundle_verified_sha256": sha(stage / "bundle-verified.json"),
        "qualification_run_sha256": sha(run_path),
        "launch_manifest_sha256": launch_sha,
        "foundations": {
            "audit_cpu_foundation.py": FOUNDATION,
            "audit_cpu_numeric_foundation.py": NUMERIC,
            "profile_timeline.py": TIMELINE,
        },
        "retention": originals.summary,
        "workers": len(pids),
        "accuracy_gates": numerical,
        "actual_native_cpu_configuration": configurations[0],
        "selection_recomputed": selected,
        "exploration_absolute": exploratory_absolute,
        "confirmation_recomputed": confirmed,
        "confirmation_absolute": absolute,
        "speed_verdict": "CONFIRMED_PRACTICAL_WIN"
        if confirmed and confirmed["passes_practical_2_percent_gate"]
        else "NO_CONFIRMED_WIN",
        "profile": profile,
        "dynamic_tiny_profiler_preflight": tiny,
        "checkpoint_integrity": checkpoint,
        "storage_capacity": disk,
        "hardware": {
            key: capacity[key]
            for key in (
                "gpu_name",
                "gpu_memory_mib",
                "gpu_uuid",
                "native_ram_limit_bytes",
            )
        },
        "cleanup": read(stage / "independent-vast-absence.json"),
        "budget": {
            "conservative_stage_usd": costs[0]["conservative_usd"],
            "remaining_task_usd": registered["remaining_before_usd"]
            - costs[0]["conservative_usd"],
            "provider_invoice_verified": False,
        },
        "recording_limits": {
            "accuracy": "five separate complete two-update/four-micro trajectories",
            "timed_losses": "all recorded last-micro losses; first-micro scalar not persisted",
            "timed_final_tensors": "not persisted; NO VERDICT on full final timed tensor parity",
            "profile": "forward-fetch window; no backward/full-step causal split",
            "quality": "fixed random-token short updates; no convergence/task-quality verdict",
            "physical_io": "logical payload counts are not physical SSD traffic",
            "ram": "RSS excludes filesystem/kernel charges; native cgroup bound retained",
            "checkpoint": "deleted model payloads not independently rehashed by this local audit",
            "fill_uninitialized_memory": "runtime value not persisted; NO VERDICT",
            "profile_states": "same initialization; advancing AdamW hashes; no full parity",
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", type=Path, required=True)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--cohort", choices=tuple(COHORTS), default="a")
    args = parser.parse_args()
    try:
        report = audit(args.stage, args.source_root, args.cohort)
        code = 0
    except Exception as error:
        report = {
            "status": "failed_independent_cpu_overlap_audit",
            "source_commit": SOURCE,
            "stage_id": COHORTS[args.cohort]["stage_id"],
            "audit_script_sha256": sha(Path(__file__)),
        "audit_script_filename": Path(__file__).name,
        "pre_data_auditor_sha256": (
            "a0b434b3b7f894bcaf07af3b4cfa36e8208d91de090118cd241ed4866e63b54c"
        ),
        "posthoc_change": {
            "scope": "pip-freeze URL representation only; scientific gates unchanged",
            "normalization": "exact registered wheel URL may omit the hash fragment",
            "installation_requirements": "all twenty official URL/hash locks remain mandatory",
            "timing": "post-retention metadata parser correction; not preregistered code",
        },
            "error": f"{type(error).__name__}: {error}",
            "traceback": traceback.format_exc(),
        }
        code = 1
    args.out.write_text(
        json.dumps(report, indent=2, allow_nan=False) + "\n", encoding="utf-8"
    )
    from rich.console import Console

    Console().print({"status": report["status"], "output": str(args.out)})
    return code


if __name__ == "__main__":
    raise SystemExit(main())
