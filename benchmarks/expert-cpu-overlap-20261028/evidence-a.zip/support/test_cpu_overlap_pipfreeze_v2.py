"""Bounded actual pip-freeze representation controls; no benchmark metrics."""
from __future__ import annotations

import importlib
import json
import os
from pathlib import Path

import pytest

import test_audit_cpu_overlap as base

AUDIT = importlib.import_module(os.environ.get("AUDITOR_MODULE", "audit_cpu_overlap"))
ACTUAL = Path(__file__).with_name("pip-freeze-b-actual-fixture.txt")


def fixture(tmp_path):
    originals, registered, launch, proof = base.software_fixture(tmp_path, True)
    (tmp_path / "results/pip-freeze.txt").write_bytes(ACTUAL.read_bytes())
    return originals, registered, launch, proof


def test_actual_fragmentless_freeze_is_accepted(tmp_path):
    originals, registered, launch, _ = fixture(tmp_path)
    assert AUDIT.software_admission(originals, registered, launch)["actual_admission"][
        "torch_actual_version"] == "2.10.0+cu130"


@pytest.mark.parametrize("mutation", [
    "foreign_host", "wrong_wheel_version", "foreign_hash", "foreign_fragment",
    "empty_hash", "empty_fragment", "requirement_missing_hash", "requirement_wrong_hash",
    "actual_wrong_version", "version_form_wrong_version",
])
def test_foreign_identity_and_unpinned_requirements_are_rejected(tmp_path, mutation):
    originals, registered, launch, proof = fixture(tmp_path)
    freeze = tmp_path / "results/pip-freeze.txt"
    text = freeze.read_text()
    line = next(item for item in text.splitlines() if item.startswith("torch @ "))
    if mutation == "foreign_host":
        text = text.replace("download-r2.pytorch.org", "foreign.invalid")
    elif mutation == "wrong_wheel_version":
        text = text.replace("torch-2.10.0%2Bcu130", "torch-2.9.0%2Bcu130")
    elif mutation in ("foreign_hash", "foreign_fragment", "empty_hash", "empty_fragment"):
        suffix = {"foreign_hash": "#sha256=" + "0" * 64, "foreign_fragment": "#other=x",
                  "empty_hash": "#sha256=", "empty_fragment": "#"}[mutation]
        text = text.replace(line, line + suffix)
    elif mutation.startswith("requirement_"):
        path = tmp_path / "runtime-wheel-requirements.txt"
        text_req = path.read_text()
        if mutation == "requirement_missing_hash":
            text_req = "\n".join(item.split("#")[0] for item in text_req.splitlines()) + "\n"
        else:
            text_req = text_req.replace("#sha256=", "#sha256=0", 1)
        path.write_text(text_req)
    elif mutation == "actual_wrong_version":
        proof["actual_versions"] = dict(proof["actual_versions"], torch="2.9.0+cu130")
    else:
        text = text.replace(line, "torch==2.9.0+cu130")
    freeze.write_text(text)
    (tmp_path / "results/runtime-stack.json").write_text(json.dumps(proof))
    with pytest.raises(ValueError):
        AUDIT.software_admission(originals, registered, launch)


@pytest.mark.parametrize("direct", [False, True])
def test_existing_hashed_url_and_exact_version_forms_still_pass(tmp_path, direct):
    originals, registered, launch, _ = base.software_fixture(tmp_path, direct)
    assert AUDIT.software_admission(originals, registered, launch)["actual_admission"]
