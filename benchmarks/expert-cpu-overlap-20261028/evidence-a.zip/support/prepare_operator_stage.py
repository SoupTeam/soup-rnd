"""Offline operator scaffold; only a later explicit parent greenlight permits rental."""

import hashlib
import json
from pathlib import Path

from rich.console import Console

BASE = Path(__file__).parent.parent
PREP = Path(__file__).parent
OLD = BASE / "kanana-30b-final-gpu-20261026-f15"
NEW = BASE / "expert-cpu-overlap-gpu-20261028-a"
STAGE_ID = "soup-expert-cpu-overlap-20261028-a"

CORE = (
    "source.tar.gz", "source-manifest.json", "constraints.txt", "preflight_remote.py",
    "setup.sh", "remote_run.py", "remote_guard.py", "lossless_results.py",
    "upload-probe.bin", "checkpoint_integrity.py", "storage-capacity-plan.json",
    "api_rate_limit.py", "api_transport.py", "cloud.py", "controller.py", "launch.py",
    "transport.py", "range_transport.py", "diagnostics.py", "prepare_freeze.py",
    "launch_safety.py", "test_controller.py", "test_native_transport.py",
    "test_setup_bytes.py", "test_diagnostic_receipt.py", "test_diagnostics_concurrency.py",
    "test_f13_cross_process.py",
)
UNCHANGED = {
    "source.tar.gz", "source-manifest.json", "constraints.txt", "preflight_remote.py",
    "setup.sh", "remote_guard.py", "lossless_results.py", "upload-probe.bin",
    "checkpoint_integrity.py", "storage-capacity-plan.json", "api_rate_limit.py",
    "api_transport.py", "range_transport.py", "diagnostics.py",
}


def main():
    assert json.loads((OLD / "independent-vast-absence.json").read_text())["verified_absent"]
    assert json.loads((OLD / "bundle-verified.json").read_text())["all_manifested_raw_files_retained"]
    assert hashlib.sha256((OLD / "source.tar.gz").read_bytes()).hexdigest() == (
        "0062717d0c9512649a9971c41a3918c9323f41516cdef47e21220f32e485bd71")
    NEW.mkdir(exist_ok=False)
    for name in CORE:
        data = (OLD / name).read_bytes()
        if name not in UNCHANGED:
            text = data.decode().replace("soup-kanana-30b-final-20261026-f15", STAGE_ID)
            text = text.replace("kanana-30b-final-gpu-20261026-f15", NEW.name)
            text = text.replace("soup_kanana_30b_final_20261026_f15",
                                "soup_expert_cpu_overlap_20261028_a")
            text = text.replace("F15", "CPU overlap")
            if name in {"cloud.py", "launch.py", "test_controller.py"}:
                text = text.replace("14400", "10800").replace("4-hour", "3-hour")
            if name == "cloud.py":
                text = text.replace("USD3.786765941175221", "USD3.1857075442141882")
            if name in {"controller.py", "transport.py"}:
                text = text.replace("final_comparison.py", "cpu_overlap_probe.py")
            data = text.replace("\r\n", "\n").encode()
        (NEW / name).write_bytes(data)
    old_protocol = json.loads((OLD / "protocol.json").read_text())
    value = {key: old_protocol[key] for key in (
        "schema_version", "accuracy_first", "source_commit", "model", "cuda_test_selectors",
        "cuda_expected_case_names", "admission_fallback_allowed", "native_boundary", "retention",
        "financial", "transport", "checkpoint_input_integrity", "storage_capacity_plan")}
    value["stage_id"] = STAGE_ID
    value["financial"]["maximum_seconds"] = 10800
    value["purpose"] = "CPU thread qualification and bounded expert forward-window profiling"
    value["execution_plan"] = {
        "cpu_overlap_probe": True, "f15_qualification_claim_allowed": False,
        "profile_after_accuracy": True, "thread_timing_is_exploratory": True,
        "ordinary_streaming_timing": False, "contract_complete": False}
    value["performance"] = {
        "runner": "/root/liger/cpu_overlap_probe.py",
        "baseline": "grouped native CPU threads with two-read/static RAM8GiB/GPU2GiB",
        "requested_cpu_thread_candidates": [1, 2, 4, 8],
        "bounded_forward_window_experts": 16,
        "all_128_expert_fetch_profile_allowed": False,
        "canonical_parent_runner_contract_pending": True}
    (NEW / "protocol.json").write_text(json.dumps(value, indent=2) + "\n")
    previous_context = json.loads((OLD / "prior-budget-context.json").read_text())
    cost = sum(row["conservative_usd"] for row in json.loads(
        (OLD / "stage-ledger.json").read_text())["completed_leases"])
    assert cost == .6010583969610324
    previous_context["completed_f15_cost_usd"] = cost
    previous_context["aggregate_remaining_before_cpu_overlap_usd"] = 3.1857075442141882
    previous_context["new_stage_cap_usd"] = 3.
    previous_context["active_sibling_reservation_usd"] = 0.
    previous_context["semantics"] += (
        " Completed F15 cost deducted once. CPU overlap is a new preregistered study,"
        " not an F15-qualified reproduction. No additional allocation authorization implied.")
    (NEW / "prior-budget-context.json").write_text(json.dumps(previous_context, indent=2) + "\n")
    (NEW / "WORKPLAN.md").write_text(
        "# CPU parallelism and expert forward-window probe\n\n"
        "Offline scaffold only. No rental or freeze until parent runner, exact new protocol, "
        "CPU controls, independent review and fresh specific quote. Source43cf/archive0062717, "
        "official13 input hashes and bounded repair, GPU8/nativeRAM<=32GiB/noSwap, root32/data112 "
        "with actual free floors16/100GiB remain fixed. New cap3USD/3h/90GB+2GB within "
        "remaining3.1857075442141882USD. Accuracy first for actual CPU1/2/4/8 configurations; "
        "bounded16-expert diagnostic CUDA/H2D profile next, exploratory timings separately. "
        "Never claim this is F15 qualification or infer speed from profiler data. Native "
        "setup OMP/MKL defaults are1 and must be observed explicitly by runner. Full raw "
        "retention and exact owned instance+volume cleanup mandatory; colleague assets untouched.\n")
    Console().print({"new_stage": str(NEW), "source_archive_unchanged": True,
                     "rental_started": False, "runner_contract_pending": True})


if __name__ == "__main__":
    main()
