"""Five true auditor mutants must be killed by selected meaningful controls."""

from __future__ import annotations

import hashlib
import json
import subprocess
import sys
import tempfile
from pathlib import Path

from rich.console import Console

ROOT = Path(__file__).parent


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    original = (ROOT / "audit_cpu_overlap.py").read_text()
    cases = (
        (
            "skip_decoded_sha",
            'hashlib.sha256(data).hexdigest() == identity, "Decoded chunk SHA failed"',
            'True, "Decoded chunk SHA failed"',
            "test_decoded_chunk_sha_is_required_even_when_encoded_hash_is_resealed",
        ),
        (
            "relax_practical_ci",
            '"passes_practical_2_percent_gate": draws[124] >= 2.0',
            '"passes_practical_2_percent_gate": draws[124] >= 0.0',
            "test_independent_confirmatory_formula_and_practical_ci_gate",
        ),
        (
            "accept_ssd_only",
            'and delta["host_hits"] > 0',
            'and delta["host_hits"] >= 0',
            "test_profile_window_reject_scope_or_actual_cache_path_drift[ssd_only]",
        ),
        (
            "accept_cgroup_swap",
            'and data["sampled_peak_cgroup_swap_bytes"] == 0',
            'and data["sampled_peak_cgroup_swap_bytes"] >= 0',
            "test_resource_checks_preserve_native_no_swap_and_memory_caps[cgroup_peak]",
        ),
        (
            "select_duplicate_native",
            'row["actual_threads"] != native["actual_threads"]',
            "True",
            "test_selection_replays_exploration_and_excludes_identical_actual_native_count",
        ),
    )
    results = []
    with tempfile.TemporaryDirectory(prefix="cpu-auditor-mutations-") as temporary:
        folder = Path(temporary)
        for name, old, new, node in cases:
            if original.count(old) != 1:
                raise ValueError("Mutation target is not unique: " + name)
            mutated = original.replace(old, new)
            path = folder / (name + ".py")
            path.write_text(mutated, encoding="utf-8")
            selected_test = str(ROOT / "test_audit_cpu_overlap.py") + "::" + node
            source = (
                "import importlib.util,sys,pytest;"
                f"s=importlib.util.spec_from_file_location('audit_cpu_overlap',{str(path)!r});"
                "m=importlib.util.module_from_spec(s);sys.modules['audit_cpu_overlap']=m;"
                "s.loader.exec_module(m);"
                f"raise SystemExit(pytest.main([{selected_test!r},"
                "'-q','--tb=short','-o','addopts=']))"
            )
            process = subprocess.run(
                [sys.executable, "-c", source], capture_output=True, text=True, cwd=ROOT, timeout=60
            )
            output = process.stdout + process.stderr
            expected = any(
                marker in output for marker in ("DID NOT RAISE", "AssertionError", "E   assert ")
            )
            (ROOT / ("audit-cpu-mutation-" + name + ".log")).write_text(output, encoding="utf-8")
            if process.returncode != 1 or not expected:
                raise ValueError("Mutant was not killed by its intended assertion: " + name)
            results.append(
                {
                    "name": name,
                    "selected_test": node,
                    "returncode": process.returncode,
                    "intended_assertion_observed": expected,
                    "mutant_source_sha256": digest(mutated.encode()),
                }
            )
    value = {
        "status": "passed_five_true_independent_auditor_mutation_controls",
        "audit_script_sha256": digest((ROOT / "audit_cpu_overlap.py").read_bytes()),
        "test_source_sha256": digest((ROOT / "test_audit_cpu_overlap.py").read_bytes()),
        "killed_mutants": results,
        "gpu_or_cloud_calls": 0,
        "scope": "temporary independent audit mutants only; no frozen study/source change",
    }
    (ROOT / "audit-cpu-overlap-mutations.json").write_text(json.dumps(value, indent=2) + "\n")
    Console().print({"status": value["status"], "killed": len(results)})


if __name__ == "__main__":
    main()
