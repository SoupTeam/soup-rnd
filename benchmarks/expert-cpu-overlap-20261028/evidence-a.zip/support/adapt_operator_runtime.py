"""Build a new probe entrypoint while preserving frozen source/setup/input checks."""

import ast
from pathlib import Path

BASE = Path(__file__).parent.parent
OLD = BASE / "kanana-30b-final-gpu-20261026-f15"
NEW = BASE / "expert-cpu-overlap-gpu-20261028-a"


def main():
    text = (OLD / "remote_run.py").read_text()
    tree = ast.parse(text)
    lines = text.splitlines(keepends=True)
    keep = {"digest", "retain_exact_metadata", "save", "phase_receipt", "pre_download_disk_gate",
            "pre_prepare_disk_gate", "command", "export", "validate_cuda_xml", "main"}
    pieces = [text[:text.index("def digest(path):")].replace(
        '"""Immutable Kanana-30B baseline profiles then separate grouped-dispatch qualification."""',
        '"""New CPU-thread/forward-window study; unchanged input and resource safety gates."""')]
    for node in tree.body:
        if not isinstance(node, ast.FunctionDef) or node.name not in keep:
            continue
        part = "".join(lines[node.lineno - 1:node.end_lineno])
        if node.name == "export":
            part = part.replace("'final_comparison.py'", "'cpu_overlap_probe.py'")
        if node.name == "main":
            begin = part.index("        # This lease runs the public qualifier's")
            end = part.index("    except BaseException as exc:", begin)
            part = part[:begin] + '''        arguments = [sys.executable, str(ROOT / 'cpu_overlap_probe.py'),
                     'run', '--spec', str(spec_path), '--out', str(OUT / 'cpu-overlap'),
                     '--source-root', str(REPO), '--source-commit', manifest['source_commit'],
                     '--protocol', str(ROOT / 'protocol.json')]
        phase_receipt('cpu_overlap_probe', 'started', spec_path, arguments)
        command('cpu-overlap-probe', arguments, timeout=7200)
        validate_cpu_overlap_outputs(OUT / 'cpu-overlap', spec_path, protocol)
        phase_receipt('cpu_overlap_probe', 'completed', spec_path)
        final = {'status': 'completed', 'phase': 'complete', 'unix': time.time(),
                 'purpose': 'preregistered_cpu_overlap_probe_new_study'}
''' + part[end:]
        pieces.append(part + "\n\n\n")
    # Freeze remains impossible until the parent provides and reviews the new pure validator API.
    pieces.insert(-1, '''def validate_cpu_overlap_outputs(directory, spec_path, protocol):
    raise RuntimeError('Parent probe result-validator contract is not yet integrated')


''')
    pieces.append("if __name__ == '__main__':\n    raise SystemExit(main())\n")
    (NEW / "remote_run.py").write_text("".join(pieces))


if __name__ == "__main__":
    main()
