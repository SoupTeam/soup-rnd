"""Data-free independent audit controls; no new GPU result is used as a fixture."""

from __future__ import annotations

import copy
import gzip
import hashlib
import importlib.util
import io
import json
import math
import shutil
import struct
import tarfile
from pathlib import Path

import pytest

import audit_cpu_overlap as audit


def schedule():
    env = {
        key: None
        for key in (
            "OMP_NUM_THREADS",
            "MKL_NUM_THREADS",
            "OPENBLAS_NUM_THREADS",
            "NUMEXPR_NUM_THREADS",
            "TOKENIZERS_PARALLELISM",
        )
    }
    env.update(OMP_NUM_THREADS="1", MKL_NUM_THREADS="1", TOKENIZERS_PARALLELISM="false")
    return {"intraop": 1, "interop": 2, "cpu_count": 12, "affinity": list(range(12)), "env": env}


def control(policy):
    before = schedule()
    after = copy.deepcopy(before)
    after["intraop"] = 1 if policy == "native" else audit.POLICIES[policy]
    return {
        "before": before,
        "after": after,
        "requested": audit.POLICIES[policy],
        "applied_after_build": True,
        "configuration_seconds_included_in_native_setup": 0.0001,
    }


@pytest.mark.parametrize("policy", list(audit.POLICIES))
def test_thread_getters_and_fixed_scheduling_metadata(policy):
    assert audit.thread_control(control(policy), policy) == schedule()


@pytest.mark.parametrize(
    "mutation",
    [
        "requested_bool",
        "actual_count",
        "interop",
        "affinity",
        "environment",
        "cpu_count",
        "negative_cost",
        "before_build",
    ],
)
def test_thread_evidence_reject_changed_identity_or_unrelated_configuration(mutation):
    value = control("t1")
    if mutation == "requested_bool":
        value["requested"] = True
    elif mutation == "actual_count":
        value["after"]["intraop"] = 8
    elif mutation == "interop":
        value["after"]["interop"] = 8
    elif mutation == "affinity":
        value["after"]["affinity"] = [0]
    elif mutation == "environment":
        value["after"]["env"]["OMP_NUM_THREADS"] = "8"
    elif mutation == "cpu_count":
        value["after"]["cpu_count"] = 1
    elif mutation == "negative_cost":
        value["configuration_seconds_included_in_native_setup"] = -1
    else:
        value["applied_after_build"] = False
    with pytest.raises(ValueError):
        audit.thread_control(value, "t1")


def exploration(times=None):
    times = times or {"native": 10, "t1": 1, "t2": 9, "t4": 8, "t8": 12}
    return [
        {
            "policy": policy,
            "actual_threads": 1 if policy == "native" else audit.POLICIES[policy],
            "step_seconds": [times[policy]] * 6,
        }
        for policy in audit.EXPLORATION
    ]


def test_selection_replays_exploration_and_excludes_identical_actual_native_count():
    result = audit.selection(exploration())
    assert result["candidate"] == "t4"
    assert result["duplicate_controls"] == ["t1"]
    assert result["exploratory_only"] and result["not_a_confirmatory_speed_estimate"]


def test_no_positive_exploration_is_no_confirmed_win_not_zero_effect_claim():
    result = audit.selection(exploration({key: 10 for key in audit.POLICIES}))
    assert result["status"] == "NO_CONFIRMED_WIN" and result["candidate"] is None


@pytest.mark.parametrize("mutation", ["order", "count", "short", "nan", "bool", "zero"])
def test_exploration_reject_missing_or_relabelled_times(mutation):
    values = exploration()
    if mutation == "order":
        values.reverse()
    elif mutation == "count":
        values[0]["actual_threads"] = 8
    elif mutation == "short":
        values[0]["step_seconds"].pop()
    else:
        values[0]["step_seconds"][0] = {"nan": math.nan, "bool": True, "zero": 0}[mutation]
    with pytest.raises(ValueError):
        audit.selection(values)


def confirmation(ratio=0.9):
    rows = []
    pair = ("native", "t2")
    for number, order in enumerate((pair, tuple(reversed(pair))) * 2):
        for position, policy in enumerate(order):
            raw = {"pid": 100 + 2 * number + position, "thread_control": control(policy)}
            for phase, count in (("warmup", 2), ("timing", 6)):
                raw[phase] = {
                    "complete": True,
                    "updates_complete": count,
                    "finite_state_checks_per_update": True,
                    "update_seconds": [10 if policy == "native" else 10 * ratio] * count,
                    "losses": [2.0] * count,
                }
            rows.append({"round": number, "position": position, "policy": policy, "result": raw})
    return rows


def test_independent_confirmatory_formula_and_practical_ci_gate():
    result = audit.confirmation(confirmation(), "t2")
    assert result["step_time_reduction_percent"] == pytest.approx(10)
    assert result["throughput_increase_percent"] == pytest.approx(100 / 9)
    assert result["paired_bootstrap_95_percent"] == pytest.approx([10, 10])
    assert result["passes_practical_2_percent_gate"] is True
    assert audit.confirmation(confirmation(0.99), "t2")["passes_practical_2_percent_gate"] is False
    assert audit.confirmation(confirmation(1.1), "t2")["step_time_reduction_percent"] < 0


@pytest.mark.parametrize(
    "mutation",
    [
        "order",
        "reuse",
        "bad_pid",
        "count",
        "native_drift",
        "incomplete",
        "boolean_time",
        "loss",
        "short",
    ],
)
def test_confirmation_reject_scientifically_invalid_or_incomplete_blocks(mutation):
    rows = confirmation()
    if mutation == "order":
        rows[0]["position"] = 1
    elif mutation == "reuse":
        rows[0]["result"]["pid"] = rows[1]["result"]["pid"]
    elif mutation == "bad_pid":
        rows[0]["result"]["pid"] = True
    elif mutation == "count":
        rows[1]["result"]["thread_control"]["after"]["intraop"] = 8
    elif mutation == "native_drift":
        rows[2]["result"]["thread_control"]["before"]["intraop"] = 4
    elif mutation == "incomplete":
        rows[1]["result"]["timing"]["complete"] = False
    elif mutation == "boolean_time":
        rows[1]["result"]["timing"]["update_seconds"][0] = True
    elif mutation == "loss":
        rows[1]["result"]["timing"]["losses"][0] = 2.001
    else:
        rows.pop()
    with pytest.raises(ValueError):
        audit.confirmation(rows, "t2")


def window():
    return {
        "skip_fetches": 1024,
        "requested_fetches": 16,
        "profiled_fetches": 16,
        "microbatch": 0,
        "phase": "forward",
        "started": True,
        "stopped": True,
        "restored": True,
        "cache_before": {
            "logical_fetches": 1024,
            "storage_reads": 0,
            "storage_bytes_read": 0,
            "materializations": 1024,
            "host": {"hits": 1024},
            "device": {"hits": 0},
        },
        "cache_after": {
            "logical_fetches": 1040,
            "storage_reads": 0,
            "storage_bytes_read": 0,
            "materializations": 1040,
            "host": {"hits": 1040},
            "device": {"hits": 0},
        },
        "cache_delta": {
            "logical_fetches": 16,
            "storage_reads": 0,
            "storage_bytes_read": 0,
            "materializations": 16,
            "host_hits": 16,
            "device_hits": 0,
        },
    }


def test_bounded_profile_checks_actual_cache_counters_not_skip_index_assumption():
    assert audit.window_cache(window())["host_hits"] == 16


@pytest.mark.parametrize(
    "mutation",
    ["old_skip", "wide", "backward", "not_restored", "relabelled", "device_only", "ssd_only"],
)
def test_profile_window_reject_scope_or_actual_cache_path_drift(mutation):
    value = window()
    if mutation == "old_skip":
        value["skip_fetches"] = 128
    elif mutation == "wide":
        value["profiled_fetches"] = 128
    elif mutation == "backward":
        value["phase"] = "backward"
    elif mutation == "not_restored":
        value["restored"] = False
    elif mutation == "relabelled":
        value["cache_delta"]["host_hits"] = 15
    else:
        value["cache_after"]["host"]["hits"] = 1024
        value["cache_delta"]["host_hits"] = 0
        if mutation == "device_only":
            value["cache_after"]["device"]["hits"] = 16
            value["cache_delta"]["device_hits"] = 16
        else:
            value["cache_after"]["storage_reads"] = 16
            value["cache_delta"]["storage_reads"] = 16
    with pytest.raises(ValueError):
        audit.window_cache(value)


def resource_fixture():
    spec = {
        "host_boundary": {"effective_limit_bytes": 30 * audit.GIB},
        "max_host_bytes": 32 * audit.GIB,
        "device_cap_bytes": 8 * audit.GIB,
    }
    point = {
        "process_swap_bytes": 0,
        "host_memory": {"MemTotal": 32 * audit.GIB, "SwapTotal": audit.GIB},
        "cgroup": {
            "constraints": [
                {"memory.max": 30 * audit.GIB, "memory.swap.current": 0, "memory.swap.max": 0}
            ]
        },
    }
    data = {
        "before": copy.deepcopy(point),
        "after": copy.deepcopy(point),
        "samples": 3,
        "sample_interval_seconds": 0.05,
        "sampled_peak_rss_bytes": 12 * audit.GIB,
        "sampled_peak_process_swap_bytes": 0,
        "sampled_peak_cgroup_swap_bytes": 0,
    }
    return {
        "resources": data,
        "cuda": {"peak_allocated_bytes": 4 * audit.GIB, "peak_reserved_bytes": 4 * audit.GIB},
    }, spec


def test_original_native_resource_boundary_accepts_no_swap():
    audit.resources(*resource_fixture())


@pytest.mark.parametrize(
    "mutation",
    [
        "rss",
        "process_peak",
        "cgroup_peak",
        "no_samples",
        "gpu",
        "current_swap",
        "swap_max",
        "parent_lower",
        "host_lower",
    ],
)
def test_resource_checks_preserve_native_no_swap_and_memory_caps(mutation):
    value, spec = resource_fixture()
    data = value["resources"]
    if mutation == "rss":
        data["sampled_peak_rss_bytes"] = 33 * audit.GIB
    elif mutation == "process_peak":
        data["sampled_peak_process_swap_bytes"] = 4096
    elif mutation == "cgroup_peak":
        data["sampled_peak_cgroup_swap_bytes"] = 51175424
    elif mutation == "no_samples":
        data["samples"] = 0
    elif mutation == "gpu":
        value["cuda"]["peak_reserved_bytes"] = 8 * audit.GIB + 1
    elif mutation == "current_swap":
        data["after"]["cgroup"]["constraints"][0]["memory.swap.current"] = 51142656
    elif mutation == "swap_max":
        data["after"]["cgroup"]["constraints"][0]["memory.swap.max"] = "max"
    elif mutation == "parent_lower":
        data["after"]["cgroup"]["constraints"].append(
            {"memory.max": audit.GIB, "memory.swap.current": 0, "memory.swap.max": 0}
        )
    else:
        data["after"]["host_memory"]["MemTotal"] = audit.GIB
    with pytest.raises(ValueError):
        audit.resources(value, spec)


def lossless_fixture(tmp_path, random_member=False):
    path = Path(__file__).parent.parent / "expert-cpu-overlap-gpu-20261028-a/lossless_results.py"
    spec = importlib.util.spec_from_file_location("audit_test_lossless", path)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    stage, source = tmp_path / "stage", tmp_path / "source"
    stage.mkdir()
    source.mkdir()
    base = b"\0\0\x80\x3f" * 1100000
    names = ["left/capture.pt", "right/capture.pt", "same/capture.pt", "empty.txt"]
    values = [base, base[:-1] + b"\x40", base, b""]
    if random_member:
        names.append("random.bin")
        values.append(
            b"".join(hashlib.sha256(index.to_bytes(4, "little")).digest() for index in range(4096))
        )
    for name, value in zip(names, values):
        file = source / name
        file.parent.mkdir(parents=True, exist_ok=True)
        file.write_bytes(value)
    packed = helper.pack(source, names, stage / "result.lossless.tar")
    with tarfile.open(stage / "result.lossless.tar", "r:") as archive:
        inner = json.load(archive.extractfile("original-files.json"))
    outer = {
        "format": packed["format"],
        "source_commit": audit.SOURCE,
        "archive_bytes": packed["archive_bytes"],
        "sha256": packed["archive_sha256"],
        "original_bytes": packed["original_bytes"],
        "files": {
            name: {key: row[key] for key in ("bytes", "sha256")}
            for name, row in inner["files"].items()
        },
    }
    bundle = {
        "expected_source_commit": audit.SOURCE,
        "export_source_commit": audit.SOURCE,
        "all_manifested_raw_files_retained": True,
        "whole_archive_verified": True,
        "per_range_hashes_verified": True,
        "bytes": packed["archive_bytes"],
        "sha256": packed["archive_sha256"],
        "format": packed["format"],
        "verified_files": len(names),
        "original_bytes": packed["original_bytes"],
    }
    (stage / "archive-manifest.json").write_text(json.dumps(outer))
    (stage / "bundle-verified.json").write_text(json.dumps(bundle))
    shutil.copytree(source, stage / "retained")
    return stage, inner


def test_retention_independently_decodes_planes_xor_aliases_and_every_original(tmp_path):
    stage, inner = lossless_fixture(tmp_path)
    assert any("reference" in row for row in inner["objects"].values())
    result = audit.Originals(stage)
    assert result.summary["verified_files"] == 4
    assert result.summary["decoded_unique_chunks_verified"] == len(inner["objects"])
    assert result.summary["original_bytes"] == 13200000


@pytest.mark.parametrize(
    "mutation", ["raw_original", "encoded_archive", "bundle_flag", "raw_count"]
)
def test_retention_rejects_corruption_or_unverified_metadata(tmp_path, mutation):
    stage, _inner = lossless_fixture(tmp_path)
    if mutation == "raw_original":
        path = stage / "retained/left/capture.pt"
        path.write_bytes(b"wrong")
    elif mutation == "encoded_archive":
        path = stage / "result.lossless.tar"
        data = bytearray(path.read_bytes())
        data[600] ^= 1
        path.write_bytes(data)
    else:
        path = stage / "bundle-verified.json"
        value = audit.read(path)
        value["whole_archive_verified" if mutation == "bundle_flag" else "verified_files"] = False
        path.write_text(json.dumps(value))
    with pytest.raises(ValueError):
        audit.Originals(stage)


def test_decoder_rejects_corrupted_payload_even_after_outer_hashes_are_resealed(tmp_path):
    stage, _inner = lossless_fixture(tmp_path)
    path = stage / "result.lossless.tar"
    with tarfile.open(path, "r:") as archive:
        members = [(row.name, archive.extractfile(row).read()) for row in archive.getmembers()]
    name, payload = members[-1]
    members[-1] = (name, bytes([payload[0] ^ 1]) + payload[1:])
    with tarfile.open(path, "w") as archive:
        for name, payload in members:
            entry = tarfile.TarInfo(name)
            entry.size = len(payload)
            archive.addfile(entry, io.BytesIO(payload))
    for filename in ("archive-manifest.json", "bundle-verified.json"):
        target = stage / filename
        value = audit.read(target)
        value["sha256"] = audit.sha(path)
        value["archive_bytes" if filename.startswith("archive") else "bytes"] = path.stat().st_size
        target.write_text(json.dumps(value))
    with pytest.raises(ValueError, match="Encoded chunk SHA"):
        audit.Originals(stage)


def test_original_mutation_after_initial_verification_is_refused(tmp_path):
    stage, _inner = lossless_fixture(tmp_path)
    retained = audit.Originals(stage)
    (stage / "retained/empty.txt").write_text("changed")
    with pytest.raises(ValueError, match="changed after"):
        retained.file("empty.txt")


def test_decoded_chunk_sha_is_required_even_when_encoded_hash_is_resealed(tmp_path):
    stage, inner = lossless_fixture(tmp_path, random_member=True)
    identity = next(key for key, row in inner["objects"].items() if row["codec"] == "raw")
    path = stage / "result.lossless.tar"
    with tarfile.open(path, "r:") as archive:
        members = {row.name: archive.extractfile(row).read() for row in archive.getmembers()}
    payload = bytearray(members["objects/" + identity])
    payload[0] ^= 1
    members["objects/" + identity] = bytes(payload)
    inner["objects"][identity]["encoded_sha256"] = hashlib.sha256(payload).hexdigest()
    members["original-files.json"] = audit.archive_bytes(inner)
    with tarfile.open(path, "w") as archive:
        for name, payload in members.items():
            entry = tarfile.TarInfo(name)
            entry.size = len(payload)
            archive.addfile(entry, io.BytesIO(payload))
    for filename in ("archive-manifest.json", "bundle-verified.json"):
        target = stage / filename
        value = audit.read(target)
        value["sha256"] = audit.sha(path)
        value["archive_bytes" if filename.startswith("archive") else "bytes"] = path.stat().st_size
        target.write_text(json.dumps(value))
    with pytest.raises(ValueError, match="Decoded chunk SHA"):
        audit.Originals(stage)


@pytest.mark.parametrize("name", ["../secret", "/absolute", "C:/secret", "a\\b", "a/./b"])
def test_containment_refuses_noncanonical_paths(tmp_path, name):
    with pytest.raises(ValueError):
        audit.contained(tmp_path, name)


class DiagnosticOriginals:
    def __init__(self, root):
        self.root = root

    def file(self, name):
        return audit.contained(self.root, name)

    def read(self, name):
        return audit.read(self.file(name))


def trace_fixture(tmp_path, mutation=None):
    prefix = tmp_path / "results/profiler-preflight"
    prefix.mkdir(parents=True)
    parser = audit.module("profile_timeline", audit.TIMELINE)
    events = [
        {"name": "cudaMemcpyAsync HtoD", "cat": "cuda_runtime", "ph": "X", "ts": 0, "dur": 30},
        {
            "name": "nf4_dequant",
            "cat": "kernel",
            "ph": "X",
            "ts": 10,
            "dur": 10,
            "args": {"device": 0},
        },
        {
            "name": "Memcpy HtoD",
            "cat": "gpu_memcpy",
            "ph": "X",
            "ts": 15,
            "dur": 10,
            "args": {"device": 0},
        },
    ]
    if mutation == "cpu_only":
        for event in events:
            event["cat"] = "cuda_runtime"
    elif mutation == "missing_h2d":
        events[2]["name"] = "Memcpy DtoH"
    raw = json.dumps({"traceEvents": events}).encode()
    encoded = gzip.compress(raw, mtime=0)
    path = prefix / "trace.json.gz"
    path.write_bytes(encoded)
    retained = {
        "bytes": len(encoded),
        "sha256": audit.sha(path),
        "within_bound": True,
        "decoded_verified": True,
        "decoded_bytes": len(raw),
        "decoded_sha256": hashlib.sha256(raw).hexdigest(),
        "maximum_encoded_bytes": 128 * 2**20,
    }
    if mutation == "decoded_hash":
        retained["decoded_sha256"] = "0" * 64
    elif mutation == "size_gate":
        retained["maximum_encoded_bytes"] = 256 * 2**20
    timeline = parser.analyze_trace(path)
    if mutation == "forged_union":
        timeline["devices"]["0"]["busy_union_us"] = 100
    summary = {
        "event_count": 3,
        "cuda_event_count": 2,
        "cuda_kernel_event_count": 1,
        "cuda_h2d_event_count": 1,
    }
    proof = {
        "status": "passed",
        "window": window(),
        "trace": retained,
        "model_downloaded": mutation == "downloaded",
        "fetcher_restored": True,
        "timeline_parser_binding": {
            "actual_path": "/root/liger/profile_timeline.py",
            "sha256": audit.TIMELINE,
            "launch_manifest_sha256": audit.LAUNCH,
        },
    }
    if mutation == "shadow_parser":
        proof["timeline_parser_binding"]["sha256"] = "0" * 64
    for name, value in (
        ("proof.json", proof),
        ("trace-retention.json", retained),
        ("timeline.json", timeline),
        ("key-averages.json", summary),
    ):
        (prefix / name).write_text(json.dumps(value))
    return DiagnosticOriginals(tmp_path), parser


def test_dynamic_profile_replays_actual_categories_and_nonadditive_interval_union(tmp_path):
    originals, parser = trace_fixture(tmp_path)
    value = audit.trace(originals, "results/profiler-preflight", parser, tiny=True)
    assert value["timeline"]["devices"]["0"]["busy_union_us"] == 15
    assert value["timeline"]["devices"]["0"]["union_us_by_kind"]["h2d"] == 10


@pytest.mark.parametrize(
    "mutation",
    [
        "cpu_only",
        "missing_h2d",
        "decoded_hash",
        "size_gate",
        "forged_union",
        "downloaded",
        "shadow_parser",
    ],
)
def test_profile_cannot_pass_by_claiming_cuda_events_or_forging_summary(mutation, tmp_path):
    originals, parser = trace_fixture(tmp_path, mutation)
    with pytest.raises(ValueError):
        audit.trace(originals, "results/profiler-preflight", parser, tiny=True)


def manifest(rows):
    return {
        "tensors": rows,
        "canonical_index_sha256": hashlib.sha256(
            json.dumps(rows, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest(),
    }


def state_manifest_fixture():
    value = {"dtype": "torch.float32", "shape": [1, 4], "bytes": 16, "sha256": "a" * 64}
    initial = manifest({f"lora-{index}": copy.deepcopy(value) for index in range(288)})
    raw = {"initial_adapters": copy.deepcopy(initial)}
    for phase in ("state_before", "state_after"):
        rows = {
            prefix + name: copy.deepcopy(value)
            for prefix in ("adapter/", "gradient/")
            for name in initial["tensors"]
        }
        rows.update(
            {
                f"adamw/{name}/{field}": copy.deepcopy(value)
                for field in ("step", "exp_avg", "exp_avg_sq")
                for name in initial["tensors"]
            }
        )
        if phase == "state_after":
            for key in rows:
                if key.endswith("/step"):
                    rows[key]["sha256"] = "b" * 64
        raw[phase] = manifest(rows)
    return raw, initial


def test_profile_state_manifest_preserves_initialization_and_advances_all_optimizer_steps():
    audit.profile_training_manifests(*state_manifest_fixture())


@pytest.mark.parametrize("mutation", ["initial", "missing_gradient", "forged_index", "no_update"])
def test_profile_tensor_manifest_rejects_incomplete_or_unadvanced_training_state(mutation):
    raw, initial = state_manifest_fixture()
    if mutation == "initial":
        raw["initial_adapters"]["tensors"]["lora-0"]["sha256"] = "0" * 64
    elif mutation == "missing_gradient":
        rows = raw["state_before"]["tensors"]
        del rows["gradient/lora-0"]
        raw["state_before"] = manifest(rows)
    elif mutation == "forged_index":
        raw["state_after"]["canonical_index_sha256"] = "0" * 64
    else:
        raw["state_after"] = copy.deepcopy(raw["state_before"])
    with pytest.raises(ValueError):
        audit.profile_training_manifests(raw, initial)


def test_native_initial_tensor_hashes_use_exact_cpu_bytes():
    import torch

    value = audit.tensor_index({"lora": torch.tensor([1.0, -0.0], dtype=torch.float32)})
    assert value["tensors"]["lora"] == {
        "dtype": "torch.float32",
        "shape": [2],
        "bytes": 8,
        "sha256": hashlib.sha256(struct.pack("<ff", 1.0, -0.0)).hexdigest(),
    }
