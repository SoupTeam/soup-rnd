"""Record the bounded offline B software review without allocating resources."""

import ast
import hashlib
import json
import xml.etree.ElementTree as ET
from pathlib import Path

from rich.console import Console

ROOT = Path(__file__).parent
STAGE = ROOT.parent/"expert-cpu-overlap-gpu-20261028-b"
OLD = ROOT.parent/"expert-cpu-overlap-gpu-20261028-a"
EXPECTED = "875cb67d59076e037c6a595179bba2cf2f7f1f6b14fa17bef341af06ea0b0da3"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert sha(STAGE/"runtime_stack.py") == sha(ROOT/"runtime_stack.py") == EXPECTED
    for name in ("source.tar.gz", "source-manifest.json", "cpu_overlap_probe.py",
                 "protocol-contract.json", "checkpoint_integrity.py", "preflight_remote.py",
                 "storage-capacity-plan.json", "remote_guard.py"):
        assert (STAGE/name).read_bytes() == (OLD/name).read_bytes(), name
    protocol = json.loads((STAGE/"protocol.json").read_text())
    old = json.loads((OLD/"protocol.json").read_text())
    for field in ("execution_plan", "native_boundary", "model", "cuda_test_selectors",
                  "cuda_expected_case_names", "storage_capacity_plan", "checkpoint_input_integrity"):
        assert protocol[field] == old[field], field
    assert protocol["financial"]["maximum_stage_usd"] == 5.6
    assert protocol["financial"]["maximum_seconds"] == 9000
    context = json.loads((STAGE/"prior-budget-context.json").read_text())
    remaining = context["cpu_overlap_a_remaining_before_usd"]-context["failed_cpu_overlap_a_cost_usd"]
    assert abs(remaining-5.678490342737433) < 1e-12
    assert context["new_stage_cap_usd"] == 5.6 < remaining
    cases = ET.parse(ROOT/"cpu-overlap-cuda13-independent.xml").findall(".//testcase")
    assert len(cases) == 18 and not any(case.find(tag) is not None for case in cases
                                      for tag in ("failure", "error", "skipped"))
    tree = ast.parse((STAGE/"remote_run.py").read_text())
    function = next(row for row in tree.body if isinstance(row, ast.FunctionDef) and row.name == "main")
    commands = [node.args[0].value for node in ast.walk(function) if isinstance(node, ast.Call)
                and isinstance(node.func, ast.Name) and node.func.id == "command"
                and node.args and isinstance(node.args[0], ast.Constant)]
    assert commands.index("runtime-stack-preflight") < commands.index("gpu-preflight")
    assert commands.index("gpu-preflight") < commands.index("profiler-preflight")
    assert commands.index("profiler-preflight") < commands.index("prepare")
    software = json.loads((STAGE/"software-cohort.json").read_text())
    lock = json.loads((STAGE/"runtime-wheel-lock.json").read_text())
    assert {key: row["version"] for key, row in lock["wheels"].items()} == software["required_versions"]
    assert len(lock["wheels"]) == 20 and sha(STAGE/"runtime-wheel-lock.json") == software["wheel_lock_sha256"]
    assert software["gpu_proof_from_metadata"] is False
    assert software["old_f15_or_stage_a_timing_denominator_allowed"] is False
    result = {"status": "passed_independent_cuda13_offline_cohort_review",
              "stage_id": protocol["stage_id"], "runtime_helper_sha256": EXPECTED,
              "source_commit": protocol["source_commit"], "source_and_scientific_gates": "unchanged",
              "runtime": "Torch2.10.0+cu130/CUDA13.0/Triton3.6.0; fresh within-cohort baseline only",
              "official_hash_locked_runtime_wheels": 20, "independent_fake_module_controls_passed": 18,
              "full_ruff_E_F_I_N_W_100": "passed", "actual_gpu_compatibility": "UNVERIFIED",
              "requires_actual_before_model_download": ["runtime admission", "four numerical CUDA cells",
                                                         "dynamic actual CUDA kernel and H2D trace"],
              "financial_cap_usd": 5.6, "maximum_seconds": 9000,
              "remaining_task_budget_usd": remaining,
              "files": {name: {"bytes": (ROOT/name).stat().st_size, "sha256": sha(ROOT/name)}
                        for name in ("runtime_stack.py", "test_cpu_overlap_cuda13_independent.py",
                                     "cpu-overlap-cuda13-independent.xml", "audit-cuda13-fixture.json")},
              "new_stage_sources": {name: sha(STAGE/name) for name in (
                  "constraints.txt", "software-cohort.json", "runtime-wheel-lock.json",
                  "runtime-wheel-requirements.txt", "setup.sh", "remote_run.py")},
              "scope": "Offline code/control/pin review only; final manifest/quote/approval separate",
              "gpu_cloud_or_git_mutations": 0}
    target = ROOT/"cpu-overlap-cuda13-independent-review.json"
    target.write_text(json.dumps(result, indent=2)+"\n")
    Console().print({"status": result["status"], "review_sha256": sha(target)})


if __name__ == "__main__":
    main()
