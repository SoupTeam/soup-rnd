"""Generate an explicitly unencrypted own key without native-shell argument ambiguity."""

import hashlib
import json
import sys
from pathlib import Path

BASE = Path(r"C:\Users\esenb\Documents\SoupResearch\expert-dispatch-profile-20261026")
STAGE = BASE.parent / "expert-cpu-overlap-gpu-20261028-b"
sys.path[:0] = [str(BASE / ".key-deps"), str(STAGE / ".deps")]

from cryptography.hazmat.primitives import serialization  # noqa: E402
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey  # noqa: E402
from rich.console import Console  # noqa: E402


private, public = STAGE / "ssh-key", STAGE / "ssh-key.pub"
assert not private.exists() and not public.exists()
key = Ed25519PrivateKey.generate()
private.write_bytes(key.private_bytes(serialization.Encoding.PEM,
                    serialization.PrivateFormat.OpenSSH, serialization.NoEncryption()))
public.write_bytes(key.public_key().public_bytes(serialization.Encoding.OpenSSH,
                   serialization.PublicFormat.OpenSSH) + b" soup-cpu-overlap-b\n")
decoded = serialization.load_ssh_private_key(private.read_bytes(), password=None)
assert decoded.public_key().public_bytes(serialization.Encoding.OpenSSH,
       serialization.PublicFormat.OpenSSH).split()[:2] == public.read_bytes().split()[:2]
proof = {"cipher": "none", "private_decodes_without_password": True,
         "key_pair_matches": True, "public_sha256": hashlib.sha256(public.read_bytes()).hexdigest()}
(STAGE / "key-control.json").write_bytes((json.dumps(proof, indent=2) + "\n").encode())
Console().print({"key_pair_verified": True, "cipher": "none"})
