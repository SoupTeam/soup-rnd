"""Resume observation/retention of the SAME B lease, never allocate or restart compute."""
import json
import sys
import time
import traceback
from pathlib import Path

STAGE = Path(__file__).parent.parent / "expert-cpu-overlap-gpu-20261028-b"
sys.path[:0] = [str(STAGE), str(STAGE / ".deps")]
import cloud  # noqa: E402
import controller  # noqa: E402
from rich.console import Console  # noqa: E402


def main():
    policy = cloud.receipt()
    assert policy["instance_id"] == 58097253 and policy["volume_id"] == 58097252
    assert policy["created_unix"] == 1793192041.9839172
    assert policy["maximum_seconds"] == 9000 and policy["maximum_usd"] == 5.6
    controller.freeze_check()
    network = json.loads((STAGE / "network-preflight.json").read_text())
    cloud.save("same-lease-monitor-recovery.json", {
        "unix": time.time(), "instance_id": policy["instance_id"],
        "volume_id": policy["volume_id"], "original_created_unix": policy["created_unix"],
        "original_deadline_unix": policy["created_unix"] + policy["maximum_seconds"],
        "lease_reallocated": False, "compute_restarted": False,
        "scope": "Root-authorized original-lease observation, retention and cleanup only",
    })
    collected = False
    exited_since = None
    try:
        while True:
            if controller._remaining(policy) <= network["recovery_reserve_seconds"]:
                raise RuntimeError("Original reserved evidence-recovery boundary reached")
            guard = controller.refresh_guard()
            if time.time() - guard["unix"] > 30:
                raise RuntimeError("Exact original remote guard telemetry is stale")
            state = json.loads(controller._remote(
                "cat /root/liger/results/stage-status.json", timeout=20))
            cloud.save("remote-stage-status.json", state)
            cloud.save("same-lease-recovery-monitor-latest.json", {
                "unix": time.time(), "remaining_seconds": controller._remaining(policy),
                "guard_unix": guard["unix"], "state": state,
            })
            Console().print({"same_lease": policy["instance_id"], "state": state,
                             "remaining_seconds": int(controller._remaining(policy))})
            if state.get("archive_ready"):
                controller.collect_archive(policy)
                collected = True
                if state.get("status") != "completed":
                    raise RuntimeError("Original GPU study failed; complete raw export retained")
                return
            exited = controller._remote(
                "test ! -f /root/liger/setup.exit || cat /root/liger/setup.exit", timeout=15)
            if exited.strip():
                exited_since = exited_since or time.monotonic()
                if time.monotonic() - exited_since > 60:
                    controller.emergency_archive()
                    controller.collect_archive(policy)
                    collected = True
                    raise RuntimeError("Original setup exited; emergency full evidence retained")
            time.sleep(12)
    except BaseException as exc:
        cloud.save("same-lease-recovery-failure.json", {
            "unix": time.time(), "type": type(exc).__name__, "error": str(exc),
            "traceback": traceback.format_exc(), "archive_collected": collected,
        })
        if not collected and controller._remaining(policy) > 210:
            try:
                controller._collect_logs()
                exported = controller._remote(
                    "test ! -s /root/liger/exports/archive-manifest.json || echo READY",
                    timeout=15, attempts=1)
                if exported.strip() != b"READY":
                    controller.emergency_archive()
                controller.collect_archive(policy)
                collected = True
            except BaseException as recovery:
                cloud.save("same-lease-recovery-collection-failure.json", {
                    "unix": time.time(), "type": type(recovery).__name__,
                    "error": str(recovery), "traceback": traceback.format_exc(),
                })
        raise
    finally:
        try:
            cloud.destroy("Root-authorized SAME B recovery finally, exact instance and volume")
        finally:
            controller.verify_absence()


if __name__ == "__main__":
    main()
