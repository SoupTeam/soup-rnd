"""Inspect official package metadata only; never execute a downloaded binary."""

from __future__ import annotations

import hashlib
import html.parser
import json
import re
import struct
import urllib.request
from pathlib import Path

BASE = Path(__file__).parent


def get(url: str, headers: dict | None = None) -> tuple[int, dict, bytes]:
    request = urllib.request.Request(url, headers=headers or {})
    with urllib.request.urlopen(request, timeout=45) as response:
        return response.status, dict(response.headers.items()), response.read(2**20)


class Links(html.parser.HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.urls = []

    def handle_starttag(self, tag, attributes) -> None:
        if tag == "a":
            data = dict(attributes)
            if data.get("href"):
                self.urls.append(data)


def main() -> None:
    status, _headers, body = get("https://download.pytorch.org/whl/cu130/torch/")
    assert status == 200
    parser = Links()
    parser.feed(body.decode())
    matches = [row for row in parser.urls if
               "torch-2.10.0%2Bcu130-cp312-cp312-manylinux_2_28_x86_64.whl" in row["href"]]
    assert len(matches) == 1, "Exact official CPython3.12 Linux wheel missing"
    wheel_url = matches[0]["href"].split("#")[0]
    status, _headers, metadata = get(wheel_url + ".metadata")
    assert status == 200
    expected = matches[0].get("data-dist-info-metadata", "")
    if expected.startswith("sha256="):
        assert hashlib.sha256(metadata).hexdigest() == expected.split("=", 1)[1]
    dependencies = [line for line in metadata.decode().splitlines()
                    if line.startswith(("Name:", "Version:", "Requires-Dist:"))]
    assert any("Version: 2.10.0+cu130" == line for line in dependencies)
    status, _headers, raw = get("https://pypi.org/pypi/bitsandbytes/0.50.2/json")
    assert status == 200
    package = json.loads(raw)
    wheels = [row for row in package["urls"] if
              row["filename"].endswith("manylinux_2_24_x86_64.whl")]
    assert len(wheels) == 1
    bnb = wheels[0]
    status, headers, tail = get(bnb["url"], {"Range": "bytes=-65536"})
    assert status == 206, "Server did not honor bounded ZIP-tail request"
    range_header = headers.get("Content-Range", headers.get("content-range", ""))
    matched = re.fullmatch(r"bytes (\d+)-(\d+)/(\d+)", range_header)
    assert matched and int(matched[3]) == bnb["size"]
    start = int(matched[1])
    end = tail.rfind(b"PK\x05\x06")
    assert end >= 0
    directory_size, directory_offset = struct.unpack_from("<II", tail, end + 12)
    offset, stop = directory_offset - start, directory_offset - start + directory_size
    assert 0 <= offset <= stop <= len(tail)
    names = []
    while offset < stop:
        assert tail[offset:offset + 4] == b"PK\x01\x02"
        name_size, extra_size, comment_size = struct.unpack_from("<HHH", tail, offset + 28)
        names.append(tail[offset + 46:offset + 46 + name_size].decode())
        offset += 46 + name_size + extra_size + comment_size
    assert any(name.endswith("libbitsandbytes_cuda130.so") for name in names)
    report = {"scope": "official metadata / wheel directory inspection; NOT a GPU proof",
              "torch_wheel": matches[0], "torch_metadata_sha256":
              hashlib.sha256(metadata).hexdigest(), "torch_dependencies": dependencies,
              "bnb_wheel": {key: bnb[key] for key in ("filename", "url", "size", "digests")},
              "bnb_native_cuda_libraries": [name for name in names if "cuda" in name
                                             and name.endswith(".so")],
              "bnb_full_binary_downloaded_or_executed": False,
              "related_primary_report": "https://github.com/pytorch/pytorch/issues/174195",
              "observed_stage_a_failure": "CUPTI_ERROR_INVALID_DEVICE(2), torch2.8cu128",
              "original_numerical_tolerances_must_remain_unchanged": True}
    (BASE / "cuda13-stack-metadata.json").write_text(json.dumps(report, indent=2) + "\n")
    from rich.console import Console

    Console().print({"torch": "2.10.0+cu130", "official_metadata_sha_verified":
                     expected.startswith("sha256="),
                     "bnb0.50.2_cuda130_library_present": True,
                     "runtime_gpu_compatibility": "UNVERIFIED; require actual preflight"})


if __name__ == "__main__":
    main()
