"""Freeze this NEW reviewed study; never rebuild source, access cloud, or allocate."""

import hashlib
import json
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).parent
sys.path[:0] = [str(ROOT), str(ROOT / ".deps")]

import controller  # noqa: E402
from rich.console import Console  # noqa: E402

LOCAL_FILES = (
    "controller.py", "launch.py", "cloud.py", "transport.py", "range_transport.py",
    "launch_safety.py", "diagnostics.py", "api_rate_limit.py", "api_transport.py",
    "prepare_freeze.py", "prior-budget-context.json", "ssh-key.pub", "key-control.json",
    "key-dacl-control.json", "test_operator_safety.py", "test_controller.py",
    "test_native_transport.py", "test_setup_bytes.py", "test_diagnostics_concurrency.py",
    "test_f13_cross_process.py", "test_runtime_stack.py", "operator-tests.xml",
    "software-lock-validation.json",
    "check_boundary_compatibility.py", "cpu-overlap-actual-boundary-compatibility.json", "cpu-overlap-independent-combined.xml",
)


def completed_cpu_controls(path, minimum):
    cases = ET.parse(path).findall(".//testcase")
    if len(cases) < minimum or any(
            item.find(tag) is not None for item in cases for tag in ("failure", "error", "skipped")):
        raise ValueError("CPU controls incomplete/failed/skipped: " + path.name)
    return len(cases)


def verify_independent_review():
    path = ROOT / "cpu-overlap-independent-review.json"
    review = json.loads(path.read_text())
    if (review.get("status") != "passed_independent_offline_runner_design_review"
            or review.get("source_commit") != "43cf0b34afe0d8850d76bf86d60663ab5c85cdb2"):
        raise ValueError("Independent design review did not pass for the fixed source")
    controls = review["independent_cpu_controls"]
    count = completed_cpu_controls(ROOT / "cpu-overlap-independent.xml", 55)
    if controls["passed"] != count or controls["failed"] != 0 or controls["skipped"] != 0:
        raise ValueError("Independent CPU review differs from its actual complete XML")
    required = {"cpu_overlap_probe.py", "profile_timeline.py", "protocol-contract.json",
                "test_cpu_overlap_independent.py", "cpu-overlap-independent.xml",
                "check_boundary_compatibility.py", "cpu-overlap-actual-boundary-compatibility.json"}
    if not required <= review.get("private_files", {}).keys():
        raise ValueError("Independent review omitted its bound sources and proof inputs")
    for name, row in review["private_files"].items():
        item = controller._contained(ROOT, name)
        if (not item.is_file() or item.stat().st_size != row["bytes"]
                or hashlib.sha256(item.read_bytes()).hexdigest() != row["sha256"]):
            raise ValueError("Independent review binding is stale: " + name)
    actual = json.loads((ROOT / "cpu-overlap-actual-boundary-compatibility.json").read_text())
    if (actual.get("runner_sha256") != hashlib.sha256(
            (ROOT / "cpu_overlap_probe.py").read_bytes()).hexdigest()
            or actual.get("f14_actual_swap_failure_rejected") is not True
            or len(actual.get("f15_actual_workers_passed", [])) != 11):
        raise ValueError("Actual boundary compatibility proof is stale or incomplete")
    return review


def main():
    if (ROOT / "vast-rental.json").exists() or (ROOT / "lease-greenlight.json").exists():
        raise RuntimeError("Do not mutate a paid or already-authorized frozen operator stage")
    source = json.loads((ROOT / "source-manifest.json").read_text())
    if (source["source_commit"] != "43cf0b34afe0d8850d76bf86d60663ab5c85cdb2"
            or source["archive_sha256"] != (
                "0062717d0c9512649a9971c41a3918c9323f41516cdef47e21220f32e485bd71")):
        raise ValueError("Frozen production source changed")
    protocol = json.loads((ROOT / "protocol.json").read_text())
    if protocol["execution_plan"] != json.loads((ROOT / "protocol-contract.json").read_text()):
        raise ValueError("Standalone preregistered contract differs from active protocol")
    verify_independent_review()
    controls = {"operator": completed_cpu_controls(ROOT / "operator-tests.xml", 72),
                "independent": completed_cpu_controls(ROOT / "cpu-overlap-independent.xml", 55)}
    names = set(controller.REQUIRED) | set(LOCAL_FILES)
    rows = {}
    for name in sorted(names):
        path = ROOT / name
        if not path.is_file():
            raise ValueError("Missing reviewed frozen input: " + name)
        rows[name] = {"bytes": path.stat().st_size,
                      "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
    manifest = {"schema_version": 1, "study_id": protocol["stage_id"], "files": rows,
                "source_commit": source["source_commit"], "cpu_controls": controls,
                "retention_estimate_bytes": protocol["retention"]["encoded_estimate_bytes"],
                "raw_estimate_bytes": protocol["retention"]["raw_estimate_bytes"]}
    path = ROOT / "launch-manifest.json"
    path.write_text(json.dumps(manifest, indent=2) + "\n")
    controller.freeze_check()
    Console().print({"new_study_frozen": True, "inputs": len(rows), "cpu_controls": controls,
                     "manifest_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                     "rental_started": False})


if __name__ == "__main__":
    main()
