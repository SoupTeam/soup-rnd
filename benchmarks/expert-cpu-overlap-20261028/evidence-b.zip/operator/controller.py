"""One exact-owned lease: frozen inputs, verified retention, bounded collection.

Only launch.py allocates a lease. The controller's upload allowlist deliberately
excludes this file, cloud.py, private SSH material and the group credential.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import re
import shutil
import shlex
import subprocess
import sys
import tarfile
import time
import traceback
from pathlib import Path, PurePosixPath
from concurrent.futures import ThreadPoolExecutor

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT / ".deps"))

import cloud  # noqa: E402
import transport  # noqa: E402
from diagnostics import step  # noqa: E402
from rich.console import Console  # noqa: E402

REQUIRED = (
    "source.tar.gz", "source-manifest.json", "constraints.txt", "preflight_remote.py",
    "setup.sh", "remote_run.py", "remote_guard.py", "lossless_results.py",
    "runtime_stack.py", 'test_cpu_overlap_cuda13_independent.py', 'cpu-overlap-cuda13-independent.xml', 'cpu-overlap-cuda13-independent-review.json', 'audit-cuda13-fixture.json', "software-cohort.json", "runtime-wheel-lock.json",
    "runtime-wheel-requirements.txt", "cuda13-stack-metadata.json",
    "cuda13-transitive-metadata.json", "prior-attempt-a.json",
    "protocol.json", "upload-probe.bin", "cpu_overlap_probe.py", "profile_timeline.py", "protocol-contract.json",
    "test_cpu_overlap_independent.py", "cpu-overlap-independent.xml",
    "cpu-overlap-independent-review.json",
    "test_cpu_overlap_runtime.py", "cpu-overlap-controls.xml", "checkpoint_integrity.py", "storage-capacity-plan.json",
)
REMOTE = "/root/liger"
MIB = 2**20
GIB = 2**30


def _json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _sha_stream(handle):
    digest = hashlib.sha256()
    for block in iter(lambda: handle.read(8 * MIB), b""):
        digest.update(block)
    return digest.hexdigest()


def _valid_row(row):
    return (isinstance(row, dict) and type(row.get("bytes")) is int and row["bytes"] >= 0
            and isinstance(row.get("sha256"), str)
            and re.fullmatch("[0-9a-f]{64}", row["sha256"]) is not None)


def _safe_relative(name):
    if not isinstance(name, str) or not name or "\\" in name or ":" in name:
        raise ValueError("Invalid archive relative path")
    parts = name.split("/")
    if PurePosixPath(name).is_absolute() or any(
        part in ("", ".", "..") or part.endswith((".", " ")) for part in parts
    ):
        raise ValueError("Archive path is not a contained canonical relative path")
    reserved = {"CON", "PRN", "AUX", "NUL"} | {
        prefix + str(index) for prefix in ("COM", "LPT") for index in range(1, 10)
    }
    if any(part.partition(".")[0].upper() in reserved for part in parts):
        raise ValueError("Archive path uses a Windows device alias")
    return parts


def _contained(root, name):
    parts = _safe_relative(name)
    base = os.path.realpath(root)
    target = os.path.realpath(os.path.join(base, *parts))
    if os.path.normcase(os.path.commonpath((base, target))) != os.path.normcase(base):
        raise ValueError("Archive member escapes retention root")
    return Path(target)


def _validate_tar(archive, files, destination=None):
    """Never call extract/extractall: validate names/types/sizes and copy bytes ourselves."""
    if not isinstance(files, dict) or not files:
        raise ValueError("Archive must have a nonempty per-file hash manifest")
    for name, row in files.items():
        _safe_relative(name)
        if not _valid_row(row):
            raise ValueError("Invalid per-file byte/hash declaration")
    names = set()
    aliases = set()
    with tarfile.open(archive, "r:*") as source:
        for member in source:
            name = member.name.rstrip("/") if member.isdir() else member.name
            _safe_relative(name)
            if member.isdir():
                continue
            if not member.isfile() or member.issym() or member.islnk():
                raise ValueError("Archive links/devices/unsupported entries are refused")
            if name in names or name not in files:
                raise ValueError("Duplicate or unmanifested archive member")
            names.add(name)
            # Windows file aliases must not overwrite a previously verified member.
            identity = os.path.normcase(os.path.realpath(os.path.join(ROOT, *name.split("/"))))
            if identity in aliases:
                raise ValueError("Archive member aliases another file")
            aliases.add(identity)
            expected = files[name]
            if member.size != expected["bytes"]:
                raise ValueError("Archive file size differs from its manifest")
            incoming = source.extractfile(member)
            if incoming is None:
                raise ValueError("Manifested archive file could not be read")
            digest = hashlib.sha256()
            if destination is None:
                with incoming:
                    actual = _sha_stream(incoming)
            else:
                target = _contained(destination, name)
                target.parent.mkdir(parents=True, exist_ok=True)
                temporary = target.with_name(target.name + ".incoming")
                with incoming, temporary.open("xb") as sink:
                    for block in iter(lambda: incoming.read(8 * MIB), b""):
                        digest.update(block)
                        sink.write(block)
                    sink.flush()
                    os.fsync(sink.fileno())
                actual = digest.hexdigest()
                if actual == expected["sha256"]:
                    os.replace(temporary, target)
            if actual != expected["sha256"]:
                raise ValueError("Archive file SHA256 differs from its manifest")
    if names != set(files):
        raise ValueError("Archive omitted manifested files")
    return {"verified_files": len(names), "original_bytes": sum(row["bytes"] for row in files.values())}


def _unpack_lossless(archive, destination, files):
    """Restore complete opaque files, then independently verify the outer raw manifest."""
    import lossless_results

    if not isinstance(files, dict) or not files:
        raise ValueError("Lossless export requires a nonempty original-file manifest")
    aliases = set()
    for name, row in files.items():
        path = _contained(destination, name)
        if not _valid_row(row):
            raise ValueError("Invalid original-file byte/hash declaration")
        identity = str(path).casefold()
        if identity in aliases:
            raise ValueError("Original files have colliding Windows aliases")
        aliases.add(identity)
    destination = Path(destination)
    if destination.exists() and any(destination.iterdir()):
        raise ValueError("Lossless output must be a new or empty directory")
    with tarfile.open(archive, "r:") as source:
        member = source.getmember("original-files.json")
        if not member.isfile() or member.size > 64 * MIB:
            raise ValueError("Invalid bounded lossless original manifest")
        internal = json.load(source.extractfile(member))
        originals = internal.get("files")
        if not isinstance(originals, dict) or set(originals) != set(files):
            raise ValueError("Lossless inner/outer original-file sets differ")
        for name, row in originals.items():
            _contained(destination, name)
            if row.get("bytes") != files[name]["bytes"] or row.get("sha256") != files[name]["sha256"]:
                raise ValueError("Lossless inner/outer original hash or size differs")
    decoded = lossless_results.unpack(Path(archive), destination)
    if decoded["all_original_files_verified"] != len(files):
        raise ValueError("Lossless decoder omitted original files")
    for name, row in files.items():
        path = _contained(destination, name)
        if (path.is_symlink() or not path.is_file() or path.stat().st_size != row["bytes"]
                or cloud.digest(path) != row["sha256"]):
            raise ValueError("Independent original-file size/SHA verification failed")
    return {"verified_files": len(files), "original_bytes": sum(row["bytes"] for row in files.values()),
            "lossless_manifest_sha256": decoded["manifest_sha256"],
            "lossless_archive_sha256": decoded["archive_sha256"]}


def freeze_check():
    manifest = _json(ROOT / "launch-manifest.json")
    rows = manifest.get("files")
    if not isinstance(rows, dict) or not set(REQUIRED) <= rows.keys():
        raise ValueError("Launch manifest omitted required frozen inputs")
    # Controller/transport/cloud cannot drift either, even though they stay local.
    for name in ("controller.py", "launch.py", "cloud.py", "transport.py", "range_transport.py",
                 "launch_safety.py", "diagnostics.py", "api_rate_limit.py", "api_transport.py"):
        if name not in rows:
            raise ValueError("Launch manifest omitted local execution source: " + name)
    for name, expected in rows.items():
        path = _contained(ROOT, name)
        if not _valid_row(expected) or not path.is_file():
            raise ValueError("Frozen launch input is absent or malformed: " + name)
        if path.stat().st_size != expected["bytes"] or cloud.digest(path) != expected["sha256"]:
            raise ValueError("Frozen launch input changed: " + name)
    source = _json(ROOT / "source-manifest.json")
    if (not isinstance(source.get("source_commit"), str)
            or re.fullmatch("[0-9a-f]{40}", source["source_commit"]) is None
            or source.get("archive_sha256") != cloud.digest(ROOT / "source.tar.gz")):
        raise ValueError("Source commit/archive identity differs from the frozen source")
    _validate_tar(ROOT / "source.tar.gz", source.get("files"))
    from launch_safety import validate_protocol

    validate_protocol(_json(ROOT / "protocol.json"), source_commit=source["source_commit"],
                      stage_id=cloud.STAGE)
    return manifest


def _remaining(policy):
    return policy["created_unix"] + policy["maximum_seconds"] - time.time()


def _remote(command, timeout=30, attempts=3):
    return transport.ssh_retry(command, timeout=timeout, attempts=attempts).stdout


def refresh_guard():
    row = json.loads(_remote("cat /root/liger/guard-status.json", timeout=15, attempts=2))
    policy = cloud.receipt()
    if str(row.get("instance_id")) != str(policy["instance_id"]):
        raise RuntimeError("Guard telemetry belongs to a different exact instance")
    cloud.save("guard-status-latest.json", row)
    return row


def _upload(name):
    if name not in (*REQUIRED, "launch-manifest.json"):
        raise ValueError("Upload is outside the exact public-input allowlist")
    for attempt in range(3):
        try:
            with step('upload-public-input', file=name, attempt=attempt + 1, maximum_attempts=3):
                transport.upload(name)
            return
        except (OSError, EOFError, subprocess.TimeoutExpired):
            if attempt == 2:
                raise
            time.sleep(3)


def _verify_remote_inputs(names):
    program = """import hashlib,json
from pathlib import Path
root=Path('/root/liger'); manifest=json.loads((root/'launch-manifest.json').read_text())['files']
for name in %r:
 path=root/name; expected=manifest[name]
 h=hashlib.sha256()
 with path.open('rb') as f:
  for data in iter(lambda:f.read(8*2**20),b''):h.update(data)
 assert path.stat().st_size==expected['bytes'] and h.hexdigest()==expected['sha256'],name
""" % (tuple(names),)
    _remote("python3 - <<'PY'\n" + program + "PY", timeout=90)


def _native_gate():
    program = """import subprocess,sys,tarfile
from pathlib import Path
root=Path('/root/liger');(root/'repo').mkdir(exist_ok=True)
with tarfile.open(root/'source.tar.gz','r:gz') as source:
 source.extractall(root/'repo',filter='data')
with (root/'preflight.log').open('wb') as log:
 result=subprocess.run([sys.executable,str(root/'preflight_remote.py')],stdout=log,stderr=subprocess.STDOUT,timeout=90)
raise SystemExit(result.returncode)
"""
    failure = None
    try:
        _remote("python3 - <<'PY'\n" + program + "PY", timeout=150, attempts=1)
    except Exception as exc:
        failure = exc
    try:
        report = json.loads(_remote("cat /root/liger/results/capacity-preflight.json", timeout=20))
    except Exception:
        if failure is not None:
            raise failure
        raise
    cloud.save("capacity-preflight.json", report)
    if failure is not None or report.get("passed") is not True:
        raise RuntimeError("Native physical GPU/RAM/swap gate did not pass")
    return report


def _download_file(remote, target, expected_size, expected_sha, policy, *, timeout=600):
    """The retention probe and final export use authenticated ranges from byte zero."""
    import range_transport

    last_print = [0.0]

    def progress(row):
        cloud.save("range-transfer-latest.json", {**row, "artifact": Path(target).name})
        if time.monotonic() - last_print[0] >= 30 or row["range_bytes_complete"] == row["total_bytes"]:
            Console().print({"artifact": Path(target).name, "retained_bytes": row["range_bytes_complete"],
                             "total_bytes": row["total_bytes"]})
            last_print[0] = time.monotonic()

    return range_transport.download(
        remote, target, expected_size, expected_sha,
        reader=range_transport.ssh_reader(transport.stream),
        remaining=lambda: _remaining(policy), refresh=refresh_guard,
        timeout=timeout, progress=progress,
    )


def retention_preflight(policy, launch_manifest):
    estimate = launch_manifest.get("retention_estimate_bytes", 3 * GIB)
    raw_estimate = launch_manifest.get("raw_estimate_bytes", 12 * GIB)
    if type(estimate) is not int or estimate < 32 * MIB:
        raise ValueError("Retained-archive estimate must be a positive conservative byte bound")
    if type(raw_estimate) is not int or raw_estimate < 256 * MIB:
        raise ValueError("Complete raw-evidence byte estimate is required")
    if shutil.disk_usage(ROOT).free < 2 * estimate + raw_estimate + GIB:
        raise RuntimeError("Insufficient local space for archive and complete raw extraction")
    program = """import json,os,shutil
from pathlib import Path
import lossless_results as codec
root=Path('/root/liger')
corpus=root/'retention-corpus';corpus.mkdir(exist_ok=True)
names=[f'arm-{index}/capture.pt' for index in range(4)]
for name in names:(corpus/name).parent.mkdir(parents=True,exist_ok=True)
with (corpus/names[0]).open('wb') as output:
 for index in range(16):
  block=bytearray(4*2**20);entropy=os.urandom(2*2**20)
  block[2::4]=entropy[::2];block[3::4]=entropy[1::2]
  output.write(block)
shutil.copyfile(corpus/names[0],corpus/names[1])
for index in (2,3):
 with (corpus/names[0]).open('rb') as source,(corpus/names[index]).open('wb') as output:
  for block in iter(lambda:source.read(4*2**20),b''):
   block=bytearray(block)
   for position in range((index-2)*64*2**10,len(block),128*2**10):block[position]^=1
   output.write(block)
proof=codec.pack(corpus,names,root/'retention-probe.lossless.tar')
proof['files']={name:{'bytes':(corpus/name).stat().st_size,'sha256':codec.file_sha(corpus/name)} for name in names}
(root/'retention-probe.json').write_text(json.dumps(proof))
"""
    _remote("cd /root/liger && python3 - <<'PY'\n" + program + "PY", timeout=120)
    expected = json.loads(_remote("cat /root/liger/retention-probe.json"))
    if (expected.get("format") != "soup-lossless-results-v1"
            or expected.get("original_file_count") != 4 or expected.get("original_bytes") != 256 * MIB):
        raise ValueError("Retention corpus is not the declared four-file 256 MiB lossless control")
    began = time.monotonic()
    archive = ROOT / "retention-probe.lossless.tar"
    proof = _download_file(REMOTE + "/retention-probe.lossless.tar", archive,
                           expected["archive_bytes"], expected["archive_sha256"], policy, timeout=600)
    transfer_elapsed = time.monotonic() - began
    decoded = _unpack_lossless(archive, ROOT / "retention-probe-retained", expected["files"])
    elapsed = time.monotonic() - began
    rate = expected["archive_bytes"] / max(elapsed, 0.001)
    reserve = max(600, math.ceil(estimate / rate * 1.5 + 180))
    available = _remaining(policy)
    proof.update(decoded, verified=True, bytes_per_second=rate,
                 transfer_bytes_per_second=expected["archive_bytes"] / max(transfer_elapsed, 0.001),
                 retention_estimate_bytes=estimate, raw_estimate_bytes=raw_estimate,
                 original_file_count=4, synthetic_original_bytes=expected["original_bytes"],
                 encoded_archive_bytes=expected["archive_bytes"], format=expected["format"],
                 compression_result_is_synthetic=True, actual_export_size_is_authoritative=True,
                 recovery_reserve_seconds=reserve, local_free_bytes=shutil.disk_usage(ROOT).free,
                 remaining_seconds_at_retention_check=available,
                 recovery_window_admitted=reserve + 300 < available)
    # Preserve measured negative evidence before the unchanged fail-closed guard.
    cloud.save("network-preflight.json", proof)
    if reserve + 300 >= _remaining(policy):
        proof.update(recovery_window_admitted=False,
                     rejection_reason="Measured retention cannot fit the complete archive within the lease")
        cloud.save("network-preflight.json", proof)
        raise RuntimeError("Measured retention cannot fit the complete archive within the lease")
    return proof


def _collect_logs():
    for name in ("setup.log", "setup.exit", "preflight.log"):
        try:
            command = "test ! -f /root/liger/" + name + " || tail -c 1048576 /root/liger/" + name
            (ROOT / ("remote-" + name)).write_bytes(_remote(command, timeout=20, attempts=2))
        except Exception:
            pass


def emergency_archive():
    """Retain only explicit result/log paths when setup fails before normal export."""
    program = """import hashlib,json,os,shutil,tarfile,tempfile,time
from pathlib import Path
root=Path('/root/liger'); export=root/'exports'; export.mkdir(exist_ok=True)
paths=[]
for name in ('setup.log','setup.exit','preflight.log'):
 path=root/name
 if path.is_file() and not path.is_symlink(): paths.append(path)
if (root/'results').is_dir():
 for path in (root/'results').rglob('*'):
  if path.is_file() and not path.is_symlink():
   resolved=os.path.realpath(path)
   if os.path.commonpath((os.path.realpath(root/'results'),resolved))==os.path.realpath(root/'results'):
    paths.append(path)
if not paths: raise RuntimeError('No explicit emergency result/log files are available')
snapshot=Path(tempfile.mkdtemp(prefix='emergency-snapshot-',dir=export))
snapshots=[]
for path in paths:
 relative=path.relative_to(root)
 target=snapshot/relative;target.parent.mkdir(parents=True,exist_ok=True)
 shutil.copyfile(path,target);snapshots.append(target)
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for data in iter(lambda:f.read(8*2**20),b''):h.update(data)
 return h.hexdigest()
files={p.relative_to(snapshot).as_posix():{'bytes':p.stat().st_size,'sha256':digest(p)} for p in snapshots}
temp=export/'result.tar.gz.incoming'
with tarfile.open(temp,'w:gz',compresslevel=1) as tar:
 for path in snapshots: tar.add(path,arcname=path.relative_to(snapshot).as_posix(),recursive=False)
archive=export/'result.tar.gz'; os.replace(temp,archive)
commit=json.loads((root/'source-manifest.json').read_text())['source_commit'] if (root/'source-manifest.json').is_file() else None
manifest={'archive_bytes':archive.stat().st_size,'sha256':digest(archive),'files':files,
 'source_commit':commit,'stage_status':{'status':'failed','emergency_archive':True}}
temporary=export/'archive-manifest.json.incoming'; temporary.write_text(json.dumps(manifest))
os.replace(temporary,export/'archive-manifest.json')
"""
    return _remote("python3 - <<'PY'\n" + program + "PY", timeout=180, attempts=1)


def collect_archive(policy):
    manifest = json.loads(_remote("cat /root/liger/exports/archive-manifest.json", timeout=30))
    source_commit = _json(ROOT / "source-manifest.json")["source_commit"]
    emergency = isinstance(manifest.get("stage_status"), dict) and (
        manifest["stage_status"].get("emergency_archive") is True
    )
    if (manifest.get("source_commit") != source_commit
            and not (emergency and manifest.get("source_commit") is None)):
        raise ValueError("Export belongs to a different frozen source commit")
    files = manifest.get("files")
    if not isinstance(files, dict) or not files or not all(_valid_row(row) for row in files.values()):
        raise ValueError("Export lacks a complete per-file hash manifest")
    required_free = 2 * manifest["archive_bytes"] + sum(row["bytes"] for row in files.values()) + GIB
    if shutil.disk_usage(ROOT).free < required_free:
        raise RuntimeError("Insufficient space for the declared complete raw export")
    cloud.save("archive-manifest.json", manifest)
    format_name = manifest.get("format")
    if format_name not in (None, "soup-lossless-results-v1"):
        raise ValueError("Unknown exported evidence encoding")
    filename = "result.lossless.tar" if format_name else "result.tar.gz"
    target = ROOT / filename
    receipt = _download_file(REMOTE + "/exports/" + filename, target,
                             manifest["archive_bytes"], manifest["sha256"], policy,
                             timeout=max(1, int(_remaining(policy) - 180)))
    retained = ROOT / "retained"
    if retained.exists():
        raise ValueError("Refuse replacing an existing retained evidence tree")
    temporary = ROOT / ("retained-incoming-" + str(os.getpid()))
    temporary.mkdir(exist_ok=False)
    verified = (_unpack_lossless(target, temporary, files) if format_name
                else _validate_tar(target, files, temporary))
    os.replace(temporary, retained)
    receipt.update(verified, all_manifested_raw_files_retained=True,
                   expected_source_commit=source_commit, export_source_commit=manifest.get("source_commit"),
                   stage_status=manifest.get("stage_status"), format=format_name or "raw-tar-gzip",
                   encoded_archive_bytes=manifest["archive_bytes"], unix=time.time())
    cloud.save("bundle-verified.json", receipt)
    return receipt


def verify_absence():
    policy = cloud.receipt()
    instances, volumes = cloud.rows(), cloud.volume_rows()
    identity, volume = policy.get("instance_id"), policy.get("volume_id")
    instance_absent = not any(str(row.get("id")) == str(identity) for row in instances)
    volume_absent = not any(cloud.resource_id(row["id"]) == cloud.resource_id(volume)
                            for row in volumes) if volume is not None else True
    labelled_absent = not any(row.get("label") == cloud.LABEL for row in instances)
    volume_label_absent = not any(
        row.get(name) == cloud.VOLUME_LABEL for row in volumes
        for name in ("name", "label", "volume_label")
    )
    proof = {"instance_id": identity, "volume_id": volume, "label": cloud.LABEL,
             "instance_verified_absent": instance_absent, "volume_verified_absent": volume_absent,
             "label_verified_absent": labelled_absent and volume_label_absent,
             "verified_absent": instance_absent and volume_absent and labelled_absent and volume_label_absent,
             "method": "fresh read-only full account listings after exact-owned cleanup", "unix": time.time()}
    cloud.save("independent-vast-absence.json", proof)
    if not proof["verified_absent"]:
        raise RuntimeError("Fresh resource/label absence was not established")
    return proof


def probe_ssh_routes(policy):
    """Read actual container identity on both API routes before choosing any write path."""
    path = ROOT / 'api-ssh-routes.json'
    if not path.exists():
        return False
    pool = _json(path)
    if pool.get('instance_id') != policy['instance_id'] or pool.get('label') != cloud.LABEL:
        raise ValueError('SSH readiness pool belongs to another lease')
    routes = pool.get('routes', [])
    if not routes:
        return False
    program = ("import json,os;from pathlib import Path;"
               "p=json.loads(Path('/root/liger/policy.json').read_text());"
               "print(json.dumps({'actual_container_id':os.environ.get('CONTAINER_ID'),"
               "'label':p.get('label'),'source_sha256':p.get('source_sha256')}))")
    command = 'python3 -c ' + shlex.quote(program)
    def probe(route):
        began = time.monotonic()
        row = {'route': route, 'identity_verified': False}
        try:
            with step('read-only-ssh-route-probe', route_kind=route['kind'],
                      host=route['host'], port=route['port'], timeout=15):
                result = cloud.ssh(command, timeout=15, route=route)
                row['returncode'] = result.returncode
                if result.returncode:
                    row['stderr_tail'] = result.stderr.decode(errors='replace')[-400:]
                else:
                    actual = json.loads(result.stdout)
                    row.update(actual)
                    row['identity_verified'] = (str(actual.get('actual_container_id')) == str(policy['instance_id'])
                        and actual.get('label') == cloud.LABEL
                        and actual.get('source_sha256') == policy['source_sha256'])
                    if not row['identity_verified']:
                        row['error'] = 'Actual container/label/source identity differs'
        except Exception as exc:
            row.update(error_type=type(exc).__name__, error=str(exc)[:400])
        row['elapsed_seconds'] = time.monotonic() - began
        return row
    with ThreadPoolExecutor(max_workers=2) as executor:
        results = list(executor.map(probe, routes))
    record = {'instance_id': policy['instance_id'], 'label': cloud.LABEL, 'unix': time.time(),
              'source_sha256': policy['source_sha256'], 'read_only': True, 'routes': results,
              'selection_scope': 'fastest successful identity probe; actual throughput proved separately before weights'}
    cloud.save('route-readiness-' + str(time.time_ns()) + '.json', record)
    cloud.save('route-readiness.json', record)
    verified = [row for row in results if row['identity_verified']]
    if not verified:
        return False
    selected = min(verified, key=lambda row: row['elapsed_seconds'])
    cloud.save('vast-connection.json', {**selected['route'], 'identity_verified': True,
               'actual_container_id': selected['actual_container_id'],
               'source_sha256': policy['source_sha256'], 'verified_unix': time.time()})
    return True


def attach_frozen_ssh_key(policy, manifest):
    """Retry only definitive 429 refusal of the same idempotent owned-key attachment."""
    from api_transport import MutationRateLimitRefusalError, READONLY_BACKOFF

    identity = policy.get("instance_id")
    if (type(identity) is not int or identity <= 0
            or policy.get("label") != cloud.LABEL or policy.get("stage_id") != cloud.STAGE
            or policy.get("maximum_usd") != cloud.MAXIMUM_USD):
        raise ValueError("SSH attachment requires the exact-owned frozen lease")
    path = cloud.SSH_KEY.with_suffix(".pub")
    before = path.stat()
    public = path.read_bytes()
    expected = manifest.get("files", {}).get("ssh-key.pub", {})
    public_sha = hashlib.sha256(public).hexdigest()
    if expected != {"bytes": len(public), "sha256": public_sha}:
        raise ValueError("SSH public key does not match the frozen launch manifest")
    payload = {"ssh_key": public.decode("ascii").strip()}
    endpoint = f"/api/v0/instances/{identity}/ssh/"
    deadline = min(time.monotonic() + 300., time.monotonic() + _remaining(policy) - 600.)
    for attempt in range(8):
        if time.monotonic() >= deadline:
            raise TimeoutError("Bounded SSH key-attachment deadline reached")
        current = cloud.receipt()
        if any(current.get(key) != policy.get(key) for key in (
                "instance_id", "label", "stage_id", "maximum_usd", "source_sha256")):
            raise ValueError("SSH key attachment lease identity changed")
        current_stat = path.stat()
        if (current_stat.st_size, current_stat.st_mtime_ns) != (before.st_size, before.st_mtime_ns):
            raise ValueError("Frozen SSH public key changed; never attach replacement bytes")
        try:
            reply = cloud.api(endpoint, "POST", payload)
        except MutationRateLimitRefusalError as error:
            if attempt == 7:
                raise
            delay = max(READONLY_BACKOFF[attempt], error.retry_after_seconds)
            cloud.save("ssh-key-attach-refusal.json", {"instance_id": identity,
                "public_key_sha256": public_sha, "attempt": attempt + 1,
                "type": type(error).__name__, "error": str(error), "delay_seconds": delay,
                "only_exact_owned_idempotent_attachment_will_be_retried": True})
            if time.monotonic() + delay >= deadline:
                raise TimeoutError("SSH key-attachment backoff exceeds its deadline") from error
            time.sleep(delay)
            continue
        if reply.get("success") is not True:
            raise RuntimeError("Owned SSH key attachment was not confirmed")
        proof = {key: reply[key] for key in ("success", "msg", "error") if key in reply}
        proof.update(instance_id=identity, public_key_sha256=public_sha, attempts=attempt + 1,
                     bounded_idempotent_429_retry_only=True)
        cloud.save("ssh-key-attach.json", proof)
        return proof
    raise AssertionError("SSH key attachment loop exhausted without a verdict")


def wait_for_boot(policy):
    """Transient inventory throttles do not end an otherwise valid paid boot."""
    from api_transport import ReadOnlyTransientError

    boot_deadline = min(time.monotonic() + 1800, time.monotonic() + _remaining(policy) - 600)
    while time.monotonic() < boot_deadline:
        try:
            cloud.status()
            if probe_ssh_routes(policy):
                return True
        except ReadOnlyTransientError as error:
            cloud.save("boot-readonly-transient.json", {
                "type": type(error).__name__, "error": str(error), "unix": time.time(),
                "remaining_seconds": _remaining(policy), "lease_kept_alive": True})
            # This path uses only previously API-supplied exact-owned routes.
            # The SSH probe rechecks container, label and source identity before writes.
            if probe_ssh_routes(policy):
                return True
            if _remaining(policy) <= 600:
                return False
            time.sleep(min(10., max(0., boot_deadline - time.monotonic())))
            continue
        time.sleep(min(3., max(0., boot_deadline - time.monotonic())))
    return False


def main():
    manifest = freeze_check()
    policy = cloud.receipt()
    if (policy["label"] != cloud.LABEL or policy["maximum_usd"] != cloud.MAXIMUM_USD
            or policy["source_sha256"] != cloud.digest(ROOT / "source.tar.gz")):
        raise RuntimeError("Receipt differs from the exact frozen stage/source")
    ready = False
    collected = False
    try:
        attach_frozen_ssh_key(policy, manifest)
        ready = wait_for_boot(policy)
        if not ready:
            raise RuntimeError("Bounded SSH boot deadline reached")
        refresh_guard()
        early = ("upload-probe.bin", "preflight_remote.py", "source.tar.gz", "source-manifest.json", "lossless_results.py")
        for name in early:
            _upload(name)
        _upload("launch-manifest.json")
        _verify_remote_inputs(early)
        _native_gate()
        network = retention_preflight(policy, manifest)
        freeze_check()
        for name in REQUIRED:
            if name not in early:
                _upload(name)
        _verify_remote_inputs(REQUIRED)
        _remote("nohup bash /root/liger/setup.sh > /root/liger/setup.log 2>&1 < /dev/null &", timeout=20)
        last = None
        last_print = 0.0
        exited_since = None
        while True:
            if _remaining(policy) <= network["recovery_reserve_seconds"]:
                raise RuntimeError("Reserved result-recovery boundary reached")
            refresh_guard()
            raw = _remote("if test -f /root/liger/results/stage-status.json; then cat /root/liger/results/stage-status.json; else echo '{}'; fi", timeout=20)
            state = json.loads(raw)
            cloud.save("remote-stage-status.json", state)
            marker = (state.get("status"), state.get("phase"), state.get("error"))
            if marker != last or time.monotonic() - last_print >= 30:
                Console().print({"status": marker[0], "phase": marker[1],
                                 "remaining_seconds": int(_remaining(policy))})
                last, last_print = marker, time.monotonic()
                _collect_logs()
            if state.get("archive_ready"):
                collect_archive(policy)
                collected = True
                if state.get("status") != "completed":
                    raise RuntimeError("GPU stage failed; its complete raw export was retained")
                return state
            exited = _remote("test ! -f /root/liger/setup.exit || cat /root/liger/setup.exit", timeout=15)
            if exited.strip():
                exited_since = exited_since or time.monotonic()
                if time.monotonic() - exited_since > 60:
                    emergency_archive()
                    collect_archive(policy)
                    collected = True
                    raise RuntimeError("Setup exited without normal export; emergency evidence retained")
            time.sleep(12)
    except BaseException as exc:
        cloud.save("controller-failure.json", {"type": type(exc).__name__, "error": str(exc),
                                               "unix": time.time(), "archive_collected": collected,
                                               "traceback": traceback.format_exc(),
                                               "operation": (_json(ROOT / "operation-latest.json")
                                                             if (ROOT / "operation-latest.json").exists() else None)})
        if ready and not collected and _remaining(policy) > 210:
            try:
                _collect_logs()
                # Never replace an immutable normal export after a transient transfer failure.
                exported = _remote("test ! -s /root/liger/exports/archive-manifest.json || echo READY", timeout=15, attempts=1)
                if exported.strip() != b"READY":
                    emergency_archive()
                collect_archive(policy)
                collected = True
                cloud.save("controller-recovery.json", {"archive_collected": True,
                                                         "method": "emergency snapshot", "unix": time.time()})
            except Exception as recovery:
                cloud.save("collection-failure.json", {"type": type(recovery).__name__,
                                                       "error": str(recovery), "unix": time.time()})
        raise
    finally:
        if ready:
            try:
                refresh_guard()
            except Exception:
                pass

